-- LevelPilot Data - Datenpaket
-- Diese Datei ist automatisch erzeugt und Teil des Addons "LevelPilot Data".
-- Die Daten stammen aus Questie (https://github.com/Questie/Questie), Version v11.38.0
-- (Commit 454b9d072965ee8f1a881429260fcf1fac8d60f7), veroeffentlicht unter der
-- GNU General Public License Version 3. Fuer LevelPilot gekuerzt, umgeformt und fuer
-- WoW Forever umgerechnet. Dieses Paket steht ebenfalls unter der GNU GPL v3 (siehe LICENSE.txt).

local D = LevelPilotData
D.Q = D.Q or {}
;(function() local T = D.Q
T[2]={d="Bring Sharptalon's Claw to Senani Thunderheart at Splintertree Post, Ashenvale.",en={12696},l=30,n="Sharptalon's Claw",ps={6383},r=178,rl=20,si={16305},su=16305,x=2450}
T[5]={d="Speak with Chef Grual.",en={272},l=20,n="Jitters' Growling Gut",nx=93,r=77,rl=17,sn={288},x=390}
T[6]={d="Kill Garrick Padfoot and bring his head to Deputy Willem at Northshire Abbey.",en={823},l=5,n="Bounty on Garrick Padfoot",ob={i={{182}}},ps={18},r=77,rl=2,sn={823},x=335}
T[7]={d="Kill 10 Kobold Vermin, then return to Marshal McBride.",en={197},l=2,n="Kobold Camp Cleanup",nx=15,ob={k={{6}}},ps={783},r=77,rl=1,sn={197},x=170}
T[8]={d="Deliver the Nondescript Letter to Innkeeper Renee in Tirisfal Glades.",en={5688},l=5,n="A Rogue's Deal",nx=590,r=178,rl=1,sn={6784},su=7628,x=110}
T[9]={d="Farmer Saldean wants you to kill 20 Harvest Watchers.",en={233},l=15,n="The Killing Fields",ob={k={{114}}},r=77,rl=8,sn={233},x=1050}
T[10]={d="Discover the fate of Junior Surveyor Scrimshank, and bring either him or his surveying equipment to Senior Surveyor Fizzledowser in Gadgetzan.",en={7724},l=48,n="The Scrimshank Redemption",nx=110,ob={i={{8593}}},ps={82},r=0,rl=39,sn={7724},x=4400}
T[11]={d="Bring 8 Painted Gnoll Armbands to Deputy Rainer at the Barracks.",en={963},l=10,n="Riverpaw Gnoll Bounty",ob={i={{782}}},ps={76},r=77,rl=6,sn={963},x=840}
T[12]={d="Gryan Stoutmantle wants you to kill 15 Defias Trappers and 15 Defias Smugglers then return to him on Sentinel Hill.",en={234},l=12,n="The People's Militia",nx=13,ob={k={{504},{95}}},r=77,rl=9,sn={234},x=910}
T[13]={d="Gryan Stoutmantle wants you to kill 15 Defias Pillagers and 15 Defias Looters and return to him on Sentinel Hill.",en={234},l=14,n="The People's Militia",nx=14,ob={k={{589},{590}}},ps={12},r=77,rl=9,sn={234},x=980}
T[14]={d="Gryan Stoutmantle wants you to kill 15 Defias Highwaymen, 5 Defias Pathstalkers and 5 Defias Knuckledusters then return to him on Sentinel Hill.",en={234},l=17,n="The People's Militia",ob={k={{122},{121},{449}}},ps={13},r=77,rl=9,sn={234},x=1600}
T[15]={d="Kill 10 Kobold Workers, then report back to Marshal McBride.",en={197},l=3,n="Investigate Echo Ridge",nx=21,ob={k={{257}}},ps={7},r=77,rl=1,sn={197},x=250}
T[16]={en={255},l=1,n="Give Gerard a Drink",ob={i={{159}}},r=77,rl=1,sf=1,sn={255}}
T[17]={d="Bring 12 Magenta Fungus Caps to Ghak Healtouch in Thelsamar.",en={1470},l=42,n="Uldaman Reagent Run",ob={i={{8047}}},ps={2500},r=77,rl=38,sn={1470},tg=81,x=3450,z=1337}
T[18]={d="Bring 12 Red Burlap Bandanas to Deputy Willem outside the Northshire Abbey.",en={823},l=4,n="Brotherhood of Thieves",ob={i={{752}}},ps={783},r=77,rl=2,sn={823},x=355}
T[19]={d="Bring Tharil'zun's Head to Marshal Marris in Redridge.",en={382},l=25,n="Tharil'zun",ob={i={{1260}}},ps={20},r=77,rl=18,sn={382},tg=1,x=2550}
T[20]={d="Bring 10 Battleworn Axes to Marshal Marris in Lakeshire.",en={382},l=21,n="Blackrock Menace",nx=19,ob={i={{3014}}},r=77,rl=18,sn={382},x=1650}
T[21]={d="Kill 12 Kobold Laborers, then return to Marshal McBride at Northshire Abbey.",en={197},l=5,n="Skirmish at Echo Ridge",nx=54,ob={k={{80}}},ps={15},r=77,rl=1,sn={197},x=450}
T[22]={d="Salma Saldean needs 8 Goretusk livers to make a Goretusk Liver Pie.",en={235},l=12,n="Goretusk Liver Pie",ob={i={{723}}},r=77,rl=9,sn={235},x=910}
T[23]={d="Bring Ursangous's Paw to Senani Thunderheart at Splintertree Post, Ashenvale.",en={12696},l=24,n="Ursangous's Paw",ps={6383},r=178,rl=20,si={16303},su=16303,x=1950}
T[24]={d="Bring Shadumbra's Head to Senani Thunderheart at Splintertree Post, Ashenvale.",en={12696},l=27,n="Shadumbra's Head",ps={6383},r=178,rl=20,si={16304},su=16304,x=2200}
T[25]={d="Dispatch 12 Befouled Water Elementals at Mystral Lake, due east of the Talondeep Path and southwest of Splintertree Post.",en={12737},l=25,n="Stonetalon Standstill",ob={e={"Scout the gazebo on Mystral Lake that overlooks the nearby Alliance outpost.",{{1440,48.9,69.6}}},k={{3917}}},r=178,rl=23,sf=2,sn={12737},x=2000}
T[26]={c=1024,d="Speak with Dendrite Starblaze in the village of Nighthaven, Moonglade.",en={11802},l=16,n="A Lesson to Learn",nx=29,r=8,rl=16,sn={4217},x=115}
T[27]={c=1024,d="Speak with Dendrite Starblaze in the village of Nighthaven, Moonglade.",en={11802},l=16,n="A Lesson to Learn",nx=28,r=32,rl=16,sn={3033},x=115}
T[28]={c=1024,d="Find a Shrine Bauble in Lake Elune'ara, and take it to the Shrine of Remulos in northwestern Moonglade. Once there, use the Shrine Bauble.",en={11799},l=16,n="Trial of the Lake",nx=30,ob={o={{15885}}},ps={27},r=32,rl=16,rs={15877},sf=2,sn={11802},x=880}
T[29]={c=1024,d="Find a Shrine Bauble in Lake Elune'ara, and take it to the Shrine of Remulos in northwestern Moonglade. Once there, use the Shrine Bauble.",en={11799},l=16,n="Trial of the Lake",nx=272,ob={o={{15885}}},ps={26},r=8,rl=16,rs={15877},sf=2,sn={11802},x=880}
T[30]={c=1024,d="Find the Half Pendant of Aquatic Agility and the Half Pendant of Aquatic Endurance. Speak with the residents of Moonglade to learn clues as to where these items may be located.",en={11802},l=16,n="Trial of the Sea Lion",nx=31,ob={i={{15885}}},ps={28},r=32,rl=16,rs={15883,15882},sn={11799},x=880}
T[31]={c=1024,d="Return to Thunder Bluff and show Turak Runetotem the Pendant of the Sea Lion.",en={3033},l=16,n="Aquatic Form",ps={30},r=32,rl=16,sn={11802},su=15885,x=1150}
T[32]={d="Take the report to Zilzibin Drumlore in Orgrimmar.",en={7010},l=48,n="Rise of the Silithid",ps={113},r=178,rl=39,sn={7724},su=8594,x=5450}
T[33]={d="Bring 8 pieces of Tough Wolf Meat to Eagan Peltskinner outside Northshire Abbey.",en={196},l=2,n="Wolves Across the Border",ob={i={{750}}},r=77,rl=1,sn={196},x=170}
T[34]={d="Martie Jainrose of Lakeshire wants you to kill Bellygrub. Bring her his tusk as proof.",en={342},l=24,n="An Unwelcome Guest",ob={i={{3631}}},r=77,rl=18,sn={342},x=1950}
T[35]={d="Marshal Dughan wants you to speak with Guard Thomas.",en={261},l=10,n="Further Concerns",nx=37,ps={40},r=77,rl=7,sn={240},x=420}
T[36]={d="Verna Furlbrow wants you to deliver her recipe for Westfall Stew to Salma Saldean.",en={235},l=10,n="Westfall Stew",nx=38,r=77,rl=9,sn={238},su=2832,x=420}
T[37]={d="Guard Thomas wants you to travel north up the river and search for the two lost guards, Rolf and Malakai.",eo={55},l=10,n="Find the Lost Guards",nx=45,ps={35},r=77,rl=7,sn={261},x=210}
T[38]={d="Salma Saldean wants 3 Stringy Vulture Meat, 3 Goretusk Snouts, 3 Murloc Eyes, 3 Okra.",en={235},l=13,n="Westfall Stew",ob={i={{729},{730},{731},{732}}},ps={36},r=77,rl=9,sn={235},x=910}
T[39]={d="Report to Marshal Dughan in Goldshire.",en={240},l=10,n="Deliver Thomas' Report",nx=59,ps={71},r=77,rl=7,sn={261},x=1050}
T[40]={d="Remy \"Two Times\" wants you to speak with Marshal Dughan in Goldshire.",en={240},l=10,n="A Fishy Peril",nx=35,r=77,rl=7,sn={241},x=85}
T[45]={d="Search the murloc village for Rolf, or signs of his death.",eo={56},l=10,n="Discover Rolf's Fate",nx=71,ps={37},r=77,rl=7,so={55},x=420}
T[46]={d="Bring 8 Torn Murloc Fins to Guard Thomas at the east Elwynn bridge.",en={261},l=10,n="Bounty on Murlocs",ob={i={{780}}},ps={39},r=77,rl=7,sn={261},x=840}
T[47]={d="Bring 10 Gold Dust to Remy \"Two Times\" in Goldshire. Gold Dust is gathered from Kobolds in Elwynn Forest.",en={241},l=7,n="Gold Dust Exchange",ob={i={{773}}},r=77,rl=4,sn={241},x=630}
T[48]={d="Bring Holy Spring Water to Grimbooze Thunderbrew.",en={239},l=44,n="Sweet Amber",nx=49,ob={i={{737}}},r=77,rl=40,sn={239},x=3750}
T[49]={d="Grimbooze Thunderbrew wants a Sack of Barley, a Sack of Rye and a Sack of Corn.",en={239},l=44,n="Sweet Amber",nx=50,ob={i={{738},{739},{740}}},ps={48},r=77,rl=40,sn={239},x=4650}
T[50]={d="Grimbooze Thunderbrew wants Truesilver.",en={239},l=44,n="Sweet Amber",nx=51,ob={i={{6037}}},ps={49},r=77,rl=40,sn={239},x=4650}
T[51]={d="Bring a Sycamore Branch to Grimbooze Thunderbrew.",en={239},l=44,n="Sweet Amber",nx=53,ob={i={{742}}},ps={50},r=77,rl=40,sn={239},x=4650}
T[52]={d="Kill 8 Prowlers and 5 Young Forest Bears, and then return to Guard Thomas at the east Elwynn bridge.",en={261},l=10,n="Protect the Frontier",ob={k={{118},{822}}},r=77,rl=7,sn={261},x=630}
T[53]={d="Bring Grimbooze Thunderbrew a bundle of Charred Oak.",en={239},l=44,n="Sweet Amber",ob={i={{743}}},ps={51},r=77,rl=40,sn={239},x=5600}
T[54]={d="Take Marshal McBride's Documents to Marshal Dughan in Goldshire.",en={240},l=5,n="Report to Goldshire",ps={21},r=77,rl=1,sn={197},su=745,x=225}
T[55]={d="Use Morbent's Bane on Morbent Fel, kill Morbent Fel, then return Morbent's Bane to Sven at his camp.",en={311},l=32,n="Morbent Fel",ob={k={{1200}}},ps={325},r=77,rl=20,sn={311},su=7297,tg=1,x=3850}
T[56]={d="Commander Althea Ebonlocke of Darkshire wants you to kill 8 Skeletal Warriors and 6 Skeletal Mages.",en={264},l=24,n="The Night Watch",nx=57,ob={k={{48},{203}}},r=77,rl=18,sn={264},x=1450}
T[57]={d="Commander Althea Ebonlocke of Darkshire wants you to kill 15 Skeletal Fiends and 15 Skeletal Horrors.",en={264},l=26,n="The Night Watch",nx=58,ob={k={{531},{202}}},ps={56},r=77,rl=18,sn={264},x=2100}
T[58]={d="Commander Althea Ebonlocke of Darkshire wants you to kill 20 Plague Spreaders in the eastern Raven Hill mausoleum.",en={264},l=30,n="The Night Watch",ob={k={{604}}},ps={57},r=77,rl=18,sn={264},x=2450}
T[59]={d="Give Sara Timberlain the Stormwind Armor Marker.",en={278},l=10,n="Cloth and Leather Armor",ps={39},r=77,rl=7,sn={240},su=748,x=210}
T[60]={d="Bring 8 Large Candles to William Pestle in Goldshire.",en={253},l=7,n="Kobold Candles",nx=61,ob={i={{772}}},r=77,rl=3,sn={253},x=475}
T[61]={d="Bring William's Shipment to Morgan Pestle in the Stormwind Trade District.",en={279},l=7,n="Shipment to Stormwind",ps={60},r=77,rl=3,sn={253},su=957,x=790}
T[62]={d="Explore the Fargodeep Mine, then return to Marshal Dughan in Goldshire.",en={240},l=7,n="The Fargodeep Mine",nx=76,ob={e={"Scout through the Fargodeep Mine",{{1429,40.6,82.3}}}},r=77,rl=4,sf=2,sn={240},x=475}
T[63]={c=64,d="Defeat the Corrupt Manifestation of Water and place the Corrupted Manifestation's Bracers along with the Remaining Drops of Purest Water on the Brazier of Everfount in Silverpine Forest.",eo={113791},l=23,n="Call of Water",nx=100,ob={i={{7812}}},ps={220},r=178,rl=20,rs={6637},sn={5901},su=7811,x=1400}
T[64]={d="Farmer Furlbrow wants you to retrieve his pocket watch from the wardrobe in his farmhouse at the pumpkin farm to the West.",en={237},l=12,n="The Forgotten Heirloom",ob={i={{841}}},r=77,rl=9,sn={237},x=910}
T[65]={d="Gryan Stoutmantle wants you to talk to Wiley in Lakeshire.",en={266},l=18,n="The Defias Brotherhood",nx=132,r=77,rl=14,sn={234},x=1350}
T[66]={d="Seek out the Clerk Daltry in the Darkshire Town Hall.",en={267},l=28,n="The Legend of Stalvan",nx=67,r=77,rl=22,sn={265},x=230}
T[67]={d="Travel to the Moonbrook Schoolhouse and bring back any updated information about Stalvan to Clerk Daltry.",eo={3643},l=28,n="The Legend of Stalvan",nx=68,ps={66},r=77,rl=22,sn={267},x=1150}
T[68]={d="Take the Dusty Unsent Letter to Clerk Daltry.",en={267},l=28,n="The Legend of Stalvan",nx=69,ps={67},r=77,rl=22,so={3643},su=889,x=1700}
T[69]={d="Go to The Lion's Pride Inn to see if anyone there has heard of the name Stalvan.",en={295},l=28,n="The Legend of Stalvan",nx=70,ps={68},r=77,rl=22,sn={267},x=570}
T[70]={d="Retrieve Stalvan's Undelivered Letter from the chest and deliver it to the Canal District in Stormwind.",en={297},l=28,n="The Legend of Stalvan",nx=72,ob={i={{910}}},ps={69},r=77,rl=22,sn={295},x=1700}
T[71]={d="Deliver Rolf and Malakai's Medallions to Guard Thomas at the eastern Elwynn bridge.",en={261},l=10,n="Report to Thomas",nx=39,ps={45},r=77,rl=7,so={56},su=735,x=210}
T[72]={d="Search through the packed up possessions for a clue.",eo={1561},l=28,n="The Legend of Stalvan",nx=74,ps={70},r=77,rl=22,sn={297},x=230}
T[74]={d="The Torn Journal page you discovered provides your next clue.",en={294},l=28,n="The Legend of Stalvan",nx=75,ps={72},r=77,rl=22,so={1561},su=916,x=1150}
T[75]={d="Marshal Haggard wants you to check the chest upstairs for the Faded Journal Page.",en={294},l=28,n="The Legend of Stalvan",nx=78,ob={i={{921}}},ps={74},r=77,rl=22,sn={294},x=1150}
T[76]={d="Explore the Jasperlode Mine, then report back to Marshal Dughan in Goldshire.",en={240},l=10,n="The Jasperlode Mine",nx=239,ob={e={"Scout through the Jasperlode Mine",{{1429,60.2,49.2}}}},ps={62},r=77,rl=4,sf=2,sn={240},x=840}
T[77]={d="Recover 10 bottles of Hinterlands Honey Ripple from the crates located around the abandoned Horde base in Skulk Rock.",en={7801},l=48,n="A Sticky Situation",nx=81,ob={i={{8684}}},ps={650},r=178,rl=42,sn={7801},x=4400}
T[78]={d="Take the Faded Journal Page to Tavernkeep Smitts.",en={273},l=28,n="The Legend of Stalvan",nx=79,ps={75},r=77,rl=22,sn={294},su=921,x=570}
T[79]={d="Take the muddy page to Commander Ebonlocke.",en={264},l=28,n="The Legend of Stalvan",nx=80,ps={78},r=77,rl=22,sn={273},su=938,x=230}
T[80]={d="Show Clerk Daltry the Bloodstained Journal Page.",en={267},l=28,n="The Legend of Stalvan",nx=97,ps={79},r=77,rl=22,sn={264},su=939,x=230}
T[81]={d="Deliver the barrel to Dran Droffers in Orgrimmar.",en={6986},l=48,n="Ripple Delivery",ps={77},r=178,rl=42,sn={7801},su=8685,x=4400}
T[82]={d="Bring five Centipaar insect parts from the Noxious Lair to Alchemist Pestlezugg in Gadgetzan.",en={5594},l=47,n="Noxious Lair Investigation",nx=10,ob={i={{8587}}},ps={992},r=0,rl=39,sn={7724},x=3150}
T[83]={d="Bring 6 Red Linen Bandanas to Sara Timberlain at the Eastvale Logging Camp.",en={278},l=9,n="Red Linen Goods",ob={i={{1019}}},r=77,rl=4,sn={278},x=780}
T[84]={d="Bring the Pork Belly Pie to Billy Maclure at the Maclure Vineyards.",en={247},l=6,n="Back to Billy",nx=87,ps={86},r=77,rl=5,sn={246},su=962,x=135}
T[85]={d="Speak with Billy Maclure.",en={247},l=6,n="Lost Necklace",nx=86,r=77,rl=5,sn={246},x=135}
T[86]={d="Bring 4 Chunks of Boar Meat to Auntie Bernice Stonefield at the Stonefield's Farm.",en={246},l=6,n="Pie for Billy",nx=84,ob={i={{769}}},ps={85},r=77,rl=5,sn={247},x=405}
T[87]={d="Bring Bernice's Necklace to \"Auntie\" Bernice Stonefield at the Stonefield Farm.",en={246},l=8,n="Goldtooth",ob={i={{981}}},ps={84},r=77,rl=5,sn={247},x=880}
T[88]={d="Kill Princess, grab her collar, then bring it back to Ma Stonefield at the Stonefield Farm.",en={244},l=9,n="Princess Must Die!",ob={i={{1006}}},r=77,rl=6,sn={244},x=780}
T[89]={d="Bring 5 Iron Pikes and 5 Iron Rivets to Foreman Oslow in Lakeshire.",en={341},l=20,n="The Everstill Bridge",ob={i={{2856},{1013}}},ps={125},r=77,rl=15,sn={341},x=1550}
T[90]={d="Gather 10 Lean Wolf Flanks and Stormwind Seasoning Herbs and return to Chef Grual in Darkshire.",en={272},l=25,n="Seasoned Wolf Kabobs",ob={i={{1015},{2665}}},r=77,rl=18,sk={185,50},sn={272},x=2000}
T[91]={d="Bring 10 Shadowhide Pendants to Bailiff Conacher in the Lakeshire Town Hall.",en={900},l=23,n="Solomon's Law",ob={i={{1075}}},r=77,rl=17,sn={900},x=1850}
T[92]={d="Chef Breanna of Lakeshire wants five pieces of Tough Condor Meat, five Great Goretusk Snouts and five helpings of Crisp Spider Meat.",en={343},l=18,n="Redridge Goulash",ob={i={{2296},{1080},{1081}}},r=77,rl=15,sn={343},x=1350}
T[93]={d="Gather 6 Gooey Spider Legs and bring them to Chef Grual in Darkshire.",en={272},l=20,n="Dusky Crab Cakes",nx=240,ob={i={{2251}}},ps={5},r=77,rl=17,sn={272},x=780}
T[94]={d="Take the Glyph of Azora to the Lion Statue near the Tower of Ilgalar in Redridge.",eo={31},l=21,n="A Watchful Eye",nx=248,r=77,rl=20,sn={313},su=1083,x=1250}
T[95]={d="Go to Sven's Farm and find what was buried behind the old stump.",eo={59},l=25,n="Sven's Revenge",nx=230,r=77,rl=20,sn={311},x=1000}
T[96]={c=64,d="Bring the Shard of Water to Islen Waterseer in the Barrens.",en={5901},l=23,n="Call of Water",ps={100},r=178,rl=20,sn={5895},su=7813,x=2750}
T[97]={d="Report the news to Commander Ebonlocke.",en={264},l=28,n="The Legend of Stalvan",nx=98,ps={80},r=77,rl=22,sn={267},x=230}
T[98]={d="Kill Stalvan Mistmantle and show Madame Eva his family ring.",en={265},l=35,n="The Legend of Stalvan",ob={i={{3629}}},ps={97},r=77,rl=22,sn={264},x=4100}
T[99]={d="Bring 6 Pyrewood Shackles to Dalar Dawnweaver at the Sepulcher.",en={1938},l=15,n="Arugal's Folly",ob={i={{3218}}},ps={424},r=178,rl=9,sn={1938},tg=1,x=1350}
T[100]={c=64,d="Speak to the Minor Manifestation of Water in Silverpine Forest.",en={5895},l=23,n="Call of Water",nx=96,ps={63},r=178,rl=20,so={113791},x=1400}
T[101]={d="Bring 10 Ghoul Fangs, 10 Skeleton Fingers and 5 Vials of Spider Venom to Madame Eva in Darkshire.",en={265},l=25,n="The Totem of Infliction",ob={i={{1129},{1130},{2378}}},r=77,rl=18,sn={265},x=2550}
T[102]={d="Bring 8 Gnoll Paws to Captain Danuvin on Sentinel Hill.",en={821},l=14,n="Patrolling Westfall",ob={i={{725}}},r=77,rl=8,sn={821},x=980}
T[103]={d="Bring 5 Flasks of Oil to Captain Grayson at the Westfall Lighthouse.",en={392},l=16,n="Keeper of the Flame",ob={i={{814}}},r=0,rl=10,sn={392},x=1150}
T[104]={d="Bring a scale of Old Murk-Eye to Captain Grayson at the Westfall Lighthouse.",en={392},l=20,n="The Coastal Menace",ob={i={{3636}}},r=0,rl=15,sn={392},x=1550}
T[105]={d="Bring Araj's Phylactery Shard to High Executor Derrington at the Bulwark, Western Plaguelands.",en={10837},l=60,n="Alas, Andorhal",ob={i={{17114}}},ps={5098},r=178,rl=50,sn={10837},tg=1,x=8300}
T[106]={d="Give Maybell's Love Letter to Tommy Joe Stonefield.",en={252},l=6,n="Young Lovers",nx=111,r=77,rl=5,sn={251},su=1208,x=135}
T[107]={d="Take Gramma Stonefield's Note to William Pestle.",en={253},l=6,n="Note to William",nx=112,ps={111},r=77,rl=5,sn={248},su=1252,x=135}
T[109]={d="Talk to Gryan Stoutmantle. He usually can be found in the stone tower on Sentinel Hill, just off the road, in the middle of Westfall.",en={234},l=10,n="Report to Gryan Stoutmantle",r=77,rl=9,sn={233,237,240,261,294,963},x=630}
T[110]={d="Check in Gadgetzan for Alchemist Pestlezugg and his analysis of the insect parts.",en={5594},l=48,n="Insect Part Analysis",nx=113,ps={10},r=0,rl=39,sn={7724},x=440}
T[111]={d="Speak with Gramma Stonefield.",en={248},l=6,n="Speak with Gramma",nx=107,ps={106},r=77,rl=5,sn={252},x=135}
T[112]={d="Bring 4 Crystal Kelp Fronds to William Pestle in Goldshire.",en={253},l=7,n="Collecting Kelp",nx=114,ob={i={{1256}}},ps={107},r=77,rl=5,sn={253},x=315}
T[113]={d="Deliver the report to Senior Surveyor Fizzledowser in Gadgetzan. Be sure he gives you a copy of the report, as Alchemist Pestlezugg has requested.",en={7724},l=48,n="Insect Part Analysis",ps={110},r=0,rl=39,sn={5594},su=8594,x=440}
T[114]={d="Take the Invisibility Liquor to Maybell Maclure.",en={251},l=7,n="The Escape",ps={112},r=77,rl=5,sn={253},su=1257,x=790}
T[115]={d="Bring 3 Midnight Orbs to Marshal Marris in Lakeshire.",en={382},l=23,n="Shadow Magic",ob={i={{1261}}},ps={20},r=77,rl=18,sn={382},tg=1,x=2300}
T[116]={d="Barkeep Daniels of Lakeshire needs a keg of Thunderbrew Lager, a cask of Merlot, a bottle of Moonshine and a skin of Sweet Rum.",en={346},l=15,n="Dry Times",ob={i={{1262},{1941},{1942},{1939}}},r=77,rl=12,sn={346},x=1050}
T[117]={d="Bring Grimbooze Thunderbrew 5 hops to complete his special brew.",en={239},l=15,n="Thunderbrew",ob={i={{1274}}},r=77,rl=10,sf=1,sn={239}}
T[118]={d="Take Verner's Note to Smith Argus in Goldshire.",en={514},l=18,n="The Price of Shoes",nx=119,r=77,rl=14,sn={415},su=1283,x=340}
T[119]={d="Return to Verner Osgood in Redridge. Give him the Crate of Horseshoes.",en={415},l=18,n="Return to Verner",ps={118},r=77,rl=13,sn={514},su=1284,x=680}
T[120]={d="Magistrate Solomon has given you a report which must be delivered to General Marcus Jonathan in Stormwind. The judge wants you to return to him as soon as the delivery has been made.",en={466},l=14,n="Messenger to Stormwind",nx=121,r=77,rl=14,sn={344},su=1293,x=490}
T[121]={d="Take General Marcus Jonathan's letter of response to Magistrate Solomon in Lakeshire.",en={344},l=14,n="Messenger to Stormwind",nx=143,ps={120},r=77,rl=14,sn={466},su=1294,x=245}
T[122]={d="Gather 6 Underbelly Whelp Scales from Black Dragon Whelps, and bring them to Verner Osgood in Redridge.",en={415},l=18,n="Underbelly Scales",ob={i={{1221}}},ps={119},r=77,rl=14,sn={415},x=1700}
T[123]={d="Go to Marshal Dughan in Goldshire and give him The Collector's Schedule.",en={240},l=10,n="The Collector",nx=147,r=77,rl=7,si={1307},su=2223,x=210}
T[124]={d="Kill 10 Redridge Brutes and 8 Redridge Mystics, then return to Verner Osgood.",en={415},l=20,n="A Baying of Gnolls",nx=126,ob={k={{426},{430}}},ps={119},r=77,rl=15,sn={415},x=1150}
T[125]={d="Foreman Oslow of Lakeshire wants you to retrieve his toolbox from the bottom of Lake Everstill.",en={341},l=16,n="The Lost Tools",nx=89,ob={i={{1309}}},r=77,rl=15,sn={341},x=880}
T[126]={d="Bring Yowler's Paw to Verner Osgood in Lakeshire.",en={415},l=25,n="Howling in the Hills",ob={i={{3614}}},ps={124},r=77,rl=15,sn={415},x=2000}
T[127]={d="Bring 10 Spotted Sunfish to Dockmaster Baren in Lakeshire.",en={381},l=21,n="Selling Fish",ob={i={{1467}}},r=77,rl=16,sn={381},x=1250}
T[128]={d="Kill 15 Blackrock Champions and Guard Howe in Lakeshire will reward you.",en={903},l=25,n="Blackrock Bounty",ob={k={{435}}},r=77,rl=20,sn={903},x=2000}
T[129]={d="Bring Parker's lunch to Guard Parker. He patrols the road leading to Darkshire.",en={464},l=15,n="A Free Lunch",nx=130,r=77,rl=12,sn={379},su=5534,x=540}
T[130]={d="Speak with the Redridge Herbalist, Martie Jainrose.",en={342},l=15,n="Visit the Herbalist",nx=131,ps={129},r=77,rl=12,sn={464},x=270}
T[131]={d="Give Darcy the Daffodil Bouquet.",en={379},l=15,n="Delivering Daffodils",ps={130},r=77,rl=12,sn={342},su=1325,x=270}
T[132]={d="Take Wiley's Note to Gryan Stoutmantle in Westfall.",en={234},l=18,n="The Defias Brotherhood",nx=135,ps={65},r=77,rl=14,sn={266},su=1327,x=680}
T[133]={d="Gather 7 Ghoul Ribs and bring them to Abercrombie at his shack.",en={289},l=27,n="Ghoulish Effigy",nx=134,ob={i={{884}}},ps={159},r=77,rl=20,sn={289},x=1650}
T[134]={d="Return Abercrombie's Crate to Abercrombie.",en={289},l=30,n="Ogre Thieves",nx=160,ob={i={{1349}}},ps={133},r=77,rl=20,sn={289},x=1200}
T[135]={d="Take Wiley's Note to Mathias Shaw in Stormwind.",en={332},l=18,n="The Defias Brotherhood",nx=141,ps={132},r=77,rl=14,sn={234},su=1327,x=680}
T[136]={d="Find Captain Sanders' footlocker and search it for the next clue.",eo={35},l=16,n="Captain Sander's Hidden Treasure",nx=138,r=0,rl=10,si={1357},x=580}
T[138]={d="Find the old barrel near the ruined chimney and search it for your next clue.",eo={36},l=16,n="Captain Sander's Hidden Treasure",nx=139,ps={136},r=0,rl=10,so={35},su=1358,x=580}
T[139]={d="Search the empty jug next to the windmill for the next clue.",eo={34},l=16,n="Captain Sander's Hidden Treasure",nx=140,ps={138},r=0,rl=10,so={36},su=1361,x=580}
T[140]={d="Locate Captain Sanders' chest and open it for your reward.",eo={33},l=16,n="Captain Sander's Hidden Treasure",ps={139},r=0,rl=10,so={34},su=1362,x=1150}
T[141]={d="Take Shaw's report to Gryan Stoutmantle in Westfall.",en={234},l=18,n="The Defias Brotherhood",nx=142,ps={135},r=77,rl=14,sn={332},su=1353,x=340}
T[142]={d="Track down the Defias Messenger in Westfall and bring his message to Stoutmantle.",en={234},l=18,n="The Defias Brotherhood",nx=155,ob={i={{1381}}},ps={141},r=77,rl=14,sn={234},x=1350}
T[143]={d="Magistrate Solomon wants you to take his written plea to Gryan Stoutmantle in Westfall.",en={234},l=14,n="Messenger to Westfall",nx=144,ps={121},r=77,rl=14,sn={344},su=1407,x=490}
T[144]={d="Return to Magistrate Solomon with Gryan Stoutmantle's response.",en={344},l=14,n="Messenger to Westfall",nx=145,ps={143},r=77,rl=14,sn={234},su=1408,x=245}
T[145]={d="Magistrate Solomon wants you to take a letter to Lord Ebonlocke in Darkshire.",en={263},l=18,n="Messenger to Darkshire",nx=146,ps={144},r=77,rl=18,sn={344},su=1409,x=1000}
T[146]={d="Return to Magistrate Solomon with Lord Ebonlocke's letter of response.",en={344},l=18,n="Messenger to Darkshire",ps={145},r=77,rl=18,sn={263},su=1410,x=340}
T[147]={d="Find and kill \"the Collector\" then return to Marshal Dughan with The Collector's Ring.",en={240},l=10,n="Manhunt",ob={i={{2239}}},ps={123},r=77,rl=7,sn={240},x=840}
T[148]={d="Speak with Madame Eva.",en={265},l=24,n="Supplies from Darkshire",nx=149,r=77,rl=20,sn={289},x=485}
T[149]={d="Bring the Spectral Comb to Blind Mary.",en={302},l=24,n="Ghost Hair Thread",nx=154,ps={148},r=77,rl=20,sn={265},su=1453,x=485}
T[150]={d="Bring 8 Murloc Fins to Dockmaster Baren in Lakeshire.",en={381},l=20,n="Murloc Poachers",ob={i={{1468}}},r=77,rl=20,sn={381},x=1550}
T[151]={d="Verna Furlbrow in Westfall wants you to bring her 8 Handfuls of Oats.",en={238},l=14,n="Poor Old Blanchy",ob={i={{1528}}},r=77,rl=9,sn={238},x=1250}
T[152]={d="Kill 7 Tidehunters, 7 Warriors, 7 Oracles and 7 Coastrunners and return to Captain Grayson at the Westfall Lighthouse.",en={392},l=19,n="The Coast Isn't Clear",ob={k={{126},{171},{127},{517}}},r=0,rl=10,sn={392},x=1450}
T[153]={d="Bring 15 Red Leather Bandanas to Scout Galiaan at Sentinel Hill.",en={878},l=15,n="Red Leather Bandanas",ob={i={{829}}},r=77,rl=10,sn={878},x=1050}
T[154]={d="Return the Ghost Hair Comb to Madame Eva in Darkshire.",en={265},l=24,n="Return the Comb",nx=157,ps={149},r=77,rl=20,sn={302},su=1518,x=195}
T[155]={d="Escort the Defias Traitor to the secret hideout of the Defias Brotherhood. Once the Defias Traitor shows you where VanCleef and his men are hiding out, return to Gryan Stoutmantle with the information.",en={234},es=1,l=18,n="The Defias Brotherhood",nx=166,ob={e={"Escort The Defias Traitor to discover where VanCleef is hiding",{{1436,42.6,71.5}}}},ps={142},r=77,rl=14,sf=2,sn={467},x=1700}
T[156]={d="Gather 8 Rot Blossoms and bring them to Tavernkeep Smitts in Darkshire.",en={273},l=24,n="Gather Rot Blossoms",nx=159,ob={i={{1598}}},ps={158},r=77,rl=20,sn={273},x=970}
T[157]={d="Bring the Ghost Hair Thread to Abercrombie, in his shack north of the Raven Hill Cemetery.",en={289},l=24,n="Deliver the Thread",nx=158,ps={154},r=77,rl=20,sn={265},su=1596,x=1450}
T[158]={d="Speak with Tavernkeep Smitts.",en={273},l=24,n="Zombie Juice",nx=156,ps={157},r=77,rl=20,sn={289},x=485}
T[159]={d="Bring the Zombie Juice to Abercrombie at his shack.",en={289},l=24,n="Juice Delivery",nx=133,ps={156},r=77,rl=20,sn={273},su=1451,x=970}
T[160]={d="Bring Abercrombie's Letter to Ello Ebonlocke, Mayor of Darkshire.",en={263},l=30,n="Note to the Mayor",nx=251,ps={134},r=77,rl=20,sn={289},su=1637,x=610}
T[161]={d="Chief Engineer Hinderweir wants you to take the strange smelling powder to Ashlan Stonesmirk, the explosives expert in Dun Modr.",en={1073},l=18,n="A Dark Threat Looms",nx=274,ps={199},r=77,rl=16,sn={1093},su=2563,x=1350}
T[162]={d="Take the Insect Analysis Report to Gracina Spiritmight in Darnassus.",en={7740},l=49,n="Rise of the Silithid",nx=4493,ps={113},r=77,rl=39,sn={7724},su=8594,x=5700}
T[163]={d="Find out what is haunting Raven Hill.",en={288},l=20,n="Raven Hill",nx=5,r=77,rl=17,sn={633},x=390}
T[164]={d="Deliver the supplies to Sven.",en={311},l=23,n="Deliveries to Sven",nx=95,r=77,rl=17,sn={633},su=1922,x=920}
T[165]={d="Check on the old man in the shack near Raven Hill cemetery.",en={289},l=25,n="The Hermit",nx=148,r=77,rl=17,sn={633},x=1000}
T[166]={d="Kill Edwin VanCleef and bring his head to Gryan Stoutmantle.",en={234},l=22,n="The Defias Brotherhood",ob={i={{3637}}},ps={155},r=77,rl=14,sn={234},tg=81,x=2600,z=1581}
T[167]={d="Bring Foreman Thistlenettle's Explorers' League Badge to Wilder Thistlenettle in Stormwind.",en={656},l=20,n="Oh Brother. . .",ob={i={{1875}}},r=77,rl=15,sn={656},x=1550,z=1581}
T[168]={d="Retrieve 4 Miners' Union Cards and return them to Wilder Thistlenettle in Stormwind.",en={656},l=18,n="Collecting Memories",ob={i={{1894}}},r=77,rl=14,sn={656},x=1350,z=1581}
T[169]={d="Kill Gath'Ilzogg and bring his head to Magistrate Solomon in Lakeshire for the reward.",en={344},l=26,n="Wanted: Gath'Ilzogg",ob={i={{3633}}},r=77,rl=15,so={60},tg=1,x=2650}
T[170]={d="Balir Frosthammer wants you to kill 6 Rockjaw Troggs and 6 Burly Rockjaw Troggs.",en={713},l=2,n="A New Threat",ob={k={{707},{724}}},ps={179},r=77,rl=1,sn={713},x=170}
T[173]={d="Kill 6 Nightbane Shadow Weaver worgen for Calor in Darkshire.",en={663},l=28,n="Worgen in the Woods",nx=221,ob={k={{533}}},r=77,rl=23,sn={663},x=1150}
T[174]={d="Viktori Prism'Antras of Darkshire wants you to bring him a bronze tube.",en={276},l=25,n="Look To The Stars",nx=175,ob={i={{4371}}},r=77,rl=20,sn={276},x=2000}
T[175]={d="Locate Mary and persuade her to give up a reflective surface for Viktori's project.",en={302},l=25,n="Look To The Stars",nx=177,ps={174},r=77,rl=20,sn={276},x=1000}
T[176]={d="Slay the gnoll Hogger and bring his Huge Gnoll Claw to Marshal Dughan.",en={240},l=11,n="Wanted:  \"Hogger\"",ob={i={{1931}}},r=77,rl=5,so={68,156561},tg=1,x=880}
T[177]={d="Retrieve Blind Mary's Looking Glass from the Insane Ghoul and give it to Viktori in Darkshire.",en={276},l=25,n="Look To The Stars",nx=181,ob={i={{1946}}},ps={175},r=77,rl=20,sn={302},x=1500}
T[178]={d="Bring the Faded Shadowhide Pendant to Theocritus the Mage.",en={313},l=23,n="Theocritus' Retrieval",r=77,rl=15,si={1962},su=1956,x=1400}
T[179]={d="Sten Stoutarm would like 8 pieces of Tough Wolf Meat.",en={658},l=1,n="Dwarven Outfitters",ob={i={{750}}},r=77,rl=1,sn={658},x=80}
T[180]={d="Kill Lieutenant Fangore and return to Magistrate Solomon in Lakeshire with his paw.",en={344},l=26,n="Wanted: Lieutenant Fangore",ob={i={{3632}}},r=77,rl=15,so={47},x=2650}
T[181]={d="Locate Zzarc'Vul in the southern ogre mound in Duskwood and return his monocle to Viktori in Darkshire.",en={276},l=30,n="Look To The Stars",ob={i={{1968}}},ps={177},r=77,rl=20,sn={276},x=2450}
T[182]={d="Grelin Whitebeard would like you to kill 14 Frostmane Troll Whelps.",en={786},l=4,n="The Troll Cave",nx=218,ob={k={{706}}},r=77,rl=1,sn={786},x=355}
T[183]={d="Talin Keeneye would like you to kill 12 Small Crag Boars.",en={714},l=3,n="The Boar Hunter",ob={k={{708}}},r=77,rl=1,sn={714},x=250}
T[184]={d="Bring Furlbrow's Deed to Farmer Furlbrow.",en={237},l=9,n="Furlbrow's Deed",r=77,rl=8,si={1972},su=1971,x=590}
T[185]={d="Ajeck Rouack of Nesingwary's Expedition wants you to kill 10 Young Stranglethorn Tigers.",en={717},l=31,n="Tiger Mastery",nx=186,ob={k={{681}}},ps={583},r=0,rl=28,sn={717},x=1250}
T[186]={d="Ajeck Rouack of Nesingwary's Expedition wants you to kill 10 Stranglethorn Tigers.",en={717},l=33,n="Tiger Mastery",nx=187,ob={k={{682}}},ps={185},r=0,rl=28,sn={717},x=1300}
T[187]={d="Ajeck Rouack of Nesingwary's Expedition wants you to kill 10 Elder Stranglethorn Tigers.",en={717},l=35,n="Tiger Mastery",nx=188,ob={k={{1085}}},ps={186},r=0,rl=28,sn={717},x=2050}
T[188]={d="Ajeck Rouack of Nesingwary's Expedition wants you to kill Sin'Dall and return with her paw.",en={717},l=37,n="Tiger Mastery",ob={i={{3879}}},ps={187},r=0,rl=28,sn={717},x=2850}
T[189]={d="Acquire 15 Bloodscalp Ears and return them to Kebok in Booty Bay.",en={737},l=35,n="Bloodscalp Ears",nx=209,ob={i={{1519}}},r=0,rl=30,sn={737},x=2050}
T[190]={d="Sir S. J. Erlgadin of Nesingwary's Expedition wants you to kill 10 Young Panthers.",en={718},l=31,n="Panther Mastery",nx=191,ob={k={{683}}},ps={583},r=0,rl=28,sn={718},x=1250}
T[191]={d="Sir S. J. Erlgadin of Nesingwary's Expedition wants you to kill 10 Panthers.",en={718},l=33,n="Panther Mastery",nx=192,ob={k={{736}}},ps={190},r=0,rl=28,sn={718},x=1300}
T[192]={d="Sir S. J. Erlgadin of Nesingwary's Expedition wants you to kill 10 Shadowmaw Panthers.",en={718},l=38,n="Panther Mastery",nx=193,ob={k={{684}}},ps={191},r=0,rl=28,sn={718},x=2150}
T[193]={d="Sir S. J. Erlgadin of Nesingwary's Expedition wants you to bring him the Fang of Bhag'thera.",en={718},l=40,n="Panther Mastery",ob={i={{3876}}},ps={192},r=0,rl=28,sn={718},tg=1,x=3150}
T[194]={d="Hemet Nesingwary wants you to kill 10 Stranglethorn Raptors.",en={715},l=34,n="Raptor Mastery",nx=195,ob={k={{685}}},ps={583},r=0,rl=28,sn={715},x=1350}
T[195]={d="Hemet Nesingwary wants you to kill 10 Lashtail Raptors.",en={715},l=36,n="Raptor Mastery",nx=196,ob={k={{686}}},ps={194},r=0,rl=28,sn={715},x=1400}
T[196]={d="Hemet Nesingwary wants you to kill 10 Jungle Stalkers.",en={715},l=41,n="Raptor Mastery",nx=197,ob={k={{687}}},ps={195},r=0,rl=28,sn={715},x=2450}
T[197]={d="Hemet Nesingwary wants you to kill Tethis, an elusive, dangerous raptor in Stranglethorn.",en={715},l=43,n="Raptor Mastery",ob={i={{3877}}},ps={196},r=0,rl=28,sn={715},tg=1,x=3600}
T[198]={d="Deliver the Miscellaneous Goblin Supplies to Private Thorsen.",en={738},l=32,n="Supplies to Private Thorsen",r=77,rl=30,sn={773},su=2252,x=640}
T[199]={d="Return to Chief Engineer Hinderweir and show him the clue that you discovered.",en={1093},l=18,n="A Dark Threat Looms",nx=161,ps={250},r=77,rl=16,so={257},su=2563,x=1350}
T[200]={d="Find Bookie Herod's Records.",eo={287},l=35,n="Bookie Herod",nx=328,ps={215},r=77,rl=30,sn={469},x=1350}
T[201]={d="Find the hunters' camp and report its location to Krazek in Booty Bay.",en={773},l=32,n="Investigate the Camp",ob={e={"Locate the hunters' camp",{{1434,35.7,10.6}}}},r=0,rl=28,sf=2,sn={773},x=255}
T[202]={d="Kill 6 Kurzen Elite, 4 Kurzen Subchiefs, and bring Kurzen's Head to Lieutenant Doren at the Rebel Camp.",en={469},l=40,n="Colonel Kurzen",ob={i={{3615}},k={{939},{978}}},ps={574},r=77,rl=30,sn={469},tg=1,x=3150}
T[203]={d="Kill 15 Kurzen Jungle Fighters.",en={733},l=33,n="The Second Rebellion",ob={k={{937}}},r=77,rl=30,sn={733},x=1950}
T[204]={d="Bring 7 Jungle Remedies and 1 Venom Fern Extract to Sergeant Yohwa at the Rebel Camp.",en={733},l=34,n="Bad Medicine",ob={i={{2633},{2634}}},r=77,rl=30,sn={733},x=2700}
T[205]={d="Bring 4 Skullsplitter Fetishes to Brother Nimetz at the Rebel Camp.",en={739},l=40,n="Troll Witchery",ob={i={{2466}}},ps={207},r=77,rl=30,sn={739},x=3150}
T[206]={d="Bring the Mind's Eye to Brother Nimetz at the Rebel Camp.",en={739},l=46,n="Mai'Zoth",ob={i={{3616}}},pg={202,205},r=77,rl=30,sn={739},tg=1,x=5050}
T[207]={d="Find the 4 tablets and bring their legends back to Brother Nimetz.",en={739},l=38,n="Kurzen's Mystery",nx=205,ob={i={{2005},{2006},{2007},{2008}}},pg={204,203},r=77,rl=30,sn={739},x=3550}
T[208]={d="Hemet Nesingwary wants you to bring him the head of King Bangalash, the great white tiger.",en={715},l=43,n="Big Game Hunter",ob={i={{3880}}},pg={188,193,197},r=0,rl=28,sn={715},tg=1,x=5350}
T[209]={d="Acquire 18 Skullsplitter Tusks and return them to Kebok.",en={737},l=42,n="Skullsplitter Tusks",ob={i={{1524}}},ps={189},r=0,rl=37,sn={737},x=3450}
T[210]={d="Bring Krazek's Crock Pot to Krazek the goblin.",en={773},l=37,n="Krazek's Cookery",nx=627,r=77,rl=32,sn={770},su=4085,x=1400}
T[211]={d="Bring Araj's Phylactery Shard to Commander Ashlam Valorfist at Chillwind Camp, Western Plaguelands.",en={10838},l=60,n="Alas, Andorhal",ob={i={{17114}}},ps={5097},r=77,rl=50,sn={10838},tg=1,x=8300}
T[212]={d="Kill a Cold Eye Basilisk, get a Chilled Basilisk Haunch, and return it to Angus Stern in the Blue Recluse.",en={1141},l=40,n="A Meal Served Cold",ob={i={{2476}}},r=77,rl=35,sn={1141},x=4700}
T[213]={d="Retrieve 8 Tumbled Crystals and return them to Kebok in Booty Bay.",en={737},l=36,n="Hostile Takeover",ob={i={{4106}}},r=0,rl=31,sn={737},x=2800}
T[214]={d="Scout Riell at the Sentinel Hill Tower wants you to bring her 10 Red Silk Bandanas.",en={820},l=17,n="Red Silk Bandanas",ob={i={{915}}},ps={155},r=77,rl=14,sn={820},tg=81,x=1250,z=1581}
T[215]={d="Speak with Lieutenant Doren at the Rebel Camp.",en={469},l=33,n="Jungle Secrets",nx=200,r=77,rl=30,sn={738},x=1300}
T[216]={d="Take down 8 Thistlefur Avengers and 8 Thistlefur Shaman; most are located east of Zoram Strand in Thistlefur Village. Once completed, return to Karang Amakkar at Zoram'gar Outpost, Ashenvale.",en={12757},l=24,n="Between a Rock and a Thistlefur",nx=6621,ob={k={{3925},{3924}}},r=178,rl=21,sn={12757},x=1950}
T[217]={d="Kill the Trogg leader, Grawmug, and his two guards, Gnasher and Brawler then report back to Captain Rugelfuss in the southern guard tower.",en={1092},l=17,n="In Defense of the King's Lands",ob={k={{1205},{1206},{1207}}},pg={263,267},r=77,rl=10,sn={1092},x=1600}
T[218]={d="Grelin Whitebeard wants you to kill Grik'nir the Cold, and retrieve his journal.",en={786},l=5,n="The Stolen Journal",nx=282,ob={i={{2004}}},ps={182},r=77,rl=1,sn={786},x=560}
T[219]={d="Protect Corporal Keeshan on the journey back to Redridge.",en={382},l=25,n="Missing In Action",ob={e={"Escort Corporal Keeshan back to Redridge",{{1433,28.3,48.7}}}},r=77,rl=19,sf=2,sn={349},x=2550}
T[220]={c=64,d="Bring the Vial of Purest Water to Islen Waterseer in the Barrens.",en={5901},l=23,n="Call of Water",ps={1534},r=178,rl=20,sn={5899},su=7810,x=460}
T[221]={d="Kill 12 Nightbane Dark Runner worgen for Calor in Darkshire.",en={663},l=29,n="Worgen in the Woods",nx=222,ob={k={{205}}},ps={173},r=77,rl=23,sn={663},x=1750}
T[222]={d="Kill 8 Nightbane Vile Fang and 8 Nightbane Tainted One worgen for Calor in Darkshire.",en={663},l=31,n="Worgen in the Woods",nx=223,ob={k={{206},{920}}},ps={221},r=77,rl=23,sn={663},x=1900}
T[223]={d="Bring Calor's note to Jonathan Carevin.",en={661},l=31,n="Worgen in the Woods",ps={222},r=77,rl=23,sn={663},su=2113,x=3150}
T[224]={d="Mountaineer Cobbleflint of the southern guard tower wants you to kill 10 Stonesplinter Troggs and 10 Stonesplinter Scouts.",en={1089},l=12,n="In Defense of the King's Lands",nx=237,ob={k={{1161},{1162}}},r=77,rl=10,sn={1089},x=910}
T[225]={d="Speak with Sirra Von'Indi in Darkshire.",en={268},l=35,n="The Weathered Grave",nx=227,r=77,rl=28,so={61},x=690}
T[226]={d="Kill 12 Starving Dire Wolves and 8 Rabid Dire Wolves, then return to Lars at Sven's Camp on the western border of Duskwood.",en={893},l=21,n="Wolves at Our Heels",ob={k={{213},{565}}},r=77,rl=19,sn={893},x=1250}
T[227]={d="Speak with Commander Althea Ebonlocke in Darkshire.",en={264},l=35,n="Morgan Ladimore",nx=228,ps={225},r=77,rl=28,sn={268},x=275}
T[228]={d="Kill Mor'Ladim, then return his skull to Commander Althea Ebonlocke in Darkshire.",en={264},l=35,n="Mor'Ladim",nx=229,ob={i={{3514}}},ps={227},r=77,rl=28,sn={264},tg=1,x=2050}
T[229]={d="Speak with Watcher Sarah Ladimore in Darkshire.",en={576},l=35,n="The Daughter Who Lived",nx=231,ps={228},r=77,rl=28,sn={264},x=275}
T[230]={d="Bring the Book from Sven's Farm to Sven.",en={311},l=25,n="Sven's Camp",nx=262,ps={95},r=77,rl=20,so={59},su=2161,x=1000}
T[231]={d="Take Sarah Ladimore's ring to Morgan Ladimore's grave.",eo={61},l=35,n="A Daughter's Love",ps={229},r=77,rl=28,sn={576},su=2162,x=1350}
T[232]={d="Take the purchase order to Alessandro Luca in the Undercity.",en={7683},l=45,n="Errand for Apothecary Zinge",nx=238,r=178,rl=38,sn={5204},su=8525,x=390}
T[233]={d="Deliver the stack of letters to Talin Keeneye.",en={714},l=3,n="Coldridge Valley Mail Delivery",nx=234,ps={179},r=77,rl=1,sn={658},su=2187,x=190}
T[234]={d="Deliver the letter to Grelin Whitebeard.",en={786},l=4,n="Coldridge Valley Mail Delivery",ps={233},r=77,rl=1,sn={714},su=2188,x=270}
T[235]={d="Speak with Senani Thunderheart at Splintertree Post, Ashenvale.",en={12696},ex={742,6382},l=20,n="The Ashenvale Hunt",nx=6383,r=178,rl=20,sn={10880},x=155}
T[237]={d="Mountaineer Gravelgaw in the southern guard tower wants you to kill 10 Stonesplinter Skullthumpers and 10 Stonesplinter Seers and report back to him.",en={1091},l=15,n="In Defense of the King's Lands",nx=263,ob={k={{1163},{1166}}},ps={224},r=77,rl=10,sn={1091},x=1050}
T[238]={d="Bring the Field Sampling Kit to Apothecary Zinge in the Undercity.",en={5204},l=45,n="Errand for Apothecary Zinge",nx=243,ps={232},r=178,rl=38,sn={7683},su=8523,x=390}
T[239]={d="Go to the Westbrook Garrison and speak with Deputy Rainer.",en={963},l=10,n="Westbrook Garrison Needs Help!",nx=11,ps={76},r=77,rl=6,sn={240},x=210}
T[240]={d="Return to Jitters with the Dusky Crab Cakes.",en={288},l=20,n="Return to Jitters",ps={93},r=77,rl=17,sn={272},su=2250,x=780}
T[243]={d="Speak to Chief Engineer Bilgewhizzle in Gadgetzan about getting a power source for the testing kit.",en={7407},l=46,n="Into the Field",nx=379,ps={238},r=178,rl=38,sn={5204},su=8523,x=2000}
T[244]={d="Report to Deputy Feldon.",en={1070},l=16,n="Encroaching Gnolls",nx=246,r=77,rl=11,sn={464},x=290}
T[245]={d="Kill 15 Pygmy Venom Web Spiders, and then report back to Watcher Dodds in Duskwood.",en={888},l=21,n="Eight-Legged Menaces",ob={k={{539}}},r=77,rl=17,sn={888},x=1250}
T[246]={d="Kill 10 Redridge Mongrels and 6 Redridge Poachers, then report back to Deputy Feldon in Lakeshire.",en={1070},l=17,n="Assessing the Threat",ob={k={{423},{424}}},ps={244},r=77,rl=11,sn={1070},x=950}
T[247]={en={12696},l=30,n="The Hunt Completed",pg={2,23,24},r=178,rl=20,sn={12696},x=3050}
T[248]={d="Climb the intact watch tower beside Stonewatch Keep.",eo={76},l=22,n="Looking Further",nx=249,ps={94},r=77,rl=20,so={31},su=1083,tg=1,x=1300}
T[249]={d="Defeat Morganth.",en={313},l=27,n="Morganth",ob={i={{3617}}},ps={248},r=77,rl=20,sn={313},so={31},tg=1,x=2750}
T[250]={d="Investigate the area near the eastern ramp of the Dam and bring Chief Engineer Hinderweir a clue that might reveal what the Dark Iron Dwarves are up to.",eo={257},l=18,n="A Dark Threat Looms",nx=199,r=77,rl=16,sn={1093},x=680}
T[251]={d="Bring the Letter to Ello to Sirra Von'Indi.",en={268},l=30,n="Translate Abercrombie's Note",nx=401,ps={160},r=77,rl=20,sn={263},su=1637,x=245}
T[252]={d="Bring the Translated Letter to Lord Ello Ebonlocke",en={263},l=30,n="Translation to Ello",nx=253,ps={401},r=77,rl=20,sn={268},su=1656,x=245}
T[253]={d="Find Eliza's grave. Retrieve the Embalmer's Heart from her, then return to Ello Ebonlocke.",en={263},l=30,n="Bride of the Embalmer",ob={i={{2382}}},ps={252},r=77,rl=20,sn={263},tg=1,x=3650}
T[254]={eo={51708},l=35,n="Digging Through the Dirt",pa=253,r=77,rl=20,sf=1,so={51708}}
T[255]={d="Magistrate Bluntnose of Thelsamar has hired you to kill 4 Mo'grosh Ogres, 4 Mo'grosh Brutes and 4 Mo'grosh Enforcers.",en={1139},l=19,n="Mercenaries",ob={k={{1178},{1180},{1179}}},r=77,rl=15,sn={1139},tg=1,x=1800}
T[256]={d="Kill Chok'sul and bring his head to Magistrate Bluntnose of Thelsamar.",en={1139},l=22,n="WANTED: Chok'sul",ob={i={{2561}}},r=77,rl=17,so={256},tg=1,x=1750}
T[257]={d="Kill 6 Mountain Buzzards and return to Daryl the Youngling in the Farstrider Lodge within 15 minutes.",en={1187},l=16,n="A Hunter's Boast",nx=258,ob={k={{1194}}},r=77,rl=11,sn={1187},x=880}
T[258]={d="Kill 5 Elder Mountain Boars and return to Daryl the Youngling in the Farstrider Lodge within 12 minutes.",en={1187},l=17,n="A Hunter's Challenge",nx=271,ob={k={{1192}}},ps={257},r=77,rl=11,sn={1187},x=950}
T[261]={d="Destroy 30 Undead Ravagers, then return to Brother Anton at Nijel's Point.",en={1182},l=39,n="Down the Scarlet Path",nx=1052,ob={k={{11561}}},r=77,rl=34,sn={1182},x=3000}
T[262]={d="Take the book you found at Sven's farm and show it to townsfolk in Darkshire.",en={265},l=25,n="The Shadowy Figure",nx=265,ps={230},r=77,rl=20,sn={311},su=2161,x=510}
T[263]={d="Mountaineer Wallbang in the southern guard tower wants you to kill 10 Stonesplinter Shaman and 10 Stonesplinter Bonesnappers.",en={1090},l=15,n="In Defense of the King's Lands",nx=217,ob={k={{1197},{1164}}},ps={237},r=77,rl=10,sn={1090},x=1050}
T[264]={d="Place Clarice's Pendant on Yuriv's Tomb in Silverpine.",eo={24776},l=15,n="Until Death Do Us Part",r=178,rl=12,sn={5543},su=6145,x=540}
T[265]={d="See if other townsfolk have clues about the shadowy figure.",en={267},l=25,n="The Shadowy Search Continues",nx=266,ps={262},r=77,rl=20,sn={265},su=2161,x=200}
T[266]={d="Search the inn for clues about the shadowy figure.",en={273},l=25,n="Inquire at the Inn",nx=453,ps={265},r=77,rl=20,sn={267},su=2161,x=200}
T[267]={d="Bring 8 Trogg Stone Teeth to Captain Rugelfuss in the southern guard tower.",en={1092},l=12,n="The Trogg Threat",ob={i={{2536}}},r=77,rl=10,sn={1092},x=910}
T[268]={d="Return to Sven with Jitters' completed journal.",en={311},l=25,n="Return to Sven",nx=323,ps={453},r=77,rl=20,sn={288},su=2560,x=510}
T[269]={d="Give Jitters' Completed Journal to Bishop Farthing in Stormwind.",en={1212},l=29,n="Seeking Wisdom",nx=270,ps={323},r=77,rl=20,sn={311},su=2560,x=590}
T[270]={d="Go to Menethil Harbor in the Wetlands, and speak with Glorin Steelbrow.",en={1217},l=29,n="The Doomed Fleet",nx=321,ps={269},r=77,rl=20,sn={1212},x=1200}
T[271]={d="Kill Ol' Sooty then show your handiwork to Daryl the Youngling at the Farstrider Lodge.",en={1187},l=20,n="Vyrin's Revenge",nx=531,ob={i={{2713}}},ps={258},r=77,rl=15,sn={1156},tg=1,x=780}
T[272]={c=1024,d="Find the Half Pendant of Aquatic Agility and the Half Pendant of Aquatic Endurance. Speak with the residents of Moonglade to learn clues as to where these items may be located.",en={11802},l=16,n="Trial of the Sea Lion",nx=5061,ob={i={{15885}}},ps={29},r=8,rl=16,rs={15883,15882},sn={11799},x=880}
T[273]={d="Speak with Huldar.",en={2057},l=15,n="Resupplying the Excavation",nx=454,ob={e={"Find Huldar, Miran, and Saean",{{1432,51.2,69}}}},ps={302},r=77,rl=10,sf=2,sn={1105},x=270}
T[274]={d="Ashlan Stonesmirk wants you to return to Chief Engineer Hinderweir and inform him of the new discovery.",en={1093},l=18,n="A Dark Threat Looms",nx=278,ps={161},r=77,rl=16,sn={1073},su=2609,x=340}
T[275]={d="Kill 12 Fen Creepers, then return to Rethiel the Greenwarden in the Wetlands.",en={1244},l=26,n="Blisters on The Land",ob={k={{1040}}},ps={277},r=77,rl=20,sn={1244},x=2650}
T[276]={d="Kill 15 Mosshide Gnolls and 10 Mosshide Mongrels, then return to Rethiel the Greenwarden in the Wetlands.",en={1244},l=21,n="Tramping Paws",nx=277,ob={k={{1007},{1008}}},r=77,rl=20,sn={1244},x=1250}
T[277]={d="Bring Rethiel the Greenwarden 9 Crude Flints.",en={1244},l=23,n="Fire Taboo",nx=275,ob={i={{2611}}},ps={276},r=77,rl=20,sn={1244},x=1850}
T[278]={d="Chief Engineer Hinderweir wants you to gather Lurker Venom, a Mo'grosh Crystal, and a Crocolisk Tear.",en={1093},l=18,n="A Dark Threat Looms",nx=280,ob={i={{2606},{2607},{2939}}},ps={274},r=77,rl=16,sn={1093},tg=1,x=1350}
T[279]={d="Kill 12 Bluegill Murlocs.",en={1242},l=22,n="Claws from the Deep",nx=281,ob={i={{3618}},k={{1024}}},r=77,rl=20,sn={1242},x=1750}
T[280]={d="Chief Engineer Hinderweir wants you to swim down to the base of the dam, locate the powder keg and stir in the Disarming Mixture to prevent an explosion.",eo={1585},l=18,n="A Dark Threat Looms",nx=283,ps={278},r=77,rl=16,sn={1093},su=2610,x=680}
T[281]={d="Search the crates and barrels at the coastal Murloc camps.",eo={261},l=25,n="Reclaiming Goods",nx=284,ps={279},r=77,rl=20,sn={1242},x=510}
T[282]={d="Speak with Mountaineer Thalos.",en={1965},ex={287},l=5,n="Senir's Observations",nx=420,ps={218},r=77,rl=1,sn={786},su=2619,x=335}
T[283]={d="The Disarming Mixture seemed to take effect. Return to Chief Engineer Hinderweir to report the good news.",en={1093},l=20,n="A Dark Threat Looms",ps={280},r=77,rl=16,so={1585},x=1950}
T[284]={d="Search for the Menethil Statuette.",eo={142151},l=25,n="The Search Continues",nx=285,ps={281},r=77,rl=20,so={261},x=510}
T[285]={d="Continue searching the Murloc hovels for the Menethil Statuette.",eo={259},l=25,n="Search More Hovels",nx=286,ps={284},r=77,rl=20,so={142151},x=1000}
T[286]={d="Bring Karl Boran the Menethil Statuette.",en={1242},l=25,n="Return the Statuette",ps={285},r=77,rl=20,so={259},su=2625,x=1500}
T[287]={d="Explore Frostmane Hold, and kill 5 Frostmane Headhunters for Senir Whitebeard in Kharanos.",en={1252},l=9,n="Frostmane Hold",nx=291,ob={e={"Fully explore Frostmane Hold",{{1426,22.8,52.1}}},k={{1123}}},r=77,rl=7,sf=2,sn={1252},x=590}
T[288]={d="Buy First Mate Fitzsimmons a Flagon of Mead.",en={1239},l=27,n="The Third Fleet",nx=289,ob={i={{2594}}},r=77,rl=22,sn={1239},x=220}
T[289]={d="Kill 13 Cursed Sailors, 5 Cursed Marines and First Mate Snellig. Bring Snellig's Snuffbox to First Mate Fitzsimmons in Menethil Harbor.",en={1239},l=29,n="The Cursed Crew",nx=290,ob={i={{3619}},k={{1157},{1158}}},ps={288},r=77,rl=22,sn={1239},x=1750}
T[290]={d="Get the Intrepid Strongbox Key from Captain Halyndor.",eo={112948},l=30,n="Lifting the Curse",nx=292,ob={i={{2629}}},ps={289},r=77,rl=22,sn={1239},x=1200}
T[291]={d="Deliver Senir's report to Senator Barin Redstone in Ironforge.",en={1274},l=10,n="The Reports",ps={287},r=77,rl=1,sn={1252},su=2628,x=420}
T[292]={d="Bring the Cursed Eye of Paleth to Glorin Steelbrow.",en={1217},l=30,n="The Eye of Paleth",nx=293,ps={290},r=77,rl=22,so={112948},su=2944,x=1200}
T[293]={d="Bring Archbishop Benedictus the Cursed Eye of Paleth. Benedictus is in the Cathedral of Light, in the city of Stormwind.",en={1284},l=30,n="Cleansing the Eye",ps={292},r=77,rl=22,sn={1217},su=2944,x=2450}
T[294]={d="Ormer Ironbraid at the Whelgar Excavation Site wants you to kill 10 Mottled Screechers and 10 Mottled Raptors.",en={1078},l=24,n="Ormer's Revenge",nx=295,ob={k={{1020},{1021}}},r=77,rl=22,sn={1078},x=1950}
T[295]={d="Ormer Ironbraid wants you to kill 10 Mottled Scytheclaw raptors and 10 Mottled Razormaw raptors then return to him at the Whelgar Excavation Site.",en={1078},l=27,n="Ormer's Revenge",nx=296,ob={k={{1022},{1023}}},ps={294},r=77,rl=22,sn={1078},x=2200}
T[296]={d="Ormer Ironbraid at the Whelgar Excavation Site wants you to kill Sarltooth and return to him with one of his talons once the task is fulfilled.",en={1078},l=29,n="Ormer's Revenge",ob={i={{3638}}},ps={295},r=77,rl=22,sn={1078},x=2950}
T[297]={d="Bring Magmar Fellhew 8 Carved Stone Idols.",en={1345},l=18,n="Gathering Idols",ob={i={{2636}}},r=77,rl=13,sn={1345},x=1350}
T[298]={d="Bring Ironband's Progress Report to Jern Hornhelm in Thelsamar.",en={1105},l=15,n="Excavation Progress Report",nx=301,r=77,rl=10,sn={1344},su=2637,x=270}
T[299]={d="Prospector Whelgar wants you to scour the excavation site in search of the 4 missing tablet fragments: Ados, Modr, Golm and Neru.",en={1077},l=28,n="Uncovering the Past",ob={i={{2658},{2659},{2660},{2661}}},r=77,rl=25,sn={1077},x=2300}
T[301]={d="Take Ironband's Progress Report to Prospector Stormpike.",en={1356},l=15,n="Report to Ironforge",nx=302,ps={298},r=77,rl=10,sn={1105},su=2637,x=540}
T[302]={d="Speak with Jern Hornhelm in Thelsamar.",en={1105},l=15,n="Powder to Ironband",nx=273,ps={301},r=77,rl=10,sn={1356},x=270}
T[303]={d="Motley Garmason at Dun Modr wants you to kill 10 Dark Iron Dwarves, 5 Dark Iron Tunnelers, 5 Dark Iron Saboteurs and 5 Dark Iron Demolitionists.",en={1074},l=30,n="The Dark Iron War",nx=378,ob={k={{1051},{1053},{1052},{1054}}},r=77,rl=25,sn={1074},tg=1,x=2450}
T[304]={d="Kill Balgaras the Foul and bring his ear to Longbraid the Grim outside of Dun Modr.",en={1071},l=34,n="A Grim Task",ob={i={{3639}}},r=77,rl=26,sn={1071},tg=1,x=3350}
T[305]={d="Tarrel Rockweaver wants you to travel to the Excavation Site and contact Merrin Rockweaver.",en={1076},l=24,n="In Search of The Excavation Team",nx=306,r=77,rl=21,sn={2096},x=970}
T[306]={d="Return to Tarrel Rockweaver with Merrin's note.",en={2096},l=24,n="In Search of The Excavation Team",ps={305},r=77,rl=21,sn={1076},su=2639,x=485}
T[307]={d="Go to the Silver Stream Mine and collect 4 loads of Miners' Gear.",en={1343},l=15,n="Filthy Paws",ob={i={{2640}}},r=77,rl=9,sn={1343},x=1350}
T[308]={en={1373},l=7,n="Distracting Jarven",ob={i={{2686}}},pa=310,r=77,rl=1,sf=1,sn={1373}}
T[309]={d="Ensure Miran and the shipment arrive at the excavation site, then inform Prospector Ironband.",en={1344},l=15,n="Protecting the Shipment",ob={e={"Escort Miran to the excavation site",{{1432,65.1,65.8}}}},ps={454},r=77,rl=10,sf=2,sn={1379},x=1050}
T[310]={d="In the basement of the Thunderbrew Distillery in Kharanos, replace a barrel of Thunder Ale with a Barrel of Barleybrew Scalder.",eo={270},l=6,n="Bitter Rivals",nx=311,r=77,rl=2,sn={1375},su=2548,x=135}
T[311]={d="Bring the barrel of Thunder Ale to Marleth Barleybrew at the Brewnall Village.",en={1375},l=7,n="Return to Marleth",ps={310},r=77,rl=2,so={270},su=2666,x=630}
T[312]={d="Retrieve Tundra MacGrann's dried meats from the stolen meat locker in Old Icebeard's cave.",en={1266},l=12,n="Tundra MacGrann's Stolen Stash",ob={i={{2667}}},r=77,rl=7,sn={1266},x=910}
T[313]={d="Gather 8 Wendigo Manes and bring them to Pilot Stonegear.",en={1377},l=7,n="The Grizzled Den",ob={i={{2671}}},r=77,rl=4,sn={1377},x=630}
T[314]={d="Rudra Amberstill wants you to slay Vagash and bring his fang to her at the Ram ranch.",en={1265},l=12,n="Protecting the Herd",ob={i={{3627}}},r=77,rl=6,sn={1265},tg=1,x=910}
T[315]={d="Bring 6 Shimmerweeds to Rejold Barleybrew in the Brewnall Village.",en={1374},l=9,n="The Perfect Stout",nx=413,ob={i={{2676}}},r=77,rl=5,sn={1374},x=780}
T[317]={d="Gather 4 Chunks of Boar Meat and 2 Thick Bear Furs, and deliver them to Pilot Bellowfiz at Steelgrill's Depot.",en={1378},l=6,n="Stocking Jetsteam",nx=318,ob={i={{769},{6952}}},r=77,rl=2,sn={1378},x=680}
T[318]={d="Get a cask of Evershine from Rejold Barleybrew in Brewnall Village.",en={1374},l=7,n="Evershine",nx=319,ps={317},r=77,rl=2,sn={1378},x=160}
T[319]={d="Kill 6 Ice Claw Bears, 8 Elder Crag Boars, and 8 Snow Leopards, and then return to Rejold Barleybrew in Brewnall Village.",en={1374},l=8,n="A Favor for Evershine",nx=320,ob={k={{1196},{1127},{1201}}},ps={318},r=77,rl=2,sn={1374},x=530}
T[320]={d="Give the cask of Evershine to Pilot Bellowfiz at Steelgrill's Depot.",en={1378},l=8,n="Return to Bellowfiz",ps={319},r=77,rl=2,sn={1374},su=2696,x=880}
T[321]={d="Search the wreckage of The Flying Osprey in the Wetlands.",eo={2734},l=29,n="Lightforge Iron",nx=324,ps={270},r=77,rl=20,sn={1217},x=590}
T[322]={d="Take the Crate of Lightforge Ingots to Grimand Elmore in Stormwind.",en={1416},l=29,n="Blessed Arm",nx=325,ps={324},r=77,rl=20,sn={1217},su=2712,x=1200}
T[323]={d="Kill 15 Skeletal Raiders, 3 Skeletal Healers and 3 Skeletal Warders, and then return to Sven.",en={311},l=28,n="Proving Your Worth",nx=269,ob={k={{1110},{787},{785}}},ps={268},r=77,rl=20,sn={311},x=2300}
T[324]={d="Gather 5 Lightforge Ingots, then return to Glorin Steelbrow in the Wetlands.",en={1217},l=29,n="The Lost Ingots",nx=322,ob={i={{2702}}},ps={321},r=77,rl=20,so={2734},x=1750}
T[325]={d="Bring Morbent's Bane to Sven in Duskwood.",en={311},l=29,n="Armed and Ready",nx=55,ps={322},r=77,rl=20,sn={1416},su=7297,x=590}
T[328]={d="Use the Small Brass Key to open Bookie Herod's Strongbox.",eo={288},l=37,n="The Hidden Key",nx=329,ps={200},r=77,rl=30,so={287},su=2719,x=1400}
T[329]={d="Take the Muddy Note to Lieutenant Doren at the Rebel Camp.",en={469},l=37,n="The Spy Revealed!",nx=330,ps={328},r=77,rl=30,so={288},su=2720,x=1400}
T[330]={d="Speak with Corporal Sethman.",en={1422},l=37,n="Patrol Schedules",nx=331,ps={329},r=77,rl=30,sn={469},x=285}
T[331]={d="Speak with Lieutenant Doren.",en={469},l=37,n="Report to Doren",ps={330},r=77,rl=30,sn={1422},x=2850}
T[332]={d="Go to the Gallina Winery, and bring Suzetta Gallina the Wine Ticket for a free bottle of wine.",en={1431},l=2,n="Wine Shop Advert",r=77,rl=1,sn={1432},su=2722,x=130}
T[333]={d="Go to the Canal Tailor Shop and bring Rema Schneider the Cloth Request from Harlan Bagley.",en={1428},l=2,n="Harlan Needs a Resupply",r=77,rl=1,sn={1427},su=2724,x=85}
T[334]={d="Go to the Larson Clothiers in the Stormwind Mage Quarter, and give Thurman Schneider his Sewing Kit.",en={1429},l=2,n="Package for Thurman",r=77,rl=1,sn={1428},su=2760,x=130}
T[335]={d="Zardeth the Black Claw wants you to bring him a Tear of Tilloa from Darkshire and a Musquash Root from the Wetlands.",en={1435},l=30,n="A Noble Brew",nx=336,ob={i={{2779},{2784}}},r=77,rl=25,sn={1435},x=2450}
T[336]={d="Take the Black Claw Stout to Lord Wishock in the Hall of Petitioners.",en={1439},l=30,n="A Noble Brew",nx=397,ps={335},r=77,rl=25,sn={1435},su=2788,x=2450}
T[337]={d="Return the book: The History of Stormwind, to the Stormwind Library.",en={1440},l=25,n="An Old History Book",nx=538,r=77,rl=20,si={2794},su=2794,x=1500}
T[338]={d="Collect the missing pages from The Green Hills of Stranglethorn manuscript. Once all four chapters are complete, return them to Barnil.",en={716},l=40,n="The Green Hills of Stranglethorn",ob={i={{2756},{2757},{2758},{2759}}},ps={583},r=0,rl=30,sn={716},x=4700}
T[339]={d="Bring pages 1, 4, 6, and 8 of Nesingwary's The Green Hills of Stranglethorn to Barnil Stonepot in order to complete Chapter I.",en={716},l=40,n="Chapter I",ob={i={{2725},{2728},{2730},{2732}}},pa=338,r=0,rl=30,sn={716},x=780}
T[340]={d="Bring pages 10, 11, 14 and 16 of Nesingwary's The Green Hills of Stranglethorn to Barnil Stonepot in order to complete Chapter II.",en={716},l=40,n="Chapter II",ob={i={{2734},{2735},{2738},{2740}}},pa=338,r=0,rl=30,sn={716},x=780}
T[341]={d="Bring pages 18, 20, 21and 24 of Nesingwary's The Green Hills of Stranglethorn to Barnil Stonepot in order to complete Chapter III.",en={716},l=40,n="Chapter III",ob={i={{2742},{2744},{2745},{2748}}},pa=338,r=0,rl=30,sn={716},x=780}
T[342]={d="Bring pages 25, 26, and 27 of Nesingwary's The Green Hills of Stranglethorn to Barnil Stonepot in order to complete Chapter IV.",en={716},l=40,n="Chapter IV",ob={i={{2749},{2750},{2751}}},pa=338,r=0,rl=30,sn={716},x=780}
T[343]={d="Go to the Royal Library in Stormwind Keep and speak with Milton Sheaf. He can find for you the book on metallurgy that Brother Kristoff needs for his speech.",en={1440},l=24,n="Speaking of Fortitude",nx=344,r=77,rl=20,sn={1444},x=195}
T[344]={d="Speak with Brother Paxton in the Northshire Abbey.",en={951},l=24,n="Brother Paxton",nx=345,ps={343},r=77,rl=20,sn={1440},x=485}
T[345]={d="Speak with Foreman Oslow in Lakeshire and ask him for Rethban Iron Ore.",en={341},l=24,n="Ink Supplies",nx=347,ps={344},r=77,rl=20,sn={951},x=485}
T[346]={d="Return to Brother Kristoff in the Cathedral Square. Give him the book The Stresses of Iron.",en={1444},l=24,n="Return to Kristoff",ps={347},r=77,rl=20,sn={951},su=2795,x=1950}
T[347]={d="Gather 5 loads of Rethban Ore and bring it to Brother Paxton in the Northshire Library.",en={951},l=24,n="Rethban Ore",nx=346,ob={i={{2798}}},ps={345},r=77,rl=20,sn={341},x=970}
T[348]={d="Seek out Witch Doctor Unbagwa and have him summon Mokk the Savage. Bring the Heart of Mokk to Fin Fizracket.",en={2486},l=45,n="Stranglethorn Fever",ob={i={{2797}}},r=0,rl=40,sn={2486},x=5850}
T[349]={en={1449},l=45,n="Stranglethorn Fever",ob={i={{2799}}},pa=348,r=0,rl=32,sf=1,sn={1449}}
T[350]={d="Speak to Elling Trias in Stormwind.",en={482},l=31,n="Look to an Old Friend",nx=2745,ps={393},r=77,rl=16,sn={332},x=250}
T[351]={d="Bring the distress beacon to Oglethorpe's homing robot.",en={7784},l=48,n="Find OOX-17/TN!",nx=648,r=0,rl=43,si={8623},su=8623,x=4400}
T[353]={d="Deliver the Package for Stormpike to Mountaineer Stormpike in Loch Modan.",en={1343},l=15,n="Stormpike's Delivery",r=77,rl=9,sn={1416},su=2806,x=1050}
T[354]={d="Bring Gregor's Remains, Nissa's Remains and Thurman's Remains to Coleman Farthing in Brill.",en={1500},l=11,n="Deaths in the Family",ob={i={{2829},{2828},{2830}}},r=178,rl=7,sn={1500},x=880}
T[355]={d="Speak with Magistrate Sevren in Brill.",en={1499},l=10,n="Speak with Sevren",nx=408,pg={354,362},r=178,rl=7,sn={1500},x=85}
T[356]={d="Kill 8 Bleeding Horrors and 8 Wandering Spirits, then report back to Linnea at her camp.",en={1495},l=11,n="Rear Guard Patrol",ob={k={{1529},{1532}}},r=178,rl=6,sn={1495},x=660}
T[357]={d="Bring the Lich's Spellbook to Bethor Iceshard in the Undercity.",en={1498},l=8,n="The Lich's Identity",nx=366,ob={i={{2833}}},ps={405},r=178,rl=5,sn={1498},x=530}
T[358]={d="Kill Rot Hide Graverobbers and Rot Hide Mongrels. ",en={1499},l=8,n="Graverobbers",ob={i={{2834}},k={{1941},{1675}}},r=178,rl=4,sn={1499},x=700}
T[359]={d="Speak with Deathguard Linnea.",en={1495},l=9,n="Forsaken Duties",nx=360,ps={358},r=178,rl=6,sn={1499},x=195}
T[360]={d="Return to Magistrate Sevren in Brill.",en={1499},l=9,n="Return to the Magistrate",ps={359},r=178,rl=6,sn={1495},x=390}
T[361]={d="Find Yvette Farthing, and deliver to her the letter from Thurman Agamand.",en={1560},l=7,n="A Letter Undelivered",r=178,rl=4,si={2839},su=2837,x=475}
T[362]={d="Slay Devlin Agamand, and bring Devlin's Remains to Coleman Farthing in Brill.",en={1500},l=10,n="The Haunted Mills",ob={i={{2831}}},r=178,rl=7,sn={1500},x=420}
T[363]={d="Speak with Shadow Priest Sarvis.",en={1569},l=1,n="Rude Awakening",nx=364,r=16,rl=1,sn={1568},x=40}
T[364]={d="Shadow Priest Sarvis wants you to kill 8 Mindless Zombies and 8 Wretched Zombies.",en={1569},l=2,n="The Mindless Ones",ob={k={{1501},{1502}}},r=178,rl=1,sn={1569},x=170}
T[365]={d="Steal 10 pumpkins from the farm to the west, just north of Deathknell and take them to Apothecary Johaan in Brill.",en={1518},l=7,n="Fields of Grief",nx=407,ob={i={{2846}}},r=178,rl=4,sn={1519},x=630}
T[366]={d="Return Gunther's Spellbook to him, on the island of Gunther's Retreat.",en={1497},l=8,n="Return the Book",nx=409,ps={357},r=178,rl=5,sn={1498},su=3016,x=350}
T[367]={d="Apothecary Johaan in the town of Brill wants you to collect 5 Vials of Darkhound Blood.",en={1518},l=6,n="A New Plague",nx=368,ob={i={{2858}}},r=178,rl=6,sn={1518},x=540}
T[368]={d="Apothecary Johaan of the town of Brill needs 5 Vile Fin Scales from Murlocs in Tirisfal Glades.",en={1518},l=9,n="A New Plague",nx=369,ob={i={{2859}}},ps={367},r=178,rl=6,sn={1518},x=780}
T[369]={d="Apothecary Johaan in the town of Brill wants you to bring him 4 samples of venom from a Vicious Night Web Spider.",en={1518},l=11,n="A New Plague",nx=492,ob={i={{2872}}},ps={368},r=178,rl=6,sn={1518},x=220}
T[370]={d="Executor Zygand in Brill wants you to kill Captain Perrine, 3 Scarlet Zealots and 3 Scarlet Missionaries.",en={1515},l=9,n="At War With The Scarlet Crusade",nx=371,ob={k={{1662},{1537},{1536}}},ps={427},r=178,rl=5,sn={1515},x=780}
T[371]={d="Executor Zygand in Brill has commissioned you to slay Captain Vachon and 5 Scarlet Friars.",en={1515},l=10,n="At War With The Scarlet Crusade",nx=372,ob={k={{1664},{1538}}},ps={370},r=178,rl=5,sn={1515},x=840}
T[372]={d="Executor Zygand in the town of Brill wants you to assassinate Captain Melrache and his two bodyguards.",en={1515},l=12,n="At War With The Scarlet Crusade",ob={k={{1665},{1660}}},ps={371},r=178,rl=5,sn={1515},x=910}
T[373]={d="Deliver the Letter to the City Architect to Baros Alexston in Stormwind.",en={1646},l=22,n="The Unsent Letter",nx=389,r=77,rl=16,si={2874},su=2874,x=870}
T[374]={d="Bring 10 Scarlet Insignia Rings to Deathguard Burgess in Brill.",en={1652},l=7,n="Proof of Demise",ob={i={{2875}}},ps={427},r=178,rl=5,sn={1652},x=630}
T[375]={d="Bring five Duskbat Pelts and some Coarse Thread to Gretchen Dedmar in Brill.",en={1521},l=8,n="The Chill of Death",ob={i={{2876},{2320}}},r=178,rl=7,sn={1521},x=700}
T[376]={d="Novice Elreth requires 6 Scavenger Paws and 6 Duskbat Wings.",en={1661},l=2,n="The Damned",ob={i={{3265},{3264}}},r=178,rl=2,sn={1661},x=170}
T[377]={d="Councilman Millstipe of Darkshire wants you to bring him the hand of Dextren Ward.",en={270},l=26,n="Crime and Punishment",ob={i={{3628}}},r=77,rl=22,sn={270},tg=81,x=2100,z=717}
T[378]={d="Motley Garmason wants Kam Deepfury's head brought to him at Dun Modr.",en={1074},l=27,n="The Fury Runs Deep",ob={i={{3640}}},ps={303},r=77,rl=22,sn={1074},tg=81,x=2750,z=717}
T[379]={d="Bring 5 Wastewander Water Pouches to Chief Engineer Bilgewhizzle in Gadgetzan.",en={7407},l=46,n="Slake That Thirst",ob={i={{8483}}},ps={243},r=178,rl=38,sn={7407},x=3050}
T[380]={d="Executor Arren wants you to kill 10 Young Night Web Spiders and 8 Night Web Spiders.",en={1570},l=4,n="Night Web's Hollow",nx=381,ob={k={{1504},{1505}}},ps={376},r=178,rl=2,sn={1570},x=355}
T[381]={d="Bring Executor Arren 12 Scarlet Armbands from Scarlet Converts and Scarlet Initiates.",en={1570},l=4,n="The Scarlet Crusade",nx=382,ob={i={{3266}}},ps={380},r=178,rl=2,sn={1570},x=355}
T[382]={d="Kill Meven Korgal, the messenger, at the Crusader camp, then return any information you find to Executor Arren.",en={1570},l=5,n="The Red Messenger",nx=383,ob={i={{2885}}},ps={381},r=178,rl=2,sn={1570},x=670}
T[383]={d="Deliver the Scarlet Crusade Documents to Executor Zygand in Brill.",en={1515},l=5,n="Vital Intelligence",ps={382},r=178,rl=2,sn={1570},su=2885,x=335}
T[384]={d="Ragnar Thunderbrew in Kharanos wants 6 Crag Boar Ribs and a mug of Rhapsody Malt.",en={1267},l=7,n="Beer Basted Boar Ribs",ob={i={{2886},{2894}}},r=77,rl=5,sn={1267},x=630}
T[385]={d="Get 5 pieces of Crocolisk Meat and 6 Crocolisk Skins for Marek Ironheart at the Farstrider Lodge.",en={1154},l=15,n="Crocolisk Hunting",ob={i={{2924},{2925}}},r=77,rl=10,sn={1154},x=1050}
T[386]={d="Bring the head of Targorr the Dread to Guard Berton in Lakeshire.",en={859},l=25,n="What Comes Around...",ob={i={{3630}}},r=77,rl=22,sn={859},tg=81,x=2000,z=717}
T[387]={d="Warden Thelwater of Stormwind wants you to kill 10 Defias Prisoners, 8 Defias Convicts, and 8 Defias Insurgents in The Stockade.",en={1719},l=26,n="Quell The Uprising",ob={k={{1706},{1711},{1715}}},r=77,rl=22,sn={1719},tg=81,x=2650,z=717}
T[388]={d="Nikova Raskol of Stormwind wants you to collect 10 Red Wool Bandanas.",en={1721},l=26,n="The Color of Blood",ob={i={{2909}}},r=77,rl=22,sn={1721},tg=81,x=2650,z=717}
T[389]={d="Speak with Warden Thelwater in the Stockade.",en={1719},l=22,n="Bazil Thredd",nx=391,ps={373},r=77,rl=16,sn={1646},x=435}
T[391]={d="Kill Bazil Thredd and bring his head back to Warden Thelwater at the Stockade.",en={1719},l=29,n="The Stockade Riots",nx=392,ob={i={{2926}}},ps={389},r=77,rl=16,sn={1719},tg=81,x=2950,z=717}
T[392]={d="Bring the Sealed Description of Thredd's Visitor to Baros Alexston in Stormwind.",en={1646},l=29,n="The Curious Visitor",nx=393,ps={391},r=77,rl=16,sn={1719},su=8687,x=590}
T[393]={d="Bring the Sealed Description of Thredd's Visitor to Master Mathias Shaw in Stormwind.",en={332},l=29,n="Shadow of the Past",nx=350,ps={392},r=77,rl=16,sn={1646},su=8687,x=590}
T[394]={d="Speak to Mathias Shaw in Stormwind.",en={332},l=31,n="The Head of the Beast",nx=395,ps={434},r=77,rl=16,sn={482},x=250}
T[395]={d="Speak with Baros Alexston in Stormwind.",en={1646},l=31,n="Brotherhood's End",nx=396,ps={394},r=77,rl=16,sn={332},x=250}
T[396]={d="Deliver Baros Alexston's report on the Defias Brotherhood to King Varian Wrynn in Stormwind Keep.",en={1749},l=31,n="An Audience with the King",ps={395},r=77,rl=16,sn={1646},su=2956,x=3750}
T[397]={c=256,d="Speak with Zggi, the servant of Zardeth the Blackclaw, to claim your reward.",en={1733},l=30,n="You Have Served Us Well",ps={336},r=65,rl=25,sn={1435},x=245}
T[398]={d="Kill Maggot Eye and return to Executor Zygand in Brill with his paw for a reward.",en={1515},l=10,n="Wanted: Maggot Eye",ob={i={{3635}}},r=178,rl=6,so={711},x=840}
T[399]={d="Go to Baros Alexston's house in Westfall and search for his compass, then return it to him in Cathedral Square of Stormwind.",en={1646},l=15,n="Humble Beginnings",ob={i={{2998}}},r=77,rl=10,sn={1646},x=1050}
T[400]={d="Deliver Steelgrill's Tools to Beldin Steelgrill.",en={1376},l=5,n="Tools for Steelgrill",r=77,rl=2,sn={1872},su=2999,x=110}
T[401]={d="Wait a moment, then speak with Sirra Von'Indi again.",en={268},l=30,n="Wait for Sirra to Finish",nx=252,ps={251},r=77,rl=20,sn={268},x=1850}
T[403]={eo={269},l=1,n="Guarded Thunderbrew Barrel",pa=310,r=77,rl=1,sf=1,so={269}}
T[404]={d="Bring 7 Putrid Claws to Deathguard Dillinger in Brill.",en={1496},l=6,n="A Putrid Task",nx=426,ob={i={{2855}}},r=178,rl=4,sn={1496},x=405}
T[405]={d="Present Sevren's Orders to Bethor Iceshard in the Undercity.",en={1498},l=8,n="The Prodigal Lich",nx=357,ps={358},r=178,rl=5,sn={1499},su=3017,x=175}
T[407]={d="Take the Laced Pumpkin to the Captured Scarlet Zealot who is being held in the cellar of the Gallow's End Tavern.",en={1931},l=7,n="Fields of Grief",ps={365},r=178,rl=4,sn={1518},su=3035,x=160}
T[408]={d="Kill 8 Wailing Ancestors and 8 Rotting Ancestors.",en={1499},l=13,n="The Family Crypt",ob={i={{3082}},k={{1534},{1530}}},ps={355},r=178,rl=7,sn={1499},x=910}
T[409]={d="Obtain a Candle of Beckoning.",en={1497},l=12,n="Proving Allegiance",nx=411,ob={k={{1946}}},ps={366},r=178,rl=5,rs={3080},sn={1497},x=680}
T[410]={eo={1557},ex={411},l=10,n="The Dormant Shade",ob={i={{3080}}},pa=409,ps={366},r=178,rl=5,sf=1,so={1557}}
T[411]={d="Bring the Nether Gem to Bethor Iceshard in the Undercity.",en={1498},l=12,n="The Prodigal Lich Returns",ps={409},r=178,rl=5,sn={1497},su=3081,x=910}
T[412]={d="Bring Razzle Sprysprocket in Kharanos 8 Restabilization Cogs and 8 Gyromechanic Gears.",en={1269},l=10,n="Operation Recombobulation",ob={i={{3083},{3084}}},r=77,rl=7,sn={1269},x=840}
T[413]={d="Take the Barrel of Shimmer Stout to Mountaineer Barleybrew.",en={1959},l=10,n="Shimmer Stout",nx=414,ps={315},r=77,rl=8,sn={1374},su=3085,x=420}
T[414]={d="Take the Cask of Shimmer Stout to Mountaineer Kadrell.",en={1340},l=10,n="Stout to Kadrell",ps={413},r=77,rl=8,sn={1959},su=3086,x=630}
T[415]={d="Speak with Rejold Barleybrew.",en={1374},l=10,n="Rejold's New Brew",nx=413,ps={315},r=77,rl=8,sn={1378,1872},x=85}
T[416]={d="Bring 12 Tunnel Rat Ears to Mountaineer Kadrell in Thelsamar.",en={1340},l=11,n="Rat Catching",ob={i={{3110}}},r=77,rl=10,sn={1340},x=880}
T[417]={d="Kill Mangeclaw.",en={1960},l=11,n="A Pilot's Revenge",ob={i={{3183}}},ps={419},r=77,rl=8,so={2059},su=3117,x=660}
T[418]={d="Bring 3 pieces of Bear Meat, 3 Boar Intestines, and 3 Spider Ichor to Vidra Hearthstove in Thelsamar.",en={1963},l=11,n="Thelsamar Blood Sausages",ob={i={{3172},{3173},{3174}}},r=77,rl=7,sn={1963},x=880}
T[419]={d="Find Pilot Hildelve.",eo={2059},l=10,n="The Lost Pilot",nx=417,r=77,rl=8,sn={1960},x=420}
T[420]={d="Deliver Grelin's report to Senir Whitebeard in Kharanos.",en={1252},l=5,n="Senir's Observations",ps={282},r=77,rl=1,sn={1965},su=2619,x=335}
T[421]={d="Dalar Dawnweaver at the Sepulcher wants you to kill 5 Moonrage Whitescalps.",en={1938},l=10,n="Prove Your Worth",nx=422,ob={k={{1769}}},r=178,rl=9,sn={1938},x=840}
T[422]={d="Retrieve the Remedy of Arugal for Dalar Dawnweaver at the Sepulcher.",en={1938},l=11,n="Arugal's Folly",nx=423,ob={i={{3155}}},ps={421},r=178,rl=9,sn={1938},x=880}
T[423]={d="Bring 6 Glutton Shackles and 3 Darksoul Shackles to Dalar Dawnweaver at the Sepulcher.",en={1938},l=14,n="Arugal's Folly",nx=424,ob={i={{3156},{3157}}},ps={422},r=178,rl=9,sn={1938},x=980}
T[424]={d="Kill Grimson the Pale and bring his head to Dalar Dawnweaver at the Sepulcher.",en={1938},l=15,n="Arugal's Folly",nx=99,ob={i={{3634}}},ps={423},r=178,rl=9,sn={1938},x=1050}
T[425]={d="Kill Ivar the Foul, and bring Ivar's Head to Rane Yorick at the Ivar Patch.",en={1950},l=12,n="Ivar the Foul",ob={i={{3621}}},ps={430},r=178,rl=10,sn={1950},x=680}
T[426]={d="Gather 5 Notched Ribs and 3 Blackened Skulls, then return to Deathguard Dillinger in Brill.",en={1496},l=8,n="The Mills Overrun",ob={i={{3162},{3163}}},ps={404},r=178,rl=6,sn={1496},x=880}
T[427]={d="Executor Zygand of Brill wants you to kill 10 Scarlet Warriors.",en={1515},l=8,n="At War With The Scarlet Crusade",nx=370,ob={k={{1535}}},r=178,rl=5,sn={1515},x=700}
T[428]={d="Find the Deathstalkers Quinn and Rane Yorick.",en={1950},l=12,n="Lost Deathstalkers",nx=429,r=178,rl=10,sn={1952}}
T[429]={d="Gather 6 discolored worg hearts and bring them to Apothecary Renferrel at the Sepulcher.",en={1937},l=11,n="Wild Hearts",nx=430,ob={i={{3164}}},r=178,rl=10,sn={1950},x=440}
T[430]={d="Bring Quinn's potion to Quinn Yorick at the Ivar Patch, north of the Sepulcher.",en={1951},l=11,n="Return to Quinn",nx=425,ps={429},r=178,rl=10,sn={1937},su=3165,x=660}
T[431]={eo={1586},ex={411},l=10,n="Candles of Beckoning",pa=409,ps={366},r=178,rl=5,sf=1,so={1586}}
T[432]={d="Kill 6 Rockjaw Skullthumpers for Foreman Stonebrow at the Gol'Bolar quarry.",en={1254},l=9,n="Those Blasted Troggs!",ob={k={{1115}}},r=77,rl=5,sn={1254},x=590}
T[433]={d="Kill 10 Rockjaw Bonesnappers for Senator Mehr Stonehallow at the Gol'Bolar quarry.",en={1977},l=11,n="The Public Servant",ob={k={{1117}}},r=77,rl=6,sn={1977},x=660}
T[434]={d="Remain in the garden until Lord Gregor Lescovar and Marzon the Silent Blade have had their conversation. Afterwards, kill them both before returning to Elling Trias in Stormwind.",en={482},l=31,n="The Attack!",nx=394,ob={e={"Overhear Lescovar and Marzon's Conversation",{{1453,72.8,35.6}}},k={{1754},{1755}}},ps={2746},r=77,rl=16,sf=2,sn={7766},x=1900}
T[435]={d="Escort Erland through the wolves, to Rane Yorick.",en={1950},es=1,l=11,n="Escorting Erland",nx=449,ob={e={"Erland must reach Rane Yorick",{{1421,54.4,13.4}}}},r=178,rl=10,sf=2,sn={1978},x=880}
T[436]={d="Speak with Explorer Fellhew.",en={1345},l=18,n="Ironband's Excavation",nx=297,r=77,rl=13,sn={1105},x=340}
T[437]={d="Kill rot hide gnolls at the Dead Fields.",en={1952},l=14,n="The Dead Fields",nx=438,ob={e={"Enter the Dead Fields",{{1421,45.9,21.3}}},i={{3622}}},r=178,rl=10,sn={1952},x=980}
T[438]={d="Go to the Decrepit Ferry.",eo={1593},l=16,n="The Decrepit Ferry",nx=439,ps={437},r=178,rl=10,sn={1952},x=880}
T[439]={d="Bring Deliah's Ring to High Executor Hadrec at the Sepulcher.",en={1952},l=16,n="Rot Hide Clues",nx=443,ps={438},r=178,rl=10,so={1593},su=3234,x=290}
T[440]={d="Bring Deliah's Ring to Magistrate Sevren in Brill.",en={1499},l=16,n="The Engraved Ring",nx=441,ps={439},r=178,rl=10,sn={1952},su=3234,x=580}
T[441]={d="Bring Deliah's Ring to Raleigh.",en={2050},l=16,n="Raleigh and the Undercity",nx=530,ps={440},r=178,rl=10,sn={1499},su=3234,x=580}
T[442]={d="Bring Thule's Head to High Executor Hadrec at the Sepulcher.",en={1952},l=24,n="Assault on Fenris Isle",ob={i={{3623}}},ps={448},r=178,rl=10,sn={1952},tg=1,x=1950}
T[443]={d="Bring 8 bottles of rot hide ichor to Apothecary Renferrel at the Sepulcher.",en={1937},l=17,n="Rot Hide Ichor",nx=444,ob={i={{3236}}},ps={439},r=178,rl=10,sn={1952},x=1250}
T[444]={d="Bring the Sample Ichor to Bethor Iceshard in the Undercity.",en={1498},l=17,n="Rot Hide Origins",nx=446,ps={443},r=178,rl=10,sn={1937},su=3237,x=315}
T[445]={d="Take Apothecary Johaan's findings to Apothecary Renferrel in Silverpine Forest.",en={1937},l=10,n="Delivery to Silverpine Forest",r=178,rl=9,sn={1518},su=3238,x=630}
T[446]={d="Bring Bethor's Scroll to Apothecary Renferrel at the Silverpine Sepulcher.",en={1937},l=16,n="Thule Ravenclaw",nx=448,ps={444},r=178,rl=10,sn={1498},su=3250,x=290}
T[447]={d="Collect 6 Grizzled Bear Hearts and 6 samples of Skittering Blood and deliver them to Master Apothecary Faranell in the Undercity.",en={2055},l=12,n="A Recipe For Death",nx=450,ob={i={{3253},{3254}}},r=178,rl=9,sn={1937},x=910}
T[448]={d="Report to High Executor Hadrec at the Sepulcher.",en={1952},l=16,n="Report to Hadrec",nx=442,ps={446},r=178,rl=10,sn={1937},x=580}
T[449]={d="Bring the Deathstalker Report to High Executor Hadrec at the Sepulcher.",en={1952},l=11,n="The Deathstalkers' Report",nx=3221,ps={435},r=178,rl=10,sn={1950},su=3252,x=440}
T[450]={d="Retrieve Apothecary Berard's journal from Pyrewood Village and take it to Apothecary Renferrel at the Sepulcher.",en={1937},l=15,n="A Recipe For Death",nx=451,ob={i={{3255}}},ps={447},r=178,rl=9,sn={2055},tg=1,x=1350}
T[451]={d="Bring 6 samples of Lake Creeper Moss, 6 samples of Lake Skulker Moss and a Hardened Tumor to Master Apothecary Faranell in the Undercity.",en={2055},l=18,n="A Recipe For Death",ob={i={{3256},{3257},{3258}}},ps={450},r=178,rl=9,sn={1937},x=2050}
T[452]={d="Help Deathstalker Faerleia kill the Pyrewood Council.",en={2058},l=15,n="Pyrewood Ambush",ob={c={{{2060,2061,2062,2063,2064,2065,2066,2067,2068}}}},r=178,rl=12,sf=2,sn={2058},tg=1,x=1350}
T[453]={d="Find the Shadowy Figure. Your clues:",en={288},l=25,n="Finding the Shadowy Figure",nx=268,ps={266},r=77,rl=20,sn={273},su=2161,x=1000}
T[454]={d="Speak with Miran.",en={1379},l=15,n="After the Ambush",nx=309,ps={273},r=77,rl=10,sn={2057},x=105}
T[455]={d="Traverse Dun Algaz.",en={2086},l=21,n="The Algaz Gauntlet",nx=473,ob={e={"Traverse Dun Algaz",{{1437,53.7,70.3}}},k={{2103},{2102}}},r=77,rl=19,sf=2,sn={1342},x=1250}
T[456]={d="Kill 7 Young Nightsabers and 4 Young Thistle Boars and return to Conservator Ilthalaine.",en={2079},l=2,n="The Balance of Nature",nx=457,ob={k={{2031},{1984}}},r=77,rl=1,sn={2079},x=170}
T[457]={d="Conservator Ilthalaine needs you to kill 7 Mangy Nightsabers and 7 Thistle Boars.",en={2079},l=3,n="The Balance of Nature",ob={k={{2032},{1985}}},ps={456},r=77,rl=1,sn={2079},x=250}
T[458]={d="Seek out the dryad known as Tarindrella.",en={1992},l=1,n="The Woodland Protector",nx=459,r=77,rl=1,sn={2077},x=40}
T[459]={d="Collect 8 Fel Moss and bring them to Tarindrella.",en={1992},l=3,n="The Woodland Protector",ob={i={{3297}}},ps={458},r=77,rl=1,sn={1992},x=250}
T[460]={d="Bring Alaric's Head to his grave.",eo={1599},l=17,n="Resting in Pieces",nx=461,r=178,rl=12,si={3317},su=3317,x=630}
T[461]={d="Take Alaric to the hidden alcove.",eo={112888},l=18,n="The Hidden Niche",nx=491,ps={460},r=178,rl=12,so={1599},su=3318,x=680}
T[463]={d="Find the Greenwarden.",en={1244},l=21,n="The Greenwarden",nx=276,r=77,rl=20,sn={1239},x=830}
T[464]={d="Bring 8 Dragonmaw War Banners to Captain Stoutfist.",en={2104},l=28,n="War Banners",nx=465,ob={i={{3337}}},r=77,rl=23,sn={2104},x=2300}
T[465]={d="Destroy the Dragonmaw catapults.",eo={1609},l=31,n="Nek'rosh's Gambit",nx=474,ps={464},r=77,rl=23,sn={2104},su=3339,x=1900}
T[466]={d="Bring 6 loads of Incendicite Ore to Pilot Stonegear in Dun Morogh.",en={1377},l=22,n="Search for Incendicite",ob={i={{3340}}},r=77,rl=20,sn={1377},x=1750}
T[467]={d="Speak with Pilot Stonegear.",en={1377},l=23,n="Stonegear's Search",nx=466,r=77,rl=20,sn={1340,2092},x=460}
T[468]={d="Speak with Mountaineer Rockgar.",en={1342},l=21,n="Report to Mountaineer Rockgar",nx=455,r=77,rl=19,sn={1340},x=165}
T[469]={d="Deliver the Bundle of Crocolisk Skins to James Halloran, the tanner, in Menethil Harbor.",en={2094},l=21,n="Daily Delivery",r=77,rl=18,sn={2093},su=3347,x=830}
T[470]={d="One of the oozes at Ironbeard's Tomb has Sida's bag, retrieve it and bring it back to her in Menethil Harbor.",en={2111},l=24,n="Digging Through the Ooze",ob={i={{3349}}},r=77,rl=19,sn={2111},x=2400}
T[471]={d="Collect 6 Giant Crocolisk Skins and bring them to James Halloran in Menethil Harbor.",en={2094},l=26,n="Apprentice's Duties",ob={i={{3348}}},ps={484},r=77,rl=18,sn={2094},x=2100}
T[472]={d="Search for Longbraid near the town of Dun Modr.",en={1071},l=25,n="Fall of Dun Modr",r=77,rl=25,sn={2097},x=1000}
T[473]={d="Speak with Captain Stoutfist.",en={2104},l=28,n="Report to Captain Stoutfist",nx=464,ps={455},r=77,rl=23,sn={2086},x=230}
T[474]={d="Kill Chieftain Nek'rosh",en={2104},l=32,n="Defeat Nek'rosh",ob={i={{3625}}},ps={465},r=77,rl=23,so={1609},tg=1,x=2550}
T[475]={d="Seek out Gaerolas Talvethren in Starbreeze Village.",en={2107},l=6,n="A Troubling Breeze",nx=476,r=77,rl=4,sn={2078},x=270}
T[476]={d="Return to Athridas Bearmantle in Dolanaar.",en={2078},l=6,n="Gnarlpine Corruption",nx=483,ps={475},r=77,rl=4,sn={2107},x=540}
T[477]={d="Retrieve the contents of one of the Dalaran wizards' crates. You will find Pyrewood Village to the south.",eo={1627},l=14,n="Border Crossings",nx=478,r=178,rl=10,sn={2121},x=980}
T[478]={d="Bring the strange pendant to Shadow Priest Allister at the Sepulcher.",en={2121},l=14,n="Maps and Runes",nx=481,ps={477},r=178,rl=10,so={1627},su=3353,x=740}
T[479]={d="Obtain 8 Dalaran Pendants for Shadow Priest Allister at the Sepulcher.",en={2121},l=16,n="Ambermill Investigations",nx=480,ob={i={{3354}}},ps={482},r=178,rl=10,sn={2121},x=1150}
T[480]={d="Kill the Dalaran archmage, then retrieve his staff for Shadow Priest Allister at the Sepulcher.",en={2121},l=22,n="The Weaver",ob={i={{3515}}},ps={479},r=178,rl=10,sn={2121},x=1750}
T[481]={d="Take the rune-inscribed pendant to Dalar Dawnweaver at the Sepulcher.",en={1938},l=14,n="Dalar's Analysis",nx=482,ps={478},r=178,rl=10,sn={2121},su=3353,x=100}
T[482]={d="Speak with Shadow Priest Allister at the Sepulcher.",en={2121},l=14,n="Dalaran's Intentions",nx=479,ps={481},r=178,rl=10,sn={1938},x=100}
T[483]={d="Retrieve the Relics of Wakening and bring them to Athridas Bearmantle in Dolanaar.",en={2078},l=9,n="The Relics of Wakening",nx=486,ob={i={{3405},{3406},{3407},{3408}}},ps={476},r=77,rl=4,sn={2078},x=780}
T[484]={d="Obtain 4 Young Crocolisk Skins for James Halloran in Menethil Harbor.",en={2094},l=22,n="Young Crocolisk Skins",nx=471,ob={i={{3397}}},r=77,rl=18,rp={72,0},sn={2094},x=1750}
T[485]={d="Take the distress beacon to Oglethorpe's homing robot at the head of the river in the Hinterlands, near Skulk Rock.",en={7806},l=48,n="Find OOX-09/HL!",nx=836,r=0,rl=43,si={8704},su=8704,x=4400}
T[486]={d="Kill Ursal the Mauler and return to Athridas Bearmantle in Dolanaar.",en={2078},l=12,n="Ursal the Mauler",ob={k={{2039}}},ps={483},r=77,rl=4,sn={2078},x=1150}
T[487]={d="Slay 6 Gnarlpine Ambushers and return to Sentinel Amara Nightwalker outside of Dolanaar.",en={2151},l=8,n="The Road to Darnassus",ob={k={{2152}}},r=77,rl=5,sn={2151},x=700}
T[488]={d="Bring Zenn Foulhoof outside of Dolanaar 3 Nightsaber Fangs, 3 Strigid Owl Feathers and 3 swatches of Webwood Spider Silk.",en={2150},l=5,n="Zenn's Bidding",nx=489,ob={i={{3409},{3411},{3412}}},r=77,rl=4,sn={2150},x=450}
T[489]={d="Collect 3 Fel Cones and give them to Zenn Foulhoof outside of Dolanaar.",en={2150},l=7,n="Seek Redemption!",ob={i={{3418}}},ps={488},r=77,rl=4,sn={2081,2083,2151,2155},x=630}
T[491]={d="Take the Woven Wand to Bethor Iceshard in the Magic Quarter of the Undercity.",en={1498},l=18,n="Wand to Bethor",ps={461},r=178,rl=12,so={112888},su=3425,x=1700}
T[492]={d="Bring Johaan's Special Drink to the Captured Mountaineer.",en={2211},l=11,n="A New Plague",ps={369},r=178,rl=6,sn={1518},su=3460,x=880}
T[493]={d="Deliver Apothecary Renferrel's findings to Apothecary Lydon in the town of Tarren Mill in the Hillsbrad Foothills.",en={2216},l=20,n="Journey to Hillsbrad Foothills",r=178,rl=19,sn={1937},su=3468,x=1150}
T[494]={d="Travel to Tarren Mill to deliver Deathstalker Lesh's message to High Executor Darthalia.",en={2215},l=20,n="Time To Strike",r=178,rl=19,sn={2214},x=780}
T[495]={d="Report to Melisara at Tarren Mill in the Hillsbrad Foothills.",en={2278},l=39,n="The Crown of Will",nx=518,r=178,rl=34,sn={2227},x=300}
T[496]={d="Apothecary Lydon of Tarren Mill wants 10 Gray Bear Tongues and some Creeper Ichor.",en={2216},l=22,n="Elixir of Suffering",nx=499,ob={i={{3476},{3477}}},r=178,rl=19,sn={2216},x=175}
T[498]={d="Krusk in Tarren Mill needs you to free Drull and Tog'thar from Durnholde Keep.",en={2229},l=22,n="The Rescue",nx=533,ob={o={{1721,"Rescue Drull"},{1722,"Rescue Tog'thar"}}},r=178,rl=17,rs={3467,3499},sn={2229},x=2200}
T[499]={d="Give Umpi the Elixir of Suffering.",en={2230},l=22,n="Elixir of Suffering",ps={496},r=178,rl=19,sn={2216},su=3495,x=1750}
T[500]={d="Gather 9 Dirty Knucklebones from Crushridge ogres in the Alterac Mountains. Bring them to Marshal Redpath in Southshore.",en={2263},l=36,n="Crushridge Bounty",nx=504,ob={i={{2843}}},r=77,rl=30,sn={2263},x=3500}
T[501]={d="Bring 10 vials of Mountain Lion Blood to Apothecary Lydon in Tarren Mill.",en={2216},l=24,n="Elixir of Pain",nx=502,ob={i={{3496}}},r=178,rl=21,sn={2216},x=1950}
T[502]={d="Feed the Elixir of Pain to Stanley.",en={2274},l=24,n="Elixir of Pain",ps={501},r=178,rl=21,sn={2216},su=3497,x=1450}
T[503]={d="Free Gol'dir then return to Krusk in Tarren Mill.",en={2316},l=36,n="Gol'dir",nx=506,ob={e={"Find where Gol'dir is being held",{{1416,60.6,43.7}}},i={{3704}},k={{2316}}},ps={533},r=178,rl=29,sf=2,sn={2229},x=2800}
T[504]={d="Slay 15 Crushridge Warmongers, then return to Marshal Redpath in Southshore.",en={2263},l=40,n="Crushridge Warmongers",ob={k={{2287}}},ps={500},r=77,rl=30,sn={2263},tg=1,x=4700}
T[505]={d="Kill 12 Syndicate Footpads and 8 Syndicate Thieves, then return to Magistrate Henry Maleb in Southshore.",en={2276},l=33,n="Syndicate Assassins",ob={k={{2240},{2241}}},r=77,rl=26,sn={2276},x=1950}
T[506]={d="Return the information gathered by Gol'dir to Krusk in Tarren Mill.",en={2229},l=36,n="Blackmoore's Legacy",nx=507,ps={503},r=178,rl=29,sn={2316},x=2100}
T[507]={d="Kill Lord Aliden Perenolde and ask his mistress, Elysa, about Taretha's pendant.",en={2317},l=42,n="Lord Aliden Perenolde",nx=508,ob={k={{2423}}},ps={506},r=178,rl=29,sn={2229},x=4300}
T[508]={d="Return Taretha's pendant to Krusk in Tarren Mill.",en={2229},l=40,n="Taretha's Gift",ps={507},r=178,rl=29,sn={2317},su=3498,x=3900}
T[509]={d="Bring 6 Mudsnout Blossoms to Apothecary Lydon in Tarren Mill.",en={2216},l=28,n="Elixir of Agony",nx=513,ob={i={{3502}}},r=178,rl=24,sn={2216},x=2300}
T[510]={d="Bring the Foreboding Plans to Magistrate Maleb in Southshore.",en={2276},l=34,n="Foreboding Plans",nx=512,r=77,rl=26,so={1738,1739,1740},su=3718,x=1350}
T[511]={d="Bring the Encrypted Letter to Loremaster Dibbs in Southshore.",en={2277},l=34,n="Encrypted Letter",nx=514,r=77,rl=30,so={1738,1739,1740},su=3521,x=1350}
T[512]={d="Bring 7 Alterac Signet Rings to Magistrate Maleb in Southshore.",en={2276},l=36,n="Noble Deaths",ob={i={{3505}}},ps={510},r=77,rl=26,sn={2276},x=2800}
T[513]={d="Take the Mudsnout Composite to Master Apothecary Faranell in the Undercity.",en={2055},l=28,n="Elixir of Agony",nx=515,ps={509},r=178,rl=24,sn={2216},su=3506,x=1150}
T[514]={d="Take the Cleverly Encrypted Letter to Prospector Stormpike in Ironforge.",en={1356},l=34,n="Letter to Stormpike",nx=525,ps={511},r=77,rl=30,sn={2277},su=3521,x=1350}
T[515]={d="Bring the Mudsnout Mixture, a Strong Troll's Blood Potion, 5 Daggerspine Scales and 5 Torn Fin Eyes to Apothecary Lydon in Tarren Mill.",en={2216},l=30,n="Elixir of Agony",nx=517,ob={i={{3388},{3509},{3510}}},ps={513},r=178,rl=24,sn={2055},su=3508,x=3050}
T[516]={d="Locate Beren's Peril, then kill 6 Ravenclaw Drudgers and 6 Ravenclaw Guardians, then return to Shadow Priest Allister at the Sepulcher.",en={2121},l=21,n="Beren's Peril",ob={k={{1974},{1973}}},r=178,rl=16,sn={2121},x=1250}
T[517]={d="Bring a keg of Shindigger Stout to Apothecary Lydon in Tarren Mill.",en={2216},l=30,n="Elixir of Agony",nx=524,ob={i={{3517}}},ps={515},r=178,rl=24,sn={2216},tg=1,x=1200}
T[518]={d="Kill 10 Crushridge Maulers for Melisara in Tarren Mill.",en={2278},l=39,n="The Crown of Will",nx=519,ob={k={{2254}}},r=178,rl=34,sn={2278},tg=1,x=2250}
T[519]={d="Kill Targ, Muckrake, and Glommus and bring their heads to Melisara in Tarren Mill.",en={2278},l=41,n="The Crown of Will",nx=520,ob={i={{3550},{3551},{3552}}},ps={518},r=178,rl=34,sn={2278},tg=1,x=3300}
T[520]={d="Kill Mug'Thol, and return his head with the Crown of Will to Melisara in Tarren Mill.",en={2278},l=43,n="The Crown of Will",nx=521,ob={i={{3553},{3554}}},ps={519},r=178,rl=34,sn={2278},tg=1,x=4450}
T[521]={d="Deliver the Crown of Will to Sharlindra in the Undercity.",en={2227},l=43,n="The Crown of Will",ps={520},r=178,rl=34,sn={2278},su=3554,x=3600}
T[522]={d="Bring the Assassin's Contract to Magistrate Maleb in Southshore.",en={2276},l=38,n="Assassin's Contract",nx=523,r=77,rl=30,si={3668},su=3668,x=710}
T[523]={d="Bring the Head of Baron Vardus to Magistrate Maleb in Southshore.",en={2276},l=40,n="Baron's Demise",ob={i={{3626}}},ps={522},r=77,rl=30,sn={2276},x=3900}
T[524]={d="Place the Tainted Keg on the rug for the captured farmers.",eo={1728},l=30,n="Elixir of Agony",ps={517},r=178,rl=24,sn={2216},su=3520,x=3650}
T[525]={d="Bring the Decrypted Letter to Magistrate Maleb in Southshore.",en={2276},l=34,n="Further Mysteries",nx=537,ps={514},r=77,rl=30,sn={1356},su=3518,x=1350}
T[526]={d="Gather 5 lightforge ingots, then return to Glorin Steelbrow in the Wetlands.",en={1217},ex={322,324},l=29,n="Lightforge Ingots",nx=322,ob={i={{2702}}},ps={324},r=77,rl=20,sn={1217},x=1750}
T[527]={d="Kill 6 Hillsbrad Farmhands, 6 Hillsbrad Farmers, Farmer Ray and Farmer Getz and report back to Darthalia in Tarren Mill.",en={2215},l=24,n="Battle of Hillsbrad",nx=528,ob={k={{2266},{2360},{232},{2403}}},r=178,rl=19,sn={2215},x=1950}
T[528]={d="Kill 15 Hillsbrad Peasants and report back to Darthalia in Tarren Mill.",en={2215},l=25,n="Battle of Hillsbrad",nx=529,ob={k={{2267}}},ps={527},r=178,rl=19,sn={2215},x=2000}
T[529]={d="Kill Blacksmith Verringtan and 4 Hillsbrad Apprentice Blacksmiths.",en={2215},l=26,n="Battle of Hillsbrad",nx=532,ob={i={{3564}},k={{2404},{2265}}},ps={528},r=178,rl=19,sn={2215},x=2100}
T[530]={d="Kill Valdred Moray.",en={2050},l=20,n="A Husband's Revenge",ob={i={{3613}}},ps={441},r=178,rl=10,sn={2050},x=1550}
T[531]={d="Bring Ol' Sooty's head to Vyrin Swiftwind at the Farstrider Lodge.",en={1156},l=20,n="Vyrin's Revenge",ps={271},r=77,rl=15,sn={1187},su=2713,tg=1,x=1550}
T[532]={d="Kill Magistrate Burnside and 5 Hillsbrad Councilmen. Destroy the Hillsbrad Proclamation. Steal the Hillsbrad Town Registry. Report back to Darthalia in Tarren Mill afterwards.",en={2215},l=26,n="Battle of Hillsbrad",nx=539,ob={i={{3657}},k={{2335},{2387}},o={{1761,"Hillsbrad Proclamation destroyed"}}},ps={529},r=178,rl=19,sn={2215},x=2100}
T[533]={d="Retrieve information about Gol'dir's whereabouts for Krusk in Tarren Mill.",en={2229},l=34,n="Infiltration",nx=503,ob={i={{3601}}},ps={498},r=178,rl=29,sn={2229},x=2700}
T[535]={d="Bring a mug of Southshore Stout to Valik in the Syndicate camp.",en={2333},l=34,n="Valik",ob={i={{3703}}},pa=533,r=178,rl=29,sn={2333},x=270}
T[536]={d="Kill 10 Torn Fin Tidehunters and 10 Torn Fin Oracles for Lieutenant Farren Orinelle in Southshore.",en={2228},l=30,n="Down the Coast",nx=559,ob={k={{2377},{2376}}},r=77,rl=25,sn={2228},x=1850}
T[537]={d="Kill 4 Argus Shadow Mages.",en={2276},l=40,n="Dark Council",ob={i={{3672}},k={{2318}}},ps={525},r=77,rl=30,sn={2276},x=3150}
T[538]={d="Speak with Loremaster Dibbs in Southshore.",en={2277},l=38,n="Southshore",nx=540,ps={337},r=77,rl=20,sn={1440},x=710}
T[539]={d="Kill Foreman Bonds and 10 Hillsbrad Miners and report back to Darthalia in Tarren Mill.",en={2215},l=28,n="Battle of Hillsbrad",nx=541,ob={k={{2305},{2269}}},ps={532},r=178,rl=19,sn={2215},x=2300}
T[540]={d="Bring 5 Recovered Tomes and the Worn Leather Book containing The Arm of Gri'lek to Loremaster Dibbs in Southshore.",en={2277},l=38,n="Preserving Knowledge",nx=542,ob={i={{3658},{3659}}},ps={538},r=77,rl=20,sn={2277},tg=1,x=3550}
T[541]={d="Travel to Dun Garok and kill 8 Mountaineers, 4 Riflemen, 2 Priests and Captain Ironhill and report back to Darthalia in Tarren Mill.",en={2215},l=30,n="Battle of Hillsbrad",nx=550,ob={k={{2344},{2345},{2346},{2304}}},ps={539},r=178,rl=19,sn={2215},tg=1,x=2450}
T[542]={d="Bring the Tomes of Alterac to Milton Sheaf in Stormwind.",en={1440},l=38,n="Return to Milton",ps={540},r=77,rl=20,sn={2277},su=3660,x=3550}
T[543]={d="Bring the Perenolde Tiara to Remington Ridgewell in Stormwind.",en={2285},l=40,n="The Perenolde Tiara",ob={i={{3684}}},r=77,rl=30,sn={2285},tg=1,x=4700}
T[544]={d="Find the traitors and recover their artifacts, then return to Magus Voidglare in Tarren Mill.",en={2410},l=34,n="Prison Break In",nx=545,ob={i={{3691},{3689},{3690},{3688}}},r=178,rl=30,sn={2410},x=3350}
T[545]={d="Kill 6 Dalaran Summoners and 12 Elemental Slaves, then return to Magus Voidglare in Tarren Mill.",en={2410},l=35,n="Dalaran Patrols",ob={k={{2358},{2359}}},ps={544},r=178,rl=30,sn={2410},x=2050}
T[546]={d="Deathguard Samsa of Tarren Mill wants 30 Hillsbrad Human Skulls.",en={2418},l=25,n="Souvenirs of Death",ob={i={{3692}}},ps={527},r=178,rl=20,sn={2418},x=2550}
T[547]={d="Retrieve Deathguard Humbert's sword from Dun Garok and return it to him in Tarren Mill.",en={2419},l=30,n="Humbert's Sword",ob={i={{3693}}},r=178,rl=26,sn={2419},tg=1,x=3050}
T[549]={d="Kill 10 Syndicate Rogues and 10 Syndicate Watchmen. Return to High Executor Darthalia in Tarren Mill for your reward.",en={2215},l=22,n="WANTED: Syndicate Personnel",nx=566,ob={k={{2260},{2261}}},r=178,rl=17,so={1763},x=1750}
T[550]={d="Take Darthalia's Sealed Commendation to Varimathras in the Undercity.",en={2425},l=32,n="Battle of Hillsbrad",ps={541},r=178,rl=19,sn={2215},su=3701,x=2550}
T[551]={d="Take the Ensorcelled Parchment to Loremaster Dibbs in Southshore.",en={2277},l=40,n="The Ensorcelled Parchment",nx=554,r=77,rl=30,si={3706},su=3706,x=780}
T[552]={d="Retrieve Helcular's Rod from the Yeti and bring it back to Novice Thaivand in Tarren Mill.",en={2429},l=33,n="Helcular's Revenge",nx=553,ob={i={{3708}}},r=178,rl=29,sn={2429},x=2650}
T[553]={d="Charge the Rod of Helcular with the powers of the Flame of Azel, Flame of Veraz and the Flame of Uzel.",eo={1767},l=33,n="Helcular's Revenge",ob={o={{1768,"Flame of Azel charged"},{1769,"Flame of Veraz charged"},{1770,"Flame of Uzel charged"}}},ps={552},r=178,rl=29,sn={2429},su=3710,x=3300}
T[554]={d="Take the Ensorcelled Parchment to Prospector Stormpike in Ironforge.",en={1356},l=40,n="Stormpike's Deciphering",ps={551},r=77,rl=28,sn={2277},su=3706,x=1550}
T[555]={d="Bring 10 pieces of Turtle Meat and some Soothing Spices to Chef Jessen in Southshore.",en={2430},l=31,n="Soothing Turtle Bisque",ob={i={{3712},{3713}}},r=77,rl=28,sn={2430},x=2500}
T[556]={d="Bring 10 Worn Stone Tokens to Keeper Bel'varil in Tarren Mill.",en={2437},l=32,n="Stone Tokens",nx=557,ob={i={{3714}}},r=178,rl=30,sn={2437},x=2550}
T[557]={d="Bring 4 Bracers of Earth Binding to Keeper Bel'varil in Tarren Mill.",en={2437},l=34,n="Bracers of Binding",ob={i={{3715}}},ps={556},r=178,rl=30,sn={2437},x=2700}
T[559]={d="Collect 10 Murloc Heads from the murlocs on the Western Strand for Lieutenant Farren Orinelle in Southshore.",en={2228},l=32,n="Farren's Proof",nx=560,ob={i={{3716}}},ps={536},r=77,rl=25,sn={2228},x=2550}
T[560]={d="Deliver the sack of murloc heads to Marshall Redpath in Southshore.",en={2263},l=32,n="Farren's Proof",nx=561,ps={559},r=77,rl=25,sn={2228},su=3717,x=255}
T[561]={d="Speak with Lieutenant Farren Orinelle in Southshore.",en={2228},l=32,n="Farren's Proof",nx=562,ps={560},r=77,rl=25,sn={2263},x=255}
T[562]={d="Kill 10 Daggerspine Shorehunters and 10 Daggerspine Sirens for Lieutenant Farren Orinelle in Southshore.",en={2228},l=32,n="Stormwind Ho!",nx=563,ob={k={{2369},{2371}}},ps={561},r=77,rl=25,sn={2228},x=1950}
T[563]={d="Deliver Farren's report to Major Samuelson in Stormwind Keep.",en={2439},l=32,n="Reassignment",ps={562},r=77,rl=25,sn={2228},su=3721,x=3200}
T[564]={d="Darren Malvew of Southshore wants you to kill 8 Mountain Lions and 10 Hulking Mountain Lions.",en={2382},l=34,n="Costly Menace",ob={k={{2406},{2407}}},r=77,rl=30,sn={2382},x=2700}
T[565]={d="Bring Bartolo Ginsetti of Southshore a Bolt of Wool, a Hillman's Cloak, Fine Thread and 10 clumps of Yeti Fur.",en={2438},l=34,n="Bartolo's Yeti Fur Cloak",ob={i={{2997},{2321},{3719},{3720}}},r=77,rl=29,sn={2438},x=2700}
T[566]={d="Kill Baron Vardus and deliver his head to High Executor Darthalia in Tarren Mill.",en={2215},l=40,n="WANTED: Baron Vardus",ob={i={{3626}}},ps={549},r=178,rl=35,so={1763},x=3150}
T[567]={d="High Executor Darthalia of Tarren Mill is offering a bounty on Clerk Horrace Whitesteed, Citizen Wilkes, Miner Hackett and Farmer Kalaba.",en={2215},l=28,n="Dangerous!",ob={k={{2448},{2449},{2450},{2451}}},r=178,rl=19,so={2008},x=2300}
T[568]={d="Commander Aggro'gosh of the Grom'gol base camp wants you to kill 15 Lashtail Raptors.",en={2464},l=36,n="The Defense of Grom'gol",nx=569,ob={k={{686}}},r=178,rl=33,sn={2464},x=2800}
T[569]={d="Commander Aggro'gosh of the Grom'gol base camp wants you to kill 10 Ogre Brutes and 5 Ogre Witch Doctors.",en={2464},l=37,n="The Defense of Grom'gol",ob={k={{1142},{1144}}},ps={568},r=178,rl=33,sn={2464},x=2850}
T[570]={d="Far Seer Mok'thardin at the Grom'gol base camp wants 8 Shadowmaw Claws and a Pristine Tigress Fang.",en={2465},l=38,n="Mok'thardin's Enchantment",nx=572,ob={i={{3838},{3839}}},r=178,rl=33,sn={2465},x=2150}
T[571]={d="Bring an Aged Gorilla Sinew to Far Seer Mok'thardin in Grom'gol.",en={2465},l=41,n="Mok'thardin's Enchantment",nx=573,ob={i={{3862}}},ps={572},r=178,rl=33,sn={2465},x=2450}
T[572]={d="Bring 10 Jungle Stalker Feathers to Far Seer Mok'thardin at the Grom'gol base camp.",en={2465},l=41,n="Mok'thardin's Enchantment",nx=571,ob={i={{3863}}},ps={570},r=178,rl=33,sn={2465},x=2450}
T[573]={d="Far Seer Mok'thardin of Grom'gol needs Holy Spring Water. He also wants you to kill 10 Naga Explorers.",en={2465},l=44,n="Mok'thardin's Enchantment",ob={i={{737}},k={{1907}}},ps={571},r=178,rl=33,sn={2465},x=4650}
T[574]={d="Kill 10 Kurzen Commandoes and 6 Kurzen Headshrinkers.",en={469},l=38,n="Special Forces",nx=202,ob={k={{938},{941}}},pg={203,204},r=77,rl=30,sn={733},x=2850}
T[575]={d="Bring 2 Large River Crocolisk Skins to Drizzlik in Booty Bay.",en={2495},l=31,n="Supply and Demand",nx=577,ob={i={{4053}}},r=0,rl=26,sn={2495},x=1250}
T[576]={d="Dizzy One-Eye in Booty Bay wants you to retrieve his eye from the Bloodsail Buccaneers.",en={2493},l=42,n="Keep An Eye Out",ob={i={{3897}}},ps={597},r=0,rl=37,sn={2493},x=2550}
T[577]={d="Bring 5 Snapjaw Crocolisks Skins to Drizzlik in Booty Bay.",en={2495},l=36,n="Some Assembly Required",nx=628,ob={i={{4104}}},ps={575},r=0,rl=31,sn={2495},x=1400}
T[578]={d="Find the haunted island for Baron Revilgaz in Booty Bay.",en={2496},l=37,n="The Stone of the Tides",nx=601,ob={e={"Locate the haunted island",{{1434,20.8,23.2}}}},ps={616},r=77,rl=32,sf=2,sn={2496},su=3898,x=2850}
T[579]={en={2504},l=1,n="Stormwind Library",ob={i={{3898}}},r=77,rl=1,sf=1,sn={2504}}
T[580]={d="Whiskey Slim in Booty Bay wants you to bring him the bottles of Pupellyverbos Port he lost.",en={2491},l=50,n="Whiskey Slim's Lost Grog",ob={i={{3900}}},r=0,rl=40,sn={2491},x=4700}
T[581]={d="Bring 9 Bloodscalp Tusks to Nimboya at the Grom'gol Base Camp.",en={2497},l=34,n="Hunt for Yenniku",nx=582,ob={i={{3901}}},r=178,rl=30,sn={2497},x=2000}
T[582]={d="Bring 20 Shrunken Heads to Nimboya at the Grom'gol Base Camp.",en={2497},l=37,n="Headhunting",nx=584,ob={i={{1532}}},ps={581},r=178,rl=30,sn={2497},x=2100}
T[583]={d="Speak with Hemet Nesingwary",en={715},l=30,n="Welcome to the Jungle",r=0,rl=28,sn={716},x=245}
T[584]={d="Bring Gan'zulah's Head and Nezzliok's Head to the bubbling cauldron at the Grom'gol Base Camp.",eo={2076},l=41,n="Bloodscalp Clan Heads",ob={i={{3904},{3905}}},ps={582},r=178,rl=30,sn={2497},x=3300}
T[585]={d="Bring a Balia'mah Trophy, a Ziata'jai Trophy and a Zul'Mamwe Trophy to the Bubbling Cauldron at the Grom'gol Base Camp.",eo={2076},l=40,n="Speaking with Nezzliok",ob={i={{3906},{3907},{3908}}},ps={584},r=178,rl=30,so={2076},x=2350}
T[586]={d="Kill 8 Skullsplitter Hunters, 6 Skullsplitter Headhunters, and 4 Skullsplitter Berserkers.",eo={2076},l=46,n="Speaking with Gan'zulah",ob={i={{3909}},k={{669},{781},{783}}},ps={584},r=178,rl=30,so={2076},x=4050}
T[587]={d="Deeg in Booty Bay wants you to bring him 15 shares of Snuff.",en={2488},l=41,n="Up to Snuff",ob={i={{3910}}},ps={597},r=0,rl=37,sn={2488},x=1650}
T[588]={d="Speak with Kin'weelay.",en={2519},l=45,n="The Fate of Yenniku",nx=589,pg={585,586},r=178,rl=30,so={2076},x=390}
T[589]={d="Bring 3 Pulsing Blue Shards to Kin'weelay at the Grom'gol Base Camp.",en={2519},l=45,n="The Singing Crystals",nx=591,ob={i={{3911}}},ps={588},r=178,rl=30,sn={2519},x=3900}
T[590]={d="Defeat Calvin Montague in Deathknell.",en={6784},l=5,n="A Rogue's Deal",ob={e={"Defeat Calvin Montague",{{1420,38.2,56.7}}}},ps={8},r=178,rl=1,sf=2,sn={6784},x=110}
T[591]={d="Bring the Mind's Eye to Kin'weelay at the Grom'gol Base Camp.",en={2519},l=46,n="The Mind's Eye",nx=592,ob={i={{3616}}},ps={589},r=178,rl=30,sn={2519},tg=1,x=5050}
T[592]={d="Bring the Filled Soul Gem to Nimboya.",en={2497},l=46,n="Saving Yenniku",ob={i={{3913}}},ps={591},r=178,rl=30,sn={2519},su=3912,x=5050}
T[593]={en={2530},l=46,n="Filling the Soul Gem",ob={i={{3912}}},pa=592,r=178,rl=1,sf=1,sn={2530}}
T[594]={d="Find the author of the message in a bottle.",en={2634},l=45,n="Message in a Bottle",nx=630,r=0,rl=45,si={4098},x=2900}
T[595]={d="First Mate Crazz wants you to check the cove north of Booty Bay.",eo={2083},l=41,n="The Bloodsail Buccaneers",nx=597,r=0,rl=37,sn={2490},x=2450}
T[596]={d="Bring 25 Bloody Bone Necklaces to Kin'weelay at the Grom'gol Base Camp.",en={2519},l=37,n="Bloody Bone Necklaces",ob={i={{3915}}},r=178,rl=30,sn={2519},x=2100}
T[597]={d="Report your findings to First Mate Crazz in Booty Bay.",en={2490},l=41,n="The Bloodsail Buccaneers",nx=599,ps={595},r=0,rl=37,so={2083},x=2450}
T[598]={d="Bring 25 Split Bone Necklaces to Kin'weelay at the Grom'gol Base camp.",en={2519},l=42,n="Split Bone Necklace",ob={i={{3916}}},pg={596,629},r=178,rl=30,sn={2519},x=3450}
T[599]={d="Report the planned Bloodsail attack to Fleet Master Seahorn.",en={2487},l=41,n="The Bloodsail Buccaneers",nx=604,ps={597},r=0,rl=37,sn={2490},x=820}
T[600]={d="Bring 10 Singing Blue Crystals to Crank Fizzlebub in Booty Bay.",en={2498},l=41,n="Venture Company Mining",ob={i={{3917}}},ps={605},r=0,rl=30,sn={2498},x=3300}
T[601]={d="Acquire 6 Water Elemental Bracers for Baron Revilgaz in Booty Bay.",en={2496},l=37,n="Water Elementals",nx=602,ob={i={{3923}}},ps={578},r=77,rl=32,sn={2496},x=2850}
T[602]={d="Bring the water elemental bracers to Archmage Ansirem Runeweaver in Dalaran.",en={2543},l=37,n="Magical Analysis",nx=603,ps={601},r=77,rl=32,sn={2496},su=3960,x=1400}
T[603]={d="Talk to Catelyn in Booty Bay.",en={2542},l=37,n="Ansirem's Key",nx=610,ps={602},r=77,rl=32,sn={2543},x=1400}
T[604]={d="Fleet Master Seahorn in Booty Bay wants you to kill 10 Bloodsail Swashbucklers and bring back the Bloodsail Charts and the Bloodsail Orders.",en={2487},l=43,n="The Bloodsail Buccaneers",nx=608,ob={i={{3920},{3921}},k={{1563}}},ps={599},r=0,rl=37,sn={2487},x=3600}
T[605]={d="Bring 10 Singing Crystal Shards to Crank Fizzlebub.",en={2498},l=35,n="Singing Blue Shards",nx=600,ob={i={{3918}}},r=0,rl=30,sn={2498},x=2750}
T[606]={d="Bring 5 Mistvale Giblets to \"Shaky\" Phillipe in Booty Bay.",en={2502},l=41,n="Scaring Shaky",nx=607,ob={i={{3919}}},r=0,rl=30,sn={2501},x=820}
T[607]={d="Bring Shaky's Payment to \"Sea Wolf\" MacKinley.",en={2501},l=41,n="Return to MacKinley",nx=609,ps={606},r=0,rl=30,sn={2502},su=3922,x=2450}
T[608]={d="Fleet-Master Seahorn in Booty Bay wants you to kill Captain Stillwater, Captain Keelhaul and Fleet Master Firallon.",en={2487},l=45,n="The Bloodsail Buccaneers",ob={k={{2550},{2548},{2546}}},ps={604},r=0,rl=37,sn={2487},x=4850}
T[609]={d="Bring Maury's Clubbed Foot, Jon-Jon's Golden Spyglass, and Chucky's Huge Ring to \"Sea Wolf\" MacKinley in Booty Bay.",en={2501},l=44,n="Voodoo Dues",nx=613,ob={i={{3924},{3925},{3926}}},ps={607},r=0,rl=30,sn={2501},x=3750}
T[610]={d="Get Catelyn's dagger from \"Pretty Boy\" Duncan.",en={2542},l=39,n="\"Pretty Boy\" Duncan",nx=611,ob={i={{4027}}},ps={603},r=77,rl=32,sn={2542},x=2250}
T[611]={d="Destroy the Altar of the Tides with Catelyn's Blade, kill Gazban and bring the Stone of the Tides and Catelyn's Blade back to Baron Revilgaz.",en={2496},l=40,n="The Curse of the Tides",ob={i={{4034}}},ps={610},r=77,rl=32,sn={2542},su=4027,tg=1,x=3150}
T[613]={d="Bring Maury's Key to \"Sea Wolf\" Mackinley in Booty Bay.",en={2501},l=44,n="Cracking Maury's Foot",ob={i={{3930}}},ps={609},r=0,rl=30,sn={2501},tg=1,x=4650}
T[616]={d="Speak with Baron Revilgaz in Booty Bay.",en={2496},l=37,n="The Haunted Isle",nx=578,r=77,rl=32,sn={773},x=285}
T[617]={d="Bring 10 Bundles of Akiris Reed to Privateer Bloads in Booty Bay.",en={2494},l=43,n="Akiris by the Bundle",nx=623,ob={i={{4029}}},r=0,rl=38,sn={2494},x=3600}
T[619]={eo={2289},l=52,n="Enticing Negolash",ob={i={{4457},{4595}}},pa=8554,r=0,rl=35,sf=1,so={2289}}
T[621]={d="Bring 12 samples of Zanzil's Mixture to Crank Fizzlebub in Booty Bay.",en={2498},l=44,n="Zanzil's Secret",ob={i={{4016}}},r=0,rl=35,sn={2498},x=3750}
T[622]={d="Bring Krazek's Fixed Pot to Corporal Kaleb at the Rebel Camp.",en={770},l=37,n="Return to Corporal Kaleb",ps={627},r=77,rl=32,sn={773},su=1987,x=2850}
T[623]={d="Bring a Bundle of Akiris Reeds to Privateer Groy in Theramore.",en={2616},l=43,n="Akiris by the Bundle",ps={617},r=77,rl=38,sn={2494},su=4028,x=2700}
T[624]={d="Solve the riddle!",eo={2553},l=43,n="Cortello's Riddle",nx=625,r=0,rl=35,si={4056},x=3600}
T[625]={d="Solve the riddle!",eo={2555},l=43,n="Cortello's Riddle",nx=626,ps={624},r=0,rl=35,so={2553},x=3600}
T[626]={d="Solve the riddle!",eo={2556},l=51,n="Cortello's Riddle",ps={625},r=0,rl=35,so={2555},x=6100}
T[627]={d="Bring 4 loads of Lesser Bloodstone Ore to Krazek in Booty Bay.",en={773},l=37,n="Favor for Krazek",nx=622,ob={i={{4278}}},ps={210},r=77,rl=32,sn={773},x=2100}
T[628]={d="Bring an Elder Crocolisk Skin to Drizzlik in Booty Bay.",en={2495},l=38,n="Excelsior",ob={i={{4105}}},ps={577},r=0,rl=31,sn={2495},tg=1,x=2850}
T[629]={d="Bring a Tablet Shard to Kin'weelay at the Grom'gol Base Camp.",en={2519},l=37,n="The Vile Reef",ob={i={{4094}}},r=178,rl=30,sn={2519},tg=1,x=2850}
T[630]={d="Slay King Mukla and return to Princess Poobah with the Key to free her.",en={2634},l=51,n="Message in a Bottle",ob={i={{4103}}},ps={594},r=0,rl=45,sn={2634},tg=1,x=7350}
T[631]={d="Rhag Garmason wants you to locate Ol' Rustlocke.",eo={2652},l=31,n="The Thandol Span",nx=632,r=77,rl=28,sn={1075},tg=1,x=2500}
T[632]={d="Report back to Rhag Garmason and show him the parchment you found on Rustlocke's corpse.",en={1075},l=31,n="The Thandol Span",nx=633,ps={631},r=77,rl=28,so={2652},su=4429,x=2500}
T[633]={d="Destroy the cache of explosives.",en={1075},l=31,n="The Thandol Span",nx=634,ob={o={{2704,"Cache of Explosives Destroyed"}}},ps={632},r=77,rl=28,sn={1075},x=2500}
T[634]={d="Seek out Captain Nials at Refuge Pointe.",en={2700},l=31,n="Plea To The Alliance",ps={633},r=77,rl=28,sn={1075},x=1250}
T[635]={d="Find the crystal from your vision.",eo={138492},l=35,n="Crystal in the Mountains",r=0,rl=30,si={4614},su=4614,x=275}
T[637]={d="Deliver Sully Balloo's Letter to Sara Balloo.",en={2695},l=30,n="Sully Balloo's Letter",nx=683,r=77,rl=25,si={4433},su=4432,x=2450}
T[638]={d="Travel to Hammerfall in the Arathi Highlands and speak with Zengu.",en={2703},l=37,n="Trollbane",nx=639,r=178,rl=32,sn={2497},x=710}
T[639]={d="Get the Sigil of Strom for Zengu in Hammerfall.",en={2703},l=37,n="Sigil of Strom",nx=640,ob={i={{4440}}},r=178,rl=32,sn={2703},tg=1,x=2850}
T[640]={d="Retrieve the 11 Sigil Fragments from the defenders in Stromgarde, and bring them to Tor'gan in Hammerfall.",en={2706},l=40,n="The Broken Sigil",nx=641,ob={i={{4450}}},ps={639},r=178,rl=32,sn={2703},tg=1,x=3150}
T[641]={d="Bring the restored Sigil of Thoradin to Zengu in Hammerfall.",en={2703},l=40,n="Sigil of Thoradin",nx=643,ps={640},r=178,rl=32,sn={2706},su=4453,x=315}
T[642]={d="Gather 12 Motes of Myzrael, then bring them to the Iridescent Shards in Drywhisker Gorge.",eo={2701},l=37,n="The Princess Trapped",nx=651,ob={i={{4435}}},r=0,rl=30,so={138492},x=2850}
T[643]={d="Retrieve the Sigil of Arathor and return it to Zengu in Hammerfall.",en={2703},l=41,n="Sigil of Arathor",nx=644,ob={i={{4458}}},ps={641},r=178,rl=32,sn={2703},tg=1,x=3300}
T[644]={d="Kill Prince Galen Trollbane and bring the Sigil of Trollbane to Zengu in Hammerfall.",en={2703},l=42,n="Sigil of Trollbane",nx=645,ob={i={{4466}}},ps={643},r=178,rl=32,sn={2703},tg=1,x=3450}
T[645]={d="Retrieve Trol'kalar from Trollbane's tomb in Stromgarde.",eo={2703},l=42,n="Trol'kalar",nx=646,ps={644},r=178,rl=32,sn={2703},su=4467,tg=1,x=860}
T[646]={d="Deliver Trol'kalar to Zengu in Hammerfall.",en={2703},l=42,n="Trol'kalar",ps={645},r=178,rl=32,so={2703},su=4468,tg=1,x=4300}
T[647]={d="Take MacKreel's Moonshine to Brewmeister Bilger in Southshore.",en={2705},l=30,n="MacKreel's Moonshine",r=77,rl=28,sn={2696},su=4441,x=3050}
T[648]={d="Escort OOX-17/TN to Steamwheedle Port, then report to Oglethorpe Obnoticus in Booty Bay.",en={7406},es=1,l=48,n="Rescue OOX-17/TN!",ob={e={"Escort OOX-17/TN to Steamwheedle Port",{{1446,67.1,23.2}}}},ps={351},r=0,rl=43,sf=2,sn={7784},x=5450}
T[649]={d="Talk to Malton Droffers in Orgrimmar.",en={6987},l=48,n="Ripple Recovery",nx=650,r=178,rl=42,sn={6986},x=440}
T[650]={d="Talk to Gilveradin Sunchaser; his camp is located in the Hinterlands.",en={7801},l=48,n="Ripple Recovery",nx=77,ps={649},r=178,rl=42,sn={6987},x=4400}
T[651]={d="Gather the Burning Key, the Cresting Key and the Thundering Key from the Stone of West Binding, the Stone of East Binding and the Stone of Outer Binding.",eo={2702},l=38,n="Stones of Binding",nx=652,ob={i={{4483},{4484},{4485}}},ps={642},r=0,rl=30,so={2701},x=2850}
T[652]={d="Find and kill Fozruk. Bring the Rod of Order to the Keystone in the Arathi Highlands.",eo={2688},l=42,n="Breaking the Keystone",nx=653,ob={i={{4469}}},ps={651},r=0,rl=30,so={2702},tg=1,x=3450}
T[653]={d="Speak with Gerrig Bonegrip in the Forlorn Cavern of Ironforge.",en={2786},l=40,n="Myzrael's Allies",nx=687,ps={652},r=77,rl=30,so={2688},x=2350}
T[654]={d="Acquire acceptable samples for 8 basilisks, 8 hyenas, and 8 scorpions. Bring the testing kit back to Chief Engineer Bilgewhizzle in Gadgetzan before the power source runs out.",en={7407},l=46,n="Tanaris Field Sampling",nx=864,ob={i={{9440},{9441},{9438},{8523}}},ps={379},r=178,rl=38,rs={9437,9439,9442},si={8524},x=4050}
T[655]={d="Speak with Tor'gan in Hammerfall.",en={2706},l=34,n="Hammerfall",nx=672,r=178,rl=29,sn={2792},x=270}
T[656]={d="Go to the Shards of Myzrael, summon her and defeat her.",eo={138492},l=50,n="Summoning the Princess",ob={i={{4473}}},ps={692},r=0,rl=30,sn={2785},su=4472,tg=1,x=7100}
T[657]={d="Speak to Kinelory.",en={2713},l=36,n="Hints of a New Plague?",nx=660,ps={658},r=77,rl=30,sn={2712}}
T[658]={d="Find the Forsaken Courier and bring back her Sealed Folder to Quae near the Go'Shek Farm.",en={2712},l=36,n="Hints of a New Plague?",nx=657,ob={i={{4482}}},ps={659},r=77,rl=30,sn={2712},x=2800}
T[659]={d="Find Quae and Kinelory near the Go'Shek Farm in the Arathi Highlands.",en={2712},l=33,n="Hints of a New Plague?",nx=658,r=77,rl=30,sn={2711},x=1300}
T[660]={d="Protect Kinelory until she returns to Quae.",en={2712},l=37,n="Hints of a New Plague?",nx=661,ob={e={"Protect Kinelory",{{1417,60.1,53.8}}}},ps={657},r=77,rl=30,sf=2,sn={2713},x=2850}
T[661]={d="Find Phin Odelic in Southshore.",en={2711},l=37,n="Hints of a New Plague?",ps={660},r=77,rl=30,sn={2712},x=3550}
T[662]={d="First Mate Nilzlix wants you to retrieve the Charts and Logs from the Maiden's Folly and the Spirit of Silverpine.",en={2767},l=40,n="Deep Sea Salvage",ob={i={{4487},{4489},{4488},{4490}}},ps={663},r=0,rl=35,sn={2767},x=3150}
T[663]={d="Talk to Captain O'Breen in Faldir's Cove.",en={2610},l=35,n="Land Ho!",r=0,rl=35,sn={2766},x=690}
T[664]={d="Captain Steelgut in Faldir's Cove wants you to kill 10 Daggerspine Raiders and 3 Daggerspine Sorceresses.",en={2769},l=40,n="Drowned Sorrows",ob={k={{2595},{2596}}},ps={663},r=0,rl=35,sn={2769},x=3150}
T[665]={d="Escort Professor Phizzlethorpe to the cave and back.",en={2774},es=1,l=40,n="Sunken Treasure",nx=666,ob={e={"Defend Professor Phizzlethorpe",{{1417,33.9,80.6}}}},ps={663},r=0,rl=35,sf=2,sn={2768},x=3150}
T[666]={d="Doctor Draxlegauge in Faldir's Cove wants you to collect 10 Elven Gems and return the Goggles of Gem Hunting once you are done.",en={2774},l=40,n="Sunken Treasure",nx=668,ob={i={{4492}}},ps={665},r=0,rl=35,sn={2774},su=4491,x=3900}
T[667]={d="Protect Shakes O'Breen during the attack.",en={2610},l=44,n="Death From Below",ob={e={"Defend Shakes O'Breen",{{1417,31.9,81.8}}}},ps={670},r=0,rl=35,sf=2,sn={2610},x=4650}
T[668]={d="Take the Elven Gems to Captain O'Breen.",en={2610},l=40,n="Sunken Treasure",nx=669,ps={666},r=0,rl=35,sn={2774},su=4493,x=1550}
T[669]={d="Take the Sample Elven Gem to Fleet Master Seahorn in Booty Bay.",en={2487},l=40,n="Sunken Treasure",nx=670,ps={668},r=0,rl=35,sn={2610},su=4502,x=3150}
T[670]={d="Deliver Seahorn's Letter to Shakes O'Breen in Arathi Highlands.",en={2610},l=40,n="Sunken Treasure",nx=667,ps={669},r=0,rl=35,sn={2487},su=4494,x=3150}
T[671]={d="Get 10 Bloodstone Amulets for Tor'gan in Hammerfall.",en={2706},l=33,n="Foul Magics",nx=673,ob={i={{4495}}},r=178,rl=30,sn={2706},x=2650}
T[672]={d="Acquire 10 Highland Raptor Eyes from Highland Striders and Highland Thrashers for Tor'gan in Hammerfall.",en={2706},l=34,n="Raising Spirits",nx=674,ob={i={{4512}}},ps={655},r=178,rl=29,sn={2706},x=2700}
T[673]={d="Retrieve Marez Cowl's Bloodstone Orb and bring it to Tor'gan in Hammerfall.",en={2706},l=40,n="Foul Magics",ob={i={{4510}}},ps={671},r=178,rl=35,sn={2706},tg=1,x=3150}
T[674]={d="Give the Raptor Talon Amulet to Gor'mul.",en={2792},l=34,n="Raising Spirits",nx=675,ps={672},r=178,rl=29,sn={2706},su=4526,x=270}
T[675]={d="Speak with Tor'gan.",en={2706},l=34,n="Raising Spirits",nx=701,ps={674},r=178,rl=29,sn={2792},x=270}
T[676]={d="Kill 8 Boulderfist Ogres and 10 Boulderfist Enforcers, then find Drum Fel in the Hammerfall outpost in Arathi Highlands.",en={2771},l=32,n="The Hammer May Fall",nx=677,ob={k={{2562},{2564}}},r=178,rl=30,sn={2770},x=2550}
T[677]={d="Slay 10 Witherbark Axe Throwers, 10 Headhunters and 8 Witch Doctors, and return to Drum Fel in the Hammerfall outpost.",en={2771},l=32,n="Call to Arms",nx=678,ob={k={{2554},{2556},{2555}}},r=178,rl=30,sn={2771},x=2550}
T[678]={d="Kill 10 Boulderfist Brutes and 4 Boulderfist Magi, and return to Drum Fel in the Hammerfall outpost.",en={2771},l=38,n="Call to Arms",nx=679,ob={k={{2566},{2567}}},ps={677},r=178,rl=30,sn={2771},x=2850}
T[679]={d="Kill 7 Boulderfist Shaman and 3 Boulderfist Lords and return to Drum Fel in the Hammerfall outpost.",en={2771},l=40,n="Call to Arms",ob={k={{2570},{2571}}},ps={678},r=178,rl=30,sn={2771},tg=1,x=3150}
T[680]={d="Slay Or'Kalar and bring his Head to Korin Fel in the Hammerfall outpost.",en={2772},l=40,n="The Real Threat",ob={i={{4551}}},ps={678},r=178,rl=30,sn={2772},tg=1,x=3900}
T[681]={d="Kill 10 Syndicate Highwaymen and 6 Syndicate Mercenaries.",en={2700},l=31,n="Northfold Manor",nx=682,ob={k={{2586},{2589}}},r=77,rl=30,sn={2700},x=2500}
T[682]={d="Bring 7 Stromgarde Badges to Captain Nials at Refuge Pointe.",en={2700},l=37,n="Stromgarde Badges",ob={i={{4506}}},ps={681},r=77,rl=30,sn={2700},tg=1,x=3550}
T[683]={d="Take Sara Balloo's note to King Magni Bronzebeard of Ironforge.",en={2784},l=30,n="Sara Balloo's Plea",nx=686,ps={637},r=77,rl=25,sn={2695},su=4514,x=1200}
T[684]={d="Bring Marez's head to Captain Nials at Refuge Pointe.",en={2700},l=39,n="Wanted!  Marez Cowl",ob={i={{4515}}},r=77,rl=30,so={2713},tg=1,x=3750}
T[685]={d="Bring Otto's Head and Falconcrest's Head to Captain Nials at Refuge Pointe.",en={2700},l=40,n="Wanted!  Otto and Falconcrest",ob={i={{4516},{4517}}},r=77,rl=30,so={2713},tg=1,x=3900}
T[686]={d="King Magni Bronzebeard wants you to speak with Grand Mason Marblesten.",en={2790},l=30,n="A King's Tribute",nx=689,ps={683},r=77,rl=25,sn={2784},x=1200}
T[687]={d="Find Theldurin the Lost.",en={2785},l=40,n="Theldurin the Lost",nx=692,ps={653,688},r=0,rl=30,sn={2786,2787},x=1550}
T[688]={d="Speak with Zaruk in Hammerfall.",en={2787},l=40,n="Myzrael's Allies",nx=687,ps={652},r=178,rl=30,so={2688},x=2350}
T[689]={d="Grand Mason Marblesten of Ironforge wants 5 pieces of Alterac Granite.",en={2790},l=31,n="A King's Tribute",nx=700,ob={i={{4521}}},ps={686},r=77,rl=25,sn={2790},x=2500}
T[690]={d="Find Skuerto at Refuge Pointe in the Arathi Highlands.",en={2789},l=32,n="Malin's Request",nx=691,r=77,rl=30,sn={2708},x=1950}
T[691]={d="Find 10 Witherbark Tusks, 4 Witherbark Medicine Pouches and a Shadow Hunter Knife for Apprentice Kryten at Refuge Pointe.",en={2788},l=36,n="Worth Its Weight in Gold",nx=693,ob={i={{4503},{4522},{5040}}},r=77,rl=30,sn={2788},x=3500}
T[692]={d="Bring the Torn Scroll Fragment, the Crumpled Scroll Fragment and the Singed Scroll Fragment to Theldurin the Lost.",en={2785},l=41,n="The Lost Fragments",nx=656,ob={i={{4518},{4519},{4520}}},ps={687},r=0,rl=30,sn={2785},x=3300}
T[693]={d="Find Trelane's Wand of Invocation and return it to Skuerto at Refuge Pointe.",en={2789},l=39,n="Wand over Fist",nx=694,ob={i={{4525}}},ps={691},r=77,rl=30,sn={2789},x=3000}
T[694]={d="Find an Azure Agate and bring it to Apprentice Kryten at Refuge Pointe.",en={2788},l=39,n="Trelane's Defenses",nx=695,ob={i={{4527}}},ps={693},r=77,rl=30,sn={2789},tg=1,x=3000}
T[695]={d="Speak to Skuerto.",en={2789},l=39,n="An Apprentice's Enchantment",nx=696,ps={694},r=77,rl=30,sn={2788},su=4529,tg=1,x=300}
T[696]={d="Find Trelane's Phylactery, Trelane's Orb, and Trelane's Ember Agate, and return them to Skuerto at Refuge Pointe.",en={2789},l=39,n="Attack on the Tower",nx=697,ob={i={{4530},{4531},{4532}}},ps={695},r=77,rl=30,rs={4529},sn={2789},tg=1,x=3000}
T[697]={d="Take the Sealed Letter to Archmage Malin in the Mage Quarter of Stormwind.",en={2708},l=39,n="Malin's Request",ps={696},r=77,rl=30,sn={2789},su=4533,tg=1,x=3750}
T[698]={d="Bring 8 Unprepared Sawtooth Flanks to Tok'Kar in Swamp of Sorrows.",en={5592},l=40,n="Lack of Surplus",nx=699,ob={i={{6169}}},r=178,rl=35,sn={5591},x=3150}
T[699]={d="Bring 6 Sawtooth Snapper Claws to Tok'Kar in the Swamp of Sorrows.",en={5592},l=42,n="Lack of Surplus",nx=1422,ob={i={{6168}}},ps={698},r=178,rl=35,sn={5592},x=3450}
T[700]={d="Report to King Magni Bronzebeard.",en={2784},l=31,n="A King's Tribute",ps={689},r=77,rl=25,sn={2790},x=2500}
T[701]={d="Acquire 12 Raptor Hearts from Highland Fleshstalkers for Tor'gan.",en={2706},l=37,n="Guile of the Raptor",nx=702,ob={i={{4513}}},ps={675},r=178,rl=29,sn={2706},x=2850}
T[702]={d="Give Tor'gan's Orb to Gor'mul.",en={2792},l=37,n="Guile of the Raptor",nx=847,ps={701},r=178,rl=29,sn={2706},su=4528,x=285}
T[703]={d="Bring 4 Buzzard Wings to Rigglefuzz.",en={2817},l=40,n="Barbecued Buzzard Wings",ob={i={{3404}}},r=0,rl=33,sn={2817},x=2350}
T[704]={d="Bring 4 Carved Stone Urns to Prospector Ironband in Loch Modan.",en={1344},l=38,n="Agmond's Fate",ob={i={{4610}}},ps={739},r=77,rl=30,sn={1344},tg=81,x=2850,z=1337}
T[705]={d="Bring 9 Blue Pearls to Rigglefuzz in the Badlands.",en={2817},l=37,n="Pearl Diving",nx=1559,ob={i={{4611}}},r=0,rl=30,sn={2817},tg=1,x=3550}
T[706]={d="Acquire a Black Drake's Heart for Sigrun Ironhew.",en={2860},l=45,n="Fiery Blaze Enchantments",ob={i={{4612}}},r=77,rl=40,sn={2860},tg=1,x=3900}
T[707]={d="Speak with Prospector Ironband at Ironband's Excavation Site in Loch Modan.",en={1344},l=37,n="Ironband Wants You!",nx=738,r=77,rl=30,sn={1356},x=710}
T[709]={d="Bring the Tablet of Ryun'eh to Theldurin the Lost.",en={2785},l=40,n="Solution to Doom",ob={i={{4631}}},r=0,rl=30,sn={2785},tg=81,x=3150,z=1337}
T[710]={d="Find 10 Small Stone Shards and bring them to Lotwil Veriatus in the Badlands.",en={2921},l=37,n="Study of the Elements: Rock",nx=711,ob={i={{4626}}},r=0,rl=35,sn={2921},x=2850}
T[711]={d="Bring 3 Large Stone Slabs to Lotwil Veriatus in the Badlands.",en={2921},l=39,n="Study of the Elements: Rock",nx=712,ob={i={{4627}}},ps={710},r=0,rl=35,sn={2921},x=3000}
T[712]={d="Bring 5 Bracers of Rock Binding to Lotwil Veriatus in the Badlands.",en={2921},l=42,n="Study of the Elements: Rock",ob={i={{4628}}},ps={711},r=0,rl=35,sn={2921},x=3450}
T[713]={d="Find Frost Oil and bring it to Lotwil Veriatus in Badlands.",en={2921},l=37,n="Coolant Heads Prevail",nx=714,ob={i={{3829}}},r=0,rl=35,sn={2921},x=2850}
T[714]={d="Bring a Gyrochronatom to Lotwil Veriatus in the Badlands.",en={2921},l=37,n="Gyro... What?",nx=715,ob={i={{4389}}},ps={713},r=0,rl=35,sn={2921},x=2850}
T[715]={d="Bring a Healing Potion and a Lesser Invisibility Potion to Lucien Tosselwrench in the Badlands.",en={2920},l=37,n="Liquid Stone",ob={i={{929},{3823}}},ps={714},r=0,rl=35,sk={},sn={2920},x=2100}
T[716]={d="Bring some Patterned Bronze Bracers to Lucien Tosselwrench in the Badlands.",en={2920},l=42,n="Stone Is Better than Cloth",ob={i={{2868}}},ps={712},r=0,rl=35,sn={2920},x=2550}
T[717]={d="Use the Sign of the Earth to activate the Pillars of Amethyst, Opal, and Diamond and obtain the Runestones.",en={2888},l=50,n="Tremors of the Earth",ob={i={{4615},{4645}}},ps={732},r=77,rl=40,rs={4843,4844,4845},sn={2888},su=4640,tg=1,x=5900}
T[718]={d="Retrieve the Supply Crate for Sigrun Ironhew.",en={2860},l=38,n="Mirages",nx=733,ob={i={{4629}}},r=77,rl=35,sn={2860},x=2150}
T[719]={d="Find Ryedol's Lucky Pick and return it to Prospector Ryedol south of Hammertoe's Dig Site.",en={2910},l=35,n="A Dwarf and His Tools",ob={i={{4616}}},r=77,rl=35,sn={2910},x=2750}
T[720]={d="Find Prospector Ryedol and let him know Hammertoe Grez is alive.",en={2910},l=35,n="A Sign of Hope",nx=721,r=77,rl=35,so={2868},x=1350}
T[721]={d="Find Hammertoe Grez in Uldaman.",en={2909},l=35,n="A Sign of Hope",nx=722,ps={720},r=77,rl=35,sn={2910},tg=81,x=2750,z=1337}
T[722]={d="Find Hammertoe's Amulet and return it to him in Uldaman.",en={2909},l=40,n="Amulet of Secrets",nx=723,ob={i={{4635}}},ps={721},r=77,rl=35,sn={2909},tg=81,x=3150,z=1337}
T[723]={d="Take Hammertoe's Amulet to Prospector Ryedol in the Badlands.",en={2910},l=40,n="Prospect of Faith",nx=724,ps={722},r=77,rl=35,sn={2909},su=4635,x=2350}
T[724]={d="Take Hammertoe's Amulet to Historian Karnik in Ironforge.",en={2916},l=40,n="Prospect of Faith",nx=725,ps={723},r=77,rl=35,sn={2910},su=4635,x=3150}
T[725]={d="Find Advisor Belgrum and give him his note.",en={2918},l=40,n="Passing Word of a Threat",nx=726,ps={724},r=77,rl=35,sn={2916},su=4622,x=1550}
T[726]={d="Speak to Historian Karnik.",en={2916},l=40,n="Passing Word of a Threat",nx=762,ps={725},r=77,rl=35,sn={2918},x=2350}
T[727]={d="Give the Sigil of the Hammer to Gerrig Bonegrip in the Forlorn Cavern of Ironforge.",en={2786},l=40,n="To Ironforge for Yagyin's Digest",nx=735,ps={709},r=77,rl=30,sn={2785},su=4648,x=780}
T[728]={d="Bring the Sigil of the Hammer to Keeper Bel'dugur in the Undercity.",en={2934},l=40,n="To the Undercity for Yagyin's Digest",nx=736,ps={709},r=178,rl=30,sn={2785},su=4648,x=780}
T[729]={d="Travel south and check on Prospector Remtravel.",en={2917},l=20,n="The Absent Minded Prospector",nx=731,r=77,rl=15,sn={2913},x=1150}
T[730]={d="Travel to Auberdine and look for signs of the dwarven excavation team.",en={2913},l=14,n="Trouble In Darkshore?",nx=729,r=77,rl=14,sn={2912},x=490}
T[731]={d="Protect Prospector Remtravel as he searches for the mysterious fossil, then return to Archaeologist Hollee in Auberdine.",en={2913},l=20,n="The Absent Minded Prospector",nx=741,ob={e={"Escort Prospector Remtravel",{{1439,35.7,84}}}},ps={729},r=77,rl=15,sf=2,sn={2917},x=1950}
T[732]={d="Retrieve the Sign of the Earth for Garek.",en={2888},l=43,n="Tremors of the Earth",nx=717,ob={i={{4640}}},ps={718},r=77,rl=40,sn={2888},x=3600}
T[733]={d="Get 7 pieces of Scrap Metal for Sigrun.",en={2860},l=40,n="Scrounging",ob={i={{4630}}},ps={718},r=77,rl=35,sn={2860},x=3150}
T[734]={d="Speak to Lucien Tosselwrench in the Badlands.",en={2920},l=42,n="This Is Going to Be Hard",nx=777,pg={712,714},r=0,rl=35,sn={2921}}
T[735]={d="Return the items on the Bonegrip's Note to Gerrig Bonegrip in Ironforge.",en={2786},l=44,n="The Star, the Hand and the Heart",nx=737,ob={i={{4646},{4641},{4644}}},ps={727},r=77,rl=30,rs={4639},sn={2786},su=4649,tg=1,x=5600}
T[736]={d="Bring the items on Bel'dugur's Note to Keeper Bel'dugur in the Undercity.",en={2934},l=44,n="The Star, the Hand and the Heart",nx=737,ob={i={{4646},{4641},{4644}}},ps={728},r=178,rl=30,rs={4639},sn={2934},su=4650,tg=1,x=5600}
T[737]={d="Bring Yagyin's Digest to Theldurin.",en={2785},l=40,n="Forbidden Knowledge",ps={735,736},r=0,rl=30,sn={2786,2934},su=4647,x=2350}
T[738]={d="Find Agmond.",eo={2875},l=38,n="Find Agmond",nx=739,r=77,rl=30,sn={1344},x=1450}
T[739]={d="Slay Agmond's killer, Murdaloc.",en={1344},l=42,n="Murdaloc",nx=704,ob={k={{2945},{2893}}},ps={738},r=77,rl=30,so={2875},x=3450}
T[741]={d="Take the mysterious fossil to Chief Archaeologist Greywhisker in Darnassus.",en={2912},l=20,n="The Absent Minded Prospector",nx=942,ps={731},r=77,rl=15,sn={2913},su=4654,x=1150}
T[742]={d="Speak with Senani Thunderheart at Splintertree Post, Ashenvale.",en={12696},ex={235,6382},l=20,n="The Ashenvale Hunt",nx=6383,r=178,rl=20,sn={10881},x=155}
T[743]={d="Bring 8 Windfury Talons to Ruul Eagletalon in Bloodhoof Village.",en={2985},l=8,n="Dangers of the Windfury",ob={i={{4751}}},r=178,rl=5,sn={2985},x=700}
T[744]={d="Collect 6 Azure Feathers and 6 Bronze Feathers, and bring them to Eyahn Eagletalon in Thunder Bluff.",en={2987},l=11,n="Preparation for Ceremony",ob={i={{4752},{4753}}},r=178,rl=7,sn={2987},x=880}
T[745]={d="Kill 10 Palemane Tanners, 8 Palemane Skinners, and 5 Palemane Poachers, then return to Baine Bloodhoof in Bloodhoof Village.",en={2993},l=6,n="Sharing the Land",ob={k={{2949},{2950},{2951}}},r=178,rl=1,sn={2993},x=540}
T[746]={d="Collect 5 Prospector's Picks.",en={2993},l=8,n="Dwarven Digging",ob={i={{4703}}},r=178,rl=6,rs={4702},sn={2993},x=700}
T[747]={d="Grull Hawkwind in Camp Narache wants you to bring him 7 Plainstrider Feathers and 7 pieces of Plainstrider Meat.",en={2980},l=2,n="The Hunt Begins",ob={i={{4739},{4740}}},r=178,rl=1,sn={2980},x=170}
T[748]={d="Bring 6 Prairie Wolf Paws and 4 Plainstrider Talons to Mull Thunderhorn in Bloodhoof.",en={2948},l=5,n="Poison Water",nx=754,ob={i={{4758},{4759}}},r=32,rl=4,sn={2948},x=450}
T[749]={d="Morin Cloudstalker wants you to examine the contents of a supply crate at the Ravaged Caravan.",eo={2908},l=8,n="The Ravaged Caravan",nx=751,r=178,rl=5,sn={2988},x=530}
T[750]={d="Grull Hawkwind in Camp Narache wants you to bring him 10 Mountain Cougar Pelts.",en={2980},l=3,n="The Hunt Continues",nx=780,ob={i={{4742}}},ps={747},r=178,rl=1,sn={2980},x=250}
T[751]={d="Return the Venture Co. Documents to Morin Cloudstalker near Bloodhoof Village.",en={2988},l=8,n="The Ravaged Caravan",ps={749},r=178,rl=5,so={2908},su=4834,x=530}
T[752]={d="Chief Hawkwind wants you to search for his mother near the water well to the southeast of Camp Narache.",en={2991},l=2,n="A Humble Task",nx=753,r=178,rl=1,sn={2981},x=85}
T[753]={d="Take a Water Pitcher from the water well.",en={2981},l=3,n="A Humble Task",nx=755,ob={i={{4755}}},r=178,rl=1,sn={2991},x=250}
T[754]={d="Use the Winterhoof Cleansing Totem at the Winterhoof Water Well, then return to Mull Thunderhorn.",en={2948},l=6,n="Winterhoof Cleansing",nx=756,ob={e={"Cleanse the Winterhoof Water Well",{{1412,51.8,68.4}}}},ps={748},r=32,rl=4,sf=2,sn={2948},su=5411,x=540}
T[755]={d="Travel to Seer Graytongue who lives in the hills directly south of Camp Narache.",en={2982},l=3,n="Rites of the Earthmother",nx=757,ps={753},r=178,rl=1,sn={2981},x=250}
T[756]={d="Bring 6 Stalker Claws and 6 Cougar Claws to Mull Thunderhorn.",en={2948},l=7,n="Thunderhorn Totem",nx=758,ob={i={{4801},{4802}}},ps={754},r=32,rl=4,sn={2948},x=630}
T[757]={d="Kill Bristlebacks in Brambleblade Ravine and bring 12 Bristleback Belts to Chief Hawkwind in Camp Narache.",en={2981},l=4,n="Rite of Strength",nx=763,ob={i={{4770}}},ps={755},r=178,rl=1,sn={2982},x=445}
T[758]={d="Use the Thunderhorn Cleansing Totem at the Thunderhorn Water Well, then return to Mull.",en={2948},l=8,n="Thunderhorn Cleansing",nx=759,ob={e={"Cleanse the Thunderhorn Water Well",{{1412,44.2,51.1}}}},ps={756},r=32,rl=4,sf=2,sn={2948},su=5415,x=700}
T[759]={d="Bring 8 Prairie Alpha Teeth to Mull Thunderhorn in Bloodhoof Village.",en={2948},l=10,n="Wildmane Totem",nx=760,ob={i={{4803}}},ps={758},r=32,rl=4,sn={2948},x=840}
T[760]={d="Use the Wildmane Cleansing Totem at the Wildmane Water Well, then return to Mull Thunderhorn.",en={2948},l=10,n="Wildmane Cleansing",ob={e={"Cleanse the Wildmane Well",{{1412,42.7,25}}}},ps={759},r=32,rl=4,sf=2,sn={2948},su=5416,x=1050}
T[761]={d="Bring 8 Trophy Swoop Quills to Harken Windtotem in Bloodhoof Village.",en={2947},l=6,n="Swoop Hunting",ob={i={{4769}}},r=178,rl=4,sn={2947},x=680}
T[762]={d="Kill Ambassador Infernus in Angor Fortress and bring proof of his death to Advisor Belgrum in Ironforge.",en={2918},l=44,n="An Ambassador of Evil",nx=1139,ob={i={{4621}}},ps={726},r=77,rl=35,sn={2916},tg=1,x=4650}
T[763]={d="Take the Totem of Hawkwind to Baine Bloodhoof in Bloodhoof Village. Follow the road out of Camp Narache.",en={2993},l=5,n="Rites of the Earthmother",nx=767,ps={757},r=178,rl=1,sn={2981},su=4783,x=335}
T[764]={d="Kill 14 Venture Co. Workers and 6 Venture Co. Supervisors for Morin Cloudstalker at Bloodhoof Village.",en={2988},l=10,n="The Venture Co.",ob={k={{2978},{2979}}},ps={751},r=178,rl=5,sn={2988},x=630}
T[765]={d="Kill Supervisor Fizsprocket and return his clipboard to Morin Cloudstalker at Bloodhoof Village.",en={2988},l=12,n="Supervisor Fizsprocket",ob={i={{4819}}},ps={751},r=178,rl=5,sn={2988},x=910}
T[766]={d="Bring a Prairie Wolf Heart, Flatland Cougar Femur, Plainstrider Scale and Swoop Gizzard to Maur Raincaller at Bloodhoof Village.",en={3055},l=8,n="Mazzranache",ob={i={{4804},{4805},{4806},{4807}}},r=178,rl=5,sn={3055},x=700}
T[767]={d="Speak with Zarlman Two-Moons in Bloodhoof Village.",en={3054},l=6,n="Rite of Vision",nx=771,r=178,rl=3,sn={2993},x=55}
T[768]={d="Bring 12 pieces of Light Leather to Veren Tallstrider in Thunder Bluff.",en={3050},l=8,n="Gathering Leather",ob={i={{2318}}},r=178,rl=4,sk={393,1},sn={3050},x=880}
T[769]={d="Bring 4 Light Leather and 4 Coarse Thread to Veren Tallstrider in Thunder Bluff.",en={3050},l=10,n="Kodo Hide Bag",ob={i={{2318},{2320}}},r=178,rl=4,sk={165,10},sn={3050},x=420}
T[770]={d="Find someone who knows of Ghost Howl.",en={3052},l=12,n="The Demon Scarred Cloak",r=178,rl=6,si={4854},su=4854,x=910}
T[771]={d="Collect 2 Well Stones and 2 Ambercorn and bring them back to Zarlman Two-Moons in Bloodhoof Village.",en={3054},l=7,n="Rite of Vision",nx=772,ob={i={{4808},{4809}}},ps={767},r=178,rl=3,sn={3054},x=630}
T[772]={d="Consume the Water of the Seers in front of the tribal fire in Bloodhoof Village and follow the vision once it appears.",en={2984},l=7,n="Rite of Vision",nx=773,ps={771},r=178,rl=3,sn={3054},su=4823,x=475}
T[773]={d="Travel to Red Rocks east of Thunder Bluff and speak with the Ancestral Spirit.",en={2994},l=10,n="Rite of Wisdom",nx=775,ps={772},r=178,rl=3,sn={2984},x=840}
T[775]={d="Speak with Cairne Bloodhoof in Thunder Bluff.",en={3057},l=10,n="Journey into Thunder Bluff",nx=776,ps={773},r=178,rl=3,sn={2994},x=420}
T[776]={d="Cairne Bloodhoof in Thunder Bluff wants you to bring him the Horn of Arra'chea.",en={3057},l=14,n="Rites of the Earthmother",ob={i={{4841}}},ps={775},r=178,rl=3,sn={3057},x=1250}
T[777]={d="Bring Cog #5 to Lotwil Veriatus.",en={2921},l=42,n="This Is Going to Be Hard",nx=778,ps={734},r=0,rl=35,sn={2920},su=4846}
T[778]={d="Defeat the Fam'retor Guardian and bring Lotwil's Shackles of Elemental Binding back to Lotwil Veriatus.",en={2921},l=45,n="This Is Going to Be Hard",ob={i={{4847}}},ps={777},r=0,rl=35,sn={2921},x=4850}
T[779]={eo={2933},l=50,n="Seal of the Earth",ob={i={{4845},{4844},{4843}}},pa=717,r=77,rl=40,sf=1,so={2933}}
T[780]={d="Grull Hawkwind in Camp Narache wants you to kill Battleboars and bring back 8 Battleboar Snouts and 8 Battleboar Flanks.",en={2980},l=4,n="The Battleboars",ob={i={{4848},{4849}}},ps={750},r=178,rl=1,sn={2980},x=445}
T[781]={d="Bring the Bristleback Attack Plans to Chief Hawkwind in Camp Narache.",en={2981},l=4,n="Attack on Camp Narache",r=178,rl=1,si={4851},su=4850,x=355}
T[782]={d="Kill Boss Tho'grun and bring the Sign of the Earth to Gorn in Kargath.",en={1068},l=43,n="Broken Alliances",nx=793,ob={i={{4640}}},r=178,rl=40,sn={1068},x=3600}
T[783]={d="Speak with Marshal McBride.",en={197},l=1,n="A Threat Within",nx=7,r=77,rl=1,sn={823},x=40}
T[784]={d="Kill 10 Kul Tiras Sailors, 8 Kul Tiras Marines and Lieutenant Benedict and return to Gar'Thok in Razor Hill.",en={3139},l=7,n="Vanquish the Betrayers",nx=825,ob={k={{3128},{3129},{3192}}},r=178,rl=3,sn={3139},x=630}
T[786]={d="Lar Prowltusk outside of Sen'jin Village wants you to destroy the 3 sets of Attack Plans held within Kolkar Crag.",en={3140},l=8,n="Thwarting Kolkar Aggression",ob={o={{3189,"Attack Plan: Valley of Trials destroyed"},{3190,"Attack Plan: Sen'jin Village destroyed"},{3192,"Attack Plan: Orgrimmar destroyed"}}},r=178,rl=5,sn={3140},x=700}
T[788]={d="Kill 10 Mottled Boars then return to Gornek at the Den.",en={3143},l=2,n="Cutting Teeth",ob={k={{3098}}},r=178,rl=1,sn={3143},x=170}
T[789]={d="Get 10 Scorpid Worker Tails for Gornek in the Den.",en={3143},l=3,n="Sting of the Scorpid",ob={i={{4862}}},ps={788},r=178,rl=1,sn={3143},x=250}
T[790]={d="Kill Sarkoth and bring his claw back to Hana'zua.",en={3287},l=5,n="Sarkoth",nx=804,ob={i={{4905}}},r=178,rl=1,sn={3287},x=450}
T[791]={d="Furl Scornbrow in the Razor Hill watchtower wants 8 Canvas Scraps.",en={3147},l=7,n="Carry Your Weight",ob={i={{4870}}},r=178,rl=4,sn={3147},x=630}
T[792]={c=1247,d="Kill 12 Vile Familiars.",en={3145},l=4,n="Vile Familiars",nx=794,ob={k={{3101}}},r=178,rl=2,sn={3145},x=445}
T[793]={d="Use the Sign of the Earth to activate the Pillars of Diamond, Opal, and Amethyst and obtain the Runestones.",en={1068},l=50,n="Broken Alliances",ob={i={{4615},{4645}}},ps={782},r=178,rl=40,rs={4843,4844,4845},sn={1068},su=4640,tg=1,x=5900}
T[794]={d="Bring the Burning Blade Medallion to Zureetha Fargaze, outside The Den.",en={3145},l=5,n="Burning Blade Medallion",nx=805,ob={i={{4859}}},ps={792,1499},r=178,rl=1,sn={3145},x=670}
T[795]={eo={2933},l=55,n="Seal of the Earth",ob={i={{4845},{4844},{4843}}},pa=793,r=178,rl=40,sf=1,so={2933}}
T[804]={d="Bring the news of Hana'zua's plight to Gornek at the Den.",en={3143},l=5,n="Sarkoth",ps={790},r=178,rl=1,sn={3287},x=110}
T[805]={d="Speak with Master Gadrin in Sen'jin Village.",en={3188},l=5,n="Report to Sen'jin Village",ps={794},r=178,rl=1,sn={3145},x=225}
T[806]={d="Bring Fizzle's Claw to Orgnil Soulscar in Razor Hill.",en={3142},l=12,n="Dark Storms",nx=828,ob={i={{4869}}},ps={823},r=178,rl=4,sn={3142},x=910}
T[808]={d="Retrieve Minshina's skull from the circle of power on the Echo Isles.",en={3188},l=9,n="Minshina's Skull",ob={i={{4864}}},r=178,rl=4,sn={3188},x=780}
T[809]={d="Speak with Ak'Zeloth in the Barrens.",en={3521},l=13,n="Ak'Zeloth",nx=924,ob={e={"Destroy the Demon Seed",{{1413,62.3,20.1}}}},ps={829},r=178,rl=4,sn={3216},x=455}
T[812]={d="Find Kor'ghan in Orgrimmar and get the Venomtail Antidote. Then bring the antidote to Rhinag near the northwestern border of Durotar.",en={3190},l=9,n="Need for a Cure",ob={i={{4904}}},r=178,rl=7,sn={3190},x=980}
T[813]={d="Bring 4 Venomtail Poison Sacs to Kor'ghan in Orgrimmar.",en={3189},l=9,n="Finding the Antidote",ob={i={{4886}}},pa=812,r=178,rl=7,sf=1,sn={3189}}
T[815]={d="Bring 3 Taillasher Eggs to Cook Torka in Razor Hill.",en={3191},l=8,n="Break a Few Eggs",ob={i={{4890}}},r=178,rl=6,sn={3191},x=700}
T[816]={d="Bring a sign of Kron's fate to Misha Tor'kren at the farmstead northwest of Razor Hill.",en={3193},l=11,n="Lost But Not Forgotten",ob={i={{4891}}},r=178,rl=8,sn={3193},x=880}
T[817]={d="Bring 4 Durotar Tiger Furs to Vel'rin Fang in Sen'jin Village.",en={3194},l=8,n="Practical Prey",ob={i={{4892}}},r=178,rl=5,sn={3194},x=700}
T[818]={d="Bring 4 Intact Makrura Eyes and 8 vials of Crawler Mucus to Master Vornal in Sen'jin Village.",en={3304},l=7,n="A Solvent Spirit",ob={i={{4887},{4888}}},r=178,rl=5,sn={3304},x=630}
T[819]={d="Find someone who knows about Chen's Empty Keg.",en={3292},l=15,n="Chen's Empty Keg",nx=821,r=178,rl=11,si={4926},su=4926,x=1050}
T[821]={d="Bring 5 Savannah Lion Tusks, 5 Plainstrider Kidneys, and 1 Thunder Lizard Horn to Brewmaster Drohn in Ratchet.",en={3292},l=15,n="Chen's Empty Keg",nx=822,ob={i={{4893},{4894},{4895}}},ps={819},r=178,rl=11,sn={3292},x=1350}
T[822]={d="Bring 5 Lightning Glands, 1 Thunderhawk Saliva Gland and 1 Kodo Liver to Brewmaster Drohn in Ratchet.",en={3292},l=24,n="Chen's Empty Keg",ob={i={{4898},{4897},{4896}}},ps={821},r=178,rl=11,sf=1,sn={3292},x=970}
T[823]={d="Speak with Orgnil Soulscar in Razor Hill.",en={3142},l=7,n="Report to Orgnil",nx=806,r=178,rl=4,sn={3188},x=315}
T[824]={d="Bring the Befouled Water Globe to Je'neu Sancrea at Zoram'gar Outpost, Ashenvale.",en={12736},l=27,n="Je'neu of the Earthen Ring",ps={1918},r=178,rl=23,sn={12737},su=16408,x=2200}
T[825]={d="Gar'Thok of Razor Hill wants you to retrieve 3 Gnomish Tools from the wreckage off the coast.",en={3139},l=8,n="From The Wreckage....",ob={i={{4863}}},ps={784},r=178,rl=3,sn={3139},x=700}
T[826]={d="Defeat Zalazane.",en={3188},l=10,n="Zalazane",ob={i={{4866}},k={{3207},{3206}}},r=178,rl=4,sn={3188},x=840}
T[827]={d="Gather Searing Collars from the cultists in Skull Rock.",en={3208},l=12,n="Skull Rock",nx=829,ob={i={{4871}}},ps={828},r=178,rl=4,sn={3208},x=910}
T[828]={d="Speak with Margoz.",en={3208},l=12,n="Margoz",nx=827,ps={806},r=178,rl=4,sn={3142},x=90}
T[829]={d="Bring an Example Collar to Neeru Fireblade in Orgrimmar.",en={3216},l=12,n="Neeru Fireblade",nx=809,ps={827},r=178,rl=4,sn={3208},su=6658,x=455}
T[830]={d="Take Admiral Proudmoore's Orders to Gar'Thok in Razor Hill.",en={3139},l=7,n="The Admiral's Orders",nx=831,r=178,rl=1,si={4881},su=4883,x=630}
T[831]={d="Deliver Admiral Proudmoore's Orders to Nazgrel in Thrall's chamber in Orgrimmar.",en={3230},l=7,n="The Admiral's Orders",ps={830},r=178,rl=1,sn={3139},su=4883,x=630}
T[832]={d="Take this eye to Neeru Fireblade.",en={3216},l=12,n="Burning Shadows",r=178,rl=4,si={4903},su=4903,x=680}
T[833]={d="Lorekeeper Raintotem wants you to kill 8 Bristleback Interlopers at Red Rocks.",en={3233},l=10,n="A Sacred Burial",ob={k={{3232}}},r=178,rl=7,sn={3233},x=630}
T[834]={d="Retrieve 5 Sacks of Supplies and return them to Rezlak near Orgrimmar.",en={3293},l=9,n="Winds in the Desert",nx=835,ob={i={{4918}}},r=0,rl=7,sn={3293},x=780}
T[835]={d="Kill 12 Dustwind Savages and 8 Dustwind Storm Witches for Rezlak near Drygulch Ravine.",en={3293},l=11,n="Securing the Lines",ob={k={{3117},{3118}}},ps={834},r=0,rl=7,sn={3293},x=880}
T[836]={d="Escort OOX-09/HL to the shoreline beyond Overlook Cliff, then report to Oglethorpe Obnoticus in Booty Bay.",en={7406},es=1,l=48,n="Rescue OOX-09/HL!",ob={e={"Escort OOX-09/HL to the shoreline beyond Overlook Cliff",{{1425,79.1,61.4}}}},ps={485},r=0,rl=43,sf=2,sn={7806},x=5450}
T[837]={d="Kill 4 Razormane Quilboars, 4 Razormane Scouts, 4 Razormane Dustrunners and 4 Razormane Battleguards for Gar'Thok at Razor Hill.",en={3139},l=10,n="Encroachment",ob={k={{3111},{3112},{3113},{3114}}},r=178,rl=6,sn={3139},x=630}
T[838]={d="Speak with Apothecary Dithers at the Bulwark, Western Plaguelands.",en={11057},l=55,n="Scholomance",nx=964,ps={5098},r=178,rl=55,sn={10837},x=560}
T[840]={d="Follow the western road from Razor Hill to the Barrens over a bridge.",en={3337},l=12,n="Conscript of the Horde",nx=842,r=178,rl=10,sn={3336},su=4992,x=455}
T[841]={d="Bring 10 Wastewander Water Pouches to Chief Engineer Bilgewhizzle in Gadgetzan in exchange for another power source.",en={7407},ex={654},l=46,n="Another Power Source?",ob={i={{8483}}},ps={379},r=178,rl=38,sf=1,sn={7407}}
T[842]={d="Follow the western road from Kargal's Far Watch Outpost.",en={3338},l=12,n="Crossroads Conscription",ps={840},r=178,rl=10,sn={3337},su=4995,x=910}
T[843]={d="Gann Stonespire wants you to kill 15 Bael'dun Excavators and 5 Bael'dun Foremen.",en={3341},l=23,n="Gann's Reclamation",nx=846,ob={i={{5006}},k={{3374},{3375}}},r=178,rl=17,sn={3341},x=1850}
T[844]={d="Collect 7 Plainstrider Beaks and return them to Sergra Darkthorn in the Crossroads.",en={3338},l=12,n="Plainstrider Menace",nx=845,ob={i={{5087}}},r=178,rl=10,sn={3338},x=910}
T[845]={d="Slay Zhevra Runners to collect 4 Zhevra Hooves for Sergra Darkthorn in the Crossroads.",en={3338},l=13,n="The Zhevra",nx=903,ob={i={{5086}}},ps={844},r=178,rl=10,sn={3338},x=910}
T[846]={d="Gann Stonespire wants you to bring him 6 vials of Nitroglycerin, 6 bundles of Wood Pulp, and 6 samples of Sodium Nitrate.",en={3341},l=26,n="Revenge of Gann",nx=849,ob={i={{5017},{5018},{5019}}},ps={843},r=178,rl=17,sn={3341},x=2100}
T[847]={d="Speak with Tor'gan.",en={2706},l=37,n="Guile of the Raptor",ps={702},r=178,rl=29,sn={2792},x=2850}
T[848]={d="Bring 4 Fungal Spores to Apothecary Helbrim at the Crossroads.",en={3390},l=15,n="Fungal Spores",nx=853,ob={i={{5012}}},r=178,rl=10,sn={3390},x=1050}
T[849]={d="Destroy the flying machine at Bael Modan and return to Gann Stonespire.",en={3341},l=26,n="Revenge of Gann",ob={o={{3644,"Bael Modan Flying Machine destroyed"}}},ps={846},r=178,rl=17,sn={3341},su=5021,x=2100}
T[850]={d="Bring Barak's Head to Regthar Deathgate, west of the Crossroads.",en={3389},l=16,n="Kolkar Leaders",nx=851,ob={i={{5022}}},r=178,rl=11,sn={3389},x=880}
T[851]={d="Bring Verog's Head to Regthar Deathgate, west of the Crossroads.",en={3389},l=18,n="Verog the Dervish",nx=852,ob={i={{5023}}},ps={850},r=178,rl=11,sn={3389},x=1000}
T[852]={d="Bring Hezrul's Head to Regthar Deathgate, west of the Crossroads.",en={3389},l=19,n="Hezrul Bloodmark",nx=4021,ob={i={{5025}}},ps={851},r=178,rl=11,sn={3389},x=1100}
T[853]={d="Bring the Rendered Spores to Apothecary Zamah in Thunder Bluff, before the time limit is up.",en={3419},l=15,n="Apothecary Zamah",ps={848},r=178,rl=10,sn={3390},su=5027,x=800}
T[854]={d="Speak with Thork at the Crossroads in the Barrens.",en={3429},ex={844},l=12,n="Journey to the Crossroads",r=32,rl=9,sn={3418},x=225}
T[855]={d="Bring 15 Centaur Bracers to Regthar Deathgate, west of the Crossroads.",en={3389},l=14,n="Centaur Bracers",ob={i={{5030}}},r=178,rl=9,sn={3389},x=1250}
T[857]={d="Feegly the Exiled wants you to retrieve for him the Tear of the Moons.",en={3421},l=30,n="The Tear of the Moons",ob={i={{5038}}},r=178,rl=22,sn={3421},x=2450}
end)()
;(function() local T = D.Q
T[858]={d="Get the Ignition Key and bring it to Wizzlecrank.",en={3439},l=18,n="Ignition",nx=863,ob={i={{5050}}},r=0,rl=13,sn={3439},x=1350}
T[860]={d="Speak with Sergra Darkthorn at the Crossroads.",en={3338},l=10,n="Sergra Darkthorn",nx=844,ps={861},r=178,rl=10,sn={3441},x=85}
T[861]={d="Bring 4 Flatland Prowler Claws to Melor Stonehoof in Thunder Bluff.",en={3441},ex={844},l=10,n="The Hunter's Way",nx=860,ob={i={{5203}}},r=178,rl=10,sn={3052},x=840}
T[862]={d="Bring 8 Dig Rats to Grub east of the Crossroads.",en={3443},l=23,n="Dig Rat Stew",ob={i={{5051}}},r=178,rl=15,sk={185,15},sn={3443},x=1850}
T[863]={d="Protect Wizzlecrank and the stolen goblin shredder on the way to Sputtervalve in Ratchet.",en={3442},l=18,n="The Escape",ob={e={"Escort Wizzlecrank out of the Venture Co. drill site",{{1413,55.4,7.7}}}},ps={858},r=0,rl=13,sf=2,sn={3439},x=1700}
T[864]={d="Bring the Sealed Field Testing Kit to Apothecary Zinge in the Undercity.",en={5204},l=46,n="Return to Apothecary Zinge",ps={654},r=178,rl=38,sn={7407},su=8527,x=5050}
T[865]={d="Gather 5 Intact Raptor Horns from Sunscale Scytheclaws, and bring them to Mebok Mizzyrix in Ratchet.",en={3446},l=18,n="Raptor Horns",nx=1491,ob={i={{5055}}},r=0,rl=13,sn={3446},x=1350}
T[866]={d="Bring 8 Root Samples to Mebok Mizzyrix in Ratchet.",en={3446},l=16,n="Root Samples",ob={i={{5056}}},r=0,rl=9,sk={182,1},sn={3446},x=1150}
T[867]={d="Collect 8 Witchwing talons.",en={3449},l=15,n="Harpy Raiders",nx=875,ob={i={{5064}}},r=178,rl=12,sn={3449},x=1050}
T[868]={d="Bring 12 Silithid Eggs and the Digging Claw to Korran at the Crossroads.",en={3428},l=22,n="Egg Hunt",ob={i={{5058}}},r=178,rl=17,sn={3428},su=5059,x=1750}
T[869]={d="Bring 12 Raptor Heads to Gazrog at the Crossroads.",en={3464},l=13,n="Raptor Thieves",nx=3281,ob={i={{5062}}},r=178,rl=9,sn={3464},x=910}
T[870]={d="Report back to Tonga Runetotem with your findings.",en={3448},l=13,n="The Forgotten Pools",nx=877,ob={e={"Explore the waters of the Forgotten Pools",{{1413,45.1,22.5}}}},r=178,rl=10,sf=2,sn={3448},x=680}
T[871]={d="Of the Razormane tribe, kill 8 Water Seekers, 8 Thornweavers and 3 Hunters, and then return to Thork in the Crossroads.",en={3429},l=12,n="Disrupt the Attacks",nx=872,ob={k={{3267},{3268},{3265}}},r=178,rl=9,sn={3429},x=910}
T[872]={d="Kill 8 Razormane Geomancers, 8 Razormane Defenders, and Kreenig Snarlsnout.",en={3429},l=15,n="The Disruption Ends",ob={i={{5063}},k={{3269},{3266}}},ps={871},r=178,rl=9,sn={3429},x=1050}
T[873]={d="Bring the Heart of Isha Awak to Mahren Skyseer.",en={3388},l=27,n="Isha Awak",ob={i={{5104}}},ps={874},r=178,rl=10,sn={3388},x=2750}
T[874]={d="Speak with Mahren Skyseer.",en={3388},l=27,n="Mahren Skyseer",nx=873,ps={913},r=178,rl=9,sn={3387},x=550}
T[875]={d="Collect 6 Harpy Lieutenant Rings from Witchwing Slayers and return them to Darsok Swiftdagger at the Crossroads.",en={3449},l=16,n="Harpy Lieutenants",nx=876,ob={i={{5065}}},ps={867},r=178,rl=12,sn={3449},x=1150}
T[876]={d="Slay Serena Bloodfeather and return her head to Darsok Swiftdagger at the Crossroads.",en={3449},l=20,n="Serena Bloodfeather",nx=1060,ob={i={{5067}}},ps={875},r=178,rl=12,sn={3449},x=1950}
T[877]={d="Return to Tonga at The Crossroads, after investigating the Stagnant Oasis.",en={3448},l=16,n="The Stagnant Oasis",nx=880,ob={o={{3737,"Test the Dried Seeds"}}},ps={870},r=178,rl=10,sn={3448},su=5068,x=1150}
T[878]={d="Kill 6 Bristleback Water Seekers, 12 Bristleback Thornweavers and 12 Bristleback Geomancers and return to Mangletooth at Camp Taurajo in the Barrens.",en={3430},l=21,n="Tribes at War",nx=5052,ob={k={{3260},{3261},{3263}}},r=178,rl=14,sn={3430},x=1650}
T[879]={d="Kill Nak, Kuz, and Lok Orcbane and bring their skulls to Mangletooth at Camp Taurajo in the Barrens.",en={3430},l=25,n="Betrayal from Within",nx=906,ob={i={{5074},{5073},{5072}}},ps={5052},r=178,rl=17,sn={3430},x=1500}
T[880]={d="Bring 8 Altered Snapjaw Shells to Tonga Runetotem at the Crossroads.",en={3448},l=16,n="Altered Beings",ob={i={{5098}}},ps={877},r=178,rl=10,sn={3448},x=1150}
T[881]={d="Bring Echeyakee's Hide to Sergra Darkthorn at the Crossroads.",en={3338},l=16,n="Echeyakee",nx=905,ob={i={{5100}}},ps={903},r=178,rl=10,sn={3338},su=10327,x=1450}
T[882]={d="Bring Ishamuhale's Fang to Jorn at Camp Taurajo.",en={3387},l=19,n="Ishamuhale",nx=907,ob={i={{5101}}},ps={3261},r=178,rl=10,rs={10338},sn={3387},x=1800}
T[883]={d="Bring the Hoof of Lakota'mani to Jorn at Camp Taurajo.",en={3387},l=22,n="Lakota'mani",r=178,rl=10,si={5099},su=5099,x=1300}
T[884]={d="Bring Owatanka's Tailspike to Jorn at Camp Taurajo.",en={3387},l=24,n="Owatanka",r=178,rl=10,si={5102},su=5102,x=1450}
T[885]={d="Bring Washte Pawne's Feather to Jorn Skyseer at Camp Taurajo.",en={3387},l=25,n="Washte Pawne",r=178,rl=10,si={5103},su=5103,x=1500}
T[886]={d="Speak with Tonga Runetotem at the Crossroads.",en={3448},l=10,n="The Barrens Oases",nx=870,r=178,rl=10,sn={5769},x=85}
T[887]={d="Kill 12 Southsea Brigands and 6 Southsea Cannoneers for Gazlowe in Ratchet.",en={3391},l=14,n="Southsea Freebooters",nx=890,ob={k={{3381},{3382}}},r=0,rl=9,sn={3391},x=740}
T[888]={d="Retrieve the Shipment of Boots and Telescopic Lens for Gazlowe in Ratchet.",en={3391},l=16,n="Stolen Booty",ob={i={{5076},{5077}}},ps={892},r=0,rl=9,sn={3391},x=1150}
T[889]={en={3430},l=20,n="Spirit of the Wind",ob={i={{5075}}},ps={5052},r=178,rl=14,sf=1,sn={3430}}
T[890]={d="Bring Gazlowe's Ledger to Wharfmaster Dizzywig.",en={3453},l=14,n="The Missing Shipment",nx=892,ps={887},r=0,rl=9,sn={3391},su=5080,x=100}
T[891]={d="Captain Thalo'thas Brightsun of Ratchet wants you to collect 10 Theramore Medals and slay Captain Fairmount, Cannoneer Whessan and Cannoneer Smythe.",en={3339},l=20,n="The Guns of Northwatch",ob={i={{5078}},k={{3393},{3455},{3454}}},r=178,rl=13,sn={3339},x=1550}
T[892]={d="Return Gazlowe's Ledger to Gazlowe in Ratchet.",en={3391},l=14,n="The Missing Shipment",nx=888,ps={890},r=0,rl=9,sn={3453},su=5080,x=100}
T[893]={d="Bring a Razormane Backstabber, a Charred Razormane Wand and a Razormane War Shield to Tatternack Steelforge at Camp Taurajo in the Barrens.",en={3433},l=24,n="Weapons of Choice",nx=1153,ob={i={{5093},{5092},{5094}}},r=178,rl=17,sn={3433},x=1950}
T[894]={d="Access the control console at the Venture Company research site.",eo={4141},l=14,n="Samophlange",nx=900,r=0,rl=10,sn={3442},su=5088,x=740}
T[895]={d="Bring the head of Baron Longshore to Gazlowe in Ratchet.",en={3391},l=16,n="WANTED: Baron Longshore",ob={i={{5084}}},r=0,rl=11,so={3972},x=1150}
T[896]={d="Retrieve the Cats Eye Emerald from one of the Venture Co. Overseers or Enforcers for Wharfmaster Dizzywig at Ratchet.",en={3453},l=18,n="Miner's Fortune",ob={i={{5097}}},r=0,rl=13,sn={3453},x=1700}
T[897]={d="Bring the Harvester's Head to Jorn Skyseer.",en={3387},l=24,n="The Harvester",r=178,rl=10,si={5138},su=5138,x=2400}
T[898]={d="Safely escort Gilthares Firebough back to Captain Brightsun in Ratchet.",en={3339},es=1,l=20,n="Free From the Hold",ob={e={"Escort Gilthares Firebough back to Ratchet",{{1413,62.3,39.1}}}},r=178,rl=13,sf=2,sn={3465},x=1950}
T[899]={d="Bring 60 Bristleback Quilboar Tusks to Mankrik at the Crossroads.",en={3432},l=20,n="Consumed by Hatred",ob={i={{5085}}},r=178,rl=14,sn={3432},x=1950}
T[900]={d="Close off the Fuel Control Valve, the Regulator Valve and the Main Control Valve then use the control console again.",eo={4141},l=14,n="Samophlange",nx=901,ob={o={{4072,"Shut off Main Control Valve"},{61936,"Shut off Fuel Control Valve"},{61935,"Shut off Regulator Valve"}}},ps={894},r=0,rl=10,so={4141},x=490}
T[901]={d="Get the Console Key from Tinkerer Sniggles to use on the control console.",eo={4141},l=14,n="Samophlange",nx=902,ob={i={{5089}}},ps={900},r=0,rl=10,so={4141},x=740}
T[902]={d="Return the Samophlange to Sputtervalve in Ratchet.",en={3442},l=16,n="Samophlange",nx=3921,ps={901},r=0,rl=10,so={4141},su=5054,x=1150}
T[903]={d="Collect 7 Prowler Claws from Savannah Prowlers for Sergra Darkthorn in the Crossroads.",en={3338},l=15,n="Prowlers of the Barrens",nx=881,ob={i={{5096}}},ps={845},r=178,rl=10,sn={3338},x=1050}
T[905]={d="Kill Sunscale raptors and collect their feathers. Use the feathers on the 3 Scytheclaw nests. Return to Sergra Darkthorn in the Crossroads.",en={3338},l=17,n="The Angry Scytheclaws",nx=3261,ob={o={{6907,"Visit Blue Raptor Nest"},{6908,"Visit Yellow Raptor Nest"},{6906,"Visit Red Raptor Nest"}}},ps={881},r=178,rl=10,rs={5165},sn={3338},x=1250}
T[906]={d="Bring Lok's Skull to Thork at the Crossroads in the Barrens.",en={3429},l=25,n="Betrayal from Within",ps={879},r=178,rl=17,sn={3430},su=5072,x=3050}
T[907]={d="Bring 3 Thunder Lizard Blood to Jorn Skyseer at Camp Taurajo.",en={3387},l=18,n="Enraged Thunder Lizards",nx=913,ob={i={{5143}}},ps={882},r=178,rl=10,sn={3387},x=1700}
T[913]={d="Find and slay a Thunderhawk, return its wings to Jorn Skyseer at Camp Taurajo.",en={3387},l=20,n="Cry of the Thunderhawk",nx=874,ob={i={{5164}}},ps={907},r=178,rl=10,sn={3387},x=1950}
T[914]={d="Bring the Gems of Cobrahn, Anacondra, Pythas and Serpentis to Nara Wildmane in Thunder Bluff.",en={5770},l=22,n="Leaders of the Fang",ob={i={{9738},{9739},{9740},{9741}}},ps={1490},r=178,rl=11,sn={5770},tg=81,x=2200,z=718}
T[916]={d="Bring 10 Webwood Venom Sacs to Gilshalan Windwalker at Aldrassil.",en={2082},l=4,n="Webwood Venom",nx=917,ob={i={{5166}}},r=77,rl=3,sn={2082},x=355}
T[917]={d="Bring a Webwood Egg to Gilshalan in Aldrassil.",en={2082},l=5,n="Webwood Egg",nx=920,ob={i={{5167}}},ps={916},r=77,rl=1,sn={2082},x=560}
T[918]={d="Bring 8 Timberling Seeds to Denelan at Lake Al'Ameth.",en={2080},l=7,n="Timberling Seeds",nx=922,ob={i={{5168}}},r=77,rl=4,sn={2080},x=630}
T[919]={d="Bring 12 Timberling Sprouts to Denalan at Lake Al'Ameth.",en={2080},l=7,n="Timberling Sprouts",ob={i={{5169}}},r=77,rl=4,sn={2080},x=790}
T[920]={d="Speak with Tenaron Stormgrip atop Aldrassil in Shadowglen.",en={3514},l=5,n="Tenaron's Summons",nx=921,ps={917},r=77,rl=1,sn={2082},x=45}
T[921]={d="Fill the Crystal Phial and bring it back to Tenaron Stormgrip atop Aldrassil.",en={3514},l=5,n="Crown of the Earth",nx=928,ob={i={{5184}}},ps={920},r=77,rl=1,sn={3514},su=5185,x=335}
T[922]={d="Bring a Timberling Seed to Rellian Greenspyre in Darnassus.",en={3517},l=7,n="Rellian Greenspyre",nx=923,ps={918},r=77,rl=4,sn={2080},su=5168,x=315}
T[923]={d="Bring 5 Mossy Tumors to Rellian Greenspyre in Darnassus.",en={3517},l=9,n="Tumors",nx=2498,ob={i={{5170}}},ps={922},r=77,rl=4,sn={3517},x=980}
T[924]={d="Grab a Flawed Power Stone. Bring it to the Altar of Fire before the stone expires, then return to Ak'Zeloth.",en={3521},l=14,n="The Demon Seed",ob={o={{3525,"Destroy the Demon Seed"}}},ps={809},r=178,rl=9,rs={4986},sf=2,sn={3521},x=1250}
T[926]={eo={5619,5620,5621},l=14,n="Flawed Power Stone",pa=924,r=178,rl=1,sf=1,so={5619,5620,5621}}
T[927]={d="Bring the Moss-twined Heart to Denalan at Lake Al'Ameth.",en={2080},l=12,n="The Moss-twined Heart",nx=941,r=77,rl=5,si={5179},su=5179,x=455}
T[928]={d="Bring the Partially Filled Vessel to Corithras Moonrage in Dolanaar.",en={3515},l=5,n="Crown of the Earth",nx=929,ps={921},r=77,rl=1,sn={3514},su=5186,x=225}
T[929]={d="Fill the Jade Phial and bring it back to Corithras Moonrage in Dolanaar.",en={3515},l=5,n="Crown of the Earth",nx=933,ob={i={{5639}}},ps={928},r=77,rl=1,sn={3515},su=5619,x=335}
T[930]={d="Bring the glowing fruit to Denalan at Lake Al'Ameth.",en={2080},l=10,n="The Glowing Fruit",ps={918},r=77,rl=4,so={6751},su=5189,x=840}
T[931]={d="Bring a Shimmering Frond to Denalan at Lake Al'Ameth",en={2080},l=10,n="The Shimmering Frond",nx=2399,ps={918},r=77,rl=4,so={6752},su=5190,x=840}
T[932]={d="Kill Lord Melenas and bring his head to Tallonkai Swiftroot in Dolanaar.",en={3567},l=7,n="Twisted Hatred",ob={i={{5221}}},r=77,rl=4,sn={3567},x=630}
T[933]={d="Fill the Tourmaline Phial and bring it back to Corithras Moonrage in Dolanaar.",en={3515},l=9,n="Crown of the Earth",nx=7383,ob={i={{5645}}},ps={929},r=77,rl=1,sn={3515},su=5621,x=780}
T[935]={d="Bring the Filled Vessel to Arch Druid Fandral Staghelm in Darnassus.",en={3516},l=11,n="Crown of the Earth",ps={7383},r=77,rl=1,sn={3515},su=5188,x=1100}
T[937]={d="Acquire 6 Bloodfeather Belts and bring them to Sentinel Arynia Cloudsbreak in the Oracle Glade.",en={3519},l=11,n="The Enchanted Glade",nx=940,ob={i={{5204}}},r=77,rl=6,sn={3519},x=440}
T[938]={d="Escort Mist to Sentinel Arynia Cloudsbreak at the moon well near the Oracle Tree.",en={3519},es=1,l=12,n="Mist",ob={e={"Lead Mist safely to Sentinel Arynia Cloudsbreak",{{1438,38.3,34.4}}}},r=77,rl=7,sf=2,sn={3568},x=910}
T[939]={d="Bring the Flute of Xavaric and 5 Jadefire Felbind samples to Eridan Bluewind in southern Felwood.",en={9116},l=54,n="Flute of Xavaric",nx=4441,ob={i={{11674}}},r=77,rl=49,si={11668},su=11668,x=5450}
T[940]={d="Deliver the Oracle Tree's report to Arch Druid Fandral Staghelm in Darnassus.",en={3516},l=11,n="Teldrassil",nx=952,ps={937},r=77,rl=6,sn={3519},su=5219,x=220}
T[941]={d="Plant the Tainted Heart in Denalan's Planter.",eo={7923},l=12,n="Planting the Heart",ps={927},r=77,rl=9,sn={2080},su=5217,x=910}
T[942]={d="Take the mysterious fossil to Archaeologist Flagongut in Menethil Harbor.",en={2911},l=20,n="The Absent Minded Prospector",nx=943,ps={741},r=77,rl=15,sn={2912},su=4654,x=1550}
T[943]={d="Archaeologist Flagongut in Menethil Harbor wants you to bring him the Stone of Relu and Flagongut's Fossil.",en={2911},l=24,n="The Absent Minded Prospector",ob={i={{5233},{5234}}},ps={942},r=77,rl=15,sn={2911},x=2400}
T[944]={d="Gather information, then use the Phial of Scrying to create a Scrying Bowl. Use the bowl to speak with Onu.",eo={10076},l=17,n="The Master's Glaive",nx=949,ob={e={"Enter the Master's Glaive",{{1439,38.5,86.5}}}},ps={948},r=77,rl=12,sf=2,sn={3616},su=5251,x=630}
T[945]={d="Help Therylune escape, then tell Therysil at the Shrine of Aessina that her sister is safe.",en={3585},l=18,n="Therylune's Escape",ob={e={"Escort Therylune away from the Master's Glaive",{{1439,40.5,87.1}}}},r=77,rl=10,sf=2,sn={3584},x=1350}
T[947]={d="Bring 5 Scaber Stalks and 1 Death Cap to Barithras Moonshade in Auberdine.",en={3583},l=17,n="Cave Mushrooms",nx=948,ob={i={{5271},{5270}}},r=77,rl=12,sn={3583},x=1250}
T[948]={d="Speak with Onu at the Grove of the Ancients.",en={3616},l=17,n="Onu",nx=944,ps={947},r=77,rl=12,sn={3583},x=630}
T[949]={d="Find a clue in the Twilight's Hammer camp at the Master's Glaive.",eo={12666},l=17,n="The Twilight Camp",nx=950,ps={944},r=77,rl=12,so={10076},x=1250}
T[950]={d="Bring Onu the recovered Insane Scribbles.",en={3616},l=17,n="Return to Onu",nx=951,ps={949},r=77,rl=12,so={12666},su=5272,x=950}
T[951]={d="Bring 6 Mathystra Relics to Onu at the Grove of the Ancients.",en={3616},l=20,n="Mathystra Relics",ob={i={{5273}}},ps={950},r=77,rl=12,sn={3616},x=1950}
T[952]={d="Deliver Fandral's message to Onu in the Grove of the Ancients in Darkshore, south of Auberdine.",en={3616},l=11,n="Grove of the Ancients",ps={940},r=77,rl=6,sn={3516},su=5390,x=880}
T[953]={d="Study the tablets which tell of Ameth'Aran and of its fall, then return to Sentinel Tysha Moonblade in Darkshore.",en={3639},l=12,n="The Fall of Ameth'Aran",ob={o={{17188,"Read the Lay of Ameth'Aran"},{17189,"Read the Fall of Ameth'Aran"}}},r=77,rl=9,sn={3639},x=910}
T[954]={d="Find the source of the strange blue aura in the ruins of Bashal'Aran.",en={3650},l=12,n="Bashal'Aran",nx=955,ob={e={"Find the source of the strange blue aura in the ruins of Bashal'Aran.",{{1439,44.3,36.4}}}},r=77,rl=7,sf=2,sn={3649},x=680}
T[955]={d="Acquire 8 Grell Earrings for Asterion in Bashal'Aran.",en={3650},l=12,n="Bashal'Aran",nx=956,ob={i={{5336}}},ps={954},r=77,rl=7,sn={3650},x=910}
T[956]={d="Obtain the Ancient Moonstone Seal and bring it to Asterion in Bashal'Aran.",en={3650},l=13,n="Bashal'Aran",nx=957,ob={i={{5338}}},ps={955},r=77,rl=7,sn={3650},x=910}
T[957]={d="Destroy the Ancient Moonstone Seal at the ancient flame in Ameth'Aran, then return to Asterion in Bashal'Aran.",en={3650},l=13,n="Bashal'Aran",ob={o={{16393,"Destroy the seal at the ancient flame"}}},ps={956},r=77,rl=7,sn={3650},su=5338,x=680}
T[958]={d="Retrieve 7 Highborne Relics for Thundris Windweaver in Auberdine.",en={3649},l=12,n="Tools of the Highborne",ob={i={{5360}}},r=77,rl=9,sn={3649},x=910}
T[959]={d="Crane Operator Bigglefuzz in Ratchet wants you to retrieve the bottle of 99-Year-Old Port from Mad Magglish who is hiding in the Wailing Caverns.",en={3665},l=18,n="Trouble at the Docks",ob={i={{5334}}},r=0,rl=14,sn={3665},x=1350,z=718}
T[960]={c=0,en={3616},l=1,n="Onu is meditating",nx=0,ps={944},r=77,rl=1,sf=1,sn={3616}}
T[961]={en={3616},l=1,n="Onu is meditating",ps={949},r=77,rl=1,sf=1,sn={3616}}
T[962]={d="Apothecary Zamah in Thunder Bluff wants you to collect 10 Serpentbloom.",en={3419},l=18,n="Serpentbloom",ob={i={{5339}}},r=178,rl=14,sn={3419},x=1350,z=718}
T[963]={d="Free the spirit of Anaya Dawnrunner and bring her pendant back to Cerellean Whiteclaw in Auberdine.",en={3644},l=16,n="For Love Eternal",ob={i={{5382}}},r=77,rl=11,sn={3644},x=880}
T[964]={d="Bring 15 Skeletal Fragments to Apothecary Dithers at the Bulwark, Western Plaguelands.",en={11057},l=57,n="Skeletal Fragments",nx=5514,ob={i={{14619}}},ps={838},r=178,rl=55,sn={11057},x=4500}
T[965]={d="Find Balthule Shadowstrike near the Tower of Althalaxx in Darkshore.",en={3661},l=18,n="The Tower of Althalaxx",nx=966,r=77,rl=13,sn={3657},x=680}
T[966]={d="Collect 4 Worn Parchments for Balthule Shadowstrike near the Tower of Althalaxx.",en={3661},l=18,n="The Tower of Althalaxx",nx=967,ob={i={{5348}}},ps={965},r=77,rl=13,sn={3661},x=1350}
T[967]={d="Deliver Balthule's letter to Delgren the Purifier in Ashenvale Forest.",en={3663},l=18,n="The Tower of Althalaxx",nx=970,ps={966},r=77,rl=13,sn={3661},su=5354,x=1000}
T[968]={d="Bring the Book: The Powers Below to Gerrig Bonegrip in the Forlorn Cavern, Ironforge.",en={2786},l=20,n="The Powers Below",r=77,rl=10,si={5352},su=5352,x=1950}
T[969]={d="Collect 4 Frostmaul Shards for Witch Doctor Mau'ari in Everlook.",en={10307},l=60,n="Luck Be With You",nx=975,ob={i={{12334}}},r=0,rl=55,sn={10307},tg=1,x=6600}
T[970]={d="Collect a Glowing Soul Gem and return it to Delgren the Purifier at Maestra's Post.",en={3663},l=21,n="The Tower of Althalaxx",nx=973,ob={i={{5366}}},ps={967},r=77,rl=13,sn={3663},x=1650}
T[971]={d="Bring the Lorgalis Manuscript to Gerrig Bonegrip in the Forlorn Cavern in Ironforge.",en={2786},l=23,n="Knowledge in the Deeps",ob={i={{5359}}},r=77,rl=10,sn={2786},tg=81,x=2750,z=719}
T[972]={c=64,en={5901},l=20,n="Water Sapta",pa=0,ps={220},r=178,rl=20,sf=1,sn={5901}}
T[973]={d="Bring Ilkrud Magthrull's Tome to Delgren the Purifier at Maestra's Post.",en={3663},l=24,n="The Tower of Althalaxx",nx=1140,ob={i={{5533}}},ps={970},r=77,rl=13,sn={3663},x=1950}
T[974]={d="Krakle in Un'Goro Crater wants you to find the hottest area of Fire Plume Ridge.",en={10302},l=55,n="Finding the Source",nx=980,ob={o={{148503}}},r=0,rl=51,sn={10302},su=12472,x=5650}
T[975]={d="Speak to Witch Doctor Mau'ari again in a moment to receive the lucky charm.",en={10307},l=60,n="Cache of Mau'ari",ps={969},r=0,rl=55,sf=2,sn={10307}}
T[976]={d="Speak with Delgren the Purifier at Maestra's Post after seeing Feero safely through Ashenvale Forest.",en={3663},l=24,n="Supplies to Auberdine",ob={e={"Protect Feero Ironhand",{{1439,43.5,94.4}}}},ps={973},r=77,rl=19,sf=2,sn={4484},x=2900}
T[977]={d="Collect 2 Pristine Yeti Horns for Umi Rumplesnicker in Everlook.",en={10305},l=58,n="Are We There, Yeti?",nx=5163,ob={i={{12367}}},ps={3783},r=0,rl=52,sn={10305},x=4650}
T[978]={d="Collect 10 Moontouched Feathers from Winterspring, then return to Erelas Ambersky in Rut'theran Village.",en={7916},l=55,n="Moontouched Wildkin",nx=979,ob={i={{12383}}},ps={3661},r=77,rl=52,sn={7916},x=5650}
T[979]={d="Find Ranshalla in eastern Winterspring.",en={10300},l=57,n="Find Ranshalla",nx=4901,ps={978},r=77,rl=52,sn={7916},x=3000}
T[980]={d="Travel to Winterspring and speak with Donova Snowden.",en={9298},l=55,n="The New Springs",nx=4842,ps={974},r=0,rl=51,sn={10302},x=2800}
T[981]={d="Talk to Delgren the Purifier at Maestra's Post.",en={3663},l=31,n="The Tower of Althalaxx",ps={1143},r=77,rl=13,sn={3661},x=2500}
T[982]={d="Recover the Silver Dawning's Lockbox and the Mist Veil's Lockbox for Gorbold Steelhand in Auberdine. Both items should be found aboard the wreckage of the ships to the north of the village.",en={6301},l=17,n="Deep Ocean, Vast Sea",ob={i={{12191},{12192}}},r=77,rl=13,sn={6301},x=1250}
T[983]={d="Collect 6 Crawler Legs and place them in Buzzbox 827.",eo={17182},l=10,n="Buzzbox 827",nx=1001,ob={i={{5385}}},r=77,rl=7,sn={3666},x=840}
T[984]={d="Find a corrupt furbolg camp in Darkshore and return to Terenthis in Auberdine.",en={3693},l=14,n="How Big a Threat?",nx=985,ob={e={"Find a corrupt furbolg camp",{{1439,50.9,34.7,39.9,53.9,42.7,86.5,40,78.4}}}},r=77,rl=10,sf=2,sn={3693},x=740}
T[985]={d="Kill 8 Blackwood Pathfinders and 5 Windtalkers and return to Terenthis in Auberdine.",en={3693},l=14,n="How Big a Threat?",nx=986,ob={k={{2167},{2324}}},ps={984},r=77,rl=10,sn={3693},x=980}
T[986]={d="Find 5 Fine Moonstalker Pelts and return them to Terenthis in Auberdine.",en={3693},l=20,n="A Lost Master",nx=993,ob={i={{5386}}},ps={985},r=77,rl=10,sn={3693},x=1550}
T[990]={d="Find Raene Wolfrunner in Ashenvale.",en={3691},l=19,n="Trek to Ashenvale",ps={994,995},r=77,rl=15,sn={3694},x=365}
T[991]={d="Find Teronis in Ashenvale.",en={3891},l=19,n="Raene's Cleansing",nx=1023,r=77,rl=18,sn={3691},x=1450}
T[992]={d="Use the untapped dowsing widget near the pool of water by Sandsorrow Watch. Once you have collected the sample, return the tapped dowsing widget to Senior Surveyor Fizzledowser in Gadgetzan.",en={7724},l=46,n="Gadgetzan Water Survey",nx=82,ob={i={{8585}}},r=0,rl=38,sn={7724},su=8584,x=3050}
T[993]={d="Find Volcor in Darkshore and give him the Enchanted Moonstalker Cloak.",en={3692},l=20,n="A Lost Master",ps={986},r=77,rl=10,sn={3693},su=5387,x=780}
T[994]={d="Protect Volcor until you reach the road, then speak to Terenthis in Auberdine.",en={3693},ex={995},l=22,n="Escape Through Force",nx=990,ob={e={"Help Volcor to the road",{{1439,41.9,81.8}}}},ps={993},r=77,rl=10,sf=2,sn={3692},x=1750}
T[995]={d="Escape the Furbolg cave and meet Terenthis in Auberdine.",en={3693},ex={994},l=20,n="Escape Through Stealth",nx=990,ob={e={"Help Volcor escape the cave",{{1439,44.6,85}}}},ps={993},r=77,rl=10,sf=2,sn={3692},x=780}
T[996]={eo={174602},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174602},x=560}
T[997]={d="Bring the package of Rare Earth to Denalan at Lake Al'Ameth.",en={2080},l=5,n="Denalan's Earth",r=77,rl=4,sn={2083},su=5391,x=225}
T[998]={eo={174603},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174603},x=560}
T[1000]={d="Speak with Arch Druid Hamuul Runetotem on the Elder Rise of Thunder Bluff about the Cenarion Circle's call to explore the frontiers of Kalimdor.",en={5769},ex={1004,1018},l=55,n="The New Frontier",nx=1123,r=178,rl=54,sn={10881},x=560}
T[1001]={d="Collect 3 Thresher Eyes from Darkshore Threshers in the deep sea near Buzzbox 411.",eo={17183},l=12,n="Buzzbox 411",nx=1002,ob={i={{5412}}},ps={983},r=77,rl=7,so={17182},x=1150}
T[1002]={d="Collect 6 Moonstalker Fangs and place them in Buzzbox 323.",eo={17184},l=14,n="Buzzbox 323",nx=1003,ob={i={{5413}}},ps={1001},r=77,rl=7,so={17183},x=980}
T[1003]={d="Collect 4 Grizzled Scalps from Grizzled Thistle Bears to the south of Auberdine and place them in Buzzbox 525.",eo={17185},l=16,n="Buzzbox 525",ob={i={{5414}}},ps={1002},r=77,rl=7,so={17184},x=1150}
T[1004]={d="Speak with Arch Druid Hamuul Runetotem on the Elder Rise of Thunder Bluff about the Cenarion Circle's call to explore the frontiers of Kalimdor.",en={5769},ex={1000,1018},l=55,n="The New Frontier",nx=1123,r=178,rl=54,sn={10879},x=560}
T[1007]={d="Bring the Ancient Statuette to Talen, in his camp near the Zoram Strand.",en={3846},l=20,n="The Ancient Statuette",nx=1009,ob={i={{5424}}},r=77,rl=19,sn={3846},x=1150}
T[1008]={d="Bring 20 Wrathtail Heads to Shindrell Swiftfire in Astranaar.",en={3845},l=19,n="The Zoram Strand",nx=1134,ob={i={{5490}}},r=77,rl=14,sn={3845},x=1450}
T[1009]={d="Bring the Ring of Zoram to Talen near the Zoram Strand.",en={3846},l=25,n="Ruuzel",ob={i={{5445}}},ps={1007},r=77,rl=20,sn={3846},x=2000}
T[1010]={d="Bring 5 Bathran's Hair to Orendil Broadleaf in Ashenvale.",en={3847},l=20,n="Bathran's Hair",nx=1020,ob={i={{5437}}},r=77,rl=20,sn={3847},x=780}
T[1011]={d="Bring a Bottle of Disease to Kayneth Stillwind in Forest Song.",en={3848},l=29,n="Forsaken Diseases",nx=1012,ob={i={{5440}}},r=77,rl=24,sn={3848},x=2350}
T[1012]={d="Kill the druids: Taneel Darkwood, Uthil Mooncall, Mavoris Cloudsbreak; then return to Kayneth Stillwind in Forest Song.",en={3848},l=32,n="Insane Druids",ob={k={{3940},{3941},{3942}}},ps={1011},r=77,rl=24,sn={3848},x=3200}
T[1013]={d="Bring the Book of Ur to Keeper Bel'dugur at the Apothecarium in the Undercity.",en={2934},l=26,n="The Book of Ur",ob={i={{6283}}},r=178,rl=16,sn={2934},tg=81,x=2100,z=209}
T[1014]={d="Kill Arugal and bring his head to Dalar Dawnweaver at the Sepulcher.",en={1938},l=27,n="Arugal Must Die",ob={i={{5442}}},r=178,rl=18,sn={1938},tg=81,x=3300,z=209}
T[1015]={d="Speak with Arch Druid Fandral Staghelm at the Cenarion Enclave of Darnassus about the Cenarion Circle's call to explore the frontiers of Kalimdor.",en={3516},ex={1047,1019},l=55,n="The New Frontier",nx=6761,r=77,rl=54,sn={2198},x=560}
T[1016]={d="Collect 5 Intact Elemental Bracers and use the Divining Scroll on them. Afterwards, bring the Divined Scroll to Sentinel Velene Starstrike at the Silverwind Refuge.",en={3885},l=24,n="Elemental Bracers",nx=1017,ob={i={{5455}}},r=77,rl=20,rs={12220},sn={3885},su=5456,x=1950}
T[1017]={d="Slay Sarilus Foulborne and bring his head to Sentinel Velene Starstrike in Silverwind Refuge.",en={3885},l=25,n="Mage Summoner",ob={i={{5537}}},ps={1016},r=77,rl=20,sn={3885},x=2550}
T[1018]={d="Speak with Arch Druid Hamuul Runetotem on the Elder Rise of Thunder Bluff about the Cenarion Circle's call to explore the frontiers of Kalimdor.",en={5769},ex={1000,1004},l=55,n="The New Frontier",nx=1123,r=178,rl=54,sn={10880},x=560}
T[1019]={d="Speak with Arch Druid Fandral Staghelm at the Cenarion Enclave of Darnassus about the Cenarion Circle's call to explore the frontiers of Kalimdor.",en={3516},ex={1015,1047},l=55,n="The New Frontier",nx=6761,r=77,rl=54,sn={10877},x=560}
T[1020]={d="Bring Orendil's Cure to Pelturas Whitemoon in Astranaar.",en={3894},l=20,n="Orendil's Cure",nx=1033,ps={1010},r=77,rl=20,sn={3847},su=5460,x=1950}
T[1021]={d="Find Anilia in Xavian.",en={3920},l=32,n="Vile Satyr! Dryads in Danger!",nx=1031,r=77,rl=26,sn={3901},x=2550}
T[1022]={d="Go to the Howling Vale and study the Tome of Mel'Thandris, then return to Sentinel Melyria Frostshadow at Forest Song.",en={3880},l=30,n="The Howling Vale",nx=1037,ob={o={{19027,"View the Tome of Mel'Thandris"}}},r=77,rl=25,sn={3880},x=2450}
T[1023]={d="Find the Glowing Gem and return to Raene Wolfrunner in Astranaar with Teronis' Journal.",en={3691},l=21,n="Raene's Cleansing",nx=1024,ob={i={{5463}}},ps={991},r=77,rl=18,sn={3891},su=5505,x=1250}
T[1024]={d="Find Shael'dryn at the moonwell to the northeast.",en={3916},l=21,n="Raene's Cleansing",nx=1026,ps={1023},r=77,rl=18,sn={3691},su=5463,x=830}
T[1025]={d="Kill 1 Den Watcher, 2 Ursas, 10 Totemics, and 12 Warriors of the Foulweald tribe, and then return to Raene Wolfrunner in Astranaar.",en={3691},l=24,n="An Aggressive Defense",ob={k={{3746},{3749},{3750},{3743}}},ps={1023},r=77,rl=18,sn={3691},x=1950}
T[1026]={d="Find the Wooden Key and a piece of Dartol's Rod before returning to Shael'dryn at the moonwell.",en={3916},l=27,n="Raene's Cleansing",nx=1027,ob={i={{5464}}},ps={1024},r=77,rl=18,rs={5475},sn={3916},x=2200}
T[1027]={d="Find the final piece of Dartol's Rod and return to Shael'dryn at the moonwell.",en={3916},l=28,n="Raene's Cleansing",nx=1028,ob={i={{5519}}},ps={1026},r=77,rl=18,sn={3916},x=2300}
T[1028]={d="Find the hidden shrine and re-enchant Dartol's Rod.",eo={19024},l=28,n="Raene's Cleansing",nx=1055,ps={1027},r=77,rl=18,sn={3916},su=5547,x=1700}
T[1029]={d="Return to Raene Wolfrunner in Astranaar.",en={3691},l=28,n="Raene's Cleansing",nx=1030,ps={1055},r=77,rl=18,sn={3916},su=5462,x=230}
T[1030]={d="Find an uncorrupted furbolg, and using the power of Dartol's Rod of Transformation, speak to him.",en={3897},l=28,n="Raene's Cleansing",nx=1045,ps={1029},r=77,rl=18,sn={3691},su=5462,x=1700}
T[1031]={d="Kill Geltharis and return the Branch of Cenarius to Illiyana at Forest Song.",en={3901},l=32,n="The Branch of Cenarius",nx=1032,ob={i={{5461}}},ps={1021},r=77,rl=26,sn={3920},x=2550}
T[1032]={d="Bring 16 Satyr Horns to Illiyana in Forest Song.",en={3901},l=32,n="Satyr Slaying!",ob={i={{5481}}},ps={1031},r=77,rl=26,sn={3901},x=2550}
T[1033]={d="Bring Elune's Tear to Pelturas in Astranaar.",en={3894},l=22,n="Elune's Tear",nx=1034,ob={i={{5493}}},ps={1020},r=77,rl=20,sn={3894},x=1750}
T[1034]={d="Bring 5 Handfuls of Stardust to Pelturas in Astranaar.",en={3894},l=23,n="The Ruins of Stardust",nx=1035,ob={i={{5494}}},ps={1033},r=77,rl=20,sn={3894},x=1850}
T[1035]={d="Retrieve a Fallen Moonstone from the Shadethicket Oracle, then bring it to Pelturas in Astranaar.",en={3894},l=30,n="Fallen Sky Lake",ob={i={{5508}}},ps={1034},r=77,rl=20,sn={3894},x=3050}
T[1036]={d="Speak with Fleet Master Firallon aboard the Crimson Vale off the coast of Stranglethorn Vale.",en={2546},l=60,n="Avast Ye, Scallywag",nx=4621,r=0,rl=55,rp={87,3000},sn={2545},x=660}
T[1037]={d="Speak with Thyn'tel Bladeweaver at the Warrior's Terrace in Darnassus.",en={8026},l=30,n="Velinde Starsong",nx=1038,ps={1022},r=77,rl=25,sn={3880},x=610}
T[1038]={d="Search through Velinde's chest for her journal, then return it along with the key to Thyn'tel Bladeweaver in Darnassus.",en={8026},l=30,n="Velinde's Effects",nx=1039,ob={i={{5520}}},ps={1037},r=77,rl=25,sn={8026},su=5521,x=610}
T[1039]={d="Speak with Wharfmaster Dizzywig in Ratchet.",en={3453},l=30,n="The Barrens Port",nx=1040,ps={1038},r=77,rl=25,sn={8026},x=1200}
T[1040]={d="Take a boat to Booty Bay and speak with Caravaneer Ruzzgot.",en={3945},l=30,n="Passage to Booty Bay",nx=1041,ps={1039},r=77,rl=25,sn={3453},x=610}
T[1041]={d="Speak with Clerk Daltry in Darkshire.",en={267},l=30,n="The Caravan Road",nx=1042,ps={1040},r=77,rl=25,sn={3945},x=1200}
T[1042]={d="Speak with Jonathan Carevin in Darkshire.",en={661},l=30,n="The Carevin Family",nx=1043,ps={1041},r=77,rl=25,sn={267},x=245}
T[1043]={d="Look for signs of the Scythe of Elune then return to Jonathan Carevin in Darkshire.",en={661},l=30,n="The Scythe of Elune",nx=1044,ob={o={{19030,"Find evidence of the Scythe of Elune"}}},ps={1042},r=77,rl=25,sn={661},x=2450}
T[1044]={d="Return to Thyn'tel Bladeweaver in Darnassus.",en={8026},l=30,n="Answered Questions",ps={1043},r=77,rl=25,sn={661},x=3050}
T[1045]={d="Kill Ran Bloodtooth and 4 Bloodtooth Guards and return to Krolg near Lake Mystral.",en={3897},l=30,n="Raene's Cleansing",nx=1046,ob={k={{3696},{3932}}},ps={1030},r=77,rl=18,sn={3897},su=5462,x=2450}
T[1046]={d="Bring Ran Bloodtooth's Skull and Dartol's Rod of Transformation to Raene Wolfrunner in Astranaar.",en={3691},l=30,n="Raene's Cleansing",ob={i={{5388},{5462}}},ps={1045},r=77,rl=18,sn={3897},x=3050}
T[1047]={d="Speak with Arch Druid Fandral Staghelm at the Cenarion Enclave of Darnassus about the Cenarion Circle's call to explore the frontiers of Kalimdor.",en={3516},ex={1015,1019},l=55,n="The New Frontier",nx=6761,r=77,rl=54,sn={10878},x=560}
T[1048]={d="Kill High Inquisitor Whitemane, Scarlet Commander Mograine, Herod, the Scarlet Champion and Houndmaster Loksey and then report back to Varimathras in the Undercity.",en={2425},l=42,n="Into The Scarlet Monastery",ob={k={{3977},{3976},{3975},{3974}}},r=178,rl=33,sn={2425},tg=81,x=5150,z=796}
T[1049]={d="Retrieve the Compendium of the Fallen from the Monastery in Tirisfal Glades and return to Sage Truthseeker in Thunder Bluff.",en={3978},l=38,n="Compendium of the Fallen",ob={i={{5535}}},r=162,rl=28,sn={3978},tg=81,x=3550,z=796}
T[1050]={d="Retrieve Mythology of the Titans from the Monastery and bring it to Librarian Mae Paledust in Ironforge.",en={3979},l=38,n="Mythology of the Titans",ob={i={{5536}}},r=77,rl=28,sn={3979},tg=81,x=3550,z=796}
T[1051]={d="Return Vorrel Sengutz's wedding ring to Monika Sengutz in Tarren Mill.",en={3982},l=33,n="Vorrel's Revenge",ob={i={{5538}}},r=178,rl=25,sn={3981},tg=1,x=3300,z=796}
T[1052]={d="Take Brother Anton's Letter of Commendation to Raleigh the Devout in Southshore.",en={3980},l=40,n="Down the Scarlet Path",nx=1053,ps={261},r=77,rl=34,sn={1182},su=5539,x=1550}
T[1053]={d="Kill High Inquisitor Whitemane, Scarlet Commander Mograine, Herod, the Scarlet Champion and Houndmaster Loksey and then report back to Raleigh the Devout in Southshore.",en={3980},l=40,n="In the Name of the Light",ob={k={{3977},{3976},{3975},{3974}}},ps={1052},r=77,rl=34,sn={3980},tg=81,x=4700,z=796}
T[1054]={d="Bring Dal Bloodclaw's Skull to Raene Wolfrunner in Astranaar.",en={3691},l=25,n="Culling the Threat",ob={i={{5544}}},r=77,rl=18,sn={3691},x=2000}
T[1055]={d="Return to Shael'dryn at the moonwell.",en={3916},l=28,n="Raene's Cleansing",nx=1029,ps={1028},r=77,rl=18,so={19024},x=230}
T[1056]={d="Travel to Keeper Albagorm on Stonetalon Peak.",en={3994},l=18,n="Journey to Stonetalon Peak",nx=1057,r=77,rl=18,sn={3996},x=680}
T[1057]={d="Keeper Albagorm on Stonetalon Peak wants you to slay 7 Bloodfury Harpies, 7 Bloodfury Ambushers, 7 Bloodfury Slayers and 7 Bloodfury Roguefeathers.",en={3994},l=27,n="Reclaiming the Charred Vale",nx=1059,ob={k={{4022},{4025},{4024},{4023}}},r=77,rl=20,sn={3994},x=2200}
T[1058]={d="Witch Doctor Jin'Zil at Malaka'jin wants 5 portions of Stonetalon Sap, 5 Twilight Whiskers, 30 Courser Eyes and a Fey Dragon Scale.",en={3995},l=26,n="Jin'Zil's Forest Magic",ob={i={{5582},{5584},{5585},{5583}}},r=178,rl=20,sn={3995},x=2100}
T[1059]={d="Travel to Falfindel Waywarder on the border of Thousand Needles and Feralas.",en={4048},l=27,n="Reclaiming the Charred Vale",ps={1057},r=77,rl=20,sn={3994},x=2200}
T[1060]={d="Deliver Darsok's letter to Jin'Zil within his cave in Malaka'Jin, in Stonetalon.",en={3995},l=20,n="Letter to Jin'Zil",ps={876},r=178,rl=15,sn={3449},su=5594,x=1550}
T[1061]={d="Speak with Seereth Stonebreak in the Stonetalon Mountains.",en={4049},l=17,n="The Spirits of Stonetalon",nx=1062,r=178,rl=13,sn={4047},x=315}
T[1062]={d="Kill 15 Venture Co. Loggers, then return to Seereth Stonebreak on the border of Stonetalon and the Barrens.",en={4049},l=19,n="Goblin Invaders",ob={k={{3989}}},r=178,rl=13,sn={4049},x=1450}
T[1063]={d="Speak with Magatha in Thunder Bluff.",en={4046},l=18,n="The Elder Crone",nx=1064,ps={1062},r=178,rl=13,sn={4049},x=680}
T[1064]={d="Speak with Apothecary Zamah in the Pools of Vision in Thunder Bluff.",en={3419},l=18,n="Forsaken Aid",nx=1065,ps={1063},r=178,rl=13,sn={4046},x=340}
T[1065]={d="Bring Zamah's Note to Apothecary Lydon in Tarren Mill.",en={2216},l=18,n="Journey to Tarren Mill",nx=1066,ps={1064},r=178,rl=13,sn={3419},su=5628,x=1350}
T[1066]={d="Bring 5 Vials of Innocent Blood to Apothecary Lydon in Tarren Mill.",en={2216},l=23,n="Blood of Innocents",nx=1067,ob={i={{5620}}},ps={1065},r=178,rl=13,sn={2216},x=1850}
T[1067]={d="Bring Lydon's Toxin to Apothecary Zamah in Thunder Bluff.",en={3419},l=23,n="Return to Thunder Bluff",nx=1086,ps={1066},r=178,rl=13,sn={2216},su=5588,x=1400}
T[1068]={d="Kill the shredders XT:4 and XT:9, then return to Seereth Stonebreak at the border of the Stonetalon Mountains and the Barrens.",en={4049},l=23,n="Shredding Machines",ob={k={{4073},{4074}}},ps={1062},r=178,rl=13,sn={4049},x=1850}
T[1069]={d="Bring 15 Deepmoss Eggs to Mebok Mizzyrix in Ratchet.",en={3446},l=20,n="Deepmoss Spider Eggs",ob={i={{5570}}},r=0,rl=15,sn={3446},x=1950}
T[1070]={d="Find Kaela Shadowspear overlooking the valley entering Windshear Crag in the Stonetalon Mountains.",en={4080},l=21,n="On Guard in Stonetalon",nx=1085,r=77,rl=17,sn={4079},x=830}
T[1071]={d="Kill 10 Venture Co. Loggers, and 10 Venture Co. Deforesters and return to Gaxim Rustfizzle in Stonetalon.",en={4077},l=21,n="A Gnome's Respite",ob={k={{3989},{3991}}},ps={1085},r=77,rl=17,sn={4077},x=1650}
T[1072]={d="Speak to Lomac Gearstrip in Ironforge.",en={4081},l=21,n="An Old Colleague",nx=1073,ps={1071},r=77,rl=17,sn={4077},x=830}
T[1073]={d="Bring 4 Minor Mana Potions and 2 Elixirs of Minor Fortitude to Lomac Gearstrip in Ironforge.",en={4081},l=21,n="Ineptitude + Chemicals = Fun",nx=1074,ob={i={{2455},{2458}}},ps={1072},r=77,rl=17,sn={4081},x=1650}
T[1074]={d="Bring the Nitromirglyceronium back to Gaxim Rustfizzle in Stonetalon.",en={4077},l=21,n="Ineptitude + Chemicals = Fun",ps={1073},r=77,rl=17,sn={4081},su=5732,x=830}
T[1075]={d="Find Collin Mauren in Stormwind.",en={4078},l=21,n="A Scroll from Mauren",nx=1076,ps={1071},r=77,rl=17,sn={4077},x=830}
T[1076]={d="Bring Dust Devil Debris to Collin Mauren in Stormwind.",en={4078},l=21,n="Devils in Westfall",nx=1077,ob={i={{5669}}},ps={1075},r=77,rl=17,sn={4078},x=1650}
T[1077]={d="Bring the Scroll of Messaging to Gaxim Rustfizzle in Stonetalon.",en={4077},l=21,n="Special Delivery for Gaxim",ps={1076},r=77,rl=17,sn={4078},su=5731,x=830}
T[1078]={d="Bring 8 Crystalized Scales to Collin Mauren in Stormwind.",en={4078},l=26,n="Retrieval for Mauren",ob={i={{5675}}},r=77,rl=17,sn={4078},x=2100}
T[1079]={d="Retrieve the Venture Co.'s Engineering Plans from the lumber mill in Windshear Crag.",en={4077},l=22,n="Covert Ops - Alpha",ob={i={{5718}}},pg={1077,1074},r=77,rl=17,rs={5692,5693,5694,5695,5737},sn={4077},su=5738,x=2200}
T[1080]={d="Retrieve the Venture Co. Letters from Windshear Mine at the east end of Windshear Crag.",en={4077},l=22,n="Covert Ops - Beta",ob={i={{5717}}},pg={1077,1074},r=77,rl=17,rs={5692,5693,5694,5695,5737},sn={4077},su=5738,x=2200}
T[1081]={d="Find Tyrande Whisperwind in Darnassus.",en={7999},l=28,n="Reception from Tyrande",ps={1082},r=77,rl=17,sn={4079},x=3400}
T[1082]={d="Return to Sentinel Thenysil in Ashenvale.",en={4079},l=22,n="Update for Sentinel Thenysil",nx=1081,pg={1083,1084},r=77,rl=17,sn={4080},x=870}
T[1083]={d="Bring 8 Smoldering Embers from any of the fire elementals in the Charred Vale to Kaela Shadowspear in Stonetalon.",en={4080},l=26,n="Enraged Spirits",ob={i={{5659}}},ps={1091},r=77,rl=20,sn={4080},x=2100}
T[1084]={d="Bring a piece of Corroded Shrapnel to Kaela Shadowspear in Stonetalon.",en={4080},l=28,n="Wounded Ancients",ob={i={{5664}}},ps={1091},r=77,rl=22,sn={4080},x=2300}
T[1085]={d="Speak to Gaxim.",en={4077},l=21,n="On Guard in Stonetalon",nx=1071,r=77,rl=17,sn={4080},x=165}
T[1086]={d="Bring the Toxic Fogger to the Venture Co. sky port, then return to Apothecary Zamah.",en={3419},l=23,n="The Flying Machine Airport",ob={e={"Place the Toxic Fogger",{{1442,66.4,45.5}}}},ps={1067},r=178,rl=13,sf=2,sn={3419},su=5638,x=2300}
T[1087]={d="Kill 4 Sons of Cenarius, 4 Daughters of Cenarius and 4 Cenarion Botanists for Braelyn Firehand near Sun Rock Retreat.",en={4198},l=25,n="Cenarius' Legacy",nx=1088,ob={k={{4057},{4053},{4051}}},r=178,rl=20,sn={4198},x=1500}
T[1088]={d="Bring Ordanus' head to Braelyn Firehand near Sun Rock Retreat.",en={4198},l=29,n="Ordanus",nx=1089,ob={i={{5686}}},ps={1087},r=178,rl=20,sn={4198},x=2350}
T[1089]={d="Travel to the Den on Stonetalon Peak. Using the Gatekeeper's Key, obtain the druids' hidden items. Use these items to open the Talon Den Hoard.",eo={19599},l=29,n="The Den",ob={i={{5689},{5690},{5691}}},ps={1088},r=178,rl=20,rs={5687},sn={4198},tg=1,x=2950}
T[1090]={d="Get the mysterious ore from Piznik after he finishes mining it.",en={4276},l=22,n="Gerenzo's Orders",nx=1092,ob={k={{4276}}},r=0,rl=17,sf=2,sn={4276},x=2200}
T[1091]={d="Bring the Venture Co. Letters to Kaela Shadowspear.",en={4080},l=22,n="Kaela's Update",pg={1079,1080},r=77,rl=17,sn={4077},su=5717,x=175}
T[1092]={d="Deliver the Unidentified Ore to Ziz Fizziks in the Stonetalon Mountains.",en={4201},l=22,n="Gerenzo's Orders",ps={1090},r=0,rl=17,sn={4276},su=5733,x=1300}
T[1093]={d="Get the Super Reaper 6000 Blueprints for Ziz Fizziks in the Stonetalon Mountains.",en={4201},l=21,n="Super Reaper 6000",nx=1094,ob={i={{5734}}},r=0,rl=16,sn={4201},x=1650}
T[1094]={d="Deliver the Sealed Envelope to Sputtervalve in the Barrens.",en={3442},l=21,n="Further Instructions",nx=1095,ps={1093},r=0,rl=16,sn={4201},su=5735,x=830}
T[1095]={d="Bring the new orders to Ziz Fizziks in the Stonetalon Mountains.",en={4201},l=27,n="Further Instructions",nx=1096,ps={1094},r=0,rl=16,sn={3442},x=1100}
T[1096]={d="Bring Gerenzo Wrenchwhistle's Mechanical Arm to Ziz Fizziks in the Stonetalon Mountains.",en={4201},l=27,n="Gerenzo Wrenchwhistle",ob={i={{5736}}},ps={1095},r=0,rl=16,sn={4201},x=2200}
T[1097]={d="Speak with Grimand Elmore.",en={1416},l=15,n="Elmore's Task",nx=353,r=77,rl=9,sn={415,514},x=105}
T[1098]={d="Find the Deathstalker Adamant and Deathstalker Vincent.",en={4444},l=25,n="Deathstalkers in Shadowfang",r=178,rl=18,sn={1952},tg=81,x=2000,z=209}
T[1100]={d="Read Henrig Lonebrow's Journal.",en={4048},l=34,n="Lonebrow's Journal",nx=1101,r=77,rl=29,si={5791},su=5790,tg=1,x=1350}
T[1101]={d="Bring Razorflank's Medallion to Falfindel Waywarder in Thalanaar.",en={4048},l=34,n="The Crone of the Kraul",ob={i={{5792}}},ps={1100},r=77,rl=29,sn={4048},tg=81,x=3350,z=491}
T[1102]={d="Bring Razorflank's Heart to Auld Stonespire in Thunder Bluff.",en={4451},l=34,n="A Vengeful Fate",ob={i={{5793}}},r=178,rl=29,sn={4451},tg=81,x=4050,z=491}
T[1103]={c=64,d="Bring a Water Sapta to Tiev Mordune in Silverpine Forest if you failed to speak to the Minor Manifestation of Water.",en={7007},l=23,n="Call of Water",ob={i={{6637}}},pa=0,ps={63},r=178,rl=20,sf=1,sn={7007}}
T[1104]={d="Bring 6 Salty Scorpid Venoms to Fizzle Brassbolts in the Shimmering Flats.",en={4454},l=30,n="Salt Flat Venom",ob={i={{5794}}},r=0,rl=28,sn={4454},x=1850}
T[1105]={d="Bring 9 Hardened Tortoise Shells to Wizzle Brassbolts in the Shimmering Flats.",en={4453},l=30,n="Hardened Shells",ob={i={{5795}}},r=0,rl=28,sn={4453},x=2450}
T[1106]={d="Bring Fizzle's Letter to Martek the Exiled in the Badlands.",en={4618},l=35,n="Martek the Exiled",nx=1108,pg={1104,1105},r=0,rl=26,sn={4454},su=5827,x=1350}
T[1107]={d="Bring 10 Encrusted Tail Fins to Wizzle Brassbolts in the Shimmering Flats.",en={4453},l=35,n="Encrusted Tail Fins",ob={i={{5796}}},pg={1104,1105},r=0,rl=28,sn={4453},tg=1,x=3450}
T[1108]={d="Bring 10 Indurium Flakes to Martek the Exiled in the Badlands.",en={4618},l=39,n="Indurium",nx=1137,ob={i={{5797}}},ps={1106},r=0,rl=28,sn={4618},x=3000}
T[1109]={d="Bring 1 pile of Kraul Guano to Master Apothecary Faranell in the Undercity.",en={2055},l=33,n="Going, Going, Guano!",nx=1113,ob={i={{5801}}},r=178,rl=30,sn={2055},tg=81,x=3300,z=491}
T[1110]={d="Bring 30 Rocket Car Parts to Kravel Koalbeard in the Shimmering Flats.",en={4452},l=31,n="Rocket Car Parts",ob={i={{5798}}},r=0,rl=28,sn={4452},x=2500}
T[1111]={d="Bring Kravel's Parts Order to Wharfmaster Dizzywig in Ratchet.",en={3453},l=36,n="Wharfmaster Dizzywig",nx=1112,r=0,rl=30,sn={4452},su=5799,x=1400}
T[1112]={d="Bring Kravel's Parts to Kravel Koalbeard in the Shimmering Flats.",en={4452},l=36,n="Parts for Kravel",nx=1114,ps={1111},r=0,rl=30,sn={3453},su=5800,x=1400}
T[1113]={d="Master Apothecary Faranell in the Undercity wants 20 Hearts of Zeal.",en={2055},l=33,n="Hearts of Zeal",ob={i={{5805}}},ps={1109},r=178,rl=30,sn={2055},x=3300,z=796}
T[1114]={d="Bring the Delicate Car Parts to Fizzle Brassbolts in Shimmering Flats.",en={4454},l=36,n="Delivery to the Gnomes",nx=1115,ps={1112},r=0,rl=30,sn={4452},su=5802,x=700}
T[1115]={d="Talk to Krazek in Booty Bay.",en={773},l=36,n="The Rumormonger",nx=1116,ps={1114},r=0,rl=30,sn={4452},x=1400}
T[1116]={d="Bring 10 Specks of Dream Dust to Krazek in Booty Bay. Dream Dust is gathered from the dragon whelps of the Swamp of Sorrows.",en={773},l=36,n="Dream Dust in the Swamp",nx=1117,ob={i={{5803}}},ps={1115},r=0,rl=30,sn={773},x=3500}
T[1117]={d="Bring the Goblin Rumors to Kravel Koalbeard in the Shimmering Flats.",en={4452},l=36,n="Rumors for Kravel",nx=1118,ps={1116},r=0,rl=30,sn={773},su=5804,x=3500}
T[1118]={d="Bring Kravel's Scheme to Crank Fizzlebub in Booty Bay.",en={2498},l=43,n="Back to Booty Bay",ps={1117},r=0,rl=35,sn={4452},su=5826,x=890}
T[1119]={d="Bring the Fool's Stout back to Kravel in the Shimmering Flats.",en={4452},l=44,n="Zanzil's Mixture and a Fool's Stout",pg={621,1118},r=0,rl=35,sn={2498},su=5806,x=3750}
T[1120]={d="Bring the Fool's Stout to the Gnome Pit Boss.",en={4495},ex={1121},l=44,n="Get the Gnomes Drunk",nx=1122,ps={1119},r=0,rl=35,sn={4452},su=5806,x=375}
T[1121]={d="Bring the Fool's Stout to the Goblin Pit Boss.",en={4496},ex={1120},l=44,n="Get the Goblins Drunk",nx=1122,ps={1119},r=0,rl=35,sn={4452},su=5806,x=375}
T[1122]={d="Bring the Fool's Stout report to Crank Fizzlebub in Booty Bay.",en={2498},l=44,n="Report Back to Fizzlebub",nx=1127,ps={1120,1121},r=0,rl=35,sn={4452},su=5807,x=1850}
T[1123]={d="Speak with Rabine Saturna in the village of Nighthaven, Moonglade. Moonglade lies between Felwood and Winterspring, accessible through a path out of Timbermaw Hold.",en={11801},l=55,n="Rabine Saturna",nx=1124,ps={1000,1004,1018},r=178,rl=54,sn={5769},x=1400}
T[1124]={d="Speak with Layo Starstrike near the Valor's Rest graveyard of Silithus, showing him Rabine's Letter.",en={13220},l=55,n="Wasteland",nx=1125,ps={1123,6762},r=0,rl=54,sn={11801},su=17355,x=2800}
T[1125]={d="Free the spirits of 8 Tortured Druids and 8 Tortured Sentinels in Southwind Village, and then return to Layo Starstrike at the Valor's Rest graveyard of Silithus.",en={13220},l=55,n="The Spirits of Southwind",nx=1126,ob={k={{12178},{12179}}},ps={1124},r=0,rl=54,sn={13220},x=5650}
T[1126]={d="Scale the tower of Southwind Village and locate a means to stir the silithid hive into activity. Bring back anything unusual you may uncover when doing so to Layo Starstrike at the Valor's Rest graveyard of Silithus.",en={13220},l=57,n="Hive in the Tower",nx=6844,ob={i={{17346}}},ps={1125},r=0,rl=54,rs={17345},sn={13220},x=6000}
T[1127]={d="Bring 12 of Zanzil's Mixture to Crank Fizzlebub in Booty Bay.",en={2498},l=44,n="Fool's Stout",ob={i={{4016}}},pa=1119,ps={1122},r=0,rl=36,sf=1,sn={2498},x=375}
T[1130]={d="Speak with Melor Stonehoof in Thunder Bluff.",en={3441},l=30,n="Melor Sends Word",nx=1131,r=178,rl=20,sn={3387}}
T[1131]={d="Bring Steelsnap's Rib to Melor Stonehoof in Thunder Bluff.",en={3441},l=30,n="Steelsnap",nx=1136,ob={i={{5837}}},r=178,rl=20,sn={3441},x=2450}
T[1132]={d="Speak with Fiora Longears on the docks at Theramore in Dustwallow Marsh.",en={4456},l=20,n="Fiora Longears",nx=1133,r=77,rl=18,sn={4455},x=780}
T[1133]={d="Speak with Shindrell Swiftfire in Astranaar.",en={3845},l=20,n="Journey to Astranaar",r=77,rl=18,sn={4456},x=390}
T[1134]={d="Bring 12 Pridewing Venom Sacs to Shindrell Swiftfire in Astranaar.",en={3845},l=21,n="Pridewings of Stonetalon",ob={i={{5808}}},ps={1008},r=77,rl=18,sn={3845},x=1650}
T[1135]={d="Bring 10 Highperch Venom Sacs to Fiora Longears in Theramore.",en={4456},l=30,n="Highperch Venom",ob={i={{5809}}},r=77,rl=25,sn={4456},x=3650}
T[1136]={d="Bring Frostmaw's Mane to Melor Stonehoof in Thunder Bluff.",en={3441},l=37,n="Frostmaw",ob={i={{5811}}},ps={1131},r=178,rl=26,rs={5810},sn={3441},su=5838,x=4250}
T[1137]={d="Speak with Fizzle Brassbolts in the Shimmering Flats.",en={4454},l=38,n="News for Fizzle",nx=1190,ps={1108},r=0,rl=28,sn={4618},x=1450}
T[1138]={d="Collect 6 Fine Crab Chunks for Gubber Blump in Auberdine.",en={10216},l=17,n="Fruit of the Sea",ob={i={{12237}}},r=77,rl=15,sn={10216},x=1250}
T[1139]={d="Find the Tablet of Will, and return them to Advisor Belgrum in Ironforge.",en={2918},l=45,n="The Lost Tablets of Will",ob={i={{5824}}},ps={762},r=77,rl=35,sn={2918},tg=81,x=5850,z=1337}
T[1140]={d="Free the trapped Highborne souls in Night Run and Satyrnaar, then return to Delgren the Purifier at Maestra's Post.",en={3663},l=28,n="The Tower of Althalaxx",nx=1167,ob={o={{19901,"Free the Highborne soul in Night Run"},{20352,"Free the Highborne soul in Satyrnaar"}}},ps={973},r=77,rl=13,sn={3663},x=2300}
T[1141]={d="Catch 6 Darkshore Grouper for Gubber Blump in Auberdine.",en={10216},l=14,n="The Family and the Fishing Pole",ob={i={{12238}}},r=77,rl=10,sn={10216},x=980}
T[1142]={d="Find and return Treshala's Pendant to Treshala Fallowbrook in Darnassus.",en={4521},l=30,n="Mortality Wanes",ob={i={{5825}}},r=77,rl=25,sn={4510},tg=81,x=3050,z=491}
T[1143]={d="Kill Athrikus Narassin and bring his head to Balthule Shadowstrike near the Tower of Althalaxx.",en={3661},l=31,n="The Tower of Althalaxx",nx=981,ob={i={{5383}}},ps={1167},r=77,rl=13,sn={3661},x=2500}
T[1144]={d="Escort Willix the Importer out of Razorfen Kraul.",en={4508},es=1,l=30,n="Willix the Importer",r=0,rl=23,sf=2,sn={4508},tg=81,x=3050,z=491}
T[1145]={d="Deliver Korran's Sealed Note to Belgrom Rockmaul in Orgrimmar.",en={4485},l=33,n="The Swarm Grows",nx=1146,r=178,rl=29,sn={3428},su=5846,x=1300}
T[1146]={d="Deliver Belgrom's Sealed Note to Moktar Krin in Thousand Needles.",en={4483},l=33,n="The Swarm Grows",nx=1147,ps={1145},r=178,rl=29,sn={4485},su=5850,x=1950}
T[1147]={d="Kill 5 Silithid Searchers, 5 Silithid Hive Drones, and 5 Silithid Invaders and return to Moktar Krin in Thousand Needles.",en={4483},l=35,n="The Swarm Grows",ob={k={{4130},{4133},{4131}}},ps={1146},r=178,rl=29,sn={4483},x=2750}
T[1148]={d="Bring 1 Silithid Heart, 5 Silithid Talons, and 3 Intact Silithid Carapaces, to Korran at the Crossroads.",en={3428},l=35,n="Parts of the Swarm",nx=1184,ob={i={{5855},{5854},{5853}}},ps={1146},r=178,rl=28,si={5877},su=5877,x=1350}
T[1149]={d="If you have faith, leap from the planks overlooking Thousand Needles.",en={2986},l=26,n="Test of Faith",nx=1150,ob={e={"If you have faith, leap from the planks overlooking Thousand Needles.",{{1441,26.4,32.9}}}},r=178,rl=25,sf=2,sn={2986},x=1050}
T[1150]={d="Bring Grenka's Claw to Dorn Plainstalker in Thousand Needles.",en={2986},l=30,n="Test of Endurance",nx=1151,ob={i={{5843}}},ps={1149},r=178,rl=25,sn={2986},x=2450}
T[1151]={d="Bring Fragments of Rok'Alim to Dorn Plainstalker in Thousand Needles.",en={2986},l=30,n="Test of Strength",nx=1152,ob={i={{5844}}},ps={1150},r=178,rl=25,sn={2986},tg=1,x=3050}
T[1152]={d="Find Braug Dimspirit near the entrance to Talondeep Path in Stonetalon Mountains.",en={4489},l=30,n="Test of Lore",nx=1154,ps={1151},r=178,rl=25,sn={2986},x=1200}
T[1153]={d="Find an Unrefined Ore Sample on a Gravelsnout Digger or Surveyor and bring it to Tatternack Steelforge at Camp Taurajo in the Barrens.",en={3433},l=29,n="A New Ore Sample",ob={i={{5842}}},ps={893},r=178,rl=25,sn={3433},x=2350}
T[1154]={d="Find the Legacy of the Aspects and return it to Braug Dimspirit near the entrance to Talondeep Path in Stonetalon Mountains.",en={4489},l=30,n="Test of Lore",nx=6627,ob={i={{5860}}},ps={1152},r=178,rl=25,sn={4489},x=1850}
T[1159]={d="Find Parqual Fintallas in Undercity.",en={4488},l=30,n="Test of Lore",nx=1160,ps={6627},r=178,rl=25,sn={4489},x=1200}
T[1160]={d="Find The Beginnings of the Undead Threat, and return it to Parqual Fintallas in Undercity.",en={4488},l=36,n="Test of Lore",nx=6628,ob={i={{5861}}},ps={1159},r=178,rl=25,sn={4488},tg=81,x=2100,z=796}
T[1164]={d="Bring Kenata, Fardel, and Marcel Dabyrie's Heads to Genavie Callow in Undercity.",en={4486},l=36,n="To Steal From Thieves",ob={i={{5830},{5832},{5831}}},r=178,rl=27,sn={4486},x=2800}
T[1166]={d="Overlord Mok'Morokk in Brackenwall Village wants you to retrieve his grog, snuff and strongbox in Dustwallow Swamp.",en={4500},l=43,n="Overlord Mok'Morokk's Concern",ob={i={{5834},{5835},{5836}}},r=178,rl=38,sn={4500},tg=1,x=4450}
T[1167]={d="Speak with Balthule Shadowstrike near the Tower of Althalaxx.",en={3661},l=28,n="The Tower of Althalaxx",nx=1143,ps={1140},r=77,rl=13,sn={3663},x=570}
T[1168]={d="Tharg in Brackenwall Village wants you to kill 10 Firemane Scouts, 10 Firemane Ash Tails, and 5 Firemane Scalebanes.",en={4502},l=43,n="Army of the Black Dragon",ob={k={{4329},{4331},{4328}}},r=178,rl=38,sn={4502},x=4450}
T[1169]={d="Draz'Zilb in Brackenwall Village would like you to bring him 15 Searing Tongues and 15 Searing Hearts.",en={4501},l=43,n="Identifying the Brood",nx=1170,ob={i={{5840},{5841}}},r=178,rl=38,sn={4501},x=5350}
T[1170]={d="Speak with Overlord Mok'Morokk in Brackenwall Village.",en={4500},l=43,n="The Brood of Onyxia",nx=1171,ps={1169},r=178,rl=38,sn={4501},x=360}
T[1171]={d="Speak with Draz'Zilb in Brackenwall Village.",en={4501},l=43,n="The Brood of Onyxia",nx=1172,ps={1170},r=178,rl=38,sn={4500},x=360}
T[1172]={d="Draz'Zilb in Brackenwall Village wants you to destroy 5 Eggs of Onyxia.",en={4501},l=45,n="The Brood of Onyxia",nx=1173,ob={o={{20359,"Egg of Onyxia destroyed"}}},ps={1171},r=178,rl=38,sn={4501},tg=1,x=4850}
T[1173]={d="Defeat Mok'Morokk and report the news to Draz'Zilb in Brackenwall Village.",en={4501},l=45,n="Challenge Overlord Mok'Morokk",ob={e={"Drive Overlord Mok'Morokk from Brackenwall Village",{{1445,36.4,31.4}}}},ps={1172},r=178,rl=38,sf=2,sn={4500},tg=1,x=4850}
T[1175]={d="Kill 10 Saltstone Basilisks, 10 Saltstone Crystalhides and 6 Saltstone Gazers for Trackmaster Zherin on the Shimmering Flats.",en={4629},l=33,n="A Bump in the Road",ob={k={{4147},{4151},{4150}}},r=0,rl=28,sn={4629},x=2650}
T[1176]={d="Get 10 Hollow Vulture Bones for Pozzik in the Shimmering Flats.",en={4630},l=30,n="Load Lightening",nx=1178,ob={i={{5848}}},r=0,rl=29,sn={4630},x=1850}
T[1177]={d="Mudcrush Durtfeet in northern Dustwallow wants 12 Mirefin Heads.",en={4503},l=36,n="Hungry!",ob={i={{5847}}},r=0,rl=32,sn={4503},x=2800}
T[1178]={d="Speak to Gazlowe in Ratchet.",en={3391},l=37,n="Goblin Sponsorship",nx=1180,ps={1176},r=0,rl=29,sn={4630},x=710}
T[1179]={d="Bring the crate of crash helmets to Wizzle Brassbolts in the Shimmering Flats.",en={4453},l=30,n="The Brassbolts Brothers",r=77,rl=28,sn={2092},su=5849,x=2450}
T[1180]={d="Speak with Wharfmaster Lozgil in Booty Bay.",en={4631},l=37,n="Goblin Sponsorship",nx=1181,ps={1178},r=0,rl=29,sn={3391},x=710}
T[1181]={d="Speak with Baron Revilgaz in Booty Bay.",en={2496},l=37,n="Goblin Sponsorship",nx=1182,ps={1180},r=0,rl=29,sn={4631},x=285}
T[1182]={d="Bring the Fuel Regulator Blueprints to Baron Revilgaz in Booty Bay.",en={2496},l=37,n="Goblin Sponsorship",nx=1183,ob={i={{5852}}},ps={1181},r=0,rl=29,rs={5851},sn={2496},x=2850}
T[1183]={d="Deliver the Fuel Regulator Blueprints to Pozzik on the Shimmering Flats.",en={4630},l=37,n="Goblin Sponsorship",nx=1186,ps={1182},r=0,rl=29,sn={2496},su=5852,x=710}
T[1184]={d="Return to Belgrom Rockmaul in Orgrimmar.",en={4485},l=35,n="Parts of the Swarm",ps={1148},r=178,rl=28,sn={3428},x=1350}
T[1185]={en={11939},l=57,n="Under the Chitin Was...",ps={6845},r=0,rl=54,sn={11939},x=3000}
T[1186]={d="Speak with Razzeric on the Shimmering Flats.",en={4706},l=37,n="The Eighteenth Pilot",nx=1187,ps={1183},r=0,rl=29,sn={4630},x=285}
T[1187]={d="Retrieve the Seaforium Booster for Razzeric in the Shimmering Flats.",en={4706},l=41,n="Razzeric's Tweaking",nx=1188,ob={i={{5862}}},ps={1186},r=0,rl=29,sn={4706},x=3300}
T[1188]={d="Bring the Seaforium Booster to Shreev in Gadgetzan.",en={4708},l=41,n="Safety First",nx=1189,ps={1187},r=0,rl=29,sn={4706},su=5862,x=820}
T[1189]={d="Return the Modified Seaforium Booster to Razzeric on the Shimmering Flats.",en={4706},l=41,n="Safety First",ps={1188},r=0,rl=29,sn={4708},su=5865,x=820}
T[1190]={d="Have Zamek create a diversion, then steal Rizzle's plans for Pozzik on the Shimmering Flats.",eo={20805},l=41,n="Keeping Pace",nx=1194,ps={1137},r=0,rl=29,sn={4630},x=1650}
T[1191]={en={4709},l=41,n="Zamek's Distraction",pa=1190,r=0,rl=29,sf=1,sn={4709}}
T[1192]={en={4630},l=42,n="Indurium Ore",ob={i={{5833}}},ps={1194},r=0,rl=29,sf=1,sn={4630},z=1337}
T[1193]={eo={179485},l=60,n="A Broken Trap",ob={i={{15994},{3829}}},r=0,rl=56,sf=1,so={179485},tg=81,z=2557}
T[1194]={d="Bring the Sample of Indurium Ore to Pozzik on the Shimmering Flats.",en={4630},l=41,n="Rizzle's Schematics",nx=1192,ps={1190},r=0,rl=29,so={20805,179888},su=5866,x=1650}
T[1195]={d="Return a Filled Etched Phial to Zangen Stonehoof in Thunder Bluff.",en={4721},l=25,n="The Sacred Flame",nx=1196,ob={i={{5868}}},r=178,rl=20,rs={5867},sn={4721},x=2550}
T[1196]={d="Deliver the Filled Etched Phial to Rau Cliffrunner at the Freewind Post.",en={4722},l=29,n="The Sacred Flame",nx=1197,ps={1195},r=178,rl=20,sn={4721},su=5868,x=590}
T[1197]={d="Retrieve the Cloven Hoof for Rau Cliffrunner at the Freewind Post.",en={4722},l=29,n="The Sacred Flame",ob={i={{5869}}},ps={1196},r=178,rl=20,sn={4722},su=5868,x=2350}
T[1198]={d="Seek out Argent Guard Thaelrid in Blackfathom Deeps.",en={4787},l=24,n="In Search of Thaelrid",nx=1200,r=0,rl=18,sn={4786},tg=81,x=2400,z=719}
T[1199]={d="Bring 10 Twilight Pendants to Argent Guard Manados in Darnassus.",en={4784},l=25,n="Twilight Falls",ob={i={{5879}}},r=77,rl=20,sn={4784},tg=81,x=2550,z=719}
T[1200]={d="Bring the head of Twilight Lord Kelris to Dawnwatcher Selgorm in Darnassus.",en={4783},l=27,n="Blackfathom Villainy",ob={i={{5881}}},r=77,rl=18,sn={4787},tg=81,x=1650,z=719}
T[1201]={d="Kill 9 Theramore Infiltrators, then return to Nazeer Bloodpike in Brackenwall Village.",en={4791},l=35,n="Theramore Spies",nx=1202,ob={k={{4834}}},r=178,rl=30,sn={4791},x=2750}
T[1202]={d="Bring the Captain's Documents to Nazeer Bloodpike in Brackenwall Village.",en={4791},l=35,n="The Theramore Docks",ob={i={{5882}}},ps={1201},r=178,rl=30,sn={4791},x=2750}
T[1203]={d="Bring a Moonsteel Broadsword to Jarl in Dustwallow Marsh.",en={4792},l=35,n="Jarl Needs a Blade",ob={i={{3853}}},ps={1206},r=0,rl=30,sn={4792},x=3450}
T[1204]={d="Bring 8 Forked Mudrock Tongues to Morgan Stern in Theramore.",en={4794},l=38,n="Mudrock Soup and Bugs",nx=1258,ob={i={{5883}}},r=77,rl=33,sn={4794},x=2850}
T[1205]={d="Bring Deadmire's Tooth to Melor in Thunder Bluff.",en={3441},l=45,n="Deadmire",ob={i={{5945}}},r=178,rl=35,sn={3441},x=3900}
T[1206]={d="Bring 40 Unpopped Darkmist Eyes to \"Swamp Eye\" Jarl at the Swamplight Manor.",en={4792},l=35,n="Jarl Needs Eyes",nx=1203,ob={i={{5884}}},ps={1218},r=0,rl=30,sn={4792},x=2750}
T[1218]={d="Bring 3 Soothing Spices to \"Swamp Eye\" Jarl in Dustwallow Marsh.",en={4792},l=35,n="Soothing Spices",nx=1206,ob={i={{3713}}},r=0,rl=30,sn={4792},x=1350}
T[1219]={d="Bring the Spy's Report to a Theramore Lieutenant.",en={4947},l=35,n="The Orc Report",nx=1220,r=77,rl=30,so={20985},su=5917,x=690}
T[1220]={d="Bring the Spy's Report to Captain Garran Vimes.",en={4944},l=35,n="Captain Vimes",ps={1219},r=77,rl=30,sn={4947},su=5917,x=2750}
T[1221]={d="Grab a Crate with Holes.",en={3446},l=26,n="Blueleaf Tubers",ob={i={{5876},{5880},{5897},{6684}}},r=0,rl=20,sn={3446},su=6684,tg=81,x=2100,z=491}
T[1222]={d="Escort \"Stinky\" Ignatz, then speak with Morgan Stern in Theramore.",en={4794},es=1,l=37,n="Stinky's Escape",nx=1271,ob={e={"Help Stinky find Bogbean Leaves",{{1445,48.9,24.6}}}},r=77,rl=30,sf=2,sn={4880},x=2850}
T[1238]={d="Bring the Spy's Report to Nazeer Bloodpike in Brackenwall Village.",en={4791},l=35,n="The Lost Report",nx=1239,r=178,rl=30,so={20985},su=5917,x=2050}
T[1239]={d="Bring the Defiant Orc Head to Nazeer Bloodpike in Brackenwall Village.",en={4791},l=35,n="The Severed Head",nx=1240,ps={1238},r=178,rl=30,so={20985},su=5918,x=2050}
T[1240]={d="Take the Defiant Orc Head to Kin'weelay in the Grom'gol Base Camp in Stranglethorn Vale.",en={2519},l=35,n="The Troll Witchdoctor",nx=1261,ps={1239},r=178,rl=30,sn={4791},su=5918,x=2750}
T[1241]={d="Find Jorgen in Stormwind City.",en={4959},l=28,n="The Missing Diplomat",nx=1242,ps={1274},r=77,rl=28,sn={4960},su=5948,x=230}
T[1242]={d="Delivery Jorgen's Sealed Note to Elling Trias in Stormwind City.",en={482},l=28,n="The Missing Diplomat",nx=1243,ps={1241},r=77,rl=28,sn={4959},su=5946,x=230}
T[1243]={d="Give the Sealed Note to Watcher Backus in Duskwood.",en={840},l=28,n="The Missing Diplomat",nx=1244,ps={1242},r=77,rl=28,sn={482},su=5960,x=230}
T[1244]={d="Find the Defias Docket and return it to Watcher Backus in Duskwood.",en={840},l=30,n="The Missing Diplomat",nx=1245,ob={i={{5947}}},ps={1243},r=77,rl=28,sn={840},x=2450}
T[1245]={d="Bring the Defias Docket to Elling Trias in Stormwind.",en={482},l=30,n="The Missing Diplomat",nx=1246,ps={1244},r=77,rl=28,sn={840},su=5947,x=245}
T[1246]={d="Speak to Dashel Stonefist in Stormwind.",en={4961},l=31,n="The Missing Diplomat",nx=1447,ps={1245},r=77,rl=28,sn={482},x=250}
T[1247]={d="Speak to Elling Trias in Stormwind.",en={482},l=31,n="The Missing Diplomat",nx=1248,ps={1447},r=77,rl=28,sn={4961},x=250}
T[1248]={d="Speak to Mikhail in the Wetlands.",en={4963},l=33,n="The Missing Diplomat",nx=1249,ps={1247},r=77,rl=28,sn={482},x=660}
T[1249]={d="Subdue Tapoke Jahn before he escapes, and then return to Mikhail in Menethil.",en={4963},l=33,n="The Missing Diplomat",nx=1250,ob={k={{4962}}},ps={1248},r=77,rl=28,sf=2,sn={4963},x=1300}
T[1250]={d="Speak to Mikhail in the Wetlands.",en={4963},l=33,n="The Missing Diplomat",nx=1264,ps={1249},r=77,rl=28,sn={4962},x=265}
T[1251]={d="Bring the Blackened Iron Shield to Krog in Brackenwall Village.",en={4926},l=35,n="The Black Shield",nx=1321,r=178,rl=30,so={20992},su=5919,x=690}
T[1252]={d="Bring Reethe's Badge to Captain Garran Vimes in Theramore.",en={4944},l=40,n="Lieutenant Paval Reethe",nx=1259,ps={1302,1282},r=77,rl=30,so={21042},su=5950,x=780}
T[1253]={d="Bring the Blackened Iron Shield to Captain Garran Vimes in Theramore.",en={4944},l=35,n="The Black Shield",nx=1319,ps={1302,1282},r=77,rl=30,so={20992},su=5919,x=690}
T[1258]={d="Bring 12 Pristine Crawler Legs to Morgan Stern in Theramore.",en={4794},l=40,n="... and Bugs",ob={i={{5938}}},ps={1204},r=77,rl=33,sn={4794},x=3150}
T[1259]={d="Find out more about Reethe from Adjutant Tesoran in Theramore.",en={4948},l=40,n="Lieutenant Paval Reethe",nx=1285,ps={1252},r=77,rl=30,sn={4944},x=315}
T[1260]={d="Speak with Morgan Stern in Theramore.",en={4794},l=38,n="Morgan Stern",nx=1204,r=77,rl=33,sn={1141},x=710}
T[1261]={d="Bring the Jeweled Pendant to Nazeer in Brackenwall Village.",en={4791},l=40,n="Marg Speaks",nx=1262,ob={i={{5942}}},ps={1240},r=178,rl=30,so={2076},x=3150}
T[1262]={d="Bring the Jeweled Pendant to Zor Lonetree in Orgrimmar.",en={4047},l=40,n="Report to Zor",nx=7541,ps={1261},r=178,rl=30,sn={4791},su=5942,x=3150}
T[1264]={d="Find Commander Samaul in Dustwallow Marsh.",en={4964},l=33,n="The Missing Diplomat",nx=1265,ps={1250},r=77,rl=28,sn={4963},x=1300}
T[1265]={d="Search Sentry Point for any sign of Private Hendel.",en={4967},l=35,n="The Missing Diplomat",nx=1266,ob={e={"Sentry Point explored",{{1445,59.9,40.9}}}},ps={1264},r=77,rl=28,sf=2,sn={4964},x=275}
T[1266]={d="Find Private Hendel in Dustwallow Marsh.",en={4966},l=36,n="The Missing Diplomat",nx=1324,ps={1265},r=77,rl=28,sn={4967},x=700}
T[1267]={d="Speak to Jaina Proudmore in Dustwallow Swamp.",en={4968},l=38,n="The Missing Diplomat",ps={1324},r=77,rl=28,sn={4968},x=4300}
T[1268]={d="Report about the suspicious prints at the Shady Rest Inn to Krog in Brackenwall Village.",en={4926},l=35,n="Suspicious Hoofprints",r=178,rl=30,so={21015,21016},x=1350}
T[1269]={d="Bring Reethe's Badge to Krog in Brackenwall Village.",en={4926},l=37,n="Lieutenant Paval Reethe",nx=1273,r=178,rl=30,so={21042},su=5950,x=710}
T[1270]={d="Escort \"Stinky\" Ignatz, then speak with Mebok Mizzyrix in Ratchet.",en={3446},es=1,l=37,n="Stinky's Escape",ob={e={"Help Stinky find Bogbean Leaves",{{1445,48.9,24.6}}}},r=178,rl=30,sf=2,sn={4880},x=2850}
T[1271]={en={1141},l=37,n="Feast at the Blue Recluse",ps={1222},r=77,rl=30,sn={1141}}
T[1273]={d="Go with Ogron to speak with Reethe, then return to Krog in Brackenwall Village.",en={4926},l=37,n="Questioning Reethe",ob={e={"Question Reethe with Ogron",{{1445,42.5,38.1}}}},ps={1269},r=178,rl=30,sf=2,sn={4983},x=3550}
T[1274]={d="Find Bishop DeLavey in Stormwind Keep.",en={4960},l=28,n="The Missing Diplomat",nx=1241,r=77,rl=28,sn={4982},x=230}
T[1275]={d="Gershala Nightwhisper in Auberdine wants 8 Corrupt Brain stems.",en={8997},l=24,n="Researching the Corruption",ob={i={{5952}}},r=77,rl=18,sn={8997},tg=81,x=2400,z=719}
T[1276]={d="Show the Blackened Iron Shield to Mosarn in Thunder Bluff.",en={4943},l=37,n="The Black Shield",ps={1273},r=178,rl=30,sn={4926},su=5919,x=1400}
T[1282]={d="Speak with Captain Garran Vimes on the top floor of Foothold Citadel.",en={4944},l=35,n="They Call Him Smiling Jim",r=77,rl=30,sn={4921},x=275}
T[1284]={d="Report about the suspicious prints at the Shady Rest Inn to Captain Garran Vimes in Theramore.",en={4944},l=35,n="Suspicious Hoofprints",ps={1282,1302},r=77,rl=30,so={21015,21016},x=1350}
T[1285]={d="Return the information about Reethe to Captain Garran Vimes in Theramore.",en={4944},l=38,n="Daelin's Men",nx=1286,ps={1259},r=77,rl=30,sn={4948},x=285}
T[1286]={d="Get information about Reethe from Balos Jacken and the deserters in Dustwallow Marsh.",en={5089},l=38,n="The Deserters",nx=1287,ps={1285},r=77,rl=30,sn={4944},x=2850}
T[1287]={d="Speak with Captain Garran Vimes in Theramore about Reethe.",en={4944},l=38,n="The Deserters",ps={1286},r=77,rl=30,sn={5089},x=2850}
T[1301]={d="Speak with Vincent Hyal in Menethil Harbor.",en={5082},l=35,n="James Hyal",nx=1302,r=77,rl=30,sn={5081},x=690}
T[1302]={d="Speak with Clerk Lendry at Foothold Citadel in Theramore.",en={5083},l=35,n="James Hyal",r=77,rl=30,sn={5082},x=690}
T[1319]={d="Show the Blackened Iron Shield to Caz Twosprocket in Theramore.",en={4941},l=35,n="The Black Shield",nx=1320,ps={1253},r=77,rl=30,sn={4944},su=5919,x=275}
T[1320]={d="Speak with Captain Garran Vimes in Theramore.",en={4944},l=35,n="The Black Shield",ps={1319},r=77,rl=30,sn={4941},x=1350}
T[1321]={d="Show the Blackened Iron Shield to Do'gol in Brackenwall Village.",en={5087},l=35,n="The Black Shield",nx=1322,ps={1251},r=178,rl=30,sn={4926},su=5919,x=275}
T[1322]={d="Acquire 6 Acidic Venom Sacs for Do'gol in Brackenwall Village.",en={5087},l=37,n="The Black Shield",nx=1323,ob={i={{5959}}},ps={1321},r=178,rl=30,sn={5087},x=2850}
T[1323]={d="Talk with Krog in Brackenwall Village.",en={4926},l=37,n="The Black Shield",ps={1322},r=178,rl=30,sn={5087},x=1400}
T[1324]={d="Defeat Private Hendel in Dustwallow Marsh.",en={4967},l=38,n="The Missing Diplomat",nx=1267,ob={k={{4966}}},ps={1266},r=77,rl=28,sf=2,sn={4966},x=2150}
T[1338]={d="Bring Stormpike's Request to Furen Longbeard in Stormwind.",en={5413},l=14,n="Stormpike's Order",r=77,rl=9,sn={1343},su=5998,x=980}
T[1339]={d="Speak with Mountaineer Stormpike.",en={1343},l=15,n="Mountaineer Stormpike's Task",nx=1338,r=77,rl=9,sn={1340},x=540}
T[1358]={d="Bring the Wolf Heart Sample to Apothecary Helbrim in the Barrens.",en={3390},l=15,n="Sample for Helbrim",ps={1359},r=178,rl=10,sn={5204},su=6016,x=1050}
T[1359]={d="Bring the Wolf Heart Samples to Apothecary Zinge in the Undercity.",en={5204},l=15,n="Zinge's Delivery",nx=1358,ps={3221},r=178,rl=10,sn={1937},su=10283,x=105}
T[1360]={d="Get Krom Stoutarm's treasured possession from his chest in the North Common Hall of Uldaman, and bring it to him in Ironforge.",en={6294},l=43,n="Reclaimed Treasures",ob={i={{8027}}},r=77,rl=33,sn={6294},tg=81,x=3600,z=1337}
T[1361]={d="Speak with Regthar Deathgate.",en={3389},l=32,n="Regthar Deathgate",nx=1362,r=178,rl=30,sn={2229,3230,4485},x=640}
T[1362]={d="Speak with Felgur Twocuts at Ghost Walker Post in Desolace.",en={5395},l=32,n="The Kolkar of Desolace",r=178,rl=30,sn={3389},x=640}
T[1363]={d="Speak with Acolyte Dellis in Stormwind.",en={5386},l=41,n="Mazen's Behest",nx=1364,r=77,rl=37,sn={338},x=330}
T[1364]={d="Retrieve Khadgar's Essays on Dimensional Convergence and deliver them to Watcher Mahar Ba in Nethergarde Keep.",en={5385},l=41,n="Mazen's Behest",ob={i={{6065}}},ps={1363},r=77,rl=37,sn={5386},x=3300}
T[1365]={d="Bring Khan Dez'hepah's Head to Felgur Twocuts in Desolace.",en={5395},l=35,n="Khan Dez'hepah",nx=1366,ob={i={{6066}}},r=178,rl=30,sn={5395},x=3450}
T[1366]={d="Bring 15 Centaur Ears to Felgur Twocuts in Desolace.",en={5395},l=31,n="Centaur Bounty",ob={i={{6067}}},ps={1365},r=178,rl=30,sn={5395},x=3750}
T[1367]={d="Gain a Friendly reputation with the Magram, then speak with Warug.",en={5398},l=33,n="Magram Alliance",nx=1369,r=178,rl=30,sn={5412},x=660}
T[1368]={d="Gain a Friendly reputation with the Gelkis, then speak with Uthek the Wise.",en={5397},l=33,n="Gelkis Alliance",nx=1370,r=178,rl=30,sn={5412},x=660}
T[1369]={d="Maintain your reputation with the Magram, and bring 3 Broken Tears to Warug in the Magram Village.",en={5398},l=33,n="Broken Tears",nx=1371,ob={i={{6083}}},ps={1367,1386},r=0,rl=30,rp={93,3000},sn={5398},x=2650}
T[1370]={d="Bring 6 bags of Crudely Dried Meat to Uthek the Wise in the Gelkis Village.",en={5397},l=35,n="Stealing Supplies",nx=1373,ob={i={{6069}}},ps={1368,1384},r=0,rl=30,rp={92,3000},sn={5397},x=1350}
T[1371]={d="Maintain your reputation with the Magram, and bring an Advanced Target Dummy to Warug in the Magram Village in Desolace.",en={5398},l=35,n="Gizmo for Warug",nx=1375,ob={i={{4392}}},ps={1369},r=0,rl=30,rp={93,3000},sn={5398},x=2050}
T[1372]={d="Speak with Apothecary Faustin at Beggar's Haunt.",en={5414},l=42,n="Nothing But The Truth",nx=1383,r=178,rl=37,sn={5418},x=345}
T[1373]={d="Maintain your reputation with the Gelkis, and bring a Draenethyst Shard to Uthek the Wise in the Gelkis Village in Desolace.",en={5397},l=37,n="Ongeku",nx=1374,ob={i={{6190}}},ps={1370},r=0,rl=30,rp={92,3000},sn={5397},x=2850}
T[1374]={d="Bring the Khan Jehn's Head to Uthek the Wise in the Gelkis Village in Desolace.",en={5397},l=37,n="Khan Jehn",nx=1380,ob={i={{6072}}},ps={1373},r=0,rl=30,rp={92,3000},sn={5397},x=2850}
T[1375]={d="Maintain your reputation with the Magram, and bring the Head of Khan Shaka to Warug in the Magram Village in Desolace.",en={5398},l=37,n="Khan Shaka",nx=1381,ob={i={{6073}}},ps={1371},r=0,rl=30,rp={93,3000},sn={5398},x=2850}
T[1380]={d="Maintain your reputation with the Gelkis, and bring the Maraudine Key Fragment to Uthek the Wise in the Gelkis Village.",en={5397},l=42,n="Khan Hratha",ob={i={{6077}}},ps={1374},r=0,rl=30,rp={92,3000},rs={6074},sn={5397},tg=1,x=4300}
T[1381]={d="Maintain your Magram reputation, and bring the Maraudine Key Fragment to Warug in the Magram Village in Desolace.",en={5398},l=42,n="Khan Hratha",ob={i={{6077}}},ps={1375},r=0,rl=30,rp={93,3000},rs={6074},sn={5398},tg=1,x=4300}
T[1382]={d="Gain a Friendly reputation with the Gelkis, then speak with Uthek the Wise.",en={5397},l=35,n="Strange Alliance",nx=1384,r=77,rl=30,sn={5396},x=2050}
T[1383]={d="Apothecary Faustin at Beggar's Haunt needs 5 Shadow Panther Hearts, Mire Lord Fungus and a Deep Strider Tumor.",en={5414},l=42,n="Nothing But The Truth",nx=1388,ob={i={{6080},{6081},{6082}}},ps={1372},r=178,rl=37,sn={5414},tg=1,x=4300}
T[1384]={d="Maintain your reputation with the Gelkis, and bring 10 Crude Charms to Uthek the Wise in the Gelkis Village in Desolace.",en={5397},l=32,n="Raid on the Kolkar",nx=1370,ob={i={{6079}}},ps={1382},r=77,rl=30,rp={92,3000},sn={5397},x=2550}
T[1385]={d="Gain a Friendly reputation with the Magram, then speak with Warug.",en={5398},l=35,n="Brutal Politics",nx=1386,r=77,rl=30,sn={5396},x=2050}
T[1386]={d="Maintain your reputation with the Magram. Kill 12 Kolkar Centaurs, 12 Kolkar Scouts and 6 Kolkar Maulers, then return to Warug in the Magram Village in Desolace.",en={5398},l=32,n="Assault on the Kolkar",nx=1369,ob={k={{4632},{4633},{4634}}},ps={1385},r=77,rl=30,rp={93,3000},sn={5398},x=2550}
T[1387]={d="Bring 15 Centaur Ears to Corporal Melkins at Nijel's Point in Desolace.",en={5752},l=31,n="Centaur Bounty",ob={i={{6067}}},r=77,rl=30,sn={5752},x=3750}
T[1388]={d="Give Faustin's Truth Serum to Deathstalker Zraedus at Beggar's Haunt.",en={5418},l=42,n="Nothing But The Truth",nx=1391,ps={1383},r=178,rl=37,sn={5414},su=6086,x=345}
T[1389]={d="Bring 6 Draenethyst crystals to Magtoor at The Harborage in the Swamp of Sorrows.",en={1776},l=35,n="Draenethyst Crystals",ob={i={{6071}}},r=0,rl=30,sn={1776},x=2750}
T[1391]={d="Take Zraedus's Brew to Infiltrator Marksen in Stonard.",en={5416},l=42,n="Nothing But The Truth",ps={1388},r=178,rl=37,sn={5418},su=6089,x=2550}
T[1392]={d="Bring Noboru's Cudgel to the leader of The Harborage in the Swamp of Sorrows.",en={1776},l=39,n="Noboru the Cudgel",r=0,rl=29,si={6196},su=6196,x=2250}
T[1393]={d="Escort Galen out of danger, then find his camp in the Swamp of Sorrows and open his strongbox.",eo={32569},es=1,l=38,n="Galen's Escape",ob={e={"Escort Galen out of the Fallow Sanctuary.",{{1435,53.1,29.6}}}},r=0,rl=30,sf=2,sn={5391},x=2850}
T[1394]={d="Speak to Dorn Plainstalker in Thousand Needles.",en={2986},l=36,n="Final Passage",ps={6628},r=178,rl=25,sn={4488},x=4200}
T[1395]={d="Bring the Crate of Powerstones to Quartermaster Lungertz, before the powerstones expire.",en={5393},l=45,n="Supplies for Nethergarde",r=77,rl=40,sn={5464},su=6091,x=2900}
T[1396]={d="Kill 8 Young Sawtooth Crocolisks, 10 Sorrow Spinners and 10 Swamp Jaguars then return to Watcher Biggs in the Swamp of Sorrows.",en={5476},l=37,n="Encroaching Wildlife",nx=1421,ob={k={{1084},{858},{767}}},r=77,rl=30,sn={5476},x=2850}
T[1398]={d="Bring 8 pieces of Sundried Driftwood to Watcher Biggs in the Swamp of Sorrows.",en={5476},l=42,n="Driftwood",nx=1425,ob={i={{6146}}},ps={1421},r=77,rl=30,sn={5476},x=3450}
T[1418]={d="Speak with Neeka Bloodscar.",en={5394},l=35,n="Neeka Bloodscar",nx=1420,r=178,rl=30,sn={1442},x=1350}
T[1419]={d="Bring 30 Coyote Jawbones to Neeka Bloodscar in Kargath.",en={5394},l=40,n="Coyote Thieves",ob={i={{6166}}},r=178,rl=30,sn={5394},x=3150}
T[1420]={d="Bring Neeka's Report to Helgrum the Swift in Stonard.",en={1442},l=40,n="Report to Helgrum",r=178,rl=30,sn={5394},su=6167,x=2350}
T[1421]={d="Find the Caravan Chest in the Fallow Sanctuary, obtain the Wizards' Reagents and bring to Watcher Biggs.",en={5476},l=35,n="The Lost Caravan",nx=1398,ob={i={{6170}}},ps={1396},r=77,rl=30,sn={5476},x=2750}
T[1422]={d="Speak to Katar in the Swamp of Sorrows.",en={5593},l=45,n="Threat From the Sea",nx=1426,ps={699},r=178,rl=35,sn={5592}}
T[1423]={d="Bring the Lost Supplies to Quartermaster Lungertz.",en={5393},l=40,n="The Lost Supplies",r=77,rl=30,sf=1,si={6172},su=6172,x=0}
T[1424]={d="Fel'zerul in Stonard wants you to gather 10 Atal'ai Artifacts.",en={1443},l=43,n="Pool of Tears",nx=1429,ob={i={{6175}}},r=178,rl=38,sn={1443},tg=1,x=4450}
T[1425]={d="Bring the Shipment to Nethergarde to Quartermaster Lungertz in Nethergarde Keep.",en={5393},l=42,n="Deliver the Shipment",ps={1398},r=77,rl=30,sn={5476},su=6178,x=2550}
T[1426]={d="Kill 10 Marsh Murlocs, 10 Marsh Inkspewer, and 10 Marsh Flesheater, then return to Katar in the Swamp of Sorrows.",en={5593},l=43,n="Threat From the Sea",nx=1427,ob={k={{747},{750},{751}}},ps={1422},r=178,rl=35,sn={5593},x=4450}
T[1427]={d="Speak with Tok'Kar in the Swamp of Sorrows.",en={5592},l=43,n="Threat From the Sea",nx=1428,ps={1426},r=178,rl=35,sn={5593},x=3600}
T[1428]={d="Kill 10 Marsh Inkspewers, 10 Marsh Flesheaters, and 10 Marsh Oracles, then return to Katar in the Swamp of Sorrows.",en={5593},l=45,n="Continued Threat",ob={k={{750},{751},{752}}},ps={1427},r=178,rl=35,sn={5593},x=3900}
T[1429]={d="Bring the Bundle of Atal'ai Artifacts to the Atal'ai Exile in the Hinterlands.",en={5598},l=44,n="The Atal'ai Exile",nx=1444,ps={1424},r=178,rl=38,sn={1443},su=6193,x=3750}
T[1430]={d="Bring 10 Monstrous Crawler Legs to Dar in the Swamp of Sorrows.",en={5591},l=44,n="Fresh Meat",ob={i={{6184}}},r=178,rl=35,sn={5591},x=3750}
T[1431]={d="Speak to Keldran in Orgrimmar.",en={5640},l=30,n="Alliance Relations",nx=1432,r=178,rl=30,sn={5639},x=610}
T[1432]={d="Speak to Takata Steelblade in Desolace.",en={5641},l=30,n="Alliance Relations",nx=1433,ps={1431},r=178,rl=30,sn={5640},x=1200}
T[1433]={d="Speak to Maurin Bonesplitter in Desolace.",en={4498},l=33,n="Alliance Relations",nx=1435,ps={1432},r=178,rl=30,sn={5641},x=265}
T[1434]={d="Slay 7 Hatefury Rogues, 7 Hatefury Felsworn, 7 Hatefury Betrayers, and 7 Hatefury Hellcallers, and return to Takata Steelblade in Desolace.",en={5641},l=33,n="Befouled by Satyr",ob={k={{4670},{4672},{4673},{4675}}},ps={1432},r=178,rl=25,sn={5641},x=2650}
T[1435]={d="Return the Burning Gem and 15 Infused Burning Gems to Maurin Bonesplitter in Desolace.",en={4498},l=33,n="The Burning of Spirits",ob={i={{6435}}},ps={1433},r=178,rl=25,sn={4498},su=6436,x=2650}
T[1436]={d="Speak to Keldran in Orgrimmar.",en={5640},l=33,n="Alliance Relations",pg={1434,1435},r=178,rl=30,sn={5641},x=2650}
T[1437]={d="Find and search Tyranis and Dalinda Malem's wagon in Desolace.",eo={50961},l=33,n="Vahlarriel's Search",nx=1465,r=77,rl=30,sn={5642},x=1950}
T[1438]={d="Find Dalinda Malem in Desolace.",en={5644},l=33,n="Vahlarriel's Search",nx=1439,ps={1465},r=77,rl=30,sn={5642},x=2650}
T[1439]={d="Find Tyranis Malem in Desolace.",en={5644},l=33,n="Search for Tyranis",nx=1440,ob={i={{6767}}},ps={1438},r=77,rl=30,sn={5644},x=2650}
T[1440]={d="Escort Dalinda Malem from Thunder Axe Fortress and then return to Vahlarriel Demonslayer in Desolace.",en={5642},es=1,l=33,n="Return to Vahlarriel",ob={e={"Rescue Dalinda Malem",{{1443,58.3,30.9}}}},ps={1439},r=77,rl=30,sf=2,sn={5644},x=3300}
T[1442]={c=2,d="Bring a Kor Gem to Thundris Windweaver in Darkshore.",en={3649},l=22,n="Seeking the Kor Gem",ob={i={{6995}}},pa=1654,r=5,rl=20,sf=1,sn={3649},tg=81,x=435}
T[1444]={d="Return to Fel'Zerul in Stonard.",en={1443},l=44,n="Return to Fel'Zerul",nx=1445,ps={1429},r=178,rl=38,sn={5598},x=3750}
T[1445]={d="Collect 20 Fetishes of Hakkar and bring them to Fel'Zerul in Stonard.",en={1443},l=50,n="The Temple of Atal'Hakkar",ob={i={{6181}}},ps={1444},r=178,rl=38,sn={1443},tg=81,x=5900,z=1477}
T[1446]={d="The Atal'ai Exile in The Hinterlands wants the Head of Jammal'an.",en={5598},l=53,n="Jammal'an the Prophet",ob={i={{6212}}},r=0,rl=38,sn={5598},tg=81,x=6550,z=1477}
T[1447]={d="Defeat Dashel Stonefist in Stormwind.",en={4961},l=31,n="The Missing Diplomat",nx=1247,ob={k={{4961}}},ps={1246},r=77,rl=28,sf=2,sn={4961},x=1250}
T[1448]={d="Brohann Caskbelly in Stormwind wants you to search for the Temple of Atal'Hakkar.",en={5384},l=43,n="In Search of The Temple",nx=1449,ob={e={"Search for the Temple of Atal'Hakkar",{{1435,70.2,45.2,73.6,48.1,75.4,53.3,73.6,58.4}}}},r=77,rl=38,sf=2,sn={5384},tg=1,x=3600}
T[1449]={d="Speak with High Thane Falstad Wildhammer at Aerie Peak in the Hinterlands.",en={5635},l=43,n="To The Hinterlands",nx=1450,ps={1448},r=77,rl=38,sn={5384},x=1800}
T[1450]={d="Speak with Gryphon Master Talonaxe inside the Aerie Peak Aviary.",en={5636},l=43,n="Gryphon Master Talonaxe",nx=1451,ps={1449},r=77,rl=38,sn={5635},x=890}
T[1451]={d="Seek out Rhapsody Shindigger in The Hinterlands.",en={5634},l=43,n="Rhapsody Shindigger",nx=1452,ps={1450},r=77,rl=38,sn={5636},x=1800}
T[1452]={d="Rhapsody Shindigger in The Hinterlands wants you to bring him 3 Roc Gizzards, 3 Groddoc Livers and 3 Ironfur Livers.",en={5634},l=43,n="Rhapsody's Kalimdor Kocktail",nx=1469,ob={i={{6257},{6258},{6259}}},ps={1451},r=77,rl=38,sn={5634},x=3600}
T[1453]={d="Speak to Kreldig Ungor in Desolace.",en={5638},l=33,n="Reclaimers' Business in Desolace",r=77,rl=30,sn={5637},x=1300}
T[1454]={d="Find Karnitol's Chest in Desolace.",eo={35251},l=39,n="The Karnitol Shipwreck",nx=1455,ps={1453},r=77,rl=30,sn={5638},x=3000}
T[1455]={d="Return to Kreldig Ungor in Desolace.",en={5638},l=39,n="The Karnitol Shipwreck",nx=1456,ps={1454},r=77,rl=30,so={35251},x=1500}
T[1456]={d="Find Karnitol's Satchel and return it to Kreldig Ungor in Desolace.",en={5638},l=39,n="The Karnitol Shipwreck",nx=1457,ob={i={{6245}}},ps={1455},r=77,rl=30,sn={5638},x=3000}
T[1457]={d="Bring Karnitol's Satchel to Roetten Stonehammer in Ironforge.",en={5637},l=39,n="The Karnitol Shipwreck",ps={1456},r=77,rl=30,sn={5638},su=6245,x=1500}
T[1458]={d="Bring 10 Hatefury Claws, and 10 Hatefury Horns to Kreldig Ungor in Desolace.",en={5638},l=33,n="Reagents for Reclaimers Inc.",nx=1459,ob={i={{6246},{6247}}},ps={1453},r=77,rl=30,sn={5638},x=2650}
T[1459]={d="Bring 7 vials of Scorpashi Venom and 3 Aged Kodo Hides to Kreldig Ungor in Desolace.",en={5638},l=35,n="Reagents for Reclaimers Inc.",nx=1466,ob={i={{6248},{6249}}},ps={1458},r=77,rl=30,sn={5638},x=2750}
T[1462]={c=64,en={5888},l=4,n="Earth Sapta",pa=0,ps={1520},r=178,rl=4,sf=1,sn={5888}}
T[1463]={c=64,en={5887},l=4,n="Earth Sapta",pa=0,ps={1517},r=178,rl=4,sf=1,sn={5887}}
T[1464]={c=64,en={5900},l=13,n="Fire Sapta",pa=0,ps={1525},r=178,rl=10,sf=1,sn={5900}}
T[1465]={d="Return the Malem Pendant to Vahlarriel Demonslayer in Desolace.",en={5642},l=33,n="Vahlarriel's Search",nx=1438,ps={1437},r=77,rl=30,so={50961},su=6479,x=1950}
T[1466]={d="Bring 10 Felhound Brains, 10 Nether Wings, and 10 vials of Doomwarder Blood to Kreldig Ungor in Desolace.",en={5638},l=40,n="Reagents for Reclaimers Inc.",nx=1467,ob={i={{6250},{6251},{6252}}},ps={1459},r=77,rl=30,sn={5638},x=3150}
T[1467]={d="Bring Leftwitch's Package back to Roetten Stonehammer in Ironforge.",en={5637},l=40,n="Reagents for Reclaimers Inc.",ps={1466},r=77,rl=30,sn={5638},su=6253,x=3150}
T[1469]={d="Bring the Atal'ai Tablet Fragment to Brohann Caskbelly in Stormwind.",en={5384},l=43,n="Rhapsody's Tale",nx=1475,ps={1452},r=77,rl=38,sn={5634},su=6287,x=2700}
T[1470]={c=256,d="Bring Venya Marthand 3 Rattlecage Skulls.",en={5667},ex={1485},l=3,n="Piercing the Veil",ob={i={{6281}}},r=178,rl=1,sn={5667},x=190}
T[1471]={c=256,d="Using the Runes of Summoning, summon and subdue a voidwalker, then return the Runes of Summoning to Carendin Halgar in the Magic Quarter of the Undercity.",en={5675},l=10,n="The Binding",ob={k={{5676}}},ps={1473},r=16,rl=10,sn={5675},su=6284,x=630}
T[1472]={c=256,d="Speak with Godrick Farsan in the Temple of the Damned.",en={5693},ex={1507},l=-1,n="Devourer of Souls",nx=1476,r=178,rl=20,sn={5675},x=155}
T[1473]={c=256,d="Recover Egalin's Grimoire and bring it to Carendin Halgar in the Temple of the Damned.",en={5675},l=10,n="Creature of the Void",nx=1471,ob={i={{6285}}},r=16,rl=10,sn={5675},x=630}
T[1474]={c=256,d="Using the Pure Hearts, summon and subdue a succubus, then return the Pure Hearts to Carendin Halgar in the Magic Quarter of the Undercity.",en={5675},ex={1507},l=20,n="The Binding",ob={k={{5677}}},ps={1476},r=178,rl=20,sn={5675},su=6286,x=1550}
T[1475]={d="Gather 10 Atal'ai Tablets for Brohann Caskbelly in Stormwind.",en={5384},l=50,n="Into The Temple of Atal'Hakkar",ob={i={{6288}}},ps={1469},r=77,rl=41,sn={5384},tg=81,x=7100,z=1477}
T[1476]={c=256,d="Bring the hearts of Dalin Forgewright and Comar Villard to Carendin Halgar in the Temple of the Damned.",en={5675},ex={1507},l=-1,n="Hearts of the Pure",nx=1474,ob={i={{6312},{6313}}},ps={1472},r=178,rl=20,sn={5693},x=1550}
T[1477]={d="Speak with Watchmaster Sorigal.",en={5464},l=45,n="Vital Supplies",nx=1395,r=77,rl=40,sn={5694},x=970}
T[1478]={c=256,d="Speak with Carendin Halgar in the Undercity.",en={5675},l=10,n="Halgar's Summons",nx=1473,r=178,rl=10,sn={5724},x=210}
T[1480]={d="Bring the Flayed Demon Skin to Maurin Bonesplitter in Desolace.",en={4498},l=33,n="The Corrupter",nx=1481,r=178,rl=25,si={20310},su=20310,x=1300}
T[1481]={d="Bring a Shadowstalker Scalp to Maurin Bonesplitter in Desolace.",en={4498},l=33,n="The Corrupter",nx=1482,ob={i={{6441}}},ps={1480},r=178,rl=25,sn={4498},x=2650}
T[1482]={d="Bring an Oracle Crystal to Maurin Bonesplitter in Desolace.",en={4498},l=35,n="The Corrupter",nx=1484,ob={i={{6442}}},ps={1481},r=178,rl=25,sn={4498},x=2750}
T[1483]={d="Speak with Ziz Fizziks in Windshear Crag.",en={4201},l=21,n="Ziz Fizziks",nx=1093,r=0,rl=16,sn={3442},x=415}
T[1484]={d="Speak to Takata Steelblade in Desolace.",en={5641},l=35,n="The Corrupter",nx=1488,ps={1482},r=178,rl=25,sn={4498},x=275}
T[1485]={c=256,d="Bring 6 Vile Familiar Heads to Ruzan.",en={5765},ex={1470},l=4,n="Vile Familiars",nx=1499,ob={i={{6487}}},r=178,rl=1,sn={5765},x=355}
T[1486]={d="Nalpak in the Wailing Caverns wants 20 Deviate Hides.",en={5767},l=17,n="Deviate Hides",ob={i={{6443}}},r=0,rl=13,sn={5767},tg=81,x=1600,z=718}
T[1487]={d="Ebru in the Wailing Caverns wants you to kill 7 Deviate Ravagers, 7 Deviate Vipers, 7 Deviate Shamblers and 7 Deviate Dreadfangs.",en={5768},l=21,n="Deviate Eradication",ob={k={{3636},{5755},{5761},{5056}}},r=0,rl=15,sn={5768},tg=81,x=2050,z=718}
T[1488]={d="Slay Lord Azrethoc and Jugkar Grim'rod and return to Takata Steelblade in Desolace.",en={5641},l=40,n="The Corrupter",ob={k={{5760},{5771}}},ps={1484},r=178,rl=25,sn={5641},tg=1,x=3900}
T[1489]={d="Speak with Hamuul Runetotem.",en={5769},l=16,n="Hamuul Runetotem",nx=1490,ps={880},r=178,rl=12,sn={3448},x=290,z=718}
T[1490]={d="Speak with Nara Wildmane.",en={5770},l=16,n="Nara Wildmane",nx=914,ps={1489},r=178,rl=12,sn={5769},x=115,z=718}
T[1491]={d="Bring 6 portions of Wailing Essence to Mebok Mizzyrix in Ratchet.",en={3446},l=18,n="Smart Drinks",ob={i={{6464}}},ps={865},r=0,rl=13,sn={3446},tg=81,x=1350,z=718}
T[1492]={d="Bring the Secure Crate to Wharfmaster Dizzywig in Ratchet.",en={3453},l=11,n="Wharfmaster Dizzywig",r=178,rl=9,sn={3390},su=6462,x=440}
T[1498]={c=1,d="Bring 5 Singed Scales to Uzzek at Far Watch Post in the Barrens.",en={5810},ex={1819},l=10,n="Path of Defense",nx=1502,ob={i={{6486}}},r=178,rl=10,sn={5810}}
T[1499]={c=256,d="Speak with Zureetha Fargaze.",en={3145},l=4,n="Vile Familiars",nx=794,ps={1470,1485},r=178,rl=1,sn={5765},x=35}
T[1501]={c=256,d="Retrieve the Tablet of Verga for Gan'rul Bloodeye in Orgrimmar.",en={5875},l=11,n="Creature of the Void",nx=1504,ob={i={{6535}}},r=2,rl=10,sn={5875},x=880}
T[1502]={c=1,d="Speak with Thun'grim Firegaze in the Barrens.",en={5878},l=10,n="Thun'grim Firegaze",nx=1503,ps={1498,1819},r=178,rl=10,sn={5810},x=210}
T[1503]={c=1,d="Bring the Forged Steel Bars to Thun'grim Firegaze in the Barrens.",en={5878},l=10,n="Forged Steel",ob={i={{6534}}},ps={1502},r=178,rl=10,sn={5878},x=840}
T[1504]={c=256,d="Using the Glyphs of Summoning, summon and subdue a voidwalker, then return the Glyphs of Summoning to Gan'rul Bloodeye in Orgrimmar.",en={5875},l=11,n="The Binding",ob={k={{5676}}},ps={1501},r=2,rl=10,sn={5875},su=7464,x=660}
T[1505]={c=1,d="Speak with Uzzek at Far Watch Post.",en={5810},ex={1819},l=10,n="Veteran Uzzek",nx=1498,r=178,rl=10,sn={3041,3063,3169,3354},x=85}
T[1506]={c=256,d="Speak with Gan'rul Bloodeye in Orgrimmar.",en={5875},l=10,n="Gan'rul's Summons",nx=1501,r=178,rl=10,sn={3294},x=210}
T[1507]={c=256,d="Speak with Cazul in the Cleft of Shadow.",en={5909},ex={1472},l=-1,n="Devourer of Souls",nx=1508,r=178,rl=20,sn={5875},x=155}
T[1508]={c=256,d="Speak with Zankaja in Orgrimmar.",en={5910},ex={1472},l=-1,n="Blind Cazul",nx=1509,ps={1507},r=178,rl=20,sn={5909},x=390}
T[1509]={c=256,d="Speak with Gazrog at the Crossroads.",en={3464},ex={1472},l=20,n="News of Dogran",nx=1510,ps={1508},r=178,rl=20,sn={5910},x=390}
T[1510]={c=256,d="Speak with Ken'zigla at the Malaka'jin.",en={4197},ex={1472},l=20,n="News of Dogran",nx=1511,ps={1509},r=178,rl=20,sn={3464},x=780}
T[1511]={c=256,d="Bring Ken'zigla's Draught to Grunt Logmar at Camp Taurajo.",en={5911},ex={1472},l=20,n="Ken'zigla's Draught",nx=1515,ps={1510},r=178,rl=20,sn={4197},su=6624,x=1550}
T[1512]={c=256,d="Bring the Dirt-caked Pendant to Gan'rul Bloodeye in Orgrimmar.",en={5875},ex={1472},l=20,n="Love's Gift",nx=1513,ps={1515},r=178,rl=20,sn={5908},su=6625,x=390}
T[1513]={c=256,d="Using Dogran's Pendant, summon and subdue a succubus, then return Dogran's Pendant to Gan'rul Bloodeye in Orgrimmar.",en={5875},ex={1472},l=20,n="The Binding",ob={k={{5677}}},ps={1512},r=178,rl=20,sn={5875},su=6626,x=1150}
T[1514]={eo={174709},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174709},x=560}
T[1515]={c=256,d="Bring Ken'zigla's Draught to Dogran in the Barrens.",en={5908},ex={1472},l=20,n="Dogran's Captivity",nx=1512,ps={1511},r=178,rl=20,sn={5911},su=6624,x=1150}
T[1516]={c=64,d="Bring 2 Felstalker Hooves to Canaga Earthcaller in the Valley of Trials.",en={5887},ex={1519},l=4,n="Call of Earth",nx=1517,ob={i={{6640}}},r=178,rl=4,sn={5887},x=270}
T[1517]={c=64,d="Find Spirit Rock and drink the Earth Sapta.",en={5891},l=4,n="Call of Earth",nx=1518,ps={1516,1519},r=178,rl=4,sn={5887},su=6635,x=270}
T[1518]={c=64,d="Bring the Rough Quartz to Canaga Earthcaller in the Valley of Trials.",en={5887},l=4,n="Call of Earth",ps={1517},r=178,rl=4,rs={6635},sn={5891},su=6656,x=445}
T[1519]={c=64,d="Bring 2 applications of Ritual Salve to Seer Ravenfeather in Camp Narache.",en={5888},ex={1516},l=4,n="Call of Earth",nx=1520,ob={i={{6634}}},r=178,rl=4,sn={5888},x=270}
T[1520]={c=64,d="Find Kodo Rock and drink the Earth Sapta.",en={5891},l=4,n="Call of Earth",nx=1521,ps={1516,1519},r=178,rl=4,sn={5888},su=6635,x=180}
T[1521]={c=64,d="Bring the Rough Quartz to Seer Ravenfeather in Camp Narache.",en={5888},l=4,n="Call of Earth",ps={1520},r=178,rl=4,rs={6635},sn={5891},su=6656,x=445}
T[1522]={c=64,d="Find Kranal Fiss in the Barrens.",en={5907},ex={1523,2983,2984},l=10,n="Call of Fire",nx=1524,r=178,rl=10,sn={5892},x=420}
T[1523]={c=64,d="Find Kranal Fiss in the Barrens.",en={5907},ex={1522,2983,2984},l=10,n="Call of Fire",nx=1524,r=178,rl=10,sn={5906},x=420}
T[1524]={c=64,d="Bring the Torch of the Dormant Flame to Telf Joolam in Durotar.",en={5900},l=11,n="Call of Fire",nx=1525,r=178,rl=10,sn={5907},su=6653,x=660}
T[1525]={c=64,d="Bring 1 Fire Tar and 1 Reagent Pouch to Telf Joolam in Durotar.",en={5900},l=12,n="Call of Fire",nx=1526,ob={i={{5026},{6652}}},ps={1524},r=178,rl=10,sn={5900},x=910}
T[1526]={c=64,d="Defeat the Minor Manifestation of Fire, and place the Glowing Ember in the brazier atop the Shrine of Eternal Flame.",eo={61934},l=13,n="Call of Fire",nx=1527,ob={i={{6655}}},ps={1525},r=178,rl=10,rs={6636},sn={5900},su=6653,x=1150}
T[1527]={c=64,d="Bring the Torch of Eternal Flame to Kranal Fiss in the Barrens.",en={5907},l=13,n="Call of Fire",ps={1526},r=178,rl=10,so={61934},su=6654,x=1150}
T[1528]={c=64,d="Find Islen Waterseer in the Barrens.",en={5901},ex={1529,2985,2986},l=20,n="Call of Water",nx=1530,r=178,rl=20,sn={5892},x=780}
T[1529]={c=64,d="Find Islen Waterseer in the Barrens.",en={5901},ex={1528,2985,2986},l=20,n="Call of Water",nx=1530,r=178,rl=20,sn={5906},x=780}
T[1530]={c=64,d="Find Brine in Southern Barrens.",en={5899},l=22,n="Call of Water",nx=1535,r=178,rl=20,sn={5901},x=435}
T[1531]={c=64,d="Find Prate Cloudseer in Thousand Needles.",en={5905},ex={1532},l=30,n="Call of Air",r=178,rl=30,sn={5892},x=2450}
T[1532]={c=64,d="Find Prate Cloudseer in Thousand Needles.",en={5905},ex={1531},l=30,n="Call of Air",r=178,rl=30,sn={5906},x=2450}
T[1534]={c=64,d="Fill the Empty Blue Waterskin at the Ruins of Stardust in Ashenvale and return to Brine in the Barrens.",en={5899},l=23,n="Call of Water",nx=220,ob={i={{7770}}},ps={1536},r=178,rl=20,sn={5899},su=7767,x=1400}
T[1535]={c=64,d="Fill the Empty Brown Waterskin at the watering hole below Brine's hut and return it to her in the Barrens.",en={5899},l=22,n="Call of Water",nx=1536,ob={i={{7769}}},ps={1530},r=178,rl=20,sn={5899},su=7766,x=870}
T[1536]={c=64,d="Fill the Empty Red Waterskin at the well in Tarren Mill and return to Brine in the Barrens.",en={5899},l=22,n="Call of Water",nx=1534,ob={i={{7771}}},ps={1535},r=178,rl=20,sn={5899},su=7768,x=1300}
T[1559]={en={2817},l=37,n="Flash Bomb Recipe",ps={705},r=0,rl=30,sk={202,1},sn={2817}}
T[1560]={d="Show Tooga the way back to his wife, Torta.",en={6015},l=50,n="Tooga's Quest",ob={k={{6015}}},r=0,rl=40,sf=2,sn={5955},x=5900}
T[1578]={d="Bring 6 Copper Axes and 6 Copper Chain Belts to Thorvald in the southern guard tower of Loch Modan.",en={6030},l=12,n="Supplying the Front",ob={i={{2845},{2851}}},r=77,rl=1,sk={164,30},sn={6031},x=910}
T[1579]={d="Bring 8 Gaffer Jacks to Wizbang Cranktoggle in Auberdine.",en={3666},l=12,n="Gaffer Jacks",nx=1580,ob={i={{6717}}},r=77,rl=10,sk={356,30},sn={3666},x=455}
T[1580]={d="Bring 12 Electropellers to Wizbang Cranktoggle in Auberdine.",en={3666},l=12,n="Electropellers",ob={i={{6718}}},ps={1579},r=77,rl=10,sk={356,30},sn={3666},x=910}
T[1581]={d="Bring 6 Elixirs of Lion's Strength and 2 Elixirs of Minor Defense to Syral Bladeleaf in Dolanaar.",en={2083},l=8,n="Elixirs for the Bladeleafs",ob={i={{2454},{5997}}},r=77,rl=4,sk={171,20},sn={2083},x=700}
T[1582]={d="Bring 1 Embossed Leather Gloves, 5 Embossed Leather Boots and 5 Embossed Leather Cloaks to Lotherias in Darnassus.",en={6034},l=18,n="Moonglow Vest",ob={i={{4239},{2309},{2310}}},r=77,rl=8,sk={165,90},sn={6034},x=1350}
T[1598]={c=256,d="Retrieve the Powers of the Void for Drusilla La Salle.",en={459},ex={1599},l=4,n="The Stolen Tome",ob={i={{6785}}},r=77,rl=1,sn={459},x=355}
T[1599]={c=256,d="Bring 3 Feather Charms to Alamar Grimm in Anvilmar.",en={460},ex={1598},l=4,n="Beginnings",ob={i={{6753}}},r=77,rl=1,sn={460},x=355}
T[1618]={d="Tormus Deepforge wants you to bring 4 Runed Copper Belts and 4 Heavy Copper Mauls to Verner Osgood in Redridge.",en={415},l=16,n="Gearing Redridge",ob={i={{2857},{6214}}},r=77,rl=1,sk={164,60},sn={6031},x=1150}
T[1638]={c=1,d="Speak with Harry Burlguard.",en={6089},ex={1678,1683,1639},l=10,n="A Warrior's Training",nx=0,r=77,rl=10,sn={913,5480},x=85}
T[1639]={c=1,d="Speak with Bartleby.",en={6090},ex={1678,1683},l=10,n="Bartleby the Drunk",nx=1640,r=77,rl=10,sn={6089},x=85}
T[1640]={c=1,d="Beat Bartleby, then talk to him.",en={6090},l=10,n="Beat Bartleby",nx=1665,ob={k={{6090}}},ps={1639,1678,1683},r=77,rl=10,sf=2,sn={6090},x=210}
T[1641]={c=2,en={6171},l=12,n="The Tome of Divinity",nx=1642,r=1,rl=12,sf=1,sn={6171}}
T[1642]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},l=12,n="The Tome of Divinity",nx=1643,r=1,rl=12,si={6775},x=90}
T[1643]={c=2,d="Search the Trade District of Stormwind for Stephanie Turner.",en={6174},l=12,n="The Tome of Divinity",nx=1644,ps={1642},r=1,rl=12,sn={6171},x=455}
T[1644]={c=2,d="Bring 10 Linen Cloth to Stephanie Turner in Stormwind.",en={6174},l=13,n="The Tome of Divinity",nx=1780,ob={i={{2589}}},ps={1643},r=1,rl=12,sn={6174},x=910}
T[1645]={c=2,en={6179},l=12,n="The Tome of Divinity",nx=1646,r=4,rl=12,sf=1,sn={6179}}
T[1646]={c=2,d="Speak to Tiza Battleforge in Ironforge.",en={6179},l=12,n="The Tome of Divinity",nx=1647,r=4,rl=12,si={6916},x=90}
T[1647]={c=2,d="Search the outer ring of Ironforge for John Turner.",en={6175},l=12,n="The Tome of Divinity",nx=1648,ps={1646},r=4,rl=12,sn={6179},x=455}
T[1648]={c=2,d="Bring 10 Linen Cloth to John Turner in Ironforge.",en={6175},l=13,n="The Tome of Divinity",nx=1778,ob={i={{2589}}},ps={1647},r=4,rl=12,sn={6175},x=910}
T[1649]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},l=20,n="The Tome of Valor",nx=1650,r=5,rl=20,si={6776},x=390}
T[1650]={c=2,d="Find Daphne Stilwell in Westfall.",en={6182},l=23,n="The Tome of Valor",nx=1651,ps={1649},r=5,rl=20,sn={6171},x=1850}
T[1651]={c=2,d="Defend Daphne Stilwell from the Defias attack.",en={6182},l=25,n="The Tome of Valor",nx=1652,ob={e={"Protect Daphne Stilwell",{{1436,42.2,88.4}}}},ps={1650},r=5,rl=20,sf=2,sn={6182},x=1000}
T[1652]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},l=25,n="The Tome of Valor",nx=1653,ps={1651},r=5,rl=20,sn={6182},x=2550}
T[1653]={c=2,d="Speak to Jordan Stilwell in Ironforge",en={6181},l=21,n="The Test of Righteousness",nx=1654,ps={1652},r=5,rl=20,sn={6171},tg=81,x=830}
T[1654]={c=2,d="Using Jordan's Weapon Notes, find some Whitestone Oak Lumber, Bailor's Refined Ore Shipment, Jordan's Smithing Hammer, and a Kor Gem, and return them to Jordan Stilwell in Ironforge.",en={6181},l=22,n="The Test of Righteousness",nx=1806,ob={i={{6994},{6993},{6895},{7083}}},ps={1653},r=5,rl=20,sn={6181},su=6996,tg=81,x=2200}
T[1655]={c=2,d="Bring Jordan's Ore Shipment to Bailor Stonehand in Loch Modan.",en={6241},l=22,n="Bailor's Ore Shipment",ob={i={{6992}}},pa=1654,r=5,rl=20,sf=1,sn={6241},tg=1,x=435}
T[1656]={d="Bring the Bundle of Furs to Innkeeper Kauth in Bloodhoof Village.",en={6747},l=5,n="A Task Unfinished",r=178,rl=1,sn={6775},su=7626,x=110}
T[1661]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},ex={4485,4486},l=40,n="The Tome of Nobility",r=5,rl=40,sn={6171}}
T[1665]={c=1,d="Bring Bartleby's Mug to Burlguard",en={6089},l=10,n="Bartleby's Mug",nx=1666,ps={1640},r=77,rl=10,sn={6090},su=6781,x=420}
T[1666]={c=1,d="Speak with Marshal Haggard.",en={294},l=10,n="Marshal Haggard",nx=1667,ps={1665},r=77,rl=10,sn={6089},x=420}
T[1667]={c=1,d="Retrieve Haggard's Badge from Dead-tooth Jack's camp, and return to Marshal Haggard.",en={294},l=10,n="Dead-tooth Jack",ob={i={{6782}}},ps={1666},r=77,rl=10,rs={6783},sn={294},x=840}
T[1678]={c=1,d="Bring Vejrek's Head to Muren Stormpike in Ironforge.",en={6114},ex={1639,1683},l=11,n="Vejrek",nx=1680,ob={i={{6799}}},r=77,rl=10,sn={6114},x=1100}
T[1679]={c=1,d="Speak with Muren Stormpike.",en={6114},ex={1639,1683},l=10,n="Muren Stormpike",nx=1678,r=77,rl=10,sn={1229},x=85}
T[1680]={c=1,d="Speak with Tormus Deepforge.",en={6031},l=11,n="Tormus Deepforge",nx=1681,ps={1683,1678,1639},r=77,rl=10,sn={6114},x=90}
T[1681]={c=1,d="Bring a load of Umbral Ore to Tormus Deepforge in Ironforge.",en={6031},l=11,n="Ironband's Compound",nx=1682,ob={i={{6800}}},ps={1683,1678,1639},r=77,rl=10,sn={6031},x=660}
T[1682]={c=1,en={6031},l=10,n="Grey Iron Weapons",ps={1681},r=77,rl=10,sn={6031},x=630}
T[1683]={c=1,d="Bring the Horn of Vorlus to Elanaria in Darnassus.",en={4088},ex={1639,1678},l=10,n="Vorlus Vilehoof",nx=1686,ob={i={{6805}}},r=77,rl=10,sn={4088},x=840}
T[1684]={c=1,d="Speak with Elanaria.",en={4088},ex={1639,1678,1683},l=10,n="Elanaria",nx=0,r=77,rl=10,sn={2151,3598,3657},x=85}
T[1685]={c=256,d="Report to Gakin the Darkbinder in the Mage Quarter of Stormwind.",en={6122},l=10,n="Gakin's Summons",nx=1688,r=77,rl=10,sn={6121},x=420}
T[1686]={c=1,d="Bring 8 loads of Elunite Ore and the Medallion of Elura to Elanaria in Darnassus.",en={4088},l=10,n="The Shade of Elura",nx=1692,ob={i={{6808},{6809}}},ps={1683,1678,1639},r=77,rl=10,sn={4088},x=840}
T[1688]={c=256,d="Retrieve Surena's Choker for Gakin the Darkbinder in Stormwind.",en={6122},l=10,n="Surena Caledon",nx=1689,ob={i={{6810}}},r=77,rl=10,sn={6122},x=630}
T[1689]={c=256,d="Using the Bloodstone Choker, summon and subdue a voidwalker, then return the Bloodstone Choker to Gakin the Darkbinder in Stormwind.",en={6122},l=10,n="The Binding",ob={k={{5676}}},ps={1688},r=77,rl=10,sn={6122},su=6928,x=630}
T[1690]={d="Take down 10 Wastewander Bandits and Thieves east of Gadgetzan, then report back to Chief Engineer Bilgewhizzle.",en={7407},l=43,n="Wastewander Justice",nx=1691,ob={k={{5618},{5616}}},r=0,rl=40,sn={7407},x=3600}
T[1691]={d="Take down 10 Wastewander Shadow Mages, 8 Wastewander Rogues, and 6 Wastewander Assassins for Chief Engineer Bilgewhizzle in Gadgetzan.",en={7407},l=44,n="More Wastewander Justice",ob={k={{5615},{5623},{5617}}},ps={1690},r=0,rl=40,sn={7407},x=3750}
T[1692]={c=1,d="Bring the Case of Elunite to Smith Mathiel.",en={6142},l=10,n="Smith Mathiel",nx=1693,ps={1686},r=77,rl=10,sn={4088},su=6812,x=420}
T[1693]={c=1,en={6142},l=10,n="Weapons of Elunite",ps={1692},r=77,rl=10,sn={6142},x=630}
T[1698]={c=1,d="Speak with Yorus Barleybrew.",en={6166},l=20,n="Yorus Barleybrew",nx=1699,r=77,rl=20,sn={5113,5479,7315},x=155}
T[1699]={c=1,d="Enter the Rethban Caverns, reach the first fork, and return to Yorus Barleybrew within the time allowed.",en={6166},l=22,n="The Rethban Gauntlet",nx=1702,ob={e={"Enter the Rethban Caverns",{{1433,14.1,24.7}}}},r=77,rl=20,sf=2,sn={6166},x=1300}
T[1700]={c=1,d="Bring Furen's Notes to Grimand Elmore.",en={1416},l=28,n="Grimand Elmore",nx=1705,ps={1782},r=1,rl=20,sn={5413},su=6926,x=570}
T[1701]={c=1,d="Gather the materials Furen Longbeard requires, and bring them to him in Stormwind.",en={5413},l=28,n="Fire Hardened Mail",nx=1782,ob={i={{6838},{6839},{6840},{6841}}},ps={1702},r=77,rl=20,sn={5413},su=6842,tg=1,x=2300}
T[1702]={c=1,d="Bring the Cask of Scalder to Furen Longbeard.",en={5413},l=22,n="The Shieldsmith",nx=1701,ps={1699},r=77,rl=20,sn={6166},su=6843,x=435}
T[1703]={c=1,d="Bring Furen's Notes to Mathiel.",en={6142},l=28,n="Mathiel",nx=1710,ps={1782},r=8,rl=20,sn={5413},su=6926,x=1150}
T[1704]={c=1,d="Bring Furen's Notes to Klockmort Spannerspan.",en={6169},l=28,n="Klockmort Spannerspan",nx=1708,ps={1782},r=68,rl=20,sn={5413},su=6926,x=570}
T[1705]={c=1,d="Bring 20 vials of Burning Blood and 1 Burning Rock to Grimand Elmore in Stormwind.",en={1416},l=28,n="Burning Blood",nx=1706,ob={i={{6844},{6845}}},ps={1782},r=77,rl=20,sn={1416},x=2300}
T[1706]={c=1,en={1416},l=30,n="Grimand's Armor",ps={1705},r=77,rl=20,sn={1416},x=3050}
T[1707]={d="Bring 5 Wastewander Water Pouches to Spigot Operator Luglunket in Gadgetzan.",en={7408},l=44,n="Water Pouch Bounty",nx=1878,ob={i={{8483}}},r=0,rl=40,sn={7408},x=2800}
T[1708]={c=1,d="Bring 20 loads of Searing Coral to Klockmort Spannerspan in Ironforge.",en={6169},l=29,n="Iron Coral",nx=1709,ob={i={{6848}}},ps={1782},r=77,rl=20,sn={6169},x=1750}
T[1709]={c=1,en={6169},l=30,n="Klockmort's Creation",ps={1708},r=77,rl=20,sn={6169},x=3050}
T[1710]={c=1,d="Bring 20 Sunscorched Shells to Mathiel in Darnassus.",en={6142},l=30,n="Sunscorched Shells",nx=1711,ob={i={{6849}}},ps={1782},r=77,rl=20,sn={6142},x=1850}
T[1711]={c=1,en={6142},l=30,n="Mathiel's Armor",ps={1710},r=77,rl=20,sn={6142},x=3050}
T[1712]={c=1,d="Bring the items on Bath'rah's Parchment to Bath'rah the Windwatcher in Alterac.",en={6176},l=40,n="Cyclonian",nx=1713,ob={i={{3357},{3901},{6851}}},ps={1791},r=0,rl=30,rs={4480,4479,4481},sn={6176},su=6929,x=2350}
T[1713]={c=1,d="Bring the Whirlwind Heart to Bath'rah Windwatcher.",en={6176},l=40,n="The Summoning",nx=1792,ob={i={{6894}}},ps={1712},r=0,rl=30,sn={6176},tg=1,x=2350}
T[1714]={c=1,eo={89931},l=37,n="Essence of the Exile",ob={i={{4480},{4479},{4481}}},pa=1712,r=0,rl=30,sf=1,so={89931}}
T[1715]={c=256,d="Report to Gakin the Darkbinder in the Mage Quarter of Stormwind.",en={6122},ex={1688},l=10,n="The Slaughtered Lamb",r=77,rl=10,sn={6120},x=420}
T[1716]={c=256,d="Speak with Takar the Seer in the Barrens.",en={6244},l=-1,n="Devourer of Souls",nx=1738,r=77,rl=20,sn={6122},x=780}
T[1717]={c=256,d="Report to Gakin the Darkbinder in the Mage Quarter of Stormwind.",en={6122},ex={1716},l=20,n="Gakin's Summons",nx=0,r=77,rl=20,sn={6120},x=390}
T[1718]={c=1,d="Speak with Klannoc Macleod.",en={6236},l=30,n="The Islander",nx=1719,r=0,rl=30,sn={3041,3354,4595,5113,5479},x=610}
T[1719]={c=1,d="Kill Big Will, then speak to Klannoc Macleod on Fray Island.",en={6236},l=30,n="The Affray",nx=1791,ob={e={"Step on the grate to begin the Affray",{{1413,68.6,48.7}}},k={{6238}}},ps={1718},r=0,rl=30,sf=2,sn={6236},x=2450}
T[1738]={c=256,d="Retrieve the Heartswood from Ashenvale and bring it to Gakin the Darkbinder in the Mage Quarter of Stormwind.",en={6122},l=20,n="Heartswood",nx=1739,ob={i={{6912}}},ps={1716},r=77,rl=20,sn={6244},x=1550}
T[1739]={c=256,d="Using the Heartswood Core, summon and subdue a succubus, then return the Heartswood Core to Gakin the Darkbinder in the Slaughtered Lamb.",en={6122},l=20,n="The Binding",ob={k={{5677}}},ps={1738},r=77,rl=20,sn={6122},su=6913,x=1150}
T[1740]={c=256,d="Find 3 Soran'ruk Fragments and 1 Large Soran'ruk Fragment and return them to Doan Karhan in the Barrens.",en={6247},l=25,n="The Orb of Soran'ruk",ob={i={{6914},{6915}}},r=0,rl=20,sn={6247},tg=81,x=2550}
T[1758]={c=256,d="Speak with Krom Stoutarm in Ironforge.",en={6294},l=30,n="Tome of the Cabal",nx=1802,r=77,rl=30,sn={6251},x=610}
T[1778]={c=2,d="Speak to Tiza Battleforge in Ironforge.",en={6179},l=13,n="The Tome of Divinity",nx=1779,ps={1648},r=4,rl=12,sn={6175},x=230}
T[1779]={c=2,d="Take the Symbol of Life and speak to Muiredon Battleforge in Ironforge.",en={6178},l=13,n="The Tome of Divinity",nx=1783,ps={1778},r=4,rl=12,sn={6179},su=6866}
T[1780]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},l=13,n="The Tome of Divinity",nx=1781,ps={1644},r=1,rl=12,sn={6174},x=230}
T[1781]={c=2,d="Take the Symbol of Life to Gazin Tenorm in Stormwind.",en={6173},l=13,n="The Tome of Divinity",nx=1786,ps={1780},r=1,rl=12,sn={6171},su=6866}
T[1782]={c=1,en={5413},l=28,n="Furen's Armor",ps={1701},r=77,rl=20,sn={5413},x=3400}
T[1783]={c=2,d="Take the Symbol of Life and resurrect Narm Faulk in Dun Morogh.",en={6177},l=13,n="The Tome of Divinity",nx=1784,ob={k={{6177}}},ps={1779},r=4,rl=12,rs={6866},sn={6178},x=680}
T[1784]={c=2,d="Retrieve a Dark Iron Script from the Dark Iron dwarves near Helm's Bed, and return to Muiredon Battleforge in Ironforge.",en={6178},l=13,n="The Tome of Divinity",nx=1785,ob={i={{6847}}},ps={1783},r=4,rl=12,sn={6177},x=680}
T[1785]={c=2,d="Speak to Tiza Battleforge in Ironforge.",en={6179},l=13,n="The Tome of Divinity",ps={1784},r=4,rl=12,sn={6178},x=1150}
T[1786]={c=2,d="Take the Symbol of Life and resurrect Henze Faulk in Elwynn.",en={6172},l=13,n="The Tome of Divinity",nx=1787,ob={k={{6172}}},ps={1781},r=1,rl=12,rs={6866},sn={6173},x=680}
T[1787]={c=2,d="Retrieve a Defias Script from the Defias Rogue Wizards in Elwynn, and return to Gazin Tenorm in Stormwind.",en={6173},l=13,n="The Tome of Divinity",nx=1788,ob={i={{6846}}},ps={1786},r=1,rl=12,sn={6172},x=680}
T[1788]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},l=13,n="The Tome of Divinity",ps={1787},r=1,rl=12,sn={6173},x=1150}
T[1789]={c=2,en={6179},ex={1784},l=12,n="The Symbol of Life",ps={1779},r=4,rl=12,sf=1,sn={6179}}
T[1790]={c=2,en={6171},ex={1787},l=12,n="The Symbol of Life",ps={1781},r=1,rl=12,sf=1,sn={6171}}
T[1791]={c=1,d="Speak with Bath'rah the Windwatcher.",en={6176},l=30,n="The Windwatcher",nx=1712,ps={1719},r=0,rl=30,sn={6236},x=245}
T[1792]={c=1,en={6176},l=40,n="Whirlwind Weapon",ps={1713},r=0,rl=30,sn={6176},x=3900}
T[1793]={c=2,en={6171},l=20,n="The Tome of Valor",nx=1649,r=5,rl=20,sf=1,sn={6171}}
T[1794]={c=2,en={6179},l=20,n="The Tome of Valor",nx=1649,r=5,rl=20,sf=1,sn={6179}}
T[1795]={c=256,d="Using the Tome of the Cabal, summon and subdue a felhunter, then return the Tome of the Cabal to Strahad Farsan in Ratchet.",en={6251},l=30,n="The Binding",ob={k={{6268}}},ps={1805,1804},r=0,rl=30,sn={6251},su=6999,x=2450}
T[1796]={c=256,d="Bring Robes of the Arcana to Menara Voidrender in the Barrens.",en={6266},l=31,n="Components for the Enchanted Gold Bloodrobe",nx=4781,ob={i={{5770}}},r=0,rl=31,sn={6266},x=2500}
T[1798]={c=256,d="Speak with Strahad Farsan in the Barrens.",en={6251},l=30,n="Seeking Strahad",nx=1758,r=77,rl=30,sn={6120,6122},x=610}
T[1799]={c=256,d="Speak to Menara's acolytes inside the tower above Ratchet and choose one of their paths to follow.",en={6546},l=40,n="Fragments of the Orb of Orahil",nx=4961,ob={i={{7291}}},r=0,rl=35,sn={6266},x=3150}
T[1801]={c=256,d="Speak with Jorah Annison in the Undercity.",en={6293},l=30,n="Tome of the Cabal",nx=1803,r=178,rl=30,sn={6251},x=610}
T[1802]={c=256,d="Retrieve the Moldy Tome and Tattered Manuscript for Krom Stoutarm in Ironforge.",en={6294},l=30,n="Tome of the Cabal",nx=1804,ob={i={{6931},{6997}}},ps={1758},r=77,rl=30,sn={6294},x=2450}
T[1803]={c=256,d="Retrieve the Moldy Tome and Tattered Manuscript for Jorah Annison in the Undercity.",en={6293},l=30,n="Tome of the Cabal",nx=1805,ob={i={{6931},{6997}}},ps={1801},r=178,rl=30,sn={6293},x=2450}
T[1804]={c=256,d="Bring the Reconstructed Tome and 3 Rods of Channeling to Strahad Farsan in Ratchet.",en={6251},l=30,n="Tome of the Cabal",nx=1795,ob={i={{6930}}},ps={1802},r=77,rl=30,sn={6294},su=7006,x=2450}
T[1805]={c=256,d="Bring the Reconstructed Tome and 3 Rods of Channeling to Strahad Farsan in Ratchet.",en={6251},l=30,n="Tome of the Cabal",nx=1795,ob={i={{6930}}},ps={1803},r=178,rl=30,sn={6293},su=7006,x=2450}
T[1806]={c=2,d="Wait for Jordan Stilwell to finish forging a weapon for you.",en={6181},l=22,n="The Test of Righteousness",ps={1654},r=5,rl=20,sn={6181},x=2200}
T[1818]={c=1,d="Speak with Deathguard Dillinger in Brill.",en={1496},ex={1498},l=10,n="Speak with Dillinger",nx=1819,r=178,rl=10,sn={2131,4595},x=85}
T[1819]={c=1,d="Kill Ulag the Cleaver, then speak with Deathguard Dillinger.",en={1496},ex={1498},l=10,n="Ulag the Cleaver",nx=1820,ob={k={{6390}}},r=178,rl=10,sn={1496},x=840}
T[1820]={c=1,d="Speak with Coleman Farthing.",en={1500},l=10,n="Speak with Coleman",nx=1821,ps={1498,1819},r=178,rl=10,sn={1496},x=210}
T[1821]={c=1,d="Bring Coleman Farthing the Agamand Family Axe, the Agamand Family Sword, the Agamand Family Mace and the Agamand Family dagger.",en={1500},l=11,n="Agamand Heirlooms",nx=1822,ob={i={{7567},{7568},{7569},{7566}}},ps={1498,1819},r=178,rl=10,sn={1500},x=660}
T[1822]={c=1,en={1500},l=11,n="Heirloom Weapon",ps={1821},r=178,rl=10,sn={1500},x=880}
T[1823]={c=1,d="Speak with Ruga Ragetotem.",en={6394},l=20,n="Speak with Ruga",nx=1824,r=178,rl=20,sn={3041,3354,4595},x=155}
T[1824]={c=1,d="Bring 5 twitching antennae to Ruga Ragetotem at Camp Taurajo",en={6394},l=20,n="Trial at the Field of Giants",nx=1825,ob={i={{7119}}},r=178,rl=20,sn={6394},x=1550}
T[1825]={c=1,d="Speak with Thun'grim Firegaze in the Barrens.",en={5878},l=20,n="Speak with Thun'grim",nx=1838,ps={1824},r=178,rl=20,sn={6394},x=780}
T[1838]={c=1,d="Bring to Thun'grim Firegaze 15 Smoky Iron Ingots, 10 Powdered Azurite, 10 Iron Bars and a Vial of Phlogiston.",en={5878},l=30,n="Brutal Armor",nx=1848,ob={i={{7126},{7127},{3575},{6841}}},ps={1824},r=178,rl=20,sn={5878},su=7587,x=3650}
T[1839]={c=1,d="Speak with Ula'elek in Durotar.",en={6408},l=30,n="Ula'elek and the Brutal Gauntlets",nx=1842,ps={1848},r=178,rl=20,sn={5878},x=1200}
T[1840]={c=1,d="Speak with Orm Stonehoof in Thunder Bluff.",en={6410},l=30,n="Orm Stonehoof and the Brutal Helm",nx=1844,ps={1848},r=178,rl=20,sn={5878},x=1200}
T[1841]={c=1,d="Speak with Velora Nitely in the Undercity.",en={6411},l=30,n="Velora Nitely and the Brutal Legguards",nx=1846,ps={1848},r=178,rl=20,sn={5878},x=1200}
T[1842]={c=1,d="Bring 7 Uncloven Satyr Hooves to Ula'elek at Sen'jin Village in Durotar.",en={6408},l=30,n="Satyr Hooves",nx=1843,ob={i={{7128}}},ps={1848},r=178,rl=20,sn={6408},x=1200}
T[1843]={c=1,en={6408},l=30,n="Brutal Gauntlets",ps={1842},r=178,rl=20,sn={6408},x=1850}
T[1844]={c=1,d="Bring a Galvanized Horn to Orm Stonehoof in Thunder Bluff.",en={6410},l=30,n="Chimaeric Horn",nx=1845,ob={i={{6840}}},ps={1848},r=178,rl=20,sn={6410},x=1200}
T[1845]={c=1,en={6410},l=30,n="Brutal Helm",ps={1844},r=178,rl=20,sn={6410},x=1850}
T[1846]={c=1,d="Bring 8 Sturdy Dragonmaw Shinbones to Velora Nitely in the Undercity.",en={6411},l=30,n="Dragonmaw Shinbones",nx=1847,ob={i={{7134}}},ps={1848},r=178,rl=20,rs={7131},sn={6411},x=1200}
T[1847]={c=1,en={6411},l=30,n="Brutal Legguards",ps={1846},r=178,rl=20,sn={6411},x=1850}
T[1848]={c=1,en={5878},l=30,n="Brutal Hauberk",ps={1838},r=178,rl=20,sn={5878},x=3050}
T[1858]={c=8,d="Steal Tazan's key, then use it to open his Satchel and deliver its contents to Therzok in the Cleft of Shadow in Orgrimmar.",en={6446},l=13,n="The Shattered Hand",ob={i={{7295}}},ps={1963},r=130,rl=10,rs={7208},sn={6446},su=7209,x=455}
T[1859]={c=8,d="Speak with Therzok in the Cleft of Shadow in Orgrimmar.",en={6446},ex={1885},l=10,n="Therzok",nx=1963,r=2,rl=10,sn={3170},x=210}
T[1860]={c=128,d="Speak with Jennea Cannon in Stormwind.",en={5497},ex={1880},l=10,n="Speak with Jennea",nx=1861,r=65,rl=10,sn={328},x=420}
T[1861]={c=128,d="Bring a Mirror Lake sample to Jennea Cannon in Stormwind.",en={5497},ex={1880},l=10,n="Mirror Lake",ob={i={{7206}}},r=65,rl=10,sn={5497},su=7207,x=840}
T[1878]={en={7408},l=44,n="Water Pouch Bounty",ob={i={{8483}}},ps={1707},r=0,rl=40,sf=1,sn={7408},x=375}
T[1879]={c=128,d="Speak with Bink in Ironforge.",en={5144},ex={1861},l=10,n="Speak with Bink",nx=1880,r=65,rl=10,sn={1228},x=85}
T[1880]={c=128,d="Bring Bink her Mage-tastic Gizmonitor.",en={5144},ex={1861},l=10,n="Mage-tastic Gizmonitor",ob={i={{7226}}},r=65,rl=10,sn={5144},x=840}
T[1881]={c=128,d="Speak with Anastasia Hartwell.",en={4568},ex={1884},l=10,n="Speak with Anastasia",nx=1882,r=144,rl=10,sn={2128},x=85}
T[1882]={c=128,d="Bring Balnir Snapdragons to Anastasia Hartwell in the Mage Quarter of the Undercity.",en={4568},ex={1884},l=10,n="The Balnir Farmstead",ob={i={{7227}}},r=144,rl=10,sn={4568},x=840}
T[1883]={c=128,d="Speak with Un'thuwa.",en={5880},ex={1882},l=10,n="Speak with Un'thuwa",nx=1884,r=144,rl=10,sn={3049,7311},x=85}
T[1884]={c=128,d="Destroy 4 Ju-Ju Heaps, then return to Un'thuwa in Sen'jin Village.",en={5880},ex={1882},l=10,n="Ju-Ju Heaps",ob={o={{102986,"Ju-Ju Heaps Destroyed"}}},r=144,rl=10,sn={5880},x=840}
T[1885]={c=8,d="Speak with Mennet Carkad in the Rogues' Quarter of the Undercity.",en={6467},ex={1859},l=10,n="Mennet Carkad",nx=1886,r=16,rl=10,sn={2130},x=210}
T[1886]={c=8,d="Get Astor's Letter of Introduction and return it to Mennet Carkad in the Rogues' Quarter.",en={6467},l=13,n="The Deathstalkers",nx=1898,ob={i={{7231}}},r=16,rl=10,sn={6467},x=680}
T[1898]={c=8,d="Speak with Andron Gant in the Undercity.",en={6522},l=13,n="The Deathstalkers",nx=1899,ps={1886},r=16,rl=10,sn={6467},su=7231,x=230}
T[1899]={c=8,d="Bring Andron's Ledger to Mennet Carkad in the Rogues' Quarter of Undercity.",en={6467},l=13,n="The Deathstalkers",nx=1978,ob={i={{7294}}},ps={1898},r=16,rl=10,sn={6522},x=230}
T[1918]={d="Bring the Befouled Water Globe to Mastok Wrilehiss at Splintertree Post, Ashenvale.",en={12737},l=27,n="The Befouled Element",nx=824,r=178,rl=23,si={16408},su=16408,x=550}
T[1919]={c=128,d="Speak with Jennea Cannon in Stormwind.",en={5497},l=15,n="Report to Jennea",nx=1920,r=65,rl=15,sn={328,1228,7312},x=105}
T[1920]={c=128,d="Obtain a Cantation of Manifestation and a Chest of Containment coffers from behind Jennea Cannon. Bring 3 Filled Containment Coffers to Jennea at the Wizard's Sanctum.",en={5497},l=16,n="Investigate the Blue Recluse",nx=1921,ob={i={{7292},{7247},{7308}}},r=65,rl=15,sn={5497},x=1150}
T[1921]={c=128,d="Bring 10 Linen Cloth and the 6 Charged Rift Gems to Wynne Larson in Stormwind.",en={1309},l=15,n="Gathering Materials",nx=1941,ob={i={{2589},{7249}}},ps={1920},r=65,rl=15,sn={5497},x=800}
T[1938]={c=128,d="Bring Ur's Treatise on Shadow Magic to High Sorcerer Andromath in Stormwind.",en={5694},l=28,n="Ur's Treatise on Shadow Magic",nx=1940,ob={i={{7266}}},r=65,rl=26,sn={5694},x=2300}
T[1939]={c=128,d="Speak with High Sorcerer Andromath.",en={5694},l=26,n="High Sorcerer Andromath",nx=1938,r=65,rl=26,sn={5144,5497},x=1050}
T[1940]={c=128,d="Bring 8 Pristine Spider Silk to Wynne Larson in Stormwind.",en={1309},l=26,n="Pristine Spider Silk",nx=1942,ob={i={{7267}}},ps={1938},r=65,rl=26,sn={5694},x=1600}
T[1941]={c=128,en={1309},l=15,n="Manaweave Robe",ps={1921},r=65,rl=15,sn={1309},x=1050}
T[1942]={c=128,en={1309},l=26,n="Astral Knot Garment",ps={1940},r=65,rl=26,sn={1309},x=2100}
T[1943]={c=128,d="Speak with Deino.",en={5885},l=26,n="Speak with Deino",nx=1944,r=144,rl=26,sn={4568},x=210}
T[1944]={c=128,d="Bring the Xavian Water Sample to Deino in Orgrimmar.",en={5885},l=26,n="Waters of Xavian",nx=1945,ob={i={{7268}}},r=144,rl=26,sn={5885},su=7269,x=2100}
T[1945]={c=128,d="Bring 12 Laughing Sister's Hairs to Kil'hala at the Crossroads.",en={3484},l=26,n="Laughing Sisters",nx=1946,ob={i={{7270}}},ps={1944},r=144,rl=26,sn={5885},x=1600}
T[1946]={c=128,en={3484},l=26,n="Nether-lace Garment",ps={1945},r=144,rl=26,sn={3484},x=2100}
T[1947]={c=128,d="Speak with Tabetha.",en={6546},l=38,n="Journey to the Marsh",r=0,rl=30,sn={3048,4568,5885,5144,5497},x=285}
T[1948]={c=128,d="Bring 1 Jade and the Bolt Charged Bramble to Tabetha in Dustwallow Marsh.",en={6546},l=40,n="Items of Power",ob={i={{1529},{7272}}},ps={1947},r=0,rl=30,rs={7273},sn={6546},su=7516,x=3150}
T[1949]={c=128,d="Speak with Magus Tirth in the Shimmering Flats.",en={6548},l=38,n="Hidden Secrets",nx=1950,ps={1947},r=0,rl=30,sn={6546},x=1450}
T[1950]={c=128,d="Find the phrase to Tirth's strongbox, then return to Tirth.",en={6548},l=30,n="Get the Scoop",nx=1951,ob={k={{6626}}},ps={1949},r=0,rl=30,sf=2,sn={6548},x=1850}
T[1951]={c=128,d="Bring the book Rituals of Power to Tabetha in Dustwallow Marsh.",en={6546},l=40,n="Rituals of Power",ob={i={{7274}}},ps={1950},r=0,rl=30,sn={6548},tg=81,x=3150,z=796}
T[1952]={c=128,d="Speak with Tabetha after her ritual.",en={6546},l=40,n="Mage's Wand",pg={1948,1951},r=0,rl=30,sn={6546},x=3150}
T[1953]={c=128,d="Speak with Tabetha.",en={6546},l=40,n="Return to the Marsh",nx=1954,r=0,rl=35,sn={3048,4568,5885,5144,5497},x=315}
T[1954]={c=128,d="Bring an Infernal Orb to Tabetha in Dustwallow Marsh.",en={6546},l=40,n="The Infernal Orb",nx=1955,ob={i={{7291}}},r=0,rl=35,sn={6546},x=2350}
T[1955]={c=128,d="Kill the Demon of the Orb, then speak with Tabetha.",en={6546},l=40,n="The Exorcism",nx=1956,ob={e={"Kill the Demon of the Orb",{{1445,45.6,57.2}}},k={{6549}}},ps={1954},r=0,rl=35,sn={6546},tg=1,x=2350}
T[1956]={c=128,d="Retrieve an Obsidian Power Source and bring it to Tabetha in Dustwallow Marsh.",en={6546},l=40,n="Power in Uldaman",nx=1957,ob={i={{8053}}},ps={1955},r=0,rl=35,sn={6546},tg=81,x=3900,z=1337}
T[1957]={c=128,d="Kill 12 Mana Surges in the allowed time limit.",en={6546},l=40,n="Mana Surges",nx=1958,ob={k={{6550}}},ps={1956},r=0,rl=35,sn={6546},x=2350}
T[1958]={c=128,en={6546},l=40,n="Celestial Power",ps={1957},r=0,rl=35,sn={6546},x=3150}
T[1959]={c=128,d="Speak with Anastasia Hartwell.",en={4568},l=15,n="Report to Anastasia",nx=1960,r=144,rl=15,sn={2128,3049,5880,7311},x=105}
T[1960]={c=128,d="Obtain a Cantation of Manifestation and a Chest of Containment Coffers from behind Anastasia Hartwell. Bring 3 Filled Containment Coffers, the Chest of Containment Coffers and the Cantation of Manifestation to Anastasia in the Undercity.",en={4568},l=16,n="Investigate the Alchemist Shop",nx=1961,ob={i={{7292},{7247},{7308}}},r=144,rl=15,sn={4568},x=1150}
T[1961]={c=128,d="Bring 10 Linen Cloth and 6 Dalaran Mana Gems to Josef Gregorian.",en={4576},l=15,n="Gathering Materials",nx=1962,ob={i={{2589},{7293}}},ps={1960},r=144,rl=15,sn={4568},x=800}
T[1962]={c=128,en={4576,11048,11049},l=15,n="Spellfire Robes",ps={1961},r=144,rl=15,sn={4576,11048,11049},x=1050}
T[1963]={c=8,d="Kill Tazan and bring his Satchel to Therzok in the Cleft of Shadow in Orgrimmar.",en={6446},l=13,n="The Shattered Hand",nx=1858,ob={i={{7209}}},r=130,rl=10,sn={6446},x=680}
T[1978]={c=8,d="Deliver Andron's Ledger to Varimathras in the Hall of the Dark Lady in the Undercity.",en={2425},l=13,n="The Deathstalkers",ps={1899},r=16,rl=10,sn={6467},su=7294,x=910}
T[1998]={c=8,d="Kill Fenwick Thatros and bring his head back to Mennet Carkad in the Rogues' Quarter of the Undercity.",en={6467},l=16,n="Fenwick Thatros",nx=1999,ob={i={{7306}}},r=16,rl=16,sn={6467},x=880}
T[1999]={c=8,d="Find the Dalaran Status Report and return it to Mennet Carkad in the Rogues' Quarter of the Undercity.",en={6467},l=20,n="Tools of the Trade",ob={i={{7309}}},ps={1998},r=16,rl=16,rs={5060},sn={6467},x=1550}
T[2038]={d="Find and return Bingles' supplies:",en={6577},l=15,n="Bingles' Missing Supplies",ob={i={{7343},{7345},{7346},{7376}}},r=77,rl=12,sn={6577},x=1050}
T[2039]={d="Find Bingles Blastenheimer in Loch Modan.",en={6577},l=15,n="Find Bingles",nx=2038,r=77,rl=12,sn={6569},x=270}
T[2040]={d="Retrieve the Gnoam Sprecklesprocket from the Deadmines and return it to Shoni the Shilent in Stormwind.",en={6579},l=20,n="Underground Assault",ob={i={{7365}}},r=77,rl=15,sn={6579},tg=81,x=1550,z=1581}
T[2041]={d="Speak with Shoni the Shilent in Stormwind.",en={6579},l=15,n="Speak with Shoni",nx=2040,r=77,rl=15,sn={6569},x=270}
T[2078]={d="Find Gelkak's First Mate, the Threshwackonator 4100, and lead it back to Gelkak.",en={6667},l=20,n="Gyromast's Revenge",ob={k={{6669,"Gelkak's First Mate"}}},ps={2098},r=77,rl=14,sn={6667},su=7442,tg=1,x=1150}
T[2098]={d="Find and return the three pieces of Gelkak's Key to Gelkak Gyromast.",en={6667},l=20,n="Gyromast's Retrieval",nx=2078,ob={i={{7498},{7499},{7500}}},r=77,rl=14,sn={6667},x=1550}
T[2118]={d="Capture a living Rabid Thistle Bear and bring it back to Tharnariun.",en={3701},l=14,n="Plagued Lands",nx=2138,ob={k={{2164}}},r=77,rl=10,sn={3701},su=7586,x=980}
T[2138]={d="Cleanse the forest of 20 Rabid Thistle Bears and return to Tharnariun Treetender in Darkshore.",en={3701},l=16,n="Cleansing of the Infected",nx=2139,ob={k={{2164}}},ps={2118},r=77,rl=10,sn={3701},x=1150}
T[2139]={d="Find and kill the Den Mother.",en={3701},l=18,n="Tharnariun's Hope",ob={k={{6788}}},ps={2138},r=77,rl=10,sn={3701},x=1350}
T[2158]={d="Speak with Innkeeper Farley at the Lion's Pride Inn.",en={295},l=5,n="Rest and Relaxation",r=77,rl=1,sn={6774},x=110}
T[2159]={d="Bring the Dolanaar Delivery to Innkeeper Keldamyr.",en={6736},l=5,n="Dolanaar Delivery",r=77,rl=1,sn={6780},su=7627,x=110}
T[2160]={d="Deliver the Crate of Inn Supplies to Tannok Frosthammer in Kharanos.",en={6806},l=5,n="Supplies to Tannok",r=77,rl=1,sn={6782},su=7646,x=110}
T[2161]={d="Bring Ukor's Burden to Innkeeper Grosk in Razor Hill.",en={6928},l=5,n="A Peon's Burden",r=178,rl=1,sn={6786},su=7629,x=110}
T[2178]={d="Bring back 5 Strider Meat to Alanndarian Nightsong in Auberdine.",en={3702},l=12,n="Easy Strider Living",ob={i={{5469}}},r=77,rl=9,sk={185,10},sn={3702},x=910}
T[2198]={d="Search for the original creator of the shattered necklace to learn of its potential value.",en={6826},l=41,n="The Shattered Necklace",nx=2199,r=77,rl=37,si={7666},su=7666,tg=81,x=3300,z=1337}
T[2199]={d="Bring five silver bars to Talvash del Kissel in Ironforge.",en={6826},l=41,n="Lore for a Price",nx=2200,ob={i={{2842}}},ps={2198},r=77,rl=37,sn={6826},tg=81,x=2450,z=1337}
T[2200]={d="Search for clues as to the current disposition of Talvash's necklace within Uldaman. The slain paladin he mentioned was the person who had it last.",en={6912},l=42,n="Back to Uldaman",nx=2201,ps={2199},r=77,rl=37,sn={6826},su=7667,tg=81,x=2550,z=1337}
T[2201]={d="Find the ruby, sapphire, and topaz that are scattered throughout Uldaman. Once acquired, contact Talvash del Kissel remotely by using the Phial of Scrying he previously gave you.",eo={112877},l=43,n="Find the Gems",nx=2204,ob={i={{7669},{7670},{7671}}},ps={2200},r=77,rl=37,sn={6912},su=7668,tg=81,x=3600,z=1337}
T[2202]={d="Bring 12 Magenta Fungus Caps to Jarkal Mossmeld in Kargath.",en={6868},l=42,n="Uldaman Reagent Run",nx=2203,ob={i={{8047}}},ps={2258},r=178,rl=36,sn={6868},tg=81,x=3450,z=1337}
T[2203]={d="Use the empty thaumaturgy vessels on scorched guardian dragons found in the Badlands. Once you have them filled, bring them to Jarkal Mossmeld in Kargath.",en={6868},l=44,n="Badlands Reagent Run II",ob={i={{7867}}},ps={2202},r=178,rl=40,sk={171,210},sn={6868},su=7870,tg=1,x=3750}
T[2204]={d="Obtain a power source from the most powerful construct you can find in Uldaman, and deliver it to Talvash del Kissel in Ironforge.",en={6826},l=44,n="Restoring the Necklace",nx=2361,ob={i={{7672}}},ps={2201},r=77,rl=37,so={112877},tg=81,x=930,z=1337}
T[2205]={c=8,d="Deliver Keryn Sylvius's package to Master Mathias Shaw at the Stormwind Barracks.",en={332},l=10,n="Seek out SI: 7",nx=2206,r=77,rl=10,sn={917},su=7674,x=210}
T[2206]={c=8,d="Find the Defias Dockmaster and recover the Shipping Schedule for Master Mathias Shaw.",en={332},l=10,n="Snatch and Grab",ob={i={{7675}}},ps={2205},r=77,rl=10,sn={332},x=840}
T[2218]={c=8,d="Speak with Hulfdan Blackbeard in Ironforge.",en={5165},l=10,n="Road to Salvation",nx=2238,r=77,rl=10,sn={1234},x=420}
T[2238]={c=8,d="Find Onin MacHammar by Gnomeregan.",en={6886},l=10,n="Simple Subterfugin'",nx=2239,ps={2218},r=77,rl=10,sn={5165},x=840}
T[2239]={c=8,d="Take Onin's Report back to Hulfdan in Ironforge.",en={5165},l=10,n="Onin's Report",ps={2238},r=77,rl=10,sn={6886},su=7715,x=840}
T[2240]={d="Read Baelog's Journal, explore the hidden chamber, then report to Prospector Stormpike.",en={1356},l=40,n="The Hidden Chamber",r=77,rl=35,sf=2,sn={6906},tg=81,x=3900,z=1337}
T[2241]={c=8,d="Take Jannok's Rose to Syurna in Darnassus.",en={4163},l=10,n="The Apple Falls",nx=2242,r=77,rl=10,sn={3599},su=7735,x=420}
T[2242]={c=8,d="Find Sethir the Ancient and bring back any clues that you may discover to Syurna.",en={4163},l=10,n="Destiny Calls",ob={i={{7737}}},ps={2241},r=77,rl=10,sn={4163},x=840}
T[2258]={d="Bring 5 Buzzard Gizzards, 10 Crag Coyote Fangs, and 5 Rock Elemental Shards to Jarkal Mossmeld in Kargath, Badlands.",en={6868},l=39,n="Badlands Reagent Run",nx=2202,ob={i={{7847},{7846},{7848}}},r=178,rl=36,sn={6868},x=3000}
T[2259]={c=8,d="Contact Erion Shadewhisper in Darnassus.",en={4214},l=16,n="Erion Shadewhisper",nx=2260,r=77,rl=16,sn={3599},x=115}
T[2260]={c=8,d="Travel to Stormwind City and seek council with Renzik \"The Shiv.\"",en={6946},l=16,n="Erion's Behest",r=77,rl=16,sn={4214},x=580}
T[2278]={d="Speak with stone watcher and learn what ancient lore it keeps. Once you have learned what lore it has to offer, activate the Discs of Norgannon.",eo={131474},l=47,n="The Platinum Discs",ob={k={{7172}}},r=0,rl=40,sf=2,so={131474},tg=81,x=4200,z=1337}
T[2279]={d="Take the miniature version of the Discs of Norgannon to the Explorers' League in Ironforge.",en={5387},l=47,n="The Platinum Discs",nx=2439,ps={2278},r=77,rl=40,so={131474},su=6064,x=5250,z=1337}
T[2280]={d="Take the miniature version of the Discs of Norgannon to the one of the sages in Thunder Bluff.",en={3978},l=47,n="The Platinum Discs",nx=2440,ps={2278},r=178,rl=40,so={131474},su=6064,tg=81,x=5250,z=1337}
T[2281]={c=8,d="Venture forth to Lakeshire in the Redridge Mountains and speak with Lucius.",en={6966},l=16,n="Redridge Rendezvous",nx=2282,r=77,rl=16,sn={6946},x=115}
T[2282]={c=8,d="Open Lucius's Lockbox, recover the Token of Thievery and return it to Lucius in Lakeshire.",en={6966},l=20,n="Alther's Mill",ob={i={{7871}}},ps={2281},r=77,rl=16,sn={6966},su=5060,x=1550}
T[2283]={d="Look for a valuable necklace within the Uldaman dig site and bring it back to Dran Droffers in Orgrimmar. The necklace may be damaged.",en={6986},l=41,n="Necklace Recovery",nx=2284,ob={i={{7666}}},r=178,rl=37,sn={6986},tg=81,x=2450,z=1337}
T[2284]={d="Find a clue as to the gems' whereabouts in the depths of Uldaman.",en={6912},l=41,n="Necklace Recovery, Take 2",nx=2318,ps={2283},r=178,rl=37,sn={6986},tg=81,x=2450,z=1337}
T[2298]={c=8,d="Travel to Stormwind and seek out Renzik \"The Shiv.\"",en={6946},l=16,n="Kingly Shakedown",r=77,rl=16,sn={5165},x=115}
T[2299]={c=8,d="Travel to Ironforge and speak with Hulfdan Blackbeard.",en={5165},l=16,n="To Hulfdan!",nx=2298,r=77,rl=16,sn={1234},x=115}
T[2300]={c=8,d="Travel to Stormwind and seek out Renzik \"The Shiv.\"",en={6946},l=16,n="SI:7",nx=0,r=77,rl=16,sn={917},x=115}
T[2318]={d="Find someone who can translate the paladin's journal. The closest location that might have someone is Kargath, in the Badlands.",en={6868},l=42,n="Translating the Journal",nx=2338,ps={2284},r=178,rl=37,sn={6912},su=7886,tg=81,x=860,z=1337}
T[2338]={d="Let Jarkal borrow the necklace. In exchange, he will translate the journal for you.",en={6868},l=42,n="Translating the Journal",nx=2339,ps={2318},r=178,rl=37,sn={6868},su=7886,tg=81,x=345,z=1337}
T[2339]={d="Recover all three gems and a power source for the necklace from Uldaman, and then bring them to Jarkal Mossmeld in Kargath. Jarkal believes a power source might be found on the strongest construct present in Uldaman.",en={6868},l=44,n="Find the Gems and Power Source",nx=2340,ob={i={{7669},{7670},{7671},{7672}}},ps={2338},r=178,rl=37,sn={6868},su=7668,tg=81,x=3750,z=1337}
T[2340]={d="Deliver the Necklace and Gem Salvage to Dran Droffers in Orgrimmar.",en={6986},l=44,n="Deliver the Gems",nx=2341,ps={2339},r=178,rl=37,sn={6868},su=7887,tg=81,x=1850,z=1337}
T[2341]={d="Visit Jarkal Mossmeld in Kargath to see if he was successful.",en={6868},l=44,n="Necklace Recovery, Take 3",ps={2340},r=178,rl=40,sn={6986},tg=81,x=5600,z=1337}
T[2342]={d="Get Patrick Garrett's family treasure from their family chest in the South Common Hall of Uldaman, and bring it to him in the Undercity.",en={5651},l=43,n="Reclaimed Treasures",ob={i={{8026}}},r=178,rl=33,sn={5651},tg=81,x=3600,z=1337}
T[2359]={c=8,d="Steal the Defias Tower Key, break into the Defias Tower and uncover the contents of the Duskwood Chest. Take whatever information you find back to Mathias Shaw in Stormwind. Read Kearnen's Journal to gain insight about the tower.",en={332},l=24,n="Klaven's Tower",nx=2607,ob={i={{7908},{7923}}},ps={2360},r=77,rl=20,sn={7024},su=8046,tg=1,x=1950}
T[2360]={c=8,d="Travel to Westfall and find Agent Kearnen for your debriefing.",en={7024},l=20,n="Mathias and the Defias",nx=2359,r=77,rl=20,sn={332},x=390}
T[2361]={en={6826},l=44,n="Restoring the Necklace",ps={2204},r=77,rl=37,sn={6826},tg=81,x=5600,z=1337}
T[2378]={c=8,d="Journey to Orgrimmar and speak with Shenthul at the Cleft of Shadow.",en={3401},ex={2380},l=16,n="Find the Shattered Hand",nx=0,r=178,rl=16,sn={6467},x=115}
T[2379]={c=8,d="Speak with Zando'zan at the Cleft of Shadow.",en={3402},l=16,n="Zando'zan",nx=2382,r=178,rl=16,sn={3401}}
T[2380]={c=8,d="Speak with Shenthul at the Cleft of Shadow in Orgrimmar.",en={3401},ex={2378},l=16,n="To Orgrimmar!",nx=0,r=178,rl=16,sn={3170},x=115}
T[2381]={c=8,d="Bring the Southsea Treasure back to Wrenix the Wretched in Ratchet. Do not forget to get an E.C.A.C. and Thieves' Tools from Wrenix's Gizmotronic Apparatus. You will need both of these items to complete your mission.",en={7161},l=18,n="Plundering the Plunderers",ob={i={{7968}}},ps={2382},r=178,rl=16,rs={7970,5060},sn={7161},x=1350}
T[2382]={c=8,d="Travel to Ratchet and speak with Wrenix the Wretched.",en={7161},l=16,n="Wrenix of Ratchet",nx=2381,ps={2379},r=178,rl=16,sn={3402},x=115}
T[2383]={c=1,d="Read the Simple Parchment and speak to Frang in the Valley of Trials.",en={3153},l=1,n="Simple Parchment",ps={788},r=2,rl=1,sn={3143},su=12635,x=40}
T[2398]={d="Find Baelog in Uldaman.",en={6906},l=40,n="The Lost Dwarves",nx=2240,r=77,rl=35,sn={1356},tg=81,x=315,z=1337}
T[2399]={eo={7510},l=10,n="The Sprouted Fronds",ps={931},r=77,rl=4,so={7510},x=85}
T[2418]={d="Bring 8 Dentrium Power Stones and 8 An'Alleum Power Stones to Rigglefuzz in the Badlands.",en={2817},l=36,n="Power Stones",ob={i={{8009},{8052}}},r=0,rl=30,sn={2817},tg=81,x=3500,z=1337}
T[2438]={d="Bring the Emerald Dreamcatcher to Tallonkai Swiftroot in Dolanaar.",en={3567},l=6,n="The Emerald Dreamcatcher",nx=2459,ob={i={{8048}}},r=77,rl=1,sf=0,sn={3567},x=405}
T[2439]={d="Take your reward voucher to Dinita Stonemantle in the Vault of Ironforge.",en={7292},l=47,n="The Platinum Discs",nx=2963,ps={2279},r=77,rl=40,sn={5387},su=8070,x=420}
T[2440]={d="Take the reward voucher to Bena Winterhoof in Thunder Bluff.",en={3009},l=47,n="The Platinum Discs",nx=2965,ps={2280},r=178,rl=40,sn={3978},su=8070,x=420}
T[2458]={c=8,d="Travel to the Venture Co. Tower, north of the Sludge Fen and contact the Shattered Hand's covert operative, Taskmaster Fizzule.",en={7233},l=20,n="Deep Cover",nx=2478,ps={2460},r=178,rl=20,sn={3401},su=8051,x=1150}
T[2459]={d="Tallonkai Swiftroot in Dolanaar wants you to kill 7 Gnarlpine Mystics and find the Missing Jewel.",en={3567},l=8,n="Ferocitas the Dream Eater",ob={i={{8050}},k={{7235}}},ps={2438},r=77,rl=1,rs={8049},sn={3567},x=880}
T[2460]={c=8,d="Perform the Shattered Salute on Shenthul.",en={3401},l=20,n="The Shattered Salute",nx=2458,ob={k={{3401}}},r=178,rl=20,sf=2,sn={3401},x=155}
T[2478]={c=8,d="Steal Silixiz's Tower Key from Foreman Silixiz, then kill two Mutated Venture Co. Drones, two Venture Co. Patrollers, and two Venture Co. Lookouts.",en={3401},l=24,n="Mission: Possible But Not Probable",nx=2479,ob={i={{8074},{8072},{8073}},k={{7310},{7307},{7308}}},ps={2458},r=178,rl=20,rs={8066},sn={7233},tg=1,x=1950}
T[2479]={c=8,d="Travel to Tarren Mill in Hillsbrad Foothills and deliver the Sample of Zanzil's Mixture to Serge Hinott.",en={2391},l=26,n="Hinott's Assistance",nx=2480,ps={2478},r=178,rl=20,sn={3401},su=8087,x=1050}
T[2480]={c=8,d="Wait for Serge Hinott to complete the cure.",en={2391},l=20,n="Hinott's Assistance",ob={e={"Cure Completed",{{1424,61.6,19.2}}}},ps={2479},r=178,rl=20,sf=2,sn={2391},x=155}
T[2498]={d="Rellian Greenspyre wants you to speak with Denalan at Lake Al'Ameth.",en={2080},l=9,n="Return to Denalan",nx=2499,ps={923},r=77,rl=4,sn={3517},x=80}
T[2499]={d="Denalan at Lake Al'Ameth wants you to collect the Gargantuan Tumor from Oakenscowl.",en={2080},l=9,n="Oakenscowl",ob={i={{8136}}},ps={2498},r=77,rl=4,sn={2080},tg=1,x=980}
T[2500]={d="Acquire the reagents Ghak Healtouch needs from the Badlands, then return to him in Thelsamar.",en={1470},l=39,n="Badlands Reagent Run",nx=17,ob={i={{7847},{7846},{7848}}},r=77,rl=36,sn={1470},x=3000}
T[2501]={d="Use the empty thaumaturgy vessels on scorched guardian dragons found in the Badlands. Once you have them filled, bring them to Ghak Healtouch in Thelsamar.",en={1470},l=44,n="Badlands Reagent Run II",ob={i={{7867}}},pg={2500,17},r=77,rl=40,sk={171,210},sn={1470},su=7870,tg=1,x=3750}
T[2518]={d="Priestess A'moora in the Temple of the Moon at Darnassus wants you to bring her Lady Sathrah's Silvery Spinnerets.",en={7313},l=12,n="Tears of the Moon",nx=2520,ob={i={{8344}}},r=77,rl=5,sn={7313},x=1150}
T[2519]={d="Sister Aquinne wants you to speak with Priestess A'moora in the Temple of the Moon.",en={7313},l=10,n="The Temple of the Moon",nx=2518,r=77,rl=5,sn={7316},x=85}
T[2520]={d="Priestess A'moora wants you to place Lady Sathrah's silvery spinnerets at the fountain inside the temple, and then return to her.",en={7313},l=12,n="Sathrah's Sacrifice",ob={o={{138498}}},ps={2518},r=77,rl=5,sf=2,sn={7313},su=8155,x=910}
T[2521]={d="In your journeys throughout the Blasted Lands, should you ever come across a Flawless Draenethyst Sphere, take the item back to Kum'isha the Collector.",en={7363},l=55,n="To Serve Kum'isha",nx=2522,ob={i={{8244}}},r=0,rl=45,sn={7363},x=8450}
T[2522]={d="Find and return a Flawless Draenethyst Sphere to Kum'isha the Collector.",en={7363},l=55,n="Kum'isha's Endeavors",ob={i={{8244}}},ps={2521},r=0,rl=45,sf=1,sn={7363},x=5650}
T[2523]={eo={164886},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={164886},x=560}
T[2541]={d="Bring a Shaman Voodoo Charm to Oben Rageclaw in the Ban'ethil Barrow Den.",en={7317},l=8,n="The Sleeping Druid",nx=2561,ob={i={{8363}}},r=77,rl=3,sn={7317},x=700}
T[2561]={d="Oben Rageclaw wants you to kill his soulless body, and then use the Voodoo Charm.",en={7317},l=10,n="Druid of the Claw",ob={k={{7318}}},ps={2541},r=77,rl=3,sf=2,sn={7317},su=8149,x=1050}
T[2581]={d="Bring three Snickerfang Jowls, two Blasted Boar Lungs, and one Scorpok Pincer to Bloodmage Drazial.",en={7505},l=50,n="Snickerfang Jowls",nx=2582,ob={i={{8391},{8392},{8393}}},r=0,rl=45,sn={7505},x=4700}
T[2582]={d="Bring three Snickerfang Jowls, two Blasted Boar Lungs, and one Scorpok Pincer to Bloodmage Drazial.",en={7505},l=50,n="Rage of Ages",ob={i={{8391},{8392},{8393}}},ps={2581},r=0,rl=45,sf=1,sn={7505}}
T[2583]={d="Bring three Blasted Boar Lungs, two Scorpok Pincers, and one Basilisk Brain to Bloodmage Drazial.",en={7505},l=50,n="A Boar's Vitality",nx=2584,ob={i={{8392},{8393},{8394}}},r=0,rl=45,sn={7505},x=4700}
T[2584]={d="Bring three Blasted Boar Lungs, two Scorpok Pincers, and one Basilisk Brain to Bloodmage Drazial.",en={7505},l=50,n="Spirit of the Boar",ob={i={{8392},{8393},{8394}}},ps={2583},r=0,rl=45,sf=1,sn={7505}}
T[2585]={d="Bring three Scorpok Pincers, two Vulture Gizzards, and one Blasted Boar Lung to Bloodmage Drazial.",en={7505},l=50,n="The Decisive Striker",nx=2586,ob={i={{8393},{8396},{8392}}},r=0,rl=45,sn={7505},x=4700}
T[2586]={d="Bring three Scorpok Pincers, two Vulture Gizzards, and one Blasted Boar Lung to Bloodmage Drazial.",en={7505},l=50,n="Salt of the Scorpok",ob={i={{8393},{8396},{8392}}},ps={2585},r=0,rl=45,sf=1,sn={7505}}
T[2601]={d="Bring ten Basilisk Brains and two Vulture Gizzards to Bloodmage Lynnore.",en={7506},l=50,n="The Basilisk's Bite",nx=2602,ob={i={{8394},{8396}}},r=0,rl=45,sn={7506},x=4700}
T[2602]={d="Bring ten Basilisk Brains and two Vulture Gizzards to Bloodmage Lynnore.",en={7506},l=50,n="Infallible Mind",ob={i={{8394},{8396}}},ps={2601},r=0,rl=45,sf=1,sn={7506}}
T[2603]={d="Bring ten Vulture Gizzards and two Snickerfang Jowls to Bloodmage Lynnore.",en={7506},l=50,n="Vulture's Vigor",nx=2604,ob={i={{8396},{8391}}},r=0,rl=45,sn={7506},x=4700}
T[2604]={d="Bring ten Vulture Gizzards and two Snickerfang Jowls to Bloodmage Lynnore.",en={7506},l=50,n="Spiritual Domination",ob={i={{8396},{8391}}},ps={2603},r=0,rl=45,sf=1,sn={7506}}
T[2605]={d="Collect a Laden Dew Gland and bring it to Marin Noggenfogger in Gadgetzan.",en={7564},l=49,n="The Thirsty Goblin",nx=2606,ob={i={{8428}}},r=0,rl=44,sn={7564},x=4550}
T[2606]={d="Marin Noggenfogger wants you to speak with Sprinkle in Gadgetzan.",en={7583},l=49,n="In Good Taste",nx=2641,ps={2605},r=0,rl=44,sn={7564},su=8603,x=455}
T[2607]={c=8,d="Speak with Doc Mixilpixil in the cellar of the Barracks.",en={7207},l=20,n="The Touch of Zanzil",nx=2608,ps={2359},r=77,rl=20,sn={332}}
T[2608]={c=8,d="/Lay down to be examined by Doc Mixilpixil. How can he find the cure if he can't find the cause?",en={7207},l=20,n="The Touch of Zanzil",nx=2609,ob={e={"Diagnosis Complete",{{1453,80.1,70.1}}}},ps={2607},r=77,rl=20,sf=2,sn={7207},x=155}
T[2609]={c=8,d="Bring Doc Mixilpixil one bundle of Simple Wildflowers, one Leaded Vial, one Bronze Tube, and one Spool of Light Chartreuse Silk Thread. The 'itis' doesn't cure itself, young <fella/lady>.",en={7207},l=20,n="The Touch of Zanzil",ob={i={{3421},{3372},{4371},{8431}}},ps={2608},r=77,rl=20,sn={7207},x=1150}
T[2621]={d="Speak to Dispatch Commander Ruag in Stonard.",en={7623},l=50,n="The Disgraced One",nx=2622,ps={2784},r=178,rl=45,sn={7572},x=1200}
T[2622]={d="Speak to Bengor.",en={7643},l=50,n="The Missing Orders",nx=2623,ps={2621},r=178,rl=45,sn={7623},x=1200}
T[2623]={d="Retrieve the Warchief's Orders and return them to the Fallen Hero of the Horde.",en={7572},l=55,n="The Swamp Talker",ob={i={{8463}}},ps={2622},r=178,rl=45,sn={7643},x=5650}
T[2641]={d="Sprinkle in Gadgetzan wants you to collect a Violet Tragan and return it to her.",en={7583},l=49,n="Sprinkle's Secret Ingredient",nx=2661,ob={i={{8526}}},ps={2606},r=0,rl=44,sn={7583},x=4550}
T[2661]={d="Sprinkle wants to you take the Violet Powder to Marin Noggenfogger in Gadgetzan.",en={7564},l=49,n="Delivery for Marin",nx=2662,ps={2641},r=0,rl=44,sn={7583},su=8528,x=455}
T[2662]={d="Marin Noggenfogger wants you to speak to him again after he creates his elixir.",en={7564},l=49,n="Noggenfogger Elixir",ps={2661},r=0,rl=44,sn={7564}}
T[2681]={d="Free nine Servants of Razelikh, three Servants of Sevine, three Servants of Allistarj, and three Servants of Grol. Return to the Fallen Hero when your task is complete. You must remain within close proximity of the stones or the process will fail.",en={7572},l=57,n="The Stones That Bind Us",nx=2702,ob={k={{7668,"Servants of Razelikh Freed"},{7669,"Servants of Grol Freed"},{7670,"Servants of Allistarj Freed"},{7671,"Servants of Sevine Freed"}}},ps={2801},r=0,rl=45,sn={7572},x=7550}
T[2701]={d="Open the chest and claim your reward.",eo={141980},l=57,n="Heroes of Old",nx=2721,ps={2702},r=0,rl=45,sn={7750},x=6000}
T[2702]={d="Speak to Corporal Thund Splithoof.",en={7750},l=57,n="Heroes of Old",nx=2701,ps={2681},r=0,rl=45,sn={7572},x=3000}
T[2721]={d="Find out what became of Lieutenant Kirith.",en={7729},l=58,n="Kirith",nx=2743,ps={2701},r=0,rl=45,sn={7572},tg=1,x=6200}
T[2741]={eo={142071},l=60,n="The Super Egg-O-Matic",ob={i={{8564}}},r=0,rl=42,so={142071},x=4950}
T[2742]={d="Escort Rin'ji out of the Quel'Danil Lodge, then find his hidden secret at the Overlook Cliffs to the east.",eo={142127},es=1,l=47,n="Rin'ji is Trapped!",nx=2782,ob={e={"Escort Rin'ji to safety",{{1425,34.6,56.3}}}},r=178,rl=42,sf=2,sn={7780},x=4200}
T[2743]={d="Return to the Fallen Hero of the Horde with your findings.",en={7572},l=60,n="The Cover of Darkness",nx=2744,ps={2721},r=0,rl=45,sn={7729},x=3300}
T[2744]={d="Speak with Loramus Thalipedes in Azshara.",en={7783},l=60,n="The Demon Hunter",nx=3141,ob={k={{7783}}},ps={2743},r=0,rl=45,sf=2,sn={7572},x=6600}
T[2745]={d="Speak to Tyrion in Stormwind Castle.",en={7766},l=31,n="Infiltrating the Castle",nx=2746,ps={350},r=77,rl=16,sn={482},x=250}
T[2746]={d="Bring 3 Silk Cloth and 2 of Clara's Fresh Apples to Tyrion in Stormwind.",en={7766},l=31,n="Items of Some Consequence",nx=434,ob={i={{4306},{8683}}},ps={2745},r=77,rl=16,sn={7766},x=630}
T[2747]={en={7763},l=60,n="An Extraordinary Egg",ob={i={{8643}}},ps={2741},r=0,rl=42,sf=1,sn={7763}}
T[2748]={en={7763},l=60,n="A Fine Egg",ob={i={{8644}}},ps={2741},r=0,rl=42,sf=1,sn={7763}}
T[2749]={en={7763},l=60,n="An Ordinary Egg",ob={i={{8645}}},ps={2741},r=0,rl=42,sf=1,sn={7763}}
T[2750]={en={7763},l=47,n="A Bad Egg",ob={i={{8646}}},ps={2741},r=0,rl=42,sf=1,sn={7763}}
T[2751]={d="Bring two Patterned Bronze Bracers, two Bronze Greatswords, and two Sharp Claws to Orokk Omosh in Orgrimmar.",en={7790},l=32,n="Barbaric Battlements",nx=2752,ob={i={{2868},{7957},{5635}}},r=178,rl=32,sk={164,140},sn={7790},x=2550}
T[2752]={d="Bring four Bronze Battleaxes and four Bronze Warhammers to Orokk Omosh in Orgrimmar.",en={7790},l=32,n="On Iron Pauldrons",nx=2753,ob={i={{7958},{7956}}},ps={2751},r=178,rl=32,sk={164,1},sn={7790},x=2550}
T[2753]={d="Bring four Green Iron Helms, four Green Iron Bracers, and two Green Iron Leggings to Orokk Omosh in Orgrimmar.",en={7790},l=36,n="Trampled Under Foot",nx=2754,ob={i={{3836},{3835},{3842}}},ps={2752},r=178,rl=32,sk={164,1},sn={7790},x=2800}
end)()
;(function() local T = D.Q
T[2754]={d="Bring two Solid Iron Mauls, two Silvered Bronze Boots, and two Silvered Bronze Gauntlets to Orokk Omosh in Orgrimmar.",en={7790},l=36,n="Horns of Frenzy",nx=2755,ob={i={{3851},{3482},{3483}}},ps={2753},r=178,rl=32,sk={164,1},sn={7790},x=2800}
T[2755]={d="Watch and learn the Omosh Dance of Joy.",en={7790},l=36,n="Joys of Omosh",ob={k={{7790}}},ps={2754},r=178,rl=32,sf=2,sk={164,1},sn={7790},x=280}
T[2756]={d="Bring four Steel Breastplates and four Steel Plate Helms to Aturk the Anvil in Orgrimmar.",en={7792},l=40,n="The Old Ways",nx=2757,ob={i={{7963},{7922}}},r=178,rl=40,sk={164,210},sn={7792},x=3150}
T[2757]={d="Speak with McGavan in Booty Bay.",en={7794},l=40,n="Booty Bay or Bust!",nx=2760,ps={2756},r=178,rl=40,sk={164,210},sn={7793},su=8663,x=1550}
T[2758]={d="Bring six Golden Scale Bracers to Hank the Hammer in Stormwind.",en={7798},l=40,n="The Origins of Smithing",nx=2759,ob={i={{6040}}},r=77,rl=40,sk={164,210},sn={7798},x=4700}
T[2759]={d="Speak with McGavan in Booty Bay.",en={7794},l=40,n="In Search of Galvan",nx=2760,ps={2758},r=77,rl=40,sk={164,210},sn={7798},su=8663,x=2350}
T[2760]={d="Speak with Galvan the Ancient in Stranglethorn Vale.",en={7802},l=40,n="The Mithril Order",ps={2757,2759},r=0,rl=40,sk={164,210},sn={7794},su=8686,x=3150}
T[2761]={d="Bring forty Mithril Bars and forty Iron Bars to Galvan the Ancient in Stranglethorn.",en={7802},l=45,n="Smelt On, Smelt Off",nx=2764,ob={i={{3575},{3860}}},ps={2760},r=0,rl=40,sk={164,210},sn={7802},x=3900}
T[2762]={d="Bring forty Mithril Bars and five Truesilver Bars to Galvan the Ancient in Stranglethorn.",en={7802},l=45,n="The Great Silver Deceiver",ob={i={{3860},{6037}}},ps={2760},r=0,rl=40,sk={164,210},sn={7802},x=3900}
T[2763]={d="Bring forty Mithril Bars and four Citrines to Galvan the Ancient in Stranglethorn.",en={7802},l=45,n="The Art of the Imbue",ob={i={{3860},{3864}}},ps={2760},r=0,rl=40,sk={164,210},sn={7802},x=3900}
T[2764]={d="Speak with Trenton Lighthammer in Gadgetzan.",en={7804},l=45,n="Galvan's Finest Pupil",ps={2761},r=0,rl=40,sk={164,210},sn={7802},x=2900}
T[2765]={d="Claim your reward from Galvan the Ancient!",en={7802},l=45,n="Expert Blacksmith!",ob={k={{7802}}},pg={2761,2762,2763},r=0,rl=40,sf=2,sk={164,210},sn={7802},x=3900}
T[2766]={d="Take the distress beacon to Oglethorpe's homing robot in a cave near Feral Scar Vale.",en={7807},l=45,n="Find OOX-22/FE!",nx=2767,r=0,rl=40,si={8705},su=8705,x=3900}
T[2767]={d="Escort OOX-22/FE to the dock along the Forgotten Coast, then report to Oglethorpe Obnoticus in Booty Bay.",en={7406},es=1,l=45,n="Rescue OOX-22/FE!",ob={e={"Escort OOX-22/FE to the dock along the Forgotten Coast",{{1444,45.6,43.4}}}},ps={2766},r=0,rl=40,sf=2,sn={7807},x=4850}
T[2768]={d="Bring the Divino-matic Rod to Chief Engineer Bilgewhizzle in Gadgetzan.",en={7407},l=47,n="Divino-matic Rod",ob={i={{8548}}},r=0,rl=40,sn={7407},tg=81,x=6300,z=1176}
T[2769]={d="Speak with Wizzle Brassbolts in the Shimmering Flats.",en={4453},l=46,n="The Brassbolts Brothers",nx=2770,r=77,rl=40,sn={6169},tg=81,x=405}
T[2770]={d="Bring Gahz'rilla's Electrified Scale to Wizzle Brassbolts in the Shimmering Flats.",en={4453},l=50,n="Gahz'rilla",ob={i={{8707}}},r=0,rl=40,sn={4453},tg=81,x=7100,z=1176}
T[2771]={d="Bring two Mithril Coifs and one Ornate Mithril Shoulder to Trenton Lighthammer.",en={7804},l=45,n="A Good Head On Your Shoulders",ob={i={{7931},{7928}}},ps={2764},r=0,rl=40,sk={164,210},sn={7804},x=3900}
T[2772]={d="Bring two Heavy Mithril Boots and one Ornate Mithril Pants to Trenton Lighthammer.",en={7804},l=45,n="The World At Your Feet",ob={i={{7933},{7926}}},ps={2764},r=0,rl=40,sk={164,210},sn={7804},x=3900}
T[2773]={d="Bring two Heavy Mithril Breastplates and one Ornate Mithril Gloves to Trenton Lighthammer.",en={7804},l=45,n="The Mithril Kid",ob={i={{7930},{7927}}},ps={2764},r=0,rl=40,sk={164,210},sn={7804},x=3900}
T[2781]={d="Bring the head of Caliph Scorpidsting to Chief Engineer Bilgewhizzle in Gadgetzan.",en={7407},l=46,n="WANTED: Caliph Scorpidsting",ob={i={{8723}}},r=0,rl=39,so={142122,150075},x=5050}
T[2782]={d="Oran Snakewrithe, a well known scholar on matters concerning the Witherbark trolls, may be able to decipher the tablet. She is known to reside within the Magic Quarter of the Undercity.",en={7825},l=47,n="Rin'ji's Secret",nx=8273,ps={2742},r=178,rl=42,so={142127},su=8724,x=2100}
T[2783]={d="Speak with the Fallen Hero of the Horde at the border of the Blasted Lands and the swamp.",en={7572},l=57,n="Petty Squabbles",nx=2801,r=77,rl=50,sn={7826},x=4500}
T[2784]={d="Listen to the Fallen Hero of the Horde tell his story.",en={7572},l=50,n="Fall From Grace",nx=2621,ob={k={{7572}}},r=178,rl=45,sf=2,sn={7572},x=470}
T[2801]={d="Listen to the Fallen Hero of the Horde tell his story.",en={7572},l=57,n="A Tale of Sorrow",nx=2681,ob={k={{7572}}},ps={2623,2783},r=0,rl=45,sf=2,sn={7572},x=600}
T[2821]={d="Bring 10 Thick Yeti Hides to Pratt McGrubben in Feathermoon Stronghold.",en={7852},l=46,n="The Mark of Quality",nx=7733,ob={i={{8973}}},r=77,rl=40,sn={7852},x=4050}
T[2822]={d="Bring 10 Thick Yeti Hides to Jangdor Swiftstrider in Camp Mojache.",en={7854},l=46,n="The Mark of Quality",nx=7734,ob={i={{8973}}},r=178,rl=40,sn={7854},x=4050}
T[2841]={d="Retrieve the Rig Blueprints and Thermaplugg's Safe Combination from Gnomeregan and bring them to Nogg in Orgrimmar.",en={3412},l=35,n="Rig Wars",ob={i={{9153},{9299}}},r=178,rl=25,sn={3412},tg=81,x=2750,z=721}
T[2842]={d="Speak with Scooty in Booty Bay.",en={7853},l=35,n="Chief Engineer Scooty",nx=2843,pa=0,r=178,rl=20,sn={3413},tg=81,x=275,z=721}
T[2843]={d="Wait for Scooty to calibrate the Goblin Transponder.",en={7853},l=35,n="Gnomer-gooooone!",ob={k={{7853}}},ps={2842},r=178,rl=20,sf=2,sn={7853},tg=81,z=721}
T[2844]={d="Locate the lost night elf girl.",en={7774},l=49,n="The Giant Guardian",nx=2845,r=77,rl=44,sn={7765},x=3400}
T[2845]={d="Pick up Shay's Bell from the chest.",en={7765},l=49,n="Wandering Shay",ob={e={"Take Shay Leafrunner to Rockbiter's camp",{{1444,42.3,21.9}}},i={{9189}}},ps={2844},r=77,rl=44,sf=2,sn={7774},x=4550}
T[2846]={d="Bring the Tiara of the Deep to Tabetha in Dustwallow Marsh.",en={6546},l=46,n="Tiara of the Deep",ob={i={{9234}}},r=0,rl=40,sn={6546},tg=81,x=6050,z=1176}
T[2847]={d="Bring 10 Thick Leather to Pratt McGrubben in Feathermoon Stronghold.",en={7852},l=45,n="Wild Leather Armor",ob={i={{4304}}},r=77,rl=30,sk={165,200},sn={7852},x=1950}
T[2848]={d="Bring 6 Thick Armor Kits and a Wildvine to Pratt McGrubben in Feathermoon Stronghold.",en={7852},l=45,n="Wild Leather Shoulders",ob={i={{8173},{8153}}},ps={2847},r=77,rl=30,sk={165,225},sn={7852},x=2900}
T[2849]={d="Bring 2 Turtle Scale Breastplates, 2 Turtle Scale Gloves, and a Wildvine to Pratt McGrubben in Feathermoon Stronghold.",en={7852},l=45,n="Wild Leather Vest",ob={i={{8189},{8187},{8153}}},ps={2847},r=77,rl=30,sk={165,225},sn={7852},x=2900}
T[2850]={d="Bring 2 Nightscape Tunics, 2 Nightscape Headbands, and a Wildvine to Pratt McGrubben in Feathermoon Stronghold.",en={7852},l=45,n="Wild Leather Helmet",ob={i={{8175},{8176},{8153}}},ps={2847},r=77,rl=30,sk={165,225},sn={7852},x=2900}
T[2851]={d="Bring 2 Nightscape Pants, 2 Nightscape Boots, and 2 Wildvines to Pratt McGrubben in Feathermoon Stronghold.",en={7852},l=45,n="Wild Leather Boots",ob={i={{8193},{8197},{8153}}},pg={2848,2849,2850},r=77,rl=30,sk={165,225},sn={7852},x=2900}
T[2852]={d="Bring 2 Turtle Scale Helms, 2 Turtle Scale Bracers, and 2 Wildvines to Pratt McGrubben in Feathermoon Stronghold.",en={7852},l=45,n="Wild Leather Leggings",ob={i={{8191},{8198},{8153}}},pg={2848,2849,2850},r=77,rl=30,sk={165,225},sn={7852},x=2900}
T[2853]={d="Give Pratt's Letter to Telonis, the master leatherworker of Darnassus.",en={4212},l=45,n="Master of the Wild Leather",nx=5143,pg={2851,2852},r=77,rl=30,sk={165,225},sn={7852},su=9235,x=3900}
T[2854]={d="Bring 10 Thick Leather to Jangdor Swiftstrider in Camp Mojache.",en={7854},l=45,n="Wild Leather Armor",ob={i={{4304}}},r=178,rl=30,sk={165,200},sn={7854},x=1950}
T[2855]={d="Bring 6 Thick Armor Kits and a Wildvine to Jangdor Swiftstrider in Camp Mojache.",en={7854},l=45,n="Wild Leather Shoulders",ob={i={{8173},{8153}}},ps={2854},r=178,rl=30,sk={165,225},sn={7854},x=2900}
T[2856]={d="Bring 2 Turtle Scale Breastplates, 2 Turtle Scale Gloves, and a Wildvine to Jangdor Swiftstrider in Camp Mojache.",en={7854},l=45,n="Wild Leather Vest",ob={i={{8189},{8187},{8153}}},ps={2854},r=178,rl=30,sk={165,225},sn={7854},x=2900}
T[2857]={d="Bring 2 Nightscape Tunics, 2 Nightscape Headbands, and a Wildvine to Jangdor Swiftstrider in Camp Mojache.",en={7854},l=45,n="Wild Leather Helmet",ob={i={{8175},{8176},{8153}}},ps={2854},r=178,rl=30,sk={165,225},sn={7854},x=2900}
T[2858]={d="Bring 2 Nightscape Pants, 2 Nightscape Boots, and 2 Wildvines to Jangdor Swiftstrider in Camp Mojache.",en={7854},l=48,n="Wild Leather Boots",ob={i={{8193},{8197},{8153}}},pg={2855,2856,2857},r=178,rl=30,sk={165,225},sn={7854},x=3300}
T[2859]={d="Bring 2 Turtle Scale Helms, 2 Turtle Scale Bracers, and 2 Wildvines to Jangdor Swiftstrider in Camp Mojache.",en={7854},l=45,n="Wild Leather Leggings",ob={i={{8191},{8198},{8153}}},pg={2855,2856,2857},r=178,rl=30,sk={165,225},sn={7854},x=2900}
T[2860]={d="Give Jangdor's Letter to Una, the master leatherworker of Thunder Bluff.",en={3007},l=45,n="Master of the Wild Leather",nx=5148,pg={2858,2859},r=178,rl=30,sk={165,225},sn={7854},su=9236,x=3900}
T[2861]={d="Speak with Tabetha in Dustwallow Marsh.",en={6546},l=46,n="Tabetha's Task",nx=2846,r=0,rl=40,sn={4568,5144,5497,5885},tg=81,x=405,z=1176}
T[2862]={d="Bring 10 Woodpaw Gnoll Manes to Hadoken Swiftstrider in Camp Mojache.",en={7875},l=42,n="War on the Woodpaw",nx=2863,ob={i={{9237}}},r=178,rl=39,sn={7875},x=2550}
T[2863]={d="Kill 5 Woodpaw Alphas and return to Hadoken Swiftstrider within one hour.",en={7875},l=43,n="Alpha Strike",nx=2902,ob={k={{5258}}},ps={2862},r=178,rl=39,sn={7875},x=2700}
T[2864]={d="Speak with Tran'rek in Gadgetzan.",en={7876},l=45,n="Tran'rek",nx=2865,r=0,rl=40,sn={773},tg=81,x=390,z=1176}
T[2865]={d="Bring 5 Uncracked Scarab Shells to Tran'rek in Gadgetzan.",en={7876},l=45,n="Scarab Shells",ob={i={{9238}}},r=0,rl=40,sn={7876},tg=81,x=3900,z=1176}
T[2866]={d="Explore the Ruins of Solarsal and investigate the presence of the naga there.",eo={142179},l=43,n="The Ruins of Solarsal",nx=2867,r=77,rl=40,sn={3936},x=2700}
T[2867]={d="Return to Shandris Feathermoon in the Feathermoon Stronghold and report your findings.",en={3936},l=43,n="Return to Feathermoon Stronghold",nx=3130,ps={2866},r=77,rl=40,so={142179},x=1800}
T[2869]={d="Bring 10 Hatecrest Naga Scales to Latronicus Moonspear in Feathermoon Stronghold.",en={7877},l=43,n="Against the Hatecrest",nx=2870,ob={i={{9247}}},ps={3130},r=77,rl=40,sn={7877},x=2700}
T[2870]={d="Eliminate Lord Shalzaru, and then bring the Mysterious Relic he uncovered to Latronicus Moonspear in Feathermoon Stronghold.",en={7877},l=45,n="Against Lord Shalzaru",nx=2871,ob={i={{9248}}},ps={2869},r=77,rl=40,sn={7877},x=2900}
T[2871]={d="Deliver the Mysterious Relic to Vestia Moonspear in Feathermoon Stronghold.",en={7878},l=45,n="Delivering the Relic",ps={2870},r=77,rl=40,sn={7877},su=9248,x=3900}
T[2872]={d="Speak with Stoley in Steamwheedle Port.",en={7881},l=45,n="Stoley's Debt",nx=2873,r=0,rl=40,sn={2501},x=390}
T[2873]={d="Bring Stoley's Shipment to Stoley in Steamwheedle Port.",en={7881},l=45,n="Stoley's Shipment",nx=2874,ob={i={{9244}}},r=0,rl=40,sn={7881},x=3900}
T[2874]={d="Bring Stoley's Bottle to \"Sea Wolf\" MacKinley in Booty Bay.",en={2501},l=45,n="Deliver to MacKinley",ps={2873},r=0,rl=40,sn={7881},su=9245,x=3900}
T[2875]={d="Bring Andre's Head to Security Chief Bilgewhizzle in Steamwheedle Port.",en={7882},l=45,n="WANTED: Andre Firebeard",ob={i={{9246}}},r=0,rl=40,so={142122,150075},x=3900}
T[2876]={d="Report the Ship Schedules to an authority in Steamwheedle Port.",en={7882},l=45,n="Ship Schedules",r=0,rl=40,si={9250},su=9250,x=4850}
T[2877]={d="Kill 10 Green Sludges and 10 Jade Oozes, and then report back to Fraggar Thundermantle in Aerie Peak.",en={7884},l=48,n="Skulk Rock Clean-up",ob={k={{2655},{2656}}},r=77,rl=40,sn={7884},x=4400}
T[2878]={eo={174594},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={174594},x=560}
T[2879]={d="Energize Troyas' Stave and find the Equinex Monolith.",eo={144063},l=50,n="The Stave of Equinex",nx=2942,ob={i={{9306}}},ps={2943},r=77,rl=42,rs={9255,9256,9257,9258},sn={7764},su=9263,x=4700}
T[2880]={d="Bring 5 Troll Tribal Necklaces to Fraggar Thundermantle in Aerie Peak.",en={7884},l=45,n="Troll Necklace Bounty",nx=2881,ob={i={{9259}}},r=77,rl=40,sn={7884},x=3900}
T[2881]={en={7884},l=45,n="Troll Necklace Bounty",ob={i={{9259}}},ps={2880},r=77,rl=40,sf=1,sn={7884},x=390}
T[2882]={d="Find Cuergo's gold!",eo={142194},l=45,n="Cuergo's Gold",ob={i={{9275}}},r=0,rl=40,sf=1,si={9254}}
T[2902]={d="Find the gnoll battle plans somewhere in the gnoll camps to the south of Camp Mojache.",eo={142195},l=43,n="Woodpaw Investigation",nx=2903,ps={2863},r=178,rl=39,sn={7875},x=1800}
T[2903]={d="Bring the Woodpaw Battle Plans to Hadoken Swiftstrider in Camp Mojache.",en={7875},l=43,n="The Battle Plans",ps={2902},r=178,rl=39,so={142195},su=9266,x=3600}
T[2904]={d="Escort Kernobee to the Clockwerk Run exit and then report to Scooty in Booty Bay.",en={7853},es=1,l=30,n="A Fine Mess",r=0,rl=24,sf=2,sn={7850},tg=81,x=2450,z=721}
T[2922]={d="Bring Techbot's Memory Core to Tinkmaster Overspark in Ironforge.",en={7944},l=26,n="Save Techbot's Brain!",ob={i={{9277}}},r=77,rl=20,sn={7944},tg=81,x=2650,z=721}
T[2923]={d="Speak with Tinkmaster Overspark in Ironforge.",en={7944},l=26,n="Tinkmaster Overspark",nx=2922,r=77,rl=20,sn={7917},tg=81,x=210,z=721}
T[2924]={d="Bring 12 Essential Artificials to Klockmort Spannerspan in Ironforge.",en={6169},l=30,n="Essential Artificials",ob={i={{9278}}},r=77,rl=24,sn={6169},tg=81,x=3050,z=721}
T[2925]={d="Speak with Klockmort Spannerspan in Ironforge.",en={6169},l=30,n="Klockmort's Essentials",nx=2924,r=77,rl=24,sn={6142},tg=81,x=245,z=721}
T[2926]={d="Use the Empty Leaden Collection Phial on Irradiated Invaders or Irradiated Pillagers to collect radioactive fallout. Once it is full, take it back to Ozzie Togglevolt in Kharanos.",en={1268},l=27,n="Gnogaine",nx=2962,ob={i={{9284}}},r=77,rl=20,sn={1268},su=9283,tg=81,x=2200,z=721}
T[2927]={d="Speak with Ozzie Togglevolt in Kharanos.",en={1268},l=27,n="The Day After",nx=2926,r=77,rl=20,sn={6569},tg=81,x=220,z=721}
T[2928]={d="Bring twenty-four Robo-mechanical Guts to Shoni in Stormwind.",en={6579},l=30,n="Gyrodrillmatic Excavationators",ob={i={{9309}}},r=77,rl=20,sn={6579},tg=81,x=2450,z=721}
T[2929]={d="Venture to Gnomeregan and kill Mekgineer Thermaplugg. Return to High Tinker Mekkatorque when the task is complete.",en={7937},l=35,n="The Grand Betrayal",ob={k={{7800}}},r=77,rl=25,sn={7937},tg=81,x=2750,z=721}
T[2930]={d="Bring a Prismatic Punch Card to Master Mechanic Castpipe in Ironforge.",en={7950},l=30,n="Data Rescue",ob={i={{9316}}},r=77,rl=25,rs={9279,9280,9281,9282},sn={7950},tg=81,x=3650,z=721}
T[2931]={d="Speak with Master Mechanic Castpipe in Ironforge.",en={7950},l=28,n="Castpipe's Task",nx=2930,r=77,rl=25,sn={4077},tg=81,x=230,z=721}
T[2932]={d="Gather Witherbark Skulls and place on Nimboya's Pike. Place Nimboya's Laden Pike at one of the Witherbark Villages in the Hinterlands, then return to Nimboya in Stranglethorn.",en={2497},l=42,n="Grim Message",ob={e={"Place the grim message.",{{1425,23.4,58.1}}}},r=178,rl=35,rs={9320},sf=2,sn={2497},su=15002,x=3450}
T[2933]={d="Bring a Venom Bottle to an apothecary in Tarren Mill.",en={2216},l=43,n="Venom Bottles",nx=2934,r=178,rl=40,so={142702},su=9321,x=3600}
T[2934]={d="Bring an Undamaged Venom Sac to Apothecary Lydon in Tarren Mill.",en={2216},l=45,n="Undamaged Venom Sac",nx=2935,ob={i={{9322}}},ps={2933},r=178,rl=40,sn={2216},x=3900}
T[2935]={d="Speak with Master Gadrin in Sen'jin Village.",en={3188},l=45,n="Consult Master Gadrin",nx=2936,ps={2934},r=178,rl=40,sn={2216},tg=1,x=2900}
T[2936]={d="Read from the Tablet of Theka to learn the name of the Witherbark spider god, then return to Master Gadrin.",en={3188},l=45,n="The Spider God",nx=2937,ob={e={"Find the Spider God's Name",{{1446,38.7,19.9}}}},ps={2935},r=178,rl=40,sf=2,sn={3188},tg=81,x=4850,z=1176}
T[2937]={d="Defeat Shadra at the altar of Shadra'Alor, then bring her venom to Apothecary Lydon in Tarren Mill.",en={2216},l=55,n="Summoning Shadra",nx=2938,ob={i={{9324}}},ps={2936},r=178,rl=40,sn={3188},su=9323,tg=1,x=8450}
T[2938]={d="Bring Faranell's Parcel to Master Apothecary Faranell in the Undercity.",en={2055},l=55,n="Venom to the Undercity",ps={2937},r=178,rl=40,sn={2216},su=9436,x=8450}
T[2939]={d="Talk to Daryn Lightwind in Rut'theran Village.",en={7907},l=47,n="In Search of Knowledge",nx=2940,r=77,rl=42,sn={7764},x=420}
T[2940]={d="Ask Daryn Lightwind if you may borrow her book.",en={7907},l=47,n="Feralas: A History",nx=2941,ps={2939},r=77,rl=42,so={142958},x=420}
T[2941]={d="Take the letter to Curgle Cranklehop in Tanaris.",en={7763},l=48,n="The Borrower",nx=2944,ps={2940},r=77,rl=42,sn={7907},su=9329,x=1100}
T[2942]={d="Return the Sparkling Stone and the Stave of Equinex to Troyas Moonbreeze in Feathermoon Stronghold.",en={7764},l=50,n="The Morrow Stone",ob={i={{9307}}},ps={2879},r=77,rl=42,so={144063},su=9306,x=4700}
T[2943]={d="Deliver the book to Troyas Moonbreeze in Feathermoon Stronghold.",en={7764},l=48,n="Return to Troyas",nx=2879,ps={2944},r=77,rl=42,sn={7907},su=9331,x=3300}
T[2944]={d="Use the Super Snapper FX to take a snapshot of Gammerita, then return to Daryn Lightwind in Rut'theran Village.",en={7907},l=48,n="The Super Snapper FX",nx=2943,ob={i={{9330}}},ps={2941},r=77,rl=42,sn={7763},su=9328,tg=1,x=4400}
T[2945]={d="Figure out a way to remove the grime from the Grime-Encrusted Ring.",eo={142487},l=34,n="Grime-Encrusted Ring",r=0,rl=28,si={9326},su=9326,tg=81,x=2700,z=721}
T[2946]={d="Bring the miniature platinum discs to the gates of Uldum in Tanaris and look for clues as to the connection between the two.",eo={142343},l=50,n="Seeing What Happens",nx=2954,ps={2963},r=77,rl=45,sn={2916},su=6064,tg=1,x=4700}
T[2947]={d="You may either keep the ring, or you may find the person responsible for the imprint and engravings on the inside of the band.",en={6826},l=34,n="Return of the Ring",nx=2948,ps={2945},r=77,rl=28,so={142487},su=9362,tg=81,x=2700,z=721}
T[2948]={d="Bring the Brilliant Gold Ring, a Silver Bar, a Moss Agate, and 30 silver coins to Talvash del Kissel in Ironforge.",en={6826},l=35,n="Gnome Improvement",ob={i={{2842},{1206}}},ps={2947},r=77,rl=28,sn={6826},su=9362,x=2750}
T[2949]={d="You may either keep the ring, or you may find the person responsible for the imprint and engravings on the inside of the band.",en={3412},l=34,n="Return of the Ring",nx=2950,ps={2945},r=178,rl=28,so={142487},su=9362,tg=81,x=2700,z=721}
T[2950]={d="Bring the Brilliant Gold Ring, a Silver Bar, a Moss Agate, and 30 silver coins to Nogg in Orgrimmar.",en={3412},l=35,n="Nogg's Ring Redo",ob={i={{2842},{1206}}},ps={2949},r=178,rl=28,sn={3412},su=9362,x=2750}
T[2951]={d="Insert a Grime-Encrusted Item into the Sparklematic 5200, and be sure to have three silver coins to start the machine.",eo={142487},ex={4601,4602},l=30,n="The Sparklematic 5200!",ob={i={{9308}}},r=0,rl=25,so={142487},tg=81,z=721}
T[2952]={eo={142487},ex={4605,4606},l=30,n="The Sparklematic 5200!",ps={2951,4601,4602},r=0,rl=25,so={142487},tg=81,x=2450,z=721}
T[2953]={eo={142487},ex={4603,4604},l=30,n="More Sparklematic Action",ob={i={{9308}}},ps={2952,4605,4606},r=0,rl=25,sf=1,so={142487},tg=81,z=721}
T[2954]={d="Learn the purpose of the Stone Watcher of Norgannon, and then interact with the Uldum Pedestal in the Tanaris desert.",eo={142343},l=50,n="The Stone Watcher",ob={k={{7918}}},ps={2946,2966},r=0,rl=45,sf=2,sn={7918},so={142343},tg=1,x=4700}
T[2962]={d="Travel to Gnomeregan and bring back High Potency Radioactive Fallout. Be warned, the fallout is unstable and will collapse rather quickly.",en={1268},l=30,n="The Only Cure is More Green Glow",ob={i={{9365}}},ps={2926},r=77,rl=20,sn={1268},su=9364,tg=81,x=2450,z=721}
T[2963]={d="Speak with Historian Karnik in the Hall of Explorers within Ironforge.",en={2916},l=50,n="Portents of Uldum",nx=2946,ps={2439},r=77,rl=45,sn={5387},x=470}
T[2964]={d="Speak with High Explorer Magellas in Ironforge.",en={5387},l=50,n="A Future Task",ps={2977},r=77,rl=45,sn={2916},x=4700}
T[2965]={d="Speak with Nara Wildmane on the Elder Rise in Thunder Bluff.",en={5770},l=50,n="Portents of Uldum",nx=2966,ps={2440},r=178,rl=45,sn={3978},x=470}
T[2966]={d="Bring the miniature platinum discs to the gates of Uldum in Tanaris and look for clues as to the connection between the two.",eo={142343},l=50,n="Seeing What Happens",nx=2954,ps={2965},r=178,rl=45,sn={5770},su=6064,tg=1,x=4700}
T[2967]={d="Speak with Nara Wildmane in Thunder Bluff.",en={5770},l=50,n="Return to Thunder Bluff",nx=2968,ps={2954},r=178,rl=45,so={142343},su=6064,tg=1,x=470}
T[2968]={d="Speak with Sage Truthseeker in Thunder Bluff.",en={3978},l=50,n="A Future Task",ps={2967},r=178,rl=45,sn={5770},x=4700}
T[2969]={d="Using the Bamboo Cage Key, free the Sprite Darters from the pen in the Grimtotem camp. At least 6 Sprite Darters and Kindal Moonweaver must survive.",en={7956},l=47,n="Freedom for All Creatures",nx=2970,ob={e={"Save at least 6 Sprite Darters from capture",{{1444,67.3,46.7}}}},r=77,rl=38,sf=2,sn={7956},su=12301,x=3150}
T[2970]={d="Kill 12 Grimtotem Naturalists, 10 Grimtotem Raiders, and 6 Grimtotem Shamans before returning to Jer'kai Moonweaver in Feralas.",en={7957},l=47,n="Doling Justice",nx=2972,ob={k={{7726},{7725},{7727}}},ps={2969},r=77,rl=38,sn={7957},x=3150}
T[2972]={d="Take Jer'kai's Signet Ring to High Priestess Tyrande Whisperwind in Darnassus.",en={7999},l=47,n="Doling Justice",nx=3841,ps={2970},r=77,rl=38,sn={7957},su=9368,x=5250}
T[2973]={d="Bring 10 Iridescent Sprite Darter Wings to Krueg Skullsplitter in Camp Mojache.",en={4544},l=45,n="A New Cloak's Sheen",nx=2974,ob={i={{9369}}},r=178,rl=38,sn={4544},x=3900}
T[2974]={d="Bring 20 Grimtotem Horns to Krueg Skullsplitter in Camp Mojache.",en={4544},l=45,n="A Grim Discovery",nx=2976,ob={i={{9460}}},ps={2973},r=178,rl=38,sn={4544},x=3900}
T[2975]={d="Rok Orhan in Camp Mojache wants you to kill 10 Gordunni Ogres, 10 Gordunni Ogre-Magi, and 5 Gordunni Brutes.",en={7777},l=43,n="The Ogres of Feralas",nx=2980,ob={k={{5229},{5237},{5232}}},r=178,rl=38,sn={7777},x=2700}
T[2976]={d="Bring the Crate of Grimtotem Horns to Belgrom Rockmaul in Orgrimmar.",en={4485},l=45,n="A Grim Discovery",ps={2974},r=178,rl=37,sn={4544},su=9462,x=4850}
T[2977]={d="Speak with Historian Karnik in Ironforge.",en={2916},l=50,n="Return to Ironforge",nx=2964,ps={2954},r=77,rl=45,so={142343},su=6064,tg=1,x=470}
T[2978]={d="Bring the Gordunni Scroll to Rok Orhan in Camp Mojache.",en={7777},l=43,n="The Gordunni Scroll",nx=2979,r=178,rl=38,si={9370},su=9370,x=1800}
T[2979]={d="Rok Orhan in Camp Mojache wants you to find a Gordunni Orb.",en={7777},l=46,n="Dark Ceremony",nx=3002,ob={i={{9371}}},ps={2978},r=178,rl=38,sn={7777},x=4050}
T[2980]={d="Rok Orhan in Camp Mojache wants you to kill 10 Gordunni Shaman, 10 Gordunni Warlocks, and 5 Gordunni Maulers.",en={7777},l=44,n="The Ogres of Feralas",ob={k={{5236},{5240},{5234}}},ps={2975},r=178,rl=38,sn={7777},x=3750}
T[2981]={d="Belgrom Rockmaul wants you to speak with Rok Orhan in Camp Mojache.",en={7777},l=43,n="A Threat in Feralas",nx=2975,r=178,rl=38,sn={4485},x=890}
T[2982]={d="Angelas Moonbreeze wants you to kill 8 Gordunni Warlocks, 8 Gordunni Shaman, and 8 Gordunni Brutes.",en={7900},l=44,n="The High Wilderness",ob={k={{5240},{5236},{5232}}},r=77,rl=39,sn={7900},x=3750}
T[2983]={c=64,d="Find Kranal Fiss in the Barrens.",en={5907},ex={1522,1523,2984},l=10,n="Call of Fire",nx=1524,r=178,rl=10,sn={3173},x=420}
T[2984]={c=64,d="Find Kranal Fiss in the Barrens.",en={5907},ex={1522,1523,2983},l=10,n="Call of Fire",nx=1524,r=178,rl=10,sn={3066},x=420}
T[2985]={c=64,d="Find Islen Waterseer in the Barrens.",en={5901},ex={1528,1529,2986},l=20,n="Call of Water",nx=1530,r=178,rl=20,sn={3173},x=780}
T[2986]={c=64,d="Find Islen Waterseer in the Barrens.",en={5901},ex={1528,1529,2985},l=20,n="Call of Water",nx=1530,r=178,rl=20,sn={3066},x=780}
T[2987]={d="Orwin Gizzmick in Camp Mojache wants 12 samples of Gordunni Cobalt.",en={8021},l=43,n="Gordunni Cobalt",ob={i={{9463}}},r=178,rl=38,sn={8021},su=9466,x=3600}
T[2988]={d="Check the cages at the two Witherbark villages, then return to Gryphon Master Talonaxe.",en={5636},l=45,n="Witherbark Cages",nx=2989,ob={o={{144066,"Check First Cage"},{144067,"Check Second Cage"},{144068,"Check Third Cage"}}},r=77,rl=40,sn={5636},x=3900}
T[2989]={d="Check the top of the Altar of Zul, then return to Gryphon Master Talonaxe.",en={5636},l=48,n="The Altar of Zul",nx=2990,ob={e={"Search the Altar of Zul",{{1425,49,68.7}}}},ps={2988},r=77,rl=40,sf=2,sn={5636},x=4400}
T[2990]={d="Bring Sharpbeak's Feather to Thadius Grimshade in the Blasted Lands.",en={8022},l=47,n="Thadius Grimshade",nx=2991,ps={2989},r=77,rl=40,sn={5636},su=9468,x=2100}
T[2991]={d="Bring Nekrum's Medallion to Thadius Grimshade in the Blasted Lands.",en={8022},l=47,n="Nekrum's Medallion",nx=2992,ob={i={{9471}}},ps={2990},r=77,rl=40,sn={8022},tg=81,x=5250,z=1176}
T[2992]={d="Wait until Grimshade performs the ritual of divination.",en={8022},l=47,n="The Divination",nx=2993,ob={k={{8022}}},ps={2991},r=77,rl=40,sf=2,sn={8022},x=1050}
T[2993]={d="Speak with Gryphon Master Talonaxe.",en={5636},l=47,n="Return to the Hinterlands",nx=2994,ps={2992},r=77,rl=40,sn={8022},tg=1,x=2100}
T[2994]={d="Fight to the top of Jintha'Alor, kill Vile Priestess Hexx for the key to Sharpbeak's cage, and save Sharpbeak.",en={5636},l=51,n="Saving Sharpbeak",ob={o={{144070,"Open Sharpbeak's Cage"}}},ps={2993},r=77,rl=40,rs={9472},sn={5636},tg=1,x=7900}
T[2995]={d="Oran Snakewrithe in Undercity wants you to travel to the Hinterlands and burn the Highvale Records, Highvale Report, and Highvale Notes.",en={7825},l=47,n="Lines of Communication",ob={o={{144071,"Burn the Highvale Records"},{144072,"Burn the Highvale Notes"},{144073,"Burn the Highvale Report"}}},r=178,rl=42,sn={7825},x=3150}
T[2996]={c=256,d="Speak to Strahad Farsan in Ratchet.",en={6251},l=30,n="Seeking Strahad",nx=1801,r=178,rl=30,sn={5875},x=610}
T[2997]={c=2,d="Speak to Tiza Battleforge in Ironforge.",en={6179},ex={2999,3000},l=12,n="Tome of Divinity",nx=1646,r=4,rl=12,sn={1232},x=90}
T[2998]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},ex={3681},l=12,n="Tome of Divinity",nx=1642,r=1,rl=12,sn={927},x=225}
T[2999]={c=2,d="Speak to Tiza Battleforge in Ironforge",en={6179},ex={2997,3000},l=12,n="Tome of Divinity",nx=1646,r=4,rl=12,sn={5149},x=90}
T[3000]={c=2,d="Speak to Tiza Battleforge in Ironforge.",en={6179},ex={2997,2999},l=12,n="Tome of Divinity",nx=1646,r=4,rl=12,sn={928},x=225}
T[3001]={c=256,d="Find Strahad Farsan in Ratchet.",en={6251},l=30,n="Seeking Strahad",nx=1801,r=178,rl=30,sn={5675},x=610}
T[3002]={d="Bring the Gordunni Orb to Uthel'nay in the Darkbriar Lodge in Orgrimmar.",en={7311},l=47,n="The Gordunni Orb",ps={2979},r=178,rl=38,sn={7777},su=9371,x=2100}
T[3022]={d="Bring the Carefully-packed Crate to Erelas Ambersky in Rut'theran Village.",en={7916},l=47,n="Handle With Care",r=77,rl=42,sn={7763},su=9507,x=2100}
T[3042]={d="Bring 20 Vials of Troll Temper to Trenton Lighthammer in Gadgetzan.",en={7804},l=45,n="Troll Temper",ob={i={{9523}}},r=0,rl=40,sn={7804},tg=81,x=3900,z=1176}
T[3062]={d="Talo Thornhoof in Camp Mojache wants Edana Hatetalon's Dark Heart.",en={7776},l=50,n="Dark Heart",ob={i={{9528}}},r=178,rl=45,rs={9530},sn={7776},tg=1,x=5900}
T[3063]={d="Talo Thornhoof wants you to kill 4 Northspring Harpies, 4 Northspring Roguefeathers, 4 Northspring Windcallers, and 4 Northspring Slayers.",en={7776},l=50,n="Vengeance on the Northspring",ob={k={{5362},{5363},{5364},{5366}}},r=178,rl=45,sn={7776},x=3550}
T[3065]={c=1,d="Read the Simple Tablet and speak to Frang in the Valley of Trials.",en={3153},l=1,n="Simple Tablet",ps={788},r=128,rl=1,sn={3143},su=6488,x=40}
T[3082]={c=4,d="Speak to Jen'shan in the Valley of Trials.",en={3154},l=1,n="Etched Tablet",ps={788},r=128,rl=1,sn={3143},su=9564,x=40}
T[3083]={c=8,d="Read the Encrypted Tablet and speak to Rwag in the Valley of Trials.",en={3155},l=1,n="Encrypted Tablet",ps={788},r=128,rl=1,sn={3143},su=9554,x=40}
T[3084]={c=64,d="Speak to Shikrik in the Valley of Trials.",en={3157},l=1,n="Rune-Inscribed Tablet",ps={788},r=128,rl=1,sn={3143},su=9562,x=40}
T[3085]={c=16,d="Read the Hallowed Tablet and speak to Ken'jai outside the Den in the Valley of Trials.",en={3707},l=1,n="Hallowed Tablet",ps={788},r=128,rl=1,sn={3143},su=9561,x=40}
T[3086]={c=128,d="Read the Glyphic Tablet and speak with Mai'ah near the entrance to the Den in the Valley of Trials.",en={5884},l=1,n="Glyphic Tablet",ps={788},r=128,rl=1,sn={3143},su=9575,x=40}
T[3087]={c=4,d="Read the Etched Parchment and speak to Jen'shan in the Valley of Trials.",en={3154},l=1,n="Etched Parchment",ps={788},r=2,rl=1,sn={3143},su=9553,x=40}
T[3088]={c=8,d="Read the Encrypted Parchment and speak to Rwag in the Valley of Trials.",en={3155},l=1,n="Encrypted Parchment",ps={788},r=2,rl=1,sn={3143},su=9560,x=40}
T[3089]={c=64,d="Read the Rune-Inscribed Parchment and speak to Shikrik in the Valley of Trials.",en={3157},l=1,n="Rune-Inscribed Parchment",ps={788},r=2,rl=1,sn={3143},su=9568,x=40}
T[3090]={c=256,d="Read the Tainted Parchment and speak to Nartok inside the Den in the Valley of Trials.",en={3156},l=1,n="Tainted Parchment",ps={788},r=2,rl=1,sn={3143},su=9579,x=40}
T[3091]={c=1,d="Read the Simple Note and speak to Harutt Thunderhorn in Camp Narache.",en={3059},l=1,n="Simple Note",ps={747},r=32,rl=1,sn={2980},su=9547,x=40}
T[3092]={c=4,d="Read the Etched Note and speak to Lanka Farshot in Red Cloud Mesa.",en={3061},l=1,n="Etched Note",ps={747},r=32,rl=1,sn={2980},su=9565,x=60}
T[3093]={c=64,d="Read the Rune-Inscribed Note and speak to Meela Dawnstrider in Camp Narache.",en={3062},l=1,n="Rune-Inscribed Note",ps={747},r=32,rl=1,sn={2980},su=9552,x=60}
T[3094]={c=1024,d="Read the Verdant Note and speak to Gart Mistrunner in Camp Narache.",en={3060},l=1,n="Verdant Note",ps={747},r=32,rl=1,sn={2980},su=9581,x=60}
T[3095]={c=1,d="Read the Simple Scroll and speak to Dannal Stern in Deathknell.",en={2119},l=1,n="Simple Scroll",ps={364},r=16,rl=1,sn={1569},su=9546,x=40}
T[3096]={c=8,d="Read the Encrypted Scroll and speak to David Trias in Deathknell.",en={2122},l=1,n="Encrypted Scroll",ps={364},r=16,rl=1,sn={1569},su=9559,x=40}
T[3097]={c=16,d="Read the Hallowed Scroll and speak to Dark Cleric Duesten in the church in Deathknell.",en={2123},l=1,n="Hallowed Scroll",ps={364},r=16,rl=1,sn={1569},su=9569,x=40}
T[3098]={c=128,d="Read the Glyphic Scroll and speak to Isabella in the church in Deathknell.",en={2124},l=1,n="Glyphic Scroll",ps={364},r=16,rl=1,sn={1569},su=9574,x=40}
T[3099]={c=256,d="Read the Tainted Scroll and speak to Maximillion in Deathknell.",en={2126},l=1,n="Tainted Scroll",ps={364},r=16,rl=1,sn={1569},su=9578,x=40}
T[3100]={c=1,d="Read the Simple Letter and speak to Llane Beshere in Northshire Abbey.",en={911},l=1,n="Simple Letter",ps={7},r=1,rl=1,sn={197},su=9542,x=40}
T[3101]={c=2,d="Read the Consecrated Letter and speak to Brother Sammuel in Northshire Abbey.",en={925},l=1,n="Consecrated Letter",ps={7},r=1,rl=1,sn={197},su=9570,x=40}
T[3102]={c=8,d="Read the Encrypted Letter and speak to Jorik Kerridan in the stable behind Northshire Abbey.",en={915},l=1,n="Encrypted Letter",ps={7},r=1,rl=1,sn={197},su=9555,x=40}
T[3103]={c=16,d="Read the Hallowed Letter and speak to Priestess Anetta in Northshire Abbey.",en={375},l=1,n="Hallowed Letter",ps={7},r=1,rl=1,sn={197},su=9548,x=40}
T[3104]={c=128,d="Read the Glyphic Letter and speak to Khelden Bremen inside Northshire Abbey.",en={198},l=1,n="Glyphic Letter",ps={7},r=1,rl=1,sn={197},su=9571,x=40}
T[3105]={c=256,d="Read the Tainted Letter and speak to Drusilla La Salle next to Northshire Abbey.",en={459},l=1,n="Tainted Letter",ps={7},r=1,rl=1,sn={197},su=9576,x=40}
T[3106]={c=1,d="Read the Simple Rune and speak to Thran Khorman in Coldridge Valley.",en={912},l=1,n="Simple Rune",ps={179},r=4,rl=1,sn={658},su=9543,x=40}
T[3107]={c=2,d="Read the Consecrated Rune and speak to Bromos Grummner in Coldridge Valley.",en={926},l=1,n="Consecrated Rune",ps={179},r=4,rl=1,sn={658},su=9563,x=40}
T[3108]={c=4,d="Read the Etched Rune and speak to Thorgas Grimson in Coldridge Valley.",en={895},l=1,n="Etched Rune",ps={179},r=4,rl=1,sn={658},su=9566,x=40}
T[3109]={c=8,d="Read the Encrypted Rune and speak to Solm Hargrin in Coldridge Valley.",en={916},l=1,n="Encrypted Rune",ps={179},r=4,rl=1,sn={658},su=9550,x=40}
T[3110]={c=16,d="Read the Hallowed Rune and speak to Branstock Khalder in Anvilmar.",en={837},l=1,n="Hallowed Rune",ps={179},r=4,rl=1,sn={658},su=9556,x=40}
T[3112]={c=1,d="Read the Simple Memorandum and speak to Thran Khorman in Coldridge Valley.",en={912},l=1,n="Simple Memorandum",ps={179},r=64,rl=1,sn={658},su=9544,x=40}
T[3113]={c=8,d="Read the Encrypted Memorandum and speak to Solm Hargrin in Coldridge Valley.",en={916},l=1,n="Encrypted Memorandum",ps={179},r=64,rl=1,sn={658},su=9558,x=40}
T[3114]={c=128,d="Read the Glyphic Memorandum and speak to Marryk Nurribit inside Anvilmar above Coldridge Valley.",en={944},l=1,n="Glyphic Memorandum",ps={179},r=64,rl=1,sn={658},su=9573,x=40}
T[3115]={c=256,d="Read the Tainted Memorandum and speak to Alamar Grimm inside Anvilmar above Coldridge Valley.",en={460},l=1,n="Tainted Memorandum",ps={179},r=64,rl=1,sn={658},su=9577,x=40}
T[3116]={c=1,d="Read the Simple Sigil and speak to Alyissia in Shadowglen.",en={3593},l=1,n="Simple Sigil",ps={456},r=8,rl=1,sn={2079},su=9545,x=40}
T[3117]={c=4,d="Read the Etched Sigil and speak to Ayanna Everstride at the top of Aldrassil in Shadowglen.",en={3596},l=1,n="Etched Sigil",ps={456},r=8,rl=1,sn={2079},su=9567,x=40}
T[3118]={c=8,d="Read the Encrypted Sigil and speak to Frahun Shadewhisper in Shadowglen.",en={3594},l=1,n="Encrypted Sigil",ps={456},r=8,rl=1,sn={2079},su=9551,x=40}
T[3119]={c=16,d="Read the Hallowed Sigil and speak to Shanda in Aldrassil.",en={3595},l=1,n="Hallowed Sigil",ps={456},r=8,rl=1,sn={2079},su=9557,x=40}
T[3120]={c=1024,d="Read the Verdant Sigil and speak to Mardant Strongoak, in the tree Aldrassil in Shadowglen.",en={3597},l=1,n="Verdant Sigil",ps={456},r=8,rl=1,sn={2079},su=9580,x=40}
T[3121]={d="Take the Shrunken Head to Neeru Fireblade in Orgrimmar.",en={3216},l=45,n="A Strange Request",nx=3122,r=178,rl=40,sn={8115},su=9629,x=1950}
T[3122]={d="Deliver Neeru's Herb Pouch to Witch Doctor Uzer'i in Feralas.",en={8115},l=45,n="Return to Witch Doctor Uzer'i",ps={3121},r=178,rl=40,sn={3216},su=9628,x=970}
T[3123]={d="Travel to the Hinterlands, and locate the Wildkin. Kill 10, and use the Muisek Vessel to shrink and capture the fallen Wildkin.",en={8115},l=47,n="Testing the Vessel",nx=3124,ob={i={{9594}}},ps={3122},r=178,rl=40,sn={8115},su=9618,x=4200}
T[3124]={d="Kill 10 Frayfeather Hippogryphs of any type, then use the Muisek Vessel to shrink and capture them.",en={8115},l=47,n="Hippogryph Muisek",nx=3125,ob={i={{9595}}},ps={3123},r=178,rl=40,sn={8115},su=9619,x=4200}
T[3125]={d="Kill 8 Sprite Darters or Sprite Dragons. Use the Muisek Vessel to shrink and capture the fallen Faerie Dragons.",en={8115},l=45,n="Faerie Dragon Muisek",nx=3126,ob={i={{9596}}},ps={3124},r=178,rl=40,sn={8115},su=9620,x=3900}
T[3126]={d="Kill 3 Wandering Forest Walkers. Use the Muisek Vessel to shrink and capture the fallen Treants.",en={8115},l=50,n="Treant Muisek",nx=3127,ob={i={{9593}}},ps={3125},r=178,rl=40,sn={8115},su=9606,x=4700}
T[3127]={d="Kill 7 Land Walkers or Cliff Giants. Use the Muisek Vessel to shrink and capture the fallen Mountain Giants.",en={8115},l=50,n="Mountain Giant Muisek",ob={i={{9597}}},ps={3126},r=178,rl=40,sn={8115},su=9621,tg=1,x=4700}
T[3128]={d="Bring 2 Splintered Logs, 6 Encrusted Minerals, 20 pieces of Resilient Sinew, and 40 Metallic Fragments to Witch Doctor Uzer'i in Camp Mojache.",en={8115},l=50,n="Natural Materials",ob={i={{9590},{9589},{9591},{9592}}},ps={3122},r=178,rl=40,sn={8115},x=4700}
T[3129]={d="Witch Doctor Uzer'i wants you to wait for a moment while he prepares the weapons.",en={8115},l=50,n="Weapons of Spirit",pg={3127,3128},r=178,rl=40,sn={8115},x=4700}
T[3130]={d="Report to Latronicus Moonspear in Feathermoon Stronghold.",en={7877},l=43,n="Against the Hatecrest",nx=2869,ps={2867},r=77,rl=40,sn={3936},x=360}
T[3141]={d="Listen to Loramus Thalipedes tell his story.",en={7783},l=57,n="Loramus",nx=3508,ob={k={{7783}}},ps={2744},r=0,rl=45,sf=2,sn={7783},x=600}
T[3161]={d="Marvon Rivetseeker in Tanaris wants you to collect 30 Gahz'ridian Ornaments.",en={7771},l=48,n="Gahz'ridian",ob={i={{8443}}},r=0,rl=43,sn={7771},su=9978,x=4400}
T[3181]={d="Take Margol's Gigantic Horn to Mountaineer Pebblebitty.",en={3836},l=48,n="The Horn of the Beast",nx=3182,r=77,rl=40,si={10000},su=10005,tg=1,x=5450}
T[3182]={d="Take Margol's Gigantic Horn to Curator Thorius in Ironforge.",en={8256},l=48,n="Proof of Deed",nx=3201,ps={3181},r=77,rl=40,sn={3836},su=10005,tg=1,x=4400}
T[3201]={d="Take the Proof of Deed back to Mountaineer Pebblebitty.",en={3836},l=48,n="At Last!",ps={3182},r=77,rl=40,sn={8256},su=10022,tg=1,x=4400}
T[3221]={d="Speak with Apothecary Renferrel at the Sepulcher.",en={1937},l=12,n="Speak with Renferrel",nx=1359,ps={449},r=178,rl=10,sn={1952},x=90}
T[3261]={d="Speak with Jorn Skyseer at Camp Taurajo.",en={3387},l=18,n="Jorn Skyseer",nx=882,ps={905},r=178,rl=10,sn={3338},x=135}
T[3281]={d="Bring the Stolen Silver to Gazrog in the Crossroads.",en={3464},l=18,n="Stolen Silver",ob={i={{5061}}},ps={869},r=178,rl=9,sn={3464},x=1350}
T[3301]={d="Speak with Mura Runetotem in the Sepulcher.",en={8385},l=15,n="Mura Runetotem",ps={880},r=178,rl=10,sn={3448},su=10414,x=1050}
T[3321]={d="Wait for Trenton to finish his work.",en={7804},l=50,n="Did You Lose This?",ob={k={{7804}}},pg={2771,2772,2773},r=0,rl=40,sf=2,sk={164,210},sn={7804},x=7100}
T[3341]={d="Andrew Brownell wants you to kill Amnennar the Coldbringer and return his skull.",en={2308},l=42,n="Bring the End",ob={i={{10420}}},r=178,rl=37,sn={2308},tg=81,x=4300,z=722}
T[3361]={d="Bring Felix's Box, Felix's Chest and Felix's Bucket of Bolts to Felix Whindlebolt in Anvilmar.",en={8416},l=3,n="A Refugee's Quandary",ob={i={{10438},{16313},{16314}}},r=77,rl=3,sn={8416},x=250}
T[3362]={d="Tran'rek in Gadgetzan wants you to kill 8 Gnarled Thistleshrubs and 8 Thistleshrub Rootshapers.",en={7876},l=50,n="Thistleshrub Valley",ob={k={{5490},{5485}}},r=0,rl=45,sn={7876},x=4700}
T[3363]={eo={174595},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={174595},x=560}
T[3364]={d="Take a Scalding Mornbrew to Durnan Furcutter inside Anvilmar before it gets cold in five minutes!",en={836},l=5,n="Scalding Mornbrew Delivery",nx=3365,r=77,rl=4,sn={12738},su=10439,x=225}
T[3365]={d="Return Nori's Mug to Nori Pridedrift.",en={12738},l=5,n="Bring Back the Mug",ps={3364},r=77,rl=4,sn={836},su=10440,x=450}
T[3367]={d="Help Dorius get back to Ironforge.",eo={175704},l=48,n="Suntara Stones",nx=3368,ob={e={"Dorius Escort",{{1427,74.5,19.4}}}},r=77,rl=40,sf=2,sn={8284},x=4400}
T[3368]={d="Take the Singed Letter to Thorius in Ironforge. He is in the Hall of Explorers.",en={8256},l=48,n="Suntara Stones",nx=3371,ps={3367},r=77,rl=40,so={175704},su=10443,x=4400}
T[3369]={d="Bring the Nightmare Shard to Hamuul Runetotem on Elder Rise.",en={5769},l=25,n="In Nightmares",ps={6981},r=178,rl=15,sn={8418},su=10649,x=2000}
T[3370]={d="Bring the Nightmare Shard to Mathrengyl Bearwalker in Darnassus.",en={4217},l=25,n="In Nightmares",ps={6981},r=77,rl=15,sn={8418},su=10649,x=2000}
T[3371]={d="Return to the Searing Gorge and find Dorius's archaeology unit.",en={8417},l=55,n="Dwarven Justice",nx=3372,ps={3368},r=77,rl=40,sn={8256},x=5650}
T[3372]={d="Find the Mysterious Artifact being guarded by the Twilight's Hammer Idolaters in the northwest quadrant of the Searing Gorge and bring it to the Altar of Suntara in the Slag Pit.",eo={148498},l=52,n="Release Them",nx=3566,ob={i={{10442}}},ps={3371},r=77,rl=40,sn={8417},tg=1,x=5100}
T[3373]={d="Place the Essence of Eranikus in the Essence Font located in this lair in the Sunken Temple.",eo={148512},l=55,n="The Essence of Eranikus",nx=3374,r=0,rl=48,si={10454},su=10454,tg=81,x=2800,z=1477}
T[3374]={d="Bring the Oathstone of Ysera's Dragonflight and the Chained Essence of Eranikus to Itharius in the Swamp of Sorrows. It is there that you will make your choice to aid Ysera's Dragonflight or not.",en={5353},l=55,n="The Essence of Eranikus",nx=3512,ob={i={{10455}}},ps={3373},r=0,rl=48,si={10589},su=10589,x=560}
T[3375]={d="Bring a Mana Potion, Coal, and Sweet Nectar to Talvash del Kissel in Ironforge to get a replacement for Talvash's Phial of Scrying.",en={6826},l=42,n="Replacement Phial",ob={i={{3827},{3857},{1708}}},ps={2201},r=77,rl=37,sf=1,sn={6826},z=1337}
T[3376]={d="Bring the head of Chief Sharptusk Thornmantle to Brave Windfeather in Red Cloud Mesa.",en={3209},l=5,n="Break Sharptusk!",ob={i={{10459}}},r=178,rl=3,sn={3209},x=670}
T[3377]={d="Hear Zamael tell his tale.",en={8436},l=50,n="Prayer to Elune",nx=3378,ob={k={{8436}}},r=77,rl=40,sf=2,sn={8436},x=470}
T[3378]={d="Find the Prayer to Elune and take it to Astarii Starseeker in Darnassus.",en={4090},l=50,n="Prayer to Elune",ob={i={{10458}}},ps={3377},r=77,rl=40,sn={8436},x=5900}
T[3379]={d="Kill the group of Shadow Silk Poachers that wander the Searing Gorge. Nilith has reason to believe that there are five of them that need to be exterminated. Return to Nilith in the Searing Gorge when this task is complete.",en={8439},l=50,n="Shadoweaver",nx=3385,ob={k={{8442}}},r=0,rl=46,sk={197,230},sn={8439},x=7100}
T[3380]={d="Find Marvon Rivetseeker in Tanaris.",en={7771},l=51,n="The Sunken Temple",nx=3444,r=178,rl=46,sn={8115},tg=81,x=3650,z=1477}
T[3382]={d="Defend Captain Vanessa Beltis, her crew and the Horizon Scout's passengers against the naga attack. Captain Vanessa Beltis must survive.",en={8380},l=57,n="A Crew Under Fire",ob={e={"Protect Captain Vanessa Beltis from the naga attack",{{1447,52.9,87.8}}}},r=0,rl=48,sf=3,sn={8380},x=600}
T[3385]={d="Slay Trade Master Kovic and his minion Clunk. Retrieve the Trader's Satchel from his corpse and return it to Nilith.",en={8439},l=50,n="The Undermarket",nx=3402,ob={i={{10467}},k={{8444},{8447}}},ps={3379},r=0,rl=46,sk={197,230},sn={8439},tg=1,x=7100}
T[3402]={d="Speak with Vizzklick in Gadgetzan.",en={6568},l=50,n="The Undermarket",ps={3385},r=0,rl=43,sk={197,230},sn={8439},x=7100}
T[3421]={en={8399},l=55,n="Return Trip",r=0,rl=45,sf=1,sn={8399}}
T[3441]={d="Listen as Kalaran Windblade tells his story.",en={8479},l=48,n="Divine Retribution",nx=3442,ob={k={{8479}}},r=0,rl=40,sf=2,sn={8479},x=440}
T[3442]={d="Collect 4 Hearts of Flame and 4 globes of Golem Oil and return the items to Kalaran Windblade.",en={8479},l=48,n="The Flawless Flame",nx=3443,ob={i={{10509},{10511}}},ps={3441},r=0,rl=40,sn={8479},x=4400}
T[3443]={d="Bring 8 Thorium Plated Daggers to Kalaran Windblade.",en={8479},l=48,n="Forging the Shaft",nx=3452,ob={i={{10551}}},ps={3442},r=0,rl=40,sn={8479},x=4400}
T[3444]={d="Retrieve the Stone Circle from Marvon Rivetseeker's workshop in Ratchet.",en={7771},l=51,n="The Stone Circle",ob={i={{10556}}},ps={3380,3445},r=0,rl=46,sn={7771},x=4900}
T[3445]={d="Find Marvon Rivetseeker in Tanaris.",en={7771},l=51,n="The Sunken Temple",nx=3444,r=77,rl=46,sn={7900},x=3650}
T[3446]={d="Find the Altar of Hakkar in the Sunken Temple in Swamp of Sorrows.",eo={148836},l=51,n="Into the Depths",ps={3444},r=0,rl=46,sn={7771},su=10466,tg=81,x=4900,z=1477}
T[3447]={d="Travel into the Sunken Temple and discover the secret hidden in the circle of statues.",eo={148838},l=51,n="Secret of the Circle",ps={3444},r=0,rl=46,sn={7771},tg=81,x=6100,z=1477}
T[3448]={d="Speak to Tymor in Ironforge.",en={8507},l=52,n="Passing the Burden",nx=3449,r=77,rl=45,sn={2916},x=510}
T[3449]={d="Using the Drawing Kit, make rubbings of the Rune of Beth'Amara, the Rune of Jin'yael, the Rune of Markri, and the Rune of Sael'hai before heading to the small island off of the southern peninsula of Azshara and signaling Pilot Xiggs Fuselighter to pick them up.",en={8392},l=52,n="Arcane Runes",nx=3461,ob={i={{10563},{10564},{10565},{10566}}},ps={3448},r=77,rl=45,rs={10444},sn={8507},su=10445,x=2550}
T[3450]={d="Speak to Xiggs Fuselighter in Ironforge.",en={8517},l=52,n="An Easy Pickup",nx=3451,pa=3449,r=77,rl=45,sn={8507}}
T[3451]={d="Speak to Xiggs Fuselighter and get a Standard Issue Flare Gun from him in Ironforge.",en={8517},l=52,n="Signal for Pickup",nx=3483,ps={3450},r=77,rl=45,sn={8517}}
T[3452]={d="Find and return a Symbol of Ragnaros to Kalaran Windblade.",en={8479},l=50,n="The Flame's Casing",nx=3453,ob={i={{10552}}},ps={3443},r=0,rl=40,sn={8479},tg=1,x=4700}
T[3453]={d="Wait for Kalaran Windblade to complete the Torch of Retribution.",en={8479},l=50,n="The Torch of Retribution",nx=3454,ob={k={{8479}}},ps={3452},r=0,rl=40,sf=2,sn={8479},x=470}
T[3454]={d="Take the Torch of Retribution.",eo={149047},l=50,n="The Torch of Retribution",nx=3462,ps={3453},r=0,rl=40,sn={8479},x=4700}
T[3461]={d="Return Tymor's Drawing Kit to him in Ironforge.",en={8507},l=52,n="Return to Tymor",ps={3449},r=77,rl=45,sn={8392},su=10445,x=7600}
T[3462]={d="Speak with Squire Maltrake.",en={8509},l=50,n="Squire Maltrake",nx=3463,ps={3454},r=0,rl=40,sn={8479},x=470}
T[3463]={d="Set the North, South, East, and West Sentry Towers on fire by using the Torch of Retribution inside each of the buildings. ",en={8509},l=52,n="Set Them Ablaze!",nx=3481,ob={o={{149025,"Western Tower Ablaze"},{149030,"Southern Tower Ablaze"},{149031,"Eastern Tower Ablaze"},{149032,"Northern Tower Ablaze"}}},ps={3462},r=0,rl=40,sn={8509},su=10515,tg=1,x=7600}
T[3481]={d="Open the chest.",eo={149502},l=50,n="Trinkets...",nx=4022,ps={3463},r=0,rl=40,so={149502},x=470}
T[3483]={en={8517},l=52,n="Signal for Pickup",ps={3451},r=77,rl=45,sf=1,sn={8517}}
T[3501]={d="Bring Kum'isha Imperfect Draenethyst Fragments and be rewarded for each one you turn in.",en={7363},l=55,n="Everything Counts In Large Amounts",nx=3502,ob={i={{10593}}},r=0,rl=45,sn={7363},x=5650}
T[3502]={d="Bring Kum'isha Imperfect Draenethyst Fragments. Any form of monster in the Blasted Lands could be carrying a fragment.",en={7363},l=55,n="One Draenei's Junk...",ob={i={{10593}}},ps={3501},r=0,rl=45,sf=1,sn={7363}}
T[3503]={en={8395},l=55,n="Meeting with the Master",r=0,rl=45,sf=1,sn={8395}}
T[3504]={d="Deliver the Sealed Letter to Ag'tor Bloodfist in Azshara.",en={8576},l=53,n="Betrayed",nx=3505,r=178,rl=44,sn={4485},su=10643,x=2650}
T[3505]={d="Kill 10 Blood Elf Reclaimers, and 10 Blood Elf Surveyors before seeking out Magus Rimtori's camp. Once you've found it, look for something that might be important to her that can be used to draw her into a fight.",eo={151286},l=53,n="Betrayed",nx=3506,ob={e={"Find Magus Rimtori's camp",{{1447,59.5,31.5}}},k={{6199},{6198}}},ps={3504},r=178,rl=44,sf=2,sn={8576},x=3950}
T[3506]={d="Destroy the arcane focusing crystal tied to Magus Rimtori and then slay her. Afterwards, take the Head of Magus Rimtori to Ag'tor Bloodfist in Azshara.",en={8576},l=56,n="Betrayed",nx=3507,ob={i={{10597}}},ps={3505},r=178,rl=44,so={151286},x=4350}
T[3507]={d="Speak to Belgrom Rockmaul in Orgrimmar.",en={4485},l=56,n="Betrayed",ps={3506},r=178,rl=44,sn={8576},su=10597,x=7300}
T[3508]={d="Wait for Loramus to complete the enlightenment spell.",en={7783},l=58,n="Breaking the Ward",nx=3509,ps={3141},r=0,rl=45,sf=2,sn={7783},x=3100}
T[3509]={d="Speak with Lord Arkkoroc in Azshara. Begin your search at the waters edge to find the Temple of Arkkoran.",en={6134},l=58,n="The Name of the Beast",nx=3510,ps={3508},r=0,rl=45,sn={7783},x=6200}
T[3510]={d="Slay Hetaera and bring back Hetaera's Bloodied Head, Hetaera's Beaten Head, and Hetaera's Bruised Head to Lord Arkkoroc.",en={6134},l=58,n="The Name of the Beast",nx=3511,ob={i={{10599},{10598},{10600}}},ps={3509},r=0,rl=45,sn={6134},tg=1,x=6200}
T[3511]={d="Take the temper back to Loramus Thalipedes.",en={7783},l=58,n="The Name of the Beast",nx=3602,ps={3510},r=0,rl=45,sn={6134},su=10610,x=3100}
T[3512]={d="Travel to the eastern part of Winterspring and speak with Umbranse the Spiritspeaker.",en={8588},l=55,n="In Eranikus' Own Words",ps={3374},r=0,rl=48,sn={5353},x=4200}
T[3513]={d="Take the Runed Scroll to the northern guard tower in the Barrens.",en={8582},l=25,n="The Runed Scroll",nx=3514,r=178,rl=15,si={10621},su=10621,x=2550}
T[3514]={d="Kill the leader of the Talon Den, Rynthariel the Keymaster.",en={8582},l=29,n="Horde Presence",ob={k={{8518}}},ps={3513},r=178,rl=15,sn={8582},su=10622,tg=1,x=2950}
T[3517]={d="Find the Tablet of Beth'Amara, the Tablet of Jin'yael, the Tablet of Markri, and the Tablet of Sael'hai before returning to Jediga in Azshara.",en={8587},l=52,n="Stealing Knowledge",ob={i={{10538},{10539},{10540},{10541}}},r=178,rl=45,sn={8587},x=5100}
T[3518]={d="Bring the Tablet of Beth'Amara to Magatha in Thunder Bluff.",en={4046},l=52,n="Delivery to Magatha",nx=3562,ps={3517},r=178,rl=45,sn={8587},su=10538,x=2550}
T[3519]={d="Speak to Dirania Silvershine in Shadowglen.",en={8583},l=4,n="A Friend in Need",nx=3521,ps={4495},r=77,rl=2,sn={8584},x=90}
T[3520]={d="Capture the spirits of 3 screechers in Feralas, then return to Yeh'kinya in Steamwheedle Port.",en={8579},l=44,n="Screecher Spirits",nx=3527,ob={k={{8612}}},r=0,rl=40,sn={8579},su=10699,x=3750}
T[3521]={d="Collect 7 Hyacinth Mushrooms, 4 Moonpetal Lilies, and 1 Webwood Ichor for Dirania Silveshine in Shadowglen.",en={8583},l=4,n="Iverron's Antidote",nx=3522,ob={i={{10639},{10641},{10640}}},ps={3519},r=77,rl=2,sn={8583},x=355}
T[3522]={d="Bring Iverron's Antidote to Iverron before the time limit is up. Iverron can be found by the cave to the north.",en={8584},l=4,n="Iverron's Antidote",ps={3521},r=77,rl=2,sn={8583},su=10642,x=445}
T[3523]={d="If you agree to aid Belnistrasz, speak with him again and hand the Oathstone he gave you back to him.",en={8516},l=37,n="Scourge of the Downs",nx=3525,r=0,rl=32,sn={8516},su=10682,tg=81,x=285,z=722}
T[3524]={d="Recover Sea Creature Bones from the beached sea creature just south of Auberdine, and then return with it to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=13,n="Washed Ashore",nx=4681,ob={i={{12242}}},r=77,rl=11,sn={10219},x=680}
T[3525]={d="Escort Belnistrasz to the Quilboar's idol in Razorfen Downs.",eo={152097},es=1,l=37,n="Extinguishing the Idol",ob={e={"Protect Belnistrasz while he performs the ritual to shut down the idol",{{1413,50.9,92.9}}}},ps={3523},r=0,rl=32,sf=2,sn={8516},tg=81,x=4250,z=722}
T[3526]={d="If you wish to learn more about Goblin Engineering, take the Manual of Engineering Disciplines to Nixx Sprocketspring in Gadgetzan.",en={8126},ex={3629,3633,4181,3640,3642},l=47,n="Goblin Engineering",nx=3638,r=178,rl=30,sk={202,200},sn={4586},su=10789,x=420}
T[3527]={d="Bring the First and Second Mosh'aru Tablets to Yeh'kinya in Tanaris.",en={8579},l=47,n="The Prophecy of Mosh'aru",nx=4787,ob={i={{10660},{10661}}},ps={3520},r=0,rl=40,sn={8579},tg=81,x=5250,z=1176}
T[3528]={d="Bring the Filled Egg of Hakkar to Yeh'kinya in Tanaris.",en={8579},l=53,n="The God Hakkar",nx=5065,ob={i={{10662}}},ps={4787},r=0,rl=40,rs={10663},sn={8579},su=10465,tg=81,x=7900,z=1477}
T[3541]={d="Bring the Tablet of Jin'yael to Jes'rimon in Orgrimmar.",en={8659},l=52,n="Delivery to Jes'rimon",nx=3563,ps={3517},r=178,rl=45,sn={8587},su=10539,x=2550}
T[3542]={d="Bring the Tablet of Markri to Andron Gant in Undercity.",en={6522},l=52,n="Delivery to Andron Gant",nx=3564,ps={3517},r=178,rl=45,sn={8587},su=10540,x=2550}
T[3561]={d="Bring the Tablet of Sael'hai to Archmage Xylem in Azshara.",en={8379},l=52,n="Delivery to Archmage Xylem",nx=3565,ps={3517},r=178,rl=45,sn={8587},su=10541,x=2550}
T[3562]={d="Deliver Magatha's Note to Jediga in Azshara.",en={8587},l=52,n="Magatha's Payment to Jediga",ps={3518},r=178,rl=45,sn={4046},su=10678,x=3800}
T[3563]={d="Deliver Jes'rimon's Note to Jediga in Azshara.",en={8587},l=52,n="Jes'rimon's Payment to Jediga",ps={3541},r=178,rl=45,sn={8659},su=10680,x=3800}
T[3564]={d="Deliver Andron's Note to Jediga in Azshara.",en={8587},l=52,n="Andron's Payment to Jediga",ps={3542},r=178,rl=45,sn={6522},su=10679,x=3800}
T[3565]={d="Deliver Xylem's Note to Jediga in Azshara.",en={8587},l=52,n="Xylem's Payment to Jediga",ps={3561},r=178,rl=45,sn={8379},su=10681,x=3800}
T[3566]={d="Slay Lathoric the Black and Obsidion, and return to Thorius in Ironforge with the Head of Lathoric the Black and the Heart of Obsidion.",en={8256},l=52,n="Rise, Obsidion!",ob={i={{10447},{10446}}},ps={3372},r=77,rl=45,sn={8417},tg=1,x=7600}
T[3567]={en={7773},l=25,n="To the Top",r=0,rl=25,sf=1,sn={7773}}
T[3568]={d="Fill all 4 Empty Vials at the tide pools along the coast of the Ruins of Eldarath in Azshara before returning to Chemist Cuely.",en={8390},l=52,n="Seeping Corruption",nx=3569,ob={i={{10691},{10692},{10693},{10694}}},r=178,rl=45,sn={8390},su=10695,x=2550}
T[3569]={d="Give Cuely's Elixir to Thersa Windsong in Undercity.",en={8393},l=52,n="Seeping Corruption",nx=3570,ps={3568},r=178,rl=45,sn={8390},su=10712,x=510}
T[3570]={en={8390},l=52,n="Seeping Corruption",ps={3569},r=178,rl=45,sn={8390},x=5100}
T[3601]={d="Search the Thalassian Base Camp for Kim'jael's Compass, Scope, Stuffed Chicken and Wizzlegoober, then return them to him in Azshara.",en={8420},l=53,n="Kim'jael Indeed!",nx=5534,ob={i={{10717},{10715},{10722},{10718}}},r=0,rl=47,sn={8420},x=6550}
T[3602]={d="Recover twenty Crystallized Azsharite from southern Azshara. You may use the Felhound to assist you in 'sniffing' out the location of cleverly hidden deposits.",en={7783},l=58,n="Azsharite",nx=3621,ob={i={{10714}}},ps={3511},r=0,rl=45,rs={10831,10832},sn={7783},su=10834,tg=1,x=7750}
T[3621]={d="Take the Shipment to Galvan the Ancient in Stranglethorn Vale.",en={7802},l=58,n="The Formation of Felbane",nx=3625,ps={3602},r=0,rl=45,sn={7783},su=10738,x=4650}
T[3625]={d="Wait for Galvan to finish forging the weaponry.",en={7802},l=58,n="Enchanted Azsharite Fel Weaponry",nx=3626,ob={k={{7802}}},ps={3621},r=0,rl=45,sf=2,sn={7802},x=620}
T[3626]={d="Return to the Fallen Hero of the Horde.",en={7572},l=58,n="Return to the Blasted Lands",nx=3627,ps={3625},r=0,rl=45,sn={7802},x=1550}
T[3627]={d="Slay Grol the Destroyer, Lady Sevine, and Archmage Allistarj. From their corpses take the Amulet of Grol, the Amulet of Sevine, and the Amulet of Allistarj.",en={7572},l=60,n="Uniting the Shattered Amulet",nx=3628,ob={i={{10755},{10753},{10754}}},ps={3626},r=0,rl=45,sn={7572},tg=1,x=8300}
T[3628]={d="Destroy Razelikh the Defiler and return the Severed Horn of the Defiler to the Fallen Hero of the Horde. You will also need to return the Ward of the Defiler so that the Fallen Hero can destroy it, preventing it from ever falling into the wrong hands.",en={7572},l=60,n="You Are Rakh'likh, Demon",ob={i={{10759}}},ps={3627},r=0,rl=45,sn={7572},su=10757,tg=1,x=9950}
T[3629]={d="If you wish to learn more about Goblin Engineering, take the Manual of Engineering Disciplines to Nixx Sprocketspring in Gadgetzan.",en={8126},ex={3526,3633,4181,3640,3642},l=47,n="Goblin Engineering",nx=3638,r=77,rl=30,sf=0,sk={202,200},sn={5174},su=10789,x=420}
T[3630]={d="If you wish to learn more about Gnome Engineering, take the Manual of Engineering Disciplines to Tinkmaster Overspark in Ironforge.",en={7944},ex={3632,3634,3635,3637,3638,3642},l=47,n="Gnome Engineering",nx=3640,r=77,rl=30,sk={202,200},sn={5518},su=10789,x=420}
T[3631]={c=256,d="Speak to Strahad Farsan in the Barrens.",en={6251},ex={4487,4488,4489},l=40,n="Summon Felsteed",nx=4490,r=178,rl=40,sn={3326}}
T[3632]={d="If you wish to learn more about Gnome Engineering, take the Manual of Engineering Disciplines to Tinkmaster Overspark in Ironforge.",en={7944},ex={3630,3634,3635,3637,3638,3642},l=47,n="Gnome Engineering",nx=3640,r=77,rl=30,sk={202,200},sn={5174},su=10789,x=420}
T[3633]={d="If you wish to learn more about Goblin Engineering, take the Manual of Engineering Disciplines to Nixx Sprocketspring in Gadgetzan.",en={8126},ex={3526,3629,4181,3640,3642},l=47,n="Goblin Engineering",nx=3638,r=0,rl=30,sk={202,200},sn={3494},su=10789,x=420}
T[3634]={d="If you wish to learn more about Gnome Engineering, take the Manual of Engineering Disciplines to Tinkmaster Overspark in Ironforge.",en={7944},ex={3630,3632,3635,3637,3638,3642},l=47,n="Gnome Engineering",nx=3640,r=77,rl=30,sk={202,200},sn={3494},su=10789,x=420}
T[3635]={d="If you wish to learn more about Gnome Engineering, take the Manual of Engineering Disciplines to Oglethorpe Obnoticus in Booty Bay.",en={7406},ex={3630,3632,3634,3637,3638,3640},l=47,n="Gnome Engineering",nx=3642,r=178,rl=30,sk={202,200},sn={4586},su=10789,x=420}
T[3636]={d="Archbishop Bendictus wants you to slay Amnennar the Coldbringer in Razorfen Downs.",en={1284},l=42,n="Bring the Light",ob={k={{7358}}},r=77,rl=39,sn={1284},tg=81,x=4300,z=722}
T[3637]={d="If you wish to learn more about Gnome Engineering, take the Manual of Engineering Disciplines to Oglethorpe Obnoticus in Booty Bay.",en={7406},ex={3630,3632,3634,3635,3638,3640},l=47,n="Gnome Engineering",nx=3642,r=178,rl=30,sk={202,200},sn={3494},su=10789,x=420}
T[3638]={d="If you agree to become a Goblin Engineer, then right-click on the Pledge of Secrecy and speak once more with Nixx Sprocketspring in Gadgetzan.",en={8126},ex={3640,3642},l=47,n="The Pledge of Secrecy",nx=3639,ob={i={{11270}}},ps={3526,3629,3633,4181},r=0,rl=30,sk={202,200},sn={8126},su=10792,x=420}
T[3639]={d="Bring 20 Big Iron Bombs, 20 Solid Dynamite, and 5 Explosive Sheep to Nixx Sprocketspring in Gadgetzan.",en={8126},ex={3640,3641,3642,3643},l=47,n="Show Your Work",nx=3644,ob={i={{4394},{10507},{4384}}},ps={3638},r=0,rl=30,sk={202,200},sn={8126},x=3150}
T[3640]={d="If you agree to become a Gnome Engineer, then right-click on the Pledge of Secrecy and speak once more with Tinkmaster Overspark in Ironforge.",en={7944},ex={3638,3642},l=47,n="The Pledge of Secrecy",nx=3641,ob={i={{11283}}},ps={3630,3632,3634},r=77,rl=30,sk={202,200},sn={7944},su=10793,x=420}
T[3641]={d="Bring 6 Mithril Tubes, an Accurate Scope, and 2 Advanced Target Dummies to Tinkmaster Overspark in Ironforge.",en={7944},ex={3638,3639},l=47,n="Show Your Work",nx=3647,ob={i={{10559},{4407},{4392}}},ps={3640},r=77,rl=30,sk={202,200},sn={7944},x=3150}
T[3642]={d="If you agree to become a Gnome Engineer, then right-click on the Pledge of Secrecy and speak once more with Oglethrope Obnoticus in Booty bay.",en={7406},ex={3638,3640},l=47,n="The Pledge of Secrecy",nx=3643,ob={i={{11282}}},ps={3635,3637},r=178,rl=30,sk={202,200},sn={7406},su=10794,x=420}
T[3643]={d="Bring 6 Mithril Tubes, an Accurate Scope, and a 2 Advanced Target Dummies to Oglethorpe Obnoticus in Booty Bay.",en={7406},ex={3638,3639},l=47,n="Show Your Work",nx=3645,ob={i={{10559},{4407},{4392}}},ps={3642},r=178,rl=30,sk={202,200},sn={7406},x=3150}
T[3644]={en={8126},l=47,n="Membership Card Renewal",ps={3639,3641,3643},r=0,rl=30,sf=1,sk={202,200},sn={8126}}
T[3645]={en={7406},l=47,n="Membership Card Renewal",ps={3639,3641,3643},r=0,rl=30,sf=1,sk={202,200},sn={7406}}
T[3646]={en={8738},l=47,n="Membership Card Renewal",ps={3639,3641,3643},r=0,rl=30,sf=1,sk={202,200},sn={8738}}
T[3647]={en={7944},l=47,n="Membership Card Renewal",ps={3639,3641,3643},r=77,rl=30,sf=1,sk={202,200},sn={7944}}
T[3661]={d="Collect 15 Wildkin Feathers from the Hinterlands for Erelas Ambersky in Rut'theran Village.",en={7916},l=47,n="Favored of Elune?",nx=978,ob={i={{10819}}},r=77,rl=42,sn={7916},x=6300}
T[3681]={c=2,d="Speak with Duthorian Rall in Stormwind.",en={6171},ex={2998},l=12,n="Tome of Divinity",nx=1642,r=1,rl=12,sn={5149},x=225}
T[3701]={d="Venture to the Ruins of Thaurissan in the Burning Steppes and recover information from the Thaurissan Relics. Return to Royal Historian Archesonus when you have recovered the information.",en={8879},l=54,n="The Smoldering Ruins of Thaurissan",nx=4341,ob={o={{153556,"Information Recovered"}}},ps={3702},r=77,rl=50,sn={8879},x=5450}
T[3702]={d="Listen to Royal Historian Archesonus recant the history of Thaurissan.",en={8879},l=54,n="The Smoldering Ruins of Thaurissan",nx=3701,ob={k={{8879}}},r=77,rl=50,sf=2,sn={8879},x=540}
T[3721]={en={7406},l=50,n="An OOX of Your Own",pg={648,836,2767},r=0,rl=45,sn={7406},x=7100}
T[3741]={d="Find Hilary's Necklace, and return it to Hilary in Lakeshire.",en={8962},l=15,n="Hilary's Necklace",ob={i={{10958}}},r=0,rl=12,sn={8965},x=1350}
T[3761]={d="Bring 20 Un'Goro Soil samples to Ghede on the Elder Rise of Thunder Bluff.",en={9076},l=50,n="Un'Goro Soil",nx=3782,ob={i={{11018}}},r=178,rl=47,sn={5769},x=4700}
T[3762]={d="Speak with Arch Druid Hamuul Runetotem in Thunder Bluff.",en={5769},ex={936,3784},l=50,n="Assisting Arch Druid Runetotem",nx=3761,r=178,rl=47,sn={6746},x=470}
T[3763]={d="Speak with Arch Druid Fandral Staghelm in Darnassus.",en={3516},ex={3789,3790},l=50,n="Assisting Arch Druid Staghelm",nx=3764,r=77,rl=47,sn={6735},x=470}
T[3764]={d="Bring 20 Un'Goro Soil samples to Jenal at the Cenarion Enclave in Darnassus.",en={9047},l=50,n="Un'Goro Soil",nx=3781,ob={i={{11018}}},r=77,rl=47,sn={3516},x=4700}
T[3765]={d="Travel to Gershala Nightwhisper in Auberdine.",en={8997},l=24,n="The Corruption Abroad",nx=1275,r=77,rl=18,sn={4984},x=1450}
T[3781]={d="Take the Arch Druid's Seed Voucher to Mathrengyl Bearwalker in the Cenarion Enclave of Darnassus.",en={4217},l=50,n="Morrowgrain Research",nx=3785,ps={3764},r=77,rl=47,sn={3516},su=11103,x=470}
T[3782]={d="Take the Seed Voucher to Bashana Runetotem in Thunder Bluff.",en={9087},l=50,n="Morrowgrain Research",nx=3786,ps={3761},r=178,rl=47,sn={5769},su=11103,x=470}
T[3783]={d="Collect 10 Thick Yeti Furs for Umi Rumplesnicker in Everlook.",en={10305},l=56,n="Are We There, Yeti?",nx=977,ob={i={{12366}}},r=0,rl=52,sn={10305},x=4350}
T[3784]={d="Speak with Arch Druid Hamuul Runetotem in Thunder Bluff.",en={5769},ex={936,3762},l=50,n="Assisting Arch Druid Runetotem",nx=3761,r=178,rl=47,sn={6741},x=470}
T[3785]={d="Use an Evergreen Pouch with a Packet of Tharlendis Seeds and two Un'Goro Soil samples to try and cultivate samples of Morrowgrain.",en={4217},l=50,n="Morrowgrain Research",nx=3803,ob={i={{11040}}},ps={3781},r=77,rl=47,rs={11018,11022},sn={4217},su=11020,x=4700}
T[3786]={d="Use an Evergreen Pouch with a Packet of Tharlendis Seeds and two Un'Goro Soil samples to try and cultivate samples of Morrowgrain.",en={9087},l=50,n="Morrowgrain Research",nx=3804,ob={i={{11040}}},ps={3782},r=178,rl=47,rs={11018,11022},sn={9087},su=11020,x=4700}
T[3787]={d="Speak with Quintis Jonespyre in Feathermoon Stronghold.",en={7879},ex={3788},l=50,n="Jonespyre's Request",nx=3791,ps={3781},r=77,rl=47,sn={5566},x=1200}
T[3788]={d="Speak with Quintis Jonespyre in Feathermoon Stronghold.",en={7879},ex={3787},l=50,n="Jonespyre's Request",nx=3791,ps={3781},r=77,rl=47,sn={7736},x=470}
T[3789]={d="Speak with Arch Druid Fandral Staghelm in Darnassus.",en={3516},ex={3763,3790},l=50,n="Assisting Arch Druid Staghelm",nx=3764,r=77,rl=47,sn={6740},x=470}
T[3790]={d="Speak with Arch Druid Fandral Staghelm in Darnassus.",en={3516},ex={3763,3789},l=50,n="Assisting Arch Druid Staghelm",nx=3764,r=77,rl=47,sn={5111},x=470}
T[3791]={d="Bring 10 Morrowgrain to Quintis Jonespyre in Feathermoon Stronghold.",en={7879},l=50,n="The Mystery of Morrowgrain",nx=3792,ob={i={{11040}}},ps={3781},r=77,rl=47,rs={11018,11022},sn={7879},su=11020,x=4700}
T[3792]={en={7879},l=55,n="Morrowgrain to Feathermoon Stronghold",ob={i={{11040}}},ps={3791},r=77,rl=47,sf=1,sn={7879},x=560}
T[3801]={d="Speak with Franclorn Forgewright if you are interested in obtaining a key to the city major.",en={8888},l=52,n="Dark Iron Legacy",nx=3802,r=0,rl=48,sf=2,sn={8888},tg=81,x=510,z=1584}
T[3802]={d="Slay Fineous Darkvire and recover the great hammer, Ironfel. Take Ironfel to the Shrine of Thaurissan and place it on the statue of Franclorn Forgewright.",eo={164689},l=52,n="Dark Iron Legacy",ob={i={{10999}}},ps={3801},r=0,rl=48,sn={8888},tg=81,x=5100,z=1584}
T[3803]={en={4217},l=55,n="Morrowgrain to Darnassus",ob={i={{11040}}},ps={3785},r=77,rl=47,sf=1,sn={4217},x=4200}
T[3804]={en={9087},l=55,n="Morrowgrain to Thunder Bluff",ob={i={{11040}}},ps={3786},r=178,rl=47,sf=1,sn={9087},x=560}
T[3821]={d="Venture forth to the Burning Steppes and find out what became of Sha'ni Proudtusk.",en={9136},l=52,n="Dreadmaul Rock",nx=3822,r=178,rl=48,sn={9082},x=5100}
T[3822]={d="Recover Sha'ni's Nose-Ring from Krom'Grul and return it to Thal'trak in Kargath. Search the various caves and mines in Dreadmaul Rock.",en={9082},l=53,n="Krom'Grul",ob={i={{11058}}},ps={3821},r=178,rl=48,sn={9136},x=5250}
T[3823]={d="Slay 15 Firegut Ogre-Mages, 7 Firegut Ogres, and 7 Firegut Ogre Brutes, and return to Oralius when you are finished.",en={9177},l=52,n="Extinguish the Firegut",nx=3824,ob={k={{7034},{7033},{7035}}},r=77,rl=48,sn={9177},x=5100}
T[3824]={d="Find Gor'tesh, somewhere to the west of Dreadmaul Rock. Kill Gor'tesh and then take Gor'tesh's Lopped Off Head back to Oralius in Burning Steppes.",en={9177},l=53,n="Gor'tesh the Brute Lord",nx=3825,ob={i={{11080}}},ps={3823},r=77,rl=48,sn={9177},x=5250}
T[3825]={d="Take Gor'tesh's Lopped Off Head and place it at the top of Dreadmaul Rock. Look for a soft dirt mound to plant the pike.",en={9177},l=53,n="Ogre Head On A Stick = Party",ob={o={{160840,"Gor'tesh Head Planted"}}},ps={3824},r=77,rl=48,sn={9177},su=11079,x=5250}
T[3841]={d="Speak to Quentin in Thousand Needles.",en={9238},l=47,n="An Orphan Looking For a Home",nx=3842,ps={2972},r=77,rl=38,sn={7956},su=11102,x=1050}
T[3842]={d="Bring 2 Elixir of Fortitudes to Quentin in Thousand Needles.",en={9238},l=47,n="A Short Incubation",nx=3843,ob={i={{3825}}},ps={3841},r=77,rl=38,sn={9238},x=2100}
T[3843]={d="Take your Fragile Sprite Darter Egg to the Hinterlands and speak to Agnar Beastamer, but hurry, you only have 1 hour to find him before the hatchling within the egg dies.",en={9660},l=47,n="The Newest Member of the Family",nx=4297,ps={3842},r=77,rl=38,sn={9238},su=11471,x=4200}
T[3844]={d="Look around in the pond for a clue about who this wrecked raft may belong to.",eo={161504},l=52,n="It's a Secret to Everybody",nx=3845,r=0,rl=47,so={161505},x=1250}
T[3845]={d="Examine the items inside the pack and bring them to their owner.",en={8737},l=52,n="It's a Secret to Everybody",nx=3908,ob={i={{11104},{11105},{11106}}},ps={3844},r=0,rl=47,so={161504},su=11107,x=5100}
T[3861]={d="Find some Special Chicken Feed and return to your befriended chicken. When you find it, /cheer at it before trying to give it the Special Chicken Feed.",en={620},l=1,n="CLUCK!",ob={i={{11109}}},r=77,rl=1,sf=1,sn={620}}
T[3881]={d="Bring a Crate of Foodstuffs and Research Equipment to Williden Marshal in Un'Goro Crater.",en={9270},l=53,n="Expedition Salvation",ob={i={{11113},{11112}}},r=0,rl=48,sn={9270},x=3950}
T[3882]={d="Bring 8 Dinosaur Bones to Spark Nilminer in Un'Goro Crater.",en={9272},l=51,n="Roll the Bones",ob={i={{11114}}},r=0,rl=49,sn={9272},x=4900}
T[3883]={d="Use the Scraping Vial to collect a Hive Wall Sample from one of the Gorishi hive hatcheries in Un'Goro Crater. Look for the chambers with the hanging larval spawns.",en={9271},l=52,n="Alien Ecology",ob={i={{11131}}},r=0,rl=48,sn={9271},su=11132,x=2550}
T[3884]={d="Return the journal to Williden Marshal somewhere in Un'Goro Crater.",en={9270},l=50,n="Williden's Journal",r=0,rl=48,si={11116},su=11116,x=3550}
T[3901]={d="Kill 12 Rattlecage Skeletons, and then return to Shadow Priest Sarvis in Deathknell when you are done.",en={1569},l=3,n="Rattling the Rattlecages",ob={k={{1890}}},ps={364},r=178,rl=1,sn={1569},x=250}
T[3902]={d="Search Deathknell and the vicinity for 6 pieces of Scavenged Goods, and return them to Deathguard Saltain.",en={1740},l=3,n="Scavenging Deathknell",ob={i={{11127}}},ps={376},r=178,rl=2,sn={1740},x=315}
T[3903]={d="Speak with Milly Osworth.",en={9296},l=4,n="Milly Osworth",nx=3904,ps={18},r=77,rl=2,sn={823},x=35}
T[3904]={d="Bring 8 crates of Milly's Harvest to Milly Osworth at Northshire Abbey.",en={9296},l=4,n="Milly's Harvest",nx=3905,ob={i={{11119}}},ps={18},r=77,rl=2,sn={9296},x=180}
T[3905]={d="Bring the Grape Manifest to Brother Neals in Northshire Abbey.",en={952},l=4,n="Grape Manifest",ps={3904},r=77,rl=2,sn={9296},su=11125,x=355}
T[3906]={d="Travel to the quarry in Blackrock Mountain and slay Overmaster Pyron. Return to Thunderheart when you have completed this assignment.",en={9084},l=52,n="Disharmony of Flame",nx=3907,ob={k={{9026}}},r=178,rl=48,sn={9084},tg=81,x=5100}
T[3907]={d="Enter Blackrock Depths and track down Lord Incendius. Slay him and return any source of information you may find to Thunderheart.",en={9084},l=56,n="Disharmony of Fire",ob={i={{11126}},k={{9017}}},ps={3906},r=178,rl=48,sn={9084},tg=81,x=7300,z=1584}
T[3908]={d="Take Linken's Sword to Donova Snowden in Winterspring.",en={9298},l=52,n="It's a Secret to Everybody",nx=3909,ps={3845},r=0,rl=47,sn={8737},su=11133,x=5100}
T[3909]={d="Seek out Gregan Brewspewer in northern Feralas. From him, learn how you may acquire the Videre Elixir, then return to Donova Snowden in Winterspring.",en={9298},l=52,n="The Videre Elixir",nx=3912,ob={i={{11243}}},ps={3908},r=0,rl=47,rs={11141,11242},sn={9298},x=5100}
T[3912]={d="Go to the graveyard outside Gadgetzan, and use the Videre Elixir. Follow the rest of Donova's instructions to find Gaeriyan.",en={9299},l=52,n="Meet at the Grave",nx=3913,ps={3909},r=0,rl=47,rs={11243},sn={9298},su=11136,x=5100}
T[3913]={d="Resurrect, then look for the gravestone that Gaeriyan told you to find.",eo={148504},l=52,n="A Grave Situation",nx=3914,ps={3912},r=0,rl=47,sn={9299},su=11136,x=2550}
T[3914]={d="Deliver Linken's Superior Sword to Linken in Un'Goro Crater.",en={8737},l=52,n="Linken's Sword",nx=3941,ps={3913},r=0,rl=47,so={148504},su=11162,x=5100}
T[3921]={d="Bring the Broken Samophlange to Wenikee Boltbucket.",en={9316},l=14,n="Wenikee Boltbucket",nx=3922,ps={902},r=178,rl=10,sn={3442},su=11142,x=490}
T[3922]={d="Bring 15 Nugget Slugs to Wenikee Boltbucket in the Barrens.",en={9316},l=15,n="Nugget Slugs",nx=3923,ob={i={{11143}}},ps={3921},r=178,rl=10,sn={9316},x=1050}
T[3923]={d="Bring the Broken and Battered Samophlange to Rilli Greasygob in Orgrimmar.",en={9317},l=18,n="Rilli Greasygob",nx=3924,ps={3922},r=178,rl=10,sn={9316},su=11146,x=340}
T[3924]={d="Bring the Samophlange Manual to Rilli Greasygob in Orgrimmar.",en={9317},l=19,n="Samophlange Manual",ob={i={{11149}}},ps={3923},r=178,rl=10,rs={11148,11147},sn={9317},x=1800}
T[3941]={d="Find J.D. Collie in the cave at Marshal's Refuge.",en={9117},l=52,n="A Gnome's Assistance",nx=3942,ps={3914},r=0,rl=47,sn={8737},x=1250}
T[3942]={d="Find Eridan Bluewind in southern Felwood.",en={9116},l=54,n="Linken's Memory",nx=4084,ps={3941},r=0,rl=47,sn={9117},x=5450}
T[3961]={d="Take the Silver Totem of Aquementas to Linken in Marshal's Refuge.",en={8737},l=54,n="Linken's Adventure",nx=3962,ps={4005},r=0,rl=47,sn={9117},su=11522,x=2700}
T[3962]={d="Travel to Fire Plume Ridge, south of Marshal's Refuge.",en={8737},l=56,n="It's Dangerous to Go Alone",ob={i={{11179}},k={{9376}}},ps={3961},r=0,rl=47,sn={8737},su=11522,tg=1,x=7300}
T[3981]={d="Find Commander Gor'shak in Blackrock Depths.",en={9020},l=52,n="Commander Gor'shak",nx=3982,ps={3906},r=178,rl=48,sn={9081},tg=81,x=5100,z=1584}
T[3982]={d="Defend Gor'shak.",en={9020},l=54,n="What Is Going On?",nx=4001,ob={k={{9020}}},ps={3981},r=178,rl=48,sf=3,sn={9020},tg=81,x=4100,z=1584}
T[4001]={d="Speak with Kharan Mighthammer and gather information about Princess Moira Bronzebeard's kidnapping. Take that information to Thrall in Orgrimmar.",en={4949},l=54,n="What Is Going On?",nx=4002,ob={k={{9021}}},ps={3982},r=178,rl=48,sf=2,sn={9020},tg=81,x=540,z=1584}
T[4002]={d="Speak with Thrall if you are prepared to take on the mission he has planned.",en={4949},l=54,n="The Eastern Kingdom",nx=4003,ps={4001},r=178,rl=48,sn={4949},tg=81,z=1584}
T[4003]={d="Slay Emperor Dagran Thaurissan and free Princess Moira Bronzebeard from his evil spell. ",en={8929},l=59,n="The Royal Rescue",nx=4004,ob={k={{9019}}},ps={4002},r=178,rl=48,sn={4949},tg=81,x=8050,z=1584}
T[4004]={d="Return to Thrall!",en={4949},l=60,n="The Princess Saved?",ps={4003},r=178,rl=48,sn={8929},tg=81,x=9950,z=1584}
T[4005]={d="Take the Book of Aquor, the Silvery Claws, and the Irontree Heart to Tanaris.",en={9117},l=54,n="Aquementas",nx=3961,ob={i={{11522}}},ps={4084},r=0,rl=47,rs={11169,11172,11173},sn={9116},su=11617,x=5450}
T[4021]={d="Bring a Piece of Krom'zar's Banner to Regthar Deathgate, west of the Crossroads.",en={3389},l=20,n="Counterattack!",ob={i={{11227}}},ps={852},r=178,rl=11,sn={3389},x=1950}
T[4022]={d="Show Cyrus Therepentous the Black Dragonflight Molt you received from Kalaran Windblade.",en={9459},ex={4023},l=54,n="A Taste of Flame",nx=4024,ob={c={{{9459}}},i={{10575}}},ps={3481},r=0,rl=52,sn={9459},x=5450}
T[4023]={d="Show Cyrus Therepentous proof of your worth.",en={9459},ex={4022},l=54,n="A Taste of Flame",nx=4024,ob={i={{10575}}},r=0,rl=52,sn={9459},tg=1,x=5450}
T[4024]={d="Travel to Blackrock Depths and slay Bael'Gar.",en={9459},l=58,n="A Taste of Flame",ob={i={{11230}}},ps={4022,4023},r=0,rl=52,sn={9459},su=11231,tg=81,x=6200,z=1584}
T[4041]={en={7775},l=52,n="The Videre Elixir",ob={i={{11242}}},pa=3909,r=0,rl=47,sf=1,sn={7775}}
T[4061]={d="Venture to the Burning Steppes and recover 10 Fractured Elemental Shards for Hierophant Theodora Mulvadania.",en={9079},l=54,n="The Rise of the Machines",nx=4062,ob={i={{11266}}},r=178,rl=52,sn={9079},x=5450}
T[4062]={d="Take the Elemental Shard Sample to Lotwil Veriatus.",en={2921},l=54,n="The Rise of the Machines",nx=4063,ps={4061},r=178,rl=52,sn={9079},su=11267,x=1350}
T[4063]={d="Find and slay Golem Lord Argelmach. Return his head to Lotwil. You will also need to collect 10 Intact Elemental Cores from the Ragereaver Golems and Warbringer Constructs protecting Argelmach. You know this because you are psychic.",en={2921},l=58,n="The Rise of the Machines",ob={i={{11268},{11269}}},ps={4062},r=178,rl=52,sn={2921},tg=81,x=6200,z=1584}
T[4081]={d="Venture to Blackrock Depths and destroy the vile aggressors!",en={9077},l=52,n="KILL ON SIGHT: Dark Iron Dwarves",nx=4082,ob={k={{8891},{8890},{8892}}},r=178,rl=48,so={164867},tg=81,x=5100,z=1584}
T[4082]={d="Venture to Blackrock Depths and destroy the vile aggressors!",en={9077},l=54,n="KILL ON SIGHT: High Ranking Dark Iron Officials",nx=4122,ob={k={{8894},{8893},{8895}}},ps={4081},r=178,rl=50,so={164868},tg=81,x=5450,z=1584}
T[4083]={eo={164869},l=55,n="The Spectral Chalice",ob={i={{7910},{3577},{6037}}},r=0,rl=40,sk={186,230},so={164869},tg=81,x=560,z=1584}
T[4084]={d="Collect 11 Silvery Claws and 1 Irontree Heart for Eridan Bluewind in Felwood.",en={9116},l=54,n="Silver Heart",nx=4005,ob={i={{11172},{11173}}},ps={3942},r=0,rl=47,sn={9116},x=5650}
T[4101]={d="Bring 15 Blood Amber to Arathandris Silversky in Felwood.",en={9528},l=55,n="Cleansing Felwood",nx=5882,ob={i={{11503}}},r=77,rl=48,sn={9528},x=5650}
T[4102]={d="Bring 15 Blood Amber to Maybess Riverbreeze in Felwood.",en={9529},l=55,n="Cleansing Felwood",ob={i={{11503}}},r=178,rl=48,sn={9529},x=5650}
T[4103]={en={9528},l=55,n="Salve via Hunting",ob={i={{11515}}},ps={5882},r=77,rl=48,sf=1,sn={9528},x=4200}
T[4104]={en={9528},l=55,n="Salve via Mining",ob={i={{11513}}},ps={5883},r=77,rl=48,sf=1,sk={186,200},sn={9528},x=4200}
T[4105]={en={9528},l=55,n="Salve via Gathering",ob={i={{11514}}},ps={5884},r=77,rl=48,sf=1,sk={182,200},sn={9528},x=4200}
T[4106]={en={9528},l=55,n="Salve via Skinning",ob={i={{11512}}},ps={5885},r=77,rl=48,sf=1,sk={393,200},sn={9528},x=4200}
T[4107]={en={9528},l=55,n="Salve via Disenchanting",ob={i={{11174}}},ps={5886},r=77,rl=48,sf=1,sk={333,200},sn={9528},x=4200}
T[4108]={en={9529},l=55,n="Salve via Hunting",ob={i={{11515}}},ps={5887},r=178,rl=48,sf=1,sn={9529}}
T[4109]={en={9529},l=55,n="Salve via Mining",ob={i={{11513}}},ps={5888},r=178,rl=48,sf=1,sk={186,200},sn={9529}}
T[4110]={en={9529},l=55,n="Salve via Gathering",ob={i={{11514}}},ps={5889},r=178,rl=48,sf=1,sk={182,200},sn={9529}}
T[4111]={en={9529},l=55,n="Salve via Skinning",ob={i={{11512}}},ps={5890},r=178,rl=48,sf=1,sk={393,200},sn={9529}}
T[4112]={en={9529},l=55,n="Salve via Disenchanting",ob={i={{11174}}},ps={5891},r=178,rl=48,sf=1,sk={333,200},sn={9529}}
T[4113]={eo={174596},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={174596},x=560}
T[4114]={eo={174597},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={174597},x=560}
T[4115]={eo={173327},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={173327},x=560}
T[4116]={eo={174598},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={174598},x=560}
T[4117]={eo={164888},l=55,n="Corrupted Whipper Root",ob={i={{11516}}},r=0,rl=48,sf=1,so={164888},x=560}
T[4118]={eo={174712},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={174712},x=560}
T[4119]={eo={164885},l=55,n="Corrupted Night Dragon",ob={i={{11516}}},r=0,rl=48,sf=1,so={164885},x=560}
T[4120]={d="Talo Thornhoof at Camp Mojache in Feralas wants you to kill 12 Angerclaw Grizzlies and 12 Felpaw Ravagers in Felwood.",en={7776},l=52,n="The Strength of Corruption",ob={k={{8957},{8961}}},r=178,rl=47,sn={7776},x=5100}
T[4121]={d="Escort your prisoner, Grark Lorkrub, through Burning Steppes and through Blackrock Mountain to the Searing Gorge.",en={9080},es=1,l=58,n="Precarious Predicament",nx=4132,ob={e={"Prisoner Transport",{{1428,25.7,27.1}}},i={{11286}}},ps={4122},r=178,rl=52,sf=2,sn={9520},tg=81,x=7750,z=1584}
T[4122]={d="Travel to the Burning Steppes and find Grark Lorkrub. You recall Lexlort mentioning that he was last seen in a massive Blackrock fortress.",en={9520},l=58,n="Grark Lorkrub",nx=4121,ps={4082},r=178,rl=52,sn={9080},su=11286,tg=81,x=6200,z=1584}
T[4123]={d="Bring the Heart of the Mountain to Maxwort Uberglint in the Burning Steppes.",en={9536},l=55,n="The Heart of the Mountain",ob={i={{11309}}},r=0,rl=50,rs={11078},sn={9536},tg=81,x=5650,z=1584}
T[4124]={d="Speak with Ginro Hearthkindle in Feathermoon Stronghold.",en={7880},l=43,n="The Missing Courier",nx=4125,r=77,rl=40,sn={7877},x=360}
T[4125]={d="Locate the courier's boat somewhere along the coast of Feralas.",eo={164909},l=43,n="The Missing Courier",nx=4127,ps={4124},r=77,rl=40,sn={7880},x=2700}
T[4126]={d="Bring the Lost Thunderbrew Recipe to Ragnar Thunderbrew in Kharanos.",en={1267},l=55,n="Hurley Blackbreath",ob={i={{11312}}},r=77,rl=50,sn={1267},tg=81,x=5650,z=1584}
T[4127]={d="Return to Feathermoon Stronghold and show Ginro Hearthkindle the Discarded Knife you have found.",en={7880},l=44,n="Boat Wreckage",nx=4129,ps={4125},r=77,rl=40,so={164909,186419},su=11462,x=375}
T[4128]={d="Speak with Ragnar Thunderbrew.",en={1267},l=55,n="Ragnar Thunderbrew",nx=4126,r=77,rl=50,sn={9540},tg=81,x=560,z=1584}
T[4129]={d="Take the Discarded Knife to Quintis Jonespyre in Feathermoon Stronghold.",en={7879},l=44,n="The Knife Revealed",nx=4130,ps={4127},r=77,rl=40,sn={7880},su=11462,x=375}
T[4130]={d="Speak with Ginro Hearthkindle in Feathermoon Stronghold.",en={7880},l=44,n="Psychometric Reading",nx=4131,ps={4129},r=77,rl=40,sn={7879},x=375}
T[4131]={d="Search the Woodpaw Gnoll camps of southern Feralas for evidence of the courier's belongings or the courier himself.",eo={164953},l=44,n="The Woodpaw Gnolls",nx=4135,ps={4130},r=77,rl=40,sn={7880},x=2800}
T[4132]={d="Travel to Blackrock Depths and slay General Angerforge! Return to Warlord Goretooth when the task is complete.",en={9077},l=58,n="Operation: Death to Angerforge",ob={k={{9033}}},ps={4121},r=178,rl=52,sn={9077},tg=81,x=7750,z=1584}
T[4133]={d="Speak with Shadowmaster Vivian Lagrave in Kargath.",en={9078},l=55,n="Vivian Lagrave",nx=4134,r=178,rl=50,sn={5204},tg=81,x=560,z=1584}
T[4134]={d="Bring the Lost Thunderbrew Recipe to Vivian Lagrave in Kargath.",en={9078},l=55,n="Lost Thunderbrew Recipe",ob={i={{11312}}},r=178,rl=50,sn={9078},tg=81,x=5650,z=1584}
T[4135]={d="Now that Raschal's last known whereabouts have been discovered, continue your search for him or his remains in the Writhing Deep. According to the note, it is located to the south of the Woodpaw gnoll camps.",eo={164954},l=46,n="The Writhing Deep",nx=4265,ps={4131},r=77,rl=40,so={164953},su=11463,x=3050}
T[4136]={d="Bring Ribbly's Head to Yuka Screwspigot in the Burning Steppes.",en={9544},l=53,n="Ribbly Screwspigot",ob={i={{11313}}},r=0,rl=48,sn={9544},tg=81,x=2650,z=1584}
T[4141]={d="Collect 15 Bloodpetals and return to Muigin.",en={9119},l=52,n="Muigin and Larion",nx=4142,ob={i={{11316}}},r=77,rl=47,sn={9119},x=5100}
T[4142]={d="Take a Bloodpetal to Gregan Brewspewer in Feralas.",en={7775},l=52,n="A Visit to Gregan",nx=4143,ps={4141},r=77,rl=47,sn={9119},su=11316,x=3800}
T[4143]={d="Collect 5 samples of Atal'ai Haze, then return to Muigin in Un'Goro Crater.",en={9119},l=52,n="Haze of Evil",nx=4144,ob={i={{11318}}},ps={4142},r=77,rl=47,sn={7775},tg=81,x=5100,z=1477}
T[4144]={en={9119},l=53,n="Bloodpetal Sprouts",ob={i={{11315}}},ps={4143},r=77,rl=47,sn={9119},x=3950}
T[4145]={d="Hunt 5 Bloodpetal Lashers, 5 Bloodpetal Threshers, 5 Bloodpetal Flayers and 5 Bloodpetal Trappers for Larion at Marshal's Refuge.",en={9118},l=52,n="Larion and Muigin",nx=4147,ob={k={{6509},{6512},{6510},{6511}}},r=178,rl=47,sn={9118},x=5100}
T[4146]={d="Deliver the Unloaded Zapper and 5 samples of Atal'ai Haze to Larion in Marshal's Refuge.",en={9118},l=52,n="Zapper Fuel",nx=4148,ob={i={{11318}}},ps={4147},r=178,rl=47,sn={8496},su=11319,tg=1,x=5100,z=1477}
T[4147]={d="Travel to Marvon Rivetseeker's workshop in Ratchet.",en={8496},l=52,n="Marvon's Workshop",nx=4146,ps={4145},r=178,rl=47,sn={9118},x=2550}
T[4148]={en={9118},l=53,n="Bloodpetal Zapper",ob={i={{11315}}},ps={4146},r=178,rl=47,sn={9118},tg=81,x=3950}
T[4161]={d="Collect 7 Small Spider Legs for Zarrin in Dolanaar.",en={6286},l=7,n="Recipe of the Kaldorei",ob={i={{5465}}},r=77,rl=1,sk={185,1},sn={6286},x=630}
T[4181]={d="If you wish to learn more about Goblin Engineering, take the Manual of Engineering Disciplines to Nixx Sprocketspring in Gadgetzan.",en={8126},ex={3526,3629,3633,3640,3642},l=47,n="Goblin Engineering",nx=3638,r=77,rl=30,sk={202,200},sn={5518},su=10789,x=420}
T[4182]={d="Slay 15 Black Broodlings, 10 Black Dragonspawn, 4 Black Wyrmkin and 1 Black Drake. Return to Helendis Riverhorn when the task is complete.",en={9562},l=54,n="Dragonkin Menace",nx=4183,ob={k={{7047},{7040},{7044},{7041}}},r=77,rl=48,sn={9562},tg=1,x=5450}
T[4183]={d="Travel to Lakeshire and deliver Helendis Riverhorn's Letter to Magistrate Solomon.",en={344},l=54,n="The True Masters",nx=4184,ps={4182},r=77,rl=48,sn={9562},su=11366,x=4100}
T[4184]={d="Travel to Stormwind and deliver Solomon's Plea to Highlord Bolvar Fordragon.",en={1748},l=54,n="The True Masters",nx=4185,ps={4183},r=77,rl=48,sn={344},su=11367,x=4100}
T[4185]={d="Speak with Highlord Bolvar Fordragon after speaking with Lady Katrana Prestor.",en={1748},l=54,n="The True Masters",nx=4186,ob={k={{1749}}},ps={4184},r=77,rl=48,sf=2,sn={1748},x=540}
T[4186]={d="Take Bolvar's Decree to Magistrate Solomon in Lakeshire.",en={344},l=54,n="The True Masters",nx=4223,ps={4185},r=77,rl=48,sn={1748},su=11368,x=5450}
T[4201]={d="Bring 4 Gromsblood, 10 Giant Silver Veins and Nagmara's Filled Vial to Mistress Nagmara in Blackrock Depths.",en={9500},l=54,n="The Love Potion",ob={i={{8846},{11405},{11413}}},r=0,rl=50,sn={9500},su=11412,tg=81,x=5450,z=1584}
T[4221]={eo={174599},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174599},x=560}
T[4222]={eo={174600},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174600},x=560}
T[4223]={d="Speak with Marshal Maxwell in the Burning Steppes.",en={9560},l=54,n="The True Masters",nx=4224,ps={4186},r=77,rl=48,sn={344},x=540}
T[4224]={d="Speak with Ragged John to learn of Marshal Windsor's fate and return to Marshal Maxwell when you have completed this task.",en={9560},l=54,n="The True Masters",nx=4241,ob={k={{9563}}},ps={4223},r=77,rl=48,sf=2,sn={9560},x=540}
T[4241]={d="Travel to Blackrock Mountain in the northwest and enter Blackrock Depths. Find out what became of Marshal Windsor.",en={9023},l=54,n="Marshal Windsor",nx=4242,ps={4224},r=77,rl=48,sn={9560},tg=81,x=5450,z=1584}
T[4242]={d="Give Marshal Maxwell the bad news.",en={9560},l=54,n="Abandoned Hope",nx=4264,ps={4241},r=77,rl=48,sn={9023},tg=81,x=5450,z=1584}
T[4243]={d="Find A-Me 01 in Un'Goro Crater.",en={9623},l=53,n="Chasing A-Me 01",nx=4244,r=0,rl=48,sn={9618},x=2650}
T[4244]={d="Find a Mithril Casing and return to A-Me 01 in Un'Goro Crater.",en={9623},l=53,n="Chasing A-Me 01",nx=4245,ob={i={{10561}}},ps={4243},r=0,rl=48,sn={9623},x=3950}
T[4245]={d="Escort A-Me 01 back to Karna Remtravel in Un'Goro Crater.",en={9618},es=1,l=53,n="Chasing A-Me 01",ob={e={"Protect A-Me 01 until you reach Karna Remtravel",{{1449,46.4,13.8}}}},ps={4244},r=0,rl=48,sf=2,sn={9623},x=6550}
T[4261]={d="Escort Arei to safety, then speak with Kayneth Stillwind in Forest Song, in eastern Ashenvale.",en={3848},es=1,l=56,n="Ancient Spirit",ob={e={"Help Arei get to Safety",{{1448,49.4,14.5}}}},ps={4442},r=77,rl=49,sf=2,sn={9598},x=7300}
T[4262]={d="Slay Overmaster Pyron and return to Jalinda Sprig.",en={9561},l=52,n="Overmaster Pyron",nx=4263,ob={k={{9026}}},r=77,rl=48,sn={9561},tg=81,x=5100}
T[4263]={d="Find Lord Incendius in Blackrock Depths and destroy him!",en={9561},l=56,n="Incendius!",ob={k={{9017}}},ps={4262},r=77,rl=48,sn={9561},tg=81,x=5800,z=1584}
T[4264]={d="You may have just stumbled on to something that Marshal Windsor would be interested in seeing. There may be hope, after all.",en={9023},l=58,n="A Crumpled Up Note",nx=4282,ps={4242},r=77,rl=50,si={11446},su=11446,tg=81,x=6200,z=1584}
T[4265]={d="Free Raschal from the Zukk'ash hive.",en={7880},l=46,n="Freed from the Hive",nx=4266,ob={e={"Free Raschal.",{{1444,72.1,63.8}}}},ps={4135},r=77,rl=40,sf=2,so={164954},x=4050}
T[4266]={d="Speak with Shandris Feathermoon in Feathermoon Stronghold.",en={3936},l=46,n="A Hero's Welcome",nx=4267,ps={4265},r=77,rl=40,sn={7880},x=6050}
T[4267]={d="Bring Raschal's Report to Gracina Spiritmight in Darnassus.",en={7740},l=46,n="Rise of the Silithid",ps={4266},r=77,rl=40,sn={3936},su=11466,x=405}
T[4281]={d="Bring the Undelivered Parcel to Falfindel Waywarder in Thalanaar.",en={4048},l=44,n="Thalanaar Delivery",ps={4131},r=77,rl=40,si={11463},su=11463,x=2800}
T[4282]={d="Return Marshal Windsor's Lost Information.",en={9023},l=58,n="A Shred of Hope",nx=4322,ob={i={{11464},{11465}}},ps={4264},r=77,rl=50,sn={9023},tg=81,x=6200,z=1584}
T[4283]={d="Oralius wants 50 Blackrock Medallions. Chances are high that these medallions can be found on the orcs in the Burning Steppes.",en={9177},l=56,n="FIFTY! YEP!",ob={i={{11467}}},r=77,rl=50,sn={9177},x=5800}
T[4284]={d="Collect 7 Power Crystals of each color: red, blue, yellow, and green. Bring them to J.D. Collie at Marshal's Refuge.",en={9117},l=53,n="Crystals of Power",ob={i={{11186},{11188},{11185},{11184}}},r=0,rl=47,sn={9117},x=5250}
T[4285]={d="Discover the location of the Northern Crystal Pylon in Un'Goro Crater.",en={9117},l=53,n="The Northern Pylon",ob={o={{164955}}},ps={4284},r=0,rl=47,sf=2,sn={9117},x=3950}
T[4286]={d="Travel to Blackrock Depths and recover 20 Dark Iron Fanny Packs. Return to Oralius when you have completed this task. You assume that the Dark Iron dwarves inside Blackrock Depths carry these 'fanny pack' contraptions.",en={9177},l=56,n="The Good Stuff",ob={i={{11468}}},r=77,rl=50,sn={9177},tg=81,x=5800,z=1584}
T[4287]={d="Discover the location of the Eastern Crystal Pylon in Un'Goro Crater.",en={9117},l=53,n="The Eastern Pylon",ob={o={{164957}}},ps={4284},r=0,rl=47,sf=2,sn={9117},x=3950}
T[4288]={d="Discover the location of the Western Crystal Pylon.",en={9117},l=53,n="The Western Pylon",ob={o={{164956}}},ps={4284},r=0,rl=47,sf=2,sn={9117},x=3950}
T[4289]={d="Bring 2 Un'Goro Gorilla Pelts, 2 Un'Goro Stomper Pelts, and 2 Un'Goro Thunderer Pelts to Torwa Pathfinder at the entrance of Un'Goro Crater.",en={9619},l=55,n="The Apes of Un'Goro",nx=4301,ob={i={{11478},{11479},{11480}}},r=0,rl=47,sn={9619},x=5650}
T[4290]={d="Find the carcass of Lar'korwi's freshest kill and steal a Piece of Threshadon Carcass before returning to Torwa Pathfinder in Un'Goro Crater.",en={9619},l=53,n="The Fare of Lar'korwi",nx=4291,ob={i={{11504}}},r=0,rl=48,sn={9619},x=5250}
T[4291]={d="Bring 2 Ravasaur Pheromone Glands to Torwa Pathfinder near the entrance to Un'Goro Crater.",en={9619},l=53,n="The Scent of Lar'korwi",nx=4292,ob={i={{11509}}},ps={4290},r=0,rl=48,sn={9619},x=5250}
T[4292]={d="Using the contents of Torwa's Pouch, summon Lar'korwi and defeat him. Then bring Lar'korwi's Head to Torwa Pathfinder near the entrance to Un'Goro Crater.",en={9619},l=56,n="The Bait for Lar'korwi",ob={i={{11510}}},ps={4291},r=0,rl=48,rs={11569,11570},sn={9619},su=11568,x=7300}
T[4293]={d="Gather Felwood Slime Samples from any of the slimes in Felwood. Then, using the Testing Equipment next to Chemist Fuely in Undercity, see which of your samples are the most corrupt. Bring 5 of the Corrupted Felwood Samples you find to Chemist Fuely.",en={10136},l=52,n="A Sample of Slime...",ob={i={{12234}}},r=178,rl=48,rs={12230},sn={10136},x=5100}
T[4294]={d="Gather Un'Goro Slime Samples from any of the slimes in Un'Goro Crater. Then, using the Testing Equipment next to Chemist Fuely in Undercity, see which of your samples are the most pure. Bring 5 of the Pure Un'Goro Samples you find to Chemist Fuely.",en={10136},l=56,n="... and a Batch of Ooze",ob={i={{12236}}},r=178,rl=48,rs={12235},sn={10136},x=5800}
T[4295]={en={9503},l=1,n="Rocknot's Ale",ob={i={{11325}}},r=0,rl=42,sf=1,sn={9503},tg=81,z=1584}
T[4296]={d="Bring the Tablet Transcript to Maxwort Uberglint in the Burning Steppes.",en={9536},l=50,n="Tablet of the Seven",ob={i={{11470}}},r=0,rl=50,sn={9536},x=2350}
T[4297]={d="Bring 5 Silvermane Stalker Flanks to Agnar Beastamer in Hinterlands.",en={9660},l=47,n="Food for Baby",nx=4298,ob={i={{11472}}},ps={3843},r=77,rl=38,sn={9660},x=4200}
T[4298]={d="Speak to Agnar Beastamer in the Hinterlands.",en={9660},l=48,n="Becoming a Parent",ps={4297},r=77,rl=37,sn={9660},x=440}
T[4300]={d="Bring 8 White Ravasaur Claws to Jes'rimon in Orgrimmar.",en={8659},l=52,n="Bone-Bladed Weapons",ob={i={{11477}}},r=178,rl=48,sn={8659},x=5100}
T[4301]={d="Bring U'cha's Pelt to Torwa Pathfinder at the entrance of Un'Goro Crater.",en={9619},l=55,n="The Mighty U'cha",ob={i={{11476}}},ps={4289},r=0,rl=50,sn={9619},x=5650}
T[4321]={d="Speak with J.D. Collie in a moment.",en={9117},l=53,n="Making Sense of It",pg={4285,4287,4288},r=0,rl=47,sf=2,sn={9117},x=530}
T[4322]={d="Help Marshal Windsor get his gear back and free his friends. Return to Marshal Maxwell if you succeed.",en={9560},l=58,n="Jail Break!",nx=6402,ps={4282},r=77,rl=50,sf=2,sn={9023},tg=81,x=7750,z=1584}
T[4324]={d="Speak with Yuka Screwspigot in the Burning Steppes.",en={9544},l=53,n="Yuka Screwspigot",nx=4136,r=0,rl=48,sn={9706},tg=81,x=2650,z=1584}
T[4341]={d="Travel to Blackrock Depths and find Kharan Mighthammer.",en={9021},l=59,n="Kharan Mighthammer",nx=4342,ps={3701},r=77,rl=50,sn={2784},tg=81,x=6400,z=1584}
T[4342]={d="Listen as Kharan Mighthammer tells his story.",en={9021},l=59,n="Kharan's Tale",nx=4361,ob={k={{9021}}},ps={4341},r=77,rl=50,sf=2,sn={9021},tg=81,x=1600,z=1584}
T[4343]={eo={164887},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={164887},x=560}
T[4361]={d="Return to Ironforge and deliver the bad news to King Magni Bronzebeard.",en={2784},l=59,n="The Bearer of Bad News",nx=4362,ps={4342},r=77,rl=50,sn={9021},tg=81,x=6400,z=1584}
T[4362]={d="Return to Blackrock Depths and rescue Princess Moira Bronzebeard from the evil clutches of Emperor Dagran Thaurissan.",en={8929},l=59,n="The Fate of the Kingdom",nx=4363,ob={k={{9019}}},ps={4361},r=77,rl=50,sn={2784},tg=81,x=8050,z=1584}
T[4363]={d="Return to Ironforge and speak with King Magni Bronzebeard.",en={2784},l=59,n="The Princess's Surprise",ps={4362},r=77,rl=50,sn={8929},tg=81,x=9650,z=1584}
T[4381]={eo={164955},l=53,n="Crystal Restore",ob={i={{11188},{11185}}},ps={4321},r=0,rl=47,sf=1,so={164955}}
T[4382]={eo={164957},l=53,n="Crystal Force",ob={i={{11185},{11184}}},ps={4321},r=0,rl=47,sf=1,so={164957}}
T[4383]={eo={164956},l=53,n="Crystal Ward",ob={i={{11186},{11185}}},ps={4321},r=0,rl=47,sf=1,so={164956}}
T[4384]={eo={164956},l=53,n="Crystal Yield",ob={i={{11186},{11184}}},ps={4321},r=0,rl=47,sf=1,so={164956}}
T[4385]={eo={164955},l=53,n="Crystal Charge",ob={i={{11186},{11188}}},ps={4321},r=0,rl=47,sf=1,so={164955}}
T[4386]={eo={164957},l=53,n="Crystal Spire",ob={i={{11184},{11188}}},ps={4321},r=0,rl=47,sf=1,so={164957}}
T[4401]={eo={174713},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={174713},x=560}
T[4402]={d="Bring Galgar 10 Cactus Apples. You remember him saying that they could be found near cactuses.",en={9796},l=3,n="Galgar's Cactus Apple Surprise",ob={i={{11583}}},ps={788},r=178,rl=1,sn={9796},x=380}
T[4403]={eo={174601},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174601},x=560}
T[4421]={d="Kill 11 Jadefire Felsworns, 9 Jadefire Shadowstalkers, 9 Jadefire Rogues, and Xavathras. Return to Eridan Bluewind in Felwood when the task has been completed.",en={9116},l=54,n="The Corruption of the Jadefire",nx=4906,ob={k={{7109},{7110},{7106},{9454}}},r=77,rl=49,sn={9116},x=5450}
T[4441]={d="Travel to Darnassus and use Eridan's Vial to collect a Vial of Blessed Water from the Temple of the Moon. Return to Eridan with the filled vial.",en={9116},l=54,n="Felbound Ancients",nx=4442,ob={i={{5646}}},ps={939},r=77,rl=49,sn={9116},su=11682,x=5450}
T[4442]={d="Speak to Eridan again in a moment.",en={9116},l=54,n="Purified!",nx=4261,ps={4441},r=77,rl=49,sn={9116},x=5450}
T[4443]={eo={173284},l=55,n="Corrupted Whipper Root",ob={i={{11516}}},r=0,rl=48,sf=1,so={173284},x=560}
T[4444]={eo={174605},l=55,n="Corrupted Whipper Root",ob={i={{11516}}},r=0,rl=48,sf=1,so={174605},x=560}
T[4445]={eo={174606},l=55,n="Corrupted Whipper Root",ob={i={{11516}}},r=0,rl=48,sf=1,so={174606},x=560}
T[4446]={eo={174607},l=55,n="Corrupted Whipper Root",ob={i={{11516}}},r=0,rl=48,sf=1,so={174607},x=560}
T[4447]={eo={173324},l=55,n="Corrupted Night Dragon",ob={i={{11516}}},r=0,rl=48,sf=1,so={173324},x=560}
T[4448]={eo={174608},l=55,n="Corrupted Night Dragon",ob={i={{11516}}},r=0,rl=48,sf=1,so={174608},x=560}
T[4449]={d="Kill 8 Dark Iron Geologists and bring 15 pieces of Silk Cloth to the person locked in the outhouse in Searing Gorge.",eo={173265},l=45,n="Caught!",nx=4450,ob={i={{4306}},k={{5839}}},r=0,rl=43,so={173265},x=3900}
T[4450]={d="Take the copy of Goodsteel's Ledger and then find the items listed in it before seeking Krinkle Goodsteel in Tanaris.",en={5411},l=46,n="Ledger from Tanaris",ob={i={{11727},{11725},{11724},{11723}}},ps={4449},r=0,rl=43,so={173265},x=5050}
T[4451]={d="Search Searing Gorge and find a use for the Grimesilt Outhouse Key you have found.",eo={173265},l=47,n="The Key to Freedom",r=0,rl=43,si={11818},su=11818,x=5250}
T[4461]={eo={174686},l=55,n="Corrupted Whipper Root",ob={i={{11516}}},r=0,rl=48,sf=1,so={174686},x=560}
T[4462]={eo={174684},l=55,n="Corrupted Night Dragon",ob={i={{11516}}},r=0,rl=48,sf=1,so={174684},x=560}
T[4463]={en={9836},l=55,n="Libram of Rumination",ob={i={{11754},{11752},{8424},{11732}}},r=0,rl=50,sf=1,sn={9836}}
T[4464]={eo={171942},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={171942},x=560}
T[4465]={eo={171939},l=55,n="Corrupted Songflower",ob={i={{11516}}},r=0,rl=48,sf=1,so={171939},x=560}
T[4466]={eo={174604},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174604},x=560}
T[4467]={eo={174708},l=55,n="Corrupted Windblossom",ob={i={{11516}}},r=0,rl=48,sf=1,so={174708},x=560}
T[4481]={en={9836},l=55,n="Libram of Constitution",ob={i={{11754},{8411},{11733},{11952}}},r=0,rl=50,sf=1,sn={9836}}
T[4482]={en={9836},l=55,n="Libram of Tenacity",ob={i={{11754},{11734},{11564},{11753}}},r=0,rl=50,sf=1,sn={9836}}
T[4483]={en={9836},l=55,n="Libram of Resilience",ob={i={{11754},{11567},{11751},{11736}}},r=0,rl=50,sf=1,sn={9836}}
T[4484]={en={9836},l=55,n="Libram of Voracity",ob={i={{11754},{11737},{11951},{11563}}},r=0,rl=50,sf=1,sn={9836}}
T[4485]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},ex={1661,4486},l=40,n="The Tome of Nobility",r=5,rl=40,sn={6179},x=315}
T[4486]={c=2,d="Speak to Duthorian Rall in Stormwind.",en={6171},ex={1661,4485},l=40,n="The Tome of Nobility",r=5,rl=40,sn={5149},x=315}
T[4487]={c=256,d="Speak to Strahad Farsan in Ratchet.",en={6251},ex={3631,4488,4489},l=40,n="Summon Felsteed",nx=4490,r=77,rl=40,sn={5172}}
T[4488]={c=256,d="Speak to Strahad Farsan in Ratchet.",en={6251},ex={3631,4487,4489},l=40,n="Summon Felsteed",nx=4490,r=77,rl=40,sn={461}}
T[4489]={c=256,d="Speak to Strahad Farsan in Ratchet.",en={6251},ex={3631,4487,4488},l=40,n="Summon Felsteed",nx=4490,r=178,rl=40,sn={4563}}
T[4490]={c=256,d="Speak to Strahad Farsan in Ratchet to learn the ability to summon a Felsteed.",en={6251},l=40,n="Summon Felsteed",ps={3631,4487,4488,4489},r=0,rl=40,sn={6251},x=315}
T[4491]={d="Lead Ringo to Spraggle Frock at Marshal's Refuge.",en={9997},l=55,n="A Little Help From My Friends",ob={e={"Escort Ringo to Spraggle Frock at Marshal's Refuge",{{1449,43.7,8.3}}}},ps={4492},r=0,rl=50,sf=2,sn={9999},su=11804,x=5650}
T[4492]={d="Find Ringo at Fire Plume Ridge.",en={9999},l=55,n="Lost!",nx=4491,ob={e={"Escort Ringo to Spraggle Frock at Marshal's Refuge",{{1449,43.7,8.3}}}},r=0,rl=50,sn={9997},su=15722,x=2800}
T[4493]={d="Speak to Alchemist Pestlezugg in Gadgetzan.",en={5594},l=53,n="March of the Silithid",nx=4496,ps={162},r=77,rl=50,sn={7740},x=530}
T[4494]={d="Speak to Alchemist Pestlezugg in Gadgetzan.",en={5594},l=53,n="March of the Silithid",nx=4496,ps={32,7732},r=178,rl=50,sn={7010},x=530}
T[4495]={d="Find Iverron by the cave to the north.",en={8584},l=4,n="A Good Friend",nx=3519,r=77,rl=2,sn={8583},x=270}
T[4496]={d="Bring a Gorishi Scent Gland and 5 Un'Goro Soil samples to Alchemist Pestlezugg in Gadgetzan.",en={5594},l=53,n="Bungle in the Jungle",nx=4507,ob={i={{11837},{11018}}},ps={4493,4494},r=0,rl=50,sn={5594},x=5250}
T[4501]={d="Kill 10 Pterrordax and 15 Frenzied Pterrordax, then speak to Spraggle Frock at Marshal's Refuge.",en={9997},l=55,n="Beware of Pterrordax",ob={k={{9166},{9167}}},r=0,rl=49,so={174682},x=5650}
T[4502]={d="Collect 9 samples of Un'Goro Ash from the fire elementals around the volcano in Un'Goro Crater, and return them to Liv Rizzlefix in Ratchet.",en={8496},l=55,n="Volcanic Activity",ob={i={{11829}}},r=0,rl=49,sn={8496},x=5650}
T[4503]={d="Collect 8 Webbed Diemetradon Scales and 8 Webbed Pterrordax Scales for Shizzle in Marshal's Refuge.",en={9998},l=51,n="Shizzle's Flyer",ob={i={{11830},{11831}}},r=0,rl=49,sn={9998},x=4900}
T[4504]={d="Collect 12 samples of Super Sticky Tar for Tran'rek in Gadgetzan.",en={7876},l=54,n="Super Sticky",ob={i={{11834}}},r=0,rl=48,sn={7876},x=5450}
T[4505]={d="Collect a sample of corrupted water from the Jadefire Satyrs' moonwell and bring it to Winna Hazzard at Bloodvenom Post.",en={9996},l=54,n="Well of Corruption",nx=4506,ob={i={{12567}}},r=178,rl=49,sn={9996},su=12566,x=5450}
T[4506]={d="Take Winna's kitten to the corrupted moonwell, release it, then bring it back to Winna.",en={9996},l=54,n="Corrupted Sabers",ob={e={"Return the corrupted cat to Winna Hazzard",{{1448,34.3,52.3}}}},ps={4505},r=178,rl=49,sf=2,sn={9996},su=12565,x=5450}
T[4507]={d="Defeat the Gorishi Hive Queen once she is summoned.",en={5594},l=54,n="Pawn Captures Queen",ob={i={{11835}}},ps={4496},r=0,rl=50,sn={5594},su=11833,x=5450}
T[4508]={d="Bring Pestlezugg's Un'Goro Report to Gracina Spiritmight in Darnassus.",en={7740},l=54,n="Calm Before the Storm",nx=4510,ps={4507},r=77,rl=50,sn={5594},su=11844,x=540}
T[4509]={d="Bring Pestlezugg's Un'Goro Report to Zilzibin Drumlore in Orgrimmar.",en={7010},l=54,n="Calm Before the Storm",nx=4511,ps={4507},r=178,rl=50,sn={5594},su=11844,x=540}
T[4510]={d="Bring the Bank Voucher to Idriana in the bank of Darnassus.",en={4155},l=54,n="Calm Before the Storm",ps={4508},r=77,rl=50,sn={7740},su=11843,x=8150}
T[4511]={d="Bring the Bank Voucher to Karus in the bank of Orgrimmar.",en={3309},l=54,n="Calm Before the Storm",ps={4509},r=178,rl=50,sn={7010},su=11843,x=8150}
T[4512]={d="Bring 6 Filled Cursed Ooze Jars and 6 Filled Tainted Ooze Jars to Laris Geardawdle in Ironforge.",en={9616},l=52,n="A Little Slime Goes a Long Way",nx=4513,ob={i={{11947},{11949}}},r=77,rl=48,rs={11914,11948},sn={9616},su=11912,x=6350}
T[4513]={d="Bring 10 Filled Pure Sample Jars to Laris Geardawdle in Ironforge.",en={9616},l=54,n="A Little Slime Goes a Long Way",ob={i={{11954}}},ps={4512},r=77,rl=48,rs={11953},sn={9616},su=11955,x=6800}
T[4521]={d="Trull Failbane in Felwood wants you to kill 15 Raging Owlbeasts and 15 Ragged Owlbeasts.",en={10306},l=56,n="Wild Guardians",nx=4741,ob={k={{7451},{7450}}},r=178,rl=52,sn={10306},x=5800}
T[4542]={d="Bring the Urgent Message to Cliffwatcher Longhorn at Freewind Post.",en={10537},l=25,n="Message to Freewind Post",nx=4841,r=178,rl=23,sn={10079},su=11886,x=510}
T[4561]={eo={175265},l=52,n="Testing for Impurities - Un'Goro Crater",ob={i={{12235}}},pa=4294,r=178,rl=48,sf=1,so={175265}}
T[4581]={d="Take Shindrell's Note to Kayneth Stillwind in Forest Song.",en={3848},l=29,n="Kayneth Stillwind",r=77,rl=24,sn={3845},su=12060,x=590}
T[4621]={d="Slay Fleet Master Seahorn and Baron Revilgaz of Booty Bay, and then return to Fleet Master Firallon aboard the Crimson Veil off the coast of Stranglethorn Vale.",en={2546},l=60,n="Avast Ye, Admiral!",ob={k={{2496},{2487}}},r=0,rl=55,rp={87,3000},sn={2546},x=9950}
T[4641]={d="Speak with Gornek. You recall Kaltunk marking your map with his location and mentioning that Gornek resided in the Den, a building to the west.",en={3143},l=1,n="Your Place In The World",nx=788,r=178,rl=1,sn={10176},x=40}
T[4642]={d="Bring a Merged Ooze Sample to Chemist Fuely in Undercity.",en={10136},l=55,n="Melding of Influences",ob={i={{12291}}},pg={4293,4294},r=178,rl=48,sn={10136},su=12288,x=7050}
T[4661]={eo={174848},l=52,n="Testing for Corruption - Felwood",ob={i={{12230}}},pa=4293,r=178,rl=48,sf=1,so={174848}}
T[4681]={d="Recover the Sea Turtle Remains from the Skeletal Sea Turtle in the waters west of Auberdine, and then speak with Gwennyth Bly'Leggonde back in Auberdine.",en={10219},l=14,n="Washed Ashore",ob={i={{12289}}},ps={3524},r=77,rl=11,sn={10219},x=980}
T[4701]={d="Travel to Blackrock Spire and destroy the source of the worg menace. As you left Helendis, he shouted a name: Halycon. It is what the orcs refer to in regards to the worg.",en={9562},l=59,n="Put Her Down",ob={k={{10220}}},r=77,rl=55,sn={9562},tg=81,x=6400,z=1583}
T[4721]={d="Trull Failbane in Felwood wants you to hunt 10 Berserk Owlbeasts in Winterspring.",en={10306},l=59,n="Wild Guardians",ob={k={{7454}}},ps={4741},r=178,rl=52,sn={10306},x=6400}
T[4722]={d="Take the Sea Turtle Remains to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=13,n="Beached Sea Turtle",ps={4681},r=77,rl=11,so={176190},su=12289,x=455}
T[4723]={d="Take the Sea Creature Bones to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=13,n="Beached Sea Creature",ps={4681},r=77,rl=11,so={175233},su=12242,x=455}
T[4724]={d="Slay Halycon, pack mistress of the Bloodaxe worg.",en={9081},l=59,n="The Pack Mistress",ob={k={{10220}}},r=178,rl=55,sn={9081},tg=81,x=6400,z=1583}
T[4725]={d="Take the Strangely Marked Box to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=15,n="Beached Sea Turtle",ps={4681},r=77,rl=12,so={176197},su=12292,x=540}
T[4726]={d="Bring 8 Broodling Essence and the Draco-Incarcinatrix 900 to Tinkee Steamboil at the Flame Crest in the Burning Steppes.",en={10267},l=52,n="Broodling Essence",nx=4808,ob={i={{12283}}},r=0,rl=50,sn={10267},su=12284,x=5100}
T[4727]={d="Take the Sea Turtle Remains to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=15,n="Beached Sea Turtle",ps={4681},r=77,rl=12,so={176196},su=12289,x=540}
T[4728]={d="Take the Sea Creature Bones to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=14,n="Beached Sea Creature",ps={4681},r=77,rl=12,so={175226},su=12242,x=490}
T[4729]={d="Travel to Blackrock Spire and find Bloodaxe Worg Pups. Use the cage to carry the ferocious little beasts. Bring back a Caged Worg Pup to Kibler.",en={10260},l=59,n="Kibler's Exotic Pets",ob={i={{12263}}},r=0,rl=55,sn={10260},su=12262,tg=81,x=6400,z=1583}
T[4730]={d="Take the Sea Creature Bones to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=16,n="Beached Sea Creature",ps={4681},r=77,rl=12,so={175227},su=12242,x=580}
T[4731]={d="Take the Strangely Marked Box to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=19,n="Beached Sea Turtle",ps={4681},r=77,rl=13,so={176198},su=12292,x=730}
T[4732]={d="Take the Sea Turtle Remains to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=19,n="Beached Sea Turtle",ps={4681},r=77,rl=13,so={176191},su=12289,x=730}
T[4733]={d="Take the Sea Creature Bones to Gwennyth Bly'Leggonde in Auberdine.",en={10219},l=19,n="Beached Sea Creature",ps={4681},r=77,rl=13,so={175230},su=12242,x=730}
T[4734]={d="Use the Eggscilloscope Prototype on an egg in the Rookery.",en={10267},l=60,n="Egg Freezing",nx=4735,ob={o={{175124}}},ps={4810},r=0,rl=57,sf=2,sn={10267},su=12286,tg=62,x=8300,z=1583}
T[4735]={d="Bring 8 Collected Dragon Eggs and the Collectronic Module to Tinkee Steamboil at Flame Crest in the Burning Steppes.",en={10267},l=60,n="Egg Collection",nx=5522,ob={o={{175124}}},ps={4734},r=0,rl=57,sn={10267},su=12287,tg=62,x=9950,z=1583}
T[4736]={c=256,d="Speak to Menara Voidrender in the Barrens.",en={6266},ex={4737,4738,4739},l=31,n="In Search of Menara Voidrender",nx=1796,r=77,rl=31,sn={5172},x=630}
T[4737]={c=256,d="Speak to Menara Voidrender in the Barrens.",en={6266},ex={4736,4738,4739},l=31,n="In Search of Menara Voidrender",nx=1796,r=178,rl=31,sn={3326},x=630}
T[4738]={c=256,d="Speak with Menara Voidrender in the Barrens.",en={6266},ex={4736,4737,4739},l=31,n="In Search of Menara Voidrender",nx=1796,r=77,rl=31,sn={461},x=630}
T[4739]={c=256,d="Speak to Menara Voidrender in the Barrens.",en={6266},ex={4736,4737,4738},l=31,n="In Search of Menara Voidrender",nx=1796,r=178,rl=31,sn={4563},x=630}
T[4740]={d="Find and slay the murloc known as Murkdeep. The creature is thought to be defending the murloc huts south of Auberdine along the water.",en={2930},l=18,n="WANTED: Murkdeep!",ob={k={{10323}}},r=77,rl=15,so={175320},x=1700}
T[4741]={d="Trull Failbane in Felwood wants you to hunt 13 Moontouched Owlbeasts.",en={10306},l=58,n="Wild Guardians",nx=4721,ob={k={{7453}}},ps={4521},r=178,rl=52,sn={10306},x=6200}
T[4742]={d="Find the three gemstones of command: The Gemstone of Smolderthorn, Gemstone of Spirestone, and Gemstone of Bloodaxe. Return them, along with the Unadorned Seal of Ascension, to Vaelan.",en={10299},l=60,n="Seal of Ascension",nx=4743,ob={i={{12336},{12335},{12337},{12219}}},r=0,rl=57,sn={10299},tg=81,x=8300,z=1583}
T[4743]={d="Travel to the Wyrmbog in Dustwallow Marsh. Find the ancient drake, Emberstrife and beat him without mercy until his will is broken.",en={10299},l=60,n="Seal of Ascension",ob={i={{12324}}},ps={4742},r=0,rl=57,rs={12300,12323},sn={10299},su=12339,tg=81,x=9950,z=1583}
T[4761]={d="Speak with Thundris Windweaver in Auberdine.",en={3649},l=15,n="Thundris Windweaver",nx=4762,ps={984},r=77,rl=11,sn={3693},x=105}
T[4762]={d="Travel north of Auberdine to the first waterfall along the Cliffspring River and draw a sample from the pool there.",en={3649},l=15,n="The Cliffspring River",nx=4763,ob={i={{12349}}},ps={4761},r=77,rl=11,sn={3649},su=12350,x=800}
T[4763]={d="Fill the Empty Cleansing Bowl at the Auberdine Moonwell.",en={3649},l=18,n="The Blackwood Corrupted",ob={i={{12355}}},ps={4762},r=77,rl=15,rs={12341,12342,12343,12347},sn={3649},su=12346,x=1700}
T[4764]={d="Bring Doomrigger's Clasp to Mayara Brightwing in the Burning Steppes.",en={9565},l=60,n="Doomrigger's Clasp",nx=4765,ob={i={{12352}}},r=77,rl=57,sn={9565},tg=62,x=1650,z=1583}
T[4765]={d="Bring Ridgewell's Crate to Remington Ridgewell in Stormwind.",en={2285},l=60,n="Delivery to Ridgewell",ps={4764},r=77,rl=57,sn={9565},su=12437,x=6600,z=1583}
T[4766]={d="Speak with Mayara Brightwing in the Burning Steppes.",en={9565},l=60,n="Mayara Brightwing",nx=4764,r=77,rl=57,sn={2285},tg=62,x=660,z=1583}
T[4767]={d="Bring 10 Highperch Wyvern Eggs to Elu in Freewind Post.",en={10377},l=29,n="Wind Rider",ob={i={{12356}}},r=178,rl=25,sn={10377},x=1750}
T[4768]={d="Bring the Darkstone Tablet to Shadow Mage Vivian Lagrave in Kargath.",en={9078},l=60,n="The Darkstone Tablet",ob={i={{12358}}},r=178,rl=57,sn={9078},tg=62,x=8300,z=1583}
T[4769]={d="Speak with Shadowmage Vivian Lagrave.",en={9078},l=60,n="Vivian Lagrave and the Darkstone Tablet",nx=4768,r=178,rl=57,sn={5204},tg=62,x=660,z=1583}
T[4770]={d="Escort Pao'ka Swiftmountain from Highperch, and then talk to Motega Firemane in Whitereach Post.",en={10428},es=1,l=29,n="Homeward Bound",ob={e={"Escort Pao'ka from Highperch",{{1441,15.2,32.7}}}},r=178,rl=25,sf=2,sn={10427},x=2350}
T[4771]={d="Place Dawn's Gambit in the Viewing Room of the Scholomance. Defeat Vectus, then return to Betina Bigglezink.",en={11035},l=60,n="Dawn's Gambit",ob={k={{10432}}},ps={5531},r=0,rl=57,sf=2,sn={11035},su=12368,tg=81,x=9950,z=2057}
T[4781]={c=256,d="Bring a Gold Bar to Xizk Goodstitch in Stranglethorn Vale.",en={2670},l=34,n="Components for the Enchanted Gold Bloodrobe",nx=4782,ob={i={{3577}}},ps={1796},r=0,rl=31,sn={6266},x=2000}
T[4782]={c=256,d="Return to Menara Voidrender in the Barrens.",en={6266},l=34,n="Components for the Enchanted Gold Bloodrobe",nx=4783,ps={4781},r=0,rl=31,sn={2670},x=1350}
T[4783]={c=256,d="Bring 10 Vials of Hatefury Blood and 1 Lesser Infernal Stone to Menara Voidrender in the Barrens.",en={6266},l=37,n="Components for the Enchanted Gold Bloodrobe",nx=4784,ob={i={{6989},{6990}}},ps={4782},r=0,rl=31,sn={6266},x=2850}
T[4784]={c=256,d="Bring some Fine Gold Thread, 2 Smoldering Coals, and a Soul Shard to Menara Voidrender in the Barrens.",en={6266},l=37,n="Components for the Enchanted Gold Bloodrobe",nx=4786,ob={i={{12293},{6991},{6265}}},ps={4783},r=0,rl=31,sn={6266},x=2100}
T[4785]={c=256,en={2670},l=37,n="Fine Gold Thread",ps={4783},r=0,rl=31,sf=1,sn={2670}}
T[4786]={c=256,d="Wait for Menara Voidrender to complete your robe and then speak to her again.",en={6266},l=38,n="The Completed Robe",ob={k={{6266}}},ps={4784},r=0,rl=31,sn={6266},x=3550}
T[4787]={d="Bring the Ancient Egg to Yeh'kinya in Tanaris.",en={8579},l=50,n="The Ancient Egg",nx=3528,ob={i={{12402}}},ps={3527},r=0,rl=40,sn={8579},tg=1,x=5900}
T[4788]={d="Bring the Fifth and Sixth Mosh'aru Tablets to Prospector Ironboot in Tanaris.",en={10460},l=58,n="The Final Tablets",nx=8181,ob={i={{12740},{12741}}},ps={5065},r=0,rl=40,sn={10460},tg=81,x=7750,z=1583}
T[4801]={en={10307},l=60,n="Frostsaber E'ko",ob={i={{12430}}},ps={975},r=0,rl=55,sf=1,sn={10307}}
T[4802]={en={10307},l=60,n="Winterfall E'ko",ob={i={{12431}}},ps={975},r=0,rl=55,sf=1,sn={10307}}
T[4803]={en={10307},l=60,n="Shardtooth E'ko",ob={i={{12432}}},ps={975},r=0,rl=55,sf=1,sn={10307}}
T[4804]={en={10307},l=60,n="Chillwind E'ko",ob={i={{12434}}},ps={975},r=0,rl=55,sf=1,sn={10307}}
T[4805]={en={10307},l=60,n="Ice Thistle E'ko",ob={i={{12435}}},ps={975},r=0,rl=55,sf=1,sn={10307}}
T[4806]={en={10307},l=60,n="Frostmaul E'ko",ob={i={{12436}}},ps={975},r=0,rl=55,sf=1,sn={10307}}
T[4807]={en={10307},l=60,n="Wildkin E'ko",ob={i={{12433}}},ps={975},r=0,rl=55,sf=1,sn={10307}}
T[4808]={d="Give Tinkee's Letter to Felnok Steelspring.",en={10468},l=54,n="Felnok Steelspring",nx=4809,ps={4726},r=0,rl=50,sn={10267},su=12438,x=2700}
T[4809]={d="Bring 8 Uncracked Chillwind Horns to Felnok Steelspring.",en={10468},l=54,n="Chillwind Horns",nx=4810,ob={i={{12444}}},ps={4808},r=0,rl=50,sn={10468},x=5450}
T[4810]={d="Bring Felnok's Package to Tinkee Steamboil in the Burning Steppes.",en={10267},l=54,n="Return to Tinkee",nx=4907,ps={4809},r=0,rl=50,sn={10468},su=12445,x=2700}
T[4811]={d="Travel east of Auberdine and look for a large, red crystal along Darkshore's eastern mountain range. Report back what you find to Sentinel Glynda Nal'Shea in Auberdine.",en={2930},l=14,n="The Red Crystal",nx=4812,ob={e={"Locate the large, red crystal on Darkshore's eastern mountain range",{{1439,47.2,48.7}}},o={{175524}}},r=77,rl=12,sf=2,sn={2930},x=490}
T[4812]={d="Fill the Empty Water Tube at the Auberdine moonwell, and then investigate the red crystal along Darkshore's eastern mountain wall.",eo={175524},l=14,n="As Water Cascades",nx=4813,ob={i={{14339}}},ps={4811},r=77,rl=12,sn={2930},su=14338,x=490}
T[4813]={d="Report back what you have found to Sentinel Glynda Nal'Shea in Auberdine.",en={2930},l=14,n="The Fragments Within",ps={4812},r=77,rl=12,so={175524},x=980}
T[4821]={d="Return the Alien Egg to Hagar Lightninghoof in Freewind Post.",en={10539},l=26,n="Alien Egg",nx=4865,ob={i={{12467}}},r=178,rl=24,sn={10539},x=2100}
T[4841]={d="Kill 12 Galak Scouts, 10 Galak Wranglers, and 6 Galak Windchasers, and then return to Cliffwatcher Longhorn in Freewind Post.",en={10537},l=25,n="Pacify the Centaur",nx=5064,ob={k={{4094},{4093},{4096}}},r=178,rl=23,sn={10537},x=2000}
T[4842]={d="Follow Donova Snowden's instructions, then report back.",en={9298},l=56,n="Strange Sources",ob={e={"Discover Darkwhisper Gorge",{{1452,59.8,74.3}}}},ps={980},r=0,rl=51,sf=2,sn={9298},x=5800}
T[4861]={d="Locate Jaron Stoneshaper's wrecked camp and supplies in southern Winterspring.",eo={175587},l=59,n="Enraged Wildkin",nx=4863,r=77,rl=53,sn={10301},x=3200}
T[4862]={d="Travel to Blackrock Spire and collect 15 Spire Spider Eggs for Kibler.",en={10260},l=59,n="En-Ay-Es-Tee-Why",ob={i={{12530}}},r=0,rl=55,sn={10260},tg=81,x=6400,z=1583}
T[4863]={d="Find Jaron Stoneshaper's wrecked wagon.",eo={175586},l=59,n="Enraged Wildkin",nx=4864,ps={4861},r=77,rl=53,so={175587},x=3200}
T[4864]={d="Pick up Jaron's Supplies from the snow, then find the wildkin that stole the amulet Jaron spoke of.",en={10301},l=59,n="Enraged Wildkin",ob={i={{12525},{12524}}},ps={4863},r=77,rl=53,so={175586},x=6400}
T[4865]={d="Report your findings to Motega Firemane.",en={10428},l=26,n="Serpent Wild",nx=5062,ps={4821},r=178,rl=24,sn={10539},x=1050}
T[4866]={d="In the heart of Blackrock Spire you will find Mother Smolderweb. Engage her and get her to poison you. Chances are good that you will have to kill her as well. Return to Ragged John when you are poisoned so that he can 'milk' you.",en={9563},l=60,n="Mother's Milk",ob={k={{9563}}},r=0,rl=55,sf=2,sn={9563},tg=81,x=9950,z=1583}
T[4867]={d="Read Warosh's Scroll. Bring Warosh's Mojo to Warosh.",en={10799},l=60,n="Urok Doomhowl",ob={i={{12712}}},r=0,rl=55,rs={12533,12534},sn={10799},su=12730,tg=81,x=9950,z=1583}
T[4881]={d="Warn Kanati Greycloud at Whitereach Post of the plot to kill him.",en={10638},l=28,n="Assassination Plot",nx=4966,r=178,rl=23,si={12564},x=2300}
T[4882]={d="Take the Blue-feathered Necklace to Trull Failbane at Bloodvenom Post.",en={10306},l=59,n="Guarding Secrets",nx=4883,ps={4741},r=178,rl=52,si={12558},su=12558,x=3200}
T[4883]={d="Take the Blue-feathered Necklace to Nara Wildmane.",en={5770},l=59,n="Guarding Secrets",ps={4882},r=178,rl=52,sn={10306},su=12558,x=6400}
T[4901]={d="Protect Ranshalla while she attempts to reactivate the Altar of Elune. Report your findings to Erelas Ambersky in Rut'theran Village.",en={7916},l=59,n="Guardians of the Altar",nx=4902,ob={e={"Discover the secret of the Altar of Elune",{{1452,64.9,63.7}}}},ps={979},r=77,rl=52,sf=2,sn={10300},x=4800}
T[4902]={d="Speak with Arch Druid Fandral Staghelm in Darnassus.",en={3516},l=57,n="Wildkin of Elune",ps={4901},r=77,rl=52,sn={7916},x=6000}
T[4903]={d="Slay Highlord Omokk, War Master Voone, and Overlord Wyrmthalak. Recover Important Blackrock Documents. Return to Warlord Goretooth in Kargath when the mission has been accomplished.",en={9077},l=60,n="Warlord's Command",nx=4941,ob={i={{12562}},k={{9568},{9196},{9237}}},r=178,rl=55,si={12563},sn={9077},tg=81,x=8300,z=1583}
T[4904]={d="Escort Lakota Windsong from the Darkcloud Pinnacle, and then talk to Thalia Amberhide at Freewind Post.",en={10645},es=1,l=29,n="Free at Last",ob={e={"Escort Lakota Windsong from the Darkcloud Pinnacle.",{{1441,30.9,37.1}}}},r=178,rl=25,sf=2,sn={10646},x=2350}
T[4906]={d="Eridan Bluewind in Felwood wants you to kill 8 Jadefire Hellcallers, 8 Jadefire Betrayers, 8 Jadefire Tricksters, and Xavaric. Return to Eridan when the task is completed.",en={9116},l=54,n="Further Corruption",ob={k={{7111},{7108},{7107},{10648}}},ps={4421},r=77,rl=49,sn={9116},x=5450}
T[4907]={d="Speak with Tinkee Steamboil.",en={10267},l=60,n="Tinkee Steamboil",nx=4734,ps={4810},r=0,rl=57,sn={10468},tg=62,x=660,z=1583}
T[4921]={d="Find Mankrik's wife and then return to him in the Crossroads.",en={3432},l=20,n="Lost in Battle",ob={k={{10668}}},r=178,rl=14,sn={3432},x=1150}
T[4941]={d="Speak with Eitrigg in Orgrimmar. When you have discussed matters with Eitrigg, seek council from Thrall.",en={4949},l=60,n="Eitrigg's Wisdom",nx=4974,ob={e={"Council with Eitrigg.",{{1454,34.1,39.3}}}},ps={4903},r=178,rl=55,sf=2,sn={9077},x=6600}
T[4961]={c=256,d="Kill the Demon of the Orb, then speak with Tabetha.",en={6546},l=40,n="Cleansing of the Orb of Orahil",nx=4976,ob={k={{6549}}},pg={1799,4962},r=0,rl=35,sn={6546},tg=1,x=2350}
T[4962]={c=256,d="Take the Felhas Ruby and use it on one of the Felhounds found in Desolace. After successful, bring the Felhas Ruby and the Imprisoned Felhound Spirit back to Menara Voidrender in the Barrens.",en={6266},ex={4963},l=40,n="Shard of a Felhound",ob={i={{12648}}},pa=0,r=0,rl=35,sn={6254},su=12647,x=2350}
T[4963]={c=256,d="Take the Infus Emerald and use it on one of the Infernals found in Desolace. After successful, bring the Infus Emerald and the Imprisoned Infernal Spirit back to Menara Voidrender in the Barrens.",en={6266},ex={4962},l=40,n="Shard of an Infernal",ob={i={{12649}}},pa=0,r=0,rl=35,sn={6252},su=12646,x=2350}
T[4964]={c=256,d="Wait for Menara Voidrender to complete the Orb of Dar'Orahil and then speak to her again.",en={6266},ex={4963},l=40,n="The Completed Orb of Dar'Orahil",ob={k={{6266}}},pg={4976,-4962},r=0,rl=35,sn={6266},x=3900}
T[4965]={c=256,d="Speak to Menara Voidrender in the Barrens.",en={6266},ex={4967,4968,4969},l=35,n="Knowledge of the Orb of Orahil",nx=1799,r=77,rl=35,sn={5172},x=1350}
T[4966]={d="Protect Kanati Greycloud from the centaur attack.",en={10638},l=28,n="Protect Kanati Greycloud",ob={k={{10720}}},ps={4881},r=178,rl=23,sf=2,sn={10638},x=2300}
T[4967]={c=256,d="Speak to Menara Voidrender in the Barrens.",en={6266},ex={4965,4968,4969},l=35,n="Knowledge of the Orb of Orahil",nx=1799,r=178,rl=35,sn={3326},x=1350}
T[4968]={c=256,d="Speak to Menara Voidrender in the Barrens.",en={6266},ex={4965,4967,4969},l=35,n="Knowledge of the Orb of Orahil",nx=1799,r=77,rl=35,sn={461},x=1350}
T[4969]={c=256,d="Speak to Menara Voidrender in the Barrens.",en={6266},ex={4965,4967,4968},l=35,n="Knowledge of the Orb of Orahil",nx=1799,r=178,rl=35,sn={4563},x=1350}
T[4970]={d="Collect 5 Shardtooth Meats and 5 Chillwind Meats for Rivern Frostwind in Winterspring.",en={10618},l=60,n="Frostsaber Provisions",ob={i={{12622},{12623}}},r=77,rl=58,sf=1,sn={10618}}
T[4971]={d="Use the Temporal Displacer near one of Andorhal's silos and uncover Temporal Parasites.",en={10667},l=56,n="A Matter of Time",nx=4972,ob={k={{10717}}},r=0,rl=53,sn={10667},su=12627,x=5800}
T[4972]={d="Locate 5 Andorhal Watches, found in lockboxes amongst the rubble of the city. Return with them to Chromie in the Andorhal Inn, Western Plaguelands.",en={10667},l=56,n="Counting Out Time",nx=4973,ob={i={{12638}}},ps={4971},r=0,rl=53,sn={10667},x=5800}
T[4973]={d="Locate 5 Andorhal Watches amongst the rubble of the city, and return with them to Chromie in the Andorhal Inn, Western Plaguelands.",en={10667},l=56,n="Counting Out Time",ob={i={{12638}}},ps={4972},r=0,rl=53,sf=1,sn={10667},x=580}
T[4974]={d="Travel to Blackrock Spire and slay Warchief Rend Blackhand. Take his head and return to Orgrimmar.",en={4949},l=60,n="For The Horde!",nx=6566,ob={i={{12630}}},ps={4941},r=178,rl=55,sn={4949},tg=62,x=9950,z=1583}
T[4975]={c=256,d="Wait for Menara Voidrender to complete the Orb of Noh'Orahil and then speak to her again.",en={6266},ex={4962},l=40,n="The Completed Orb of Noh'Orahil",ob={k={{6266}}},pg={4976,-4963},r=0,rl=35,sn={6266},x=3900}
T[4976]={c=256,d="Return the Cleansed Infernal Orb to Menara Voidrender in the Barrens.",en={6266},l=40,n="Returning the Cleansed Orb",ps={4961},r=0,rl=35,sn={6546},su=12642,x=1550}
T[4981]={d="Travel to Blackrock Spire and find out what happened to Bijou.",en={10257},l=59,n="Operative Bijou",nx=4982,r=178,rl=55,sn={9080},tg=81,x=6400,z=1583}
T[4982]={d="Find Bijou's Belongings and return them to her. You recall her mentioning that she stashed them on the bottom floor of the city.",en={10257},l=59,n="Bijou's Belongings",nx=4983,ob={i={{12345}}},ps={4981},r=178,rl=55,sn={10257},tg=81,x=6400,z=1583}
T[4983]={d="Take Bijou's Reconnaissance Report back to Grandmaster Lexlort in Kargath.",en={9080},l=59,n="Bijou's Reconnaissance Report",ps={4982},r=178,rl=55,sn={10257},su=12652,tg=81,x=6400,z=1583}
T[4984]={d="Destroy 8 Diseased Wolves, and then return to Mulgris Deepriver at the Writhing Haunt, Western Plaguelands.",en={10739},l=54,n="The Wildlife Suffers Too",nx=4985,ob={k={{1817}}},r=0,rl=51,sn={10739},x=4100}
T[4985]={d="Destroy 8 Diseased Grizzlies, and then return to Mulgris Deepriver at the Writhing Haunt, Western Plaguelands.",en={10739},l=56,n="The Wildlife Suffers Too",ob={k={{1816}}},ps={4984},r=0,rl=51,sn={10739},x=4350}
T[4986]={d="Based on the magic enchanted within the Glyphed Oaken Branch, its delivery to the Cenarion Circle in Darnassus is the next step the tauren druid sought. Seek one of the druids there for assistance.",en={4217},l=56,n="Glyphed Oaken Branch",ps={4985},r=77,rl=51,sn={10739},su=12663,x=5800}
T[4987]={d="Based on the magic enchanted within the Glyphed Oaken Branch, its delivery to the Cenarion Circle in Thunder Bluff is the next step the tauren druid sought. Seek one of the druids there for assistance.",en={5770},l=56,n="Glyphed Oaken Branch",ps={4985},r=178,rl=51,sn={10739},su=12663,x=5800}
T[5001]={d="Find Bijou's Belongings and return them to her. Good luck!",en={10257},l=59,n="Bijou's Belongings",nx=5002,ob={i={{12345}}},r=77,rl=55,sn={10257},tg=81,x=6400,z=1583}
T[5002]={d="Travel to the Burning Steppes and give Bijou's Information to Marshal Maxwell.",en={9560},l=59,n="Message to Maxwell",nx=5081,ps={5001},r=77,rl=55,sn={10257},su=12770,tg=81,x=6400,z=1583}
T[5021]={d="The ramblings of the ghostly woman indicated that she needed a package delivered. She claimed that it was where her horse was. As to where the horse is or where the package was to be delivered - the ghost remains incomprehensible.",eo={175894},l=52,n="Better Late Than Never",r=0,rl=50,sn={10778},x=2550}
T[5022]={d="Check with the Royal Factors of Stormwind to learn the whereabouts of an Emma Felstone. There is usually a census officer located in City Hall.",en={10782},l=52,n="Better Late Than Never",nx=5048,ps={5021},r=77,rl=50,so={175894},su=12724,x=2550}
T[5023]={d="Check with the Royal Overseers of the Undercity to learn the whereabouts of a Jeremiah Felstone. There is usually a census officer located near guild and tabard registration.",en={10781},l=52,n="Better Late Than Never",nx=5049,ps={5021},r=178,rl=50,so={175894},su=12724,x=2550}
T[5041]={d="Find and return Crossroads' Supply Crates to Thork in the Barrens.",en={3429},l=14,n="Supplies for the Crossroads",ob={i={{12708}}},r=178,rl=9,sn={3429},x=980}
T[5042]={en={3430},l=20,n="Agamaggan's Strength",ob={i={{5075}}},ps={5052},r=178,rl=14,sf=1,sn={3430}}
T[5043]={en={3430},l=20,n="Agamaggan's Agility",ob={i={{5075}}},ps={5052},r=178,rl=14,sf=1,sn={3430}}
T[5044]={en={3430},l=20,n="Wisdom of Agamaggan",ob={i={{5075}}},ps={5052},r=178,rl=14,sf=1,sn={3430}}
T[5045]={en={3430},l=20,n="Rising Spirit",ob={i={{5075}}},ps={5052},r=178,rl=14,sf=1,sn={3430}}
T[5046]={en={3430},l=20,n="Razorhide",ob={i={{5075}}},ps={5052},r=178,rl=14,sf=1,sn={3430}}
T[5047]={d="Talk to Malyfous Darkhammer in Everlook.",en={10637},l=60,n="Pip Quickwit, At Your Service!",r=0,rl=55,sn={10776},su=12710,tg=81,x=6600,z=1583}
T[5048]={d="Find Ol' Emma in Stormwind and see if she is in fact Emma Felstone. If she is, then perhaps she'd like the package Janice Felstone made for her.",en={3520},l=52,n="Good Natured Emma",nx=5050,ps={5022},r=77,rl=50,sn={10782},su=12724,x=5100}
T[5049]={d="Find Jeremiah Payson in the Undercity and see if he is in fact Jeremiah Felstone. If he is, then perhaps he'd like the package Janice Felstone made for him.",en={8403},l=52,n="The Jeremiah Blues",nx=5050,ps={5023},r=178,rl=50,sn={10781},su=12724,x=5100}
T[5050]={d="Return to Janice Felstone in Western Plaguelands her Good Luck Half-Charm.",en={10778},l=52,n="Good Luck Charm",nx=5051,ps={5048,5049},r=0,rl=50,sn={3520,8403},su=12721,x=2550}
T[5051]={d="Locate the other half of the Good Luck Charm somewhere on the Felstone Farm in Western Plaguelands and reassemble it.",en={10778},l=54,n="Two Halves Become One",ob={i={{12723}}},ps={5050},r=0,rl=50,rs={12722},sn={10778},su=12721,x=5450}
T[5052]={d="Bring a Blood Shard to Mangletooth in Camp Taurajo in the Barrens.",en={3430},l=21,n="Blood Shards of Agamaggan",nx=879,ob={i={{5075}}},ps={878},r=178,rl=14,sn={3430},x=1250}
T[5054]={d="Storm Shadowhoof at Everlook in Winterspring wants you to kill Ursius.",en={10303},l=56,n="Ursius of the Shardtooth",nx=5055,ob={k={{10806}}},r=178,rl=53,sn={10303},tg=1,x=5800}
T[5055]={d="Storm Shadowhoof at Everlook in Winterspring wants you to kill Brumeran.",en={10303},l=58,n="Brumeran of the Chillwind",nx=5056,ob={k={{10807}}},ps={5054},r=178,rl=53,sn={10303},tg=1,x=6200}
T[5056]={d="Storm Shadowhoof at Everlook in Winterspring wants you to defeat Shy-Rotam.",en={10303},l=60,n="Shy-Rotam",nx=5057,ob={k={{10737}}},ps={5055},r=178,rl=53,rs={12733},sn={10303},tg=1,x=8300}
T[5057]={en={10303},l=60,n="Past Endeavors",ps={5056},r=178,rl=53,sn={10303},x=3300}
T[5058]={eo={175926},l=55,n="Mrs. Dalson's Diary",r=0,rl=52,so={175926}}
T[5059]={eo={175925},l=55,n="Locked Away",ob={i={{12738}}},r=0,rl=52,sf=1,so={175925}}
T[5060]={eo={175924},l=55,n="Locked Away",ob={i={{12739}}},r=0,rl=52,so={175924},x=7050}
T[5061]={c=1024,d="Return to Darnassus and show Mathrengyl Bearwalker the Pendant of the Sea Lion.",en={4217},l=16,n="Aquatic Form",ps={272},r=8,rl=16,sn={11802},su=15885,x=1150}
T[5062]={d="Gather 10 bushels of Incendia Agave, and then consult Magatha Grimtotem on Elder Rise in Thunderbluff.",en={4046},l=27,n="Sacred Fire",nx=5088,ob={i={{12732}}},ps={4865},r=178,rl=24,sn={10428},x=2200}
T[5063]={d="In order to create the Cap of the Scarlet Savant, you will be required to bring the following items back to Malyfous Darkhammer: 1 Pristine Hide of the Beast; 5 Frayed Abomination Stitchings; 8 Arcane Crystals; 5 Enchanted Scarlet Thread. ",en={10637},l=60,n="Cap of the Scarlet Savant",ob={i={{12731},{12735},{12363},{12734}}},ps={5047},r=0,rl=57,sf=1,so={175927},tg=1}
T[5064]={d="Locate and retrieve the three Secret Notes in Darkcloud Pinnacle.",en={10537},l=28,n="Grimtotem Spying",ob={i={{12765},{12766},{12768}}},ps={4841},r=178,rl=24,sn={10537},x=2300}
T[5065]={d="Bring the Third and Fourth Mosh'aru Tablets to Prospector Ironboot in Tanaris.",en={10460},l=58,n="The Lost Tablets of Mosh'aru",nx=4788,ob={i={{12411},{12412}}},ps={3528},r=0,rl=40,sn={10460},tg=1,x=7750}
T[5066]={d="Seek out Commander Ashlam Valorfist. His base camp is located at Chillwind Camp, north of the Alterac Mountains.",en={10838},ex={5090,5091},l=50,n="A Call to Arms: The Plaguelands!",nx=5092,r=77,rl=50,sn={2198},x=470}
T[5067]={d="In order to create the Leggings of Arcana, you will be required to bring the following items back to Malyfous Darkhammer: 1 Pristine Hide of the Beast; 5 Frayed Abomination Stitchings; 5 Arcanite Bars; 5 Frostwhisper's Embalming Fluid.",en={10637},l=60,n="Leggings of Arcana",ob={i={{12731},{12735},{12360},{12736}}},ps={5047},r=0,rl=57,sf=1,so={175927},tg=1}
T[5068]={d="In order to create the Breastplate of Bloodthirst, you will be required to bring the following items back to Malyfous Darkhammer: 1 Pristine Hide of the Beast; 10 Frayed Abomination Stitchings; 5 Arcanite Bars; 5 Skin of Shadow.",en={10637},l=60,n="Breastplate of Bloodthirst",ob={i={{12731},{12735},{12360},{12753}}},ps={5047},r=0,rl=57,sf=1,so={175927},tg=1}
T[5081]={d="Travel to Blackrock Spire and destroy War Master Voone, Highlord Omokk, and Overlord Wyrmthalak. Return to Marshal Maxwell when the job is done.",en={9560},l=60,n="Maxwell's Mission",ob={k={{9237},{9196},{9568}}},ps={5002},r=77,rl=55,sn={9560},tg=81,x=8300,z=1583}
T[5082]={d="Donova Snowden in Winterspring wants you to kill 8 Winterfall Pathfinders, 8 Winterfall Den Watchers, and 8 Winterfall Totemics.",en={9298},l=56,n="Threat of the Winterfall",ob={k={{7442},{7440},{7441}}},r=0,rl=52,sn={9298},x=5800}
T[5083]={d="Bring the Empty Firewater Flask to Donova Snowden in Winterspring.",en={9298},l=56,n="Winterfall Firewater",nx=5084,r=0,rl=52,si={12771},su=12771,x=2900}
T[5084]={d="Search the Deadwood furbolg camp in northern Felwood for a clue.",eo={176091},l=56,n="Falling to Corruption",nx=5085,ps={5083},r=0,rl=52,sn={9298},x=4350}
T[5085]={d="Report back to Donova Snowden with your findings.",en={9298},l=56,n="Mystery Goo",nx=5086,ps={5084},r=0,rl=52,so={176091},su=12813,x=4350}
T[5086]={d="Collect 3 Toxic Horror Droplets for Donova Snowden in Winterspring.",en={9298},l=56,n="Toxic Horrors",nx=5087,ob={i={{12822}}},ps={5085},r=0,rl=52,sn={9298},x=4350}
T[5087]={d="Find the Winterfall Runners and stop them from delivering their shipment to Winterfall Village.",en={9298},l=57,n="Winterfall Runners",nx=5121,ob={i={{12829}}},ps={5086},r=0,rl=52,sn={9298},x=6000}
T[5088]={d="Slay Arikara. Bring her remains and the Incendia powder to Motega Firemane in Whitereach Post as proof of your deed.",en={10428},l=28,n="Arikara",ob={i={{12925}},o={{175944}}},ps={5062},r=178,rl=24,sf=2,sn={4046},su=12785,tg=1,x=2300}
T[5089]={d="Take General Drakkisath's Command to Marshal Maxwell in Burning Steppes.",en={9560},l=60,n="General Drakkisath's Command",nx=5102,r=77,rl=55,si={12780},su=12780,tg=81,x=6600,z=1583}
T[5090]={d="Seek out Commander Ashlam Valorfist. His base camp is located at Chillwind Camp, north of the Alterac Mountains.",en={10838},ex={5066,5091},l=50,n="A Call to Arms: The Plaguelands!",nx=5092,r=77,rl=50,sn={10877},x=470}
T[5091]={d="Seek out Commander Ashlam Valorfist. His base camp is located at Chillwind Camp, north of the Alterac Mountains.",en={10838},ex={5066,5090},l=50,n="A Call to Arms: The Plaguelands!",nx=5092,r=77,rl=50,sn={10878},x=470}
T[5092]={d="Kill 10 Skeletal Flayers and 10 Slavering Ghouls in Sorrow Hill.",en={10838},l=52,n="Clear the Way",nx=5097,ob={k={{1783},{1791}}},r=77,rl=50,sn={10838},x=5100}
T[5093]={d="Seek out High Executor Derrington. His base camp is located at the Bulwark, east of Tirisfal Glade and the Undercity.",en={10837},ex={5094,5095},l=50,n="A Call to Arms: The Plaguelands!",nx=5096,r=178,rl=50,sn={10880},x=470}
T[5094]={d="Seek out High Executor Derrington. His base camp is located at the Bulwark, east of Tirisfal Glade and the Undercity.",en={10837},ex={5093,5095},l=50,n="A Call to Arms: The Plaguelands!",nx=5096,r=178,rl=50,sn={10879},x=470}
T[5095]={d="Seek out High Executor Derrington. His base camp is located at the Bulwark, east of Tirisfal Glades and the Undercity.",en={10837},ex={5093,5094},l=50,n="A Call to Arms: The Plaguelands!",nx=5096,r=178,rl=50,sn={10881},x=470}
T[5096]={d="Proceed to the Scarlet Crusade's base camp between Felstone Field and Dalson's Tears and destroy their command tent.",en={10837},l=53,n="Scarlet Diversions",nx=5098,ob={e={"Destroy the command tent and plant the Scourge banner in the camp",{{1422,40.7,52}}}},r=178,rl=50,rs={12814},sf=2,sn={10837},su=12807,x=5250}
T[5097]={d="Using the Beacon Torch, mark each tower in Andorhal; you will need to stand in the doorway of the tower to successfully mark it.",en={10838},l=56,n="All Along the Watchtowers",nx=5533,ob={k={{10902},{10903},{10904},{10905}}},ps={5092},r=77,rl=50,sn={10838},su=12815,x=5800}
T[5098]={d="Using the Beacon Torch, mark each tower in Andorhal; you will need to stand in the doorway of the tower to successfully mark it.",en={10837},l=56,n="All Along the Watchtowers",nx=838,ob={k={{10902},{10903},{10904},{10905}}},ps={5096},r=178,rl=50,sn={10837},su=12815,tg=1,x=5800}
T[5102]={d="Travel to Blackrock Spire and destroy General Drakkisath. Return to Marshal Maxwell when the job is done.",en={9560},l=60,n="General Drakkisath's Demise",ob={k={{10363}}},ps={5089},r=77,rl=55,sn={9560},tg=62,x=9950,z=1583}
T[5103]={d="Someone in this world must know what to do with these gauntlets. Good luck!",en={10637},l=60,n="Hot Fiery Death",nx=5124,r=0,rl=55,rs={12812},sk={164,270},so={176090},tg=81,x=6600}
T[5121]={d="Donova Snowden in Winterspring wants you to defeat High Chief Winterfall.",en={9298},l=59,n="High Chief Winterfall",ob={k={{10738}}},ps={5087},r=0,rl=52,sn={9298},tg=1,x=6400}
T[5122]={en={10917},l=60,n="The Medallion of Faith",nx=5125,ob={i={{12845}}},r=0,rl=55,sf=1,sn={10917},tg=81,z=2017}
T[5123]={d="Bring the Crudely-written Log to Donova Snowden in Winterspring.",en={9298},l=59,n="The Final Piece",nx=5128,ps={5087},r=0,rl=52,si={12842},su=12842,x=3200}
T[5124]={d="Bring Malyfous Darkhammer 6 Enchanted Thorium Bars, 2 Essence of Fire, and 4 Star Rubies. You will also need to turn in your Unfired Plate Gauntlets.",en={10637},l=60,n="Fiery Plate Gauntlets",ob={i={{12812},{12655},{7078},{7910}}},ps={5103},r=0,rl=55,sk={164,275},sn={10637},tg=1,x=8300}
T[5125]={en={10917},l=60,n="Aurius' Reckoning",ps={5122},r=0,rl=55,sn={10917},tg=81,x=8300,z=2017}
T[5126]={c=67,d="Speak with Lorax. Listen to what he has to say.",en={10918},l=60,n="Lorax's Tale",nx=5127,ob={k={{10918}}},r=0,rl=55,sf=2,sk={164,270},sn={10918},x=660}
T[5127]={d="Travel to Blackrock Spire and find Goraluk Anvilcrack. Slay him and then use the Blood Stained Pike upon his corpse. After his soul has been siphoned, the pike will be Soul Stained.",en={10918},l=60,n="The Demon Forge",ob={i={{12847},{12806}}},ps={5126},r=0,rl=55,sk={164,270},sn={10918},su=12848,tg=81,x=8300,z=1583}
T[5128]={d="Take the Crudely-written Log to Kelek Skykeeper in southern Felwood.",en={10920},l=59,n="Words of the High Chief",ps={5123},r=0,rl=52,sn={9298},su=12842,x=6400}
T[5141]={d="Bring 2 Tough Scorpid Breastplates, 2 Tough Scorpid Gloves, and 10 Worn Dragonscales to Peter Galen in Azshara.",en={7866},ex={5143,5144},l=55,n="Dragonscale Leatherworking",ob={i={{8203},{8204},{8165}}},r=77,rl=40,sk={165,225},sn={7866},x=4200}
T[5142]={d="Find Pamela Redpath.",en={10926},ex={5601},l=55,n="Little Pamela",nx=5149,r=0,rl=50,sn={10927},x=2800}
T[5143]={d="Bring a Wild Leather Vest and a Wild Leather Helmet to Caryssia Moonhunter in Feralas.",en={7870},ex={5141,5144},l=55,n="Tribal Leatherworking",ob={i={{8211},{8214}}},ps={2853},r=77,rl=40,sk={165,225},sn={7870},x=4200}
T[5144]={d="Bring 2 Heart of Fire, 2 Globe of Water, 2 Core of Earth, and 2 Breath of Wind to Sarah Tanner in Searing Gorge.",en={7868},ex={5141,5143},l=55,n="Elemental Leatherworking",ob={i={{7077},{7079},{7075},{7081}}},r=77,rl=40,sk={165,225},sn={7868},x=4200}
T[5145]={d="Bring 2 Tough Scorpid Breastplates, 2 Tough Scorpid Gloves, and 10 Worn Dragonscales to Thorkaf Dragoneye in the Badlands.",en={7867},ex={5146,5148},l=55,n="Dragonscale Leatherworking",ob={i={{8203},{8204},{8165}}},r=178,rl=40,sk={165,225},sn={7867},x=4200}
T[5146]={d="Bring 2 Heart of Fire, 2 Globe of Water, 2 Core of Earth, and 2 Breath of Wind to Brumn Winterhoof in the Arathi Mountains.",en={7869},ex={5145,5148},l=55,n="Elemental Leatherworking",ob={i={{7077},{7079},{7075},{7081}}},r=178,rl=40,sk={165,225},sn={7869},x=4200}
T[5147]={d="Slay Arnak Grimtotem and bring proof of your deed to Cliffwatcher Longhorn in Freewind Post.",en={10537},l=29,n="Wanted - Arnak Grimtotem",ob={i={{12884}}},r=178,rl=25,so={176115},x=2350}
T[5148]={d="Bring a Wild Leather Vest and a Wild Leather Helmet to Se'Jib in Stranglethorn Vale.",en={7871},ex={5145,5146},l=55,n="Tribal Leatherworking",ob={i={{8211},{8214}}},ps={2860},r=178,rl=40,sk={165,225},sn={7871},x=4200}
T[5149]={d="Find Pamela's doll.",en={10926},l=55,n="Pamela's Doll",ob={i={{12885}}},r=0,rl=50,rs={12886,12887,12888},sn={10926},x=2800}
T[5150]={en={9274},l=55,n="Dadanga is Hungry!",ob={i={{11315}}},r=0,rl=47,sf=1,sn={9274}}
T[5151]={d="Slay the beast and bring back the Hypercapacitor Gizmo and Panther Cage Key to Wizlo Bearingshiner.",en={10941},l=30,n="Hypercapacitor Gizmo",ob={i={{12946}}},r=178,rl=24,sn={10941},su=12942,tg=1,x=3050}
T[5152]={d="Speak with Marlene, south of the Ruins of Andorhal.",en={10927},l=56,n="Auntie Marlene",nx=5153,ps={5149},r=0,rl=50,sn={10926},x=2900}
T[5153]={d="Bring Joseph's Wedding Ring to Chromie.",en={10667},l=56,n="A Strange Historian",nx=5154,ob={i={{12894}}},ps={5152},r=0,rl=50,sn={10927},tg=1,x=4350}
T[5154]={d="Bring the Annals of Darrowshire to Chromie in Andorhal.",en={10667},l=56,n="The Annals of Darrowshire",ob={i={{12900}}},ps={5153},r=0,rl=50,sn={10667},x=5800}
T[5155]={d="Enter Jaedenar and slay 4 Jaedenar Hounds, 4 Jaedenar Guardsmen, 6 Jaedenar Adepts, and 6 Jaedenar Cultists before returning to Greta Mosshoof in Felwood.",en={10922},l=51,n="Forces of Jaedenar",nx=5157,ob={k={{7125},{7113},{7115},{7112}}},r=0,rl=48,sn={10922},x=4900}
T[5156]={d="Seek out and destroy 2 Entropic Beasts and 2 Entropic Horrors while exploring Shatter Scar Vale. After checking to see if the craters there are still filled with corrupt fel water, return to Taronn Redfeather in Felwood.",en={10921},l=54,n="Verifying the Corruption",ob={e={"Explore the craters in Shatter Scar Vale",{{1448,41,42}}},k={{9878},{9879}}},r=0,rl=48,sn={10921},tg=1,x=6800}
T[5157]={d="Take the Empty Canteen to the Moon Well in the center of Jaedenar and fill it before returning to Greta Mosshoof in Felwood.",en={10922},l=52,n="Collection of the Corrupt Water",nx=5158,ob={i={{12907}}},ps={5155},r=0,rl=48,sn={10922},su=12922,x=3800}
T[5158]={d="Take the Corrupt Moon Well Water to Islen Waterseer in the Barrens.",en={5901},l=52,n="Seeking Spiritual Aid",nx=5159,ps={5157},r=0,rl=48,sn={10922},su=12907,x=2550}
T[5159]={d="Take the Purified Moon Well Water to Greta Mosshoof in Felwood.",en={10922},l=54,n="Cleansed Water Returns to Felwood",nx=5165,ps={5158},r=0,rl=48,sn={5901},su=12906,x=2700}
T[5160]={d="Travel to Winterspring and find Haleh. Give her Awbee's scale.",en={10929},l=60,n="The Matron Protectorate",nx=5161,r=0,rl=57,sn={10740},su=12923,tg=81,x=6600,z=1583}
T[5161]={d="Speak with Haleh if you wish to continue.",en={10929},l=60,n="Wrath of the Blue Flight",nx=5162,ps={5160},r=0,rl=57,sn={10929},x=660}
T[5162]={d="Speak with Jeziba in the Plaguelands. He resides in Andorhal.",en={10976},l=60,n="Wrath of the Blue Flight",nx=5164,ps={5161},r=0,rl=57,sn={10929},tg=1,x=6600}
T[5163]={d="Take Umi's Mechanical Yeti and scare her friends with it:",en={10305},l=58,n="Are We There, Yeti?",nx=8798,ob={k={{10978},{7583},{10977}}},ps={977},r=0,rl=52,sn={10305},su=12928,x=7750}
T[5164]={d="Read from the Catalogue of the Wayward.",eo={176192},l=60,n="Catalogue of the Wayward",ps={5162},r=0,rl=57,sn={10976},tg=1,x=660}
T[5165]={d="Using the Purified Moon Well Water, douse the flames of the four braziers of protection within Shadow Hold in Felwood, then return to Greta Mosshoof in the Emerald Sanctuary.",en={10922},l=55,n="Dousing the Flames of Protection",nx=5242,ob={o={{176158,"Extinguish the Brazier of Pain"},{176159,"Extinguish the Brazier of Malice"},{176160,"Extinguish the Brazier of Suffering"},{176161,"Extinguish the Brazier of Hatred"}}},ps={5159},r=0,rl=48,sn={10922},su=12906,x=5650}
T[5166]={d="To forge the Breastplate of the Chromatic Flight, you will be required to bring the following items to Jeziba the 'Sculptor':",en={10976},l=60,n="Breastplate of the Chromatic Flight",ob={i={{12871},{12607},{12938},{12735}}},ps={5164},r=0,rl=57,so={176192},tg=1,x=9950}
T[5167]={d="To forge the Legplates of the Chromatic Defier, you will be required to bring the following items to Jeziba the 'Sculptor':",en={10976},l=60,n="Legplates of the Chromatic Defier",ob={i={{12871},{12607},{12938},{12753}}},ps={5164},r=0,rl=57,so={176192},tg=1,x=9950}
T[5168]={d="Bring Davil's Libram and Redpath's Shield to Carlin Redpath.",en={11063},l=56,n="Heroes of Darrowshire",ob={i={{12954},{12955}}},ps={5210},r=0,rl=50,sn={11063},tg=1,x=5800}
T[5181]={d="Bring the Skull of Horgus and the Shattered Sword of Marduk to Carlin Redpath at Light's Hope Chapel.",en={11063},l=57,n="Villains of Darrowshire",ob={i={{12956},{12957}}},ps={5210},r=0,rl=50,sn={11063},x=6000}
T[5201]={d="Rivern Frostwind wants you to slay 5 Winterfall Shaman and 5 Winterfall Ursa.",en={10618},l=60,n="Winterfall Intrusion",ob={k={{7439},{7438}}},r=77,rl=58,rp={589,1500},sf=1,sn={10618}}
T[5202]={d="Search through Jaedenar to discover what the Blood Red Key is used for.",en={11016},l=55,n="A Strange Red Key",nx=5203,r=0,rl=49,si={13140},su=13140,x=5650}
T[5203]={d="Escort Arko'narin to where Lightforge and her equipment are being held, and then protect her as you escape Shadow Hold. Afterwards, seek out Jessir Moonbow in Felwood to let her know what's happened to her friends.",en={11019},es=1,l=55,n="Rescue From Jaedenar",nx=5204,ob={e={"Protect Arko'narin out of Shadow Hold",{{1448,35.5,59.1}}}},ps={5202},r=0,rl=49,sf=2,sn={11016},x=5650}
T[5204]={d="Return to Jaedenar and kill the succubus Rakaiah before finding the Remains of Trey Lightforge.",en={11020},l=57,n="Retribution of the Light",nx=5385,ob={k={{9518}}},ps={5203},r=0,rl=49,sn={11019},x=4500}
T[5206]={d="Bring 5 Resonating Skulls and the Mystic Crystal to Carlin Redpath in Eastern Plaguelands.",en={11063},l=60,n="Marauders of Darrowshire",nx=5941,ob={i={{13155}}},pg={5168,5181},r=0,rl=50,rs={13157},sn={11063},su=13156,x=6600}
T[5210]={d="Bring the Extended Annals of Darrowshire to Carlin Redpath in Eastern Plaguelands.",en={11063},l=56,n="Brother Carlin",nx=5181,ps={5154},r=0,rl=50,sn={10667},su=13202,x=2900}
T[5211]={d="Free 15 Darrowshire Spirits and return to Carlin Redpath.",en={11063},l=55,n="Defenders of Darrowshire",ob={k={{11064}}},r=0,rl=50,sn={11063},x=5650}
T[5212]={d="Recover 10 Plagued Flesh Samples from Stratholme and return them to Betina Bigglezink. You suspect that any creature in Stratholme would have said flesh sample.",en={11035},l=60,n="The Flesh Does Not Lie",nx=5213,ob={i={{13174}}},r=0,rl=55,sn={11035},tg=81,x=6600,z=2017}
T[5213]={d="Travel to Stratholme and search the ziggurats. Find and return new Scourge Data to Betina Bigglezink.",en={11035},l=60,n="The Active Agent",ob={i={{13176}}},ps={5212},r=0,rl=55,sn={11035},tg=81,x=6600,z=2017}
T[5214]={d="Find Ezra Grimm's smoke shop in Stratholme and recover a box of Grimm's Premium Tobacco. Return to Smokey LaRue when the job is done.",en={11033},l=60,n="The Great Ezra Grimm",ob={i={{13172}}},r=0,rl=55,sn={11033},tg=81,x=8300,z=2017}
T[5215]={d="Speak with High Priestess MacDonnell at Chillwind Point, Western Plaguelands.",en={11053},l=53,n="The Scourge Cauldrons",nx=5216,ps={5092},r=77,rl=50,sn={10838},x=530}
T[5216]={d="Go to Felstone Field in Western Plaguelands to locate and defeat the Cauldron Lord present there. It may have a key that will allow access to the cauldron. You must have the Empty Felstone Field Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={176361},l=53,n="Target: Felstone Field",nx=5217,ob={i={{13194}}},ps={5215},r=77,rl=50,sn={11053},su=13186,x=5250}
T[5217]={d="Bring the Filled Felstone Field Bottle to High Priestess MacDonnell at Chillwind Camp, Western Plaguelands.",en={11053},l=53,n="Return to Chillwind Camp",nx=5219,ps={5216},r=77,rl=50,so={176361},su=13190,x=2650}
T[5218]={eo={176361},l=53,n="Felstone Field Cauldron",ob={i={{13320},{13357},{14047}}},ps={5217,5230},r=0,rl=50,sf=1,so={176361},x=530}
T[5219]={d="Go to Dalson's Tears in Western Plaguelands to locate and defeat the Cauldron Lord present there, and use its key to gain access to the cauldron. You must have the Empty Dalson's Tears Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={177289},l=55,n="Target: Dalson's Tears",nx=5220,ob={i={{13195}}},ps={5217},r=77,rl=50,sn={11053},su=13187,x=5650}
T[5220]={d="Bring the Filled Dalson's Tears Bottle to High Priestess MacDonnell at Chillwind Camp, Western Plaguelands.",en={11053},l=55,n="Return to Chillwind Camp",nx=5222,ps={5219},r=77,rl=50,so={177289},su=13191,x=2800}
T[5221]={eo={177289},l=55,n="Dalson's Tears Cauldron",ob={i={{13320},{13356},{14047}}},ps={5220,5232},r=0,rl=50,sf=1,so={177289},x=560}
T[5222]={d="Go to the Writhing Haunt in Western Plaguelands to locate and defeat the Cauldron Lord present there, and use its key to gain access to the cauldron. You must have the Empty Writhing Haunt Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={176393},l=55,n="Target: Writhing Haunt",nx=5223,ob={i={{13197}}},ps={5220},r=77,rl=50,sn={11053},su=13188,x=5650}
T[5223]={d="Bring the Filled Writhing Haunt Bottle to High Priestess MacDonnell at Chillwind Camp, Western Plaguelands.",en={11053},l=55,n="Return to Chillwind Camp",nx=5225,ps={5222},r=77,rl=50,so={176393},su=13192,x=5650}
T[5224]={eo={176393},l=55,n="Writhing Haunt Cauldron",ob={i={{13320},{13356},{14047}}},ps={5223,5234},r=0,rl=50,sf=1,so={176393},x=560}
T[5225]={d="Go to Gahrron's Withering in Western Plaguelands to locate and defeat the Cauldron Lord present there, and use its key to gain access to the cauldron. You must have the Empty Gahrron's Withering Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={176392},l=58,n="Target: Gahrron's Withering",nx=5226,ob={i={{13196}}},ps={5223},r=77,rl=50,sn={11053},su=13189,x=6200}
T[5226]={d="Bring the Filled Gahrron's Withering Bottle to High Priestess MacDonnell at Chillwind Camp, Western Plaguelands.",en={11053},l=58,n="Return to Chillwind Camp",nx=5238,ps={5225},r=77,rl=50,so={176392},su=13193,x=3100}
T[5227]={eo={176392},l=58,n="Gahrron's Withering Cauldron",ob={i={{13320},{13354},{14047}}},ps={5226,5236},r=0,rl=50,sf=1,so={176392},x=620}
T[5228]={d="Speak with Shadow Priestess Vandis at the Bulwark, Western Plaguelands.",en={11055},l=53,n="The Scourge Cauldrons",nx=5229,ps={5096},r=178,rl=50,sn={10837},x=530}
T[5229]={d="Go to Felstone Field in Western Plaguelands to locate and defeat the Cauldron Lord present there. It may have a key that will allow access to the cauldron. You must have the Empty Felstone Field Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={176361},l=53,n="Target: Felstone Field",nx=5230,ob={i={{13194}}},ps={5228},r=178,rl=50,sn={11055},su=13186,x=5250}
T[5230]={d="Bring the Filled Felstone Field Bottle to Shadow Priestess Vandis at the Bulwark, Western Plaguelands.",en={11055},l=53,n="Return to the Bulwark",nx=5231,ps={5229},r=178,rl=50,so={176361},su=13190,x=2650}
T[5231]={d="Go to Dalson's Tears in Western Plaguelands to locate and defeat the Cauldron Lord present there, and use its key to gain access to the cauldron. You must have the Empty Dalson's Tears Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={177289},l=55,n="Target: Dalson's Tears",nx=5232,ob={i={{13195}}},ps={5230},r=178,rl=50,sn={11055},su=13187,x=5650}
T[5232]={d="Bring the Filled Dalson's Tears Bottle to Shadow Priestess Vandis at the Bulwark, Western Plaguelands.",en={11055},l=55,n="Return to the Bulwark",nx=5233,ps={5231},r=178,rl=50,so={177289},su=13191,x=2800}
T[5233]={d="Go to the Writhing Haunt in Western Plaguelands to locate and defeat the Cauldron Lord present there, and use its key to gain access to the cauldron. You must have the Empty Writhing Haunt Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={176393},l=55,n="Target: Writhing Haunt",nx=5234,ob={i={{13197}}},ps={5232},r=178,rl=50,sn={11055},su=13188,x=5650}
T[5234]={d="Bring the Filled Writhing Haunt Bottle to Shadow Priestess Vandis at The Bulwark, Western Plaguelands.",en={11055},l=55,n="Return to the Bulwark",nx=5235,ps={5233},r=178,rl=50,so={176393},su=13192,x=2800}
T[5235]={d="Go to Gahrron's Withering in Western Plaguelands to locate and defeat the Cauldron Lord present there, and use its key to gain access to the cauldron. You must have the Empty Gahrron's Withering Bottle with you to secure a sample of the poisons used inside the cauldron.",eo={176392},l=58,n="Target: Gahrron's Withering",nx=5236,ob={i={{13196}}},ps={5234},r=178,rl=50,sn={11055},su=13189,x=6200}
T[5236]={d="Bring the Filled Gahrron's Withering Bottle to Shadow Priestess Vandis at the Bulwark, Western Plaguelands.",en={11055},l=58,n="Return to the Bulwark",nx=5237,ps={5235},r=178,rl=50,so={176392},su=13193,x=3100}
T[5237]={en={10838},l=58,n="Mission Accomplished!",ps={5226},r=77,rl=50,sn={10838},x=9300}
T[5238]={en={10837},l=58,n="Mission Accomplished!",ps={5236},r=178,rl=50,sn={10837},x=9300}
T[5241]={d="Find Carlin Redpath.",en={11063},l=56,n="Uncle Carlin",nx=5211,ps={5149},r=0,rl=50,sn={10926},x=2900}
T[5242]={d="Kill Moora and Salia, and bring Shadow Lord Fel'dan's Head to Greta Mosshoof in Felwood.",en={10922},l=58,n="A Final Blow",ob={i={{13207}},k={{9861},{9860}}},ps={5165},r=0,rl=48,sn={10922},x=9300}
T[5243]={d="Travel to Stratholme, in the north. Search the supply crates that litter the city and recover 5 Stratholme Holy Water. Return to Leonid Barthalomew the Revered when you have collected enough of the blessed fluid.",en={11036},l=60,n="Houses of the Holy",ob={i={{13180}}},r=0,rl=55,sn={11036},tg=81,x=6600,z=2017}
T[5244]={d="Speak with Jaron Stoneshaper in Starfall Village.",en={10301},l=56,n="The Ruins of Kel'Theril",nx=5245,r=77,rl=53,sn={11079},x=580}
T[5245]={d="Use Jaron's Pick to find the four Highborne Relic Fragments. Bring them to Aurora Skycaller in Eastern Plaguelands.",en={10304},l=56,n="Troubled Spirits of Kel'Theril",nx=5246,ob={i={{12896},{12897},{12898},{12899}}},ps={5244},r=77,rl=53,sn={10301},su=12891,x=5800}
T[5246]={d="Find the Sacred Highborne Writings in the Temple of Zin-Malor in Azshara, and bring them to Aurora Skycaller near the Northpass Tower in Eastern Plaguelands.",en={10304},l=56,n="Fragments of the Past",nx=5247,ob={i={{13313}}},ps={5245},r=77,rl=53,sn={10304},x=5800}
T[5247]={d="Bring an Enchanted Thorium Bar, 5 Crystal Restore, and a Vial of Dire Water to Aurora Skycaller near the Northpass Tower in Eastern Plaguelands.",en={10304},l=57,n="Fragments of the Past",ob={i={{12655},{11562},{16973}}},ps={5246},r=77,rl=53,sn={10304},su=16974,tg=1,x=6000}
T[5248]={d="Take the Crystal of Zin-Malor to Lake Kel'Theril in Winterspring and find a highborne spirit that will speak to you.",en={10684},l=58,n="Tormented By the Past",nx=5252,ps={5247},r=77,rl=53,sn={10304},su=13347,x=4650}
T[5249]={d="Find Starfall Village in Winterspring and speak with Wynd Nightchaser.",en={11079},ex={5250},l=56,n="To Winterspring!",nx=5244,r=77,rl=53,sn={10924},x=580}
T[5250]={d="Find Starfall in Winterspring and speak with Wynd Nightchaser.",en={11079},ex={5249},l=56,n="Starfall",nx=5244,r=77,rl=53,sn={7907},x=580}
T[5251]={d="Travel to Stratholme and find Archivist Galford of the Scarlet Crusade. Destroy him and burn down the Scarlet Archive.",en={11039},l=60,n="The Archivist",nx=5262,ob={k={{10811}},o={{176245,"Archive Burned"}}},r=0,rl=55,sn={11039},tg=81,x=8300,z=2017}
T[5252]={d="Speak with Wynd Nightchaser in Starfall Village, and ask about the proper place for the Crystal of Zin-Malor.",en={11079},l=58,n="Remorseful Highborne",nx=5253,ps={5248},r=77,rl=53,sn={10684},su=13347,x=4650}
T[5253]={d="Deliver the Crystal of Zin-Malor to Arch Druid Fandral Staghelm in Darnassus.",en={3516},l=58,n="The Crystal of Zin-Malor",ps={5252},r=77,rl=53,sn={11079},su=13347,x=6200}
T[5261]={d="Speak with Eagan Peltskinner.",en={196},l=2,n="Eagan Peltskinner",nx=33,ps={783},r=77,rl=1,sn={823},x=85}
T[5262]={d="Take the Head of Balnazzar to Duke Nicholas Zverenhoff in the Eastern Plaguelands.",en={11039},l=60,n="The Truth Comes Crashing Down",nx=5263,ps={5251},r=0,rl=55,si={13250},su=13250,tg=81,x=8300,z=2017}
T[5263]={d="Venture to Stratholme and destroy Baron Rivendare. Take his head and return to Duke Nicholas Zverenhoff.",en={11039},l=60,n="Above and Beyond",nx=5264,ob={i={{13251}}},ps={5262},r=0,rl=55,sn={11039},tg=81,x=8300,z=2017}
T[5264]={d="Speak with Lord Maxwell Tyrosus. He is inside the church.",en={11034},l=60,n="Lord Maxwell Tyrosus",nx=5265,ps={5263},r=0,rl=55,sn={11039},tg=1,x=6600}
T[5265]={d="Open the Argent Hold and claim your reward.",eo={176317},l=60,n="The Argent Hold",ps={5264},r=0,rl=55,sn={11034},tg=1,x=9950}
T[5281]={d="Find Egan. You only know that he was last seen around Stratholme.",en={11140},l=60,n="The Restless Souls",nx=5282,r=0,rl=55,sn={11038},tg=81,x=6600}
end)()
;(function() local T = D.Q
T[5282]={d="Use Egan's Blaster on the ghostly and spectral citizens of Stratholme. When the restless souls break free from their ghostly shells, use the blaster again - freedom will be theirs!",en={11140},l=60,n="The Restless Souls",ob={k={{11122,"Souls Freed"}}},ps={5281},r=0,rl=55,sn={11140},su=13289,tg=81,x=8300,z=2017}
T[5283]={d="To become an Armorsmith, you must make the following items and return them to Grumnus: 4 Ornate Mithril Helms, 2 Ornate Mithril Boots, 1 Ornate Mithril Breastplate.",en={5164},ex={5284},l=40,n="The Art of the Armorsmith",ob={i={{7937},{7936},{7935}}},r=77,rl=40,sk={164,200},sn={5164},x=3150}
T[5284]={d="To become a Weaponsmith, you must make the following items and return them to Ironus: 4 Moonsteel Broadswords, 4 Massive Iron Axes, 2 Heavy Mithril Axes, and 2 Big Black Maces.",en={11146},ex={5283},l=40,n="The Way of the Weaponsmith",ob={i={{3853},{3855},{7941},{7945}}},r=77,rl=40,sk={164,200},sn={11146},x=3150}
T[5301]={d="To become an armorsmith, you must make the following items and return them to Okothos: 4 Ornate Mithril Helms, 2 Ornate Mithril Boots, 1 Ornate Mithril Breastplate.",en={11177},ex={5302},l=40,n="The Art of the Armorsmith",ob={i={{7937},{7936},{7935}}},r=178,rl=40,sk={164,200},sn={11177},x=3150}
T[5302]={d="To become a Weaponsmith, you must make the following items and return them to Borgosh: 4 Moonsteel Broadswords, 4 Massive Iron Axes, 2 Heavy Mithril Axes, and 2 Big Black Maces.",en={11178},ex={5301},l=40,n="The Way of the Weaponsmith",ob={i={{3853},{3855},{7941},{7945}}},r=178,rl=40,sk={164,200},sn={11178},x=3150}
T[5305]={d="Travel to Stratholme and kill the Crimson Hammersmith. Recover the Crimson Hammersmith's Apron and return to Lilith.",en={11191},ex={8869},l=60,n="Sweet Serenity",ob={i={{13351}}},r=0,rl=50,sk={164,250},sn={11191},tg=81,x=8300,z=2017}
T[5306]={d="Travel to Blackrock Spire and slay Shadow Hunter Vosh'gajin. Recover Vosh'gajin's Snakestone and return to Kilram.",en={11192},l=60,n="Snakestone of the Shadow Huntress",ob={i={{13352}}},r=0,rl=50,sk={164,250},sn={11192},tg=81,x=8300,z=1583}
T[5307]={d="Find the Black Guard Swordsmith in Stratholme and destroy him. Recover the Insignia of the Black Guard and return to Seril Scourgebane.",en={11193},l=60,n="Corruption",ob={i={{13350}}},r=0,rl=50,sk={164,250},sn={11193},tg=81,x=8300,z=2017}
T[5321]={d="Escort Kerlonian Evershade to Liladris Moonriver at Maestra's Post in Ashenvale.",en={11219},es=1,l=20,n="The Sleeper Has Awakened",ob={e={"Escort Kerlonian Evershade to Maestra's Post",{{1440,26.8,36.9}}},i={{13536}}},r=77,rl=17,sf=2,sn={11218},x=1550}
T[5341]={d="Venture to the Scholomance and recover the Barov family fortune. Four deeds make up this fortune: The Deed to Caer Darrow; The Deed to Brill; The Deed to Tarren Mill; and The Deed to Southshore. Return to Alexi Barov when you have completed this task.",en={11022},l=60,n="Barov Family Fortune",nx=5342,ob={i={{13471},{13448},{13450},{13451}}},r=178,rl=52,sn={11022},tg=81,x=6600,z=2057}
T[5342]={d="Travel to Chillwind Camp - Alliance territory - and assassinate Weldon Barov. Take his head and return to Alexi Barov.",en={11022},l=60,n="The Last Barov",ob={i={{13469}}},ps={5341},r=178,rl=52,sn={11022},tg=41,x=8300}
T[5343]={d="Venture to the Scholomance and recover the Barov family fortune. Four deeds make up this fortune: The Deed to Caer Darrow; The Deed to Brill; The Deed to Tarren Mill; and The Deed to Southshore. Return to Weldon Barov when you have completed this task.",en={11023},l=60,n="Barov Family Fortune",nx=5344,ob={i={{13471},{13448},{13450},{13451}}},r=77,rl=52,sn={11023},tg=81,x=6600,z=2057}
T[5344]={d="Travel to the Bulwark - Horde territory - and assassinate Alexi Barov. Take his head and return to Weldon Barov.",en={11023},l=60,n="The Last Barov",ob={i={{13470}}},ps={5343},r=77,rl=52,sn={11023},tg=41,x=8300}
T[5361]={d="Deliver Cliffwatcher Longhorn Report to Nataka Longhorn at Ghost Walker Post in Desolace.",en={11259},l=35,n="Family Tree",r=178,rl=32,sn={10537},su=13507,x=2050}
T[5381]={d="Retrieve the Demon Box from Thunder Axe Fortress, and return it, along with the Demon Pick to Taiga Wisemane in Shadowprey Village.",en={11624},l=38,n="Hand of Iruxos",nx=5581,ob={i={{13542}}},r=178,rl=32,sn={11624},su=14523,x=2850}
T[5382]={d="Find Doctor Theolen Krastinov inside the Scholomance. Destroy him, then burn the Remains of Eva Sarkhoff and the Remains of Lucien Sarkhoff. Return to Eva Sarkhoff when the task is complete.",en={11216},l=60,n="Doctor Theolen Krastinov, the Butcher",nx=5515,ob={k={{11261}},o={{176544,"Remains of Eva Sarkhoff Burned"},{176545,"Remains of Lucien Sarkhoff Burned"}}},r=0,rl=55,sn={11216},tg=81,x=6600,z=2057}
T[5384]={d="Return to the Scholomance with the Blood of Innocents. Find the porch and place the Blood of Innocents in the brazier. Kirtonos will come to feast upon your soul.",en={11216},l=60,n="Kirtonos the Herald",nx=5461,ob={k={{10506}}},ps={5515},r=0,rl=55,sn={11216},su=13523,tg=81,x=8300,z=2057}
T[5385]={d="Return the Remains of Trey Lightforge to Jessir Moonbow in Felwood.",en={11019},l=57,n="The Remains of Trey Lightforge",ps={5204},r=0,rl=49,sn={11020},su=13562,x=7550}
T[5386]={d="Talk to Jinar'Zillen at Shadowprey Village, and then bring Nataka Longhorn 2 Bloodbelly fish.",en={11259},l=37,n="Catch of the Day",ob={i={{13546}}},r=178,rl=32,sn={11259},x=2100}
T[5401]={en={10840},ex={5405,5503},l=55,n="Argent Dawn Commission",r=0,rl=50,sn={10840},x=560}
T[5402]={en={10840},l=55,n="Minion's Scourgestones",ob={i={{12840}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={10840},x=560}
T[5403]={en={10840},l=55,n="Invader's Scourgestones",ob={i={{12841}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={10840},x=560}
T[5404]={en={10840},l=55,n="Corruptor's Scourgestones",ob={i={{12843}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={10840},x=560}
T[5405]={en={10839},ex={5401,5503},l=55,n="Argent Dawn Commission",r=0,rl=50,sn={10839},x=560}
T[5406]={en={10839},l=55,n="Corruptor's Scourgestones",ob={i={{12843}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={10839},x=560}
T[5407]={en={10839},l=55,n="Invader's Scourgestones",ob={i={{12841}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={10839},x=560}
T[5408]={en={10839},l=55,n="Minion's Scourgestones",ob={i={{12840}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={10839},x=560}
T[5421]={en={11317},l=25,n="Fish in a Bucket",ob={i={{13545}}},pa=0,r=178,rl=25,sf=1,sn={11317}}
T[5441]={d="Use the Foreman's Blackjack on Lazy Peons when they're sleeping. Wake up 5 peons, then return the Foreman's Blackjack to Foreman Thazz'ril in the Valley of Trials.",en={11378},l=4,n="Lazy Peons",nx=6394,ob={k={{10556}}},r=178,rl=3,sn={11378},su=16114,x=445}
T[5461]={d="Travel to the Arathi Highlands, to the ruins of Stromgarde. Search Stromgarde for a Keepsake of Remembrance. If you find such an item, return with it to Magistrate Marduke.",en={11286},l=60,n="The Human, Ras Frostwhisper",nx=5462,ob={i={{13585}}},ps={5384},r=0,rl=57,sn={11286},tg=1,x=6600}
T[5462]={d="Travel to Light's Hope in Eastern Plaguelands and seek out Leonid Barthalomew the Revered. Show him the Keepsake of Remembrance and tell him all that you have discovered.",en={11036},l=60,n="The Dying, Ras Frostwhisper",nx=5463,ps={5461},r=0,rl=57,sn={11286},su=13585,tg=1,x=4950}
T[5463]={d="Travel to Stratholme and find Menethil's Gift. Place the Keepsake of Remembrance upon the unholy ground.",eo={176631},l=60,n="Menethil's Gift",nx=5464,ps={5462},r=0,rl=57,sn={11036},su=13585,tg=81,x=6600,z=2017}
T[5464]={d="Take the Soulbound Keepsake to Leonid Barthalomew in Eastern Plaguelands.",en={11036},l=60,n="Menethil's Gift",nx=5465,ps={5463},r=0,rl=57,so={176631},su=13624,tg=1,x=8300}
T[5465]={d="Return to Magistrate Marduke in Caer Darrow. Show him the Soulbound Keepsake.",en={11286},l=60,n="Soulbound Keepsake",nx=5466,ps={5464},r=0,rl=57,sn={11036},su=13624,tg=1,x=4950}
T[5466]={d="Find Ras Frostwhisper in the Scholomance. When you have found him, use the Soulbound Keepsake on his undead visage. Should you succeed in reverting him to a mortal, strike him down and recover the Human Head of Ras Frostwhisper. Take the head back to Magistrate Marduke.",en={11286},l=60,n="The Lich, Ras Frostwhisper",ob={i={{13626}}},ps={5465},r=0,rl=57,sn={11286},su=13752,tg=81,x=9950,z=2057}
T[5481]={d="Collect 3 Gloom Weed and deliver them to Junior Apothecary Holland in the Brill graveyard.",en={10665},l=5,n="Gordo's Task",nx=5482,ob={i={{12737}}},r=178,rl=5,sn={10666},x=225}
T[5482]={d="Collect 10 Doom Weed and deliver them back to Junior Apothecary Holland.",en={10665},l=6,n="Doom Weed",ob={i={{13702}}},ps={5481},r=178,rl=5,sn={10665},x=540}
T[5501]={d="Bring 10 Kodo Bones from the Kodo Graveyard to Bibbly F'utzbuckle at Kormek's Hut.",en={11438},l=39,n="Bone Collector",ob={i={{13703}}},r=0,rl=33,sn={11438},x=2250}
T[5503]={en={11039},ex={5401,5405},l=55,n="Argent Dawn Commission",r=0,rl=50,sn={11039},x=560}
T[5504]={d="Bring 10 Argent Dawn Valor Tokens to Quartermaster Hasana at the Bulwark, Western Plaguelands.",en={10856},ex={5507,5513},l=60,n="Mantles of the Dawn",ob={i={{12844}}},r=178,rl=55,rp={529,21000},sn={10856},x=6600}
T[5505]={en={11056},l=60,n="The Key to Scholomance",ps={5803},r=77,rl=55,sn={11056},x=9950}
T[5507]={d="Bring 10 Argent Dawn Valor Tokens to Quartermaster Lightspark at Chillwind Camp, Western Plaguelands.",en={10857},ex={5504,5513},l=60,n="Mantles of the Dawn",ob={i={{12844}}},r=77,rl=55,rp={529,21000},sn={10857},x=6600}
T[5508]={en={11039},l=55,n="Corruptor's Scourgestones",ob={i={{12843}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={11039},x=560}
T[5509]={en={11039},l=55,n="Invader's Scourgestones",ob={i={{12841}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={11039},x=560}
T[5510]={en={11039},l=55,n="Minion's Scourgestones",ob={i={{12840}}},ps={5401,5503,5405},r=0,rl=50,sf=1,sn={11039},x=560}
T[5511]={en={10837},l=60,n="The Key to Scholomance",ps={5804},r=178,rl=55,sn={10837},x=9950}
T[5513]={d="Bring 10 Argent Dawn Valor Tokens to Quartermaster Breechlock at Light's Hope Chapel, Eastern Plaguelands.",en={11536},ex={5504,5507},l=60,n="Mantles of the Dawn",ob={i={{12844}}},r=0,rl=55,rp={529,21000},sn={11536},x=6600}
T[5514]={d="Bring the Imbued Skeletal Fragments and 15 gold coins to Krinkle Goodsteel in Gadgetzan.",en={5411},l=57,n="Mold Rhymes With...",nx=5802,ps={964},r=178,rl=55,sn={11057},su=14628,x=600}
T[5515]={d="Locate Jandice Barov in the Scholomance and destroy her. From her corpse recover Krastinov's Bag of Horrors. Return the bag to Eva Sarkhoff.",en={11216},l=60,n="Krastinov's Bag of Horrors",nx=5384,ob={i={{13725}}},ps={5382},r=0,rl=55,sn={11216},tg=81,x=6600,z=2057}
T[5517]={d="Bring 25 Argent Dawn Valor Tokens to Quartermaster Breechlock at Light's Hope Chapel, Eastern Plaguelands.",en={11536},ex={5521,5524},l=60,n="Chromatic Mantle of the Dawn",ob={i={{12844}}},r=0,rl=55,rp={529,42000},sn={11536},x=8300}
T[5518]={d="Bring 4 Bolts of Runecloth, 8 Rugged Leather, 2 Rune Threads, and Ogre Tannin to Knot Thimblejack. He is currently chained inside the Gordok wing of Dire Maul.",en={14338},l=60,n="The Gordok Ogre Suit",nx=5519,ob={i={{14048},{8170},{14341},{18240}}},r=0,rl=56,sn={14338},tg=81,x=6600,z=2557}
T[5519]={en={14338},l=60,n="The Gordok Ogre Suit",ob={i={{14048},{8170},{14341},{18240}}},ps={5518},r=0,rl=56,sf=1,sn={14338},tg=81,z=2557}
T[5521]={d="Bring 25 Argent Dawn Valor Tokens to Quartermaster Lightspark at Chillwind Camp, Western Plaguelands.",en={10857},ex={5517,5524},l=60,n="Chromatic Mantle of the Dawn",ob={i={{12844}}},r=77,rl=55,rp={529,42000},sn={10857},x=8300}
T[5522]={d="Bring the Frozen Eggs to Leonid Barthalomew in the Eastern Plaguelands.",en={11036},l=60,n="Leonid Barthalomew",nx=5531,ps={4735},r=0,rl=57,sn={10267},su=13761,tg=81,x=4950}
T[5524]={d="Bring 25 Argent Dawn Valor Tokens to Quartermaster Hasana at the Bulwark, Western Plaguelands.",en={10856},ex={5517,5521},l=60,n="Chromatic Mantle of the Dawn",ob={i={{12844}}},r=178,rl=55,rp={529,42000},sn={10856},x=8300}
T[5525]={en={14338},l=60,n="Free Knot!",nx=7429,ob={i={{18250}}},r=0,rl=57,sn={14338},tg=81,x=6600,z=2557}
T[5526]={d="Find the Felvine in Dire Maul and acquire a shard from it. Chances are you'll only be able to procure one with the demise of Alzzin the Wildshaper. Use the Reliquary of Purity to securely seal the shard inside, and return it to Rabine Saturna in Nighthaven, Moonglade.",en={11801},l=60,n="Shards of the Felvine",ob={i={{18540}}},ps={5527},r=0,rl=56,rs={18501},sn={11801},su=18539,tg=81,x=8300}
T[5527]={d="Travel to Silithus and search for a Reliquary of Purity within the ruins of Southwind Village. If you are able to find it, return with it to Rabine Saturna in Nighthaven, Moonglade.",en={11801},l=60,n="A Reliquary of Purity",nx=5526,ob={i={{22201}}},r=0,rl=56,sn={11801},x=6600}
T[5528]={en={14322},l=60,n="The Gordok Taste Test",r=0,rl=57,sn={14322},tg=81,z=2557}
T[5529]={d="Kill 20 Plagued Hatchlings, then return to Betina Bigglezink at the Light's Hope Chapel.",en={11035},l=58,n="Plagued Hatchlings",nx=5582,ob={k={{10678}}},r=0,rl=55,sn={11035},tg=81,x=6200,z=2057}
T[5531]={d="Bring the Frozen Eggs to Betina Bigglezink.",en={11035},l=60,n="Betina Bigglezink",nx=4771,ps={5522},r=0,rl=57,sn={11036},su=13761,tg=81,x=1650,z=2057}
T[5533]={d="Speak with Alchemist Arbington at Chillwind Point, Western Plaguelands.",en={11056},l=55,n="Scholomance",nx=5537,ps={5097},r=77,rl=55,sn={10838},x=560}
T[5534]={d="Find Some Rune that the naga have in their possession in the Ruins of Eldarath and return it to Kim'jael in Azshara.",en={8420},l=53,n="Kim'jael's \"Missing\" Equipment",ob={i={{13815}}},ps={3601},r=0,rl=47,sn={8420},x=6550}
T[5535]={d="Destroy 6 Highborne Apparitions and 6 Highborne Lichlings before returning to Loh'atu in Azshara.",en={11548},l=47,n="Spiritual Unrest",ob={k={{6116},{6117}}},r=0,rl=45,sn={11548},x=4200}
T[5536]={d="Kill 6 Haldarr Satyr, 2 Haldarr Tricksters, 2 Haldarr Felsworn and then return to Loh'atu on the border of Ashenvale.",en={11548},l=47,n="A Land Filled with Hatred",ob={k={{6125},{6126},{6127}}},r=0,rl=45,sn={11548},x=4200}
T[5537]={d="Bring 15 Skeletal Fragments to Alchemist Arbington at Chillwind Point, Western Plaguelands.",en={11056},l=57,n="Skeletal Fragments",nx=5538,ob={i={{14619}}},ps={5533},r=77,rl=55,sn={11056},x=4500}
T[5538]={d="Bring the Imbued Skeletal Fragments and 15 gold coins to Krinkle Goodsteel in Gadgetzan.",en={5411},l=57,n="Mold Rhymes With...",nx=5801,ps={5537},r=77,rl=55,sn={11056},su=14628,x=600}
T[5541]={d="Bring Rumbleshot's Ammo to Hegnar Rumbleshot in Dun Morogh.",en={1243},l=6,n="Ammo for Rumbleshot",ob={i={{13850}}},r=77,rl=5,sn={1694},x=540}
T[5542]={d="Slay 20 Plaguehound Runts, 5 Plaguehounds and 5 Frenzied Plaguehounds. Return to Tirion Fordring when the task is complete.",en={1855},l=56,n="Demon Dogs",nx=5742,ob={k={{8596},{8597},{8598}}},r=0,rl=52,sn={1855,12126},x=5800}
T[5543]={d="Slay 30 Plaguebats and return to Tirion Fordring.",en={1855},l=56,n="Blood Tinged Skies",nx=5742,ob={k={{8600}}},r=0,rl=52,sn={1855,12126},x=5800}
T[5544]={d="Seek out the Carrion Grubs and Devourers of the region. Slay them and harvest their meat. Return to Tirion Fordring when you have gathered 15 Slabs of Carrion Worm Meat.",en={1855},l=56,n="Carrion Grubbage",nx=5742,ob={i={{13853}}},r=0,rl=52,sn={1855,12126},x=5800}
T[5545]={d="Bring 8 Bundles of Wood to Raelen at the Eastvale Logging Camp.",en={10616},l=9,n="A Bundle of Trouble",ob={i={{13872}}},r=77,rl=5,sn={10616},x=780}
T[5561]={d="Bring five Tamed Kodos and the Kodo Kombobulator back to Smeed Scrabblescrew at Scrabblescrew's Camp.",en={11596},l=34,n="Kodo Roundup",ob={c={{{4700,4701,4702}}}},r=0,rl=30,sn={11596},su=13892,x=2000}
T[5581]={d="Banish 6 Portals at Mannoroc Coven and return to Taiga Wisemane at Shadowprey Village.",en={11624},l=38,n="Portals of the Legion",ob={k={{11937,"Portals Banished"}}},ps={5381},r=178,rl=32,sn={11624},su=14547,x=3550}
T[5582]={d="Bring the Healthy Dragon Scale to Betina Bigglezink at the Light's Hope Chapel in Eastern Plaguelands.",en={11035},l=58,n="Healthy Dragon Scale",ps={5529},r=0,rl=55,sf=1,si={13920},su=13920,tg=81,z=2057}
T[5601]={d="Find Pamela Redpath in Darrowshire.",en={10926},ex={5142},l=55,n="Sister Pamela",nx=5149,r=0,rl=50,sn={11629},x=560}
T[5621]={c=16,d="Find Sentinel Shaya and heal her wounds using Lesser Heal (Rank 2). Afterwards, grant her Power Word: Fortitude and then return to Laurna Morninglight in Dolanaar.",en={3600},l=4,n="Garments of the Moon",ob={k={{12429}}},r=8,rl=5,sn={3600},x=270}
T[5622]={c=16,d="Speak to Laurna Morninglight in Teldrassil.",en={3600},l=4,n="In Favor of Elune",nx=5621,r=8,rl=5,sn={3595},x=90}
T[5623]={c=16,d="Speak to Priestess Josetta in Elwynn Forest.",en={377},l=4,n="In Favor of the Light",nx=5624,r=1,rl=5,sn={375},x=90}
T[5624]={c=16,d="Find Guard Roberts and heal his wounds using Lesser Heal (Rank 2). Afterwards, grant him Power Word: Fortitude and then return to Priestess Josetta in Goldshire.",en={377},l=4,n="Garments of the Light",ob={k={{12423}}},r=1,rl=5,sn={377},x=270}
T[5625]={c=16,d="Find Mountaineer Dolf and heal his wounds using Lesser Heal (Rank 2). Afterwards, grant him Power Word: Fortitude and then return to Maxan Anvol in Kharanos.",en={1226},l=4,n="Garments of the Light",ob={k={{12427}}},r=4,rl=5,sn={1226},x=270}
T[5626]={c=16,d="Speak to Maxan Anvol in Dun Morogh.",en={1226},l=4,n="In Favor of the Light",nx=5625,r=4,rl=5,sn={837},x=90}
T[5627]={c=16,en={11401},ex={5628,5629,5630,5631,5632,5633},l=10,n="Stars of Elune",ps={5628,5629,5630,5631,5632,5633},r=8,rl=10,sn={11401}}
T[5628]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5627,5629,5630,5631,5632,5633},l=10,n="Returning Home",nx=0,r=8,rl=10,sn={377},x=210}
T[5629]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5627,5628,5630,5631,5632,5633},l=10,n="Returning Home",nx=0,r=8,rl=10,sn={3600},x=210}
T[5630]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5627,5628,5629,5631,5632,5633},l=10,n="Returning Home",nx=0,r=8,rl=10,sn={1226},x=210}
T[5631]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5627,5628,5629,5630,5632,5633},l=10,n="Returning Home",nx=0,r=8,rl=10,sn={376},x=210}
T[5632]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5627,5628,5629,5630,5631,5633},l=10,n="Returning Home",nx=0,r=8,rl=10,sn={11397},x=210}
T[5633]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5627,5628,5629,5630,5631,5632},l=10,n="Returning Home",nx=0,r=8,rl=10,sn={11406},x=210}
T[5634]={c=16,en={376},ex={5635,5636,5637,5638,5639,5640},l=10,n="Desperate Prayer",r=5,rl=10,sn={376}}
T[5635]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5634,5636,5637,5638,5639,5640},l=10,n="Desperate Prayer",r=5,rl=10,sn={377},x=210}
T[5636]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5634,5635,5637,5638,5639,5640},l=10,n="Desperate Prayer",r=5,rl=10,sn={3600},x=210}
T[5637]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5634,5635,5636,5638,5639,5640},l=10,n="Desperate Prayer",r=5,rl=10,sn={1226},x=210}
T[5638]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5634,5635,5636,5637,5639,5640},l=10,n="Desperate Prayer",r=5,rl=10,sn={11397}}
T[5639]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5634,5635,5636,5637,5638,5640},l=10,n="Desperate Prayer",r=5,rl=10,sn={11406},x=210}
T[5640]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5634,5635,5636,5637,5638,5639},l=10,n="Desperate Prayer",r=5,rl=10,sn={11401}}
T[5641]={c=16,en={11406},ex={5645,5647},l=20,n="A Lack of Fear",r=4,rl=20,sn={11406}}
T[5642]={c=16,d="Speak to Ur'kyo in Orgrimmar.",en={6018},ex={5643,5680},l=20,n="Shadowguard",r=128,rl=20,sn={3044},x=390}
T[5643]={c=16,d="Speak to Ur'kyo in Orgrimmar.",en={6018},ex={5642,5680},l=20,n="Shadowguard",r=128,rl=20,sn={4606},x=390}
T[5644]={c=16,d="Speak to Aelthalyste in the Undercity.",en={4606},ex={5646,5679},l=20,n="Devouring Plague",r=16,rl=20,sn={3044},x=390}
T[5645]={c=16,d="Speak to High Priest Rohan in Ironforge.",en={11406},ex={5641,5647},l=20,n="A Lack of Fear",r=4,rl=20,sn={376},x=390}
T[5646]={c=16,d="Speak to Aelthalyste in the Undercity.",en={4606},ex={5644,5679},l=20,n="Devouring Plague",r=16,rl=20,sn={6018},x=390}
T[5647]={c=16,d="Speak to High Priest Rohan in Ironforge.",en={11406},ex={5641,5645},l=20,n="A Lack of Fear",r=4,rl=20,sn={11401},x=390}
T[5648]={c=16,d="Find Grunt Kor'ja and heal her wounds using Lesser Heal (Rank 2). Afterwards, grant her Power Word: Fortitude and then return to Tai'jin at Razor Hill.",en={3706},l=4,n="Garments of Spirituality",ob={k={{12430}}},r=128,rl=5,sn={3706},x=270}
T[5649]={c=16,d="Speak to Tai'jin in Durotar.",en={3706},l=4,n="In Favor of Spirituality",nx=5648,r=128,rl=5,sn={3707},x=90}
T[5650]={c=16,d="Find Deathguard Kel and heal his wounds using Lesser Heal (Rank 2). Afterwards, grant him Power Word: Fortitude and then return to Dark Cleric Beryl in Brill.",en={2129},l=4,n="Garments of Darkness",ob={k={{12428}}},r=16,rl=5,sn={2129},x=270}
T[5651]={c=16,d="Speak to Dark Cleric Beryl in Tirisfal Glades.",en={2129},l=4,n="In Favor of Darkness",nx=5650,r=16,rl=5,sn={2123},x=90}
T[5652]={c=16,en={6018},ex={5654,5655,5656,5657},l=10,n="Hex of Weakness",r=128,rl=10,sn={6018}}
T[5654]={c=16,d="Speak to Ur'kyo in Orgrimmar.",en={6018},ex={5652,5655,5656,5657},l=10,n="Hex of Weakness",r=128,rl=10,sn={3706},x=210}
T[5655]={c=16,d="Speak to Ur'kyo in Orgrimmar.",en={6018},ex={5652,5654,5656,5657},l=10,n="Hex of Weakness",r=128,rl=10,sn={11407},x=210}
T[5656]={c=16,d="Speak to Ur'kyo in Orgrimmar.",en={6018},ex={5652,5654,5655,5657},l=10,n="Hex of Weakness",r=128,rl=10,sn={3044},x=210}
T[5657]={c=16,d="Speak to Ur'kyo in Orgrimmar.",en={6018},ex={5652,5654,5655,5656},l=10,n="Hex of Weakness",r=128,rl=10,sn={4606},x=210}
T[5658]={c=16,en={4606},ex={5660,5661,5662,5663},l=10,n="Touch of Weakness",r=16,rl=10,sn={4606}}
T[5660]={c=16,d="Speak to Aelthalyste in the Undercity.",en={4606},ex={5658,5661,5662,5663},l=10,n="Touch of Weakness",r=16,rl=10,sn={3706},x=210}
T[5661]={c=16,d="Speak to Aelthalyste in the Undercity.",en={4606},ex={5658,5660,5662,5663},l=10,n="Touch of Weakness",r=16,rl=10,sn={11407},x=210}
T[5662]={c=16,d="Speak to Aelthalyste in the Undercity.",en={4606},ex={5658,5660,5661,5663},l=10,n="Touch of Weakness",r=16,rl=10,sn={6018},x=210}
T[5663]={c=16,d="Speak to Aelthalyste in the Undercity.",en={4606},ex={5658,5660,5661,5662},l=10,n="Touch of Weakness",r=16,rl=10,sn={3044},x=210}
T[5672]={c=16,en={11401},ex={5673,5674,5675},l=20,n="Elune's Grace",r=8,rl=20,sn={11401}}
T[5673]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5672,5674,5675},l=20,n="Elune's Grace",r=8,rl=20,sn={376},x=390}
T[5674]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5672,5673,5675},l=20,n="Elune's Grace",r=8,rl=20,sn={11397},x=390}
T[5675]={c=16,d="Speak to Priestess Alathea in Darnassus.",en={11401},ex={5672,5673,5674},l=20,n="Elune's Grace",r=8,rl=20,sn={11406},x=390}
T[5676]={c=16,en={376},ex={5677,5678},l=20,n="Arcane Feedback",r=1,rl=20,sn={376},x=390}
T[5677]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5676,5678},l=20,n="Arcane Feedback",r=1,rl=20,sn={11406},x=390}
T[5678]={c=16,d="Speak to High Priestess Laurena in Stormwind.",en={376},ex={5676,5677},l=20,n="Arcane Feedback",r=1,rl=20,sn={11401}}
T[5679]={c=16,en={4606},ex={5644,5646},l=20,n="Devouring Plague",r=16,rl=20,sn={4606}}
T[5680]={c=16,en={6018},ex={5642,5643},l=20,n="Shadowguard",r=128,rl=20,sn={6018}}
T[5713]={d="Protect Sentinel Aynasha, then speak with Onaeya at Maestra's Post in Ashenvale.",en={11806},l=15,n="One Shot. One Kill.",ob={e={"Protect Aynasha",{{1439,45.9,90.4}}}},r=77,rl=10,sf=2,sn={11711},x=1050}
T[5721]={d="Place the Relic Bundle at the Darrowshire town square.",en={10926},l=60,n="The Battle of Darrowshire",nx=5942,ob={k={{10936}}},ps={5941},r=0,rl=55,sn={10667},su=15209,tg=62,x=8300}
T[5722]={d="Search Ragefire Chasm for Maur Grimtotem's corpse and search it for any items of interest.",en={11834},l=16,n="Searching for the Lost Satchel",nx=5724,r=178,rl=9,sn={11833},tg=81,x=880,z=2437}
T[5723]={d="Search Orgrimmar for Ragefire Chasm, then kill 8 Ragefire Troggs and 8 Ragefire Shaman before returning to Rahauro in Thunder Bluff.",en={11833},l=15,n="Testing an Enemy's Strength",ob={k={{11318},{11319}}},r=178,rl=9,sn={11833},tg=81,x=800,z=2437}
T[5724]={d="Take the Grimtotem Satchel to Rahauro in Thunder Bluff.",en={11833},l=16,n="Returning the Lost Satchel",ps={5722},r=178,rl=9,sn={11834},su=14381,tg=81,x=1450,z=2437}
T[5725]={d="Bring the books Spells of Shadow and Incantations from the Nether to Varimathras in Undercity.",en={2425},l=16,n="The Power to Destroy...",ob={i={{14395},{14396}}},r=178,rl=9,sn={2425},tg=81,x=1450,z=2437}
T[5726]={d="Bring a Lieutenant's Insignia to Thrall in Orgrimmar.",en={4949},l=12,n="Hidden Enemies",nx=5727,ob={i={{14544}}},r=178,rl=9,sn={4949},x=910}
T[5727]={d="Take the Lieutenant's Insignia to Neeru Fireblade and speak to him. Gauge if he believes you are a member of the Burning Blade and then return to Thrall in Orgrimmar.",en={4949},l=12,n="Hidden Enemies",nx=5728,ob={k={{3216}}},ps={5726},r=178,rl=9,sf=2,sn={4949},su=14544,x=455}
T[5728]={d="Kill Bazzalan and Jergosh the Invoker before returning to Thrall in Orgrimmar.",en={4949},l=16,n="Hidden Enemies",nx=5729,ob={k={{11519},{11518}}},ps={5727},r=178,rl=9,sn={4949},tg=81,x=1150,z=2437}
T[5729]={d="Speak to Neeru Fireblade in Orgrimmar.",en={3216},l=15,n="Hidden Enemies",nx=5730,ps={5728},r=178,rl=9,sn={4949},x=105}
T[5730]={d="Speak to Thrall in Orgrimmar and tell him what you've learned.",en={4949},l=16,n="Hidden Enemies",ps={5729},r=178,rl=9,sn={3216},x=1450}
T[5741]={d="Get the Sceptre of Light and then return it to Azore Aldamort at the tower in Ethel Rethor.",en={11863},l=33,n="Sceptre of Light",nx=6027,ob={i={{15750}}},r=0,rl=30,sn={11863},x=2650}
T[5742]={d="Listen to what Tirion Fordring has to say.",en={1855},l=56,n="Redemption",nx=5781,ob={k={{1855}}},pg={5542,5543,5544},r=0,rl=52,sf=2,sn={1855},x=580}
T[5761]={d="Enter Ragefire Chasm and slay Taragaman the Hungerer, then bring his heart back to Neeru Fireblade in Orgrimmar.",en={3216},l=16,n="Slaying the Beast",ob={i={{14540}}},r=178,rl=9,sn={3216},tg=81,x=1150,z=2437}
T[5762]={d="Take Kravel's Crate to Hemet Nesingwary in Stranglethorn.",en={715},l=31,n="Hemet Nesingwary",r=0,rl=28,sn={4452},su=14542,x=1250}
T[5763]={d="Bring Roon's Kodo Horn to Hemet Nesingwary in Stranglethorn.",en={715},l=31,n="Hunting in Stranglethorn",r=178,rl=28,sn={11877},su=14546,x=1250}
T[5781]={d="Travel to the Undercroft - at the southernmost section of the Eastern Plaguelands - and recover Taelan's Hammer. Return to Tirion Fordring upon completion of your objective.",en={1855},l=57,n="Of Forgotten Memories",nx=5845,ob={i={{14613}}},ps={5742},r=0,rl=52,sn={1855},x=6000}
T[5801]={d="Take the Skeleton Key Mold and 2 Thorium Bars to the top of Fire Plume Ridge in Un'Goro Crater. Use the Skeleton Key Mold by the lava lake to forge the Unfinished Skeleton Key.",en={11056},l=57,n="Fire Plume Forged",nx=5803,ob={i={{14645}}},ps={5538},r=77,rl=55,sn={5411},su=14644,x=4500}
T[5802]={d="Take the Skeleton Key Mold and 2 Thorium Bars to the top of Fire Plume Ridge in Un'Goro Crater. Use the Skeleton Key Mold by the lava lake to forge the Unfinished Skeleton Key.",en={11057},l=57,n="Fire Plume Forged",nx=5804,ob={i={{14645}}},ps={5514},r=178,rl=55,sn={5411},su=14644,x=4500}
T[5803]={d="Destroy Araj the Summoner and bring Araj's Scarab to Alchemist Arbington at Chillwind Point, Western Plaguelands.",en={11056},l=60,n="Araj's Scarab",nx=5505,ob={i={{14610}}},ps={5801},r=77,rl=55,sn={11056},tg=1,x=4950}
T[5804]={d="Destroy Araj the Summoner and bring Araj's Scarab to Apothecary Dithers at the Bulwark, Western Plaguelands.",en={11057},l=60,n="Araj's Scarab",nx=5511,ob={i={{14610}}},ps={5802},r=178,rl=55,sn={11057},tg=1,x=4950}
T[5821]={d="Escort the Gizelton Caravan past the Kolkar Centaur village. Talk with Smeed at Scrabblescrew's Camp for your reward.",en={11596},es=1,l=35,n="Bodyguard for Hire",ob={e={"Escort Gizelton Caravan past Kolkar Centaur Village",{{1443,67.2,56.6}}}},r=0,rl=30,sf=2,sn={11625},x=2750}
T[5845]={d="Travel to Northdale, in the northeastern region of the Eastern Plaguelands, and recover the Symbol of Lost Honor. Return to Tirion Fordring upon completion of your objective.",en={1855},l=58,n="Of Lost Honor",nx=5846,ob={i={{14625}}},ps={5781},r=0,rl=52,sn={1855},x=6200}
T[5846]={d="Travel to island of Caer Darrow, in the south-central region of the Plaguelands, and look for any clues as to the whereabouts of the painting.",en={11936},l=58,n="Of Love and Family",nx=5848,ps={5845},r=0,rl=52,sn={1855},x=6200}
T[5848]={d="Travel to Stratholme, in the northern part of the Plaguelands. It is in the Scarlet Bastion that you will find the painting 'Of Love and Family,' hidden behind another painting depicting the twin moons of our world.",en={1855},l=60,n="Of Love and Family",nx=5861,ob={i={{14679}}},ps={5846},r=0,rl=52,sn={11936},tg=81,x=6600,z=2017}
T[5861]={d="Travel to Uther's Tomb, located in the southern Plaguelands. Show Myranda the Hag Tirion's Gift.",en={11872},l=60,n="Find Myranda",nx=5862,ps={5848},r=0,rl=52,sn={1855},su=14872,x=4950}
T[5862]={d="Speak to Myranda to gain the Scarlet Illusion. Travel to Hearthglen while under the Scarlet Illusion and deliver Tirion's Gift to Highlord Taelan Fordring.",en={1842},l=60,n="Scarlet Subterfuge",nx=5944,ps={5861},r=0,rl=52,sn={11872},su=14872,tg=1,x=6600}
T[5863]={d="Andi Lynn in Gadgetzan wants you to destroy the Dunemaul Compound by killing 10 Dunemaul Brutes, 10 Dunemaul Enforcers, and Gor'marok the Ravager.",en={11758},l=49,n="The Dunemaul Compound",ob={k={{5474},{5472},{12046}}},r=0,rl=44,sn={11758},x=4550}
T[5881]={d="Maggran wishes you to deliver a letter to Grish Longrunner at the Great Lift in the Barrens.",en={12576},l=28,n="Calling in the Reserves",r=178,rl=23,sn={11860},su=16189,x=1150}
T[5882]={en={9528},l=55,n="Salve via Hunting",nx=4103,ob={i={{11515}}},ps={4101},r=77,rl=48,sn={9528},x=4200}
T[5883]={en={9528},l=55,n="Salve via Mining",nx=4104,ob={i={{11513}}},ps={4101},r=77,rl=48,sk={186,200},sn={9528},x=4200}
T[5884]={en={9528},l=55,n="Salve via Gathering",nx=4105,ob={i={{11514}}},ps={4101},r=77,rl=48,sk={182,200},sn={9528},x=4200}
T[5885]={en={9528},l=55,n="Salve via Skinning",nx=4106,ob={i={{11512}}},ps={4101},r=77,rl=48,sk={393,200},sn={9528},x=4200}
T[5886]={en={9528},l=55,n="Salve via Disenchanting",nx=4107,ob={i={{11174}}},ps={4101},r=77,rl=48,sk={333,200},sn={9528},x=4200}
T[5887]={en={9529},l=55,n="Salve via Hunting",nx=4108,ob={i={{11515}}},ps={4102},r=178,rl=48,sf=0,sn={9529}}
T[5888]={en={9529},l=55,n="Salve via Mining",nx=4109,ob={i={{11513}}},ps={4102},r=178,rl=48,sf=0,sk={186,200},sn={9529}}
T[5889]={en={9529},l=55,n="Salve via Gathering",nx=4110,ob={i={{11514}}},ps={4102},r=178,rl=48,sf=0,sk={182,200},sn={9529}}
T[5890]={en={9529},l=55,n="Salve via Skinning",nx=4111,ob={i={{11512}}},ps={4102},r=178,rl=48,sf=0,sk={393,200},sn={9529}}
T[5891]={en={9529},l=55,n="Salve via Disenchanting",nx=4112,ob={i={{11174}}},ps={4102},r=178,rl=48,sf=0,sk={333,200},sn={9529}}
T[5892]={d="Bring 10 Irondeep Supplies to the Alliance Quartermaster in Dun Baldar.",en={12096},l=55,n="Irondeep Supplies",ob={i={{17522}}},r=77,rl=51,sf=1,sn={12096},tg=41}
T[5893]={d="Bring 10 Coldtooth Supplies to the Horde Quatermaster in Frostwolf Keep.",en={12097},l=55,n="Coldtooth Supplies",ob={i={{17542}}},r=178,rl=51,sf=1,sn={12097},tg=41}
T[5901]={d="Use the Empty Termite Jar on the Termite Mounds in Eastern Plaguelands. After you've gathered 100 Plagueland Termites, return to Mickey Levine at the Bulwark in Tirisfal Glades.",en={11615},l=55,n="A Plague Upon Thee",nx=5902,ob={i={{15043}}},r=178,rl=48,sn={11615},su=15042,x=5650}
T[5902]={d="Find someplace suitable in the center of the Northridge Lumber Mill in Western Plaguelands to place the Barrel of Plagueland Termites.",eo={177491},l=55,n="A Plague Upon Thee",nx=6390,ps={5901},r=178,rl=48,sn={11615},su=15044,x=2800}
T[5903]={d="Use the Empty Termite Jar on the Termite Mounds in Eastern Plaguelands. After you've gathered 100 Plagueland Termites, return to Nathaniel Dumah at Chillwind Camp in Western Plaguelands.",en={11616},l=55,n="A Plague Upon Thee",nx=5904,ob={i={{15043}}},r=77,rl=48,sn={11616},su=15042,x=5650}
T[5904]={d="Find someplace suitable in the center of the Northridge Lumber Mill in Western Plaguelands to place the Barrel of Plagueland Termites.",eo={177491},l=55,n="A Plague Upon Thee",nx=6389,ps={5903},r=77,rl=48,sn={11616},su=15044,x=2800}
T[5921]={c=1024,d="Use the spell \"Teleport: Moonglade\" to travel to Moonglade. When you arrive, speak with Dendrite Starblaze in the village of Nighthaven.",en={11802},l=10,n="Moonglade",nx=5929,r=8,rl=10,sn={4217},x=210}
T[5922]={c=1024,d="Use the spell \"Teleport: Moonglade\" to travel to Moonglade. When you arrive, speak with Dendrite Starblaze in the village of Nighthaven.",en={11802},l=10,n="Moonglade",nx=5930,r=32,rl=10,sn={3033},x=210}
T[5923]={c=1024,d="Speak with Mathrengyl Bearwalker in the Cenarion Enclave, Darnassus.",en={4217},ex={5924,5925},l=10,n="Heeding the Call",nx=5921,r=8,rl=10,sn={4218},x=85}
T[5924]={c=1024,d="Speak with Mathrengyl Bearwalker in the Cenarion Enclave, Darnassus.",en={4217},ex={5923,5925},l=10,n="Heeding the Call",nx=5921,r=8,rl=10,sn={5505},x=85}
T[5925]={c=1024,d="Speak with Mathrengyl Bearwalker in the Cenarion Enclave, Darnassus.",en={4217},ex={5923,5924},l=10,n="Heeding the Call",nx=5921,r=8,rl=10,sn={3602},x=85}
T[5926]={c=1024,d="Speak with Turak Runetotem on the Elder Rise of Thunder Bluff.",en={3033},ex={5927,5928},l=10,n="Heeding the Call",nx=5922,r=32,rl=10,sn={6746},x=85}
T[5927]={c=1024,d="Speak with Turak Runetotem on the Elder Rise of Thunder Bluff.",en={3033},ex={5926,5928},l=10,n="Heeding the Call",nx=5922,r=32,rl=10,sn={6929},x=85}
T[5928]={c=1024,d="Speak with Turak Runetotem on the Elder Rise of Thunder Bluff.",en={3033},ex={5926,5927},l=10,n="Heeding the Call",nx=5922,r=32,rl=10,sn={3064},x=85}
T[5929]={c=1024,d="Seek out the Great Bear Spirit in northwestern Moonglade and learn what it has to share with you about the nature of the bear. When finished, return to Dendrite Starblaze in Nighthaven, Moonglade.",en={11802},l=10,n="Great Bear Spirit",nx=5931,ob={k={{11956}}},ps={5921},r=8,rl=10,sf=2,sn={11802},x=420}
T[5930]={c=1024,d="Seek out the Great Bear Spirit in northwestern Moonglade and learn what it has to share with you about the nature of the bear. When finished, return to Dendrite Starblaze in Nighthaven, Moonglade.",en={11802},l=10,n="Great Bear Spirit",nx=5932,ob={k={{11956}}},ps={5922},r=32,rl=10,sf=2,sn={11802},x=420}
T[5931]={c=1024,d="Return to Darnassus and speak with Mathrengyl Bearwalker in the Cenarion Enclave.",en={4217},l=10,n="Back to Darnassus",nx=6001,ps={5929},r=8,rl=10,sn={11802},x=85}
T[5932]={c=1024,d="Return to Thunder Bluff and speak with Turak Runetotem on the Elder Rise.",en={3033},l=10,n="Back to Thunder Bluff",nx=6002,ps={5930},r=32,rl=10,sn={11802},x=85}
T[5941]={d="Take the Bundle of Relics to Chromie in Andorhal.",en={10667},l=60,n="Return to Chromie",nx=5721,ps={5206},r=0,rl=50,sn={11063},su=15314,x=3300}
T[5942]={d="Bring Joseph's Key to Joseph's Chest.",eo={177544},l=60,n="Hidden Treasures",ps={5721},r=0,rl=50,sn={10926},su=15328,x=9950}
T[5943]={d="Escort the Gizelton Caravan through Mannoroc Coven. Talk with Smeed at Scrabblescrew's Camp for your reward.",en={11596},es=1,l=38,n="Gizelton Caravan",ob={e={"Escort Gizelton Caravan past Mannoroc Coven",{{1443,55.7,67.8}}}},r=0,rl=32,sf=2,sn={11626},x=2850}
T[5944]={d="Escort Taelan Fordring out of Hearthglen.",en={1855,12126},es=1,l=60,n="In Dreams",ob={e={"Redemption?",{{1422,53.9,24.3}}}},ps={5862},r=0,rl=52,sf=2,sn={1842},tg=1,x=9950}
T[5961]={d="Speak with Nathanos Blightcaller in the Eastern Plaguelands. He is said to have taken up residence at the Marris Stead.",en={11878},l=56,n="The Champion of the Banshee Queen",r=178,rl=54,sn={10181},x=1450}
T[5981]={d="Rivern Frostwind wants you to kill 4 Frostmaul Giants and 4 Frostmaul Preservers.",en={10618},l=60,n="Rampaging Giants",ob={k={{7428},{7429}}},r=77,rl=58,rp={589,9000},sf=1,sn={10618},tg=1}
T[6001]={c=1024,d="Use the Cenarion Moondust on the Moonkin Stone of Auberdine to bring forth Lunaclaw. From there, you must face Lunaclaw and earn the strength of body and heart it possesses.",en={4217},l=10,n="Body and Heart",ob={k={{12144}}},ps={5931},r=8,rl=10,sf=2,sn={4217},su=15208,x=840}
T[6002]={c=1024,d="Use the Cenarion Lunardust on the Moonkin Stone between Mulgore and the Barrens to bring forth Lunaclaw. From there, you must face Lunaclaw and earn the strength of body and heart it possesses.",en={3033},l=10,n="Body and Heart",ob={k={{12144}}},ps={5932},r=32,rl=10,sf=2,sn={3033},su=15710,x=840}
T[6004]={d="Kill 2 Scarlet Medics, 2 Scarlet Hunters, 2 Scarlet Magi and 2 Scarlet Knights before returning to Kirsta Deepshadow in Western Plaguelands.",en={11610},l=56,n="Unfinished Business",nx=6023,ob={k={{10605},{1831},{1826},{1833}}},r=0,rl=50,sn={11610},x=5800}
T[6021]={d="Bring Zaeldarr's Head to Caretaker Alen at Light's Hope Chapel.",en={11038},l=55,n="Zaeldarr the Outcast",ob={i={{15785}}},r=0,rl=50,sn={11038},x=4200}
T[6022]={d="Travel to Corin's Crossing to the east and slaughter the Scourge that inhabit the town. Collect 7 pieces of Living Rot in under 10 minutes. Use the Mortar and Pestle to grind the Living Rot into Coagulated Rot.",en={11878},l=58,n="To Kill With Purpose",ob={i={{15448}}},r=178,rl=54,rs={15447},sn={11878},su=15454,x=6200}
T[6023]={d="Kill Huntsman Radley and Cavalier Durgen before returning to Kirsta Deepshadow in Western Plaguelands.",en={11610},l=57,n="Unfinished Business",nx=6025,ob={k={{11613},{11611}}},ps={6004},r=0,rl=50,sn={11610},x=6000}
T[6024]={d="Kill Infiltrator Hameya. Use his key on the Mound of Dirt behind the Undercroft.",eo={177675},l=60,n="Hameya's Plea",ob={i={{15767}}},r=0,rl=54,so={177667},x=6600}
T[6025]={d="Enter Hearthglen and find a high vantage point from which you can see the town and gauge the Scarlet Crusade's forces, then return to Kirsta Deepshadow in Western Plaguelands.",en={11610},l=58,n="Unfinished Business",ob={e={"Overlook Hearthglen from a high vantage point",{{1422,45.8,18.3}}}},ps={6023},r=0,rl=50,sf=2,sn={11610},tg=1,x=6200}
T[6026]={d="Smokey LaRue wants you to get 2 Thorium Bars, 1 Golden Rod, 8 Hi-Explosive Bombs, and 8 Unstable Triggers.",en={11033},l=58,n="That's Asking A Lot",nx=6041,ob={i={{12359},{11128},{10562},{10560}}},r=0,rl=54,sn={11033},x=6200}
T[6027]={d="Get the Book of the Ancients and return it to Azore Aldamort at the tower in Ethel Rethor.",en={11863},l=38,n="Book of the Ancients",ob={i={{15803}}},ps={5741},r=0,rl=30,sn={11863},su=15766,x=3550}
T[6028]={d="Deliver the Everlook Report to Argent Officer Pureheart at Chillwind Camp, Western Plaguelands.",en={10840},l=52,n="The Everlook Report",r=77,rl=50,sn={10431},su=15788,x=2550}
T[6029]={d="Deliver the Everlook Report to Argent Officer Garush at the Bulwark, Western Plaguelands.",en={10839},l=52,n="The Everlook Report",r=178,rl=50,sn={10431},su=15788,x=2550}
T[6030]={d="Deliver the book, \"Studies in Spirit Speaking\", to Duke Nicholas Zverenhoff at Light's Hope Chapel, Eastern Plaguelands.",en={11039},l=52,n="Duke Nicholas Zverenhoff",r=0,rl=50,sn={10431},su=15790,x=2550}
T[6031]={d="Bring 30 Runecloth to Meilosh in Timbermaw Hold.",en={11557},l=55,n="Runecloth",ob={i={{14047}}},r=0,rl=50,rp={576,3000},sn={11557},x=5650}
T[6032]={d="Bring 2 Mooncloth to Meilosh in Timbermaw Hold.",en={11557},l=55,n="Sacred Cloth",ob={i={{14342}}},r=0,rl=50,rp={576,3000},sk={197,280},sn={11557},x=5650}
T[6041]={d="Travel to Plaguewood, northwest of Light's Hope. Destroy 8 Scourge Structures by using Smokey's Special Compound at the Mark of Detonation planted inside each building. Smokey has had the Ziggurats and Slaughterhouses marked.",en={11033},l=58,n="When Smokey Sings, I Get Violent",ob={k={{12247,"Scourge Structures Destroyed"}}},ps={6026},r=0,rl=54,sn={11033},su=15736,tg=1,x=6200}
T[6042]={d="Slay 20 Noxious Plaguebats and 10 Monstrous Plaguebats. Return to Nathanos Blightcaller when you are finished.",en={11878},l=58,n="Un-Life's Little Annoyances",ob={k={{8601},{8602}}},r=178,rl=54,sn={11878},x=6200}
T[6061]={c=4,d="Use the Taming Rod to tame an Adult Plainstrider. Practice your skills, then return the Taming Rod to Yaw Sharpmane in Bloodhoof Village.",en={3065},l=10,n="Taming the Beast",nx=6087,ob={k={{2956}}},r=32,rl=10,sf=0,sn={3065},su=15914,x=840}
T[6062]={c=4,d="Use the Taming Rod to tame a Dire Mottled Boar. Practice your skills, then return the Taming Rod to Thotar in Razor Hill.",en={3171},l=10,n="Taming the Beast",nx=6083,ob={k={{3099}}},r=130,rl=10,sf=0,sn={3171},su=15917,x=840}
T[6063]={c=4,d="Use the Taming Rod to tame a Webwood Lurker. Practice your skills, then return the Taming Rod to Dazalar in Dolanaar.",en={3601},l=10,n="Taming the Beast",nx=6101,ob={k={{1998}}},r=8,rl=10,sf=0,sn={3601},su=15921,x=840}
T[6064]={c=4,d="Use the Taming Rod to tame a Large Crag Boar. Practice your skills, then return the Taming Rod to Grif Wildheart in Kharanos.",en={1231},l=10,n="Taming the Beast",nx=6084,ob={k={{1126}}},r=4,rl=10,sf=0,sn={1231},su=15911,x=840}
T[6065]={c=4,d="Speak with Yaw Sharpmane in Bloodhoof Village.",en={3065},ex={6066,6067},l=10,n="The Hunter's Path",nx=6061,r=32,rl=10,sn={3038},x=85}
T[6066]={c=4,d="Speak with Yaw Sharpmane in Bloodhoof Village.",en={3065},ex={6065,6067},l=10,n="The Hunter's Path",nx=6061,r=32,rl=10,sn={3407},x=85}
T[6067]={c=4,d="Speak with Yaw Sharpmane in Bloodhoof Village.",en={3065},ex={6065,6066},l=10,n="The Hunter's Path",nx=6061,r=32,rl=10,sn={3171},x=85}
T[6068]={c=4,d="Speak with Thotar at Razor Hill.",en={3171},ex={6069,6070},l=10,n="The Hunter's Path",nx=6062,r=130,rl=10,sn={3407},x=85}
T[6069]={c=4,d="Speak with Thotar at Razor Hill.",en={3171},ex={6068,6070},l=10,n="The Hunter's Path",nx=6062,r=130,rl=10,sn={11814},x=85}
T[6070]={c=4,d="Speak with Thotar at Razor Hill.",en={3171},ex={6068,6069},l=10,n="The Hunter's Path",nx=6062,r=130,rl=10,sn={3038},x=85}
T[6071]={c=4,d="Speak with Dazalar in Dolanaar.",en={3601},ex={6072,6073,6721,6722},l=10,n="The Hunter's Path",nx=6063,r=8,rl=10,sn={4146},x=85}
T[6073]={c=4,d="Speak with Dazalar in Dolanaar.",en={3601},ex={6071,6072,6721,6722},l=10,n="The Hunter's Path",nx=6063,r=8,rl=10,sn={5515},x=85}
T[6074]={c=4,d="Speak with Grif Wildheart in Kharanos.",en={1231},ex={6075,6076},l=10,n="The Hunter's Path",nx=6064,r=4,rl=10,sn={5116},x=85}
T[6075]={c=4,d="Speak with Grif Wildheart in Kharanos.",en={1231},ex={6074,6076},l=10,n="The Hunter's Path",nx=6064,r=4,rl=10,sn={11807},x=85}
T[6076]={c=4,d="Speak with Grif Wildheart in Kharanos.",en={1231},ex={6074,6075},l=10,n="The Hunter's Path",nx=6064,r=4,rl=10,sn={5515},x=85}
T[6081]={c=4,d="Speak with Ormak Grimshot in Orgrimmar.",en={3352},l=10,n="Training the Beast",ps={6082},r=130,rl=10,sn={3171},x=420}
T[6082]={c=4,d="Use the Taming Rod to tame an Armored Scorpid. Practice your skills, then return to Thotar at Razor Hill.",en={3171},l=10,n="Taming the Beast",nx=6081,ob={k={{3126}}},ps={6083},r=130,rl=10,sf=0,sn={3171},su=15920,x=840}
T[6083]={c=4,d="Use the Taming Rod to tame a Surf Crawler. Practice your skills, then return the Taming Rod to Thotar at Razor Hill.",en={3171},l=10,n="Taming the Beast",nx=6082,ob={k={{3107}}},ps={6062},r=130,rl=10,sf=0,sn={3171},su=15919,x=840}
T[6084]={c=4,d="Use the Taming Rod to tame a Snow Leopard. Practice your skills, then return to Grif Wildheart in Kharanos.",en={1231},l=10,n="Taming the Beast",nx=6085,ob={k={{1201}}},ps={6064},r=4,rl=10,sf=0,sn={1231},su=15913,x=840}
T[6085]={c=4,d="Use the Taming Rod to tame an Ice Claw Bear. Practice your skills, then return the Taming Rod to Grif Wildheart in Kharanos.",en={1231},l=10,n="Taming the Beast",nx=6086,ob={k={{1196}}},ps={6084},r=4,rl=10,sf=0,sn={1231},su=15908,x=840}
T[6086]={c=4,d="Speak with Belia Thundergranite in Ironforge.",en={10090},l=10,n="Training the Beast",ps={6085},r=4,rl=10,sn={1231},x=420}
T[6087]={c=4,d="Use the Taming Rod to tame a Prairie Stalker. Practice your skills, then return the Taming Rod to Yaw Sharpmane in Bloodhoof Village.",en={3065},l=10,n="Taming the Beast",nx=6088,ob={k={{2959}}},ps={6061},r=32,rl=10,sf=0,sn={3065},su=15915,x=840}
T[6088]={c=4,d="Use the Taming Rod to tame a Swoop. Practice your skills, then return the Taming Rod to Yaw Sharpmane in Bloodhoof Village.",en={3065},l=10,n="Taming the Beast",nx=6089,ob={k={{2970}}},ps={6087},r=32,rl=10,sf=0,sn={3065},su=15916,x=840}
T[6089]={c=4,d="Speak with Holt Thunderhorn on Hunter Rise in Thunder Bluff.",en={3039},l=10,n="Training the Beast",ps={6088},r=32,rl=10,sn={3065},x=420}
T[6101]={c=4,d="Use the Taming Rod to tame a Nightsaber Stalker. Practice your skills, then return the Taming Rod to Dazalar in Dolanaar.",en={3601},l=10,n="Taming the Beast",nx=6102,ob={k={{2043}}},ps={6063},r=8,rl=10,sf=0,sn={3601},su=15922,x=840}
T[6102]={c=4,d="Use the Taming Rod to tame a Strigid Screecher. Practice your skills, then return the Taming Rod to Dazalar in Dolanaar.",en={3601},l=10,n="Taming the Beast",nx=6103,ob={k={{1996}}},ps={6101},r=8,rl=10,sf=0,sn={3601},su=15923,x=840}
T[6103]={c=4,d="Speak to Jocaste in the Cenarion Enclave, in Darnassus.",en={4146},l=10,n="Training the Beast",ps={6102},r=8,rl=10,sn={3601},x=420}
T[6121]={c=1024,d="Travel to Moonglade and speak with Dendrite Starblaze in the village of Nighthaven.",en={11802},l=14,n="Lessons Anew",nx=6122,r=8,rl=14,sn={4217},x=100}
T[6122]={c=1024,d="Use the Empty Cliffspring Falls Sampler to draw a sample of water from the mouth of the cave by the falls.",en={3702},l=14,n="The Principal Source",nx=6123,ob={i={{15845}}},ps={6121},r=8,rl=14,sn={11802},su=15844,x=740}
T[6123]={c=1024,d="Bring 5 Earthroot and 12 Lunar Funguses to Alanndarian Nightsong in Auberdine so she may make a curative salve.",en={3702},l=14,n="Gathering the Cure",nx=6124,ob={i={{2449},{15851}}},ps={6122},r=8,rl=14,sn={3702},x=740}
T[6124]={c=1024,d="Use the Curative Animal Salve on 10 Sickly Deer that are located throughout Darkshore; doing so should cure them. Sickly Deer have been reported starting south of the Cliffspring River to the north of Auberdine and extending all the way into southern Darkshore where the edge of Ashenvale begins.",en={11802},l=14,n="Curing the Sick",nx=6125,ob={k={{12298}}},ps={6123},r=8,rl=14,sn={3702},su=15826,x=740}
T[6125]={c=1024,d="Return to Mathrengyl Bearwalker in the Cenarion Enclave, Darnassus.",en={4217},l=14,n="Power over Poison",ps={6124},r=8,rl=14,sn={11802},x=980}
T[6126]={c=1024,d="Travel to Moonglade and speak with Dendrite Starblaze in the village of Nighthaven.",en={11802},l=14,n="Lessons Anew",nx=6127,r=32,rl=14,sn={3033},x=100}
T[6127]={c=1024,d="Use the Empty Dreadmist Peak Sampler to draw a sample of water from a pool at the top of the peak.",en={3448},l=14,n="The Principal Source",nx=6128,ob={i={{15843}}},ps={6126},r=32,rl=14,sn={11802},su=15842,x=740}
T[6128]={c=1024,d="Bring 5 Earthroot and 5 Kodo Horns to Tonga Runetotem at the Crossroads so he may make a curative salve.",en={3448},l=14,n="Gathering the Cure",nx=6129,ob={i={{2449},{15852}}},ps={6127},r=32,rl=14,sn={3448},x=740}
T[6129]={c=1024,d="Use the Curative Animal Salve on 10 Sickly Gazelles that are located throughout the northern part of the Barrens; doing so should cure them. Sickly Gazelles have been reported north of the east-west road that runs through the Crossroads.",en={11802},l=14,n="Curing the Sick",nx=6130,ob={k={{12296}}},ps={6128},r=32,rl=14,sn={3448},su=15826,x=740}
T[6130]={c=1024,d="Return to Turak Runetotem on the Elder Rise, Thunder Bluff.",en={3033},l=14,n="Power over Poison",ps={6129},r=32,rl=14,sn={11802},x=980}
T[6132]={d="Escort Melizza Brimbuzzle, then speak with Hornizz Brimbuzzle at the Kodo Graveyard in Desolace.",en={6019},es=1,l=39,n="Get Me Out of Here!",ob={e={"Melizza Brimbuzzle escorted to safety",{{1443,40.2,61.6}}}},r=0,rl=34,sf=2,sn={12277},x=2250}
T[6133]={d="Travel to the northern borders of the Eastern Plaguelands and recover the Quel'Thalas Registry. The item is somewhere in the Quel'Lithien lodge.",en={11878},l=60,n="The Ranger Lord's Behest",ob={i={{15847}},k={{8565},{8564},{8563}}},r=178,rl=54,sn={11878},x=6600}
T[6134]={d="Bring 8 Ghost-o-plasms and the Crate of Ghost Magnets to Hornizz Brimbuzzle in Desolace.",en={6019},l=39,n="Ghost-o-plasm Round Up",ob={i={{15849}}},r=0,rl=34,sn={6019},su=15848,x=2250}
T[6135]={d="Find Duskwing and slay him. From the corpse, recover a Patch of Duskwing's Fur and return it to Nathanos Blightcaller.",en={11878},l=60,n="Duskwing, Oh How I Hate Thee...",ob={i={{15850}}},pg={6022,6042,6133},r=178,rl=56,sn={11878},tg=1,x=6600}
T[6136]={d="Find Borelgore in the northern wastes of Eastern Plaguelands and destroy him. Return to Nathanos Blightcaller when the mission is complete.",en={11878},l=60,n="The Corpulent One",ob={k={{11896}}},pg={6022,6042,6133},r=178,rl=56,sn={11878},tg=1,x=6600}
T[6141]={d="Speak with Brother Anton in Desolace.",en={1182},l=39,n="Brother Anton",nx=261,r=77,rl=34,sn={12336},x=300}
T[6142]={d="Find 10 pieces of Soft-shelled Clam Meat and bring it back to Mai'Lahii at Shadowprey Village.",en={12031},l=35,n="Clam Bait",ob={i={{15924}}},r=178,rl=31,rs={15874},sn={12031},x=2750}
T[6143]={d="Slay 7 Slitherblade Myrmidon, 7 Slitherblade Naga, and 5 Slitherblade Sorceresses, and then talk to Drulzegar at Shadowprey in Desolace.",en={12340},l=36,n="Other Fish to Fry",ob={k={{4714},{4711},{4712}}},r=178,rl=32,sn={12340},x=2800}
T[6144]={d="Travel to the Undercity and speak with Varimathras.",en={2425},l=60,n="The Call to Command",nx=6145,pg={6135,6136},r=178,rl=56,sn={11878},x=660}
T[6145]={d="Return to Eastern Plaguelands and track down the Crimson Courier. Kill the Courier and recover the Grand Crusader's Command.",en={11878},l=60,n="The Crimson Courier",nx=6146,ob={i={{15868}}},ps={6144},r=178,rl=56,sn={2425},tg=1,x=6600}
T[6146]={d="Travel to Tyr's Hand, southeast of the Marris Stead. Once there, take a bite of the Rotten Apple. While under the guise of the Scarlet Crusade, deliver the Grand Crusader's Command to Crusader Lord Valdelmar.",en={11898},l=60,n="Nathanos' Ruse",nx=6147,ob={i={{13852}}},ps={6145},r=178,rl=56,sn={11878},su=15876,tg=1,x=6600}
T[6147]={d="Return to Nathanos Blightcaller with the new information.",en={11878},l=60,n="Return to Nathanos",nx=6148,ps={6146},r=178,rl=56,sn={11898},tg=1,x=3300}
T[6148]={d="The Scarlet Crusade is on the move. Somewhere along the road from Tyr's Hand to Stratholme you will find the Oracle, Demetria, and her entourage. Hunt her down and slay her. Return to Nathanos Blightcaller should you succeed.",en={11878},l=60,n="The Scarlet Oracle, Demetria",ob={k={{12339}}},ps={6147},r=178,rl=56,sn={11878},tg=1,x=8300}
T[6161]={d="Find Rackmore's Silver Key. Find Rackmore's Golden Key. Find and open Rackmore's Chest.",eo={177786},l=36,n="Claim Rackmore's Treasure!",ob={i={{15878},{15881}}},r=0,rl=30,so={177787},x=2800}
T[6162]={d="Kill Overlord Ror and return his claw to Dreka'Sur at Bloodvenom Post in Felwood.",en={9620},l=51,n="A Husband's Last Battle",ob={i={{15879}}},r=178,rl=46,sn={9620},x=4900}
T[6163]={d="Travel to Stratholme and slay Ramstein the Gorger. Take his head as a souvenir for Nathanos.",en={11878},l=60,n="Ramstein",ob={i={{15880}}},pg={6135,6136},r=178,rl=56,sn={11878},tg=81,x=6600,z=2017}
T[6164]={d="Bring Augustus' Receipt Book to Augustus the Touched in Terrordale.",en={12384},l=55,n="Augustus' Receipt Book",ob={i={{15884}}},r=0,rl=50,sn={12384},x=1400}
T[6181]={d="Bring Lewis' Note to Thor the gryphon master.",en={523},l=10,n="A Swift Message",nx=6281,r=1,rl=10,sn={491},su=15998,x=210}
T[6182]={d="Speak with Mathias Shaw in Old Town Stormwind. He resides in the Barracks.",en={332},l=60,n="The First and the Last",nx=6183,r=77,rl=56,sn={1748},tg=1,x=660}
T[6183]={d="Speak with Mathias Shaw again if you wish to accept his task.",en={332},l=60,n="Honor the Dead",nx=6184,ps={6182},r=77,rl=56,sn={332},tg=1,x=660}
T[6184]={d="Travel to Chillwind Camp in the Western Plaguelands and meet up with your contact, Flint Shadowmore.",en={12425},l=60,n="Flint Shadowmore",nx=6185,ps={6183},r=77,rl=56,sn={332},tg=1,x=4950}
T[6185]={d="Scour the Eastern Plaguelands for clues as to the \"Blightcaller\" and the missing SI:7 agents. If you find any SI:7 Insignias, return them to Flint Shadowmore at Chillwind Camp.",en={12425},l=60,n="The Eastern Plagues",nx=6186,ob={c={{{11878}}},e={"The Blightcaller Uncovered",{{1423,22.5,63.6}}},i={{16003},{16001},{16002}}},ps={6184},r=77,rl=56,sf=2,sn={12425},tg=1,x=8300}
T[6186]={d="Return to Stormwind and inform Highlord Bolvar Fordragon of the fate of Nathanos Marris.",en={1748},l=60,n="The Blightcaller Cometh",nx=6187,ps={6185},r=77,rl=56,sn={12425},tg=1,x=6600}
T[6187]={d="Assemble an army and travel to the Eastern Plaguelands. Launch a full assault on Nathanos Blightcaller and any Horde filth that may attempt to protect him.",en={1748},l=60,n="Order Must Be Restored",ob={k={{11878}}},ps={6186},r=77,rl=56,sn={1748},tg=62,x=9950}
T[6261]={d="Bring Osric's Crate to Dungar Longdrink the gryphon master.",en={352},l=10,n="Dungar Longdrink",nx=6285,ps={6281},r=1,rl=10,sn={1323},su=16115,x=210}
T[6281]={d="Buy a gryphon ride from the gryphon master Thor, then bring Lewis' Note to Osric Strang, in the shop Limited Immunity, in the Old Town of Stormwind.",en={1323},l=10,n="Continue to Stormwind",nx=6261,ps={6181},r=1,rl=10,sn={523},su=15998,x=420}
T[6282]={d="Maggran Earthbinder in Sun Rock Retreat wants you to slay 7 Bloodfury Harpies, 7 Bloodfury Ambushers, 7 Bloodfury Slayers and 7 Bloodfury Roguefeathers.",en={11860},l=26,n="Harpies Threaten",nx=6283,ob={k={{4022},{4025},{4024},{4023}}},r=178,rl=18,sn={11860},x=2100}
T[6283]={d="Maggran at Sun Rock Retreat wishes you to slay Bloodfury Ripper and bring her remains as proof of your deed.",en={11860},l=26,n="Bloodfury Bloodline",ob={i={{16190}}},ps={6282},r=178,rl=18,sn={11860},tg=1,x=2100}
T[6284]={d="Kill Besseleth and bring Besseleth's Fang to Maggran at Sun Rock Retreat.",en={11860},l=21,n="Arachnophobia",ob={i={{16192}}},r=178,rl=15,so={177904},tg=1,x=1650}
T[6285]={d="Buy a gryphon ride to Sentinel Hill from the gryphon master Dungar Longdrink, then take Osric's Crate to Lewis at Sentinel Hill.",en={491},l=10,n="Return to Lewis",ps={6261},r=1,rl=10,sn={352},su=16115,x=1050}
T[6301]={d="Tammra Windfield at Sun Rock Retreat wants you to gather 10 Gaea Seeds.",en={11864},l=23,n="Cycle of Rebirth",nx=6381,ob={i={{16205}}},r=178,rl=17,sn={11864},x=1400}
T[6321]={d="Bring Podrig's Order to Karos Razok.",en={2226},l=10,n="Supplying the Sepulcher",nx=6323,r=16,rl=10,sn={6389},su=16209,x=210}
T[6322]={d="Bring Gordon's Crate to Michael Garrett.",en={4551},l=10,n="Michael Garrett",nx=6324,ps={6323},r=16,rl=10,sn={4556},su=16210,x=210}
T[6323]={d="Buy a bat ride to the Undercity from the bat master Karos Razok, then take Podrig's Order to Gordon Wendham in the Undercity.",en={4556},l=10,n="Ride to the Undercity",nx=6322,ps={6321},r=16,rl=10,sn={2226},su=16209,x=420}
T[6324]={d="Buy a bat ride to the Sepulcher from the bat master Michael Garrett, then bring Gordon's Crate to Deathguard Podrig in the Sepulcher.",en={6389},l=10,n="Return to Podrig",ps={6322},r=16,rl=10,sn={4551},su=16210,x=1050}
T[6341]={d="Bring Nessa's Collection to Vesprystus.",en={3838},l=10,n="The Bounty of Teldrassil",nx=6342,r=8,rl=10,sn={10118},su=16262,x=210}
T[6342]={d="Ride a hippogryph to Auberdine from the hippogryph master Vesprystus, then bring Nessa's Collection to Laird.",en={4200},l=10,n="Flight to Auberdine",nx=6343,ps={6341},r=8,rl=10,sn={3838},su=16262,x=420}
T[6343]={d="Bring Laird's Response to Nessa Shadowsong.",en={10118},l=10,n="Return to Nessa",ps={6342},r=8,rl=10,sn={4200},su=16263,x=1050}
T[6344]={d="Speak with Nessa Shadowsong.",en={10118},l=10,n="Nessa Shadowsong",nx=6341,r=8,rl=10,sn={4241},x=210}
T[6361]={d="Bring the Bundle of Hides to the wind rider master Devrak in the Crossroads.",en={3615},l=10,n="A Bundle of Hides",nx=6362,r=32,rl=10,sn={3483},su=16282,x=210}
T[6362]={d="Buy a wind rider to Thunder Bluff from the wind rider master Devrak, then bring the Bundle of Hides to Ahanu in Thunder Bluff.",en={8359},l=10,n="Ride to Thunder Bluff",nx=6363,ps={6361},r=32,rl=10,sn={3615},su=16282,x=420}
T[6363]={d="Bring Ahanu's Leather Goods to Tal in Thunder Bluff.",en={2995},l=10,n="Tal the Wind Rider Master",nx=6364,ps={6362},r=32,rl=10,sn={8359},su=16283,x=210}
T[6364]={d="Buy a wind rider to the Crossroads from the wind rider master Tal, then bring Ahanu's Leather Goods to Jahan Hawkwing.",en={3483},l=10,n="Return to Jahan",ps={6363},r=32,rl=10,sn={2995},su=16283,x=1050}
T[6365]={d="Bring Zargh's Meats to Devrak in the Crossroads.",en={3615},l=10,n="Meats to Orgrimmar",nx=6384,r=130,rl=10,sn={3489},su=16306,x=210}
T[6381]={d="Plant 10 Gaea Seeds in Gaea Dirt Mounds, and then return the remaining Enchanted Gaea Seeds to Tammra at Sun Rock Retreat.",en={11864},l=25,n="New Life",ob={o={{177929,"Gaea seed planted"}}},ps={6301},r=178,rl=17,sn={11864},su=16208,x=2000}
T[6382]={d="Speak with Senani Thunderheart at Splintertree Post, Ashenvale.",en={12696},ex={235,742},l=20,n="The Ashenvale Hunt",ps={882},r=178,rl=20,sn={3387},x=390}
T[6383]={en={12696},l=20,n="The Ashenvale Hunt",r=178,rl=20,sn={12696}}
T[6384]={d="Buy a wind rider to Orgrimmar from the wind rider master Devrak, then bring Zargh's Meats to Gryshka in Orgrimmar.",en={6929},l=10,n="Ride to Orgrimmar",nx=6385,ps={6365},r=130,rl=10,sn={3615},su=16306,x=420}
T[6385]={d="Bring Gryshka's Letter to Doras in Orgrimmar.",en={3310},l=10,n="Doras the Wind Rider Master",nx=6386,ps={6384},r=130,rl=10,sn={6929},su=16307,x=210}
T[6386]={d="Buy a wind rider to the Crossroads from the wind rider master Doras, then bring Gryshka's Letter to Zargh at the Crossroads.",en={3489},l=10,n="Return to the Crossroads.",ps={6385},r=130,rl=10,sn={3310},su=16307,x=1050}
T[6387]={d="Bring Brock's List to Thorgrum Borrelson in Thelsamar.",en={1572},l=10,n="Honor Students",nx=6391,r=68,rl=10,sn={1681},su=16310,x=210}
T[6388]={d="Bring the Honorary Picks to Gryth Thurden in Ironforge.",en={1573},l=10,n="Gryth Thurden",nx=6392,ps={6391},r=68,rl=10,sn={4256},su=16311,x=210}
T[6389]={d="Release the Plagueland Termites in the Northridge Lumber Mill, then return with the Barrel of Plagueland Termites to Nathaniel Dumah at Chillwind Camp in Western Plaguelands.",en={11616},l=55,n="A Plague Upon Thee",ps={5904},r=77,rl=48,so={177491},su=15044,x=5650}
T[6390]={d="Release the Plagueland Termites in the Northridge Lumber Mill, then return with the Barrel of Plagueland Termites to Mickey Levine at the Bulwark in Tirisfal Glades.",en={11615},l=55,n="A Plague Upon Thee",ps={5902},r=178,rl=48,so={177491},su=15044,x=5650}
T[6391]={d="Buy a gryphon to Ironforge from the gryphon master Thorgrum Borrelson, then bring Brock's List to Golnir Bouldertoe in Ironforge.",en={4256},l=10,n="Ride to Ironforge",nx=6388,ps={6387},r=68,rl=10,sn={1572},su=16310,x=420}
T[6392]={d="Buy a gryphon to Thelsamar from the gryphon master Gryth Thurden, then bring the Honorary Picks to Brock Stoneseeker in Thelsamar.",en={1681},l=10,n="Return to Brock",ps={6388},r=68,rl=10,sn={1573},su=16311,x=1050}
T[6393]={d="Bring 10 Incendrites to Tsunaman at Sun Rock Retreat.",en={11862},l=25,n="Elemental War",ob={i={{16312}}},r=178,rl=19,sn={11862},x=2000}
T[6394]={d="Bring Thazz'ril's Pick to Foreman Thazz'ril.",en={11378},l=4,n="Thazz'ril's Pick",ob={i={{16332}}},ps={5441},r=178,rl=3,sn={11378},x=445}
T[6395]={d="Bring Samuel Fipps' Remains to Marla's Grave, then return to Novice Elreth.",en={1661},l=5,n="Marla's Last Wish",ob={o={{178090,"Samuel's Remains Buried"}}},ps={376},r=178,rl=3,rs={16333},sn={1661},x=450}
T[6401]={d="Tell Tammra Windfield in Sun Rock Retreat the good news.",en={11864},l=18,n="Kaya's Alive",ps={6523},r=178,rl=12,sn={11857},x=1000}
T[6402]={d="Travel to Stormwind City and venture to the city gates. Speak with Squire Rowe so that he may let Marshal Windsor know that you have arrived.",en={12580},l=60,n="Stormwind Rendezvous",nx=6403,ps={4322},r=77,rl=50,sn={9560},tg=62,x=660}
T[6403]={d="Follow Reginald Windsor through Stormwind. Protect him from harm!",en={1748},l=60,n="The Great Masquerade",nx=6501,ob={e={"Reginald's March",{{1453,79.7,38.8}}}},ps={6402},r=77,rl=50,sf=2,sn={12580},tg=62,x=9950}
T[6421]={d="Explore deep into the cave at Boulderslide Ravine and bring back 10 Resonite Crystals for Mor'rogal at Sun Rock Retreat to investigate.",en={11861},l=18,n="Boulderslide Ravine",nx=6481,ob={e={"Investigate Cave in Boulderslide Ravine",{{1442,58.2,89.5}}},i={{16581}}},r=178,rl=14,sf=2,sn={11861},x=1350}
T[6441]={d="Collect 16 Satyr Horns for Pixel in Splintertree Post.",en={12724},l=26,n="Satyr Horns",ob={i={{5481}}},r=178,rl=21,sn={12724},x=2100}
T[6442]={d="Bring 20 Wrathtail Heads to Marukai along the Zoram Strand.",en={12719},l=19,n="Naga at the Zoram Strand",ob={i={{5490}}},r=178,rl=14,sn={12719},x=1450}
T[6461]={d="Xen'zilla at Malaka'Jin needs you to kill 10 Deepmoss Creepers and 7 Deepmoss Venomspitters.",en={12816},l=19,n="Blood Feeders",ob={k={{4005},{4007}}},r=178,rl=13,sn={12816},x=1450}
T[6462]={d="Bring 8 Troll Charms to Mitsuwa at the Zoram'gar Outpost.",en={12721},l=24,n="Troll Charm",ob={i={{16602}}},r=178,rl=19,sn={12721},x=1950}
T[6481]={d="Open the Resonite cask with the Enchanted Resonite Crystal, and then slay Goggeroc. Return to Mor'rogal with the news and Enchanted Resonite Crystal.",en={11861},l=20,n="Earthen Arise",ob={k={{11920}}},ps={6421},r=178,rl=14,sn={11861},su=16603,tg=1,x=1550}
T[6482]={d="Escort Ruul, then speak with Yama Snowhoof in Splintertree Post.",en={12837},es=1,l=24,n="Freedom to Ruul",ob={e={"Escort Ruul from the Thistlefurs.",{{1440,38.5,37.3}}}},r=178,rl=19,sf=2,sn={12818},x=2400}
T[6501]={d="You must search the world for a being capable of restoring the power to the Fragment of the Dragon's Eye. The only information you possess about such a being is that they exist.",en={10929},l=60,n="The Dragon's Eye",nx=6502,ps={6403},r=77,rl=50,sn={1748},su=16662,tg=62,x=6600}
T[6502]={d="You must retrieve the Blood of the Black Dragon Champion from General Drakkisath. Drakkisath can be found in his throne room behind the Halls of Ascension in Blackrock Spire.",en={10929},l=60,n="Drakefire Amulet",ob={i={{16663}}},ps={6501},r=77,rl=50,sn={10929},tg=62,x=8300,z=1583}
T[6503]={d="Kill 9 Ashenvale Outrunners, then return to Kuray'bin at Splintertree Outpost.",en={12867},l=24,n="Ashenvale Outrunners",ob={k={{12856}}},r=178,rl=19,sn={12867},x=1950}
T[6504]={d="Find the 12 missing pages of the Shredder Operating Manual, and put them together to form Chapters 1, 2, and 3. Return the pages to Gurda Ragescar near Splintertree Post.",en={12718},l=30,n="The Lost Pages",ob={i={{16642},{16643},{16644}}},r=178,rl=23,rs={16645,16646,16647,16648,16649,16650,16651,16652,16653,16654,16655,16656},sn={12718},x=3650}
T[6521]={d="Bring Ambassador Malcin's Head to Varimathras in the Undercity.",en={2425},l=36,n="An Unholy Alliance",ob={i={{17009}}},ps={6522},r=178,rl=28,sn={2425},tg=81,x=4200,z=722}
T[6522]={d="Take the Small Scroll to Varimathras in the Undercity.",en={2425},l=36,n="An Unholy Alliance",nx=6521,r=178,rl=28,si={17008},su=17008,tg=81,x=3500,z=722}
T[6523]={d="Escort Kaya Flathoof to Camp Aparaje, and then return to Makaba Flathoof near the southeastern edge of Stonetalon.",en={11857},es=1,l=18,n="Protect Kaya",nx=6401,ob={e={"Kaya Escorted to Camp Aparaje",{{1442,77.1,90.9}}}},r=178,rl=12,sf=2,sn={11856},x=1350}
T[6541]={d="Report to Kadrak at the watch tower in northern Barrens.",en={8582},l=19,n="Report to Kadrak",nx=6543,r=178,rl=17,sn={3429},x=145}
T[6542]={d="Report to Kadrak at the watch tower in northern Barrens.",en={8582},l=19,n="Report to Kadrak",nx=6543,r=178,rl=17,sn={11821},x=145}
T[6543]={d="Open the Bundle of Reports. Take the Warsong Reports to the Warsong Scout, Warsong Runner, and Warsong Outrider. Bring back the updates they give you to Kadrak at the northern watch tower in the barrens.",en={8582},l=19,n="The Warsong Reports",ob={i={{16764},{16763},{16765}}},r=178,rl=17,rs={16746},sn={8582},su=16783,x=1800}
T[6544]={d="Escort Torek on his attack against Silverwing Outpost and Duriel Moonfire, then report to Ertog Ragetusk at Splintertree Post.",en={12877},es=1,l=24,n="Torek's Assault",ob={e={"Take Silverwing Outpost.",{{1440,64.7,75.4}}}},r=178,rl=20,sf=2,sn={12858},x=2400}
T[6545]={en={12863},l=19,n="Warsong Runner Update",ob={i={{16746}}},pa=6543,r=178,rl=17,sf=1,sn={12863}}
T[6546]={en={12864},l=25,n="Warsong Outrider Update",ob={i={{16746}}},pa=6543,r=178,rl=17,sf=1,sn={12864}}
T[6547]={en={12862},l=21,n="Warsong Scout Update",ob={i={{16746}}},pa=6543,r=178,rl=17,sf=1,sn={12862}}
T[6548]={d="Kill 8 Grimtotem Ruffians and 6 Grimtotem Mercenaries, and then return to Makaba Flathoof near the southeastern edge of Stonetalon.",en={11857},l=18,n="Avenge My Village",nx=6629,ob={k={{11910},{11911}}},r=178,rl=12,sn={11857},x=1350}
T[6561]={d="Bring the head of Twilight Lord Kelris to Bashana Runetotem in Thunder Bluff.",en={9087},l=27,n="Blackfathom Villainy",ob={i={{5881}}},r=178,rl=18,sn={4787},tg=81,x=1650,z=719}
T[6562]={d="Speak to Je'neu Sancrea in Ashenvale.",en={12736},l=22,n="Trouble in the Deeps",nx=6563,r=178,rl=17,sn={11862},tg=81,x=435,z=719}
T[6563]={d="Bring 20 Sapphires of Aku'Mai to Je'neu Sancrea in Ashenvale.",en={12736},l=22,n="The Essence of Aku'Mai",ob={i={{16784}}},r=178,rl=17,sn={12736},tg=81,x=1750,z=719}
T[6564]={d="Bring the Damp Note to Je'neu Sancrea in Ashenvale.",en={12736},l=22,n="Allegiance to the Old Gods",nx=6565,ps={6562},r=178,rl=17,si={16790},su=16790,tg=81,x=1750,z=719}
T[6565]={d="Kill Lorgus Jett in Blackfathom Deeps and then return to Je'neu Sancrea in Ashenvale.",en={12736},l=26,n="Allegiance to the Old Gods",ob={k={{12902}}},ps={6564},r=178,rl=17,sn={12736},tg=81,x=2650,z=719}
T[6566]={d="Listen to Thrall.",en={4949},l=60,n="What the Wind Carries",nx=6567,ob={e={"Thrall's Tale",{{1454,31.8,37.8}}}},ps={4974},r=178,rl=55,sf=2,sn={4949},x=660}
T[6567]={d="Seek out Rexxar. The Warchief has instructed you as to his whereabouts. Search the paths of Desolace, between the Stonetalon Mountains and Feralas.",en={10182},l=60,n="The Champion of the Horde",nx=6568,ps={6566},r=178,rl=55,sn={4949},x=3300}
T[6568]={d="Deliver Rexxar's Letter to Myranda the Hag in the Western Plaguelands.",en={11872},l=60,n="The Testament of Rexxar",nx=6569,ps={6567},r=178,rl=55,sn={10182},su=16785,x=4950}
T[6569]={d="Travel to Blackrock Spire and collect 20 Black Dragonspawn Eyes. Return to Myranda the Hag when the task is complete.",en={11872},l=60,n="Oculus Illusions",nx=6570,ob={i={{16786}}},ps={6568},r=178,rl=55,sn={11872},tg=62,x=6600,z=1583}
T[6570]={d="Travel to the Wyrmbog in Dustwallow Marsh and seek out Emberstrife's Den. Once inside, wear the Amulet of Draconic Subversion and speak with Emberstrife.",en={10321},l=60,n="Emberstrife",ps={6569},r=178,rl=55,sn={11872},su=16787,tg=1,x=4950}
T[6571]={d="Collect the Warsong Supplies: Warsong Saw Blades, Logging Rope, Warsong Oil, and the Warsong Axe Shipment for Locke Okarr in Splintertree Post.",en={11820},l=27,n="Warsong Supplies",ob={i={{16742},{16745},{16744},{16743}}},r=178,rl=22,sn={11820},x=2750}
T[6581]={en={12724},l=27,n="Warsong Saw Blades",ob={i={{4369}}},pa=6571,r=178,rl=22,sf=1,sn={12724}}
T[6582]={d="You must find the blue dragonflight drake champion, Scryer, and slay him. Pry his skull from his corpse and return it to Emberstrife.",en={10321},l=60,n="The Test of Skulls, Scryer",ob={i={{16869}}},ps={6570},r=178,rl=55,sn={10321},tg=62,x=6600}
T[6583]={d="Destroy the drake champion of the Green Flight, Somnus. Take his skull and return it to Emberstrife.",en={10321},l=60,n="The Test of Skulls, Somnus",ob={i={{16870}}},ps={6570},r=178,rl=55,sn={10321},tg=62,x=6600}
T[6584]={d="Guarding the Caverns of Time in the Tanaris Desert is Chronalis, child of Nozdormu. Destroy him and return his skull to Emberstrife.",en={10321},l=60,n="The Test of Skulls, Chronalis",ob={i={{16871}}},ps={6570},r=178,rl=55,sn={10321},tg=62,x=6600}
T[6585]={d="Travel to Grim Batol and track down Axtroz, drake champion of the Red Flight. Destroy him and take his skull. Return the skull to Emberstrife.",en={10321},l=60,n="The Test of Skulls, Axtroz",nx=6601,ob={i={{16872}}},pg={6582,6583,6584},r=178,rl=55,sn={10321},tg=62,x=6600}
T[6601]={d="It would appear as if the charade is over. You know that the Amulet of Draconic Subversion that Myranda the Hag created for you will not function inside Blackrock Spire. Perhaps you should find Rexxar and explain your predicament. Show him the Dull Drakefire Amulet. Hopefully he will know what to do next.",en={10182},l=60,n="Ascension...",nx=6602,ps={6585},r=178,rl=55,sn={10321},su=16888,x=4950}
T[6602]={d="Travel to Blackrock Spire and slay General Drakkisath. Gather his blood and return it to Rexxar.",en={10182},l=60,n="Blood of the Black Dragon Champion",ob={i={{16663}}},ps={6601},r=178,rl=55,sn={10182},tg=62,x=9950,z=1583}
T[6603]={d="Find Donova Snowden near the hot springs in Winterspring.",en={9298},l=56,n="Trouble in Winterspring!",nx=5082,r=0,rl=52,sn={11754},x=580}
T[6604]={d="Speak with Jaron Stoneshaper at Starfall Village.",en={10301},l=59,n="Enraged Wildkin",nx=4861,r=77,rl=53,sn={11755},x=640}
T[6605]={d="Speak with Winna Hazzard in Felwood.",en={9996},l=54,n="A Strange One",nx=4505,r=178,rl=49,sn={11755},x=540}
T[6607]={d="Nat Pagle wants you to catch the following fish:",en={12919},l=45,n="Nat Pagle, Angler Extreme",ob={i={{16967},{16970},{16968},{16969}}},r=0,rl=35,sk={356,225},sn={12919},x=3900}
T[6608]={d="You think Lumak is trying to tell you that he can no longer help you improve your fishing skill. You may want to try to find his friend, Nat Pagle, a human fishing off one of the islands south of Theramore (at least that's what you think Lumak said).",en={12919},l=45,n="You Too Good.",nx=6607,r=178,rl=35,sk={356,225},sn={3332},x=970}
T[6609]={d="Travel to Kalimdor, to the coastal city of Theramore. From there you must search for an island, south of the main town. Nat Pagle awaits your arrival!",en={12919},l=45,n="I Got Nothin' Left!",nx=6607,r=77,rl=35,sk={356,225},sn={5161},x=970}
T[6610]={d="Dirge Quikcleave wants you to get the following items:",en={8125},l=45,n="Clamlette Surprise",ob={i={{12207},{7974},{8932}}},r=0,rl=35,sk={185,225},sn={8125},x=3900}
T[6611]={d="Travel to Gadgetzan in the Tanaris desert and speak with Dirge Quikcleave about advancing your cooking career.",en={8125},l=45,n="To Gadgetzan You Go!",nx=6610,r=178,rl=35,sk={185,225},sn={3399},x=970}
T[6612]={d="Travel to Gadgetzan in the Tanaris desert and speak with Dirge Quikcleave about advancing your cooking career.",en={8125},l=45,n="I Know A Guy...",nx=6610,r=77,rl=35,sk={185,225},sn={5159},x=970}
T[6621]={d="Place Karang's Banner on the Foulweald Totem Mound. Do not let the furbolgs destroy the banner. Defeat Chief Murgut and bring Murgut's Totem to Karang Amakkar at Zoram'gar.",en={12757},l=26,n="King of the Foulweald",ob={i={{16976}}},ps={216},r=178,rl=21,sn={12757},su=16972,x=2650}
T[6622]={d="Save patients by using Triage Bandages to tend to their wounds. You must save 15 patients before 6 of them die from their injuries.",en={12920},l=45,n="Triage",ob={e={"15 Patients Saved!",{{1445,67.8,49.1}}}},r=178,rl=35,sf=2,sk={129,225},sn={12920},su=16991,x=3900}
T[6623]={d="Travel to Hammerfall in the Arathi Highlands and speak with Doctor Gregory Victor about joining the ranks of Horde Trauma.",en={12920},l=45,n="Horde Trauma",nx=6622,r=178,rl=35,sk={129,225},sn={3373},x=970}
T[6624]={d="Save patients by using Triage Bandages to tend to their wounds. You must save 15 patients before 6 of them die from their injuries.",en={12939},l=45,n="Triage",ob={e={"15 Patients Saved!",{{1445,67.8,49.1}}}},r=77,rl=35,sf=2,sk={129,225},sn={12939},su=16991,x=3900}
T[6625]={d="Travel to Theramore in the Dustwallow Marsh and speak with Doctor Gustaf VanHowzen about joining the ranks of Alliance Trauma.",en={12939},l=45,n="Alliance Trauma",nx=6624,r=77,rl=35,sk={129,225},sn={5150},x=970}
T[6626]={d="Kill 8 Razorfen Battleguard, 8 Razorfen Thornweavers, and 8 Death's Head Cultists and return to Myriam Moonsinger near the entrance to Razorfen Downs.",en={12866},l=35,n="A Host of Evil",ob={k={{7873},{7874},{7872}}},r=0,rl=28,sn={12866},tg=81,x=3450,z=722}
T[6627]={d="Answer Braug Dimspirit's question successfully and then speak to him again. He will remain in Stonetalon Mountains when you are ready.",en={4489},l=30,n="Test of Lore",nx=1159,ob={e={"Answer Braug Dimspirit's question correctly",{{1442,78.8,45.6}}}},ps={1154},r=178,rl=25,sf=2,sn={4489},x=245}
T[6628]={d="Answer Parqual Fintallas' question successfully and then speak to him again. He will remain in the Undercity until you are ready.",en={4488},l=30,n="Test of Lore",nx=1394,ob={e={"Answer Parqual Fintallas' question correctly",{{1458,57.7,65.2}}}},ps={1160},r=178,rl=25,sf=2,sn={4488},x=245}
T[6629]={d="Kill Grundig Darkcloud and 6 Grimtotem Brutes, and return to Makaba Flathoof near the southeastern edge of Stonetalon.",en={11857},l=18,n="Kill Grundig Darkcloud",ob={k={{11858},{11912}}},ps={6548},r=178,rl=12,sn={11857},x=1350}
T[6641]={d="Keep Muglash safe as he travels to the brazier. Help him by putting the brazier out, then protect him as you fight against the Naga.",en={12863},l=23,n="Vorsha the Lasher",ob={e={"Defeat Vorsha the Lasher",{{1440,9.6,27.6}}}},r=178,rl=20,sf=2,sn={12717},x=2300}
T[6642]={en={12944},l=60,n="Favor Amongst the Brotherhood, Dark Iron Ore",ob={i={{11370}}},r=0,rl=60,rp={59,1},sf=1,sn={12944},tg=81}
T[6643]={en={12944},l=60,n="Favor Amongst the Brotherhood, Fiery Core",ob={i={{17010}}},r=0,rl=60,rp={59,1},sf=1,sn={12944},tg=81}
T[6644]={en={12944},l=60,n="Favor Amongst the Brotherhood, Lava Core",ob={i={{17011}}},r=0,rl=60,rp={59,1},sf=1,sn={12944},tg=81}
T[6645]={en={12944},l=60,n="Favor Amongst the Brotherhood, Core Leather",ob={i={{17012}}},r=0,rl=60,rp={59,1},sf=1,sn={12944},tg=81}
T[6646]={en={12944},l=60,n="Favor Amongst the Brotherhood, Blood of the Mountain",ob={i={{11382}}},r=0,rl=60,rp={59,1},sf=1,sn={12944},tg=81}
T[6661]={d="Capture 5 Deeprun Rats by using the Rat Catcher's Flute. Lead the rats back to Monty. Don't forget to turn in the flute when you're finished.",en={12997},l=12,n="Deeprun Rat Roundup",nx=6662,ob={k={{13016}}},r=77,rl=10,sn={12997},su=17117,x=910}
T[6662]={d="Take the Carton of Mystery Meat to Nipsy at the Stormwind Deeprun Tram Depot.",en={13018},l=12,n="Me Brother, Nipsy",ps={6661},r=77,rl=10,sn={12997},su=17118,x=90}
T[6681]={c=8,d="Take the Seal of Ravenholdt to Fahrad at Ravenholdt Manor, hidden away in the hills of Hillsbrad.",en={6707},l=24,n="The Manor, Ravenholdt",nx=6701,ob={k={{13936,"Rite of Cunning"}}},r=0,rl=24,si={17126},su=17125,x=1950}
T[6701]={c=8,en={6766},l=60,n="Syndicate Emblems",ob={i={{17124}}},ps={6681},r=0,rl=24,rp={349,0},sf=1,sn={6766}}
T[6721]={c=4,d="Speak with Dazalar in Dolanaar.",en={3601},ex={6071,6072,6073,6722},l=10,n="The Hunter's Path",nx=6063,r=8,rl=10,sn={5116},x=85}
T[6722]={c=4,d="Speak with Dazalar in Dolanaar.",en={3601},ex={6071,6072,6073,6721},l=10,n="The Hunter's Path",nx=6063,r=8,rl=10,sn={1231},x=85}
T[6741]={en={13176},l=60,n="More Booty!",ob={i={{17422}}},ps={7224},r=178,rl=51,sf=1,sn={13176},tg=41}
T[6761]={d="Speak with Mathrengyl Bearwalker at the Cenarion Enclave of Darnassus.",en={4217},l=55,n="The New Frontier",nx=6762,ps={1015,1019,1047},r=77,rl=54,sn={3516},x=560}
T[6762]={d="Speak with Rabine Saturna in the village of Nighthaven, Moonglade. Moonglade lies between Felwood and Winterspring, accessible through a path out of Timbermaw Hold.",en={11801},l=55,n="Rabine Saturna",nx=1124,ps={6761},r=77,rl=54,sn={4217},x=1400}
T[6781]={en={13257},l=60,n="More Armor Scraps",ob={i={{17422}}},ps={7223},r=77,rl=51,sf=1,sn={13257},tg=41}
T[6801]={en={13236},l=60,n="Lokholar the Ice Lord",ob={i={{17306}}},r=178,rl=51,sf=1,sn={13236},tg=41}
T[6804]={d="Use the Aspect of Neptulon on poisoned elementals of Eastern Plaguelands. Bring 12 Discordant Bracers and the Aspect of Neptulon to Duke Hydraxis in Azshara.",en={13278},l=56,n="Poisoned Water",ob={i={{17309}}},r=0,rl=55,sn={13278},su=17310,x=4350}
T[6805]={d="Kill 15 Dust Stormers and 15 Desert Rumblers and then return to Duke Hydraxis in Azshara.",en={13278},l=57,n="Stormers and Rumblers",ob={k={{11744},{11746}}},r=0,rl=55,sn={13278},x=6000}
T[6821]={d="Bring the Eye of the Emberseer to Duke Hydraxis in Azshara.",en={13278},l=60,n="Eye of the Emberseer",nx=6822,ob={i={{17322}}},pg={6804,6805},r=0,rl=56,sn={13278},tg=62,x=8300,z=1583}
T[6822]={d="Kill 1 Fire Lord, 1 Molten Giant, 1 Ancient Core Hound and 1 Lava Surger, then return to Duke Hydraxis in Azshara.",en={13278},l=60,n="The Molten Core",nx=6823,ob={k={{11658},{11668},{11673},{12101}}},ps={6821},r=0,rl=57,sn={13278},tg=62,x=9950}
T[6823]={d="Earn an Honored faction with the Hydraxian Waterlords, then talk to Duke Hydraxis in Azshara.",en={13278},l=60,n="Agent of Hydraxis",nx=6824,ps={6822},r=0,rl=60,sn={13278},x=9950}
T[6824]={d="Bring the Hands of Lucifron, Sulfuron, Gehennas and Shazzrah to Duke Hydraxis in Azshara.",en={13278},l=60,n="Hands of the Enemy",nx=7486,ob={i={{17332},{17329},{17331},{17330}}},ps={6823},r=0,rl=60,sn={13278},tg=62,x=9950}
T[6825]={en={13179},l=60,n="Call of Air - Guse's Fleet",ob={i={{17326}}},r=178,rl=51,sf=1,sn={13179},tg=41}
T[6826]={en={13180},l=60,n="Call of Air - Jeztor's Fleet",ob={i={{17327}}},r=178,rl=51,sf=1,sn={13180},tg=41}
T[6827]={en={13181},l=60,n="Call of Air - Mulverick's Fleet",ob={i={{17328}}},r=178,rl=51,sf=1,sn={13181},tg=41}
T[6844]={d="Take the Encrusted Silithid Object to Umber - the Cenarion Circle's archivist - in the village of Nighthaven, Moonglade.",en={11939},l=57,n="Umber, Archivist",nx=6845,ps={1126},r=0,rl=54,sn={13220},su=17346,x=3000}
T[6845]={d="Speak with Rabine Saturna in the village of Nighthaven, Moonglade.",en={11801},l=57,n="Uncovering Past Secrets",nx=1185,ps={6844},r=0,rl=54,sn={11939},x=7550}
T[6846]={en={13446},l=60,n="Begin the Attack!",ob={i={{17353}}},r=77,rl=51,sf=1,sn={13446},tg=41}
T[6881]={en={13442},l=60,n="Ivus the Forest Lord",ob={i={{17423}}},r=77,rl=51,sf=1,sn={13442},tg=41}
T[6921]={d="Bring the Fathom Core to Je'neu Sancrea at Zoram'gar Outpost, Ashenvale.",en={12736},l=27,n="Amongst the Ruins",ob={i={{16762}}},r=178,rl=21,sn={12736},tg=81,x=2750,z=719}
T[6922]={d="Bring the Strange Water Globe to Je'neu Sancrea at Zoram'gar Outpost, Ashenvale.",en={12736},l=30,n="Baron Aquanis",r=178,rl=21,si={16782},su=16782,tg=81,x=3050,z=719}
T[6941]={en={13439},l=60,n="Call of Air - Vipore's Fleet",ob={i={{17503}}},r=77,rl=51,sf=1,sn={13439},tg=41}
T[6942]={en={13438},l=60,n="Call of Air - Slidore's Fleet",ob={i={{17502}}},r=77,rl=51,sf=1,sn={13438},tg=41}
T[6943]={en={13437},l=60,n="Call of Air - Ichman's Fleet",ob={i={{17504}}},r=77,rl=51,sf=1,sn={13437},tg=41}
T[6981]={d="Travel to Ratchet to find someone that can tell you more about the glowing shard.",en={8418},l=26,n="The Glowing Shard",ob={k={{3442}}},r=0,rl=15,sf=2,si={10441},su=10441,x=2650,z=718}
T[6982]={d="Bring 10 Coldtooth Supplies to the Alliance Quartermaster in Dun Baldar.",en={12096},l=55,n="Coldtooth Supplies",ob={i={{17542}}},r=77,rl=51,sf=1,sn={12096},tg=41}
T[6985]={d="Bring 10 Irondeep Supplies to the Horde Quartermaster in Frostwolf Keep.",en={12097},l=55,n="Irondeep Supplies",ob={i={{17522}}},r=178,rl=51,sf=1,sn={12097},tg=41}
T[7001]={d="Locate a Frostwolf in Alterac Valley. Use the Frostwolf Muzzle when you are near the Frostwolf to 'tame' the beast. Once tamed, the Frostwolf will follow you back to the Frostwolf Stable Master. Speak with the Frostwolf Stable Master to earn credit for the capture.",en={13616},l=60,n="Empty Stables",ob={k={{14282}}},r=178,rl=51,sf=3,sn={13616},su=17626,tg=41}
T[7002]={en={13441},l=60,n="Ram Hide Harnesses",ob={i={{17642}}},r=178,rl=51,sf=1,sn={13441},tg=41}
T[7003]={d="Use Zorbin's Ultra-Shrinker to zap any kind of giant found in Feralas into a more manageable form. Bring 15 Miniaturization Residues found on the zapped versions of these giants to Zorbin Fandazzle at the docks of the Forgotten Coast, Feralas.",en={14637},l=48,n="Zapped Giants",nx=7725,ob={i={{18956}}},r=0,rl=45,sn={14637},su=18904,x=4400}
T[7026]={en={13577},l=60,n="Ram Riding Harnesses",ob={i={{17643}}},r=77,rl=51,sf=1,sn={13577},tg=41}
T[7027]={d="Locate an Alterac Ram in Alterac Valley. Use the Stormpike Training Collar when you are near the Alterac Ram to 'tame' the beast. Once tamed, the Alterac Ram will follow you back to the Stable Master. Speak with the Stable Master to earn credit for the capture.",en={13617},l=60,n="Empty Stables",ob={k={{10990}}},r=77,rl=51,sf=3,sn={13617},su=17689,tg=41}
T[7028]={d="Collect 15 Theradric Crystal Carvings for Willow in Desolace.",en={13656},l=47,n="Twisted Evils",ob={i={{17684}}},r=0,rl=41,sn={13656},tg=81,x=5250,z=2100}
T[7029]={d="Fill the Coated Cerulean Vial at the orange crystal pool in Maraudon.",en={11823},l=47,n="Vyletongue Corruption",ob={i={{17696}},k={{13696,"Vylestem Vines healed"}}},r=178,rl=41,sn={11823},su=17693,tg=81,x=5250,z=2100}
T[7041]={d="Fill the Coated Cerulean Vial at the orange crystal pool in Maraudon.",en={11715},l=47,n="Vyletongue Corruption",ob={i={{17696}},k={{13696,"Vylestem Vines healed"}}},r=77,rl=41,sn={11715},su=17693,tg=81,x=5250,z=2100}
T[7044]={d="Recover the two parts of the Scepter of Celebras: the Celebrian Rod and the Celebrian Diamond.",en={13716},l=49,n="Legends of Maraudon",nx=7046,ob={i={{17703},{17702}}},r=0,rl=41,sn={13697},tg=81,x=3400,z=2100}
T[7046]={d="Assist Celebras the Redeemed while he creates the Scepter of Celebras.",en={13716},l=49,n="The Scepter of Celebras",ob={o={{178965}}},ps={7044},r=0,rl=41,sf=2,sn={13716},tg=81,x=5700,z=2100}
T[7064]={d="Slay Princess Theradras and return to Selendra near Shadowprey Village in Desolace.",en={13699},l=51,n="Corruption of Earth and Seed",ob={k={{12201}}},r=178,rl=45,sn={13699},tg=81,x=6100,z=2100}
T[7065]={d="Slay Princess Theradras and return to Keeper Marandis at Nijel's Point in Desolace.",en={13698},l=51,n="Corruption of Earth and Seed",ob={k={{12201}}},r=77,rl=45,sn={13698},tg=81,x=6100,z=2100}
T[7066]={d="Seek out Remulos in Moonglade and give him the Seed of Life.",en={11832},l=51,n="Seed of Life",r=0,rl=45,sn={12238},su=17760,tg=81,x=6100,z=2100}
T[7067]={d="Read the Pariah's Instructions. Afterwards, obtain the Amulet of Union from Maraudon and return it to the Centaur Pariah in southern Desolace.",en={13717},l=48,n="The Pariah's Instructions",ob={i={{17758}}},r=0,rl=39,rs={17757,17761,17762,17763,17764,17765},sn={13717},su=17781,tg=81,x=5450,z=2100}
T[7068]={d="Collect 10 Shadowshard Fragments from Maraudon and return them to Uthel'nay in Orgrimmar.",en={7311},l=42,n="Shadowshard Fragments",ob={i={{17756}}},r=178,rl=39,sn={7311},tg=81,x=3450,z=2100}
T[7070]={d="Collect 10 Shadowshard Fragments from Maraudon and return them to Archmage Tervosh in Theramore on the coast of Dustwallow Marsh.",en={4967},l=42,n="Shadowshard Fragments",ob={i={{17756}}},r=77,rl=39,sn={4967},tg=81,x=3450,z=2100}
T[7081]={d="Assault a graveyard, then return to Sergeant Durgen Stormpike in the Alterac Mountains.",en={13777},l=60,n="Alterac Valley Graveyards",ob={k={{13756,"Graveyard Assaulted"}}},r=77,rl=51,sf=0,sn={13777},tg=41,x=6600}
T[7082]={d="Assault a graveyard, then return to Corporal Teeka Bloodsnarl in the Alterac Mountains.",en={13776},l=60,n="The Graveyards of Alterac",ob={k={{13756,"Graveyard Assaulted"}}},r=178,rl=51,sf=0,sn={13776},tg=41,x=6600}
T[7101]={d="Capture an enemy tower, then return to Corporal Teeka Bloodsnarl in the Alterac Mountains.",en={13776},l=60,n="Towers and Bunkers",ob={k={{13778,"Tower Captured"}}},r=178,rl=51,sn={13776},tg=41,x=6600}
T[7102]={d="Destroy the banner at an enemy tower or bunker, then return to Sergeant Durgen Stormpike in the Alterac Mountains.",en={13777},l=60,n="Towers and Bunkers",ob={k={{13778,"Banner Destroyed"}}},r=77,rl=51,sn={13777},tg=41,x=6600}
T[7121]={d="Speak with the Stormpike Quartermaster.",en={12096},l=60,n="The Quartermaster",nx=7122,r=77,rl=51,sn={13797},tg=41,x=660}
T[7122]={d="Capture a mine that the Stormpike does not control, then return to Sergeant Durgen Stormpike in the Alterac Mountains.",en={13777},l=60,n="Capture a Mine",ob={k={{13796,"Mine Captured"}}},r=77,rl=51,sn={13777},tg=41,x=6600}
T[7123]={d="Speak with the Frostwolf Quartermaster.",en={12097},l=60,n="Speak with our Quartermaster",nx=7124,r=178,rl=51,sn={13798},tg=41,x=660}
T[7124]={d="Capture a mine, then return to Corporal Teeka Bloodsnarl in the Alterac Mountains.",en={13776},l=60,n="Capture a Mine",ob={k={{13796,"Mine Captured"}}},r=178,rl=51,sn={13776},tg=41,x=6600}
T[7141]={d="Enter Alterac Valley, defeat the Horde general Drek'thar, and then return to Prospector Stonehewer in the Alterac Mountains.",en={13816},l=60,n="The Battle of Alterac",nx=8271,ob={e={"Defeat Drek'thar.",{{1459,47.2,87}}}},r=77,rl=51,sf=2,sn={13816},tg=41,x=9950}
T[7142]={d="Enter Alterac Valley and defeat the dwarven general, Vanndar Stormpike. Then, return to Voggah Deathgrip in the Alterac Mountains.",en={13817},l=60,n="The Battle for Alterac",nx=8272,ob={e={"Defeat Vanndar Stormpike.",{{1459,42.3,12.9}}}},r=178,rl=51,sf=2,sn={13817},tg=41,x=9950}
T[7161]={d="Travel to the Wildpaw cavern located southeast of the main base in Alterac Valley and find the Frostwolf Banner. Return the Frostwolf Banner to Warmaster Laggrond.",en={13840},l=60,n="Proving Grounds",nx=7163,ob={i={{17850}}},r=178,rl=51,rp={729,0},sn={13840},tg=41,x=6600}
T[7162]={d="Travel to the Icewing Caverns located southwest of Dun Baldar in Alterac Valley and recover the Stormpike Banner. Return the Stormpike Banner to Lieutenant Haggerdin in the Alterac Mountains.",en={13841},l=60,n="Proving Grounds",nx=7168,ob={i={{17849}}},r=0,rl=51,rp={730,0},sn={13841},tg=41,x=6600}
T[7163]={en={13840},l=60,n="Rise and Be Recognized",nx=7164,ob={i={{17690}}},ps={7161},r=178,rl=51,rp={729,3000},sn={13840},tg=41,x=6600}
T[7164]={en={13840},l=60,n="Honored Amongst the Clan",nx=7165,ob={i={{17905}}},ps={7163},r=178,rl=51,rp={729,9000},sn={13840},tg=41,x=6600}
T[7165]={en={13840},l=60,n="Earned Reverence",nx=7166,ob={i={{17906}}},ps={7164},r=178,rl=51,rp={729,21000},sn={13840},tg=41,x=8300}
T[7166]={en={13840},l=60,n="Legendary Heroes",nx=7167,ob={i={{17907}}},ps={7165},r=178,rl=51,rp={729,42000},sn={13840},tg=41,x=9950}
T[7167]={en={13840},l=60,n="The Eye of Command",ob={i={{17908}}},ps={7166},r=178,rl=51,rp={729,42999},sn={13840},tg=41,x=9950}
T[7168]={en={13841},l=60,n="Rise and Be Recognized",nx=7169,ob={i={{17691}}},ps={7162},r=77,rl=51,rp={730,3000},sn={13841},tg=41,x=6600}
T[7169]={en={13841},l=60,n="Honored Amongst the Guard",nx=7170,ob={i={{17900}}},ps={7168},r=77,rl=51,rp={730,9000},sn={13841},tg=41,x=6600}
T[7170]={en={13841},l=60,n="Earned Reverence",nx=7171,ob={i={{17901}}},ps={7169},r=77,rl=51,rp={730,21000},sn={13841},tg=41,x=8300}
T[7171]={en={13841},l=60,n="Legendary Heroes",nx=7172,ob={i={{17902}}},ps={7170},r=77,rl=51,rp={730,42000},sn={13841},tg=41,x=9950}
T[7172]={en={13841},l=60,n="The Eye of Command",ob={i={{17903}}},ps={7171},r=77,rl=51,rp={730,42999},sn={13841},tg=41,x=9950}
T[7181]={d="According to legend, the leader of the mighty Winterax trolls appears at will to wreak havoc on the denizens of Alterac Valley.",en={13840},l=60,n="The Legend of Korrak",ob={k={{12159}}},r=178,rl=51,sf=1,tg=41,x=9950}
T[7201]={d="Travel to Blackrock Depths and recover 10 Essence of the Elements. Your first inclination is to search the golems and golem makers. You remember Vivian Lagrave also muttering something about elementals.",en={9078},l=54,n="The Last Element",ob={i={{11129}}},ps={3906},r=178,rl=48,sn={9078},tg=81,x=5450,z=1584}
T[7202]={d="According to legend, the leader of the mighty Winterax trolls appears at will to wreak havoc on the denizens of Alterac Valley.",en={13841},l=60,n="Korrak the Bloodrager",ob={k={{12159}}},r=77,rl=51,sf=1,tg=41,x=9950}
T[7223]={d="Bring 20 Armor Scraps to Murgot Deepforge in Dun Baldar.",en={13257},l=60,n="Armor Scraps",nx=6781,ob={i={{17422}}},r=77,rl=51,sn={13257},tg=41,x=6600}
T[7224]={d="Bring 20 Armor Scraps to Smith Regzar in Frostwolf Village.",en={13176},l=60,n="Enemy Booty",nx=6741,ob={i={{17422}}},r=178,rl=51,sn={13176},tg=41,x=6600}
T[7241]={d="Venture to Alterac Valley, located in the Alterac Mountains. Find and speak with Warmaster Laggrond - who stands outside the tunnel entrance - to begin your career as a soldier of Frostwolf. You will find Alterac Valley north of Tarren Mill at the base of the Alterac Mountains.",en={13840},l=60,n="In Defense of Frostwolf",nx=7161,r=178,rl=51,sn={13842},tg=41,x=6600}
T[7261]={d="Travel to Alterac Valley in the Hillsbrad Foothills. Outside of the entrance tunnel, find and speak with Lieutenant Haggerdin.",en={13841},l=60,n="The Sovereign Imperative",nx=7162,r=77,rl=51,sn={13843},tg=41,x=6600}
T[7321]={d="Bring 10 pieces of Turtle Meat and some Soothing Spices to Christoph Jeffcoat in Tarren Mill.",en={2393},l=31,n="Soothing Turtle Bisque",ob={i={{3712},{3713}}},r=178,rl=28,sk={185,1},sn={2393},x=2500}
T[7341]={en={14182},l=60,n="A Fair Trade",ob={i={{15997}}},r=178,rl=52,sf=1,sn={14182}}
T[7342]={en={14183},l=60,n="Arrows Are For Sissies",ob={i={{15997}}},r=77,rl=52,sf=1,sn={14183}}
T[7361]={d="You have been tasked with slaying opposing night elf players in Alterac Valley.",l=60,n="Favor Amongst the Darkspear",ob={i={{18142}}},r=178,rl=51,sf=1,tg=41,x=9950}
T[7362]={d="You have been tasked with slaying opposing gnome players in Alterac Valley.",l=60,n="Ally of the Tauren",ob={i={{18143}}},r=178,rl=51,sf=1,tg=41,x=9950}
T[7363]={d="You have been tasked with slaying opposing human players in Alterac Valley.",l=60,n="The Human Condition",ob={i={{18144}}},r=178,rl=51,sf=1,tg=41,x=9950}
T[7366]={d="You have been tasked with slaying opposing Forsaken players in Alterac Valley.",l=60,n="The Archbishop's Mercy",ob={i={{18147}}},r=77,rl=51,sf=1,tg=41,x=9950}
T[7381]={d="Should Korrak the Bloodrager make a return to the Field of Strife, seek him out and destroy him.",en={13840},l=60,n="The Return of Korrak",ob={i={{18148}}},r=178,rl=51,sf=1,tg=41}
T[7382]={d="Should Korrak the Bloodrager make a return to the Field of Strife, seek him out and destroy him.",en={13841},l=60,n="Korrak the Everliving",ob={i={{18148}}},r=77,rl=51,sf=1,tg=41}
T[7383]={d="Fill the Amethyst Phial and bring it back to Corithras Moonrage in Dolanaar.",en={3515},l=11,n="Crown of the Earth",nx=935,ob={i={{18151}}},ps={933},r=77,rl=1,sn={3515},su=18152,x=660}
T[7385]={en={13236},l=60,n="A Gallon of Blood",ob={i={{17306}}},r=178,rl=51,sf=1,sn={13236},tg=41}
T[7386]={en={13442},l=60,n="Crystal Cluster",ob={i={{17423}}},r=77,rl=51,sf=1,sn={13442},tg=41}
T[7424]={l=60,n="What the Hoof?",ob={i={{18145}}},r=77,rl=55,sf=1,tg=41}
T[7429]={en={14338},l=60,n="Free Knot!",ob={i={{18250}}},ps={5525},r=0,rl=57,sf=1,sn={14338},tg=81,z=2557}
T[7441]={d="Travel to Dire Maul and locate the Imp, Pusillin. Convince Pusillin to give you Azj'Tordin's Book of Incantations through any means necessary.",en={14355},l=58,n="Pusillin and the Elder Azj'Tordin",ob={i={{18261}}},r=0,rl=54,sn={14355},tg=81,x=7750,z=2557}
T[7461]={d="You must destroy the guardians surrounding the 5 Pylons that power the Prison of Immol'thar. Once the Pylons have powered down, the force field surrounding Immol'thar will have dissipated.",en={14358},l=60,n="The Madness Within",nx=7877,ob={k={{11496},{11486}}},r=0,rl=56,sn={14358},tg=81,x=9950,z=2557}
T[7463]={c=128,d="Travel to the Warpwood Quarter of Dire Maul and slay the water elemental, Hydrospawn. Return to Lorekeeper Lydros in the Athenaeum with the Hydrospawn Essence.",en={14368},l=60,n="Arcane Refreshment",ob={i={{18299}}},r=0,rl=60,sn={14368},tg=81,x=6600}
T[7481]={d="Search Dire Maul for Telmius Dreamseeker. Report back to Sage Korolusk at Camp Mojache with whatever information that you may find.",en={14373},l=60,n="Elven Legends",ob={o={{179544}}},r=178,rl=54,sf=2,sn={14373},tg=81,x=8300,z=2557}
T[7482]={d="Search Dire Maul for Telmius Dreamseeker. Report back to Scholar Runethorn at Feathermoon with whatever information that you may find.",en={14374},l=60,n="Elven Legends",ob={o={{179544}}},r=77,rl=54,sf=2,sn={14374},tg=81,x=8300,z=2557}
T[7483]={d="Bring a Libram of Rapidity, 1 Pristine Black Diamond, 2 Large Brilliant Shards, and 2 Blood of Heroes to Lorekeeper Lydros in Dire Maul to receive an Arcanum of Rapidity.",en={14368},l=60,n="Libram of Rapidity",ob={i={{18332},{18335},{14344},{12938}}},ps={7481,7482},r=0,rl=58,sf=1,sn={14368},tg=81,z=2557}
T[7484]={d="Bring a Libram of Focus, 1 Pristine Black Diamond, 4 Large Brilliant Shards, and 2 Skin of Shadow to Lorekeeper Lydros in Dire Maul to receive an Arcanum of Focus.",en={14368},l=60,n="Libram of Focus",ob={i={{18333},{18335},{14344},{12753}}},ps={7481,7482},r=0,rl=58,sf=1,sn={14368},tg=81,z=2557}
T[7485]={d="Bring a Libram of Protection, 1 Pristine Black Diamond, 2 Large Brilliant Shards, and 1 Frayed Abomination Stitching to Lorekeeper Lydros in Dire Maul to receive an Arcanum of Protection.",en={14368},l=60,n="Libram of Protection",ob={i={{18334},{18335},{14344},{12735}}},ps={7481,7482},r=0,rl=58,sf=1,sn={14368},tg=81,z=2557}
T[7486]={d="Claim your reward from Hydraxis' Coffer.",eo={179551},l=60,n="A Hero's Reward",ps={6824},r=0,rl=60,sn={13278},x=9950}
T[7488]={d="Bring Lethtendris' Web to Latronicus Moonspear at the Feathermoon Stronghold in Feralas.",en={7877},l=57,n="Lethtendris's Web",ob={i={{18426}}},r=77,rl=54,sn={7877},tg=81,x=7550,z=2557}
T[7489]={d="Bring Lethtendris's Web to Talo Thornhoof at Camp Mojache in Feralas.",en={7776},l=57,n="Lethtendris's Web",ob={i={{18426}}},r=178,rl=54,sn={7776},tg=81,x=7550,z=2557}
T[7490]={d="Take the Head of Onyxia to Thrall in Orgrimmar.",en={4949},l=60,n="Victory for the Horde",nx=7491,ps={6602},r=178,rl=60,si={18422},su=18422,x=9950}
T[7491]={d="Seek out Overlord Runthak in the Valley of Strength.",en={14392},l=60,n="For All To See",nx=7493,ps={7490},r=178,rl=60,sn={4949},x=9950}
T[7492]={d="Speak with Talo Thornhoof at Camp Mojache in Feralas.",en={7776},l=57,n="Camp Mojache",nx=7489,r=178,rl=54,sn={10879,10880,10881},tg=81,x=1500,z=2557}
T[7493]={en={14392},l=60,n="The Journey Has Just Begun",ps={7491},r=178,rl=60,sk={165,300},sn={14392}}
T[7494]={d="Speak with Latronicus Moonspear at the Feathermoon Stronghold in Feralas.",en={7877},l=57,n="Feathermoon Stronghold",nx=7488,r=77,rl=54,sn={2198,10877,10878},tg=81,x=1500,z=2557}
T[7495]={d="Take the Head of Onyxia to Highlord Bolvar Fordragon in Stormwind.",en={1748},l=60,n="Victory for the Alliance",nx=7496,ps={6502},r=77,rl=60,si={18423},su=18423,x=9950}
T[7496]={d="Seek out Major Mattingly in the Valley of Heroes.",en={14394},l=60,n="Celebrating Good Times",nx=7497,ps={7495},r=77,rl=60,sn={1748},x=9950}
T[7497]={en={14394},l=60,n="The Journey Has Just Begun",ps={7496},r=77,rl=60,sk={165,300},sn={14394}}
T[7498]={c=8,d="Return the book to its rightful owners.",en={14383},l=60,n="Garona: A Study on Stealth and Treachery",r=0,rl=54,si={18356},su=18356,tg=81,x=6600,z=2557}
T[7499]={c=1,d="Return the book to its rightful owners.",en={14383},l=60,n="Codex of Defense",r=0,rl=54,si={18357},su=18357,tg=81,x=6600,z=2557}
T[7500]={c=128,d="Return the book to its rightful owners.",en={14383},l=60,n="The Arcanist's Cookbook",r=0,rl=54,si={18358},su=18358,tg=81,x=6600,z=2557}
T[7501]={c=2,d="Return the book to its rightful owners.",en={14382},l=60,n="The Light and How To Swing It",r=0,rl=54,si={18359},su=18359,tg=81,x=6600,z=2557}
T[7502]={c=256,d="Return the book to its rightful owners.",en={14382},l=60,n="Harnessing Shadows",r=0,rl=54,si={18360},su=18360,tg=81,x=6600,z=2557}
T[7503]={c=4,d="Return the book to its rightful owners.",en={14382},l=60,n="The Greatest Race of Hunters",r=0,rl=54,si={18361},su=18361,tg=81,x=6600,z=2557}
T[7504]={c=16,d="Return the book to its rightful owners.",en={14381},l=60,n="Holy Bologna: What the Light Won't Tell You",r=0,rl=54,si={18362},su=18362,tg=81,x=6600,z=2557}
T[7505]={c=64,d="Return the book to its rightful owners.",en={14381},l=60,n="Frost Shock and You",r=0,rl=54,si={18363},su=18363,tg=81,x=6600,z=2557}
T[7506]={c=1024,d="Return the book to its rightful owners.",en={14381},l=60,n="The Emerald Dream...",r=0,rl=54,si={18364},su=18364,tg=81,x=6600,z=2557}
T[7507]={c=3,d="Return Nostro's Compendium of Dragon Slaying to the Athenaeum.",en={14368},l=60,n="Nostro's Compendium",nx=7508,r=0,rl=60,si={18401},su=18401,tg=81,x=6600,z=2557}
T[7508]={c=3,d="Give the Dull and Flat Elven Blade to Lorekeeper Lydros.",en={14368},l=60,n="The Forging of Quel'Serrar",nx=7509,ps={7507},r=0,rl=60,si={18513},su=18513,tg=81,x=6600,z=2557}
T[7509]={c=3,d="You must get Onyxia to breathe fire on the Unfired Ancient Blade. Once this is done, pick up the now Heated Ancient Blade. Be warned, a Heated Ancient Blade will not remain heated forever - time is of the essence.",en={14368},l=60,n="The Forging of Quel'Serrar",ob={i={{18492}}},ps={7508},r=0,rl=60,rs={18488},sf=0,sn={14368},su=18489,tg=62,x=9950}
T[7541]={en={4047},l=40,n="Service to the Horde",ps={1262},r=178,rl=30,sn={4047},x=1950}
T[7562]={c=256,d="Speak with Mor'zul Bloodbringer in the Burning Steppes.",en={14436},l=58,n="Mor'zul Bloodbringer",nx=7563,r=0,rl=60,sn={5520,5815,6382,12807},x=620}
T[7563]={c=256,d="Bring 30 bottles of Raging Beast's Blood to Mor'zul Bloodbringer in the Burning Steppes.",en={14436},l=58,n="Rage of Blood",nx=7564,ob={i={{18590}}},r=0,rl=60,sn={14436},x=7750}
T[7564]={c=256,d="Bring the Case of Blood to Gorzeeki Wildeyes in the Burning Steppes.",en={14437},l=58,n="Wildeyes",ps={7563},r=0,rl=60,sn={14436},su=18591,x=3100}
T[7581]={c=256,d="Travel to Dire Maul in Feralas and recover 15 Satyr Blood from the Wildspawn Satyr that inhabit the Warpwood Quarter. Return to Daio in the Tainted Scar when this is done.",en={14463},l=60,n="The Prison's Bindings",nx=7583,ob={i={{18603}}},r=0,rl=60,sn={14463},tg=81,x=6600}
T[7582]={c=256,d="Travel to Darkwhisper Gorge in Winterspring and recover 5 Tears of the Hederine from the Hederine demons that occupy the gorge. Return to Daio in the Tainted Scar when you have completed this task.",en={14463},l=60,n="The Prison's Casing",nx=7583,ob={i={{18604}}},r=0,rl=60,sn={14463},tg=1,x=6600}
T[7583]={c=256,d="Venture forth into the Tainted Scar and locate a Doomguard Commander.",en={14463},l=60,n="Suppression",ob={i={{18605}}},pg={7581,7582},r=0,rl=60,sn={14463},su=18601,tg=1,x=6600}
T[7601]={c=256,d="Speak with Impsy in Felwood.",en={14470},l=50,n="What Niby Commands",nx=7602,r=0,rl=50,sn={14469}}
T[7602]={c=256,d="Impsy in Felwood has asked that you bring him three Flawless Fel Essences originating from three distinct locations.",en={14470},l=55,n="Flawless Fel Essence",nx=7603,ob={i={{18624},{18622},{18623}}},ps={7601},r=0,rl=50,sn={14470},x=5650}
T[7603]={c=256,d="Search Shatter Scar Vale in Felwood for the remains of Kroshius. When you locate the remains, use the Fel Fire near them and await Kroshius' return. When the infernal has awoken, slay him and take from his corpse Kroshius' Infernal Core.",en={14469},l=55,n="Kroshius' Infernal Core",ob={i={{18625}},k={{14467}}},ps={7602},r=0,rl=50,sn={14470},su=18626,tg=1,x=7050}
T[7604]={d="Turn the Thorium Brotherhood Contract in to Lokhtos Darkbargainer if you would like to receive the plans for Sulfuron.",en={12944},l=60,n="A Binding Contract",ob={i={{17203}}},r=0,rl=60,sf=0,si={18628},su=18628,tg=81,z=1584}
T[7621]={c=16,en={14494},l=60,n="A Warning",r=0,rl=60,sn={14494}}
T[7622]={c=16,d="Save 50 Peasants before 15 are slain. Speak with Eris Havenfire should you accomplish this task.",en={14494},l=60,n="The Balance of Light and Shadow",ob={e={"The Balance of Light and Shadow",{{1423,17.4,12.2}}}},r=0,rl=60,sf=2,sn={14494},x=9950}
T[7623]={c=256,d="Purchase Shadowy Potions from Gorzeeki in the Burning Steppes.",en={9516},l=58,n="Lord Banehollow",nx=7624,r=0,rl=60,sn={14437},x=6200}
T[7624]={c=256,d="Confront Ulathek, then bring The Traitor's Heart to Lord Banehollow in Jaedenar.",en={9516},l=58,n="Ulathek the Traitor",nx=7625,ob={i={{18719}}},ps={7623},r=0,rl=60,sn={9516},x=6200}
T[7625]={c=256,d="Purchase Xorothian Stardust from Ur'dan. Bring it to Gorzeeki Wildeyes in the Burning Steppes.",en={14437},l=60,n="Xorothian Stardust",ob={i={{18687}}},ps={7624},r=0,rl=60,sn={9516},x=6600}
T[7626]={c=256,d="Bring 10 Elixirs of Shadow Power to Gorzeeki Wildeyes in the Burning Steppes.",en={14437},l=60,n="Bell of Dethmoora",ob={i={{9264}}},ps={7564},r=0,rl=60,sn={14436},x=6600}
T[7627]={c=256,d="Bring 6 Large Brilliant Shards and 25 Dark Iron Ore to Gorzeeki in the Burning Steppes.",en={14437},l=60,n="Wheel of the Black March",ob={i={{14344},{11370}}},ps={7564},r=0,rl=60,sn={14436},x=6600}
T[7628]={c=256,d="Bring 35 Black Dragonscales to Gorzeeki Wildeyes in the Burning Steppes.",en={14437},l=60,n="Doomsday Candle",ob={i={{15416}}},ps={7564},r=0,rl=60,sn={14436},x=6600}
T[7629]={c=256,d="Bring the Imp in a Jar to the alchemy lab in the Scholomance. After the parchment is created, return the jar to Gorzeeki Wildeyes.",en={14437},l=60,n="Imp Delivery",ob={k={{14500}}},ps={7625},r=0,rl=60,sn={14437},su=18688,tg=81,x=6600,z=2057}
T[7630]={c=256,d="Bring 3 Arcanite Bar to Gorzeeki in the Burning Steppes.",en={14437},l=60,n="Arcanite",ob={i={{12360}}},pg={7626,7627,7628},r=0,rl=60,sn={14437},x=6600}
T[7631]={c=256,d="Read Mor'zul's Instructions. Summon a Xorothian Dreadsteed, defeat it, then bind its spirit to you.",en={14504},l=60,n="Dreadsteed of Xoroth",ob={k={{14502}}},pg={7629,7630},r=0,rl=60,rs={18663,18629,18670},sn={14436},su=18818,tg=81,x=6600}
T[7632]={c=4,d="Find the owner of the Ancient Petrified Leaf. Good luck, <Name>; It's a big world.",en={14524},l=60,n="The Ancient Leaf",r=0,rl=60,si={18703},sn={12018},so={179703},su=18703,x=9950}
T[7633]={c=4,en={14524},l=60,n="An Introduction",ps={7632},r=0,rl=60,sn={14524}}
T[7634]={c=4,d="Hastat the Ancient has asked that you bring him a Mature Blue Dragon Sinew. Should you find this sinew, return it to Hastat in Felwood.",en={14526},l=60,n="Ancient Sinew Wrapped Lamina",ob={i={{18704}}},ps={7632},r=0,rl=60,sn={14526},tg=62,x=9950}
T[7635]={c=4,d="Stoma the Ancient has asked that you bring him a Mature Black Dragon Sinew. Should you find this sinew, return it to Stoma in Felwood.",en={14525},l=60,n="A Proper String",ob={i={{18705}}},ps={7632},r=0,rl=60,sn={14525},tg=62,x=9950}
T[7636]={c=4,d="You must find and destroy these four demonic corrupters:",en={14524},l=60,n="Stave of the Ancients",ob={i={{18952},{18953},{18954},{18955}}},ps={7632},r=0,rl=60,sn={14524},su=18708,tg=1,x=9950}
T[7637]={c=2,d="Travel to Ironforge and get High Priest Rohan's Exorcism Censer. You will need to make a donation of 150 gold in order to secure it.",en={11406},l=60,n="Emphasis on Sacrifice",nx=7639,ps={7638},r=5,rl=60,sn={928},x=660}
T[7638]={c=2,d="Speak with Lord Grayson Shadowbreaker in Stormwind's Cathedral District.",en={928},l=60,n="Lord Grayson Shadowbreaker",r=5,rl=60,sn={6171},x=660}
T[7639]={c=2,d="Return the Exorcism Censer to Lord Grayson Shadowbreaker in the Cathedral District of Stormwind.",en={928},l=60,n="To Show Due Judgment",nx=7640,ps={7637},r=5,rl=60,sn={11406},su=18819,x=660}
T[7640]={c=2,d="Use the Exorcism Censer to drive out the spirits that torment Terrordale. When you have slain 25 Terrordale Spirits, return to Lord Grayson Shadowbreaker in the Cathedral District of Stormwind.",en={928},l=60,n="Exorcising Terrordale",ob={k={{14564}}},ps={7639},r=5,rl=60,sn={928},su=18752,x=6600}
T[7641]={c=2,d="Speak with Grimand Elmore in Stormwind's Dwarven District.",en={1416},l=60,n="The Work of Grimand Elmore",nx=7642,ps={7640},r=5,rl=60,sn={928},x=660}
T[7642]={c=2,d="Bring 40 Runecloth, 6 Arcanite Bars, 10 Arthas' Tears, 5 Stratholme Holy Water vials, and 150 gold to Grimand Elmore in the Dwarven District of Stormwind.",en={1416},l=60,n="Collection of Goods",ob={i={{13180},{8836},{14047},{12360}}},ps={7641},r=5,rl=60,sn={1416},tg=81,x=1650}
T[7643]={c=2,d="Acquire special horse feed used for feeding a spirit horse. Merideth Carlson in Southshore apparently is the source for such food.",en={14566},l=60,n="Ancient Equine Spirit",nx=7644,ob={i={{18775}}},ps={7642},r=5,rl=60,sn={928},su=18753,tg=81,x=4950}
T[7644]={c=2,d="Return with the Blessed Arcanite Barding to Lord Grayson Shadowbreaker in the Cathedral District of Stormwind.",en={928},l=60,n="Blessed Arcanite Barding",nx=7646,ps={7643},r=5,rl=60,sn={14566},su=18792}
T[7645]={c=2,d="Retrieve 20 Enriched Manna Biscuits - the key ingredient in making Manna-Enriched Horse Feed - for Merideth Carlson at Southshore in the Hillsbrad Foothills. The Argent Dawn is known as the sole purveyor of the biscuits.",en={2357},l=60,n="Manna-Enriched Horse Feed",ob={i={{13724}}},pa=7643,r=5,rl=60,sn={2357},x=660}
T[7646]={c=2,d="Bring an Azerothian Diamond and a Pristine Black Diamond to Lord Grayson Shadowbreaker in the Cathedral District of Stormwind.",en={928},l=60,n="The Divination Scryer",nx=7647,ob={i={{12800},{18335}}},ps={7644},r=5,rl=60,sn={928},x=3300}
T[7647]={c=2,d="Use the Divination Scryer in the heart of the Great Ossuary's basement in the Scholomance. Doing so will bring forth the spirits you must judge. Defeating these spirits will summon forth Death Knight Darkreaver. Defeat him and reclaim the lost soul of the fallen charger.",en={14568},l=60,n="Judgment and Redemption",ob={i={{18799},{18792}}},ps={7646},r=5,rl=60,rs={18749},sn={928},su=18804,tg=81,x=9950}
T[7648]={c=2,d="Take the Arcanite Barding to Lord Grayson Shadowbreaker in Stormwind's Cathedral District for his inspection.",en={928},l=60,n="Grimand's Finest Work",ps={7642},r=5,rl=60,sn={1416},su=18753,x=6600}
T[7649]={d="Return the book to its rightful owners.",en={14368},l=60,n="Enchanted Thorium Platemail: Volume I",r=0,rl=60,si={18769},sk={164,300},su=18769,tg=81,x=6600}
T[7650]={d="Return the book to its rightful owners.",en={14368},l=60,n="Enchanted Thorium Platemail: Volume II",r=0,rl=60,si={18770},sk={164,300},su=18770,tg=81,x=9950}
T[7651]={d="Return the book to its rightful owners.",en={14368},l=60,n="Enchanted Thorium Platemail: Volume III",r=0,rl=55,sf=0,si={18771},sk={164,300},su=18771,tg=81,x=9950}
T[7652]={en={14567},l=60,n="A Blue Light Bargain",r=0,rl=50,sk={164,265},sn={14567}}
T[7653]={en={14567},l=60,n="Imperial Plate Belt",ob={i={{12359}}},ps={7652},r=0,rl=50,sk={164,265},sn={14567}}
T[7654]={en={14567},l=60,n="Imperial Plate Boots",ob={i={{12359}}},ps={7652},r=0,rl=50,sk={164,265},sn={14567}}
T[7655]={en={14567},l=60,n="Imperial Plate Bracer",ob={i={{12359}}},ps={7652},r=0,rl=50,sk={164,265},sn={14567}}
T[7656]={en={14567},l=60,n="Imperial Plate Chest",ob={i={{12359}}},ps={7652},r=0,rl=50,sk={164,265},sn={14567}}
T[7657]={en={14567},l=60,n="Imperial Plate Helm",ob={i={{12359}}},ps={7652},r=0,rl=50,sk={164,265},sn={14567}}
T[7658]={en={14567},l=60,n="Imperial Plate Leggings",ob={i={{12359}}},ps={7652},r=0,rl=50,sk={164,265},sn={14567}}
T[7659]={en={14567},l=60,n="Imperial Plate Shoulders",ob={i={{12359}}},ps={7652},r=0,rl=50,sk={164,265},sn={14567}}
T[7666]={c=2,en={928},l=60,n="Again Into the Great Ossuary",ps={7647},r=5,rl=60,sf=1,sn={928},tg=81}
T[7667]={c=64,d="If you are interested in helping Sagorne Crestrider in Orgrimmar's Valley of Wisdom, bring him an Azerothian Diamond and a Pristine Black Diamond.",en={13417},l=60,n="Material Assistance",nx=8258,ob={i={{12800},{18335}}},r=178,rl=58,sn={13417},x=4950}
T[7669]={c=64,en={13417},l=60,n="Again Into the Great Ossuary",ps={7668,8258},r=178,rl=58,sf=1,sn={13417}}
T[7670]={c=2,d="Speak with Lord Grayson Shadowbreaker in Stormwind's Cathedral District.",en={928},ex={7638},l=60,n="Lord Grayson Shadowbreaker",nx=7637,r=77,rl=60,sn={5149}}
T[7701]={d="Deep within the Slag Pit of the Cauldron, in the Searing Gorge, you will find the traitorous Dark Iron dwarf named Overseer Maltorius.",en={14634},l=50,n="WANTED: Overseer Maltorius",ob={i={{18946}}},r=0,rl=45,so={179827},tg=1,x=4700}
T[7703]={d="Find the Gauntlet of Gordok Might and return it to Captain Kromcrush in Dire Maul.",en={14325},l=60,n="Unfinished Gordok Business",ob={i={{18336}}},r=0,rl=56,sn={14325},tg=81,x=8300,z=2557}
T[7721]={d="Collect 10 Water Elemental Cores from the Sea Elementals and Sea Sprays along the Forgotten Coast of Feralas, and bring them back to Zorbin Fandazzle who is near the dock there.",en={14637},l=48,n="Fuel for the Zapping",nx=7726,ob={i={{18958}}},r=0,rl=45,sn={14637},x=4400}
T[7722]={d="Somewhere in the Slag Pit of the Cauldron you will find the Secret Plans: Fiery Flux that Overseer Maltorius stole. Find those plans and return them to Master Smith Burninate in the Searing Gorge.",en={14624},l=50,n="What the Flux?",ob={i={{18922}}},r=0,rl=45,sn={14624},x=4700}
T[7723]={d="Hansel Heavyhands wants you to kill 20 Heavy War Golems.",en={14627},l=49,n="Curse These Fat Fingers",ob={k={{5854}}},r=0,rl=45,sn={14627},x=4550}
T[7724]={d="Hansel Heavyhands wants you to kill 20 Greater Lava Spiders in the Searing Gorge. You can find Greater Lava Spiders in the plateaus and lava pools of the Searing Gorge.",en={14627},l=49,n="Fiery Menace!",ob={k={{5858}}},r=0,rl=45,sn={14627},x=4550}
T[7725]={d="Use Zorbin's Ultra-Shrinker to zap any kind of giant found in Feralas into a more manageable form. Bring 10 Miniaturization Residues found on the zapped versions of these giants to Zorbin Fandazzle at the docks of the Forgotten Coast, Feralas.",en={14637},l=55,n="Again With the Zapped Giants",ob={i={{18956}}},ps={7003},r=0,rl=45,sf=1,sn={14637},su=18904,x=560}
T[7726]={d="Collect 6 Water Elemental Cores from the Sea Elementals and Sea Sprays along the Forgotten Coast of Feralas, and bring them back to Zorbin Fandazzle who is near the dock there.",en={14637},l=55,n="Refuel for the Zapping",ob={i={{18958}}},ps={7721},r=0,rl=45,sf=1,sn={14637},x=560}
T[7727]={d="Hansel Heavyhands wants you to kill 20 Incendosaurs.",en={14627},l=49,n="Incendosaurs? Whateverosaur is More Like It",ob={k={{9318}}},r=0,rl=45,sn={14627},x=4550}
T[7728]={d="Find and return the Smithing Tuyere and Lookout's Spyglass to Taskmaster Scrange in the Searing Gorge.",en={14626},l=48,n="STOLEN: Smithing Tuyere and Lookout's Spyglass",ob={i={{18959},{18960}}},r=0,rl=45,so={179827},x=4400}
T[7729]={d="Slay 15 Dark Iron Taskmasters and 15 Dark Iron Slavers. Return to Taskmaster Scrange in the Searing Gorge once you have accomplished this task.",en={14626},l=48,n="JOB OPPORTUNITY: Culling the Competition",ob={k={{5846},{5844}}},r=0,rl=45,so={179827},x=4400}
T[7730]={d="Bring 20 Zukk'ash Carapaces to Hadoken Swiftstrider at Camp Mojache, Feralas.",en={7875},l=45,n="Zukk'ash Infestation",ob={i={{18961}}},ps={2903},r=178,rl=39,sn={7875},x=3900}
T[7731]={d="Defeat Stinglasher in the Writhing Deep, bringing its glands back to Hadoken Swiftstrider at Camp Mojache, Feralas.",en={7875},l=47,n="Stinglasher",ob={i={{18962}}},ps={2903},r=178,rl=39,sn={7875},x=4200}
T[7732]={d="Deliver the Camp Mojache Zukk'ash Report to Zilzibin Drumlore. He resides in the Drag of Orgrimmar.",en={7010},l=48,n="Zukk'ash Report",pg={7730,7731},r=178,rl=39,sn={7875},su=19020,x=4400}
T[7733]={d="Bring 10 Rage Scar Yeti Hides to Pratt McGrubben at Feathermoon Stronghold, Feralas.",en={7852},l=48,n="Improved Quality",ob={i={{18947}}},ps={2821},r=77,rl=40,sn={7852},x=4400}
T[7734]={d="Bring 10 Rage Scar Yeti Hides to Jangdor Swiftstrider at Camp Mojache, Feralas.",en={7854},l=48,n="Improved Quality",ob={i={{18947}}},ps={2822},r=178,rl=40,sn={7854},x=4400}
T[7735]={d="Bring the Pristine Yeti Hide to Pratt McGrubben at the Feathermoon Stronghold, Feralas.",en={7852},l=48,n="Pristine Yeti Hide",ps={2821},r=77,rl=40,sf=1,si={18969},su=18969,x=2200}
T[7736]={en={14624},l=60,n="Restoring Fiery Flux Supplies via Kingsblood",ob={i={{18944},{3356},{3857}}},ps={7722},r=0,rl=45,rp={59,1},sf=1,sn={14624}}
T[7737]={en={14624},l=60,n="Gaining Acceptance",ob={i={{18945}}},ps={7722},r=0,rl=45,rp={59,3000},sf=1,sn={14624},tg=81}
T[7738]={d="Bring the Perfect Yeti Hide to Jangdor Swiftstrider at Camp Mojache, Feralas.",en={7854},l=48,n="Perfect Yeti Hide",ps={2822},r=178,rl=40,sf=1,si={18972},su=18972,x=2200}
T[7761]={d="That is one stupid orc. It would appear as if you need to find this brand and gain the Mark of Drakkisath in order to access the Orb of Command.",eo={179880},l=60,n="Blackhand's Command",r=0,rl=55,si={18987},tg=81,x=6600,z=1583}
T[7781]={d="Return the Head of Nefarian to Highlord Bolvar Fordragon in Stormwind.",en={1748},l=60,n="The Lord of Blackrock",nx=7782,r=77,rl=60,si={19003},su=19003,x=9950}
T[7782]={d="Venture to the Valley of Heroes in Stormwind City and speak with Field Marshal Afrasiabi.",en={14721},l=60,n="The Lord of Blackrock",ps={7781},r=77,rl=60,sn={1748},x=9950}
T[7783]={d="Return the Head of Nefarian to Thrall in Orgrimmar.",en={4949},l=60,n="The Lord of Blackrock",nx=7784,r=178,rl=60,si={19002},su=19002,x=9950}
T[7784]={d="Speak with High Overlord Saurfang in Orgrimmar. He stands waiting for you in the Valley of Strength.",en={14720},l=60,n="The Lord of Blackrock",ps={7783},r=178,rl=60,sn={4949},x=9950}
T[7785]={d="Examine the Vessel of Rebirth and return it to Highlord Demitrian.",en={14347},l=60,n="Examine the Vessel",nx=7786,r=0,rl=60,si={19016},su=19016}
T[7786]={d="To free Thunderaan the Windseeker from his prison, you must present the right and left halves of the Bindings of the Windseeker, 10 bars of Elementium, and the Essence of the Firelord to Highlord Demitrian in Silithus.",en={14347},l=60,n="Thunderaan the Windseeker",nx=7787,ob={i={{17771},{19017},{18563},{18564}}},ps={7785},r=0,rl=60,sn={14347},tg=62,x=9950}
T[7787]={d="Present the Dormant Wind Kissed Blade to Highlord Demitrian.",en={14347},l=60,n="Rise, Thunderfury!",ps={7786},r=0,rl=60,si={19018},su=19018,x=9950}
T[7791]={en={14722},l=60,n="A Donation of Wool",ob={i={{2592}}},r=77,rl=12,sn={14722},x=660}
T[7792]={en={14725},l=60,n="A Donation of Wool",ob={i={{2592}}},r=77,rl=12,sn={14725},x=660}
T[7793]={en={14722},l=60,n="A Donation of Silk",ob={i={{4306}}},r=77,rl=26,sn={14722},x=1650}
T[7794]={en={14722},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=77,rl=40,sn={14722},x=3300}
T[7795]={en={14722},l=60,n="A Donation of Runecloth",nx=7796,ob={i={{14047}}},pg={7791,7793,7794},r=77,rl=50,sn={14722},x=6600}
T[7796]={en={14722},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7795},r=77,rl=50,sf=1,sn={14722}}
T[7798]={en={14725},l=60,n="A Donation of Silk",ob={i={{4306}}},r=77,rl=26,sn={14725},x=1650}
T[7799]={en={14725},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=77,rl=40,sn={14725},x=3300}
T[7800]={en={14725},l=60,n="A Donation of Runecloth",nx=7801,ob={i={{14047}}},pg={7792,7798,7799},r=77,rl=50,sn={14725},x=6600}
T[7801]={en={14725},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7800},r=77,rl=50,sf=1,sn={14725}}
T[7802]={en={14723},l=60,n="A Donation of Wool",ob={i={{2592}}},r=77,rl=12,sn={14723},x=660}
T[7803]={en={14723},l=60,n="A Donation of Silk",ob={i={{4306}}},r=77,rl=26,sn={14723},x=1650}
T[7804]={en={14723},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=77,rl=40,sn={14723},x=3300}
T[7805]={en={14723},l=60,n="A Donation of Runecloth",nx=7806,ob={i={{14047}}},pg={7802,7803,7804},r=77,rl=50,sn={14723},x=6600}
T[7806]={en={14723},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7805},r=77,rl=50,sf=1,sn={14723}}
T[7807]={en={14724},l=60,n="A Donation of Wool",ob={i={{2592}}},r=77,rl=12,sn={14724},x=660}
T[7808]={en={14724},l=60,n="A Donation of Silk",ob={i={{4306}}},r=77,rl=26,sn={14724},x=1650}
T[7809]={en={14724},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=77,rl=40,sn={14724},x=3300}
T[7810]={d="Speak with Short John Mithril in the Stranglethorn Arena.",en={14508},l=55,n="Arena Master",nx=7838,r=0,rl=1,si={18706},su=18706,tg=41,x=560}
T[7811]={en={14724},l=60,n="A Donation of Runecloth",nx=7812,ob={i={{14047}}},pg={7807,7808,7809},r=77,rl=50,sn={14724},x=6600}
T[7812]={en={14724},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7811},r=77,rl=50,sf=1,sn={14724}}
T[7813]={en={14729},l=60,n="A Donation of Wool",ob={i={{2592}}},r=178,rl=12,sn={14729},x=660}
T[7814]={en={14729},l=60,n="A Donation of Silk",ob={i={{4306}}},r=178,rl=26,sn={14729},x=1650}
T[7815]={d="Katoom the Angler at Revantusk Village in the Hinterlands wants you to kill 15 Saltwater Snapjaw turtles. Return to him when you have completed this task.",en={14740},l=50,n="Snapjaws, Mon!",ob={k={{2505}}},r=178,rl=44,sn={14740},x=4700}
T[7816]={d="Katoom the Angler at Revantusk Village in the Hinterlands wants you to kill Gammerita and retrieve Katoom's Best Lure from her corpse.",en={14740},l=48,n="Gammerita, Mon!",ob={i={{19023}}},r=178,rl=44,sn={14740},tg=1,x=4400}
T[7817]={en={14729},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=178,rl=40,sn={14729},x=3300}
T[7818]={en={14729},l=60,n="A Donation of Runecloth",nx=7819,ob={i={{14047}}},pg={7813,7814,7817},r=178,rl=50,sn={14729},x=6600}
T[7819]={en={14729},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7818},r=178,rl=50,sf=1,sn={14729}}
T[7820]={en={14728},l=60,n="A Donation of Wool",ob={i={{2592}}},r=178,rl=12,sn={14728},x=660}
T[7821]={en={14728},l=60,n="A Donation of Silk",ob={i={{4306}}},r=178,rl=26,sn={14728},x=1650}
T[7822]={en={14728},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=178,rl=40,sn={14728},x=3300}
T[7823]={en={14728},l=60,n="A Donation of Runecloth",nx=7825,ob={i={{14047}}},pg={7820,7821,7822},r=178,rl=50,sn={14728},x=6600}
T[7824]={en={14726},l=60,n="A Donation of Runecloth",nx=7832,ob={i={{14047}}},pg={7826,7827,7831},r=178,rl=50,sn={14726},x=6600}
T[7825]={en={14728},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7823},r=178,rl=50,sf=1,sn={14728}}
T[7826]={en={14726},l=60,n="A Donation of Wool",ob={i={{2592}}},r=178,rl=12,sn={14726},x=660}
T[7827]={en={14726},l=60,n="A Donation of Silk",ob={i={{4306}}},r=178,rl=26,sn={14726},x=1650}
T[7828]={d="Huntsman Markhor at Revantusk Village in the Hinterlands wants you to kill 10 Silvermane Stalkers and 10 Silvermane Howlers. Return to him once the task is complete.",en={14741},l=48,n="Stalking the Stalkers",ob={k={{2926},{2925}}},r=178,rl=44,sn={14741},x=4400}
T[7829]={d="Huntsman Markhor at Revantusk Village in the Hinterlands wants you to kill 20 Savage Owlbeasts. Return to him once the task is complete.",en={14741},l=48,n="Hunt the Savages",ob={k={{2929}}},r=178,rl=44,sn={14741},x=4400}
T[7830]={d="Huntsman Markhor at Revantusk Village in the Hinterlands wants you to kill a Razorbeak Skylord and retrieve its Skylord Plume. Return to him once the task is complete.",en={14741},l=48,n="Avenging the Fallen",ob={i={{19025}}},r=178,rl=44,sn={14741},x=4400}
T[7831]={en={14726},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=178,rl=40,sn={14726},x=3300}
T[7832]={en={14726},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7824},r=178,rl=50,sf=1,sn={14726}}
T[7833]={en={14727},l=60,n="A Donation of Wool",ob={i={{2592}}},r=178,rl=12,sn={14727},x=660}
T[7834]={en={14727},l=60,n="A Donation of Silk",ob={i={{4306}}},r=178,rl=26,sn={14727},x=1650}
T[7835]={en={14727},l=60,n="A Donation of Mageweave",ob={i={{4338}}},r=178,rl=40,sn={14727},x=3300}
T[7836]={en={14727},l=60,n="A Donation of Runecloth",nx=7837,ob={i={{14047}}},pg={7833,7834,7835},r=178,rl=50,sn={14727},x=6600}
T[7837]={en={14727},l=60,n="Additional Runecloth",ob={i={{14047}}},ps={7836},r=178,rl=50,sf=1,sn={14727}}
T[7838]={en={14508},l=55,n="Arena Grandmaster",ob={i={{18706}}},ps={7810},r=0,rl=1,sf=1,sn={14508},tg=41}
T[7839]={d="Smith Slagtree at Revantusk Village in the Hinterlands wants you to find Slagtree's Lost Tools. Return to him once this task is complete.",en={14737},l=48,n="Vilebranch Hooligans",ob={i={{19033}}},r=178,rl=44,sn={14737},x=4400}
T[7840]={d="Lard at Revantusk Village in the Hinterlands wants you to find Lard's Lunch. Return to him when this task is complete.",en={14731},l=49,n="Lard Lost His Lunch",ob={i={{19034}}},r=178,rl=44,sn={14731},x=4550}
T[7841]={d="Otho Moji'ko at Revantusk Village in the Hinterlands wants you to slaughter 15 Highvale Outrunners, 15 Highvale Scouts, 15 Highvale Marksman and 15 Highvale Rangers. Return to him when this task is complete.",en={14738},l=48,n="Message to the Wildhammer",nx=7842,ob={k={{2692},{2691},{2694},{2693}}},r=178,rl=44,sn={14738},tg=41,x=4400}
T[7842]={d="Otho Moji'ko at Revantusk Village in the Hinterlands wants you to bring him 10 Long Elegant Feathers from the gryphons that inhabit the Hinterlands. Return to him once this task is complete.",en={14738},l=48,n="Another Message to the Wildhammer",nx=7843,ob={i={{4589}}},ps={7841},r=178,rl=44,sn={14738},tg=41,x=5450}
T[7843]={d="Otho Moji'ko at Revantusk Village in the Hinterlands wants you to travel to Aerie Peak in the western region of the Hinterlands and place the Final Message to the Wildhammer by the well in the center of town. Return to him once this task is complete.",en={14738},l=50,n="The Final Message to the Wildhammer",ob={e={"Message to the Wildhammer Delivered",{{1425,14.3,48.1}}}},ps={7842},r=178,rl=44,sf=2,sn={14738},su=19036,tg=41,x=5900}
T[7844]={d="Mystic Yayo'jin at Revantusk Village in the Hinterlands wants you to kill 30 Vilebranch Scalpers and 15 Vilebranch Soothsayers. Return to her when this task is complete.",en={14739},l=48,n="Cannibalistic Cousins",ob={k={{4466},{4467}}},r=178,rl=44,sn={14739},x=4400}
T[7845]={d="Primal Torntusk at Revantusk Village in the Hinterlands wants you to rescue her mate, Elder Torntusk, from Jintha'alor.",en={14757},l=51,n="Kidnapped Elder Torntusk!",nx=7846,r=178,rl=46,sn={14736},tg=1,x=4900}
T[7846]={d="Elder Torntusk at Jintha'alor wants you to kill Hitah'ya the Keeper to get the Shackle Key to his bindings. Return to Elder Torntusk when you have recovered the key.",en={14757},l=51,n="Recover the Key!",nx=7847,ob={i={{19064}}},ps={7845},r=178,rl=46,sn={14757},tg=1,x=6100}
T[7847]={d="Elder Torntusk at Jintha'alor wants you to return to Primal Torntusk at Revantusk Village with news of his rescue.",en={14736},l=51,n="Return to Primal Torntusk",ps={7846},r=178,rl=46,sn={14757},tg=1,x=4900}
T[7848]={d="Venture to the Molten Core entry portal in Blackrock Depths and recover a Core Fragment. Return to Lothos Riftwaker in Blackrock Mountain when you have recovered the Core Fragment.",en={14387},l=60,n="Attunement to the Core",ob={i={{18412}}},r=0,rl=55,sn={14387},tg=81,x=6600,z=1584}
T[7849]={d="Huntsman Markhor at Revantusk Village in the Hinterlands wants you to recover his twin brother's remains. Find and return Huntsman Malkhor's Skull and Huntsman Malkhor's Bones to Huntsman Markhor.",en={14741},l=50,n="Separation Anxiety",ob={i={{19069},{19070}}},r=178,rl=46,sn={14741},tg=1,x=5900}
T[7850]={d="Primal Torntusk at Revantusk Village in the Hinterlands wants you to recover 10 Vessels of Tainted Blood from Jintha'alor. Return to Primal Torntusk when this task is complete.",en={14736},l=50,n="Dark Vessels",ob={i={{19071}}},r=178,rl=46,sn={14736},tg=1,x=5900}
T[7861]={d="You have been ordered to slay Vile Priestess Hexx and 20 Vilebranch Aman'zasi Guards. See Primal Torntusk at Revantusk Village in the Hinterlands once this task is complete.",en={14736},l=51,n="Wanted: Vile Priestess Hexx and Her Minions",ob={k={{7995},{2648}}},r=178,rl=46,so={179913},tg=1,x=6100}
T[7862]={d="You have been tasked with the decimation of 20 Vilebranch Berserkers, 20 Vilebranch Shadow Hunters, 20 Vilebranch Blood Drinkers, and 20 Vilebranch Soul Eaters.",en={14736},l=51,n="Job Opening: Guard Captain of Revantusk Village",ob={k={{2643},{2645},{2646},{2647}}},r=178,rl=46,so={179913},tg=1,x=6100}
T[7863]={en={14753},ex={7864,7865},l=34,n="Sentinel Basic Care Package",r=77,rl=25,rp={890,3000},sn={14753},x=270}
T[7864]={en={14753},ex={7863,7865},l=44,n="Sentinel Standard Care Package",r=77,rl=35,rp={890,3000},sn={14753},x=375}
T[7865]={en={14753},ex={7863,7864},l=60,n="Sentinel Advanced Care Package",r=77,rl=45,rp={890,3000},sn={14753},x=660}
T[7866]={en={14754},ex={7867,7868},l=34,n="Outrider Basic Care Package",r=178,rl=25,rp={889,3000},sn={14754},x=270}
T[7867]={en={14754},ex={7866,7868},l=44,n="Outrider Standard Care Package",r=178,rl=35,rp={889,3000},sn={14754},x=375}
T[7868]={en={14754},ex={7866,7867},l=60,n="Outrider Advanced Care Package",r=178,rl=45,rp={889,3000},sn={14754},x=660}
T[7877]={d="Return to the Athenaeum and find the Treasure of the Shen'dralar. Claim your reward!",eo={179517},l=60,n="The Treasure of the Shen'dralar",ps={7461},r=0,rl=56,sn={14358},tg=81,x=660,z=2557}
T[7907]={d="Return the Beast Deck to the Darkmoon Faire when it comes to town.",en={14847},l=55,n="Darkmoon Beast Deck",ob={i={{19228}}},r=0,rl=1,sf=1,si={19228},x=560}
T[7927]={d="Return the Portals Deck to the Darkmoon Faire when it comes to town.",en={14847},l=55,n="Darkmoon Portals Deck",ob={i={{19277}}},r=0,rl=1,sf=1,si={19277},x=560}
T[7928]={d="Return the Warlords Deck to the Darkmoon Faire when it comes to town.",en={14847},l=55,n="Darkmoon Warlords Deck",ob={i={{19257}}},r=0,rl=1,sf=1,si={19257},x=560}
T[7929]={d="Return the Elementals Deck to the Darkmoon Faire when it comes to town.",en={14847},l=55,n="Darkmoon Elementals Deck",ob={i={{19267}}},r=0,rl=1,sf=1,si={19267},x=560}
T[8041]={c=1,en={14902},l=60,n="Strength of Mount Mugamba",nx=8042,r=0,rl=60,rp={270,3000},sn={14902},tg=62,x=6600}
T[8042]={c=1,en={14902},l=60,n="Strength of Mount Mugamba",nx=8043,ob={i={{19574}}},ps={8041},r=0,rl=60,rp={270,9000},sn={14902},tg=62,x=6600}
T[8043]={c=1,en={14902},l=60,n="Strength of Mount Mugamba",nx=8044,ob={i={{19575}}},ps={8042},r=0,rl=60,rp={270,21000},sn={14902},tg=62,x=6600}
T[8044]={c=1,en={14902},l=60,n="The Rage of Mugamba",ob={i={{19576}}},ps={8043},r=0,rl=60,rp={270,42000},sn={14902},tg=62,x=6600}
T[8045]={c=2,en={14902},l=60,n="The Heathen's Brand",nx=8046,r=77,rl=60,rp={270,3000},sn={14902},tg=62,x=6600}
T[8046]={c=2,en={14902},l=60,n="The Heathen's Brand",nx=8047,ob={i={{19579}}},ps={8045},r=77,rl=60,rp={270,9000},sn={14902},tg=62,x=6600}
T[8047]={c=2,en={14902},l=60,n="The Heathen's Brand",nx=8048,ob={i={{19585}}},ps={8046},r=77,rl=60,rp={270,21000},sn={14902},tg=62,x=6600}
T[8048]={c=2,en={14902},l=60,n="The Hero's Brand",ob={i={{19586}}},ps={8047},r=77,rl=60,rp={270,42000},sn={14902},tg=62,x=6600}
T[8049]={c=16,en={14903},l=60,n="The Eye of Zuldazar",nx=8050,r=0,rl=60,rp={270,3000},sn={14903},tg=62,x=6600}
T[8050]={c=16,en={14903},l=60,n="The Eye of Zuldazar",nx=8051,ob={i={{19591}}},ps={8049},r=0,rl=60,rp={270,9000},sn={14903},tg=62,x=6600}
T[8051]={c=16,en={14903},l=60,n="The Eye of Zuldazar",nx=8052,ob={i={{19592}}},ps={8050},r=0,rl=60,rp={270,21000},sn={14903},tg=62,x=6600}
T[8052]={c=16,en={14903},l=60,n="The All-Seeing Eye of Zuldazar",ob={i={{19593}}},ps={8051},r=0,rl=60,rp={270,42000},sn={14903},tg=62,x=6600}
T[8053]={c=2,d="Bring Jin'rokh the Breaker Primal Hakkari Bindings. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14902},l=61,n="Paragons of Power: The Freethinker's Armguards",ob={i={{19716}}},r=0,rl=60,sn={14902},tg=62,x=3400}
T[8054]={c=2,d="Bring Jin'rokh the Breaker a Primal Hakkari Shawl. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14902},l=61,n="Paragons of Power: The Freethinker's Belt",ob={i={{19721}}},r=0,rl=60,sn={14902},tg=62,x=3400}
T[8055]={c=2,d="Bring Jin'rokh the Breaker a Primal Hakkari Tabard. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14902},l=61,n="Paragons of Power: The Freethinker's Breastplate",ob={i={{19722}}},r=0,rl=60,sn={14902},tg=62,x=3400}
T[8056]={c=64,d="Bring Maywiki of Zuldazar a Primal Hakkari Armsplint. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14904},l=60,n="Paragons of Power: The Augur's Bracers",ob={i={{19717}}},r=0,rl=60,sn={14904},tg=62,x=6600}
T[8057]={c=1024,d="Bring Maywiki of Zuldazar a Primal Hakkari Stanchion. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14904},l=60,n="Paragons of Power: The Haruspex's Bracers",ob={i={{19718}}},r=0,rl=60,sn={14904},tg=62,x=9950}
T[8058]={c=1,d="Bring Jin'rokh the Breaker a Primal Hakkari Armsplint. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14902},l=60,n="Paragons of Power: The Vindicator's Armguards",ob={i={{19717}}},r=0,rl=60,sn={14902},tg=62,x=6600}
T[8059]={c=256,d="Bring Al'tabim the All-Seeing a Primal Hakkari Stanchion. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Demoniac's Wraps",ob={i={{19718}}},r=0,rl=60,sn={14903},tg=62,x=9950}
T[8060]={c=128,d="Bring Al'tabim the All-Seeing Primal Hakkari Bindings. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Illusionist's Wraps",ob={i={{19716}}},r=0,rl=60,sn={14903},tg=62,x=6600}
T[8061]={c=16,d="Bring Al'tabim the All-Seeing a Primal Hakkari Stanchion. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Confessor's Wraps",ob={i={{19718}}},r=0,rl=60,sn={14903},tg=62,x=6600}
T[8062]={c=4,d="Bring the following Paragons of Power from Zul'Gurub to Falthir the Sightless: A Primal Hakkari Bindings. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14905},l=60,n="Paragons of Power: The Predator's Bracers",ob={i={{19716}}},r=0,rl=60,sn={14905},tg=62,x=9950}
T[8063]={c=8,d="Bring Falthir the Sightless a Primal Hakkari Armsplint. You must also have a reputation equal to or greater than Friendly with the Zandalar Tribe.",en={14905},l=60,n="Paragons of Power: The Madcap's Bracers",ob={i={{19717}}},r=0,rl=60,sn={14905},tg=62,x=6600}
T[8064]={c=1024,d="Bring Maywiki of Zuldazar a Primal Hakkari Sash. Maywiki of Zuldazar is located on Yojamba Isle, Stranglethorn Vale. You must also be Honored with Zandalar.",en={14904},l=60,n="Paragons of Power: The Haruspex's Belt",ob={i={{19720}}},r=0,rl=60,sn={14904},tg=62,x=6600}
T[8065]={c=1024,d="Bring Maywiki of Zuldazar a Primal Hakkari Tabard. Maywiki of Zuldazar is located on Yojamba Isle, Stranglethorn Vale. You must also be Revered with Zandalar.",en={14904},l=60,n="Paragons of Power: The Haruspex's Tunic",ob={i={{19722}}},r=0,rl=60,sn={14904},tg=62,x=9950}
T[8066]={c=4,d="Bring the following Paragons of Power from Zul'Gurub to Falthir the Sightless: A Primal Hakkari Shawl. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14905},l=60,n="Paragons of Power: The Predator's Belt",ob={i={{19721}}},r=0,rl=60,sn={14905},tg=62,x=9950}
T[8067]={c=4,d="Bring the following Paragons of Power from Zul'Gurub to Falthir the Sightless: A Primal Hakkari Aegis. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14905},l=60,n="Paragons of Power: The Predator's Mantle",ob={i={{19724}}},r=0,rl=60,sn={14905},tg=62,x=9950}
T[8068]={c=128,d="Bring Al'tabim the All-Seeing a Primal Hakkari Shawl. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Illusionist's Mantle",ob={i={{19721}}},r=0,rl=60,sn={14903},tg=62,x=9950}
T[8069]={c=128,d="Bring Al'tabim the All-Seeing a Primal Hakkari Kossack. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Illusionist's Robes",ob={i={{19723}}},r=0,rl=60,sn={14903},tg=62,x=9950}
T[8070]={c=16,d="Bring Al'tabim the All-Seeing a Primal Hakkari Sash. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Confessor's Bindings",ob={i={{19720}}},r=0,rl=60,sn={14903},tg=62,x=6600}
T[8071]={c=16,d="Bring Al'tabim the All-Seeing a Primal Hakkari Aegis. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Confessor's Mantle",ob={i={{19724}}},r=0,rl=60,sn={14903},tg=62,x=6600}
T[8072]={c=8,d="Bring Falthir the Sightless a Primal Hakkari Girdle. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14905},l=60,n="Paragons of Power: The Madcap's Mantle",ob={i={{19719}}},r=0,rl=60,sn={14905},tg=62,x=9950}
T[8073]={c=8,d="Bring Falthir the Sightless a Primal Hakkari Aegis. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14905},l=60,n="Paragons of Power: The Madcap's Tunic",ob={i={{19724}}},r=0,rl=60,sn={14905},tg=62,x=9950}
T[8074]={c=64,d="Bring Maywiki of Zuldazar a Primal Hakkari Girdle. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14904},l=60,n="Paragons of Power: The Augur's Belt",ob={i={{19719}}},r=0,rl=60,sn={14904},tg=62,x=6600}
T[8075]={c=64,d="Bring Maywiki of Zuldazar a Primal Hakkari Tabard. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14904},l=60,n="Paragons of Power: The Augur's Hauberk",ob={i={{19722}}},r=0,rl=60,sn={14904},tg=62,x=9950}
T[8076]={c=256,d="Bring Al'tabim the All-Seeing a Primal Hakkari Sash. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Demoniac's Mantle",ob={i={{19720}}},r=0,rl=60,sn={14903},tg=62,x=9950}
T[8077]={c=256,d="Bring Al'tabim the All-Seeing a Primal Hakkari Kossack. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14903},l=60,n="Paragons of Power: The Demoniac's Robes",ob={i={{19723}}},r=0,rl=60,sn={14903},tg=62,x=9950}
T[8078]={c=1,d="Bring Jin'rokh the Breaker a Primal Hakkari Girdle. You must also have a reputation equal to or greater than Honored with the Zandalar Tribe.",en={14902},l=60,n="Paragons of Power: The Vindicator's Belt",ob={i={{19719}}},r=0,rl=60,sn={14902},tg=62,x=9950}
T[8079]={c=1,d="Bring Jin'rokh the Breaker a Primal Hakkari Kossack. You must also have a reputation equal to or greater than Revered with the Zandalar Tribe.",en={14902},l=60,n="Paragons of Power: The Vindicator's Breastplate",ob={i={{19723}}},r=0,rl=60,sn={14902},tg=62,x=6600}
T[8101]={c=128,en={14903},l=60,n="The Pebble of Kajaro",nx=8102,r=0,rl=60,rp={270,3000},sn={14903},tg=62,x=6600}
T[8102]={c=128,en={14903},l=60,n="The Pebble of Kajaro",nx=8103,ob={i={{19598}}},ps={8101},r=0,rl=60,rp={270,9000},sn={14903},tg=62,x=6600}
T[8103]={c=128,en={14903},l=60,n="The Pebble of Kajaro",nx=8104,ob={i={{19599}}},ps={8102},r=0,rl=60,rp={270,21000},sn={14903},tg=62,x=6600}
T[8104]={c=128,en={14903},l=60,n="The Jewel of Kajaro",ob={i={{19600}}},ps={8103},r=0,rl=60,rp={270,42000},sn={14903},tg=62,x=6600}
T[8105]={d="Assault the mine, the lumber mill, the blacksmith and the farm, then return to Field Marshal Oslight in Refuge Pointe.",en={14983},ex={8166,8167,8168},l=55,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15003,"Farm Assaulted"}}},r=77,rl=50,sf=0,sn={14983},tg=41,x=5650}
T[8106]={c=256,en={14903},l=60,n="Kezan's Taint",nx=8107,r=0,rl=60,rp={270,3000},sn={14903},tg=62,x=6600}
T[8107]={c=256,en={14903},l=60,n="Kezan's Taint",nx=8108,ob={i={{19602}}},ps={8106},r=0,rl=60,rp={270,9000},sn={14903},tg=62,x=6600}
T[8108]={c=256,en={14903},l=60,n="Kezan's Taint",nx=8109,ob={i={{19603}}},ps={8107},r=0,rl=60,rp={270,21000},sn={14903},tg=62,x=6600}
T[8109]={c=256,en={14903},l=60,n="Kezan's Unstoppable Taint",ob={i={{19604}}},ps={8108},r=0,rl=60,rp={270,42000},sn={14903},tg=62,x=6600}
T[8110]={c=1024,en={14904},l=60,n="Enchanted South Seas Kelp",nx=8111,r=0,rl=60,rp={270,3000},sn={14904},tg=62,x=6600}
T[8111]={c=1024,en={14904},l=60,n="Enchanted South Seas Kelp",nx=8112,ob={i={{19610}}},ps={8110},r=0,rl=60,rp={270,9000},sn={14904},tg=62,x=6600}
T[8112]={c=1024,en={14904},l=60,n="Enchanted South Seas Kelp",nx=8113,ob={i={{19611}}},ps={8111},r=0,rl=60,rp={270,21000},sn={14904},tg=62,x=6600}
T[8113]={c=1024,en={14904},l=60,n="Pristine Enchanted South Seas Kelp",ob={i={{19612}}},ps={8112},r=0,rl=60,rp={270,42000},sn={14904},tg=62,x=6600}
T[8114]={d="Enter Arathi Basin, capture and control four bases at the same time, and then return to Field Marshal Oslight at Refuge Pointe.",en={14983},l=60,n="Control Four Bases",ob={e={"Control Four Bases.",{{1417,46,45.3}}}},r=77,rl=60,rp={509,3000},sf=2,sn={14983},tg=41,x=9950}
T[8115]={d="Control 5 bases in Arathi Basin at the same time, then return to Field Marshal Oslight at Refuge Pointe.",en={14983},l=60,n="Control Five Bases",ob={e={"Take Five Bases.",{{1417,46,45.3}}}},r=77,rl=60,rp={509,42000},sf=2,sn={14983},tg=41,x=9950}
T[8116]={c=64,en={14904},l=60,n="Vision of Voodress",nx=8117,r=178,rl=60,rp={270,3000},sn={14904},tg=62,x=6600}
T[8117]={c=64,en={14904},l=60,n="Vision of Voodress",nx=8118,ob={i={{19606}}},ps={8116},r=178,rl=60,rp={270,9000},sn={14904},tg=62,x=6600}
T[8118]={c=64,en={14904},l=60,n="Vision of Voodress",nx=8119,ob={i={{19607}}},ps={8117},r=178,rl=60,rp={270,21000},sn={14904},tg=62,x=6600}
T[8119]={c=64,en={14904},l=60,n="The Unmarred Vision of Voodress",ob={i={{19608}}},ps={8118},r=178,rl=60,rp={270,42000},sn={14904},tg=62,x=6600}
T[8120]={d="Assault the Arathi Basin mine, lumber mill, blacksmith and stable, and then return to Deathmaster Dwire in Hammerfall.",en={15021},ex={8169,8170,8171},l=55,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15001,"Stable Assaulted"}}},r=178,rl=50,sf=0,sn={15021},tg=41,x=5650}
T[8121]={d="Hold four bases at the same time in Arathi Basin, and then return to Deathmaster Dwire in Hammerfall.",en={15021},l=60,n="Take Four Bases",ob={e={"Hold Four Bases.",{{1417,73.7,29.5},{1421,39.7,17.8},{1454,50.1,69},{1456,40.4,51.6}}}},r=178,rl=60,rp={510,3000},sf=2,sn={15021},tg=41,x=9950}
T[8122]={d="Hold five bases in Arathi Basin at the same time, then return to Deathmaster Dwire in Hammerfall.",en={15021},l=60,n="Take Five Bases",ob={e={"Hold Five Bases.",{{1417,73.7,29.5},{1421,39.7,17.8},{1454,50.1,69},{1456,40.4,51.6}}}},r=178,rl=60,rp={510,42000},sf=2,sn={15021},tg=41,x=9950}
T[8141]={c=8,en={14905},l=60,n="Zandalarian Shadow Talisman",nx=8142,r=0,rl=60,rp={270,3000},sn={14905},tg=62,x=6600}
T[8142]={c=8,en={14905},l=60,n="Zandalarian Shadow Talisman",nx=8143,ob={i={{19614}}},ps={8141},r=0,rl=60,rp={270,9000},sn={14905},tg=62,x=6600}
T[8143]={c=8,en={14905},l=60,n="Zandalarian Shadow Talisman",nx=8144,ob={i={{19615}}},ps={8142},r=0,rl=60,rp={270,21000},sn={14905},tg=62,x=6600}
T[8144]={c=8,en={14905},l=60,n="Zandalarian Shadow Mastery Talisman",ob={i={{19616}}},ps={8143},r=0,rl=60,rp={270,42000},sn={14905},tg=62,x=6600}
T[8145]={c=4,en={14905},l=60,n="The Maelstrom's Tendril",nx=8146,r=0,rl=60,rp={270,3000},sn={14905},tg=62,x=6600}
T[8146]={c=4,en={14905},l=60,n="The Maelstrom's Tendril",nx=8147,ob={i={{19618}}},ps={8145},r=0,rl=60,rp={270,9000},sn={14905},tg=62,x=6600}
T[8147]={c=4,en={14905},l=60,n="The Maelstrom's Tendril",nx=8148,ob={i={{19619}}},ps={8146},r=0,rl=60,rp={270,21000},sn={14905},tg=62,x=6600}
T[8148]={c=4,en={14905},l=60,n="Maelstrom's Wrath",ob={i={{19620}}},ps={8147},r=0,rl=60,rp={270,42000},sn={14905},tg=62,x=6600}
T[8151]={c=4,d="Speak to Ogtinc in Azshara.",en={8405},l=52,n="The Hunter's Charm",nx=8153,r=0,rl=50,sn={3039,3352,4205,5116,5516},x=510}
T[8153]={c=4,d="Bring a pair of Perfect Courser Antlers to Ogtinc in Azshara. Ogtinc resides atop the cliffs northeast of the Ruins of Eldarath.",en={8405},l=52,n="Courser Antlers",nx=8231,ob={i={{20017}}},ps={8151},r=0,rl=50,sn={8405},x=5100}
T[8166]={d="Assault the mine, the lumber mill, the blacksmith and the farm, then return to Field Marshal Oslight in Refuge Pointe.",en={14983},ex={8105,8167,8168},l=45,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15003,"Farm Assaulted"}}},r=77,rl=40,sf=0,sn={14983},tg=41,x=3900}
T[8167]={d="Assault the mine, the lumber mill, the blacksmith and the farm, then return to Field Marshal Oslight in Refuge Pointe.",en={14983},ex={8105,8166,8168},l=35,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15003,"Farm Assaulted"}}},r=77,rl=30,sf=0,sn={14983},tg=41,x=2750}
T[8168]={d="Assault the mine, the lumber mill, the blacksmith and the farm, then return to Field Marshal Oslight in Refuge Pointe.",en={14983},ex={8105,8166,8167},l=25,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15003,"Farm Assaulted"}}},r=77,rl=20,sf=0,sn={14983},tg=41,x=2000}
T[8169]={d="Assault the Arathi Basin mine, lumber mill, blacksmith and stable, and then return to Deathmaster Dwire in Hammerfall.",en={15021},ex={8120,8170,8171},l=45,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15001,"Stable Assaulted"}}},r=178,rl=40,sf=0,sn={15021},tg=41,x=3900}
T[8170]={d="Assault the Arathi Basin mine, lumber mill, blacksmith and stable, and then return to Deathmaster Dwire in Hammerfall.",en={15021},ex={8120,8169,8171},l=35,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15001,"Stable Assaulted"}}},r=178,rl=30,sf=0,sn={15021},tg=41,x=2750}
T[8171]={d="Assault the Arathi Basin mine, lumber mill, blacksmith and stable, and then return to Deathmaster Dwire in Hammerfall.",en={15021},ex={8120,8169,8170},l=25,n="The Battle for Arathi Basin!",ob={k={{15005,"Mine Assaulted"},{15004,"Lumber Mill Assaulted"},{15002,"Blacksmith Assaulted"},{15001,"Stable Assaulted"}}},r=178,rl=20,sf=0,sn={15021},tg=41,x=2000}
T[8181]={d="Speak with Yeh'kinya.",en={8579},l=58,n="Confront Yeh'kinya",nx=8182,ps={4788},r=0,rl=40,sn={10460},tg=62,x=6200}
T[8182]={d="Speak with Molthor in Stranglethorn.",en={14875},l=58,n="The Hand of Rastakhan",ps={8181},r=0,rl=40,sn={10460},tg=62,x=9300}
T[8183]={d="Bring the Heart of Hakkar to Molthor on Yojamba Isle.",en={14875},l=60,n="The Heart of Hakkar",r=0,rl=58,si={19802},su=19802,x=9950}
T[8184]={c=1,en={15042},l=60,n="Presence of Might",ob={i={{22637},{19813}}},r=0,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8185]={c=2,en={15042},l=60,n="Syncretist's Sigil",ob={i={{22637},{19815}}},r=77,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8186]={c=8,en={15042},l=60,n="Death's Embrace",ob={i={{22637},{19814}}},r=0,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8187]={c=4,en={15042},l=60,n="Falcon's Call",ob={i={{22637},{19816}}},r=0,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8188]={c=64,en={15042},l=60,n="Vodouisant's Vigilant Embrace",ob={i={{22637},{19817}}},r=178,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8189]={c=128,en={15042},l=60,n="Presence of Sight",ob={i={{22637},{19818}}},r=0,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8190]={c=256,en={15042},l=60,n="Hoodoo Hex",ob={i={{22637},{19819}}},r=0,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8191]={c=16,en={15042},l=60,n="Prophetic Aura",ob={i={{22637},{19820}}},r=0,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8192]={c=1024,en={15042},l=60,n="Animist's Caress",ob={i={{22637},{19821}}},r=0,rl=58,rp={270,3000},sf=1,sn={15042},tg=62}
T[8193]={en={15077},l=60,n="Master Angler",ob={i={{19807}}},r=0,rl=1,sf=1,sk={},sn={15077}}
T[8194]={en={15078},l=60,n="Apprentice Angler",ob={i={{19807}}},r=0,rl=1,sf=1,sk={},sn={15078},x=0}
T[8195]={en={15070},l=60,n="Zulian, Razzashi, and Hakkari Coins",ob={i={{19698},{19699},{19700}}},r=0,rl=58,sf=1,sn={15070}}
T[8196]={en={14921},l=60,n="Essence Mangoes",ob={i={{19858}}},r=0,rl=58,rp={270,9000},sf=1,sn={14921}}
T[8201]={d="String 5 Channeler's Heads, then return the Collection of Troll Heads to Exzhal on Yojamba Isle.",en={14910},l=60,n="A Collection of Heads",ob={i={{19880}}},r=0,rl=58,rs={19881},sn={14910},su=19883,tg=62,x=9950}
T[8221]={en={15079},l=60,n="Rare Fish - Keefer's Angelfish",ob={i={{19805}}},r=0,rl=1,sf=1,sk={},sn={15079}}
T[8224]={en={15079},l=60,n="Rare Fish - Dezian Queenfish",ob={i={{19806}}},r=0,rl=1,sf=1,sk={},sn={15079}}
T[8225]={en={15079},l=60,n="Rare Fish - Brownell's Blue Striped Racer",ob={i={{19803}}},r=0,rl=1,sf=1,sk={},sn={15079}}
T[8227]={d="Return Nat's Measuring Tape to Nat Pagle in Dustwallow Marsh.",en={12919},l=60,n="Nat's Measuring Tape",r=0,rl=58,si={19973},so={180366},su=19973,tg=62,x=660}
T[8228]={en={15116},l=60,n="Could I get a Fishing Flier?",r=178,rl=35,sf=1,sk={356,175},sn={15116}}
T[8229]={en={15119},l=60,n="Could I get a Fishing Flier?",r=77,rl=35,sf=1,sk={356,175},sn={15119}}
T[8231]={c=4,d="Bring 6 Wavethrasher Scales to Ogtinc in Azshara. Ogtinc resides atop the cliffs northeast the Ruins of Eldarath.",en={8405},l=52,n="Wavethrashing",nx=8232,ob={i={{20087}}},ps={8153},r=0,rl=50,sn={8405},x=5100}
T[8232]={c=4,d="Bring the Tooth of Morphaz to Ogtinc in Azshara. Ogtinc resides atop the cliffs northeast the Ruins of Eldarath.",en={8405},l=52,n="The Green Drake",ob={i={{20019}}},ps={8231},r=0,rl=50,sn={8405},tg=81,x=6350,z=1477}
T[8233]={c=8,d="Speak with Lord Jorach Ravenholdt in Ravenholdt Manor.",en={6768},l=52,n="A Simple Request",nx=8234,r=0,rl=50,sn={918,3328,4163,4583,5165,5167},x=510}
T[8234]={c=8,d="Retrieve the Sealed Azure Bag from the Timbermaw Shaman in Azshara. Then take the bag to Archmage Xylem, also found in Azshara.",en={8379},l=52,n="Sealed Azure Bag",nx=8235,ob={i={{19775}}},r=0,rl=50,sn={6768},x=5100}
T[8235]={c=8,d="Bring 10 Encoded Fragments to Archmage Xylem in Azshara.",en={8379},l=52,n="Encoded Fragments",nx=8236,ob={i={{20023}}},ps={8234},r=0,rl=50,sn={8379},x=5100}
T[8236]={c=8,d="Return the Azure Key to Lord Jorach Ravenholdt.",en={6768},l=52,n="The Azure Key",ob={i={{20022}}},ps={8235},r=0,rl=50,sn={8379},tg=81,x=6350,z=1477}
T[8238]={en={15070},l=60,n="Gurubashi, Vilebranch, and Witherbark Coins",ob={i={{19701},{19702},{19703}}},r=0,rl=58,sf=1,sn={15070}}
T[8239]={en={15070},l=60,n="Sandfury, Skullsplitter, and Bloodscalp Coins",ob={i={{19704},{19705},{19706}}},r=0,rl=58,sf=1,sn={15070}}
T[8240]={d="Destroy any one of the Hakkari Bijous found in Zul'Gurub at the Altar of Zanza on Yojamba Isle. When done, speak with Vinchaxa nearby.",en={15070},l=60,n="A Bijou for Zanza",r=0,rl=58,rs={19707,19708,19709,19710,19711,19712,19713,19714,19715},sf=2,sn={15070},x=9950}
T[8241]={en={14624},l=60,n="Restoring Fiery Flux Supplies via Iron",ob={i={{18944},{3575},{3857}}},ps={7722},r=0,rl=45,rp={59,1},sf=1,sn={14624}}
T[8242]={en={14624},l=60,n="Restoring Fiery Flux Supplies via Heavy Leather",ob={i={{18944},{4234},{3857}}},ps={7722},r=0,rl=45,rp={59,1},sf=1,sn={14624}}
T[8243]={en={14921},l=60,n="Zanza's Potent Potables",ob={i={{19858}}},r=0,rl=58,rp={270,21000},sf=1,sn={14921}}
T[8246]={en={14921},l=60,n="Signets of the Zandalar",ob={i={{19858}}},r=0,rl=58,rp={270,42000},sf=1,sn={14921}}
T[8249]={c=0,en={6707},l=60,n="Junkboxes Needed",ob={i={{16885}}},r=0,rl=50,sf=1,sn={6707}}
T[8250]={c=128,d="Seek out Sanath Lim-yo and gain passage to see Archmage Xylem.",en={8395},l=52,n="Magecraft",r=0,rl=50,sn={331,3047,4567,7311,7312},x=510}
T[8251]={c=128,d="Bring 10 Glittering Dust to Archmage Xylem.",en={8379},l=52,n="Magic Dust",nx=8252,ob={i={{20028}}},r=0,rl=50,sn={8379},x=5100}
T[8252]={c=128,d="Collect 6 Enchanted Coral and return them to Archmage Xylem.",en={8379},l=52,n="The Siren's Coral",nx=8253,ob={i={{20029}}},ps={8251},r=0,rl=50,sn={8379},x=5100}
T[8253]={c=128,d="Retrieve the Arcane Shard from Morphaz and return to Archmage Xylem.",en={8379},l=52,n="Destroy Morphaz",ob={i={{20085}}},ps={8252},r=0,rl=50,sn={8379},tg=81,x=6350,z=1477}
T[8254]={c=16,d="Seek out Ogtinc in Azshara.",en={8405},l=52,n="Cenarion Aid",nx=8255,r=0,rl=50,sn={3045,5489,6018,11406},x=510}
T[8255]={c=16,d="Acquire 4 Healthy Courser Glands and bring them to Ogtinc in Azshara. Ogtinc resides atop the cliffs northeast the Ruins of Eldarath.",en={8405},l=52,n="Of Coursers We Know",nx=8256,ob={i={{20027}}},ps={8254},r=0,rl=50,sn={8405},x=5100}
T[8256]={c=16,d="Acquire an Ichor of Undeath for Ogtinc in Azshara. Ogtinc resides atop the cliffs northeast the Ruins of Eldarath.",en={8405},l=52,n="The Ichor of Undeath",nx=8257,ob={i={{7972}}},ps={8255},r=0,rl=50,sn={8405},x=5100}
T[8257]={c=16,d="Kill Morphaz in the sunken temple of Atal'Hakkar, and return his blood to Greta Mosshoof in Felwood. The entrance to the sunken temple can be found in the Swamp of Sorrows.",en={10922},l=52,n="Blood of Morphaz",ob={i={{20025}}},ps={8256},r=0,rl=50,sn={8405},tg=81,x=6350,z=1477}
T[8258]={c=64,d="Use the Divination Scryer in the heart of the Great Ossuary's basement in the Scholomance. Doing so will bring forth spirits you must fight. Defeating these spirits will summon forth Death Knight Darkreaver; defeat him.",en={13417},ex={7668},l=60,n="The Darkreaver Menace",ob={i={{18880}}},ps={7667},r=178,rl=60,sn={13417},su=18746,tg=81,x=9950,z=2057}
T[8260]={en={15127},ex={8261,8262},l=34,n="Arathor Basic Care Package",r=77,rl=25,rp={509,3000},sn={15127},tg=41,x=270}
T[8261]={en={15127},ex={8260,8262},l=44,n="Arathor Standard Care Package",r=77,rl=35,rp={509,3000},sn={15127},tg=41,x=375}
T[8262]={en={15127},ex={8260,8261},l=60,n="Arathor Advanced Care Package",r=77,rl=45,rp={509,3000},sn={15127},tg=41,x=660}
T[8263]={en={15126},ex={8264,8265},l=34,n="Defiler's Basic Care Package",r=178,rl=25,rp={510,3000},sn={15126},tg=41,x=270}
T[8264]={en={15126},ex={8263,8265},l=44,n="Defiler's Standard Care Package",r=178,rl=35,rp={510,3000},sn={15126},tg=41,x=375}
T[8265]={en={15126},ex={8263,8264},l=60,n="Defiler's Advanced Care Package",r=178,rl=45,rp={510,3000},sn={15126},tg=41,x=660}
T[8271]={en={13816},l=60,n="Hero of the Stormpike",ps={7141},r=77,rl=51,sn={13816},tg=41,x=660}
T[8272]={en={13817},l=60,n="Hero of the Frostwolf",ps={7142},r=178,rl=51,sn={13817},tg=41,x=660}
T[8273]={en={7825},l=47,n="Oran's Gratitude",ps={2782},r=178,rl=42,sn={7825},x=4200}
T[8275]={d="Talk to Windcaller Proudhorn at Cenarion Hold in Silithus.",en={15191},l=55,n="Taking Back Silithus",nx=8280,r=77,rl=54,sn={15187},x=2800}
T[8276]={d="Talk to Windcaller Proudhorn at Cenarion Hold in Silithus.",en={15191},l=55,n="Taking Back Silithus",nx=8280,r=178,rl=54,sn={15188},x=2800}
T[8277]={d="Beetix Ficklespragg at Cenarion Hold in Silithus wants you to gather 8 Stonelash Scorpid Stingers and 8 Sand Skitterer Fangs. Return to her when you have completed the task.",en={15189},l=55,n="Deadly Desert Venom",nx=8278,ob={i={{20373},{20376}}},r=0,rl=54,sn={15189},x=5650}
T[8278]={d="Beetix Ficklespragg at Cenarion Hold in Silithus wants you to gather 3 Stonelash Pincer Stingers, 3 Stonelash Flayer Stingers and 3 Rock Stalker Fangs.",en={15189},l=57,n="Noggle's Last Hope",nx=8282,ob={i={{20375},{20374},{20377}}},ps={8277},r=0,rl=54,sn={15189},x=6000}
T[8279]={d="Bring the three chapters of the Twilight Lexicon to Hermit Ortell in Silithus.",en={15194},l=60,n="The Twilight Lexicon",nx=8287,ob={i={{20394},{20395},{20396}}},ps={8285},r=0,rl=54,sn={15194},x=8300}
T[8280]={d="Windcaller Proudhorn at Cenarion Hold in Silithus wants you to kill 15 Dredge Strikers.",en={15191},l=55,n="Securing the Supply Lines",nx=8281,ob={k={{11740}}},r=0,rl=54,sn={15191},x=5650}
T[8281]={d="Windcaller Proudhorn at Cenarion Hold in Silithus wants you to slay 20 Dredge Crushers.",en={15191},l=57,n="Stepping Up Security",ob={k={{11741}}},ps={8280},r=0,rl=54,sn={15191},x=6000}
T[8282]={d="Retrieve Noggle's Satchel from the mountains in the south of Silithus and return it to him at Cenarion Hold.",en={15190},l=58,n="Noggle's Lost Satchel",ob={i={{20379}}},ps={8278},r=0,rl=54,sn={15190},x=6200}
T[8283]={d="Bring Deathclasp's Pincer to Vish Kozus, Captain of the Guard.",en={15182},l=59,n="Wanted - Deathclasp, Terror of the Sands",ob={i={{20385}}},r=0,rl=54,so={180448},tg=1,x=8050}
T[8284]={d="Geologist Larksbane at Cenarion Hold in Silithus wants you to collect 8 Twilight Tablet Fragments.",en={15183},l=58,n="The Twilight Mystery",nx=8285,ob={i={{20378}}},r=0,rl=54,sn={15183},x=6200}
T[8285]={d="Take the restored tablet to Hermit Ortell in Silithus.",en={15194},l=59,n="The Deserter",nx=8279,ps={8284},r=0,rl=54,sn={15183},su=20401,x=4800}
T[8286]={d="Venture to the Caverns of Time in Tanaris and find Anachronos, Brood of Nozdormu.",en={15180},l=60,n="What Tomorrow Brings",nx=8288,ob={e={"Discover the Brood of Nozdormu.",{{1446,64.6,50.4}}},k={{15192}}},r=0,rl=60,sf=2,sn={15180},x=6600}
T[8287]={d="Take the Decoded Tablet Parchment to Commander Mar'alith.",en={15181},l=60,n="A Terrible Purpose",ps={8279},r=0,rl=54,sn={15194},su=20405,x=6600}
T[8288]={d="Return the Head of the Broodlord Lashlayer to Baristolth of the Shifting Sands at Cenarion Hold in Silithus.",en={15180},l=60,n="Only One May Rise",nx=8301,ob={i={{20383}}},ps={8286},r=0,rl=60,sn={15180},tg=62,x=6600}
T[8301]={d="Collect 200 Silithid Carapace Fragments and return to Baristolth.",en={15180},l=60,n="The Path of the Righteous",nx=8303,ob={i={{20384}}},ps={8288},r=0,rl=60,sn={15180},su=20402,tg=1,x=6600}
T[8302]={d="Collect 200 Silithid Carapace Fragments and return to Baristolth.",en={15180},l=60,n="The Hand of the Righteous",ob={i={{20384}}},ps={8301},r=0,rl=60,sf=1,sn={15180},tg=1,x=660}
T[8303]={d="Seek out Anachronos at the Caverns of Time in Tanaris.",en={15192},l=60,n="Anachronos",nx=8305,ps={8301},r=0,rl=60,rp={910,0},sn={15180},su=20415}
T[8304]={d="Commander Mar'alith at Cenarion Hold in Silithus wants you to question the inhabitants of Bronzebeard's Encampment. You will find Bronzebeard's Encampment south of Cenarion Hold.",en={15181},l=60,n="Dearest Natalia",nx=8306,ob={k={{15171},{15170}}},r=0,rl=58,sn={15181},tg=1,x=6600}
T[8305]={d="Locate the Crystalline Tear in Silithus and gaze into its depths.",eo={180633},l=60,n="Long Forgotten Memories",nx=8519,ps={8303},r=0,rl=60,rp={910,0},sf=2,sn={15192},x=6600}
T[8306]={d="Commander Mar'alith at Cenarion Hold in Silithus wants you to find his beloved Natalia. The information that you gathered points to Hive'Regal in the south as being the area in which you may find Mistress Natalia Mar'alith.",en={15181},l=60,n="Into The Maw of Madness",ob={k={{15215,"The Fate of Mistress Natalia Mar'alith"}}},ps={8304},r=0,rl=58,sn={15181},tg=1,x=9950}
T[8307]={d="Look for information about cooking Sandworm Meat at the Twilight's Hammer camp west of Cenarion Hold.",eo={180503},l=57,n="Desert Recipe",nx=8313,r=0,rl=54,sk={185,285},sn={15174},x=3000}
T[8308]={d="Take Brann Bronzebeard's Letter to Bronzebeard's Encampment in southern Silithus.",en={15170},l=60,n="Brann Bronzebeard's Lost Letter",r=0,rl=58,si={20461},su=20461,tg=1,x=8300}
T[8309]={d="Rutgar Glyphshaper at Bronzebeard's Encampment in Silithus wants you to venture to Hive'Ashi, Hive'Zora, and Hive'Regal and recover Glyphed Rubbings from the Glyphed Crystals of each hive.",en={15170},l=60,n="Glyph Chasing",ob={i={{20455},{20454},{20456}}},ps={8304},r=0,rl=58,sn={15170},su=20453,tg=1,x=8300}
end)()
;(function() local T = D.Q
T[8310]={d="Frankal Stonebridge at Bronzebeard's Encampment in Silithus wants you to recover a Hive'Zora Silithid Brain, Hive'Ashi Silithid Brain, and a Hive'Regal Silithid Brain. Return to Frankal when you have completed this task.",en={15171},l=60,n="Breaking the Code",ob={i={{20457},{20458},{20459}}},ps={8304},r=0,rl=58,sn={15171},tg=1,x=8300}
T[8313]={d="Bring the Torn Recipe Page to Calandrath at the inn in Cenarion Hold.",en={15174},l=57,n="Sharing the Knowledge",nx=8317,ps={8307},r=0,rl=54,sk={185,285},so={180503},su=20467,x=6000}
T[8314]={d="Rutgar Glyphshaper at Bronzebeard's Encampment wants you to deliver the Glyphed Crystal Prism to Geologist Larksbane at the Cenarion Hold in Silithus.",en={15183},l=60,n="Unraveling the Mystery",nx=8315,pg={8309,8310},r=0,rl=58,sf=0,sn={15170},su=20463,tg=1,x=4950}
T[8315]={d="Geologist Larksbane at Cenarion Hold in Silithus wants you to recover the Crystal Unlocking Mechanism from the Qiraji Emissary.",en={15183},l=60,n="The Calling",ob={i={{20465}}},ps={8314},r=0,rl=58,sn={15183},su=20464,tg=62,x=9950}
T[8316]={c=1,en={15183},l=60,n="Armaments of War",ps={8315},r=0,rl=58,sn={15183},tg=62,x=6600}
T[8317]={d="Calandrath at Cenarion Hold needs a batch of 10 Smoked Desert Dumplings.",en={15174},l=57,n="Kitchen Assistance",ob={i={{20452}}},ps={8313},r=0,rl=54,rs={20424},sk={185,285},sn={15174},x=3000}
T[8318]={d="Bring 10 Encrypted Twilight Texts to Bor Wildmane in Cenarion Hold.",en={15306},l=60,n="Secret Communication",nx=8319,ob={i={{20404}}},r=0,rl=57,sn={15306},x=6600}
T[8319]={en={15306},l=60,n="Encrypted Twilight Texts",ob={i={{20404}}},ps={8318},r=0,rl=57,sf=1,sn={15306}}
T[8320]={d="Kill 10 Twilight Geolords, then return to Huum Wildmane in Cenarion Hold.",en={15270},l=60,n="Twilight Geolords",nx=8321,ob={k={{11881}}},r=0,rl=60,sn={15270},x=6600}
T[8321]={d="Bring Vyral's Signet Ring to Huum Wildmane in Cenarion Hold.",en={15270},l=60,n="Vyral the Vile",ob={i={{20466}}},ps={8320},r=0,rl=60,sn={15270},x=6600}
T[8323]={d="Hermit Ortell wants you to bring him 10 Encrypted Twilight Texts",en={15194},l=59,n="True Believers",nx=8324,ob={i={{20404}}},ps={8279},r=0,rl=54,sn={15194},x=6400}
T[8324]={en={15194},l=59,n="Still Believing",ob={i={{20404}}},ps={8323},r=0,rl=54,sf=1,sn={15194}}
T[8331]={d="Speak with Aurel Goldleaf in Cenarion Hold.",en={15282},l=60,n="Aurel Goldleaf",nx=8332,r=0,rl=60,rp={609,3000},sn={15270},tg=1,x=660}
T[8332]={d="Bring 1 Large Brilliant Shard and 3 Abyssal Crests to Aurel Goldleaf in Cenarion Hold.",en={15282},l=60,n="Dukes of the Council",nx=8349,ob={i={{14344},{20513}}},r=0,rl=60,rp={609,3000},sn={15282},tg=1,x=6600}
T[8333]={en={15282},l=60,n="Medallion of Station",ob={i={{14344},{20513}}},ps={8332},r=0,rl=60,rp={609,3000},sf=1,sn={15282},x=6600}
T[8341]={d="Bring 5 Large Brilliant Shards and 3 Abyssal Signets to Aurel Goldleaf in Cenarion Hold.",en={15282},l=60,n="Lords of the Council",nx=8351,ob={i={{14344},{20514}}},r=0,rl=60,rp={609,21000},sn={15282},tg=1,x=6600}
T[8342]={en={15282},l=60,n="Twilight Ring of Lordship",ob={i={{20514},{14344}}},ps={8341},r=0,rl=60,rp={609,21000},sf=1,sn={15282}}
T[8343]={d="Speak with Aurel Goldleaf in Cenarion Hold.",en={15282},l=60,n="Goldleaf's Discovery",nx=8341,r=0,rl=60,rp={609,21000},sn={15270},x=660}
T[8348]={d="Bring the Abyssal Signet to Bor Wildmane in Cenarion Hold.",en={15306},l=60,n="Signet of the Dukes",nx=8363,ob={i={{20514}}},ps={8332},r=0,rl=60,rp={609,3000},sn={15306},tg=1,x=8300}
T[8349]={d="Speak with Bor Wildmane in Cenarion Hold.",en={15306},l=60,n="Bor Wildmane",nx=8348,ps={8332},r=0,rl=60,rp={609,3000},sn={15282},tg=1,x=660}
T[8351]={d="Speak with Bor Wildmane in Cenarion Hold.",en={15306},l=60,n="Bor Wishes to Speak",nx=8352,ps={8341},r=0,rl=60,rp={609,21000},sn={15282},tg=62,x=660}
T[8352]={d="Bring an Abyssal Scepter to Bor Wildmane in Cenarion Hold.",en={15306},l=60,n="Scepter of the Council",nx=8364,ob={i={{20515}}},ps={8341},r=0,rl=60,rp={609,21000},sn={15306},tg=62,x=9950}
T[8361]={d="Bor Wildmane at Cenarion Hold in Silithus wants you to destroy an Abyssal Templar and bring him an Abyssal Crest as proof of the deed.",en={15306},l=60,n="Abyssal Contacts",nx=8362,ob={i={{20513}}},r=0,rl=60,sn={15306},tg=1,x=6600}
T[8362]={en={15306},l=60,n="Abyssal Crests",ob={i={{20513}}},ps={8361},r=0,rl=60,sf=1,sn={15306},tg=1}
T[8363]={en={15306},l=60,n="Abyssal Signets",ob={i={{20514}}},ps={8348},r=0,rl=60,rp={609,3000},sf=1,sn={15306},tg=1}
T[8364]={en={15306},l=60,n="Abyssal Scepters",ob={i={{20515}}},ps={8352},r=0,rl=60,rp={609,21000},sf=1,sn={15306},tg=62,x=3300}
T[8365]={d="Haughty Modiste wants you to collect 20 Southsea Pirate Hats and return them to her at Steamwheedle Port in Tanaris.",en={15165},l=45,n="Pirate Hats Ahoy!",ob={i={{20519}}},r=0,rl=40,sn={15165},x=3900}
T[8366]={d="Security Chief Bilgewhizzle of Steamwheedle Port in Tanaris wants you to kill 10 Southsea Pirates, 10 Southsea Freebooters, 10 Southsea Dock Workers and 10 Southsea Swashbucklers.",en={7882},l=45,n="Southsea Shakedown",ob={k={{7855},{7856},{7857},{7858}}},r=0,rl=40,sn={7882},x=3900}
T[8367]={d="Bring 3 Alterac Valley Marks of Honor, 3 Arathi Basin Marks of Honor and 3 Warsong Gulch Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},l=60,n="For Great Honor",nx=8388,ob={i={{20558},{20559},{20560}}},r=178,rl=51,sn={15350},tg=41,x=8300}
T[8368]={d="Bring 3 Warsong Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8426,8427,8428,8429,8430},l=19,n="Battle of Warsong Gulch",ob={i={{20558}}},r=178,rl=10,sn={15350},tg=41,x=1450}
T[8369]={d="Bring 3 Alterac Valley Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},l=60,n="Invaders of Alterac Valley",ob={i={{20560}}},r=178,rl=51,sn={15350},tg=41,x=8300}
T[8370]={d="Bring 3 Arathi Basin Mark of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8436,8437,8438,8439},l=29,n="Conquering Arathi Basin",ob={i={{20559}}},r=178,rl=20,sn={15350},tg=41,x=2350}
T[8371]={d="Bring 3 Alterac Valley Mark of Honor, 3 Arathi Basin Mark of Honor and 3 Warsong Gulch Mark of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},l=60,n="Concerted Efforts",nx=8385,ob={i={{20560},{20559},{20558}}},r=77,rl=51,sn={15351},tg=41,x=8300}
T[8372]={d="Bring 3 Warsong Gulch Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8399,8400,8401,8402,8403},l=19,n="Fight for Warsong Gulch",ob={i={{20558}}},r=77,rl=10,sn={15351},tg=41,x=1450}
T[8374]={d="Bring 3 Arathi Basin Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8393,8394,8395,8396},l=29,n="Claiming Arathi Basin",ob={i={{20559}}},r=77,rl=20,sn={15351},tg=41,x=2350}
T[8375]={d="Bring 3 Alterac Valley Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},l=60,n="Remember Alterac Valley!",ob={i={{20560}}},r=77,rl=51,sn={15351},tg=41,x=9950}
T[8376]={c=2,en={15183},l=60,n="Armaments of War",ps={8315},r=77,rl=58,sn={15183},tg=62,x=6600}
T[8377]={c=4,en={15183},l=60,n="Armaments of War",ps={8315},r=0,rl=58,sn={15183},tg=62,x=6600}
T[8378]={c=8,en={15183},l=60,n="Armaments of War",ps={8315},r=0,rl=58,sn={15183},tg=62,x=6600}
T[8379]={c=16,en={15183},l=60,n="Armaments of War",ps={8315},r=0,rl=58,sn={15183},tg=62,x=6600}
T[8380]={c=64,en={15183},l=60,n="Armaments of War",ps={8315},r=178,rl=58,sn={15183},tg=62,x=6600}
T[8381]={c=384,en={15183},l=60,n="Armaments of War",ps={8315},r=0,rl=58,sn={15183},tg=62,x=6600}
T[8382]={c=1024,en={15183},l=60,n="Armaments of War",ps={8315},r=0,rl=58,sn={15183},tg=62,x=6600}
T[8383]={en={15351},l=60,n="Remember Alterac Valley!",ob={i={{20560}}},ps={8375},r=77,rl=51,sf=1,sn={15351},tg=41}
T[8384]={d="Bring 3 Arathi Basin Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},l=29,n="Claiming Arathi Basin",ob={i={{20559}}},ps={8374},r=77,rl=20,sf=1,sn={15351},tg=41,x=1200}
T[8385]={en={15351},l=60,n="Concerted Efforts",ob={i={{20560},{20559},{20558}}},ps={8371},r=77,rl=51,sf=1,sn={15351},tg=41,x=6600}
T[8386]={en={15351},l=19,n="Fight for Warsong Gulch",ob={i={{20558}}},ps={8372},r=77,rl=10,sf=1,sn={15351},tg=41,x=730}
T[8387]={en={15350},l=60,n="Invaders of Alterac Valley",ob={i={{20560}}},ps={8369},r=178,rl=51,sf=1,sn={15350},tg=41}
T[8388]={en={15350},l=60,n="For Great Honor",ob={i={{20560},{20559},{20558}}},ps={8367},r=178,rl=51,sf=1,sn={15350},tg=41}
T[8389]={en={15350},l=19,n="Battle of Warsong Gulch",ob={i={{20558}}},ps={8368},r=178,rl=10,sf=1,sn={15350},tg=41,x=730}
T[8390]={en={15350},l=29,n="Conquering Arathi Basin",ob={i={{20559}}},ps={8370},r=178,rl=20,sf=1,sn={15350},tg=41,x=1200}
T[8391]={en={15351},l=39,n="Claiming Arathi Basin",ob={i={{20559}}},ps={8374,8393},r=77,rl=30,sf=1,sn={15351},tg=41,x=1500}
T[8392]={en={15351},l=49,n="Claiming Arathi Basin",ob={i={{20559}}},ps={8374,8393,8394},r=77,rl=40,sf=1,sn={15351},tg=41,x=2250}
T[8393]={d="Bring 3 Arathi Basin Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8374,8394,8395,8396},l=39,n="Claiming Arathi Basin",ob={i={{20559}}},r=77,rl=30,sn={15351},tg=41,x=3000}
T[8394]={d="Bring 3 Arathi Basin Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8374,8393,8395,8396},l=49,n="Claiming Arathi Basin",ob={i={{20559}}},r=77,rl=40,sn={15351},tg=41,x=4550}
T[8395]={d="Bring 3 Arathi Basin Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8374,8393,8394,8396},l=59,n="Claiming Arathi Basin",ob={i={{20559}}},r=77,rl=50,sn={15351},tg=41,x=6400}
T[8396]={d="Bring 3 Arathi Basin Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8374,8393,8394,8395},l=60,n="Claiming Arathi Basin",ob={i={{20559}}},r=77,rl=60,sn={15351},tg=41,x=6600}
T[8397]={en={15351},l=59,n="Claiming Arathi Basin",ob={i={{20559}}},ps={8374,8393,8394,8395},r=77,rl=50,sf=1,sn={15351},tg=41,x=3200}
T[8398]={en={15351},l=60,n="Claiming Arathi Basin",ob={i={{20559}}},ps={8374,8393,8394,8395,8396},r=77,rl=60,sf=1,sn={15351},tg=41,x=3300}
T[8399]={d="Bring 3 Warsong Gulch Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8372,8400,8401,8402,8403},l=29,n="Fight for Warsong Gulch",ob={i={{20558}}},r=77,rl=20,sn={15351},tg=41,x=2350}
T[8400]={d="Bring 3 Warsong Gulch Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8372,8399,8401,8402,8403},l=39,n="Fight for Warsong Gulch",ob={i={{20558}}},r=77,rl=30,sn={15351},tg=41,x=3000}
T[8401]={d="Bring 3 Warsong Gulch Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8372,8399,8400,8402,8403},l=49,n="Fight for Warsong Gulch",ob={i={{20558}}},r=77,rl=40,sn={15351},tg=41,x=4550}
T[8402]={d="Bring 3 Warsong Gulch Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8372,8399,8400,8401,8403},l=59,n="Fight for Warsong Gulch",ob={i={{20558}}},r=77,rl=50,sn={15351},tg=41,x=6400}
T[8403]={d="Bring 3 Warsong Gulch Marks of Honor to an Alliance Brigadier General outside the battlegrounds.",en={15351},ex={8372,8399,8400,8401,8402},l=60,n="Fight for Warsong Gulch",ob={i={{20558}}},r=77,rl=60,sn={15351},tg=41,x=6600}
T[8404]={en={15351},l=29,n="Fight for Warsong Gulch",ob={i={{20558}}},ps={8372,8399},r=77,rl=20,sf=1,sn={15351},tg=41,x=1200}
T[8405]={en={15351},l=39,n="Fight for Warsong Gulch",ob={i={{20558}}},ps={8372,8399,8400},r=77,rl=30,sf=1,sn={15351},tg=41,x=1500}
T[8406]={en={15351},l=49,n="Fight for Warsong Gulch",ob={i={{20558}}},ps={8372,8399,8400,8401},r=77,rl=40,sf=1,sn={15351},tg=41,x=2250}
T[8407]={en={15351},l=59,n="Fight for Warsong Gulch",ob={i={{20558}}},ps={8372,8399,8400,8401,8402},r=77,rl=50,sf=1,sn={15351},tg=41,x=3200}
T[8408]={en={15351},l=60,n="Fight for Warsong Gulch",ob={i={{20558}}},ps={8372,8399,8400,8401,8402,8403},r=77,rl=60,sf=1,sn={15351},tg=41,x=3300}
T[8410]={c=64,d="Collect a sample of air, fire, earth and water for Bath'rah the Windwatcher.",en={6176},ex={8411},l=50,n="Elemental Mastery",nx=8412,ob={i={{7069},{7068},{7067},{7070}}},r=178,rl=50,sn={3032,13417},x=3550}
T[8411]={c=64,d="Bring the elements earth, air, fire and water to Bath'rah the Windwatcher.",en={6176},ex={8410},l=50,n="Mastering the Elements",nx=8412,ob={i={{7069},{7067},{7068},{7070}}},r=178,rl=50,sn={6176},x=3550}
T[8412]={c=64,d="Bring the pieces for the spirit totem to Bath'rah the Windwatcher.",en={6176},l=52,n="Spirit Totem",nx=8413,ob={i={{20610},{20611}}},ps={8410,8411},r=178,rl=50,sn={6176},x=5100}
T[8413]={c=64,d="Bring the voodoo feathers to Bath'rah the Windwatcher.",en={6176},l=52,n="Da Voodoo",ob={i={{20606},{20607},{20608}}},ps={8412},r=178,rl=50,sn={6176},tg=81,x=6350,z=1477}
T[8414]={c=2,d="Collect 20 Minion's Scourgestones and bring them to High Priest Thel'danis in the Western Plaguelands.",en={1854},l=52,n="Dispelling Evil",nx=8416,ob={i={{12840}}},r=5,rl=50,sn={10838},x=5100}
T[8415]={c=2,d="Speak to Commander Ashlam Valorfist at Chillwind Camp.",en={10838},l=52,n="Chillwind Point",nx=8414,r=5,rl=50,sn={928,5149},x=510}
T[8416]={c=2,d="Bring the Inert Scourgestone to Commander Ashlan Valorfist in Chillwind Point.",en={10838},l=52,n="Inert Scourgestones",nx=8418,ps={8414},r=5,rl=50,sn={1854},su=20612,x=2550}
T[8417]={c=1,d="Speak with the Fallen Hero of the Horde at the entrance to the Blasted Lands.",en={7572},l=50,n="A Troubled Spirit",nx=8423,r=0,rl=50,sn={3041,3354,4593,5113,5479,7315},x=470}
T[8418]={c=2,d="Bring the voodoo feathers to Ashlam Valorfist.",en={10838},l=52,n="Forging the Mightstone",ob={i={{20606},{20607},{20608}}},ps={8416},r=5,rl=50,sn={10838},tg=81,x=6350,z=1477}
T[8419]={c=256,d="Bring a piece of felcloth to Impsy in Felwood.",en={14470},ex={8420},l=52,n="An Imp's Request",nx=8421,ob={i={{14256}}},r=0,rl=50,sn={461,3326,4563,5172},x=3800}
T[8420]={c=256,d="Bring a piece of felcloth to Impsy in Felwood.",en={14470},ex={8419},l=52,n="Hot and Itchy",nx=8421,ob={i={{14256}}},r=0,rl=50,sn={14470},x=3800}
T[8421]={c=256,d="Bring 10 Rotting Wood and 4 Bloodvenom Essence to Impsy in Felwood.",en={14470},l=52,n="The Wrong Stuff",nx=8422,ob={i={{20613},{20614}}},ps={8419,8420},r=0,rl=50,sn={14470},x=5100}
T[8422]={c=256,d="Bring a total of 6 Voodoo Feathers from the trolls in sunken temple.",en={14470},l=52,n="Trolls of a Feather",ob={i={{20606},{20607},{20608}}},ps={8421},r=0,rl=50,sn={14470},tg=81,x=6350,z=1477}
T[8423]={c=1,d="Kill 7 Helboar in the Blasted Lands and return to the Fallen Hero of the Horde.",en={7572},l=52,n="Warrior Kinship",nx=8424,ob={k={{5993}}},r=0,rl=50,sn={7572},x=5100}
T[8424]={c=1,d="Slaughter the Shadowsworn in the Blasted Lands and return to the Fallen Hero of the Horde.",en={7572},l=52,n="War on the Shadowsworn",nx=8425,ob={k={{6006},{6004},{6005}}},ps={8423},r=0,rl=50,sn={7572},x=5100}
T[8425]={c=1,d="Bring the Voodoo Feathers from the trolls in the Sunken Temple to the Fallen Hero of the Horde.",en={7572},l=52,n="Voodoo Feathers",ob={i={{20606},{20607},{20608}}},ps={8424},r=0,rl=50,sn={7572},tg=81,x=6350,z=1477}
T[8426]={d="Bring 3 Warsong Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8368,8427,8428,8429,8430},l=29,n="Battle of Warsong Gulch",ob={i={{20558}}},r=178,rl=20,sn={15350},tg=41,x=2350}
T[8427]={d="Bring 3 Warsong Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8368,8426,8428,8429,8430},l=39,n="Battle of Warsong Gulch",ob={i={{20558}}},r=178,rl=30,sn={15350},tg=41,x=3000}
T[8428]={d="Bring 3 Warsong Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8368,8426,8427,8429,8430},l=49,n="Battle of Warsong Gulch",ob={i={{20558}}},r=178,rl=40,sn={15350},tg=41,x=4550}
T[8429]={d="Bring 3 Warsong Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8368,8426,8427,8428,8430},l=59,n="Battle of Warsong Gulch",ob={i={{20558}}},r=178,rl=50,sn={15350},tg=41,x=6400}
T[8430]={d="Bring 3 Warsong Marks of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8368,8426,8427,8428,8429},l=60,n="Battle of Warsong Gulch",ob={i={{20558}}},r=178,rl=60,sn={15350},tg=41,x=6600}
T[8431]={en={15350},l=29,n="Battle of Warsong Gulch",ob={i={{20558}}},ps={8368,8426},r=178,rl=20,sf=1,sn={15350},tg=41,x=1200}
T[8432]={en={15350},l=39,n="Battle of Warsong Gulch",ob={i={{20558}}},ps={8368,8426,8427},r=178,rl=30,sf=1,sn={15350},tg=41,x=1500}
T[8433]={en={15350},l=49,n="Battle of Warsong Gulch",ob={i={{20558}}},ps={8368,8426,8427,8428},r=178,rl=40,sf=1,sn={15350},tg=41,x=2250}
T[8434]={en={15350},l=59,n="Battle of Warsong Gulch",ob={i={{20558}}},ps={8368,8426,8427,8428,8429},r=178,rl=50,sf=1,sn={15350},tg=41,x=3200}
T[8435]={en={15350},l=60,n="Battle of Warsong Gulch",ob={i={{20558}}},ps={8368,8426,8427,8428,8429,8430},r=178,rl=60,sf=1,sn={15350},tg=41,x=3300}
T[8436]={d="Bring 3 Arathi Basin Mark of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8370,8437,8438,8439},l=39,n="Conquering Arathi Basin",ob={i={{20559}}},r=178,rl=30,sn={15350},tg=41,x=3000}
T[8437]={d="Bring 3 Arathi Basin Mark of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8370,8436,8438,8439},l=49,n="Conquering Arathi Basin",ob={i={{20559}}},r=178,rl=40,sn={15350},tg=41,x=4550}
T[8438]={d="Bring 3 Arathi Basin Mark of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8370,8436,8437,8439},l=59,n="Conquering Arathi Basin",ob={i={{20559}}},r=178,rl=50,sn={15350},tg=41,x=6400}
T[8439]={d="Bring 3 Arathi Basin Mark of Honor to a Horde Warbringer outside the battlegrounds.",en={15350},ex={8370,8436,8437,8438},l=60,n="Conquering Arathi Basin",ob={i={{20559}}},r=178,rl=60,sn={15350},tg=41,x=6600}
T[8440]={en={15350},l=39,n="Conquering Arathi Basin",ob={i={{20559}}},ps={8370,8436},r=178,rl=30,sf=1,sn={15350},tg=41,x=1500}
T[8441]={en={15350},l=49,n="Conquering Arathi Basin",ob={i={{20559}}},ps={8370,8436,8437},r=178,rl=40,sf=1,sn={15350},tg=41,x=2250}
T[8442]={en={15350},l=59,n="Conquering Arathi Basin",ob={i={{20559}}},ps={8370,8436,8437,8438},r=178,rl=50,sf=1,sn={15350},tg=41,x=3200}
T[8443]={en={15350},l=60,n="Conquering Arathi Basin",ob={i={{20559}}},ps={8370,8436,8437,8438,8439},r=178,rl=60,sf=1,sn={15350},tg=41,x=3300}
T[8446]={d="Find someone capable of deciphering the meaning behind the Nightmare Engulfed Object.",en={11832},l=60,n="Shrouded in Nightmare",nx=8447,r=0,rl=60,si={20644},su=20644,x=9950}
T[8447]={d="Wait for Keeper Remulos at the Moonglade to cleanse the Nightmare Engulfed Object.",en={11832},l=60,n="Waking Legends",ob={e={"Waking Legends.",{{1450,40,48.6}}}},ps={8446},r=0,rl=60,sf=2,sn={11832}}
T[8460]={d="Grazle wants you to prove yourself by killing 6 Deadwood Warriors, 6 Deadwood Pathfinders, and 6 Deadwood Gardeners. Return to him in southern Felwood near the Emerald Sanctuary when you are done.",en={11554},l=48,n="Timbermaw Ally",nx=8462,ob={k={{7153},{7155},{7154}}},r=0,rl=45,sn={11554},x=4400}
T[8461]={d="Nafien would like you to kill 6 Deadwood Den Watchers, 6 Deadwood Avengers, and 6 Deadwood Shamans. Return to him in northern Felwood near the entrance to Timbermaw Hold.",en={15395},l=55,n="Deadwood of the North",nx=8465,ob={k={{7156},{7157},{7158}}},r=0,rl=45,sn={15395},x=5650}
T[8462]={d="Travel north along the main road in Felwood and speak with the furbolg named Nafien. He stands guard outside the entrance to Timbermaw Hold.",en={15395},l=55,n="Speak to Nafien",ps={8460},r=0,rl=45,sn={11554},x=560}
T[8464]={d="Salfa wants you to kill 8 Winterfall Shaman, 8 Winterfall Den Watchers, and 8 Winterfall Ursa. Salfa is located just outside the entrance to Timbermaw Hold in Winterspring.",en={11556},l=58,n="Winterfall Activity",nx=8469,ob={k={{7439},{7440},{7438}}},r=0,rl=45,sn={11556},x=6200}
T[8465]={d="Travel through Timbermaw Hold and exit into Winterspring. Speak with Salfa, who stands guard outside the entrance to Timbermaw Hold.",en={11556},l=55,n="Speak to Salfa",ps={8461},r=0,rl=45,sn={15395},x=560}
T[8466]={en={11554},l=55,n="Feathers for Grazle",ob={i={{21377}}},ps={8460},r=0,rl=45,sf=1,sn={11554},x=560}
T[8467]={en={15395},l=55,n="Feathers for Nafien",ob={i={{21377}}},ps={8461},r=0,rl=45,sf=1,sn={15395},x=560}
T[8469]={en={11556},l=56,n="Beads for Salfa",ob={i={{21383}}},ps={8464},r=0,rl=50,sf=1,sn={11556},x=580}
T[8470]={d="Take the Deadwood Ritual Totem inside Timbermaw Hold and see if one of the furbolgs there will find a use for the item. The Timbermaw will not speak with you unless you are of Neutral reputation or greater with them.",en={11558},l=55,n="Deadwood Ritual Totem",r=0,rl=45,si={20741},su=20741,x=5650}
T[8471]={d="Take the Winterfall Ritual Totem inside Timbermaw Hold and see if one of the furbolgs there will find a use for the item. The Timbermaw will not speak with you unless you are of Neutral reputation or greater with them.",en={11558},l=56,n="Winterfall Ritual Totem",r=0,rl=50,si={20742},su=20742,x=5800}
T[8481]={d="Plant the Demon Summoning Torch in the mouth of High Chief Winterfall's cave in the Winterfall furbolg village. Defeat the demon and retrieve the Essence of Xandivious for Gorn One Eye in Timbermaw Hold.",en={11555},l=60,n="The Root of All Evil",ob={i={{21145}}},r=0,rl=45,rp={576,42000},sn={11555},su=21144,tg=1,x=6600}
T[8484]={d="Bring the Timbermaw Offering of Peace to King Magni Bronzebeard in Ironforge.",en={2784},l=60,n="The Brokering of Peace",ps={8481},r=77,rl=45,rp={576,42000},sn={11555},su=21155,x=9950}
T[8485]={d="Bring the Timbermaw Offering of Peace to Thrall in Orgrimmar.",en={4949},l=60,n="The Brokering of Peace",ps={8481},r=178,rl=45,rp={576,42000},sn={11555},su=21155,x=9950}
T[8492]={d="Bring 20 Copper Bars to Sergeant Stonebrow at the Military Ward in Ironforge.",en={15383},l=60,n="The Alliance Needs Copper Bars!",nx=8493,ob={i={{2840}}},r=77,rl=1,sn={15383}}
T[8493]={d="Bring 20 copper bars to Sergeant Stonebrow at the airfield in Dun Morogh.",en={15383},l=60,n="The Alliance Needs More Copper Bars!",ob={i={{2840}}},ps={8492},r=77,rl=1,sf=1,sn={15383}}
T[8494]={d="Bring 20 Iron Bars to Corporal Carnes at the Military Ward in Ironforge.",en={15431},l=60,n="The Alliance Needs Iron Bars!",nx=8495,ob={i={{3575}}},r=77,rl=1,sn={15431}}
T[8495]={d="Bring 20 iron bars to Corporal Carnes at the airfield in Dun Morogh.",en={15431},l=60,n="The Alliance Needs More Iron Bars!",ob={i={{3575}}},ps={8494},r=77,rl=1,sf=1,sn={15431}}
T[8496]={d="Bring 30 Heavy Runecloth Bandages, 30 Heavy Silk Bandages and 30 Heavy Mageweave Bandages to Windcaller Proudhorn at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing X in order to complete this quest.",en={15191},l=60,n="Bandages for the Field",ob={i={{14530},{8545},{6451}}},r=77,rl=60,sf=1,si={20806},su=20806,x=660}
T[8497]={d="Bring 4 Globes of Water, 4 Powerful Anti-Venom and 4 Smoked Desert Dumplings to Calandrath at the inn in Cenarion Hold in Silithus. You must also bring Logistics Task Briefing I in order to complete this quest.",en={15174},l=60,n="Desert Survival Kits",ob={i={{7079},{19440},{20452}}},r=77,rl=60,sf=1,si={20807},su=20807,x=660}
T[8498]={d="Obtain the Twilight Battle Orders and bring them Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Tactical Task Briefing X in order to complete this quest.",en={15181},l=60,n="Twilight Battle Orders",ob={i={{20803}}},r=0,rl=60,sf=1,si={20943},su=20943,tg=1,x=660}
T[8499]={d="Bring 20 Thorium Bars to Dame Twinbraid at the Military Ward in Ironforge.",en={15432},l=60,n="The Alliance Needs Thorium Bars!",nx=8500,ob={i={{12359}}},r=77,rl=1,sn={15432}}
T[8500]={d="Bring 20 thorium bars to Dame Twinbraid at the airfield in Dun Morogh.",en={15432},l=60,n="The Alliance Needs More Thorium Bars!",ob={i={{12359}}},ps={8499},r=77,rl=1,sf=1,sn={15432}}
T[8501]={d="Kill 30 Hive'Ashi Stingers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing XII in order to complete this quest.",en={15181},l=60,n="Target: Hive'Ashi Stingers",ob={k={{11698}}},r=0,rl=60,sf=1,si={20941},su=20941,tg=1,x=660}
T[8502]={d="Slay 30 Hive'Ashi Workers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing III in order to complete this quest.",en={15181},l=60,n="Target: Hive'Ashi Workers",ob={k={{11721}}},r=0,rl=60,sf=1,si={20942},su=20942,tg=1,x=660}
T[8503]={d="Bring 20 Stranglekelp to Private Draxlegauge at the Military Ward in Ironforge.",en={15434},l=60,n="The Alliance Needs Stranglekelp!",nx=8504,ob={i={{3820}}},r=77,rl=1,sn={15434}}
T[8504]={d="Bring 20 stranglekelp to Private Draxlegauge at the airfield in Dun Morogh.",en={15434},l=60,n="The Alliance Needs More Stranglekelp!",ob={i={{3820}}},ps={8503},r=77,rl=1,sf=1,sn={15434}}
T[8505]={d="Bring 20 Purple Lotus to Master Nightsong at the Military Ward in Ironforge.",en={15437},l=60,n="The Alliance Needs Purple Lotus!",nx=8506,ob={i={{8831}}},r=77,rl=1,sn={15437}}
T[8506]={d="Bring 20 purple lotus to Master Nightsong at the airfield in Dun Morogh.",en={15437},l=60,n="The Alliance Needs More Purple Lotus!",ob={i={{8831}}},ps={8505},r=77,rl=1,sf=1,sn={15437}}
T[8507]={d="Report for duty at the Ironforge Brigade post near Hive'Zora. Prepare your Unsigned Field Duty Papers and obtain Signed Field Duty Papers from Captain Blackanvil and return to Windcaller Kaldon at Cenarion Hold in Silithus.",en={15540},l=60,n="Field Duty",ob={i={{20810}}},r=77,rl=60,sf=1,sn={15540},su=21143,tg=1}
T[8508]={en={15440},l=60,n="Field Duty Papers",ob={i={{23024}}},pa=8507,r=77,rl=60,sf=1,sn={15440},su=20810}
T[8509]={d="Bring 20 Arthas' Tears to Sergeant Major Germaine at the Military Ward in Ironforge.",en={15445},l=60,n="The Alliance Needs Arthas' Tears!",nx=8510,ob={i={{8836}}},r=77,rl=1,sn={15445}}
T[8510]={d="Bring 20 Arthas' Tears to Sergeant Major Germaine at the airfield in Dun Morogh.",en={15445},l=60,n="The Alliance Needs More Arthas' Tears!",ob={i={{8836}}},ps={8509},r=77,rl=1,sf=1,sn={15445}}
T[8511]={d="Bring 10 Light Leather to Bonnie Stoneflayer at the Military Ward in Ironforge.",en={15446},l=60,n="The Alliance Needs Light Leather!",nx=8512,ob={i={{2318}}},r=77,rl=1,sn={15446}}
T[8512]={d="Bring 10 light leather to Bonnie Stoneflayer at the airfield in Dun Morogh.",en={15446},l=60,n="The Alliance Needs Light Leather!",ob={i={{2318}}},ps={8511},r=77,rl=1,sf=1,sn={15446}}
T[8513]={d="Bring 10 Medium Leather to Private Porter at the Military Ward in Ironforge.",en={15448},l=60,n="The Alliance Needs Medium Leather!",nx=8514,ob={i={{2319}}},r=77,rl=1,sn={15448}}
T[8514]={d="Bring 10 medium leather to Private Porter at the airfield in Dun Morogh.",en={15448},l=60,n="The Alliance Needs More Medium Leather!",ob={i={{2319}}},ps={8513},r=77,rl=1,sf=1,sn={15448}}
T[8515]={d="Bring 10 Thick Leather to Marta Finespindle at the Military Ward in Ironforge.",en={15450},l=60,n="The Alliance Needs Thick Leather!",nx=8516,ob={i={{4304}}},r=77,rl=1,sn={15450}}
T[8516]={d="Bring 10 thick leather to Marta Finespindle at the airfield in Dun Morogh.",en={15450},l=60,n="The Alliance Needs More Thick Leather!",ob={i={{4304}}},ps={8515},r=77,rl=1,sf=1,sn={15450}}
T[8517]={d="Bring 20 Linen Bandages to Sentinel Silversky at the Military Ward in Ironforge.",en={15451},l=60,n="The Alliance Needs Linen Bandages!",nx=8518,ob={i={{1251}}},r=77,rl=1,sn={15451}}
T[8518]={d="Bring 20 linen bandages to Sentinel Silversky at the airfield in Dun Morogh.",en={15451},l=60,n="The Alliance Needs More Linen Bandages!",ob={i={{1251}}},ps={8517},r=77,rl=1,sf=1,sn={15451}}
T[8519]={d="Learn all that you can of the past, then speak with Anachronos at the Caverns of Time in Tanaris.",en={15192},l=60,n="A Pawn on the Eternal Board",nx=8555,ob={e={"The War of the Shifting Sands",{{1451,29,92.1}}}},ps={8305},r=0,rl=60,rp={910,0},sf=2,so={180633},x=6600}
T[8520]={d="Bring 20 Silk Bandages to Nurse Stonefield at the Military Ward in Ironforge.",en={15452},l=60,n="The Alliance Needs Silk Bandages!",nx=8521,ob={i={{6450}}},r=77,rl=1,sn={15452}}
T[8521]={d="Bring 20 silk bandages to Nurse Stonefield at the airfield in Dun Morogh.",en={15452},l=60,n="The Alliance Needs More Silk Bandages!",ob={i={{6450}}},ps={8520},r=77,rl=1,sf=1,sn={15452}}
T[8522]={d="Bring 20 Runecloth Bandages to Keeper Moonshade at the Military Ward in Ironforge.",en={15453},l=60,n="The Alliance Needs Runecloth Bandages!",nx=8523,ob={i={{14529}}},r=77,rl=1,sn={15453}}
T[8523]={d="Bring 20 runecloth bandages to Keeper Moonshade at the airfield in Dun Morogh.",en={15453},l=60,n="The Alliance Needs More Runecloth Bandages!",ob={i={{14529}}},ps={8522},r=77,rl=1,sf=1,sn={15453}}
T[8524]={d="Bring 20 Rainbow Fin Albacore to Slicky Gastronome at the Military Ward in Ironforge.",en={15455},l=60,n="The Alliance Needs Rainbow Fin Albacore!",nx=8525,ob={i={{5095}}},r=77,rl=1,sn={15455}}
T[8525]={d="Bring 20 rainbow fin albacore to Slicky Gastronome at the airfield in Dun Morogh.",en={15455},l=60,n="The Alliance Needs More Rainbow Fin Albacore!",ob={i={{5095}}},ps={8524},r=77,rl=1,sf=1,sn={15455}}
T[8526]={d="Bring 20 Roast Raptor to Sarah Sadwhistle at the Military Ward in Ironforge.",en={15456},l=60,n="The Alliance Needs Roast Raptor!",nx=8527,ob={i={{12210}}},r=77,rl=1,sn={15456}}
T[8527]={d="Bring 20 roast raptor to Sarah Sadwhistle at the airfield in Dun Morogh.",en={15456},l=60,n="The Alliance Needs More Roast Raptor!",ob={i={{12210}}},ps={8526},r=77,rl=1,sf=1,sn={15456}}
T[8528]={d="Bring 20 Spotted Yellowtail to Huntress Swiftriver at the Military Ward in Ironforge.",en={15457},l=60,n="The Alliance Needs Spotted Yellowtail!",nx=8529,ob={i={{6887}}},r=77,rl=1,sn={15457}}
T[8529]={d="Bring 20 spotted yellowtail to Huntress Swiftriver at the airfield in Dun Morogh.",en={15457},l=60,n="The Alliance Needs More Spotted Yellowtail!",ob={i={{6887}}},ps={8528},r=77,rl=1,sf=1,sn={15457}}
T[8532]={d="Bring 20 Copper Bars to Miner Cromwell at the Valley of Spirits in Orgrimmar.",en={15459},l=60,n="The Horde Needs Copper Bars!",nx=8533,ob={i={{2840}}},r=178,rl=1,sn={15459}}
T[8533]={d="Bring 20 copper bars to Miner Cromwell in Durotar.",en={15459},l=60,n="The Horde Needs More Copper Bars!",ob={i={{2840}}},ps={8532},r=178,rl=1,sf=1,sn={15459}}
T[8534]={d="Contact Cenarion Scout Azenel inside Hive'Zora and return the Hive'Zora Scout Report to Windcaller Proudhorn at Cenarion Hold. You must also bring Tactical Task Briefing VI in order to complete this quest.",en={15191},l=60,n="Hive'Zora Scout Report",ob={i={{21158}}},r=0,rl=60,sf=1,si={21165},su=21165,tg=1,x=660}
T[8535]={d="Summon and slay a Hoary Templar and report back to Bor Wildmane in Cenarion Hold. You must also bring Tactical Task Briefing IV in order to complete this quest.",en={15306},l=60,n="Hoary Templar",ob={k={{15212}}},r=0,rl=60,sf=1,si={20947},su=20947,tg=1,x=660}
T[8536]={d="Summon and slay an Earthen Templar and report back to Bor Wildmane in Cenarion Hold. You must also bring Tactical Task Briefing III in order to complete this quest.",en={15306},l=60,n="Earthen Templar",ob={k={{15307}}},r=0,rl=60,sf=1,si={21751},su=21751,tg=1,x=660}
T[8537]={d="Summon and slay a Crimson Templar and report back to Bor Wildmane in Cenarion Hold. You must also bring Tactical Task Briefing II in order to complete this quest.",en={15306},l=60,n="Crimson Templar",ob={k={{15209}}},r=0,rl=60,sf=1,si={20945},su=20945,tg=1,x=660}
T[8538]={d="Find a way to summon and slay the Duke of Cynders, the Duke of Fathoms, the Duke of Zephyrs and the Duke of Shards and report back to Commander Mar'alith in Cenarion Hold. You must also bring Tactical Task Briefing V in order to complete this quest.",en={15181},l=60,n="The Four Dukes",ob={k={{15206},{15207},{15220},{15208}}},r=0,rl=60,sf=1,si={20948},su=20948,tg=1,x=660}
T[8539]={d="Slay 30 Hive'Zora Hive Sisters and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing V in order to complete this quest.",en={15181},l=60,n="Target: Hive'Zora Hive Sisters",ob={k={{11729}}},r=0,rl=60,sf=1,si={21249},su=21249,tg=1,x=660}
T[8540]={d="Bring 3 Ornate Mithril Boots to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing II in order to complete this quest.",en={15182},l=60,n="Boots for the Guard",ob={i={{7936}}},r=77,rl=60,sf=1,si={20939},su=20939,x=660}
T[8541]={d="Bring 10 Dense Grinding Stones, 10 Solid Grinding Stones and 10 Heavy Grinding Stones to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing III in order to complete this quest.",en={15182},l=60,n="Grinding Stones for the Guard",ob={i={{12644},{7966},{3486}}},r=77,rl=60,sf=1,si={20940},su=20940,x=660}
T[8542]={d="Bring 20 Tin Bars to Grunt Maug at the Valley of Spirits in Orgrimmar.",en={15460},l=60,n="The Horde Needs Tin Bars!",nx=8543,ob={i={{3576}}},r=178,rl=1,sn={15460}}
T[8543]={d="Bring 20 tin bars to Grunt Maug in Durotar.",en={15460},l=60,n="The Horde Needs More Tin Bars!",ob={i={{3576}}},ps={8542},r=178,rl=1,sf=1,sn={15460}}
T[8544]={c=1,d="Bring the Qiraji Bindings of Command, 2 Idols of Night, 5 Stone Scarabs and 5 Clay Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Conqueror's Spaulders",ob={i={{20928},{20875},{20863},{20858}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8545]={d="Bring 20 Mithril Bars to Senior Sergeant T'kelah at the Valley of Spirits in Orgrimmar.",en={15469},l=60,n="The Horde Needs Mithril Bars!",nx=8546,ob={i={{3860}}},r=178,rl=1,sn={15469}}
T[8546]={d="Bring 20 Mithril Bars to Senior Sergeant T'kelah at the Valley of Spirits in Orgrimmar.",en={15469},l=60,n="The Horde Needs More Mithril Bars!",ob={i={{3860}}},ps={8545},r=178,rl=1,sf=1,sn={15469}}
T[8548]={d="Bring 5 Cenarion Combat Badges, 3 Cenarion Logistics Badges and 7 Cenarion Tactical Badges to Vargus at Cenarion Hold in Silithus. You must also attain Friendly reputation with Cenarion Circle to be able to complete this quest.",en={15176},l=60,n="Volunteer's Battlegear",ob={i={{20802},{20800},{20801}}},ps={8800},r=0,rl=60,sf=1,sn={15176},x=3300}
T[8549]={d="Bring 20 Peacebloom to Herbalist Proudfeather at the Valley of Spirits in Orgrimmar.",en={15477},l=60,n="The Horde Needs Peacebloom!",nx=8550,ob={i={{2447}}},r=178,rl=1,sn={15477}}
T[8550]={d="Bring 20 Peacebloom to Herbalist Proudfeather at the Valley of Spirits in Orgrimmar.",en={15477},l=60,n="The Horde Needs Peacebloom!",ob={i={{2447}}},ps={8549},r=178,rl=1,sf=1,sn={15477}}
T[8551]={d="Bring Smotts' Chest to Hecklebury Smotts in Booty Bay.",en={2500},l=47,n="The Captain's Chest",ob={i={{3932}}},r=0,rl=35,sn={2500},tg=1,x=3150}
T[8552]={d="Return the Monogrammed Sash to its owner.",en={2500},l=50,n="The Monogrammed Sash",nx=8553,r=0,rl=40,si={3985},su=3985,x=2350}
T[8553]={d="Speak with Sprogger.",en={2594},l=50,n="The Captain's Cutlass",nx=8554,ps={8552},r=0,rl=40,sn={2500},x=470}
T[8554]={d="Bring 10 Barbecued Buzzard Wings and 5 bottles of Junglevine Wine to Captain Smotts' Lifeboat.",en={2500},l=50,n="Facing Negolash",ob={i={{3935}}},ps={8553},r=0,rl=40,sn={2594},tg=1,x=7100}
T[8555]={en={15192},l=60,n="The Charge of the Dragonflights",ps={8519},r=0,rl=60,rp={910,0},sn={15192},x=660}
T[8556]={c=1,d="Bring 1 Qiraji Magisterial Ring, 2 Lambent Idols, 5 Bronze Scarabs and 5 Ivory Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Signet of Unyielding Strength",ob={i={{20884},{20868},{20861},{20865}}},r=0,rl=60,sn={15498},tg=62,x=6600}
T[8557]={c=1,d="Bring 1 Qiraji Martial Drape, 2 Onyx Idols, 5 Silver Scarabs and 5 Bone Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Drape of Unyielding Strength",ob={i={{20885},{20867},{20864},{20860}}},r=0,rl=60,sn={15500},tg=62,x=6600}
T[8558]={c=1,d="Bring 1 Qiraji Spiked Hilt, 2 Alabaster Idols, 5 Crystal Scarabs and 5 Stone Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Sickle of Unyielding Strength",ob={i={{20886},{20873},{20862},{20858}}},r=0,rl=60,sn={15499},tg=62,x=6600}
T[8559]={c=1,d="Bring the Qiraji Bindings of Command, 2 Idols of War, 5 Ivory Scarabs and 5 Gold Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Conqueror's Greaves",ob={i={{20928},{20882},{20865},{20859}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8560]={c=1,d="Bring Ouro's Intact Hide, 2 Idols of Death, 5 Bronze Scarabs and 5 Ivory Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Conqueror's Legguards",ob={i={{20927},{20876},{20861},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8561]={c=1,d="Bring Vek'nilash's Circlet, 2 Idols of the Sun, 5 Stone Scarabs and 5 Crystal Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Conqueror's Crown",ob={i={{20926},{20874},{20862},{20858}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8562]={c=1,d="Bring the the Carapace of the Old God, 2 Idols of War, 5 Silver Scarabs and 5 Bone Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Conqueror's Breastplate",ob={i={{20929},{20882},{20860},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8572]={d="Bring 7 Cenarion Combat Badges, 4 Cenarion Logistics Badges and 4 Cenarion Tactical Badges to Vargus at Cenarion Hold in Silithus. You must also attain Honored reputation with Cenarion Circle to be able to complete this quest.",en={15176},l=60,n="Veteran's Battlegear",ob={i={{20802},{20800},{20801}}},ps={8800},r=0,rl=60,sf=1,sn={15176},x=3300}
T[8573]={d="Bring 15 Cenarion Combat Badges, 20 Cenarion Logistics Badges, 20 Cenarion Tactical Badges and 1 Mark of Cenarius to Vargus at Cenarion Hold in Silithus. You must also attain Exalted reputation with Cenarion Circle to be able to complete this quest.",en={15176},l=60,n="Champion's Battlegear",ob={i={{20802},{20800},{20801},{21508}}},ps={8800},r=0,rl=60,sf=1,sn={15176},x=3300}
T[8574]={d="Bring 15 Cenarion Combat Badges, 20 Cenarion Logistics Badges, 17 Cenarion Tactical Badges and 1 Mark of Remulos to Vargus at Cenarion Hold in Silithus. You must also attain Revered reputation with Cenarion Circle to be able to complete this quest.",en={15176},l=60,n="Stalwart's Battlegear",ob={i={{20802},{20800},{20801},{21515}}},ps={8800},r=0,rl=60,sf=1,sn={15176},x=3300}
T[8575]={d="Deliver Azuregos's Magical Ledger to Narain Soothfancy in Tanaris.",en={11811},l=60,n="Azuregos's Magical Ledger",nx=8576,ps={8555},r=0,rl=60,rp={910,0},sn={15481},su=20949,x=6600}
T[8576]={en={11811},l=60,n="Translating the Ledger",ps={8575},r=0,rl=60,rp={910,0},sn={11811},x=660}
T[8577]={d="Narain Soothfancy wants you to find his ex-best friend forever (BFF), Stewvul, and take back the scrying goggles that Stewvul stole from him.",eo={180642},l=60,n="Stewvul, Ex-B.F.F.",nx=8578,ps={8576},r=0,rl=60,rp={910,0},sn={11811},x=6600}
T[8578]={d="Find Narain's Scrying Goggles and return them to Narain Soothfancy in Tanaris.",en={11811},l=60,n="Scrying Goggles? No Problem!",ob={i={{20951}}},ps={8577},r=0,rl=60,rp={910,0},so={180642},tg=62,x=8300}
T[8579]={en={15503},l=60,n="Mortal Champions",nx=8595,ob={i={{21229}}},r=0,rl=60,sn={15503},tg=62,x=6600}
T[8580]={d="Bring 20 Firebloom to Batrider Pele'keiki at the Valley of Spirits in Orgrimmar.",en={15508},l=60,n="The Horde Needs Firebloom!",nx=8581,ob={i={{4625}}},r=178,rl=1,sn={15508}}
T[8581]={d="Bring 20 Firebloom to Batrider Pele'keiki at the Valley of Spirits in Orgrimmar.",en={15508},l=60,n="The Horde Needs More Firebloom!",ob={i={{4625}}},ps={8580},r=178,rl=1,sf=1,sn={15508}}
T[8582]={d="Bring 20 Purple Lotus to Apothecary Jezel at the Valley of Spirits in Orgrimmar.",en={15512},l=60,n="The Horde Needs Purple Lotus!",nx=8583,ob={i={{8831}}},r=178,rl=1,sn={15512}}
T[8583]={d="Bring 20 Purple Lotus to Apothecary Jezel at the Valley of Spirits in Orgrimmar.",en={15512},l=60,n="The Horde Needs More Purple Lotus!",ob={i={{8831}}},ps={8582},r=178,rl=1,sf=1,sn={15512}}
T[8584]={d="Narain Soothfancy in Tanaris wants you to speak with Dirge Quikcleave in Gadgetzan.",en={8125},l=60,n="Never Ask Me About My Business",nx=8585,ps={8576},r=0,rl=60,rp={910,0},sn={11811},x=660}
T[8585]={d="Recover Lakmaeran's Carcass and 20 Chimaerok Tenderloins for Dirge Quikcleave in Tanaris.",en={8125},l=60,n="The Isle of Dread!",nx=8586,ob={i={{21027},{21024}}},ps={8584},r=0,rl=60,rp={910,0},sn={8125},tg=62,x=6600}
T[8586]={d="Dirge Quikcleave in Gadgetzan wants you to bring him 20 Goblin Rocket Fuel and 20 Deeprock Salt.",en={8125},l=60,n="Dirge's Kickin' Chimaerok Chops",nx=8587,ob={i={{9061},{8150}}},ps={8585},r=0,rl=60,rp={910,0},sn={8125},x=6600}
T[8587]={d="Deliver the 500 Pound Chicken to Narain Soothfancy in Tanaris.",en={11811},l=60,n="Return to Narain",ps={8586},r=0,rl=60,rp={910,0},sn={8125},su=21028,x=6600}
T[8588]={d="Bring 10 Heavy Leather to Skinner Jamani at the Valley of Spirits in Orgrimmar.",en={15515},l=60,n="The Horde Needs Heavy Leather!",nx=8589,ob={i={{4234}}},r=178,rl=1,sn={15515}}
T[8589]={d="Bring 10 Heavy Leather to Skinner Jamani at the Valley of Spirits in Orgrimmar.",en={15515},l=60,n="The Horde Needs More Heavy Leather!",ob={i={{4234}}},ps={8588},r=178,rl=1,sf=1,sn={15515}}
T[8590]={d="Bring 10 Thick Leather to Sergeant Umala at the Valley of Spirits in Orgrimmar.",en={15522},l=60,n="The Horde Needs Thick Leather!",nx=8591,ob={i={{4304}}},r=178,rl=1,sn={15522}}
T[8591]={d="Bring 10 Thick Leather to Sergeant Umala at the Valley of Spirits in Orgrimmar.",en={15522},l=60,n="The Horde Needs More Thick Leather!",ob={i={{4304}}},ps={8590},r=178,rl=1,sf=1,sn={15522}}
T[8592]={c=16,d="Bring Vek'nilash's Circlet, 2 Idols of the Sage, 5 Silver Scarabs and 5 Bone Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Tiara of the Oracle",ob={i={{20926},{20877},{20860},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8593]={c=16,d="Bring Ouro's Intact Hide, 2 Idols of Life, 5 Gold Scarabs and 5 Clay Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Trousers of the Oracle",ob={i={{20927},{20879},{20859},{20863}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8594]={c=16,d="Bring the Qiraji Bindings of Command, 2 Idols of Rebirth, 5 Silver Scarabs and 5 Ivory Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Mantle of the Oracle",ob={i={{20928},{20878},{20860},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8595]={en={15503},l=60,n="Mortal Champions",ob={i={{21229}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62}
T[8596]={c=16,d="Bring the Qiraji Bindings of Command, 2 Idols of Death, 5 Bronze Scarabs and 5 Gold Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Footwraps of the Oracle",ob={i={{20928},{20876},{20861},{20859}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8597]={d="Find Narain Soothfancy's book, buried on an island in the South Seas.",eo={180652},l=60,n="Draconic for Dummies",nx=8598,ps={8576},r=0,rl=60,rp={910,0},sn={11811},x=6600}
T[8598]={d="Return the Ransom Letter to Narain Soothfancy in Tanaris.",en={11811},l=60,n="rAnS0m",nx=8606,ps={8597},r=0,rl=60,rp={910,0},so={180652},su=21029,x=3300}
T[8599]={d="Take Meridith's Love Letter to Narain Soothfancy in Tanaris.",en={11811},l=60,n="Love Song for Narain",pa=8597,r=0,rl=60,rp={910,0},sn={15526},su=21032,x=3300}
T[8600]={d="Bring 10 Rugged Leather to Doctor Serratus at the Valley of Spirits in Orgrimmar.",en={15525},l=60,n="The Horde Needs Rugged Leather!",nx=8601,ob={i={{8170}}},r=178,rl=1,sn={15525}}
T[8601]={d="Bring 10 Rugged Leather to Doctor Serratus at the Valley of Spirits in Orgrimmar.",en={15525},l=60,n="The Horde Needs More Rugged Leather!",ob={i={{8170}}},ps={8600},r=178,rl=1,sf=1,sn={15525}}
T[8602]={c=64,d="Bring the Qiraji Bindings of Dominance, 2 Idols of Life, 5 Gold Scarabs and 5 Crystal Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Stormcaller's Pauldrons",ob={i={{20932},{20879},{20859},{20862}}},ps={8579},r=178,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8603]={c=16,d="Bring the the Husk of the Old God, 2 Idols of Death, 5 Stone Scarabs and 5 Crystal Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Vestments of the Oracle",ob={i={{20933},{20876},{20858},{20862}}},ps={8579},r=0,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8604]={d="Bring 20 Wool Bandages to Healer Longrunner at the Valley of Spirits in Orgrimmar.",en={15528},l=60,n="The Horde Needs Wool Bandages!",nx=8605,ob={i={{3530}}},r=178,rl=1,sn={15528}}
T[8605]={d="Bring 20 Wool Bandages to Healer Longrunner at the Valley of Spirits in Orgrimmar.",en={15528},l=60,n="The Horde Needs More Wool Bandages!",ob={i={{3530}}},ps={8604},r=178,rl=1,sf=1,sn={15528}}
T[8606]={d="Narain Soothfancy in Tanaris wants you to travel to Winterspring and place the Bag of Gold at the drop off point documented by the booknappers.",en={11811},l=60,n="Decoy!",nx=8620,ob={k={{15554,"Who Does Number Two Work For?"}}},ps={8598},r=0,rl=60,rp={910,0},sn={11811},su=21042,tg=1,x=6600}
T[8607]={d="Bring 20 Mageweave Bandages to Lady Callow at the Valley of Spirits in Orgrimmar.",en={15529},l=60,n="The Horde Needs Mageweave Bandages!",nx=8608,ob={i={{8544}}},r=178,rl=1,sn={15529}}
T[8608]={d="Bring 20 Mageweave Bandages to Lady Callow at the Valley of Spirits in Orgrimmar.",en={15529},l=60,n="The Horde Needs More Mageweave Bandages!",ob={i={{8544}}},ps={8607},r=178,rl=1,sf=1,sn={15529}}
T[8609]={d="Bring 20 Runecloth Bandages to Stoneguard Clayhoof at the Valley of Spirits in Orgrimmar.",en={15532},l=60,n="The Horde Needs Runecloth Bandages!",nx=8610,ob={i={{14529}}},r=178,rl=1,sn={15532}}
T[8610]={d="Bring 20 Runecloth Bandages to Stoneguard Clayhoof at the Valley of Spirits in Orgrimmar.",en={15532},l=60,n="The Horde Needs More Runecloth Bandages!",ob={i={{14529}}},ps={8609},r=178,rl=1,sf=1,sn={15532}}
T[8611]={d="Bring 20 Lean Wolf Steaks to Bloodguard Rawtar at the Valley of Spirits in Orgrimmar.",en={15533},l=60,n="The Horde Needs Lean Wolf Steaks!",nx=8612,ob={i={{12209}}},r=178,rl=1,sn={15533}}
T[8612]={d="Bring 20 Lean Wolf Steaks to Bloodguard Rawtar at the Valley of Spirits in Orgrimmar.",en={15533},l=60,n="The Horde Needs More Lean Wolf Steaks!",ob={i={{12209}}},ps={8611},r=178,rl=1,sf=1,sn={15533}}
T[8613]={d="Bring 20 Spotted Yellowtail to Fisherman Lin'do at the Valley of Spirits in Orgrimmar.",en={15534},l=60,n="The Horde Needs Spotted Yellowtail!",nx=8614,ob={i={{6887}}},r=178,rl=1,sn={15534}}
T[8614]={d="Bring 20 Spotted Yellowtail to Fisherman Lin'do at the Valley of Spirits in Orgrimmar.",en={15534},l=60,n="The Horde Needs More Spotted Yellowtail!",ob={i={{6887}}},ps={8613},r=178,rl=1,sf=1,sn={15534}}
T[8615]={d="Bring 20 Baked Salmon to Chief Sharpclaw at the Valley of Spirits in Orgrimmar.",en={15535},l=60,n="The Horde Needs Baked Salmon!",nx=8616,ob={i={{13935}}},r=178,rl=1,sn={15535}}
T[8616]={d="Bring 20 Baked Salmon to Chief Sharpclaw at the Valley of Spirits in Orgrimmar.",en={15535},l=60,n="The Horde Needs More Baked Salmon!",ob={i={{13935}}},ps={8615},r=178,rl=1,sf=1,sn={15535}}
T[8620]={d="Recover the 8 lost chapters of Draconic for Dummies and combine them with the Magical Book Binding and return the completed book of Draconic for Dummies: Volume II to Narain Soothfancy in Tanaris.",en={11811},l=60,n="The Only Prescription",ob={i={{21111}}},ps={8606},r=0,rl=60,rp={910,0},rs={21103,21104,21105,21106,21107,21108,21109,21110},sn={11811},su=21112,tg=62,x=6600}
T[8621]={c=64,d="Bring the Qiraji Bindings of Dominance, 2 Idols of the Sage, 5 Bronze Scarabs and 5 Clay Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Stormcaller's Footguards",ob={i={{20932},{20877},{20861},{20863}}},ps={8579},r=178,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8622]={c=64,d="Bring the Carapace of the Old God, 2 Idols of the Sage, 5 Silver Scarabs and 5 Bone Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Stormcaller's Hauberk",ob={i={{20929},{20877},{20860},{20864}}},ps={8579},r=178,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8623]={c=64,d="Bring Vek'lor's Diadem, 2 Idols of Rebirth, 5 Stone Scarabs and 5 Crystal Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Stormcaller's Diadem",ob={i={{20930},{20878},{20858},{20862}}},ps={8579},r=178,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8624]={c=64,d="Bring the Skin of the Great Sandworm, 2 Idols of Strife, 5 Bronze Scarabs and 5 Ivory Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Stormcaller's Leggings",ob={i={{20931},{20881},{20865},{20861}}},ps={8579},r=178,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8625]={c=128,d="Bring the Qiraji Bindings of Dominance, 2 Idols of Death, 5 Stone Scarabs and 5 Bronze Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Enigma Shoulderpads",ob={i={{20932},{20876},{20858},{20861}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8626]={c=4,d="Bring the Qiraji Bindings of Command, 2 Idols of Life, 5 Stone Scarabs and 5 Bone Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Striker's Footguards",ob={i={{20928},{20879},{20858},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8627]={c=2,d="Bring the the Carapace of the Old God, 2 Idols of the Sage, 5 Silver Scarabs and 5 Bone Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Avenger's Breastplate",ob={i={{20929},{20877},{20860},{20864}}},ps={8579},r=77,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8628]={c=2,d="Bring Vek'lor's Diadem, 2 Idols of Rebirth, 5 Stone Scarabs and 5 Crystal Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Avenger's Crown",ob={i={{20930},{20878},{20858},{20862}}},ps={8579},r=77,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8629]={c=2,d="Bring the Skin of the Great Sandworm, 2 Idols of Strife, 5 Bronze Scarabs and 5 Ivory Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Avenger's Legguards",ob={i={{20931},{20881},{20865},{20861}}},ps={8579},r=77,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8630]={c=2,d="Bring the Qiraji Bindings of Dominance, 2 Idols of Life, 5 Crystal Scarabs and 5 Gold Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Avenger's Pauldrons",ob={i={{20932},{20879},{20859},{20862}}},ps={8579},r=77,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8631]={c=128,d="Bring Ouro's Intact Hide, 2 Idols of the Sage, 5 Silver Scarabs and 5 Bone Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Enigma Leggings",ob={i={{20927},{20877},{20860},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8632]={c=128,d="Bring Vek'nilash's Circlet, 2 Idols of Night, 5 Bronze Scarabs and 5 Ivory Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Enigma Circlet",ob={i={{20926},{20875},{20861},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8633]={c=128,d="Bring the Husk of the Old God, 2 Idols of the Sun, 5 Gold Scarabs and 5 Clay Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Enigma Robes",ob={i={{20933},{20874},{20859},{20863}}},ps={8579},r=0,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8634]={c=128,d="Bring the Qiraji Bindings of Dominance, 2 Idols of the Sun, 5 Silver Scarabs and 5 Crystal Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Enigma Boots",ob={i={{20932},{20874},{20860},{20862}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8637]={c=8,d="Bring the Qiraji Bindings of Command, 2 Idols of Strife, 5 Crystal Scarabs and 5 Bone Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Deathdealer's Boots",ob={i={{20928},{20881},{20862},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8638]={c=8,d="Bring the the Carapace of the Old God, 2 Idols of Strife, 5 Bronze Scarabs and 5 Ivory Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Deathdealer's Vest",ob={i={{20929},{20881},{20861},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8639]={c=8,d="Bring Vek'lor's Diadem, 2 Idols of the War, 5 Gold Scarabs and 5 Clay Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Deathdealer's Helm",ob={i={{20930},{20882},{20863},{20859}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8640]={c=8,d="Bring Ouro's Intact Hide, 2 Idols of Night, 5 Stone Scarabs and 5 Crystal Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Deathdealer's Leggings",ob={i={{20927},{20875},{20858},{20862}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8641]={c=8,d="Bring the Qiraji Bindings of Command, 2 Idols of the Sun, 5 Silver Scarabs and 5 Clay Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Deathdealer's Spaulders",ob={i={{20928},{20874},{20860},{20863}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8655]={c=2,d="Bring the Qiraji Bindings of Dominance, 2 Idols of the Sage, 5 Bronze Scarabs and 5 Clay Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Avenger's Greaves",ob={i={{20932},{20877},{20861},{20863}}},ps={8579},r=77,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8656]={c=4,d="Bring the the Carapace of the Old God, 2 Idols of Life, 5 Gold Scarabs and 5 Clay Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Striker's Hauberk",ob={i={{20929},{20879},{20859},{20863}}},ps={8579},r=0,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8657]={c=4,d="Bring Vek'lor's Diadem, 2 Idols of Strife, 5 Bronze Scarabs and 5 Ivory Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Striker's Diadem",ob={i={{20930},{20881},{20861},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8658]={c=4,d="Bring the Skin of the Great Sandworm, 2 Idols of the Sun, 5 Silver Scarabs and 5 Bone Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Striker's Leggings",ob={i={{20931},{20874},{20860},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8659]={c=4,d="Bring the Qiraji Bindings of Command, 2 Idols of War, 5 Crystal Scarabs and 5 Ivory Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Striker's Pauldrons",ob={i={{20928},{20882},{20862},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8660]={c=256,d="Bring the Qiraji Bindings of Dominance, 2 Idols of Night, 5 Clay Scarabs and 5 Ivory Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Doomcaller's Footwraps",ob={i={{20932},{20875},{20863},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8661]={c=256,d="Bring the the Husk of the Old God, 2 Idols of Night, 5 Stone Scarabs and 5 Crystal Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Doomcaller's Robes",ob={i={{20933},{20875},{20862},{20858}}},ps={8579},r=0,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8662]={c=256,d="Bring Vek'nilash's Circlet, 2 Idols of Death, 5 Silver Scarabs and 5 Bone Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Doomcaller's Circlet",ob={i={{20926},{20876},{20860},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8663]={c=256,d="Bring the Skin of the Great Sandworm, 2 Idols of Rebirth, 5 Gold Scarabs and 5 Clay Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Doomcaller's Trousers",ob={i={{20931},{20878},{20859},{20863}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8664]={c=256,d="Bring the Qiraji Bindings of Dominance, 2 Idols of the Sage, 5 Bronze Scarabs and 5 Bone Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Doomcaller's Mantle",ob={i={{20932},{20877},{20861},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8665]={c=1024,d="Bring the Qiraji Bindings of Dominance, 2 Idols of Rebirth, 5 Stone Scarabs and 5 Silver Scarabs to Kandrostrasz in Ahn'Qiraj. This quest also requires Neutral faction with the Brood of Nozdormu.",en={15503},l=60,n="Genesis Boots",ob={i={{20932},{20878},{20858},{20860}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8666]={c=1024,d="Bring the the Husk of the Old God, 2 Idols of Rebirth, 5 Bronze Scarabs and 5 Ivory Scarabs to Vethsera inside Ahn'Qiraj. You must also attain Honored reputation with the Brood of Nozdormu to complete this quest.",en={15504},l=60,n="Genesis Vest",ob={i={{20933},{20878},{20861},{20865}}},ps={8579},r=0,rl=60,sf=1,sn={15504},tg=62,x=9950}
T[8667]={c=1024,d="Bring Vek'lor's Diadem, 2 Idols of Life, 5 Gold Scarabs and 5 Clay Scarabs to Andorgos in Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Genesis Helm",ob={i={{20930},{20879},{20859},{20863}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8668]={c=1024,d="Bring the Skin of the Great Sandworm, 2 Idols of War, 5 Stone Scarabs and 5 Crystal Scarabs to Kandrostrasz inside Ahn'Qiraj. You must also attain Friendly reputation with the Brood of Nozdormu to complete this quest.",en={15503},l=60,n="Genesis Trousers",ob={i={{20931},{20882},{20858},{20862}}},ps={8579},r=0,rl=60,sf=1,sn={15503},tg=62,x=9950}
T[8669]={c=1024,d="Bring the Qiraji Bindings of Dominance, 2 Idols of Strife, 5 Gold Scarabs and 5 Bone Scarabs to Andorgos in Ahn'Qiraj. You must also attain Neutral reputation with the Brood of Nozdormu to complete this quest.",en={15502},l=60,n="Genesis Shoulderpads",ob={i={{20932},{20881},{20859},{20864}}},ps={8579},r=0,rl=60,sf=1,sn={15502},tg=62,x=9950}
T[8687]={d="Slay 30 Hive'Zora Tunnelers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing VII in order to complete this quest.",en={15181},l=60,n="Target: Hive'Zora Tunnelers",ob={k={{11726}}},r=0,rl=60,sf=1,si={21251},su=21251,tg=1,x=660}
T[8689]={c=16,d="Bring 1 Qiraji Martial Drape, 2 Jasper Idols, 5 Gold Scarabs and 5 Clay Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Shroud of Infinite Wisdom",ob={i={{20885},{20870},{20859},{20863}}},r=0,rl=60,sn={15500},tg=62,x=6600}
T[8690]={c=64,d="Bring 1 Qiraji Regal Drape, 2 Obsidian Idols, 5 Clay Scarabs and 5 Gold Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Cloak of the Gathering Storm",ob={i={{20889},{20871},{20863},{20859}}},r=178,rl=60,sn={15500},tg=62,x=6600}
T[8691]={c=128,d="Bring 1 Qiraji Martial Drape, 2 Alabaster Idols, 5 Stone Scarabs and 5 Crystal Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Drape of Vaulted Secrets",ob={i={{20885},{20873},{20858},{20862}}},r=0,rl=60,sn={15500},tg=62,x=6600}
T[8692]={c=1024,d="Bring 1 Qiraji Regal Drape, 2 Vermillion Idols, 5 Silver Scarabs and 5 Bone Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Cloak of Unending Life",ob={i={{20889},{20872},{20864},{20860}}},r=0,rl=60,sn={15500},tg=62,x=6600}
T[8693]={c=8,d="Bring 1 Qiraji Martial Drape, 2 Azure Idols, 5 Bronze Scarabs and 5 Ivory Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Cloak of Veiled Shadows",ob={i={{20885},{20866},{20861},{20865}}},r=0,rl=60,sn={15500},tg=62,x=6600}
T[8694]={c=256,d="Bring 1 Qiraji Regal Drape, 2 Amber Idols, 5 Ivory Scarabs and 5 Bronze Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Shroud of Unspoken Names",ob={i={{20889},{20869},{20861},{20865}}},r=0,rl=60,sn={15500},tg=62,x=6600}
T[8695]={c=2,d="Bring 1 Qiraji Regal Drape, 2 Obsidian Idols, 5 Gold Scarabs and 5 Clay Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Cape of Eternal Justice",ob={i={{20889},{20871},{20859},{20863}}},r=77,rl=60,sn={15500},tg=62,x=6600}
T[8696]={c=4,d="Bring 1 Qiraji Regal Drape, 2 Lambent Idols, 5 Stone Scarabs and 5 Crystal Scarabs to Keyl Swiftclaw in Silithus. You must also obtain Revered reputation with Cenarion Circle to complete this quest.",en={15500},l=60,n="Cloak of the Unseen Path",ob={i={{20889},{20868},{20858},{20862}}},r=0,rl=60,sn={15500},tg=62,x=6600}
T[8697]={c=16,d="Bring 1 Qiraji Ceremonial Ring, 2 Obsidian Idols, 5 Silver Scarabs and 5 Bone Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Ring of Infinite Wisdom",ob={i={{20888},{20871},{20860},{20864}}},r=0,rl=60,sn={15498},tg=62,x=6600}
T[8698]={c=64,d="Bring 1 Qiraji Magisterial Ring, 2 Vermillion Idols, 5 Silver Scarabs and 5 Bone Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Ring of the Gathering Storm",ob={i={{20884},{20872},{20860},{20864}}},r=178,rl=60,sn={15498},tg=62,x=6600}
T[8699]={c=128,d="Bring 1 Qiraji Magisterial Ring, 2 Azure Idols, 5 Gold Scarabs and 5 Clay Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Band of Vaulted Secrets",ob={i={{20884},{20866},{20859},{20863}}},r=0,rl=60,sn={15498},tg=62,x=6600}
T[8700]={c=1024,d="Bring 1 Qiraji Magisterial Ring, 2 Alabaster Idols, 5 Bronze Scarabs and 5 Ivory Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Band of Unending Life",ob={i={{20884},{20873},{20861},{20865}}},r=0,rl=60,sn={15498},tg=62,x=6600}
T[8701]={c=8,d="Bring 1 Qiraji Ceremonial Ring, 2 Onyx Idols, 5 Stone Scarabs and 5 Crystal Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Band of Veiled Shadows",ob={i={{20888},{20867},{20858},{20862}}},r=0,rl=60,sn={15498},tg=62,x=6600}
T[8702]={c=256,d="Bring 1 Qiraji Ceremonial Ring, 2 Jasper Idols, 5 Stone Scarabs and 5 Crystal Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Ring of Unspoken Names",ob={i={{20888},{20870},{20858},{20862}}},r=0,rl=60,sn={15498},tg=62,x=6600}
T[8703]={c=2,d="Bring 1 Qiraji Magisterial Ring, 2 Vermillion Idols, 5 Silver Scarabs and 5 Bone Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Ring of Eternal Justice",ob={i={{20884},{20872},{20860},{20864}}},r=77,rl=60,sn={15498},tg=62,x=6600}
T[8704]={c=4,d="Bring 1 Qiraji Ceremonial Ring, 2 Amber Idols, 5 Gold Scarabs and 5 Clay Scarabs to Windcaller Yessendra in Silithus. You must also attain Honored reputation with Cenarion Circle to complete this quest.",en={15498},l=60,n="Signet of the Unseen Path",ob={i={{20888},{20869},{20859},{20863}}},r=0,rl=60,sn={15498},tg=62,x=6600}
T[8705]={c=16,d="Bring 1 Qiraji Ornate Hilt, 2 Lambent Idols, 5 Bronze Scarabs and 5 Ivory Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Gavel of Infinite Wisdom",ob={i={{20890},{20868},{20861},{20865}}},r=0,rl=60,sn={15499},tg=62,x=6600}
T[8706]={c=64,d="Bring 1 Qiraji Spiked Hilt, 2 Amber Idols, 5 Ivory Scarabs and 5 Bronze Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Hammer of the Gathering Storm",ob={i={{20886},{20869},{20861},{20865}}},r=178,rl=60,sn={15499},tg=62,x=6600}
T[8707]={c=128,d="Bring 1 Qiraji Ornate Hilt, 2 Obsidian Idols, 5 Silver Scarabs and 5 Bone Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Blade of Vaulted Secrets",ob={i={{20890},{20871},{20860},{20864}}},r=0,rl=60,sn={15499},tg=62,x=6600}
T[8708]={c=1024,d="Bring 1 Qiraji Ornate Hilt, 2 Jasper Idols, 5 Crystal Scarabs and 5 Stone Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Mace of Unending Life",ob={i={{20890},{20870},{20862},{20858}}},r=0,rl=60,sn={15499},tg=62,x=6600}
T[8709]={c=8,d="Bring 1 Qiraji Spiked Hilt, 2 Vermillion Idols, 5 Gold Scarabs and 5 Clay Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Dagger of Veiled Shadows",ob={i={{20886},{20872},{20859},{20863}}},r=0,rl=60,sn={15499},tg=62,x=6600}
T[8710]={c=256,d="Bring 1 Qiraji Ornate Hilt, 2 Onyx Idols, 5 Gold Scarabs and 5 Clay Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Kris of Unspoken Names",ob={i={{20890},{20867},{20859},{20863}}},r=0,rl=60,sn={15499},tg=62,x=6600}
T[8711]={c=2,d="Bring 1 Qiraji Spiked Hilt, 2 Amber Idols, 5 Bronze Scarabs and 5 Ivory Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Blade of Eternal Justice",ob={i={{20886},{20869},{20861},{20865}}},r=77,rl=60,sn={15499},tg=62,x=6600}
T[8712]={c=4,d="Bring 1 Qiraji Spiked Hilt, 2 Azure Idols, 5 Silver Scarabs and 5 Bone Scarabs to Warden Haro in Silithus. You must also attain Exalted reputation with Cenarion Circle to complete this quest.",en={15499},l=60,n="Scythe of the Unseen Path",ob={i={{20886},{20866},{20860},{20864}}},r=0,rl=60,sn={15499},tg=62,x=6600}
T[8728]={d="Narain Soothfancy in Tanaris wants you to bring him 20 Arcanite Bars, 10 Elementium Ore, 10 Azerothian Diamonds, and 10 Blue Sapphires.",en={11811},l=60,n="The Good News and The Bad News",nx=8729,ob={i={{12360},{18562},{12800},{12361}}},pg={8578,8587,8620},r=0,rl=60,rp={910,0},sn={11811},x=6600}
T[8729]={d="Use the Arcanite Buoy at the Swirling Maelstrom at the Bay of Storms in Azshara.",en={15192},l=60,n="The Wrath of Neptulon",ob={i={{21137}}},ps={8728},r=0,rl=60,rp={910,0},sn={11811},su=21136,tg=62,x=9950}
T[8730]={d="Slay Nefarian and recover the Red Scepter Shard. Return the Red Scepter Shard to Anachronos at the Caverns of Time in Tanaris. You have 5 hours to complete this task.",en={15192},l=60,n="Nefarius's Corruption",ob={i={{21138}}},ps={8555},r=0,rl=60,rp={910,0},sn={13020},tg=62,x=9950}
T[8731]={d="Report to Krug Skullsplit at the Orgrimmar Legion post in front of Hive'Regal. Prepare your Unsigned Field Duty Papers, obtain Signed Field Duty Papers and bring them to Windcaller Kaldon in Cenarion Hold.",en={15540},l=60,n="Field Duty",ob={i={{20810}}},r=178,rl=60,sf=1,sn={15540},su=21143,tg=1}
T[8732]={en={15612},l=60,n="Field Duty Papers",ob={i={{23024}}},pa=8731,r=178,rl=60,sf=1,sn={15612},su=20810}
T[8733]={d="Travel to the continent of Teldrassil and find Malfurion's agent somewhere outside the walls of Darnassus.",en={15624},l=60,n="Eranikus, Tyrant of the Dream",nx=8734,ps={8555},r=0,rl=60,rp={910,0},sn={15362},x=6600,z=1477}
T[8734]={d="Travel to the Moonglade and speak to Keeper Remulos.",en={11832},l=60,n="Tyrande and Remulos",nx=8735,ps={8733},r=0,rl=60,rp={910,0},sn={15624},x=1650}
T[8735]={d="Travel to the four Emerald Dream portals in Azeroth and collect a Fragment of the Nightmare's Corruption from each. Return to Keeper Remulos in the Moonglade when you have completed this task.",en={11832},l=60,n="The Nightmare's Corruption",nx=8736,ob={i={{21147},{21149},{21148},{21146}}},ps={8734},r=0,rl=60,rp={910,0},sn={11832},tg=62,x=6600}
T[8736]={d="Defend Nighthaven from Eranikus. Do not let Keeper Remulos perish. Do not slay Eranikus. Defend yourself. Await Tyrande.",en={11832},l=60,n="The Nightmare Manifests",nx=8741,ob={e={"The Redemption of Eranikus",{{1450,51.8,36.4}}}},ps={8735},r=0,rl=60,rp={910,0},sf=2,sn={11832},tg=62,x=9950}
T[8737]={d="Summon and slay an Azure Templar and report back to Bor Wildmane in Cenarion Hold. You must also bring Tactical Task Briefing I in order to complete this quest.",en={15306},l=60,n="Azure Templar",ob={k={{15211}}},r=0,rl=60,sf=1,si={21245},su=21245,tg=1,x=660}
T[8738]={d="Contact Cenarion Scout Landion inside Hive'Regal and return the Hive'Regal Scout Report to Windcaller Proudhorn at Cenarion Hold. You must also bring Tactical Task Briefing VII in order to complete this quest.",en={15191},l=60,n="Hive'Regal Scout Report",ob={i={{21160}}},r=0,rl=60,sf=1,si={21166},su=21166,tg=1,x=660}
T[8739]={d="Contact Cenarion Scout Jalia inside Hive'Ashi and return the Hive'Ashi Scout Report to Windcaller Proudhorn at Cenarion Hold. You must also bring Tactical Task Briefing VIII in order to complete this quest.",en={15191},l=60,n="Hive'Ashi Scout Report",ob={i={{21161}}},r=0,rl=60,sf=1,si={21167},su=21167,tg=1,x=660}
T[8740]={d="Slay Twilight Marauder Morna and 5 Twilight Marauders. Report to Windcaller Proudhorn when your task is finished. You must also bring Tactical Task Briefing IX in order to complete this quest.",en={15191},l=60,n="Twilight Marauders",ob={k={{15541},{15542}}},r=0,rl=60,sf=1,si={20944},su=20944,tg=1,x=660}
T[8741]={d="Take the Green Scepter Shard to Anachronos at the Caverns of Time in Tanaris.",en={15192},l=60,n="The Champion Returns",ps={8736},r=0,rl=60,rp={910,0},sn={11832},su=21139,x=6600}
T[8742]={en={15192},l=60,n="The Might of Kalimdor",pg={8729,8730,8741},r=0,rl=60,rp={910,0},sn={15192},x=9950}
T[8743]={eo={180717},l=60,n="Bang a Gong!",ob={i={{21175}}},ps={8742},r=0,rl=60,rp={910,0},so={180717},tg=82}
T[8745]={en={15693},l=60,n="Treasure of the Timeless One",ps={8742},r=0,rl=60,rp={910,0},sn={15693},x=6600}
T[8747]={en={15192},ex={8752,8757},l=60,n="The Path of the Protector",nx=8748,r=0,rl=60,rp={910,0},sn={15192},x=6600}
T[8748]={en={15192},ex={8752,8757},l=60,n="The Path of the Protector",nx=8749,ob={i={{21196}}},ps={8747},r=0,rl=60,rp={910,3000},sn={15192},x=6600}
T[8749]={en={15192},ex={8752,8757},l=60,n="The Path of the Protector",nx=8750,ob={i={{21197}}},ps={8748},r=0,rl=60,rp={910,9000},sn={15192},x=6600}
T[8750]={en={15192},ex={8752,8757},l=60,n="The Path of the Protector",nx=8751,ob={i={{21198}}},ps={8749},r=0,rl=60,rp={910,21000},sn={15192},x=6600}
T[8751]={en={15192},ex={8752,8757},l=60,n="The Protector of Kalimdor",nx=8764,ob={i={{21199}}},ps={8750},r=0,rl=60,rp={910,42000},sn={15192},x=9950}
T[8752]={en={15192},ex={8747,8757},l=60,n="The Path of the Conqueror",nx=8753,r=0,rl=60,rp={910,0},sn={15192},x=6600}
T[8753]={en={15192},ex={8747,8757},l=60,n="The Path of the Conqueror",nx=8754,ob={i={{21201}}},ps={8752},r=0,rl=60,rp={910,3000},sn={15192},x=6600}
T[8754]={en={15192},ex={8747,8757},l=60,n="The Path of the Conqueror",nx=8755,ob={i={{21202}}},ps={8753},r=0,rl=60,rp={910,9000},sn={15192},x=6600}
T[8755]={en={15192},ex={8747,8757},l=60,n="The Path of the Conqueror",nx=8756,ob={i={{21203}}},ps={8754},r=0,rl=60,rp={910,21000},sn={15192},x=6600}
T[8756]={en={15192},ex={8747,8757},l=60,n="The Qiraji Conqueror",nx=8766,ob={i={{21204}}},ps={8755},r=0,rl=60,rp={910,42000},sn={15192},x=9950}
T[8757]={en={15192},ex={8747,8752},l=60,n="The Path of the Invoker",nx=8758,r=0,rl=60,rp={910,0},sn={15192},x=6600}
T[8758]={en={15192},ex={8747,8752},l=60,n="The Path of the Invoker",nx=8759,ob={i={{21206}}},ps={8757},r=0,rl=60,rp={910,3000},sn={15192},x=6600}
T[8759]={en={15192},ex={8747,8752},l=60,n="The Path of the Invoker",nx=8760,ob={i={{21207}}},ps={8758},r=0,rl=60,rp={910,9000},sn={15192},x=6600}
T[8760]={en={15192},ex={8747,8752},l=60,n="The Path of the Invoker",nx=8761,ob={i={{21208}}},ps={8759},r=0,rl=60,rp={910,21000},sn={15192},x=6600}
T[8761]={en={15192},ex={8747,8752},l=60,n="The Grand Invoker",nx=8765,ob={i={{21209}}},ps={8760},r=0,rl=60,rp={910,42000},sn={15192},x=9950}
T[8764]={en={15192},l=60,n="The Changing of Paths - Protector No More",ob={i={{21200},{20858},{20859},{20860}}},ps={8751},r=0,rl=60,rp={910,42000},sf=1,sn={15192}}
T[8765]={en={15192},l=60,n="The Changing of Paths - Invoker No More",ob={i={{21210},{20861},{20862},{20863}}},ps={8761},r=0,rl=60,rp={910,42000},sf=1,sn={15192}}
T[8766]={en={15192},l=60,n="The Changing of Paths - Conqueror No More",ob={i={{21205},{20864},{20865},{20858}}},ps={8756},r=0,rl=60,rp={910,42000},sf=1,sn={15192}}
T[8770]={d="Slay 30 Hive'Ashi Defenders and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing I in order to complete this quest.",en={15181},l=60,n="Target: Hive'Ashi Defenders",ob={k={{11722}}},r=0,rl=60,sf=1,si={21749},su=21749,tg=1,x=660}
T[8771]={d="Slay 30 Hive'Ashi Sandstalkers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing II in order to complete this quest.",en={15181},l=60,n="Target: Hive'Ashi Sandstalkers",ob={k={{11723}}},r=0,rl=60,sf=1,si={21750},su=21750,tg=1,x=660}
T[8772]={d="Slay 30 Hive'Zora Waywatchers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing VI in order to complete this quest.",en={15181},l=60,n="Target: Hive'Zora Waywatchers",ob={k={{11725}}},r=0,rl=60,sf=1,si={21250},su=21250,tg=1,x=660}
T[8773]={d="Slay 30 Hive'Zora Reavers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing IV in order to complete this quest.",en={15181},l=60,n="Target: Hive'Zora Reavers",ob={k={{11728}}},r=0,rl=60,sf=1,si={21248},su=21248,tg=1,x=660}
T[8774]={d="Kill 30 Hive'Regal Ambushers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing VIII in order to complete this quest.",en={15181},l=60,n="Target: Hive'Regal Ambushers",ob={k={{11730}}},r=0,rl=60,sf=1,si={21252},su=21252,tg=1,x=660}
T[8775]={d="Kill 30 Hive'Regal Spitfires and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing IX in order to complete this quest.",en={15181},l=60,n="Target: Hive'Regal Spitfires",ob={k={{11732}}},r=0,rl=60,sf=1,si={21253},su=21253,tg=1,x=660}
T[8776]={d="Kill 30 Hive'Regal Slavemakers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing X in order to complete this quest.",en={15181},l=60,n="Target: Hive'Regal Slavemakers",ob={k={{11733}}},r=0,rl=60,sf=1,si={21255},su=21255,tg=1,x=660}
T[8777]={d="Kill 30 Hive'Regal Burrowers and report back to Commander Mar'alith at Cenarion Hold in Silithus. You must also bring Combat Task Briefing XI in order to complete this quest.",en={15181},l=60,n="Target: Hive'Regal Burrowers",ob={k={{11731}}},r=0,rl=60,sf=1,si={21256},su=21256,tg=1,x=660}
T[8778]={d="Bring 6 Oils of Immolation, 5 Goblin Rocket Fuel and 10 Dense Blasting Powder to Arcanist Nozzlespring near Hive'Zora in Silithus. You must also bring Logistics Task Briefing IV in order to complete this quest.",en={15444},l=60,n="The Ironforge Brigade Needs Explosives!",ob={i={{8956},{9061},{15992}}},r=77,rl=60,sf=1,si={21257},su=21257,x=660}
T[8779]={d="Bring 1 Large Brilliant Shard, 1 Large Radiant Shard and 1 Huge Emerald to Geologist Larksbane at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing V in order to complete this quest.",en={15183},l=60,n="Scrying Materials",ob={i={{14344},{11178},{12364}}},r=77,rl=60,sf=1,si={21259},su=21259,x=660}
T[8780]={d="Bring 8 Rugged Armor Kits and 8 Heavy Armor Kits to Janela Stouthammer at the Ironforge Brigade Outpost near Hive'Zora in Silithus. You must also bring Logistics Task Briefing VII in order to complete this quest.",en={15443},l=60,n="Armor Kits for the Field",ob={i={{15564},{4265}}},r=77,rl=60,sf=1,si={21263},su=21263,x=660}
T[8781]={d="Bring 2 Moonsteel Broadswords to Janela Stouthammer at the Ironforge Brigade Outpost outside of Hive'Zora. You must also bring Logistics Task Briefing VI in order to complete this quest.",en={15443},l=60,n="Arms for the Field",ob={i={{3853}}},r=77,rl=60,sf=1,si={21260},su=21260,x=660}
T[8782]={d="Bring 1 Mooncloth, 2 Bolts of Runecloth and 1 Ironweb Spider Silk to Windcaller Proudhorn at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing VIII in order to complete this quest.",en={15191},l=60,n="Uniform Supplies",ob={i={{14342},{14048},{14227}}},r=77,rl=60,sf=1,si={21262},su=21262,x=660}
T[8783]={d="Bring 2 Enchanted Thorium Bars and 2 Enchanted Leather to Vargus at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing IX in order to complete this quest.",en={15176},l=60,n="Extraordinary Materials",ob={i={{12655},{12810}}},r=77,rl=60,sf=1,si={21265},su=21265,x=660}
T[8784]={d="Take the Ancient Qiraji Artifact to the dragons hiding near the entrance of the temple.",en={15502},l=60,n="Secrets of the Qiraji",r=0,rl=60,sf=1,si={21230},su=21230}
T[8785]={d="Bring 6 Powerful Mojo, 6 Flasks of Big Mojo and 8 Oils of Immolation to Shadow Priestess Shai near Hive'Regal in Silithus. You must also bring Logistics Task Briefing IV in order to complete this quest.",en={15615},l=60,n="The Orgrimmar Legion Needs Mojo!",ob={i={{8956},{8152},{12804}}},r=178,rl=60,sf=1,si={21258},su=21258,x=660}
T[8786]={d="Bring 3 Massive Iron Axes to Merok Longstride at the Orgrimmar Legion camp outside of Hive'Regal. You must also bring Logistics Task Briefing VI in order to complete this quest.",en={15613},l=60,n="Arms for the Field",ob={i={{3855}}},r=178,rl=60,sf=1,si={21261},su=21261,x=660}
T[8787]={d="Bring 8 Rugged Armor Kits and 8 Heavy Armor Kits to Merok Longstride near Hive'Regal. You must also bring Logistics Task Briefing VII in order to complete this quest.",en={15613},l=60,n="Armor Kits for the Field",ob={i={{15564},{4265}}},r=178,rl=60,sf=1,si={21264},su=21264,x=660}
T[8789]={d="Arygos in the Temple of Ahn'Qiraj will create Elementium Infused Armaments for you should you bring him Imperial Qiraji Armaments and 3 Elementium Ore.",en={15380},l=60,n="Imperial Qiraji Armaments",ob={i={{21232},{18562}}},r=0,rl=60,sf=1,sn={15380},tg=62}
T[8790]={d="Merithra of the Dream in the Temple of Ahn'Qiraj will create Elementium Infused Armaments for you should you bring her Imperial Qiraji Regalia and 3 Elementium Ore.",en={15378},l=60,n="Imperial Qiraji Regalia",ob={i={{21237},{18562}}},r=0,rl=60,sf=1,sn={15378},tg=62}
T[8791]={d="Deliver the Head of Ossirian the Unscarred to Commander Mar'alith at Cenarion Hold in Silithus.",en={15181},l=60,n="The Fall of Ossirian",r=0,rl=60,si={21220},su=21220,tg=62,x=9950}
T[8792]={d="Speak with Warlord Gorchuk in Orgrimmar's Valley of Spirits.",en={15700},ex={8793,8794},l=60,n="The Horde Needs Your Help!",r=178,rl=1,sn={15702},x=660}
T[8793]={d="Speak with Warlord Gorchuk in Orgrimmar's Valley of Spirits.",en={15700},ex={8792,8794},l=60,n="The Horde Needs Your Help!",r=178,rl=1,sn={15703},x=9950}
T[8794]={d="Speak with Warlord Gorchuk in Orgrimmar's Valley of Spirits.",en={15700},ex={8792,8793},l=60,n="The Horde Needs Your Help!",r=178,rl=1,sn={15704},x=9950}
T[8795]={d="Speak with Field Marshal Snowfall in Ironforge's Military Ward.",en={15701},ex={8796,8797},l=60,n="The Alliance Needs Your Help!",r=77,rl=1,sn={15707},x=660}
T[8796]={d="Speak with Field Marshal Snowfall in Ironforge's Military Ward.",en={15701},ex={8795,8797},l=60,n="The Alliance Needs Your Help!",r=77,rl=1,sn={15708},x=9950}
T[8797]={d="Speak with Field Marshal Snowfall in Ironforge's Military Ward.",en={15701},ex={8795,8796},l=60,n="The Alliance Needs Your Help!",r=77,rl=1,sn={15709},x=9950}
T[8798]={en={10305},l=60,n="A Yeti of Your Own",ps={5163},r=0,rl=55,sk={202,250},sn={10305}}
T[8800]={d="Talk to Vargus at Cenarion Hold in Silithus.",en={15176},l=60,n="Cenarion Battlegear",r=0,rl=60,sn={15540},x=660}
T[8801]={d="Take the Eye of C'Thun to Caelastrasz in the Temple of Ahn'Qiraj.",en={15379},l=60,n="C'Thun's Legacy",nx=8802,r=0,rl=60,si={21221},su=21221,x=9950}
T[8802]={d="Take the Eye of C'Thun to Anachronos at the Caverns of Time.",en={15192},l=60,n="The Savior of Kalimdor",ps={8801},r=0,rl=60,sn={15379},su=21221,x=9950}
T[8804]={d="Bring 4 Globes of Water, 4 Powerful Anti-Venom and 4 Smoked Desert Dumplings to Calandrath at the inn in Cenarion Hold in Silithus. You must also bring Logistics Task Briefing I in order to complete this quest.",en={15174},l=60,n="Desert Survival Kits",ob={i={{7079},{19440},{20452}}},r=178,rl=55,sf=1,si={21378},su=21378,x=660}
T[8805]={d="Bring 3 Ornate Mithril Boots to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing II in order to complete this quest.",en={15182},l=60,n="Boots for the Guard",ob={i={{7936}}},r=178,rl=60,sf=1,si={21379},su=21379,x=660}
T[8806]={d="Bring 10 Dense Grinding Stones, 10 Solid Grinding Stones and 10 Heavy Grinding Stones to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing III in order to complete this quest.",en={15182},l=60,n="Grinding Stones for the Guard",ob={i={{12644},{7966},{3486}}},r=178,rl=60,sf=1,si={21380},su=21380,x=660}
T[8807]={d="Bring 1 Large Brilliant Shard, 1 Large Radiant Shard and 1 Huge Emerald to Geologist Larksbane at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing V in order to complete this quest.",en={15183},l=60,n="Scrying Materials",ob={i={{14344},{11178},{12364}}},r=178,rl=60,sf=1,si={21382},su=21382,x=660}
T[8808]={d="Bring 1 Mooncloth, 2 Bolts of Runecloth and 1 Ironweb Spider Silk to Windcaller Proudhorn at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing VIII in order to complete this quest.",en={15191},l=60,n="Uniform Supplies",ob={i={{14342},{14048},{14227}}},r=178,rl=60,sf=1,si={21384},su=21384,x=660}
T[8809]={d="Bring 2 Enchanted Thorium Bars and 2 Enchanted Leather to Vargus at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing IX in order to complete this quest.",en={15176},l=60,n="Extraordinary Materials",ob={i={{12655},{12810}}},r=178,rl=60,sf=1,si={21381},su=21381,x=660}
T[8810]={d="Bring 30 Heavy Runecloth Bandages, 30 Heavy Silk Bandages and 30 Heavy Mageweave Bandages to Windcaller Proudhorn at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing X in order to complete this quest.",en={15191},l=60,n="Bandages for the Field",ob={i={{14530},{8545},{6451}}},r=178,rl=60,sf=1,si={21385},su=21385,x=660}
T[8811]={en={15766},l=60,n="One Commendation Signet",nx=8830,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15731,15766}}
T[8812]={en={15764},l=60,n="One Commendation Signet",nx=8834,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15733,15764}}
T[8813]={en={15762},l=60,n="One Commendation Signet",nx=8836,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15734,15762}}
T[8814]={en={15763},l=60,n="One Commendation Signet",nx=8838,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15735,15763}}
T[8815]={en={15765},l=60,n="One Commendation Signet",nx=8832,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15736,15765}}
T[8816]={en={15768},l=60,n="One Commendation Signet",nx=8840,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15737,15768}}
T[8817]={en={15767},l=60,n="One Commendation Signet",nx=8842,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15738,15767}}
T[8818]={en={15761},l=60,n="One Commendation Signet",nx=8844,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15739,15761}}
T[8819]={en={15766},l=60,n="Ten Commendation Signets",nx=8831,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15731,15766}}
T[8820]={en={15764},l=60,n="Ten Commendation Signets",nx=8835,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15733,15764}}
T[8821]={en={15762},l=60,n="Ten Commendation Signets",nx=8837,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15734,15762}}
T[8822]={en={15763},l=60,n="Ten Commendation Signets",nx=8839,ob={i={{21436}}},r=77,rl=1,sf=1,sn={15735,15763}}
T[8823]={en={15765},l=60,n="Ten Commendation Signets",nx=8833,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15736,15765}}
T[8824]={en={15768},l=60,n="Ten Commendation Signets",nx=8841,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15737,15768}}
T[8825]={en={15767},l=60,n="Ten Commendation Signets",nx=8843,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15739,15767}}
T[8826]={en={15761},l=60,n="Ten Commendation Signets",nx=8845,ob={i={{21438}}},r=178,rl=1,sf=1,sn={15738,15761}}
T[8829]={d="Bring a Skin of Shadow, 3 Frayed Abomination Stitchings and 1 Twilight Cultist Robe to Aurel Goldleaf at Cenarion Hold in Silithus. You must also bring Logistics Task Briefing XI in order to complete this quest.",en={15282},l=60,n="The Ultimate Deception",ob={i={{12753},{12735},{20407}}},r=0,rl=60,sf=1,si={21514},su=21514,tg=1,x=660}
T[8830]={en={15766},l=60,n="One Commendation Signet",ob={i={{21436}}},ps={8811},r=77,rl=1,sf=1,sn={15766}}
T[8831]={en={15766},l=60,n="Ten Commendation Signets",ob={i={{21436}}},ps={8819},r=77,rl=1,sf=1,sn={15766}}
T[8832]={en={15765},l=60,n="One Commendation Signet",ob={i={{21438}}},ps={8815},r=178,rl=1,sf=1,sn={15765}}
T[8833]={en={15765},l=60,n="Ten Commendation Signets",ob={i={{21438}}},ps={8823},r=178,rl=1,sf=1,sn={15765}}
T[8834]={en={15764},l=60,n="One Commendation Signet",ob={i={{21436}}},ps={8812},r=77,rl=1,sf=1,sn={15764}}
T[8835]={en={15764},l=60,n="Ten Commendation Signets",ob={i={{21436}}},ps={8820},r=77,rl=1,sf=1,sn={15764}}
T[8836]={en={15762},l=60,n="One Commendation Signet",ob={i={{21436}}},ps={8813},r=77,rl=1,sf=1,sn={15762}}
T[8837]={en={15762},l=60,n="Ten Commendation Signets",ob={i={{21436}}},ps={8821},r=77,rl=1,sf=1,sn={15762}}
T[8838]={en={15763},l=60,n="One Commendation Signet",ob={i={{21436}}},ps={8814},r=77,rl=1,sf=1,sn={15763}}
T[8839]={en={15763},l=60,n="Ten Commendation Signets",ob={i={{21436}}},ps={8822},r=77,rl=1,sf=1,sn={15763}}
T[8840]={en={15768},l=60,n="One Commendation Signet",ob={i={{21438}}},ps={8816},r=178,rl=1,sf=1,sn={15768}}
T[8841]={en={15768},l=60,n="Ten Commendation Signets",ob={i={{21438}}},ps={8824},r=178,rl=1,sf=1,sn={15768}}
T[8842]={en={15767},l=60,n="One Commendation Signet",ob={i={{21438}}},ps={8817},r=178,rl=1,sf=1,sn={15767}}
T[8843]={en={15767},l=60,n="Ten Commendation Signets",ob={i={{21438}}},ps={8825},r=178,rl=1,sf=1,sn={15767}}
T[8844]={en={15761},l=60,n="One Commendation Signet",ob={i={{21438}}},ps={8818},r=178,rl=1,sf=1,sn={15761}}
T[8845]={en={15761},l=60,n="Ten Commendation Signets",ob={i={{21438}}},ps={8826},r=178,rl=1,sf=1,sn={15761}}
T[8846]={en={15701},l=19,n="Five Signets for War Supplies",ob={i={{21436}}},r=77,rl=10,sf=1,sn={15701}}
T[8847]={en={15701},l=29,n="Ten Signets for War Supplies",ob={i={{21436}}},r=77,rl=20,sf=1,sn={15701}}
T[8848]={en={15701},l=39,n="Fifteen Signets for War Supplies",ob={i={{21436}}},r=77,rl=30,sf=1,sn={15701}}
T[8849]={en={15701},l=49,n="Twenty Signets for War Supplies",ob={i={{21436}}},r=77,rl=40,sf=1,sn={15701}}
T[8850]={en={15701},l=60,n="Thirty Signets for War Supplies",ob={i={{21436}}},r=77,rl=50,sf=1,sn={15701}}
T[8851]={en={15700},l=19,n="Five Signets for War Supplies",ob={i={{21438}}},r=178,rl=10,sf=1,sn={15700}}
T[8852]={en={15700},l=29,n="Ten Signets for War Supplies",ob={i={{21438}}},r=178,rl=20,sf=1,sn={15700}}
T[8853]={en={15700},l=39,n="Fifteen Signets for War Supplies",ob={i={{21438}}},r=178,rl=30,sf=1,sn={15700}}
T[8854]={en={15700},l=49,n="Twenty Signets for War Supplies",ob={i={{21438}}},r=178,rl=40,sf=1,sn={15700}}
T[8855]={en={15700},l=60,n="Thirty Signets for War Supplies",ob={i={{21438}}},r=178,rl=50,sf=1,sn={15700}}
T[8893]={eo={142071},l=47,n="The Super Egg-O-Matic",ob={i={{8564}}},ps={2741},r=0,rl=42,sf=1,so={142071}}
T[8905]={c=1024,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with a set of Wildheart Bracers to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16714}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8906]={c=4,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with a set of Beaststalker's Bindings to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16681}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8907]={c=128,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with a set of Magister's Bindings to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16683}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8908]={c=2,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with a set of Lightforge Bracers to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16722}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8909]={c=16,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with 1 set of Devout Bracers to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16697}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8910]={c=8,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with a set of Shadowcraft Bracers to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16710}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8911]={c=256,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with a set of Dreadmist Bracers to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16703}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8912]={c=1,d="Acquire 15 Winterspring Blood Samples and 20 gold and bring them along with a set of Bracers of Valor to Deliana in Ironforge.",en={16013},l=60,n="An Earnest Proposition",nx=8922,ob={i={{21928},{16735}}},r=77,rl=58,sn={16013},tg=81,x=6600}
T[8913]={c=1024,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Wildheart Bracers to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16714}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8914]={c=4,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Beaststalker's Bindings to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16681}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8915]={c=128,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Magister's Bindings to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16683}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8916]={c=16,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Devout Bracers to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16697}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8917]={c=8,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Shadowcraft Bracers to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16710}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8918]={c=64,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Bindings of Elements to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16671}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8919]={c=256,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Dreadmist Bracers to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16703}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8920]={c=1,d="Acquire 15 Silithus Venom Samples and 20 gold and bring them along with a set of Bracers of Valor to Mokvar in Orgrimmar.",en={16012},l=60,n="An Earnest Proposition",nx=8923,ob={i={{22381},{16735}}},r=178,rl=58,sn={16012},tg=81,x=6600}
T[8921]={d="Return to Mux Manascrambler in Gadgetzan with 1 Delicate Arcanite Converter, 4 Greater Eternal Essence, 10 Stonescale Oil, 25 Volcanic Ash and 40 gold.",en={16014},l=60,n="The Ectoplasmic Distiller",nx=8924,ob={i={{16006},{16203},{13423},{22338}}},ps={8922,8923},r=0,rl=58,sn={16014},x=6600}
T[8922]={d="Bring the Sealed Blood Container to Mux Manascrambler inside Gadgetzan in Tanaris.",en={16014},l=60,n="A Supernatural Device",nx=8921,ps={8905,8906,8907,8908,8909,8910,8911,8912},r=77,rl=58,sn={16013},su=21985,x=6600}
T[8923]={d="Take the Sealed Venom Container to Mux Manascrambler in Gadgetzan.",en={16014},l=60,n="A Supernatural Device",nx=8921,ps={8913,8914,8915,8916,8917,8918,8919,8920},r=178,rl=58,sn={16012},su=22382,x=6600}
T[8924]={d="Use the Ectoplasmic Distiller near incorporeal undead to collect 12 Scorched Ectoplasms in Silithus, 12 Frozen Ectoplasms in Winterspring and 12 Stable Ectoplasms in the Eastern Plaguelands. Bring them along with the Ectoplasmic Distiller back to Mux Manascrambler in Gadgetzan.",en={16014},l=60,n="Hunting for Ectoplasm",nx=8925,ob={i={{21937},{21936},{21935}}},ps={8921},r=0,rl=58,sn={16014},su=21946,x=6600}
T[8925]={d="Find Magma Lord Bokk in the Burning Steppes, obtain his Magma Core and bring it to Mux Manascrambler in Gadgetzan.",en={16014},l=60,n="A Portable Power Source",nx=8928,ob={i={{21938}}},ps={8924},r=0,rl=58,sn={16014},x=6600}
T[8926]={c=1024,d="Bring a Wildheart Belt and a set of Wildheart Gloves Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16716},{16717}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950}
T[8927]={c=1024,d="Bring a Wildheart Belt and a set of Wildheart Gloves to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16716},{16717}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950}
T[8928]={d="Search for an imp inside a cave at the entrance of Darkwhisper Gorge in southern Winterspring, purchase a Fel Elemental Rod and return to Mux Manascrambler in Gadgetzan.",en={16014},l=60,n="A Shifty Merchant",ob={i={{21939}}},ps={8925},r=0,rl=58,sn={16014},tg=1,x=3300}
T[8929]={d="Use the Extra-Dimensional Ghost Revealer at the entrance to Stratholme and speak with the ghost of Anthion Harmon.",en={16016},l=60,n="In Search of Anthion",nx=8945,ps={8926,8931,8932,8933,8934,8935,8936,8937},r=77,rl=58,sn={16013},su=22115,x=6600}
T[8930]={d="Use the Extra-Dimensional Ghost Revealer at the entrance to Stratholme and speak with the ghost of Anthion Harmon.",en={16016},l=60,n="In Search of Anthion",nx=8945,ps={8927,8938,8939,8940,8941,8942,8943,8944},r=178,rl=58,sn={16012},su=22115,x=6600}
T[8931]={c=4,d="Bring a Beaststalker's Belt and a set of Beaststalker's Gloves to Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16680},{16676}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950,z=1583}
T[8932]={c=128,d="Bring a Magister's Belt and a set of Magister's Gloves to Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16685},{16684}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950}
T[8933]={c=2,d="Bring a Lightforge Belt and a set of Lightforge Gauntlets to Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16723},{16724}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950}
T[8934]={c=16,d="Bring a Devout Belt and a set of Devout Gloves to Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16696},{16692}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950}
T[8935]={c=8,d="Bring a Shadowcraft Belt and a set of Shadowcraft Gloves to Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16713},{16712}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950}
T[8936]={c=256,d="Bring a Dreadmist Belt and a set of Dreadmist Wraps to Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16702},{16705}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950}
T[8937]={c=1,d="Bring a Belt of Valor and a set of Gauntlets of Valor to Deliana in Ironforge.",en={16013},l=60,n="Just Compensation",nx=8929,ob={i={{16736},{16737}}},ps={8977},r=77,rl=58,sn={16013},tg=81,x=9950}
T[8938]={c=4,d="Bring a Beaststalker's Belt and a set of Beaststalker's Gloves to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16680},{16676}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950,z=1583}
T[8939]={c=128,d="Bring a Magister's Belt and a set of Magister's Gloves to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16685},{16684}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950}
T[8940]={c=16,d="Bring a Devout Belt and a set of Devout Gloves to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16696},{16692}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950}
T[8941]={c=8,d="Bring a Shadowcraft Belt and a set of Shadowcraft Gloves to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16713},{16712}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950}
T[8942]={c=64,d="Bring a Cord of Elements and a set of Gauntlets of Elements to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16673},{16672}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950}
T[8943]={c=256,d="Bring a Dreadmist Belt and a set of Dreadmist Wraps to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16702},{16705}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950}
T[8944]={c=1,d="Bring a Belt of Valor and a set of Gauntlets of Valor to Mokvar in Orgrimmar.",en={16012},l=60,n="Just Compensation",nx=8930,ob={i={{16736},{16737}}},ps={8978},r=178,rl=58,sn={16012},tg=81,x=9950}
T[8945]={d="Go into Stratholme and rescue Ysida Harmon from Baron Rivendare.",en={16031},l=60,n="Dead Man's Plea",nx=8946,ob={k={{16031,"Ysida Freed"}}},ps={8929,8930},r=0,rl=58,sn={16016},tg=81,x=8300,z=2017}
T[8946]={d="Bring Ysida's Locket to Anthion Harmon in Eastern Plaguelands.",en={16016},l=60,n="Proof of Life",nx=8947,ps={8945},r=0,rl=58,sn={16031},su=22139,x=6600}
T[8947]={d="Bring 3 Dark Iron Bars, 20 Enchanted Leather, 3 Mooncloth and 4 Cured Rugged Hides to Anthion Harmon in the Eastern Plaguelands.",en={16016},l=60,n="Anthion's Strange Request",nx=8948,ob={i={{11371},{12810},{14342},{15407}}},ps={8946},r=0,rl=58,sn={16016},x=6600}
T[8948]={d="Take the incomplete Banner of Provocation to Falrin Treeshaper at the library in Dire Maul.",en={16032},l=60,n="Anthion's Old Friend",nx=8949,ps={8947},r=0,rl=58,sn={16016},su=21983,tg=81,x=6600,z=2557}
T[8949]={d="Collect 25 Ogre Warbeads from Ogres inside Dire Maul or Blackrock Spire and return to Falrin Treeshaper inside the Athenaeum in Dire Maul.",en={16032},l=60,n="Falrin's Vendetta",nx=8950,ob={i={{21982}}},ps={8948},r=0,rl=58,sn={16032},tg=81,x=6600,z=2557}
T[8950]={d="Bring the following to Falrin Treeshaper inside Dire Maul: 1 Jeering Spectre's Essence, 4 Dark Runes and 8 Large Brilliant Shards.",en={16032},l=60,n="The Instigator's Enchantment",nx=9015,ob={i={{22224},{20520},{14344}}},ps={8949},r=0,rl=58,sn={16032},tg=81,x=6600,z=2557}
T[8951]={c=1024,d="Return to Deliana in Ironforge with a set of Wildheart Boots, a Wildheart Kilt and Wildheart Spaulders.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16715},{16719},{16718}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8952]={c=4,d="Return to Deliana in Ironforge with a set of Beaststalker's Boots, Beaststalker's Pants and Beaststalker's Mantle.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16675},{16678},{16679}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8953]={c=128,d="Return to Deliana in Ironforge with a set of Magister's Boots, Magister's Leggings and Magister's Mantle.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16682},{16687},{16689}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950,z=2017}
T[8954]={c=2,d="Return to Deliana in Ironforge with a set of Lightforge Boots, Lightforge Legplates and Lightforge Spaulders.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16725},{16728},{16729}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8955]={c=16,d="Return to Deliana in Ironforge with a set of Devout Sandals, Devout Skirt and Devout Mantle.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16691},{16694},{16695}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8956]={c=8,d="Return to Deliana in Ironforge with a set of Shadowcraft Boots, Shadowcraft Pants and Shadowcraft Spaulders.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16711},{16709},{16708}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8957]={c=64,d="Return to Mokvar in Orgimmar with a set of Boots of Elements, Kilt of Elements and Pauldrons of Elements.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16670},{16668},{16669}}},ps={9015},r=178,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8958]={c=256,d="Return to Deliana in Ironforge with a set of Dreadmist Sandals, Dreadmist Leggings and Dreadmist Mantle.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16704},{16699},{16701}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8959]={c=1,d="Return to Deliana in Ironforge with a set of Boots of Valor, Legplates of Valor and Spaulders of Valor.",en={16013},l=60,n="Anthion's Parting Words",nx=8960,ob={i={{16734},{16732},{16733}}},ps={9015},r=77,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[8960]={d="Travel to Blackrock Mountain and use the Extra-Dimensional Ghost Revealer to find Bodley near Blackrock Spire.",en={16033},l=60,n="Bodley's Unfortunate Fate",nx=8961,ps={8951,8952,8953,8954,8955,8956,8958,8959},r=77,rl=58,sn={16013},x=1650}
T[8961]={d="Gather the Incendicite of Incendius, the Ember of Emberseer and the Cinder of Cynders, along with a Hallowed Brazier, and return them to Bodley inside Blackrock Mountain.",en={16033},l=60,n="Three Kings of Flame",nx=8962,ob={i={{21987},{21988},{21989},{22014}}},ps={8960,9032},r=0,rl=58,sn={16033},tg=62,x=6600}
T[8962]={d="Acquire Druidical Remains and return them to Bodley inside Blackrock Mountain.",en={16033},ex={8963,8964,8965},l=60,n="Components of Importance",nx=8966,ob={i={{22226}}},ps={8961},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8963]={d="Acquire a Starbreeze Village Relic and return it to Bodley inside Blackrock Mountain.",en={16033},ex={8962,8964,8965},l=60,n="Components of Importance",nx=8966,ob={i={{22227}}},ps={8961},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8964]={d="Retrieve a Brilliant Sword of Zealotry and return it to Bodley inside Blackrock Mountain.",en={16033},ex={8962,8963,8965},l=60,n="Components of Importance",nx=8966,ob={i={{22228}}},ps={8961},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8965]={d="Obtain Soul Ashes of the Banished and return them to Bodley inside Blackrock Mountain.",en={16033},ex={8962,8963,8964},l=60,n="Components of Importance",nx=8966,ob={i={{22229}}},ps={8961},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8966]={d="Use the Brazier of Beckoning to summon forth the spirit of Mor Grayhoof and slay him. Return to Bodley inside Blackrock Mountain with the Left Piece of Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8967,8968,8969},l=60,n="The Left Piece of Lord Valthalak's Amulet",nx=8970,ob={i={{21984}},k={{16080}}},ps={8962,8963,8964,8965},r=0,rl=58,sn={16033},su=22049,tg=81,x=8300,z=1583}
T[8967]={d="Use the Brazier of Beckoning to summon forth the spirit of Isalien and slay her. Return to Bodley inside Blackrock Mountain with the Left Piece of Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8966,8968,8969},l=60,n="The Left Piece of Lord Valthalak's Amulet",nx=8970,ob={i={{21984}},k={{16097}}},ps={8962,8963,8964,8965},r=0,rl=58,sn={16033},su=22050,tg=81,x=8300,z=2557}
T[8968]={d="Use the Brazier of Beckoning to summon forth Jarien and Sothos and slay them. Return to Bodley inside Blackrock Mountain with the Left Piece of Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8966,8967,8969},l=60,n="The Left Piece of Lord Valthalak's Amulet",nx=8970,ob={i={{21984}},k={{16101},{16102}}},ps={8962,8963,8964,8965},r=0,rl=58,sn={16033},su=22051,tg=81,x=8300,z=2017}
T[8969]={d="Use the Brazier of Beckoning to summon forth the spirit of Kormok and slay him. Return to Bodley inside Blackrock Mountain with the Left Piece of Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8966,8967,8968},l=60,n="The Left Piece of Lord Valthalak's Amulet",nx=8970,ob={i={{21984}},k={{16118}}},ps={8962,8963,8964,8965},r=0,rl=58,sn={16033},su=22052,tg=81,x=8300,z=2057}
T[8970]={d="Gather 20 Bloodkelp from the Strashaz naga and then return to Bodley inside Blackrock Mountain.",en={16033},l=60,n="I See Alcaz Island In Your Future...",nx=8985,ob={i={{22094}}},ps={8966,8967,8968,8969},r=0,rl=58,sn={16033},su=21984,tg=1,x=6600}
T[8977]={d="Bring the Extra-Dimensional Ghost Revealer to Deliana in Ironforge.",en={16013},l=60,n="Return to Deliana",ps={8928},r=77,rl=58,sn={16014},su=22115,x=6600}
T[8978]={d="Return to Mokvar in Orgrimmar with the Extra-Dimensional Ghost Revealer.",en={16012},l=60,n="Return to Mokvar",ps={8928},r=178,rl=58,sn={16014},su=22115,x=6600}
T[8985]={d="Acquire a Starbreeze Village Relic and return it to Bodley inside Blackrock Mountain.",en={16033},ex={8986,8987,8988},l=60,n="More Components of Importance",nx=8989,ob={i={{22227}}},ps={8970},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8986]={d="Acquire Druidical Remains and return them to Bodley inside Blackrock Mountain.",en={16033},ex={8985,8987,8988},l=60,n="More Components of Importance",nx=8989,ob={i={{22226}}},ps={8970},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8987]={d="Retrieve a Brilliant Sword of Zealotry and return it to Bodley inside Blackrock Mountain.",en={16033},ex={8986,8988,8989},l=60,n="More Components of Importance",nx=8989,ob={i={{22228}}},ps={8970},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8988]={d="Obtain Soul Ashes of the Banished and return them to Bodley inside Blackrock Mountain.",en={16033},ex={8986,8987,8989},l=60,n="More Components of Importance",nx=8989,ob={i={{22229}}},ps={8970},r=0,rl=58,sn={16033},tg=1,x=6600}
T[8989]={d="Use the Brazier of Beckoning to summon forth the spirit of Mor Grayhoof and slay him. Return to Bodley inside Blackrock Mountain with the recombined Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8990,8991,8992},l=60,n="The Right Piece of Lord Valthalak's Amulet",nx=8994,ob={i={{22048}},k={{16080}}},ps={8985,8986,8987,8988},r=0,rl=58,rs={22046},sn={16033},su=22049,tg=81,x=8300,z=1583}
T[8990]={d="Use the Brazier of Beckoning to summon forth the spirit of Isalien and slay her. Return to Bodley inside Blackrock Mountain with the recombined Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8989,8991,8992},l=60,n="The Right Piece of Lord Valthalak's Amulet",nx=8994,ob={i={{22048}},k={{16097}}},ps={8985,8986,8987,8988},r=0,rl=58,rs={22046},sn={16033},su=22050,tg=81,x=8300,z=2557}
T[8991]={d="Use the Brazier of Beckoning to summon forth Jarien and Sothos and slay them. Return to Bodley inside Blackrock Mountain with the recombined Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8989,8990,8992},l=60,n="The Right Piece of Lord Valthalak's Amulet",nx=8994,ob={i={{22048}},k={{16101},{16102}}},ps={8985,8986,8987,8988},r=0,rl=58,rs={22046},sn={16033},su=22051,tg=81,x=8300,z=2017}
T[8992]={d="Use the Brazier of Beckoning to summon forth the spirit of Kormok and slay him. Return to Bodley inside Blackrock Mountain with the recombined Lord Valthalak's Amulet and the Brazier of Beckoning.",en={16033},ex={8989,8990,8991},l=60,n="The Right Piece of Lord Valthalak's Amulet",nx=8994,ob={i={{22048}},k={{16118}}},ps={8985,8986,8987,8988},r=0,rl=58,rs={22046},sn={16033},su=22052,tg=81,x=8300,z=2057}
T[8994]={d="Gather 40 Blackrock Bracers and acquire a Flask of Supreme Power. Return them to Bodley inside Blackrock Mountain.",en={16033},l=60,n="Final Preparations",nx=8995,ob={i={{22138},{13512}}},ps={8989,8990,8991,8992},r=0,rl=58,sn={16033},su=22048,tg=62,x=6600,z=1583}
T[8995]={d="Use the Brazier of Beckoning to summon Lord Valthalak. Dispatch him, and use Lord Valthalak's Amulet on the corpse. Then, return Lord Valthalak's Amulet to the Spirit of Lord Valthalak.",en={16073},l=60,n="Mea Culpa, Lord Valthalak",nx=8996,ob={i={{22048}},k={{16042}}},ps={8994},r=0,rl=58,sn={16033},su=22056,tg=62,x=9950,z=1583}
T[8996]={d="Return to Bodley inside Blackrock Mountain and give him the Brazier of Beckoning.",en={16033},l=60,n="Return to Bodley",ob={i={{22056}}},ps={8995},r=0,rl=58,sn={16073},x=660}
T[8997]={d="Speak with Deliana at The High Seat in Ironforge.",en={16013},l=60,n="Back to the Beginning",ps={8996},r=77,rl=58,sn={16033},x=660}
T[8998]={d="Speak with Mokvar at Grommash Hold in Orgrimmar's Valley of Wisdom.",en={16012},l=60,n="Back to the Beginning",ps={8996},r=178,rl=58,sn={16033},x=660}
T[8999]={c=1024,d="Give Deliana your Wildheart Cowl and Wildheart Vest.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16720},{16706}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9000]={c=4,d="Give Deliana your Beaststalker's Cap and Beaststalker's Tunic.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16677},{16674}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9001]={c=128,d="Give Deliana your Magister's Crown and Magister's Robes.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16686},{16688}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9002]={c=2,d="Give Deliana your Lightforge Helm and Lightforge Breastplate.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16727},{16726}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9003]={c=16,d="Give Deliana your Devout Crown and Devout Robe.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16693},{16690}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9004]={c=8,d="Give Deliana your Shadowcraft Cap and Shadowcraft Tunic.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16707},{16721}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9005]={c=256,d="Give Deliana your Dreadmist Mask and Dreadmist Robe.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16698},{16700}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9006]={c=1,d="Give Deliana your Helm of Valor and Breastplate of Valor.",en={16013},l=60,n="Saving the Best for Last",ob={i={{16731},{16730}}},ps={8997},r=77,rl=58,sn={16013},tg=81,x=1650}
T[9007]={c=1024,d="Give Mokvar your Wildheart Cowl and Wildheart Vest.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16720},{16706}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9008]={c=4,d="Give Mokvar your Beaststalker's Cap and Beaststalker's Tunic.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16677},{16674}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9009]={c=16,d="Give Mokvar your Devout Crown and Devout Robe.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16693},{16690}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9010]={c=8,d="Give Mokvar your Shadowcraft Cap and Shadowcraft Tunic.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16707},{16721}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9011]={c=64,d="Give Mokvar your Coif of Elements and Vest of Elements.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16667},{16666}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9012]={c=256,d="Give Mokvar your Dreadmist Mask and Dreadmist Robe.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16698},{16700}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9013]={c=1,d="Give Mokvar your Helm of Valor and Breastplate of Valor.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16731},{16730}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9014]={c=128,d="Give Mokvar your Magister's Crown and Magister's Robes.",en={16012},l=60,n="Saving the Best for Last",ob={i={{16686},{16688}}},ps={8998},r=178,rl=58,sn={16012},tg=81,x=1650}
T[9015]={d="Travel to the Ring of the Law in Blackrock Depths and place the Banner of Provocation in its center as you are sentenced by High Justice Grimstone. Slay Theldren and his gladiators and return to Anthion Harmon in the Eastern Plaguelands with the first piece of Lord Valthalak's amulet.",en={16016},l=60,n="The Challenge",ob={i={{22047}},k={{16059}}},ps={8950},r=0,rl=58,sn={16032},su=21986,tg=81,x=6600,z=1584}
T[9016]={c=1024,d="Return to Mokvar in Orgimmar with a set of Wildheart Boots, a Wildheart Kilt and Wildheart Spaulders.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16715},{16719},{16718}}},ps={9015},r=178,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[9017]={c=4,d="Return to Mokvar in Orgimmar with a set of Beaststalker's Boots, Beaststalker's Pants and Beaststalker's Mantle.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16675},{16678},{16679}}},ps={9015},r=178,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[9018]={c=128,d="Return to Mokvar in Orgimmar with a set of Magister's Boots, Magister's Leggings and Magister's Mantle.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16682},{16687},{16689}}},ps={9015},r=178,rl=58,sn={16016},su=21986,tg=81,x=9950,z=2017}
T[9019]={c=16,d="Return to Mokvar in Orgimmar with a set of Devout Sandals, Devout Skirt and Devout Mantle.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16691},{16694},{16695}}},ps={9015},r=178,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[9020]={c=8,d="Return to Mokvar in Orgimmar with a set of Shadowcraft Boots, Shadowcraft Pants and Shadowcraft Spaulders.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16711},{16709},{16708}}},ps={9015},r=178,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[9021]={c=256,d="Return to Mokvar in Orgimmar with a set of Dreadmist Sandals, Dreadmist Leggings and Dreadmist Mantle.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16704},{16699},{16701}}},ps={9015},r=178,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[9022]={c=1,d="Return to Mokvar in Orgimmar with a set of Boots of Valor, Legplates of Valor and Spaulders of Valor.",en={16012},l=60,n="Anthion's Parting Words",nx=9032,ob={i={{16734},{16732},{16733}}},ps={9015},r=178,rl=58,sn={16016},su=22047,tg=81,x=9950}
T[9023]={d="Dirk Thunderwood at Cenarion Hold wants you to bring him Venoxis's Venom Sac and Kurinnaxx's Venom Sac.",en={16091},l=60,n="The Perfect Poison",ob={i={{22216},{22217}}},r=0,rl=60,sn={16091},tg=62,x=6600}
T[9032]={d="Travel to Blackrock Mountain and use the Extra-Dimensional Ghost Revealer to find Bodley near Blackrock Spire.",en={16033},l=60,n="Bodley's Unfortunate Fate",nx=8961,ps={8957,9016,9017,9018,9019,9020,9021,9022},r=178,rl=58,sn={16012},x=1650}
T[9033]={d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands wants you to slay 5 Living Monstrosities, 5 Stoneskin Gargoyles, 8 Deathknight Captains and 3 Venom Stalkers.",en={16115},l=60,n="Echoes of War",nx=9229,ob={k={{16145},{15976},{16021},{16168}}},ps={9121,9122,9123},r=0,rl=60,sn={16115},tg=62,x=9950}
T[9034]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make a Dreadnaught Breastplate if you bring him the following items: 1 Desecrated Breastplate, 25 Wartorn Plate Scraps, 4 Arcanite Bars and 2 Nexus Crystals.",en={16112},l=60,n="Dreadnaught Breastplate",ob={i={{22349},{22375},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9036]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Legplates if you bring him the following items: 1 Desecrated Legplates, 20 Wartorn Plate Scraps, 4 Arcanite Bars and 3 Cured Rugged Hides.",en={16112},l=60,n="Dreadnaught Legplates",ob={i={{22352},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9037]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make a Dreadnaught Helmet if you bring him the following items: 1 Desecrated Helmet, 15 Wartorn Plate Scraps, 5 Arcanite Bars and 1 Nexus Crystal.",en={16112},l=60,n="Dreadnaught Helmet",ob={i={{22353},{22375},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9038]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Pauldrons if you bring him the following items: 1 Desecrated Pauldrons, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 3 Cured Rugged Hides.",en={16112},l=60,n="Dreadnaught Pauldrons",ob={i={{22354},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9039]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Sabatons if you bring him the following items: 1 Desecrated Sabatons, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 3 Cured Rugged Hides.",en={16112},l=60,n="Dreadnaught Sabatons",ob={i={{22358},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9040]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Gauntlets if you bring him the following items: 1 Desecrated Gauntlets, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.",en={16112},l=60,n="Dreadnaught Gauntlets",ob={i={{22357},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9041]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make a Dreadnaught Waistguard if you bring him the following items: 1 Desecrated Waistguard, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.",en={16112},l=60,n="Dreadnaught Waistguard",ob={i={{22356},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9042]={c=1,d="Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Bracers if you bring him the following items: 1 Desecrated Bracers, 6 Wartorn Plate Scraps, 1 Arcanite Bar and 1 Nexus Crystal.",en={16112},l=60,n="Dreadnaught Bracers",ob={i={{22355},{22375},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16112},tg=62}
T[9043]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a Redemption Tunic if you bring him the following: 1 Desecrated Tunic, 25 Wartorn Plate Scraps, 4 Arcanite Bars and 3 Cured Rugged Hides.",en={16115},l=60,n="Redemption Tunic",ob={i={{22350},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9044]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a pair of Redemption Legguards if you bring him the following: 1 Desecrated Legguards, 20 Wartorn Plate Scraps, 4 Arcanite Bars and 2 Nexus Crystals.",en={16115},l=60,n="Redemption Legguards",ob={i={{22359},{22375},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9045]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a Redemption Headpiece if you bring him the following: 1 Desecrated Headpiece, 15 Wartorn Plate Scraps, 5 Arcanite Bars and 2 Cured Rugged Hides.",en={16115},l=60,n="Redemption Headpiece",ob={i={{22360},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9046]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a pair of Redemption Spaulders if you bring him the following: 1 Desecrated Spaulders, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 2 Nexus Crystals.",en={16115},l=60,n="Redemption Spaulders",ob={i={{22361},{22375},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9047]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make Redemption Boots if you bring him the following: 1 Desecrated Boots, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 3 Cured Rugged Hides.",en={16115},l=60,n="Redemption Boots",ob={i={{22365},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9048]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make Redemption Handguards if you bring him the following: 1 Desecrated Handguards, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.",en={16115},l=60,n="Redemption Handguards",ob={i={{22364},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9049]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a Redemption Girdle if you bring him the following: 1 Desecrated Girdle, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 3 Nexus Crystals.",en={16115},l=60,n="Redemption Girdle",ob={i={{22363},{22375},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9050]={c=2,d="Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make Redemption Wristguards if you bring him the following: 1 Desecrated Wristguards, 6 Wartorn Plate Scraps, 1 Arcanite Bar and 2 Cured Rugged Hides.",en={16115},l=60,n="Redemption Wristguards",ob={i={{22362},{22375},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16115},tg=62}
T[9051]={c=1024,d="Stab a Devilsaur with the Devilsaur Barb. Return to Torwa Pathfinder in Un'Goro Crater when you have completed this task.",en={9619},l=52,n="Toxic Test",nx=9053,ob={c={{{6498,6499,6500}}}},ps={9052},r=0,rl=50,sf=2,sn={9619},su=22432,tg=1,x=5100}
T[9052]={c=1024,d="Collect 8 Bloodcap and 8 Gorishi Stings, and return to Torwa Pathfinder in Un'Goro Crater.",en={9619},l=52,n="Bloodpetal Poison",nx=9051,ob={i={{22435},{22434}}},r=0,rl=50,sn={9619},x=5100}
T[9053]={c=1024,d="Retrieve a Putrid Vine from the guardian at the bottom of the Sunken Temple and return to Torwa Pathfinder.",en={9619},l=52,n="A Better Ingredient",ob={i={{22444}}},ps={9051},r=0,rl=50,sn={9619},tg=81,x=6350,z=1477}
T[9054]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make a Cryptstalker Tunic if you bring him the following: 1 Desecrated Tunic, 25 Wartorn Chain Scraps, 4 Arcanite Bars and 3 Cured Rugged Hides.",en={16132},l=60,n="Cryptstalker Tunic",ob={i={{22350},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9055]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make Cryptstalker Legguards if you bring him the following: 1 Desecrated Legguards, 20 Wartorn Chain Scraps, 3 Arcanite Bars and 5 Cured Rugged Hides.",en={16132},l=60,n="Cryptstalker Legguards",ob={i={{22359},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9056]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make a Cryptstalker Headpiece if you bring him the following: 1 Desecrated Headpiece, 15 Wartorn Chain Scraps, 4 Arcanite Bars and 2 Nexus Crystals.",en={16132},l=60,n="Cryptstalker Headpiece",ob={i={{22360},{22374},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9057]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make Cryptstalker Spaulders if you bring him the following: 1 Desecrated Spaulders, 12 Wartorn Chain Scraps, 2 Arcanite Bars and 3 Cured Rugged Hides.",en={16132},l=60,n="Cryptstalker Spaulders",ob={i={{22361},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9058]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make Cryptstalker Boots if you bring him the following: 1 Desecrated Boots, 12 Wartorn Chain Scraps, 1 Arcanite Bar and 3 Nexus Crystals.",en={16132},l=60,n="Cryptstalker Boots",ob={i={{22365},{22374},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9059]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make Cryptstalker Handguards if you bring him the following: 1 Desecrated Handguards, 8 Wartorn Chain Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.",en={16132},l=60,n="Cryptstalker Handguards",ob={i={{22364},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9060]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make a Cryptstalker Girdle if you bring him the following: 1 Desecrated Girdle, 8 Wartorn Chain Scraps, 1 Arcanite Bar and 3 Nexus Crystals.",en={16132},l=60,n="Cryptstalker Girdle",ob={i={{22363},{22374},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9061]={c=4,d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands will make Cryptstalker Wristguards if you bring him the following: 1 Desecrated Wristguards, 6 Wartorn Chain Scraps, 1 Arcanite Bar and 2 Cured Rugged Hides.",en={16132},l=60,n="Cryptstalker Wristguards",ob={i={{22362},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16132},tg=62}
T[9063]={c=1024,d="Speak with Torwa Pathfinder in Un'Goro Crater.",en={9619},l=52,n="Torwa Pathfinder",nx=9052,r=0,rl=50,sn={3033,4217,5505,12042},x=510}
T[9068]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make an Earthshatter Tunic if you bring him the following: 1 Desecrated Tunic, 25 Wartorn Chain Scraps, 4 Arcanite Bars and 3 Cured Rugged Hides.",en={16134},l=60,n="Earthshatter Tunic",ob={i={{22350},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9069]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make Earthshatter Legguards if you bring him the following: 1 Desecrated Legguards, 20 Wartorn Chain Scraps, 3 Arcanite Bars and 5 Cured Rugged Hides.",en={16134},l=60,n="Earthshatter Legguards",ob={i={{22359},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9070]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make an Earthshatter Headpiece if you bring him the following: 1 Desecrated Headpiece, 15 Wartorn Chain Scraps, 4 Arcanite Bars and 2 Nexus Crystals.",en={16134},l=60,n="Earthshatter Headpiece",ob={i={{22360},{22374},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9071]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make Earthshatter Spaulders if you bring him the following: 1 Desecrated Spaulders, 12 Wartorn Chain Scraps, 2 Arcanite Bars and 2 Mooncloth.",en={16134},l=60,n="Earthshatter Spaulders",ob={i={{22361},{22374},{12360},{14342}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9072]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make Earthshatter Boots if you bring him the following: 1 Desecrated Boots, 12 Wartorn Chain Scraps, 1 Arcanite Bar and 3 Nexus Crystals.",en={16134},l=60,n="Earthshatter Boots",ob={i={{22365},{22374},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9073]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make Earthshatter Handguards if you bring him the following: 1 Desecrated Handguards, 8 Wartorn Chain Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.",en={16134},l=60,n="Earthshatter Handguards",ob={i={{22364},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9074]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make an Earthshatter Girdle if you bring him the following: 1 Desecrated Girdle, 8 Wartorn Chain Scraps, 1 Arcanite Bar and 3 Nexus Crystals.",en={16134},l=60,n="Earthshatter Girdle",ob={i={{22363},{22374},{12360},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9075]={c=64,d="Rimblat Earthshatter at Light's Hope Chapel in the Eastern Plaguelands will make Earthshatter Wristguards if you bring him the following: 1 Desecrated Wristguards, 6 Wartorn Chain Scraps, 1 Arcanite Bar and 2 Cured Rugged Hides.",en={16134},l=60,n="Earthshatter Wristguards",ob={i={{22362},{22374},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16134},tg=62}
T[9077]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make a Bonescythe Breastplate if you bring him the following: 1 Desecrated Breastplate, 25 Wartorn Leather Scraps, 2 Arcanite Bars and 6 Cured Rugged Hides.",en={16131},l=60,n="Bonescythe Breastplate",ob={i={{22349},{22373},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9078]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make Bonescythe Legplates if you bring him the following: 1 Desecrated Legplates, 20 Wartorn Leather Scraps, 1 Arcanite Bar, 8 Cured Rugged Hides and 100 gold pieces.",en={16131},l=60,n="Bonescythe Legplates",ob={i={{22352},{22373},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9079]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make a Bonescythe Helmet if you bring him the following: 1 Desecrated Helmet, 15 Wartorn Leather Scraps, 8 Cured Rugged Hides, 1 Nexus Crystal and 75 gold pieces.",en={16131},l=60,n="Bonescythe Helmet",ob={i={{22353},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9080]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make Bonescythe Pauldrons if you bring him the following: 1 Desecrated Pauldrons, 12 Wartorn Leather Scraps, 5 Cured Rugged Hides, 1 Nexus Crystal and 50 gold pieces.",en={16131},l=60,n="Bonescythe Pauldrons",ob={i={{22354},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9081]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make Bonescythe Sabatons if you bring him the following: 1 Desecrated Sabatons, 12 Wartorn Leather Scraps, 3 Cured Rugged Hides, 2 Nexus Crystals and 25 gold pieces.",en={16131},l=60,n="Bonescythe Sabatons",ob={i={{22358},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9082]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make Bonescythe Gauntlets if you bring him the following: 1 Desecrated Gauntlets, 8 Wartorn Leather Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.",en={16131},l=60,n="Bonescythe Gauntlets",ob={i={{22357},{22373},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9083]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make a Bonescythe Waistguard if you bring him the following: 1 Desecrated Waistguard, 8 Wartorn Leather Scraps, 5 Cured Rugged Hides, 1 Nexus Crystal and 15 gold pieces.",en={16131},l=60,n="Bonescythe Waistguard",ob={i={{22356},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9084]={c=8,d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands will make Bonescythe Bracers if you bring him the following: 1 Desecrated Bracers, 6 Wartorn Leather Scraps, 1 Arcanite Bar, 2 Cured Rugged Hides and 10 gold pieces.",en={16131},l=60,n="Bonescythe Bracers",ob={i={{22355},{22373},{12360},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16131},tg=62}
T[9085]={d="Go to a summoning circle and kill a Shadow of Doom, then return to Commander Thomas Helleran at Light's Hope Chapel in Eastern Plaguelands.",en={16361},l=60,n="Shadows of Doom",ob={k={{16143}}},r=0,rl=50,sn={16361}}
T[9086]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make a Dreamwalker Tunic if you bring her the following: 1 Desecrated Tunic, 25 Wartorn Leather Scraps, 6 Cured Rugged Hides and 2 Nexus Crystals.",en={16135},l=60,n="Dreamwalker Tunic",ob={i={{22350},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9087]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make Dreamwalker Legguards if you bring her the following: 1 Desecrated Legguards, 20 Wartorn Leather Scraps, 8 Cured Rugged Hides and 1 Nexus Crystal.",en={16135},l=60,n="Dreamwalker Legguards",ob={i={{22359},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9088]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make a Dreamwalker Headpiece if you bring her the following: 1 Desecrated Headpiece, 15 Wartorn Leather Scraps, 6 Cured Rugged Hides and 2 Nexus Crystals.",en={16135},l=60,n="Dreamwalker Headpiece",ob={i={{22360},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9089]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make Dreamwalker Spaulders if you bring her the following: 1 Desecrated Spaulders, 12 Wartorn Leather Scraps, 5 Cured Rugged Hides and 1 Nexus Crystal.",en={16135},l=60,n="Dreamwalker Spaulders",ob={i={{22361},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9090]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make Dreamwalker Boots if you bring her the following: 1 Desecrated Boots, 12 Wartorn Leather Scraps, 3 Mooncloth and 2 Cured Rugged Hides.",en={16135},l=60,n="Dreamwalker Boots",ob={i={{22365},{22373},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9091]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make Dreamwalker Handguards if you bring her the following: 1 Desecrated Handguards, 8 Wartorn Leather Scraps, 5 Cured Rugged Hides and 1 Nexus Crystal.",en={16135},l=60,n="Dreamwalker Handguards",ob={i={{22364},{22373},{15407},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9092]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make a Dreamwalker Girdle if you bring her the following: 1 Desecrated Girdle, 8 Wartorn Leather Scraps, 3 Mooncloth and 2 Cured Rugged Hides.",en={16135},l=60,n="Dreamwalker Girdle",ob={i={{22363},{22373},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9093]={c=1024,d="Rayne at Light's Hope Chapel in the Eastern Plaguelands will make Dreamwalker Wristguards if you bring her the following: 1 Desecrated Wristguards, 6 Wartorn Leather Scraps, 1 Arcane Crystal and 2 Cured Rugged Hides.",en={16135},l=60,n="Dreamwalker Wristguards",ob={i={{22362},{22373},{12363},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16135},tg=62}
T[9094]={en={16786},l=60,n="Argent Dawn Gloves",ob={i={{22484}}},ps={9153},r=77,rl=50,sf=1,sn={16786}}
T[9095]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make a Frostfire Robe if you bring her the following: 1 Desecrated Robe, 25 Wartorn Cloth Scraps, 4 Mooncloth and 2 Nexus Crystals.",en={16116},l=60,n="Frostfire Robe",ob={i={{22351},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9096]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make Frostfire Leggings if you bring her the following: 1 Desecrated Leggings, 20 Wartorn Cloth Scraps, 4 Mooncloth and 2 Nexus Crystals.",en={16116},l=60,n="Frostfire Leggings",ob={i={{22366},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9097]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make a Frostfire Circlet if you bring her the following: 1 Desecrated Circlet, 15 Wartorn Cloth Scraps, 3 Mooncloth and 3 Nexus Crystals.",en={16116},l=60,n="Frostfire Circlet",ob={i={{22367},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9098]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make Frostfire Shoulderpads if you bring her the following: 1 Desecrated Shoulderpads, 12 Wartorn Cloth Scraps, 2 Mooncloth and 3 Cured Rugged Hides.",en={16116},l=60,n="Frostfire Shoulderpads",ob={i={{22368},{22376},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9099]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make Frostfire Sandals if you bring her the following: 1 Desecrated Sandals, 12 Wartorn Cloth Scraps, 2 Mooncloth and 3 Cured Rugged Hides.",en={16116},l=60,n="Frostfire Sandals",ob={i={{22372},{22376},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9100]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make Frostfire Gloves if you bring her the following: 1 Desecrated Gloves, 8 Wartorn Cloth Scraps and 4 Mooncloth.",en={16116},l=60,n="Frostfire Gloves",ob={i={{22371},{22376},{14342}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9101]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make a Frostfire Belt if you bring her the following: 1 Desecrated Belt, 8 Wartorn Cloth Scraps, 2 Arcane Crystals and 2 Mooncloth.",en={16116},l=60,n="Frostfire Belt",ob={i={{22370},{22376},{12363},{14342}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9102]={c=128,d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will make Frostfire Bindings if you bring her the following: 1 Desecrated Bindings, 6 Wartorn Cloth Scraps, 1 Arcane Crystal and 1 Nexus Crystal.",en={16116},l=60,n="Frostfire Bindings",ob={i={{22369},{22376},{12363},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16116},tg=62}
T[9103]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make a Plagueheart Robe if you bring him the following: 1 Desecrated Robe, 25 Wartorn Cloth Scraps, 4 Mooncloth and 2 Nexus Crystals.",en={16133},l=60,n="Plagueheart Robe",ob={i={{22351},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9104]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make Plagueheart Leggings if you bring him the following: 1 Desecrated Leggings, 20 Wartorn Cloth Scraps, 4 Mooncloth and 2 Nexus Crystals.",en={16133},l=60,n="Plagueheart Leggings",ob={i={{22366},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9105]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make a Plagueheart Circlet if you bring him the following: 1 Desecrated Circlet, 15 Wartorn Cloth Scraps, 3 Mooncloth and 3 Nexus Crystals.",en={16133},l=60,n="Plagueheart Circlet",ob={i={{22367},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9106]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make Plagueheart Shoulderpads if you bring him the following: 1 Desecrated Shoulderpads, 12 Wartorn Cloth Scraps, 2 Mooncloth and 3 Cured Rugged Hides.",en={16133},l=60,n="Plagueheart Shoulderpads",ob={i={{22368},{22376},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9107]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make Plagueheart Sandals if you bring him the following: 1 Desecrated Sandals, 12 Wartorn Cloth Scraps, 2 Mooncloth and 3 Cured Rugged Hides.",en={16133},l=60,n="Plagueheart Sandals",ob={i={{22372},{22376},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9108]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make Plagueheart Gloves if you bring him the following: 1 Desecrated Gloves, 8 Wartorn Cloth Scraps and 4 Mooncloth.",en={16133},l=60,n="Plagueheart Gloves",ob={i={{22371},{22376},{14342}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9109]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make a Plagueheart Belt if you bring him the following: 1 Desecrated Belt, 8 Wartorn Cloth Scraps, 2 Arcane Crystals and 2 Mooncloth.",en={16133},l=60,n="Plagueheart Belt",ob={i={{22370},{22376},{12363},{14342}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9110]={c=256,d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands will make Plagueheart Bindings if you bring him the following: 1 Desecrated Bindings, 6 Wartorn Cloth Scraps, 1 Arcane Crystal and 1 Nexus Crystal.",en={16133},l=60,n="Plagueheart Bindings",ob={i={{22369},{22376},{12363},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16133},tg=62}
T[9111]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make a Robe of Faith if you bring him the following: 1 Desecrated Robe, 25 Wartorn Cloth Scraps, 4 Mooncloth and 2 Nexus Crystals.",en={16113},l=60,n="Robe of Faith",ob={i={{22351},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9112]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make Leggings of Faith if you bring him the following: 1 Desecrated Leggings, 20 Wartorn Cloth Scraps, 4 Mooncloth and 2 Nexus Crystals.",en={16113},l=60,n="Leggings of Faith",ob={i={{22366},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9113]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make a Circlet of Faith if you bring him the following: 1 Desecrated Circlet, 15 Wartorn Cloth Scraps, 3 Mooncloth and 3 Nexus Crystals.",en={16113},l=60,n="Circlet of Faith",ob={i={{22367},{22376},{14342},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9114]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make Shoulderpads of Faith if you bring him the following: 1 Desecrated Shoulderpads, 12 Wartorn Cloth Scraps, 2 Mooncloth and 3 Cured Rugged Hides.",en={16113},l=60,n="Shoulderpads of Faith",ob={i={{22368},{22376},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9115]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make Sandals of Faith if you bring him the following: 1 Desecrated Sandals, 12 Wartorn Cloth Scraps, 2 Mooncloth and 3 Cured Rugged Hides.",en={16113},l=60,n="Sandals of Faith",ob={i={{22372},{22376},{14342},{15407}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9116]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make Gloves of Faith if you bring him the following: 1 Desecrated Gloves, 8 Wartorn Cloth Scraps and 4 Mooncloth.",en={16113},l=60,n="Gloves of Faith",ob={i={{22371},{22376},{14342}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9117]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make a Belt of Faith if you bring him the following: 1 Desecrated Belt, 8 Wartorn Cloth Scraps, 2 Arcane Crystals and 2 Mooncloth.",en={16113},l=60,n="Belt of Faith",ob={i={{22370},{22376},{12363},{14342}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9118]={c=16,d="Father Inigo Montoy at Light's Hope Chapel in the Eastern Plaguelands will make Bindings of Faith if you bring him the following: 1 Desecrated Bindings, 6 Wartorn Cloth Scraps, 1 Arcane Crystal and 1 Nexus Crystal.",en={16113},l=60,n="Bindings of Faith",ob={i={{22369},{22376},{12363},{20725}}},ps={9033},r=0,rl=60,rp={529,9000},sf=1,sn={16113},tg=62}
T[9120]={d="Take the Phylactery of Kel'Thuzad to Light's Hope Chapel in the Eastern Plaguelands.",en={16113},l=60,n="The Fall of Kel'Thuzad",ps={9121,9122,9123},r=0,rl=60,si={22520},su=22520,x=9950}
T[9121]={d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands wants 5 Arcane Crystals, 2 Nexus Crystals, 1 Righteous Orb and 60 gold pieces. You must also be Honored with the Argent Dawn.",en={16116},ex={9122,9123},l=60,n="The Dread Citadel - Naxxramas",nx=9033,ob={i={{12363},{20725},{12811}}},r=0,rl=60,rp={529,0},sn={16116}}
T[9122]={d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands wants 2 Arcane Crystals, 1 Nexus Crystal and 30 gold pieces. You must also be Revered with the Argent Dawn.",en={16116},ex={9121,9123},l=60,n="The Dread Citadel - Naxxramas",nx=9033,ob={i={{12363},{20725}}},r=0,rl=60,rp={529,21000},sn={16116}}
T[9123]={d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands will grant you Arcane Cloaking at no cost. You must be Exalted with the Argent Dawn.",en={16116},ex={9121,9122},l=60,n="The Dread Citadel - Naxxramas",nx=9033,r=0,rl=60,rp={529,42000},sn={16116}}
T[9124]={d="Huntsman Leopold at Light's Hope Chapel in the Eastern Plaguelands wants 30 Crypt Fiend Parts.",en={16132},l=60,n="Cryptstalker Armor Doesn't Make Itself...",nx=9125,ob={i={{22525}}},r=0,rl=55,rp={529,3000},sn={16132},x=6600}
T[9125]={en={16132},l=60,n="Crypt Fiend Parts",ob={i={{22525}}},ps={9124},r=0,rl=55,rp={529,3000},sf=1,sn={16132}}
T[9126]={d="Rohan the Assassin at Light's Hope Chapel in the Eastern Plaguelands wants 30 Bone Fragments.",en={16131},l=60,n="Bonescythe Digs",nx=9127,ob={i={{22526}}},r=0,rl=55,rp={529,3000},sn={16131},x=6600}
T[9127]={en={16131},l=60,n="Bone Fragments",ob={i={{22526}}},ps={9126},r=0,rl=55,rp={529,3000},sf=1,sn={16131}}
T[9128]={d="Archmage Angela Dosantos at Light's Hope Chapel in the Eastern Plaguelands wants 30 Core of Elements.",en={16116},l=60,n="The Elemental Equation",nx=9129,ob={i={{22527}}},r=0,rl=55,rp={529,3000},sn={16116},x=6600}
T[9129]={en={16116},l=60,n="Core of Elements",ob={i={{22527}}},ps={9128},r=0,rl=55,rp={529,3000},sf=1,sn={16116}}
T[9131]={d="Korfax at Light's Hope Chapel in the Eastern Plaguelands wants 30 Dark Iron Scraps.",en={16112},l=60,n="Binding the Dreadnaught",nx=9132,ob={i={{22528}}},r=0,rl=55,rp={529,3000},sn={16112},x=6600}
T[9132]={en={16112},l=60,n="Dark Iron Scraps",ob={i={{22528}}},ps={9131},r=0,rl=55,rp={529,3000},sf=1,sn={16112}}
T[9136]={d="Rayne at Light's Hope Chapel in the Eastern Plaguelands wants 30 Savage Fronds.",en={16135},l=60,n="Savage Flora",nx=9137,ob={i={{22529}}},r=0,rl=55,rp={529,3000},sn={16135},x=6600}
T[9137]={en={16135},l=60,n="Savage Fronds",ob={i={{22529}}},ps={9136},r=0,rl=55,rp={529,3000},sf=1,sn={16135}}
T[9141]={d="Dispatch Commander Metz at Light's Hope Chapel in the Eastern Plaguelands wants an Argent Dawn Valor Token.",en={16212},l=60,n="They Call Me \"The Rooster\"",nx=9142,ob={i={{12844}}},r=0,rl=55,rp={529,3000},sn={16212},x=3300}
T[9142]={en={16212},l=60,n="Craftsman's Writ",ob={i={{12844}}},ps={9141},r=0,rl=55,rp={529,3000},sf=1,sn={16212}}
T[9153]={d="Check your map to find an area under Scourge attack. Go there and damage a necropolis by defeating the Scourge around them. Return 10 of their Necrotic Runes to Commander Thomas Helleran at Light's Hope Chapel in the Eastern Plaguelands.",en={16361},l=60,n="Under the Shadow",ob={i={{22484}}},r=0,rl=50,sn={16361}}
T[9154]={d="Deliver the Call to Arms Announcement to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.",en={16281},l=60,n="Light's Hope Chapel",r=0,rl=50,sn={16241,16255},su=22595}
T[9165]={d="Deliver the signed Writ of Safe Passage to Dispatch Commander Metz at Light's Hope Chapel in the Eastern Plaguelands.",en={16212},l=60,n="Writ of Safe Passage",ob={k={{16254,"Writ of Safe Passage Signed"}}},r=0,rl=55,sf=1,sn={16226},su=22593}
T[9178]={d="Deliver 120 Dense Weightstones and the Craftsman's Writ - Dense Weightstone - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Dense Weightstone",ob={i={{12643}}},r=0,rl=55,sf=1,si={22600},su=22600}
T[9179]={d="Deliver 3 Imperial Plate Chests and the Craftsman's Writ - Imperial Plate Chest - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Imperial Plate Chest",ob={i={{12422}}},r=0,rl=55,sf=1,si={22601},su=22601}
T[9181]={d="Deliver 3 Volcanic Hammers and the Craftsman's Writ - Volcanic Hammer - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Volcanic Hammer",ob={i={{12792}}},r=0,rl=55,sf=1,si={22602},su=22602}
T[9182]={d="Deliver 3 Huge Thorium Battleaxes and the Craftsman's Writ - Huge Thorium Battleaxe - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Huge Thorium Battleaxe",ob={i={{12775}}},r=0,rl=55,sf=1,si={22603},su=22603}
T[9183]={d="Deliver 3 Radiant Circlets and the Craftsman's Writ - Radiant Circlet - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Radiant Circlet",ob={i={{12417}}},r=0,rl=55,sf=1,si={22604},su=22604}
T[9184]={d="Deliver 10 Wicked Leather Headbands and the Craftsman's Writ - Wicked Leather Headband - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Wicked Leather Headband",ob={i={{15086}}},r=0,rl=55,sf=1,si={22605},su=22605}
T[9185]={d="Deliver 25 Rugged Armor Kits and the Craftsman's Writ - Rugged Armor Kit - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Rugged Armor Kit",ob={i={{15564}}},r=0,rl=55,sf=1,si={22606},su=22606}
T[9186]={d="Deliver 9 Wicked Leather Belts and the Craftsman's Writ - Wicked Leather Belt - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Wicked Leather Belt",ob={i={{15088}}},r=0,rl=55,sf=1,si={22607},su=22607}
T[9187]={d="Deliver 4 Runic Leather Pants and the Craftsman's Writ - Runic Leather Pants - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Runic Leather Pants",ob={i={{15095}}},r=0,rl=55,sf=1,si={22608},su=22608}
T[9188]={d="Deliver 6 Brightcloth Pants and the Craftsman's Writ - Brightcloth Pants - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Brightcloth Pants",ob={i={{14104}}},r=0,rl=55,sf=1,si={22609},su=22609}
T[9190]={d="Deliver 8 Runecloth Boots and the Craftsman's Writ - Runecloth Boots - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Runecloth Boots",ob={i={{13864}}},r=0,rl=55,sf=1,si={22610},su=22610}
T[9191]={d="Deliver 8 Runecloth Bags and the Craftsman's Writ - Runecloth Bag - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Runecloth Bag",ob={i={{14046}}},r=0,rl=55,sf=1,si={22611},su=22611}
T[9194]={d="Deliver 8 Runecloth Robes and the Craftsman's Writ - Runecloth Robe - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Runecloth Robe",ob={i={{13858}}},r=0,rl=55,sf=1,si={22612},su=22612}
T[9195]={d="Deliver 20 Goblin Sapper Charges and the Craftsman's Writ - Goblin Sapper Charge - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Goblin Sapper Charge",ob={i={{10646}}},r=0,rl=55,sf=1,si={22613},su=22613}
T[9196]={d="Deliver 20 Thorium Grenades and the Craftsman's Writ - Thorium Grenade - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Thorium Grenade",ob={i={{15993}}},r=0,rl=55,sf=1,si={22614},su=22614}
T[9197]={d="Deliver 4 Gnomish Battle Chickens and the Craftsman's Writ - Gnomish Battle Chicken - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Gnomish Battle Chicken",ob={i={{10725}}},r=0,rl=55,sf=1,si={22615},su=22615}
T[9198]={d="Deliver 14 Thorium Tubes and the Craftsman's Writ - Thorium Tube - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Thorium Tube",ob={i={{16000}}},r=0,rl=55,sf=1,si={22616},su=22616}
T[9200]={d="Deliver 10 Major Mana Potions and the Craftsman's Writ - Major Mana Potion - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Major Mana Potion",ob={i={{13444}}},r=0,rl=55,sf=1,si={22617},su=22617}
T[9201]={d="Deliver 15 Greater Arcane Protection Potions and the Craftsman's Writ - Greater Arcane Protection Potion - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Greater Arcane Protection Potion",ob={i={{13461}}},r=0,rl=55,sf=1,si={22620},su=22620}
T[9202]={d="Deliver 20 Major Healing Potions and the Craftsman's Writ - Major Healing Potion - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Major Healing Potion",ob={i={{13446}}},r=0,rl=55,sf=1,si={22618},su=22618}
T[9203]={d="Deliver 1 Flask of Petrification and the Craftsman's Writ - Flask of Petrification - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Flask of Petrification",ob={i={{13506}}},r=0,rl=55,sf=1,si={22621},su=22621}
T[9204]={d="Deliver 40 Stonescale Eel and the Craftsman's Writ - Stonescale Eel - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Stonescale Eel",ob={i={{13422}}},r=0,rl=55,sf=1,si={22622},su=22622}
T[9205]={d="Deliver 30 Plated Armorfish and the Craftsman's Writ - Plated Armorfish - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Plated Armorfish",ob={i={{13890}}},r=0,rl=55,sf=1,si={22623},su=22623}
T[9206]={d="Deliver 30 Lightning Eel and the Craftsman's Writ - Lightning Eel - to Packmaster Stonebruiser at Light's Hope Chapel in the Eastern Plaguelands.",en={16283},l=60,n="Craftsman's Writ - Lightning Eel",ob={i={{13757}}},r=0,rl=55,sf=1,si={22624},su=22624}
T[9208]={d="Zanza the Restless in Zul'Gurub wants an Arcanum of Protection.",en={15042},l=60,n="The Savage Guard - Arcanum of Protection",ob={i={{18331}}},r=0,rl=60,rp={270,9000},sf=1,sn={15042},tg=62}
T[9209]={d="Zanza the Restless in Zul'Gurub wants an Arcanum of Rapidity.",en={15042},l=60,n="The Savage Guard - Arcanum of Rapidity",ob={i={{18329}}},r=0,rl=60,rp={270,9000},sf=1,sn={15042},tg=62}
T[9210]={d="Zanza the Restless in Zul'Gurub wants an Arcanum of Focus.",en={15042},l=60,n="The Savage Guard - Arcanum of Focus",ob={i={{18330}}},r=0,rl=60,rp={270,9000},sf=1,sn={15042},tg=62}
T[9211]={d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands wants 10 Insignia of the Crusade and 30 gold.",en={16133},l=60,n="The Ice Guard",ob={i={{22524}}},r=0,rl=60,rp={529,9000},sf=1,sn={16133}}
T[9213]={d="Mataus the Wrathcaster at Light's Hope Chapel in the Eastern Plaguelands wants 10 Insignia of the Crusade and 30 gold.",en={16133},l=60,n="The Shadow Guard",ob={i={{22524}}},r=0,rl=60,rp={529,9000},sf=1,sn={16133}}
T[9221]={d="For 30 Insignias of the Dawn and 30 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Superior Armaments of Battle - Friend of the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,3000},sf=1,sn={11536}}
T[9222]={d="For 110 Insignias of the Dawn and 110 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Epic Armaments of Battle - Friend of the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,3000},sf=1,sn={11536}}
T[9223]={d="For 20 Insignias of the Dawn and 20 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Superior Armaments of Battle - Honored Amongst the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,9000},sf=1,sn={11536}}
T[9224]={d="For 75 Insignias of the Dawn and 75 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Epic Armaments of Battle - Honored Amongst the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,9000},sf=1,sn={11536}}
T[9225]={d="For 45 Insignias of the Dawn and 45 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Epic Armaments of Battle - Revered Amongst the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,21000},sf=1,sn={11536}}
T[9226]={d="For 7 Insignias of the Dawn and 7 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Superior Armaments of Battle - Revered Amongst the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,21000},sf=1,sn={11536}}
T[9227]={d="For 6 Insignias of the Dawn and 6 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Superior Armaments of Battle - Exalted Amongst the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,42000},sf=1,sn={11536}}
T[9228]={d="For 27 Insignias of the Dawn and 27 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.",en={11536},l=60,n="Epic Armaments of Battle - Exalted Amongst the Dawn",ob={i={{22523},{22524}}},r=0,rl=55,rp={529,42000},sf=1,sn={11536}}
T[9229]={d="Enter Naxxramas and uncover the Fate of Ramaladni.",en={16112},l=60,n="The Fate of Ramaladni",nx=9230,ob={i={{22708}}},ps={9033},r=0,rl=60,sn={16112},tg=62}
T[9230]={d="Korfax at Light's Hope Chapel in the Eastern Plaguelands wants you to bring him 1 Frozen Rune, 1 Blue Sapphire and 1 Arcanite Bar.",en={16112},l=60,n="Ramaladni's Icy Grasp",ob={i={{22682},{12361},{12360}}},ps={9229},r=0,rl=60,sn={16112},tg=62}
T[9232]={d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants you to bring him 2 Frozen Runes, 2 Essence of Water, 2 Blue Sapphires and 30 gold pieces.",en={16376},l=60,n="The Only Song I Know...",ob={i={{22682},{7080},{12361}}},ps={9033},r=0,rl=60,sn={16376},tg=62}
T[9233]={d="Take Omarion's Handbook to Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands.",en={16376},l=60,n="Omarion's Handbook",ps={9121,9122,9123},r=0,rl=60,rp={529,21000},si={22719},su=22719,tg=62}
T[9234]={c=3,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 12 Thorium Bars, 2 Arcanite Bars, 2 Essences of Water and 200 gold.",en={16376},l=60,n="Icebane Gauntlets",ob={i={{22682},{12359},{12360},{7080}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9235]={c=3,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 12 Thorium Bars, 2 Arcanite Bars, 2 Essence of Water and 200 gold.",en={16376},l=60,n="Icebane Bracers",ob={i={{22682},{12359},{12360},{7080}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9236]={c=3,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 16 Thorium Bars, 2 Arcanite Bars, 4 Essence of Water and 300 gold. You will also need to be of Exalted reputation with the Argent Dawn.",en={16376},l=60,n="Icebane Breastplate",ob={i={{22682},{12359},{12360},{7080}}},ps={9233},r=0,rl=60,rp={},sn={16376},tg=62}
T[9237]={d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 4 Bolts of Runecloth, 2 Essences of Water, 4 Ironweb Spider Silks and 200 gold. You must also be of Exalted reputation with the Argent Dawn.",en={16376},l=60,n="Glacial Cloak",ob={i={{22682},{14048},{7080},{14227}}},ps={9233},r=0,rl=60,rp={},sn={16376},tg=62}
T[9238]={c=400,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 2 Bolts of Runecloth, 2 Essences of Water, 2 Ironweb Spider Silks and 200 gold.",en={16376},l=60,n="Glacial Wrists",ob={i={{22682},{14048},{7080},{14227}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9239]={c=400,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 4 Bolts of Runecloth, 4 Essences of Water, 2 Ironweb Spider Silks and 200 gold.",en={16376},l=60,n="Glacial Gloves",ob={i={{22682},{14048},{7080},{14227}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9240]={c=400,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 8 Bolts of Runecloth, 6 Essences of Water, 4 Ironweb Spider Silks and 300 gold. You must also be of Exalted reputation with the Argent Dawn.",en={16376},l=60,n="Glacial Vest",ob={i={{22682},{14048},{7080},{14227}}},ps={9233},r=0,rl=60,rp={},sn={16376},tg=62}
T[9241]={c=1032,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 12 Enchanted Leather, 3 Essence of Water, 3 Cured Rugged Hides and 200 gold. ",en={16376},l=60,n="Polar Bracers",ob={i={{22682},{12810},{7080},{15407}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9242]={c=1032,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 12 Enchanted Leather, 3 Essence of Water, 3 Cured Rugged Hides and 200 gold.",en={16376},l=60,n="Polar Gloves",ob={i={{22682},{12810},{7080},{15407}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9243]={c=1032,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 16 Enchanted Leathers, 5 Essences of Water, 5 Cured Rugged Hides and 300 gold. You must also be of Exalted reputation with the Argent Dawn.",en={16376},l=60,n="Polar Tunic",ob={i={{22682},{12810},{7080},{15407}}},ps={9233},r=0,rl=60,rp={},sn={16376},tg=62}
T[9244]={c=68,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 16 Heavy Scorpid Scales, 5 Essences of Water, 3 Cured Rugged Hides and 200 gold.",en={16376},l=60,n="Icy Scale Bracers",ob={i={{22682},{15408},{7080},{15407}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9245]={c=68,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 16 Heavy Scorpid Scale, 5 Essence of Water, 3 Cured Rugged Hides and 200 gold.",en={16376},l=60,n="Icy Scale Gauntlets",ob={i={{22682},{15408},{7080},{15407}}},ps={9233},r=0,rl=60,sn={16376},tg=62}
T[9246]={c=68,d="Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 24 Heavy Scorpid Scale, 7 Essence of Water, 5 Cured Rugged Hides and 300 gold. You must also be of Exalted reputation with the Argent Dawn.",en={16376},l=60,n="Icy Scale Breastplate",ob={i={{22682},{15408},{7080},{15407}}},ps={9233},r=0,rl=60,rp={},sn={16376},tg=62}
T[9248]={d="Aurel Goldleaf at Cenarion Hold in Silithus wants you to bring her 1 Abyssal Scepter. You must also be Honored with the Cenarion Circle.",en={15282},l=60,n="A Humble Offering",ob={i={{20515}}},r=0,rl=58,rp={609,0},sn={15282}}
T[9250]={c=1424,d="Find someone that will help you in recovering the last two pieces of the staff and ridding it of evil.",en={15192},l=60,n="Frame of Atiesh",nx=9251,r=0,rl=60,si={22727},su=22727,tg=62,x=9950}
T[9251]={c=1424,d="Anachronos at the Caverns of Time in Tanaris wants the Staff Head of Atiesh and the Base of Atiesh.",en={15192},l=60,n="Atiesh, the Befouled Greatstaff",ob={i={{22733},{22734}}},ps={9250},r=0,rl=60,sn={15192},tg=62,x=9950}
T[9257]={c=16,d="Anachronos at the Caverns of Time in Tanaris wants you to take Atiesh, Greatstaff of the Guardian to Stratholme and use it on Consecrated Earth. Defeat the entity that is exorcised from the staff and return to him.",en={15192},ex={9269,9270,9271},l=60,n="Atiesh, Greatstaff of the Guardian",ob={k={{16387,"Atiesh Cleansed"}}},ps={9251},r=0,rl=60,sn={15192},su=22737,tg=81,x=9950}
T[9259]={en={16399},l=60,n="Traitor to the Bloodsail",ob={i={{4306},{2604}}},r=0,rl=30,sf=1,sn={16399}}
T[9260]={d="Collect three Dim Necrotic Stones from the Scourge outside Stormwind and investigate the glowing runic circles near their encampment.",en={16478},l=6,n="Investigate the Scourge of Stormwind",ob={e={"Investigate a circle",{{1429,34.7,51,34.2,48.5,32.2,53.8,35.1,55.2}}},i={{22892}}},r=77,rl=1,sf=2,sn={16478},x=405}
T[9261]={d="Collect three Dim Necrotic Stones from the Scourge outside Ironforge and investigate the glowing runic circles near their encampment.",en={16484},l=10,n="Investigate the Scourge of Ironforge",ob={e={"Investigate a circle",{{1426,48.5,39.5,49.7,39.2}}},i={{22892}}},r=77,rl=1,sf=2,sn={16484},x=630}
T[9262]={d="Collect three Dim Necrotic Stones from the Scourge outside Darnassus and investigate the glowing runic circles near their encampment.",en={16495},l=10,n="Investigate the Scourge of Darnassus",ob={e={"Investigate a circle",{{1438,37,55.5,38.3,56.5}}},i={{22892}}},r=77,rl=1,sf=2,sn={16495},x=630}
T[9263]={d="Collect three Dim Necrotic Stones from the Scourge outside Orgrimmar and investigate the glowing runic circles near their encampment.",en={16493},l=10,n="Investigate the Scourge of Orgrimmar",ob={e={"Investigate a circle",{{1411,44.9,16.7,44.6,18.1}}},i={{22892}}},r=178,rl=1,sf=2,sn={16493},x=630}
T[9264]={d="Collect three Dim Necrotic Stones from the Scourge outside Thunder Bluff and investigate the glowing runic circles near their encampment.",en={16490},l=10,n="Investigate the Scourge of Thunder Bluff",ob={e={"Investigate a circle",{{1412,39.5,44.1}}},i={{22892}}},r=178,rl=1,sf=2,sn={16490},x=630}
T[9265]={d="Collect three Dim Necrotic Stones from the Scourge outside the Undercity and investigate the glowing runic circles near their encampment.",en={16494},l=8,n="Investigate the Scourge of the Undercity",ob={e={"Investigate a circle",{{1420,60.4,61.7}}},i={{22892}}},r=178,rl=1,sf=2,sn={16494},x=530}
T[9266]={en={16416},l=60,n="Making Amends",ob={i={{14047},{3857}}},r=0,rl=40,sf=1,sn={16416}}
T[9267]={en={16418},l=60,n="Mending Old Wounds",ob={i={{2589},{3371}}},r=0,rl=15,sf=1,sn={16418}}
T[9268]={en={16417},l=60,n="War at Sea",ob={i={{4338},{3466}}},r=0,rl=40,sf=1,sn={16417}}
T[9269]={c=1024,d="Anachronos at the Caverns of Time in Tanaris wants you to take Atiesh, Greatstaff of the Guardian to Stratholme and use it on Consecrated Earth. Defeat the entity that is exorcised from the staff and return to him.",en={15192},ex={9257,9270,9271},l=60,n="Atiesh, Greatstaff of the Guardian",ob={k={{16387,"Atiesh Cleansed"}}},ps={9251},r=0,rl=60,sn={15192},su=22737,tg=81,x=9950}
T[9270]={c=128,d="Anachronos at the Caverns of Time in Tanaris wants you to take Atiesh, Greatstaff of the Guardian to Stratholme and use it on Consecrated Earth. Defeat the entity that is exorcised from the staff and return to him.",en={15192},ex={9257,9269,9271},l=60,n="Atiesh, Greatstaff of the Guardian",ob={k={{16387,"Atiesh Cleansed"}}},ps={9251},r=0,rl=60,sn={15192},su=22737,tg=81,x=9950}
T[9271]={c=256,d="Anachronos at the Caverns of Time in Tanaris wants you to take Atiesh, Greatstaff of the Guardian to Stratholme and use it on Consecrated Earth. Defeat the entity that is exorcised from the staff and return to him.",en={15192},ex={9257,9269,9270},l=60,n="Atiesh, Greatstaff of the Guardian",ob={k={{16387,"Atiesh Cleansed"}}},ps={9251},r=0,rl=60,sn={15192},su=22737,tg=81,x=9950}
T[9272]={en={2546},l=55,n="Dressing the Part",r=0,rl=49,rp={87,0},sn={2546}}
T[9292]={d="Bring the Cracked Necrotic Crystal to Lieutenant Orrin outside the gates of Stormwind.",en={16478},l=60,n="Cracked Necrotic Crystal",r=77,rl=1,sn={16431},su=22949}
T[9295]={d="Take the Torn Letter to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.",en={16281},l=60,n="Letter from the Front",r=0,rl=45,si={22977},su=22932}
T[9299]={d="Take the Careworn Note to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.",en={16281},l=60,n="Note from the Front",r=0,rl=45,si={22972},su=22945}
T[9300]={d="Take the Ragged Page to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.",en={16281},l=60,n="Page from the Front",r=0,rl=45,si={22974},su=22946}
T[9301]={d="Take the Bloodstained Envelope to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.",en={16281},l=60,n="Envelope from the Front",r=0,rl=45,si={22970},su=22930}
T[9302]={d="Take the Crumpled Missive to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.",en={16281},l=60,n="Missive from the Front",r=0,rl=45,si={22973},su=22944}
T[9304]={d="Take the Smudged Document to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.",en={16281},l=60,n="Document from the Front",r=0,rl=45,si={22975},su=22948}
T[9310]={d="Bring the Faint Necrotic Crystal to Lieutenant Rukag in the courtyard of the Undercity.",en={16494},l=60,n="Faint Necrotic Crystal",r=178,rl=1,sn={16531},su=22950}
T[9317]={en={16786},l=60,n="Consecrated Sharpening Stones",ob={i={{22484}}},ps={9153},r=77,rl=50,sf=1,sn={16786}}
T[9318]={en={16786},l=60,n="Blessed Wizard Oil",ob={i={{22484}}},ps={9153},r=77,rl=50,sf=1,sn={16786}}
T[9320]={en={16787},l=60,n="Major Mana Potion",ob={i={{22484}}},ps={9153},r=178,rl=50,sf=1,sn={16787}}
T[9321]={en={16786},l=60,n="Major Healing Potion",ob={i={{22484}}},ps={9153},r=77,rl=50,sf=1,sn={16786}}
T[9333]={en={16787},l=60,n="Argent Dawn Gloves",ob={i={{22484}}},ps={9153},r=178,rl=50,sf=1,sn={16787}}
T[9334]={en={16787},l=60,n="Blessed Wizard Oil",ob={i={{22484}}},ps={9153},r=178,rl=50,sf=1,sn={16787}}
T[9335]={en={16787},l=60,n="Consecrated Sharpening Stones",ob={i={{22484}}},ps={9153},r=178,rl=50,sf=1,sn={16787}}
T[9336]={en={16787},l=60,n="Major Healing Potion",ob={i={{22484}}},ps={9153},r=178,rl=50,sf=1,sn={16787}}
T[9337]={en={16786},l=60,n="Major Mana Potion",ob={i={{22484}}},ps={9153},r=77,rl=50,sf=1,sn={16786}}
T[9338]={en={15540},l=60,n="Allegiance to Cenarion Circle",ob={i={{20802},{20800},{20801}}},r=0,rl=60,sf=1,sn={15540}}
T[9341]={en={16786},l=60,n="Tabard of the Argent Dawn",ob={i={{22484}}},ps={9153},r=77,rl=50,sf=1,sn={16786}}
T[9343]={en={16787},l=60,n="Tabard of the Argent Dawn",ob={i={{22484}}},ps={9153},r=178,rl=50,sf=1,sn={16787}}
T[9362]={c=128,d="Retrieve the Prismatic Shell for Archmage Xylem. The Archmage resides in a tower atop the cliffs of Azshara.",en={8379},l=60,n="Warlord Krellian",nx=9364,ob={i={{23250}}},r=0,rl=60,sn={8379},x=9950}
T[9364]={c=128,d="Polymorph the Spitelash of Azshara and kill the clones that appear several seconds later. When you have slain 50 Polymorph Clones, return to Archmage Xylem in Azshara.",en={8379},l=60,n="Fragmented Magic",ob={k={{16479}}},ps={9362},r=0,rl=60,sn={8379},su=23250}
T[9415]={d="Speak with Marshal Bluewall at the Alliance encampment near Hive'Zora.",en={17080},l=60,n="Report to Marshal Bluewall",nx=0,r=77,rl=1,sn={17082}}
T[9416]={d="Speak with General Kirika at the Horde encampment near Hive'Regal.",en={17079},l=60,n="Report to General Kirika",nx=0,r=178,rl=1,sn={17081}}
T[9419]={d="Find and deliver Silithyst to the Silithyst Extractor, then speak with Marshal Bluewall at the Alliance encampment near Hive'Zora.",en={17080},l=60,n="Scouring the Desert",ob={k={{17090}}},r=77,rl=1,sn={17080},tg=41,x=6600}
T[9422]={d="Find and deliver Silithyst to the Silithyst Extractor then speak with General Kirika at the Horde encampment near Hive'Regal.",en={17079},l=60,n="Scouring the Desert",ob={k={{18199}}},r=178,rl=1,sn={17079},tg=41,x=6600}
T[9664]={d="Capture Crown Guard Tower, Eastwall Tower, Northpass Tower and Plaguewood Tower in the Eastern Plaguelands, then return to Emmisary Whitebeard at Light's Hope Chapel.",en={17069},l=60,n="Establishing New Outposts",ob={k={{17689},{17690},{17696},{17698}}},r=77,rl=55,sn={17069},tg=41,x=6600}
T[9665]={d="Capture Crown Guard Tower, Eastwall Tower, Northpass Tower and Plaguewood Tower in the Eastern Plaguelands, then return to Emmisary Gormok at Light's Hope Chapel.",en={17072},l=60,n="Bolstering Our Defenses",ob={k={{17689},{17690},{17696},{17698}}},r=178,rl=55,sn={17072},tg=41,x=6600}
T[65593]={c=256,d="Bring the hearts of Avelina Lilly and Isaac Pearson to Carendin Halgar in the Temple of the Damned.",en={5675},ex={1507},l=-1,n="Hearts of the Lovers",nx=65597,ob={i={{190179},{190180}}},ps={1472},r=178,rl=20,sn={5693}}
T[65597]={c=256,d="Using the Lovers' Hearts, summon and subdue an incubus, then return the Lovers' Hearts to Carendin Halgar in the Magic Quarter of the Undercity.",en={5675},ex={1507},l=-1,n="The Binding",ob={k={{185335}}},ps={65593},r=178,rl=20,rs={190181},sn={5675}}
T[65601]={c=256,d="Speak with Magar in Orgrimmar.",en={3363},ex={1472},l=-1,n="Love Hurts",nx=65610,ps={1507},r=178,rl=20,sn={5909}}
T[65602]={c=256,d="Retrieve the Wooden Figurine and bring it to Gakin the Darkbinder in the Mage Quarter of Stormwind.",en={6122},l=-1,n="What Is Love?",nx=65603,ob={i={{190309}}},ps={1716},r=77,rl=20,rs={190307,190308},sn={6244}}
T[65603]={c=256,d="Using the Wooden Figurine, summon and subdue an incubus, then return the Wooden Figurine to Gakin the Darkbinder in the Slaughtered Lamb.",en={6122},l=-1,n="The Binding",ob={k={{185335}}},ps={65602},r=77,rl=20,rs={190186},sn={6122}}
T[65604]={c=256,d="Using the Withered Scarf, summon and subdue an incubus, then return the Withered Scarf to Gan'rul Bloodeye in Orgrimmar.",en={5875},ex={1472},l=-1,n="The Binding",ob={k={{185335}}},ps={65610},r=178,rl=20,rs={190187},sn={5875}}
T[65610]={c=256,d="Investigate Fallen Sky Lake in Ashenvale and report your findings to Gan'rul Bloodeye in Orgrimmar.",en={5875},ex={1472},l=-1,n="Wish You Were Here",nx=65604,ob={i={{190232}}},ps={65601},r=178,rl=20,sn={3363}}
end)()
