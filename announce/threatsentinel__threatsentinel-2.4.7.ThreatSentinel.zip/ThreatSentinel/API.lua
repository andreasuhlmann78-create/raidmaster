-- ThreatSentinel - API.lua
-- ns.API: Jede Blizzard-Funktion, die ThreatSentinel braucht, wird HIER einmal beim Laden ausgewählt.
-- Der übrige Code ruft nur ns.API.X auf (Vorbild: raidmaster/shared/vorlage/__ADDON__/API.lua).
--   * Kein "taint": Es wird nie eine Blizzard-Funktion ersetzt, nur diese eigene Tabelle gefüllt.
--   * Die Testroutine kann Einträge dieser Tabelle gefahrlos durch Attrappen ersetzen (geschützte Werte,
--     fehlende alte Funktionen, Kampfsperre, Test-Einheiten) und stellt sie danach wieder her.
--   * Fehlt eine Funktion im Client (z. B. UnitBuff in WoW Forever), ist der Eintrag nil - genau wie vorher das
--     globale Fehlen. Der Code prüft das an denselben Stellen wie bisher.

local ADDON, ns = ...

local API = {}
ns.API = API

local NAMES = {
	-- Bedrohung
	"UnitDetailedThreatSituation", "UnitThreatSituation",
	-- Einheiten
	"UnitName", "UnitExists", "UnitGUID", "UnitIsUnit", "UnitCanAttack", "UnitAffectingCombat", "UnitIsDeadOrGhost",
	"UnitIsDead", "UnitIsPlayer", "UnitIsConnected", "UnitClass", "UnitPowerType", "UnitHealth", "UnitHealthMax",
	"UnitHealthPercent", "UnitInRange", "UnitLevel", "UnitClassification", "UnitCreatureFamily", "UnitOnTaxi",
	"GetRaidTargetIndex", "CheckInteractDistance",
	-- Rollen und Gruppe
	"UnitGroupRolesAssigned", "GetPartyAssignment", "IsInGroup", "IsInRaid", "GetNumGroupMembers",
	"GetNumSubgroupMembers", "IsInInstance", "GetInstanceInfo",
	-- Kampf und Kontrolle
	"InCombatLockdown", "HasFullControl", "IsMounted",
	-- Gestalt
	"GetShapeshiftFormID", "GetShapeshiftForm",
	-- Zauber und Zauberbuch
	"GetSpellCooldown", "GetSpellBaseCooldown", "IsSpellInRange", "GetSpellInfo", "GetSpellTexture", "IsSpellKnown", "IsPlayerSpell",
	"GetSpellBookItemName",
	-- Auren (alte API)
	"UnitBuff", "UnitDebuff",
	-- Talente, Spezialisierung, Betrachten
	"GetTalentInfo", "GetNumTalents", "GetNumTalentTabs", "GetSpecialization", "GetSpecializationInfo",
	"GetSpecializationRole", "GetSpecializationRoleByID", "GetInspectSpecialization", "CanInspect", "NotifyInspect",
	"ClearInspectPlayer",
	-- moderne Tabellen (Zauber, Auren, Namensplaketten)
	"C_Spell", "C_UnitAuras", "C_NamePlate",
	-- Addon-Nachrichten, CVars, Addon-Daten (modern als C_-Tabelle, alt als Einzelfunktion)
	"C_ChatInfo", "SendAddonMessage", "RegisterAddonMessagePrefix",
	"C_CVar", "GetCVar", "SetCVar",
	"C_AddOns", "GetAddOnMetadata",
	-- Name und Realm des eigenen Charakters
	"UnitFullName", "GetNormalizedRealmName", "GetRealmName",
}
API.NAMES = NAMES

-- Einträge aus dem Spiel übernehmen (nil, wenn es die Funktion in diesem Client nicht gibt)
function API.Load()
	for _, name in ipairs(NAMES) do
		API[name] = _G[name]
	end
end
API.Load()
