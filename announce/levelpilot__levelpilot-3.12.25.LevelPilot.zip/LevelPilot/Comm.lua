-- LevelPilot - Datenaustausch zwischen Spielern (automatisch)
-- Geteilt werden aufgezeichnete Quests (Questgeber, Abgabe, Zielorte) und sichere Wege.
-- Wege (3.12.21): ueber die gemeinsame Datei GoldSentinelSync – Gruppe/Schlachtzug, Gilde und das Fluester-Netz
-- (Version 2). Der fruehere eigene Kanal "LevelPilotNet" wird nicht mehr betreten (in WoW Forever kommen Addon-
-- Nachrichten ueber eigene Kanaele nicht an) und einmal verlassen. Die Kennung LvPilot2 bleibt, damit aeltere
-- LevelPilot-Versionen anderer Spieler weiter verstanden werden.
--
-- Ablauf ohne Zutun des Spielers:
--   1) Neue eigene Aufzeichnungen werden sofort an alle geschickt.
--   2) Beim Betreten einer Zone fragt LevelPilot nach Daten genau dieser Zone ("Z").
--      Einige Spieler, die Daten dazu haben, antworten per Fluestern (zufaellig ausgewaehlt,
--      damit nicht alle gleichzeitig antworten).
--   3) Empfangene Daten werden geprueft und ergaenzen nur, was fehlt. Eigene Beobachtungen
--      haben immer Vorrang; jede weitere Meldung zaehlt als Bestaetigung.
-- Freigabe: Wer zustimmt, kennzeichnet seine Daten als "fuer die Startdatenbank freigegeben".
-- Nur solche Daten darf das Sammelwerkzeug aus fremden Speicherdateien uebernehmen.

local _, LP = ...
local L = LP.L
local Comm = {}
LP:RegisterModule("Comm", Comm)

local PREFIX = "LvPilot2"
local OLD_CHANNEL = "LevelPilotNet"   -- frueherer eigener Kanal: nur noch verlassen
local PEER_LIMIT = 80             -- Nachrichten pro Minute und Absender
local ZONE_REQ_COOLDOWN = 1200    -- Sekunden bis dieselbe Zone erneut angefragt wird
local ZONE_REPLY_COOLDOWN = 900   -- Sekunden bis wir demselben Spieler zur selben Zone erneut antworten
local ZONE_QUESTS = 30
local ZONE_PATHS = 60
local SEP = "\t"

local sentThisSession = {}
local peerRate = {}
local lastZoneReq = {}
local lastZoneReply = {}

------------------------------------------------------------------------
-- Pruefung empfangener Werte
------------------------------------------------------------------------
local function Num(v, lo, hi)
    v = tonumber(v)
    if not v or v ~= v or v < lo or v > hi then return nil end
    return v
end

local function CleanName(s)
    if type(s) ~= "string" then return nil end
    s = s:gsub("[%c|]", ""):gsub("^%s+", ""):gsub("%s+$", "")
    if #s < 2 or #s > 80 then return nil end
    return s
end

local function Point(str)
    if not str or str == "" then return nil end
    local m, x, y = str:match("^(%d+),([%d%.]+),([%d%.]+)$")
    m, x, y = Num(m, 1, 5000), Num(x, 0, 100), Num(y, 0, 100)
    if not (m and x and y) then return nil end
    return { m, x, y }
end

local function Short(v) return (string.format("%.1f", v):gsub("%.0$", "")) end

local function Consent() return LP.db.shareSeed and "1" or "0" end

------------------------------------------------------------------------
-- Kodieren
------------------------------------------------------------------------
local function EncodePoint(p)
    if not p then return "" end
    return p[1] .. "," .. Short(p[2]) .. "," .. Short(p[3])
end

function Comm:EncodeQuest(id)
    local e = LP.db.qdb[id]
    if not e or not e.n then return nil end
    -- weitergeleitete fremde Daten behalten die Freigabe ihres Urhebers
    local consent = e.net and ((e.c or 0) > 0 and "1" or "0") or Consent()
    local name = e.n:gsub("[%c|\t]", "")
    local msgs = {}
    msgs[1] = table.concat({ "Q", id, e.l or 0, e.f or "B", EncodePoint(e.s), EncodePoint(e.e), name:sub(1, 80), consent,
                             e.x or "", e.xl or "", e.dg or "" }, SEP)
    if e.o then
        for idx, list in pairs(e.o) do
            local parts = {}
            for i = 1, math.min(#list, 5) do parts[#parts + 1] = EncodePoint(list[i]) end
            msgs[#msgs + 1] = table.concat({ "O", id, idx, table.concat(parts, ";"), consent }, SEP)
        end
    end
    return msgs
end

-- Weg: Punkte {inst, n, w, zone}; bis zu 12 Punkte je Nachricht
function Comm:EncodePath(points, consent)
    local msgs, chunk, inst = {}, {}, nil
    consent = consent or Consent()
    local function flush()
        if #chunk >= 2 then msgs[#msgs + 1] = table.concat({ "P", inst, table.concat(chunk, ";"), consent }, SEP) end
    end
    for _, p in ipairs(points) do
        if inst and p[1] ~= inst then
            flush()
            chunk = {}
        end
        inst = p[1]
        chunk[#chunk + 1] = math.floor(p[2] + 0.5) .. "," .. math.floor(p[3] + 0.5) .. "," .. (p[4] or 0)
        if #chunk >= 12 then
            flush()
            chunk = { chunk[#chunk] }
        end
    end
    flush()
    return msgs
end

-- Hoehleneingang: C, Kontinent, Eingang n/w, Zone, Innenraum n/w, Radius, Freigabe
function Comm:EncodeCave(c, consent)
    if not (c and c.i and c.en and c.cn) then return nil end
    consent = consent or (c.net and "0" or Consent())
    return { table.concat({ "C", c.i, math.floor(c.en + 0.5), math.floor(c.ew + 0.5), c.m or 0,
                            math.floor(c.cn + 0.5), math.floor(c.cw + 0.5), math.floor((c.r or 60) + 0.5), consent }, SEP) }
end

-- Lernwerte (3.11): Droprate eines Questgegenstands, echtes Mob-Level, Flugzeiten (Summen, keine Namen)
function Comm:EncodeDrop(item)
    local s = LevelPilotDB and LevelPilotDB.calib
    local d = s and type(s.drops) == "table" and s.drops[item]
    if not d or d.k < 5 then return nil end
    local need = LP.Calib and LP.Calib:Need(item) or ""
    return { table.concat({ "D", item, math.floor(d.k + 0.5), math.floor(d.g + 0.5), need }, SEP) }
end
function Comm:EncodeMob(id)
    local s = LevelPilotDB and LevelPilotDB.calib
    local m = s and type(s.mobs) == "table" and s.mobs[id]
    if not m then return nil end
    return { table.concat({ "M", id, m[1], m[2] }, SEP) }
end
function Comm:EncodeFlights()
    if not LP.Calib then return nil end
    local n, dist, secs = LP.Calib:OwnFlights()
    if not n then return nil end
    return { table.concat({ "F", math.floor(n + 0.5), math.floor(dist + 0.5), math.floor(secs + 0.5) }, SEP) }
end

-- Absender nur als Zahl merken (keine Namen in der Speicherdatei)
local function SenderKey(sender)
    if type(sender) ~= "string" then return "s0" end      -- Absender geschuetzt/unbekannt
    local h = 5381
    for i = 1, #sender do h = (h * 33 + sender:byte(i)) % 4294967296 end
    return "s" .. h
end
Comm.SenderKey = SenderKey

-- 3.12.22: Urheber einer Anfrage ("Z") oder Mitspielersuche ("E"). Im Fluester-Netz kommt eine Nachricht mit dem
-- Absender der letzten Station an (Weitergeber). Darum traegt die Nachricht die Pruefsumme des eigenen Namens; der
-- Empfaenger nimmt sie nur an, wenn sie zum Absender passt (ab 3.12.23 ohne Pruefsumme gar nicht).
local function ShortName(name)
    if type(name) ~= "string" then return nil end
    return (name:match("^([^%-]+)") or name):lower()
end
function Comm.OriginKey(name)
    local n = ShortName(name)
    return n and SenderKey(n) or nil
end
function Comm.OwnOrigin()
    local me = UnitName and LP.SafeValue(UnitName("player"))
    return Comm.OriginKey(me) or ""
end
-- 3.12.23: ohne Pruefsumme nicht mehr annehmen – ein Weitergeber bringt alte Netz-Nachrichten (bis 3.12.21) auch
-- in seine Gilde, dort kaemen sie mit dist GUILD und seinem Namen an
function Comm.FromOrigin(field, sender, dist)
    if type(field) ~= "string" or field == "" then return false end
    return sender ~= nil and field == Comm.OriginKey(sender)
end

------------------------------------------------------------------------
-- Senden (GoldSentinelSync: eine gemeinsame Warteschlange und ein Takt fuer alle GoldSentinel-Addons)
------------------------------------------------------------------------
local function Sync() return _G.GoldSentinelSync end
local ep                              -- Anmeldung bei GoldSentinelSync (Comm:Init)

-- Umfang nach den Einstellungen: Gilde, Gruppe, Netz (alle Spieler mit LevelPilot); nil = nichts senden.
-- noNet: haeufige Lernwerte (Beute, Gegner) nur an Gilde und Gruppe, nie ins Fluester-Netz.
-- 3.12.22: nur die eingeschalteten Wege. GoldSentinelSync kennt (noch) keinen Umfang "nur Netz": das Netz geht
-- nur mit, wenn Gilde UND Gruppe eingeschaltet sind; sonst je eingeschaltetem Weg einzeln.
-- Rueckgabe: Liste von Optionen fuer ep:Send (leer = nichts senden)
local function Scope(noNet)
    local db = LP.db
    local guild, group, net = db.shareGuild, db.shareGroup, db.shareChannel and not noNet
    if guild and group then return { { net = net and true or false } } end
    local list = {}
    if guild then list[#list + 1] = { scope = "guild" } end
    if group then list[#list + 1] = { scope = "group" } end
    return list
end
Comm.Scope = Scope                     -- Testroutine

-- eine Nachricht senden. target: nil (alle Wege nach Einstellung), "GUILD", "PARTY"/"RAID" (nur Gruppe),
-- "WHISPER:<Name>" (an einen Spieler). Rueckgabe true, wenn sie in die Warteschlange kam.
function Comm:Queue(msg, target, noNet)
    if not ep or type(msg) ~= "string" then return false end
    if LP.Virtual and LP.Virtual.active then return false end   -- virtuelle Reise: nichts senden
    local list
    if target == nil then list = Scope(noNet)
    elseif target == "GUILD" then list = LP.db.shareGuild and { { scope = "guild" } } or {}
    elseif target == "PARTY" or target == "RAID" then list = LP.db.shareGroup and { { scope = "group" } } or {}
    elseif type(target) == "string" and target:find("^WHISPER:") then list = { { target = target:sub(9) } }
    else list = {}
    end
    local ok = false
    for _, opts in ipairs(list) do
        if ep:Send(msg, opts) then ok = true end
    end
    if ok then LP.db.net.sent = (LP.db.net.sent or 0) + 1 end
    return ok
end

-- Ins Netz gehen: Quests, Wege, Hoehlen, Fluege, Zonen-Anfragen, Lebenszeichen und die Elite-Mitspielersuche
-- (wenn eingeschaltet). Nur Gilde/Gruppe: Beute- und Gegnerwerte (noNet), Gruppenmodus (LvPilotG).
function Comm:Broadcast(msgs, key, noNet)
    if LP.Virtual and LP.Virtual.active then return end
    if key and sentThisSession[key] then return end
    local any = false
    for _, m in ipairs(msgs) do
        if self:Queue(m, nil, noNet) then any = true end
    end
    -- 3.12.22: erst als gesendet merken, wenn wirklich etwas hinausging
    if key and any then sentThisSession[key] = true end
    return any
end

-- Testroutine: eine Nachricht der gemeinsamen Warteschlange sofort senden
local function SendNext()
    local s = Sync()
    if s and s.Pump then return s.Pump(true) end
end

function Comm:Hello(target)
    local own = 0
    for _, r in pairs(LP.db.qdb) do if not r.net then own = own + 1 end end
    local msg = table.concat({ "H", LP.version, own, LP.Graph:Stats().nodes }, SEP)
    self:Queue(msg, target)
end

------------------------------------------------------------------------
-- Zonen-Abgleich
------------------------------------------------------------------------
function Comm:RequestZone(map, force)
    if not map then return end
    local now = LP:Now()
    if not force and lastZoneReq[map] and now - lastZoneReq[map] < ZONE_REQ_COOLDOWN then return end
    lastZoneReq[map] = now
    -- 3.12.22: nur Gilde/Gruppe (im Netz waere der Absender der Weitergeber), mit Pruefsumme des Urhebers
    local msg = table.concat({ "Z", map, LP:RealLevel(), Comm.OwnOrigin() }, SEP)
    self:Queue(msg, nil, true)
    LP.db.net.zoneRequests = (LP.db.net.zoneRequests or 0) + 1
end

local function InMap(p, map) return p and p[1] == map end

local function QuestsForZone(map)
    local list = {}
    for id, r in pairs(LP.db.qdb) do
        if r.n then
            local hit = InMap(r.s, map) or InMap(r.e, map)
            if not hit and r.o then
                for _, spots in pairs(r.o) do
                    for _, h in ipairs(spots) do if h[1] == map then hit = true break end end
                    if hit then break end
                end
            end
            if hit then
                -- eigene zuerst, dann haeufig bestaetigte
                list[#list + 1] = { id = id, score = (r.net and 0 or 1000) + (r.by or 0) }
            end
        end
    end
    table.sort(list, function(a, b) return a.score > b.score end)
    return list
end

local function PathsForZone(map)
    local list = {}
    for _, e in pairs(LP.db.graph.edges or {}) do
        local a, b = LP.Graph:NodeById(e[1]), LP.Graph:NodeById(e[2])
        if a and b and (a[4] == map or b[4] == map) and (e[3] == "r" or e[3] == "w" or e[3] == "s") then
            list[#list + 1] = { a = a, b = b, own = e[3] ~= "s", c = e.c, n = e[4] or 1 }
            if #list >= 600 then break end
        end
    end
    table.sort(list, function(x, y)
        if x.own ~= y.own then return x.own end
        return x.n > y.n
    end)
    return list
end

-- 3.12.22: die gemeinsame Warteschlange gehoert allen GoldSentinel-Addons. Eine Antwort hat hoechstens
-- REPLY_MAX Nachrichten (der Rest bei der naechsten Anfrage, ab dort weiter), und geantwortet wird nur, wenn
-- die Warteschlange fast leer ist.
Comm.REPLY_MAX = 25
Comm.REPLY_QUEUE_LIMIT = 50
local replyOffset = {}
function Comm:ReplyZone(sender, map)
    local key = sender .. ":" .. map
    local now = LP:Now()
    if lastZoneReply[key] and now - lastZoneReply[key] < ZONE_REPLY_COOLDOWN then return end
    local S = Sync()
    if S and type(S.queue) == "table" and #S.queue > Comm.REPLY_QUEUE_LIMIT then return end
    local quests, paths = QuestsForZone(map), PathsForZone(map)
    local caves = {}
    for _, c in pairs(LP.db.caves or {}) do if c.m == map then caves[#caves + 1] = c end end
    -- eine Liste aller moeglichen Antwortteile (je Teil 1..n Nachrichten)
    local items = {}
    for i = 1, math.min(ZONE_QUESTS, #quests) do
        local id = quests[i].id
        items[#items + 1] = function() return self:EncodeQuest(id) end
    end
    for i = 1, math.min(ZONE_PATHS, #paths) do
        local p = paths[i]
        items[#items + 1] = function()
            local consent = p.own and Consent() or (p.c and "1" or "0")
            return self:EncodePath({ p.a, p.b }, consent)
        end
    end
    for i = 1, math.min(20, #caves) do
        local c = caves[i]
        items[#items + 1] = function() return self:EncodeCave(c) end
    end
    if #items == 0 then return end
    lastZoneReply[key] = now
    local target = "WHISPER:" .. sender
    local start = (replyOffset[map] or 0) % #items
    local sent, used = 0, 0
    for k = 1, #items do
        local msgs = items[(start + k - 1) % #items + 1]() or {}
        if sent > 0 and sent + #msgs > Comm.REPLY_MAX then break end
        for _, m in ipairs(msgs) do
            if self:Queue(m, target) then sent = sent + 1 end
        end
        used = k
    end
    replyOffset[map] = start + used
    LP.db.net.zoneReplies = (LP.db.net.zoneReplies or 0) + 1
    return sent
end

-- Nicht jeder antwortet: bei vielen Spielern nur ein zufaelliger Teil, leicht verzoegert
function Comm:OnZoneRequest(sender, map)
    if type(sender) ~= "string" or sender == "" then return end   -- Absender geschuetzt: keine Antwort moeglich
    local recent = self:Stats().recent
    local chance = math.min(1, 3 / math.max(1, recent))
    if math.random() > chance then return end
    C_Timer.After(1 + math.random() * 5, function()
        LP:Safe(L["Zonen-Antwort"], Comm.ReplyZone, Comm, sender, map)
    end)
end

------------------------------------------------------------------------
-- Empfangen
------------------------------------------------------------------------
local function RateOk(sender)
    sender = sender or "?"
    local now = GetTime()
    local r = peerRate[sender]
    if not r or now - r.t > 60 then
        peerRate[sender] = { t = now, count = 1 }
        return true
    end
    r.count = r.count + 1
    return r.count <= PEER_LIMIT
end

Comm.RateOk = RateOk            -- fuer die Testroutine

-- Testroutine: eigene Eintraege der gemeinsamen Warteschlangen sichern und wiederherstellen (Testdaten gehen nie
-- an andere Spieler; Eintraege anderer Addons bleiben unberuehrt)
local function Own(item) return type(item) == "table" and (item.prefix == PREFIX or item.prefix == "LvPilotG") end
function Comm:QueueSnapshot()
    local s = Sync()
    local copy = { queue = {}, net = {} }
    if not s then return copy end
    for _, item in ipairs(s.queue or {}) do copy.queue[item] = true end
    for _, item in ipairs(s.netQueue or {}) do copy.net[item] = true end
    return copy
end
function Comm:QueueRestore(copy)
    local s = Sync()
    if not s or type(copy) ~= "table" then return end
    for _, pair in ipairs({ { s.queue, copy.queue or {} }, { s.netQueue, copy.net or {} } }) do
        local list, keep = pair[1], pair[2]
        if type(list) == "table" then
            for i = #list, 1, -1 do
                if Own(list[i]) and not keep[list[i]] then table.remove(list, i) end
            end
        end
    end
end
-- Anzahl eigener Nachrichten in den gemeinsamen Warteschlangen
function Comm:QueueCount()
    local s, n = Sync(), 0
    if not s then return 0 end
    for _, item in ipairs(s.queue or {}) do if Own(item) then n = n + 1 end end
    for _, item in ipairs(s.netQueue or {}) do if Own(item) then n = n + 1 end end
    return n
end

function Comm:Receive(msg, sender, dist)
    local parts = {}
    for field in (msg .. SEP):gmatch("(.-)" .. SEP) do parts[#parts + 1] = field end
    local kind = parts[1]
    LP.db.net.recv = (LP.db.net.recv or 0) + 1
    LP.db.net.peers = LP.db.net.peers or {}
    if sender then LP.db.net.peers[SenderKey(sender)] = LP:Now() end

    if kind == "H" then
        -- nur Statistik; Daten fliessen ueber Zonen-Anfragen
    elseif kind == "Z" then
        local map = Num(parts[2], 1, 5000)
        if map and Comm.FromOrigin(parts[4], sender, dist) then self:OnZoneRequest(sender, map) end
    elseif kind == "Q" then
        local id = Num(parts[2], 1, 300000)
        local lvl = Num(parts[3], 0, 63)
        local fac = parts[4]
        local s, e = Point(parts[5]), Point(parts[6])
        local name = CleanName(parts[7])
        local consent = parts[8] == "1"
        if not (id and lvl and name) or not (fac == "A" or fac == "H" or fac == "B") then return end
        local r = LP.db.qdb[id]
        if r and not r.net then
            r.by = (r.by or 0) + 1        -- eigene Daten bleiben, nur Bestaetigung zaehlen
            return
        end
        local isNew = not r
        if not r then
            r = { net = true, t = LP:Now(), by = 0 }
            LP.db.qdb[id] = r
        end
        r.by = (r.by or 0) + 1
        if consent then r.c = (r.c or 0) + 1 end
        r.n = r.n or name
        r.l = (r.l and r.l > 0) and r.l or (lvl > 0 and lvl or nil)
        r.f = r.f or fac
        if s and not r.s then r.s = s end
        if e and not r.e then r.e = e end
        -- echte EP und Dungeon-Zuordnung (neuere Versionen; aeltere senden diese Felder nicht)
        local xp, xl, dg = Num(parts[9], 1, 100000), Num(parts[10], 1, 63), Num(parts[11], 1, 20000)
        if xp and xl and not r.x then r.x, r.xl = xp, xl end
        if dg and LP.DungeonByArea[dg] and not r.dg then r.dg = LP.DungeonByArea[dg] end
        if isNew then LP.db.net.newQuests = (LP.db.net.newQuests or 0) + 1 end
        LP.QuestDB:Invalidate(id)
        -- 3.12.24: empfangene Quests sammeln (Kandidaten neu bauen und neu planen hoechstens alle 20 s)
        LP:Throttle("comm_qdb", 20, function() LP:Fire("QDB_CHANGED") end)
    elseif kind == "O" then
        local id = Num(parts[2], 1, 300000)
        local idx = Num(parts[3], 1, 10)
        local r = id and LP.db.qdb[id]
        if not (r and idx and parts[4]) then return end
        if not r.net then return end          -- eigene Zielorte nicht mit fremden mischen
        r.o = r.o or {}
        local list = r.o[idx] or {}
        r.o[idx] = list
        for pstr in parts[4]:gmatch("[^;]+") do
            local p = Point(pstr)
            if p and #list < 5 then
                local dup = false
                for _, h in ipairs(list) do
                    if h[1] == p[1] and math.abs(h[2] - p[2]) < 3 and math.abs(h[3] - p[3]) < 3 then
                        dup = true
                        h[4] = math.min((h[4] or 1) + 1, 50)
                    end
                end
                if not dup then list[#list + 1] = { p[1], p[2], p[3], 1 } end
            end
        end
        LP.QuestDB:Invalidate(id)
    elseif kind == "E" then
        -- Elite-Quests eines anderen Spielers (Mitspieler finden)
        if LP.Social and Comm.FromOrigin(parts[5], sender, dist) then LP.Social:OnMessage(parts, sender) end
    elseif kind == "C" then
        -- Hoehleneingang (aeltere Versionen ignorieren diese Nachricht)
        local i = Num(parts[2], 0, 100000)
        local en, ew = Num(parts[3], -40000, 40000), Num(parts[4], -40000, 40000)
        local m = Num(parts[5], 0, 5000)
        local cn, cw = Num(parts[6], -40000, 40000), Num(parts[7], -40000, 40000)
        local r = Num(parts[8], 20, 300)
        if not (i and en and ew and cn and cw and r) then return end
        if LP.Geo:Dist(en, ew, cn, cw) > 400 then return end          -- unplausibel
        local isNew = LP.Caves:Store({ i = i, en = en, ew = ew, m = m ~= 0 and m or nil, cn = cn, cw = cw, r = r }, true)
        if isNew then
            LP.db.net.newCaves = (LP.db.net.newCaves or 0) + 1
            LP:Throttle("comm_caves", 5, function() LP:Fire("CAVES_CHANGED") end)
        end
    elseif kind == "D" then
        local item = Num(parts[2], 1, 300000)
        local k, g = Num(parts[3], 1, 5000), Num(parts[4], 0, 15000)
        local need = Num(parts[5], 1, 250)
        if not (item and k and g) or g > k * 3 then return end           -- unplausibel
        local N = LevelPilotData and LevelPilotData.I
        if N and not N[item] then return end                             -- kein Questgegenstand
        if LP.Calib then LP.Calib:AddNetDrop(item, SenderKey(sender), k, g, need) end
    elseif kind == "M" then
        local id = Num(parts[2], 1, 300000)
        local lo, hi = Num(parts[3], 1, 63), Num(parts[4], 1, 63)
        local N = LevelPilotData and LevelPilotData.N
        local npc = id and N and N[id]
        -- nur nahe am Datenpaket (hoechstens 10 Level daneben), sonst Fehlmessung oder anderer Gegner
        if not (npc and npc.lo and lo and hi) or lo > hi or math.abs(lo - npc.lo) > 10 then return end
        if LP.Calib then LP.Calib:AddNetMob(id, lo, hi) end
    elseif kind == "F" then
        local n, dist, secs = Num(parts[2], 1, 10000), Num(parts[3], 300, 1e8), Num(parts[4], 10, 1e7)
        if not (n and dist and secs) then return end
        local per = secs / dist * 1000                                   -- Sekunden je 1000 Yards
        if per < 15 or per > 120 then return end
        if LP.Calib then LP.Calib:AddNetFlights(SenderKey(sender), n, dist, secs) end
    elseif kind == "P" then
        local inst = Num(parts[2], 0, 100000)
        if not inst or not parts[3] then return end
        local consent = parts[4] == "1"
        local pts = {}
        for pstr in parts[3]:gmatch("[^;]+") do
            local n, w, z = pstr:match("^(%-?%d+),(%-?%d+),(%d+)$")
            n, w, z = Num(n, -40000, 40000), Num(w, -40000, 40000), Num(z, 0, 5000)
            if n and w then pts[#pts + 1] = { inst, n, w, z ~= 0 and z or nil } end
        end
        -- Plausibilitaet: keine Spruenge ueber 120 Yards zwischen Punkten
        for i = 2, #pts do
            if LP.Geo:Dist(pts[i - 1][2], pts[i - 1][3], pts[i][2], pts[i][3]) > 120 then return end
        end
        if #pts >= 2 then
            local added = LP.Graph:AddPolyline(pts, "s", true, consent)
            if added > 0 then LP.db.net.newPaths = (LP.db.net.newPaths or 0) + added end
        end
    end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
-- frueheren eigenen Kanal einmal verlassen (frei werdender Kanalplatz); nie mehr betreten
local function LeaveOldChannel()
    if not GetChannelName or not LeaveChannelByName then return false end
    local ok, idx = pcall(GetChannelName, OLD_CHANNEL)
    if not ok or LP.SafeValue(idx) == nil or type(idx) ~= "number" or idx <= 0 then return false end
    pcall(LP.Act.Call, "LeaveChannelByName", LeaveChannelByName, OLD_CHANNEL)
    if LP.Protocol then LP.Protocol:Add("sync", "Alter Kanal " .. OLD_CHANNEL .. " verlassen") end
    return true
end
Comm.LeaveOldChannel = LeaveOldChannel   -- Testroutine
Comm.SendNext = function() return SendNext() end
Comm.PREFIX = PREFIX

-- einmalige Frage nach der Freigabe fuer die Startdatenbank
local function AskConsent()
    if LP.db.shareSeedAsked then return end
    if not StaticPopupDialogs or not StaticPopup_Show then return end
    StaticPopupDialogs["LEVELPILOT_CONSENT"] = {
        text = L["|cffffb238LevelPilot|r\n\nDürfen deine Aufzeichnungen (Quests, Wege, Händler) in die "]
            .. L["LevelPilot-Startdatenbank aufgenommen und mit dem Addon veröffentlicht werden?\n\n"]
            .. L["Es werden keine Namen oder Chatinhalte geteilt. Du kannst das jederzeit in der Zentrale ändern."],
        button1 = L["Ja, freigeben"],
        button2 = L["Nein"],
        OnAccept = function() LP.db.shareSeed = true LP.db.shareSeedAsked = true end,
        OnCancel = function() LP.db.shareSeed = false LP.db.shareSeedAsked = true end,
        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
    }
    LP.Act.Call("StaticPopup_Show", StaticPopup_Show, "LEVELPILOT_CONSENT")
end

function Comm:Init()
    LP.db.net = LP.db.net or {}
    -- 3.12.21: fruehere Absender-Namen in der Speicherdatei nur noch als Pruefsumme
    if type(LP.db.net.peers) == "table" then
        local peers = {}
        for k, t in pairs(LP.db.net.peers) do
            if type(t) == "number" then
                local key = (type(k) == "string" and k:match("^s%d+$")) and k or SenderKey(tostring(k))
                peers[key] = math.max(peers[key] or 0, t)
            end
        end
        LP.db.net.peers = peers
    end
    local S = Sync()
    if not S or not S.Register then
        LP.Report("Comm", "GoldSentinelSync fehlt")
        return
    end
    ep = S.Register("LevelPilot", PREFIX, LP.version)
    Comm.ep = ep
    ep:UseStorage(LevelPilotDB)
    ep:OnMessage(function(msg, sender, dist)
        if not RateOk(sender) then return end
        local ok, err = pcall(Comm.Receive, Comm, msg, sender, dist)
        if not ok then
            LP:Debug(L["Empfangsfehler: "] .. tostring(err))
            LP.Report("Comm-Empfang", err)        -- nur die Lua-Meldung, nie Absender oder Inhalt
        end
    end)

    -- 1) eigene Aufzeichnungen sofort teilen
    LP:Listen("QUEST_RECORDED", function(id)
        local msgs = Comm:EncodeQuest(id)
        if msgs then Comm:Broadcast(msgs, "Q" .. id .. ":" .. (LP.db.qdb[id].e and "e" or "s")) end
    end)
    LP:Listen("PATH_RECORDED", function(points)
        Comm:Broadcast(Comm:EncodePath(points))
    end)
    -- Lernwerte: hoechstens alle 10 Minuten je Gegenstand/Gegner, Fluege einmal je neuem Flug
    LP:Listen("CALIB_DROP", function(item)
        LP:Throttle("comm_drop" .. item, 600, function()
            local msgs = Comm:EncodeDrop(item)
            if msgs then Comm:Broadcast(msgs, nil, true) end
        end)
    end)
    LP:Listen("CALIB_MOB", function(id)
        LP:Throttle("comm_mob" .. id, 600, function()
            local msgs = Comm:EncodeMob(id)
            if msgs then Comm:Broadcast(msgs, nil, true) end
        end)
    end)
    LP:Listen("CALIB_FLIGHT", function()
        local msgs = Comm:EncodeFlights()
        if msgs then Comm:Broadcast(msgs) end
    end)
    LP:Listen("CAVE_LEARNED", function(key)
        local c = LP.db.caves and LP.db.caves[key]
        local msgs = c and Comm:EncodeCave(c)
        if msgs then Comm:Broadcast(msgs, "C" .. key) end
    end)

    -- 2) Zonen-Abgleich beim Betreten einer Zone
    LP:On("ZONE_CHANGED_NEW_AREA", function()
        C_Timer.After(3, function() Comm:RequestZone(C_Map.GetBestMapForUnit("player")) end)
    end)
    LP:On("GROUP_ROSTER_UPDATE", function()
        LP:Throttle("comm_group", 30, function()
            if IsInGroup() then
                Comm:Hello(IsInRaid() and "RAID" or "PARTY")
                Comm:RequestZone(C_Map.GetBestMapForUnit("player"), true)
            end
        end)
    end)

    C_Timer.After(15, function()
        LeaveOldChannel()
        Comm:Hello()
        Comm:RequestZone(C_Map.GetBestMapForUnit("player"))
    end)
    C_Timer.After(20, AskConsent)
    -- Diagnose-Protokoll: einmal je Sitzung die Wege, alle 10 Minuten der Stand (ein Eintrag, wird ueberschrieben)
    C_Timer.After(60, function()
        local lines = Comm:DiagLines()
        if LP.Protocol and lines[1] then LP.Protocol:Add("sync", lines[1]) end
    end)
    LP:Ticker("comm_diag", 600, function()
        if LP.Protocol then LP.Protocol:Add("sync", "SYNC Stand", table.concat(Comm:DiagLines(), "\n")) end
    end)
    LP:Ticker("comm_hello", 900, function()
        Comm:Hello()
        Comm:RequestZone(C_Map.GetBestMapForUnit("player"))
    end)
end

function Comm:Stats()
    local peers, recent = 0, 0
    local now = LP:Now()
    for _, t in pairs(LP.db.net.peers or {}) do
        peers = peers + 1
        if now - t < 3600 then recent = recent + 1 end
    end
    return { sent = LP.db.net.sent or 0, recv = LP.db.net.recv or 0, peers = peers, recent = recent,
             online = ep and ep:Peers(3600) or 0, queued = self:QueueCount(),
             newQuests = LP.db.net.newQuests or 0, newPaths = LP.db.net.newPaths or 0,
             zoneRequests = LP.db.net.zoneRequests or 0, zoneReplies = LP.db.net.zoneReplies or 0 }
end

-- frueher: Kanal neu betreten; heute nichts zu tun (Schalter in der Zentrale ruft es noch auf)
function Comm:Rejoin() end

-- /lp sync test: wer antwortet? Ausgabe "N Antworten (Gilde a, Gruppe b)"
function Comm:SyncTest(out)
    local S = Sync()
    out = out or function(t) LP:Print(t) end
    if not S or not S.Ping then out(L["GoldSentinelSync fehlt."]) return false end
    out(L["Sync-Test läuft (5 Sekunden) …"])
    S.Ping("LevelPilot", function(r)
        r = r or {}
        out(L("%d Antworten (Gilde %d, Gruppe %d)", r.total or 0, r.guild or 0, r.group or 0))
    end)
    return true
end

-- Zeilen fuer das Diagnose-Protokoll (ohne Spielernamen)
function Comm:DiagLines()
    local S = Sync()
    if not S or not S.DiagLines then return { "SYNC GoldSentinelSync fehlt" } end
    local ok, lines = pcall(S.DiagLines)
    return ok and lines or { "SYNC Fehler: " .. tostring(lines) }
end
