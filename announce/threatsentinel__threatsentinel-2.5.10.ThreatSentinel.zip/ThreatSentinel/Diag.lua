-- ThreatSentinel - Diag.lua
-- Diagnose-Protokoll (übernommen aus der GoldSentinel-Vorlage, Vorbild LevelPilot).
--
-- Wozu: Was nur im echten Spiel passiert (Fehler, Fehlerschleifen, langsame Durchläufe, Moduswechsel in WoW Forever),
-- schreibt ThreatSentinel selbst mit. Der Nutzer sieht es mit /ts protokoll (zum Kopieren) – oder es geht beim
-- Ausloggen / /reload automatisch als "GSDIAG1"-Zeichenkette über die SavedVariables und den RaidMasterUploader
-- nach Discord #testberichte -> GitHub (abschaltbar in den Einstellungen).
--
-- Benutzung im eigenen Code:
--   ns.Diag("MODUS", "VOLL -> ANZEIGE", ms)     -- Art, Text, optional Dauer in ms
--   ns.Timed("Durchlauf", fn, ...)              -- misst fn; über ns.DIAG_SLOW_MS -> Eintrag LANGSAM
-- Fehler aus ns:ReportError landen automatisch als FEHLER (gleicher Text direkt hintereinander wird nur gezählt).
--
-- Unterschiede zur Vorlage:
--   * Gespeichert wird in ThreatSentinelDB.diag (für alle Profile gemeinsam), nicht im Profil.
--   * Während der Testroutine wird nichts geschrieben (ihre Test-Kulisse würde sonst Einträge erzeugen).
--   * Blizzard-Funktionen nur über ns.API.
--
-- Regeln: KEINE Spieler-, Charakter-, Gilden- oder Realmnamen (das Protokoll landet im öffentlichen Repo).

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)

ns.DIAG_MAX = 200          -- höchstens so viele Einträge, älteste fallen weg
ns.DIAG_SLOW_MS = 16       -- ein Frame bei 60 fps
ns.DIAG_PREFIX = "GSDIAG1"
ns.DIAG_EXPORT_MAX = 60000 -- Zeichen in der SavedVariables-Zeichenkette

local function Now() return GetTime and GetTime() or 0 end
local function Stamp() return date and date("%d.%m. %H:%M") or "" end
local function Ms()
	if API.debugprofilestop then return API.debugprofilestop() end
	return Now() * 1000
end
local function Clean(s)
	if ns.IsSecret and ns.IsSecret(s) then return "<geschützt>" end
	s = tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("[\r\n|]", " ")
	return s
end

-- Speicher (gemeinsam für alle Profile). Im Test nur mit ns.diagForce (Testfall der Routine).
local function Store()
	if ns.routineRunning and not ns.diagForce then return nil end
	local root = ThreatSentinelDB
	if type(root) ~= "table" then return nil end
	if type(root.diag) ~= "table" then root.diag = { entries = {}, sessions = {} } end
	root.diag.entries = root.diag.entries or {}
	root.diag.sessions = root.diag.sessions or {}
	return root.diag
end

-- Einen Eintrag schreiben. Gleiche Art + gleicher Text direkt hintereinander -> nur Zähler erhöhen.
function ns.Diag(kind, text, ms)
	local d = Store()
	if not d then return end
	kind, text = Clean(kind):upper(), Clean(text)
	local e = d.entries[1]
	if e and e.k == kind and e.t == text then
		e.n = (e.n or 1) + 1
		e.z = Stamp()
		if ms then e.ms = math.max(e.ms or 0, math.floor(ms + 0.5)) end
		return e
	end
	e = { k = kind, t = text, z = Stamp(), n = 1, ms = ms and math.floor(ms + 0.5) or nil, v = ns.version }
	table.insert(d.entries, 1, e)
	for i = #d.entries, ns.DIAG_MAX + 1, -1 do d.entries[i] = nil end
	return e
end

-- Gleichartige Ereignisse zählen
function ns.DiagCount(kind, what)
	return ns.Diag(kind, what)
end

-- fn messen; ist sie langsamer als ein Frame -> LANGSAM. Fehler werden wie bisher gemeldet (ns:ReportError).
function ns.Timed(name, fn, ...)
	local t0 = Ms()
	local res = { pcall(fn, ...) }
	local ms = Ms() - t0
	if ms > ns.DIAG_SLOW_MS then ns.Diag("LANGSAM", name, ms) end
	if not res[1] then ns:ReportError(res[2]) return end
	return unpack(res, 2)
end

-- Sitzung beim Einloggen vermerken (nur Stufe, Klasse und Spielversion, kein Name)
function ns.DiagSession()
	local d = Store()
	if not d then return end
	local lvl = API.UnitLevel and API.UnitLevel("player") or 0
	if ns.IsSecret(lvl) then lvl = 0 end
	table.insert(d.sessions, 1, { z = Stamp(), lvl = lvl, class = ns.class or "?", v = ns.version,
		flavor = tostring(ns.flavor or "?") })
	for i = #d.sessions, 21, -1 do d.sessions[i] = nil end
end

-- Zusatzzeilen: Zustand, den die Prüf-Sitzung zum Verstehen braucht (keine Namen)
function ns.DiagExtra()
	local out = {}
	local last = ThreatSentinelDB and ThreatSentinelDB.threatAccess
	out[#out + 1] = string.format("Bedrohung: %s · Modus %s · gespeichert %s", tostring(ns.threatAccess), ns:ThreatMode(),
		type(last) == "table" and (tostring(last.state) .. " " .. tostring(last.date) .. " " .. tostring(last.build)) or "-")
	-- Gruppe: Spieler und Begleiter getrennt (P3: "Gruppe 6" in einer 5er-Gruppe war der Begleiter)
	local players, pets = 0, 0
	for _, u in ipairs(ns.groupUnits or {}) do
		if u:find("pet", 1, true) then pets = pets + 1 else players = players + 1 end
	end
	out[#out + 1] = string.format("Rolle %s · Tankhaltung %s · Gruppe %d Spieler + %d Begleiter · Spott %s (%s)", tostring(ns:MyRole()),
		tostring(ns:IsTankStance()), players, pets, ns.tauntSpell and "ja" or "nein", tostring(ns.tauntMode))
	local c = {}
	for _, k in ipairs(ns.COMPAT_ORDER or {}) do
		local e = ns.compat and ns.compat[k]
		if e and e.mode then c[#c + 1] = k .. "=" .. e.mode end
	end
	out[#out + 1] = "Funktionen: " .. (#c > 0 and table.concat(c, " ") or "-")
	out[#out + 1] = string.format("Gesperrte Aktionen: %d", #(ns.blocked or {}))
	if ns.Sync and ns.Sync.StatsLine then out[#out + 1] = "Sync (PARTY/RAID): " .. ns.Sync:StatsLine() end
	return out
end

-- Das Protokoll als Text (für das Kopierfenster und die Ausgabe)
function ns.DiagText()
	local d = (ThreatSentinelDB and ThreatSentinelDB.diag) or { entries = {}, sessions = {} }
	local entries, sessions = d.entries or {}, d.sessions or {}
	local G = ns.Game
	local out = {}
	local function add(s) out[#out + 1] = s end
	add(string.format("%s-Protokoll v%s · %s", ADDON, tostring(ns.version), Stamp()))
	local locale = API.GetLocale and API.GetLocale() or "?"
	add(string.format("Client %s · %s", tostring(locale), G and G.Status and Clean(G.Status()) or "?"))
	add(string.format("Sitzungen: %d", #sessions))
	for i = 1, math.min(#sessions, 10) do
		local s = sessions[i]
		add(string.format("  %s L%s %s %s v%s", s.z or "", tostring(s.lvl), tostring(s.class), tostring(s.flavor or ""), tostring(s.v)))
	end
	add("")
	add("== Diagnose")
	add(string.format("  Fehler in dieser Sitzung: %d", ns.errorCount or 0))
	local ok, extra = pcall(ns.DiagExtra)
	if ok and type(extra) == "table" then for _, line in ipairs(extra) do add("  " .. Clean(line)) end end
	add("")
	add(string.format("== Einträge (%d, neueste zuerst)", #entries))
	for _, e in ipairs(entries) do
		add(string.format("[%s] %s%s %s%s", e.z or "", e.k or "?", (e.n or 1) > 1 and (" ×" .. e.n) or "",
			e.t or "", e.ms and (" · " .. e.ms .. " ms") or ""))
	end
	return table.concat(out, "\n")
end

-- Zeichenkette für den Uploader (wie GSTEST1): Präfix, Addon, Version, dann der Text
function ns.DiagExport()
	local text = ns.DiagText()
	if #text > ns.DIAG_EXPORT_MAX then text = text:sub(1, ns.DIAG_EXPORT_MAX) end
	return ns.DIAG_PREFIX .. "|" .. ADDON .. "|" .. tostring(ns.version) .. "|" .. text
end

function ns.ShowDiag()
	local text = ns.DiagText()
	if ns.Test and ns.Test.ShowText then ns.Test:ShowText(text, ns.L.DIAG_TITLE) else ns:Print(text) end
end

-- Beim Ausloggen / /reload die Export-Zeichenkette in die SavedVariables legen (nicht während der Testroutine)
ns:On("PLAYER_LOGOUT", function()
	if ns.routineRunning or type(ThreatSentinelDB) ~= "table" then return end
	if ns.db and ns.db.diagSend == false then
		ThreatSentinelDB.diagExport = nil
		return
	end
	ThreatSentinelDB.diagExport = ns.DiagExport()
end)

ns:On("PLAYER_LOGIN", function()
	ns.DiagSession()
	-- Sync: einmal je Sitzung der Weg, danach alle 10 Minuten die Zähler (keine Namen)
	ns.Diag("SYNC", "Weg=PARTY/RAID (kein eigener Kanal)")
	C_Timer.NewTicker(600, function()
		if ns.Sync and ns.Sync.StatsLine then ns.Diag("SYNC", ns.Sync:StatsLine()) end
	end)
end)

-- Kampf: Beginn und Ende mit Modus (zählt gleiche Zeilen zusammen)
ns:On("PLAYER_REGEN_DISABLED", function()
	if ns:IsActive() then ns.DiagCount("KAMPF", "Beginn · Modus " .. ns:ThreatMode() .. " · Bedrohung " .. tostring(ns.threatAccess)) end
end)
