-- LevelPilot - Core
-- Namespace, gespeicherte Daten, Event-Verteiler, Hilfsfunktionen
-- Copyright (c) 2026 GoldSentinel. Alle Rechte vorbehalten.

local ADDON, LP = ...
LevelPilot = LP

LP.version = "3.12.45"
LP.ADDON   = ADDON

------------------------------------------------------------------------
-- Design: Graphit mit Bernstein- und Smaragd-Akzent
------------------------------------------------------------------------
LP.colors = {
    accent   = { 1.00, 0.70, 0.22 },             -- Bernstein
    accent2  = { 0.24, 0.84, 0.58 },             -- Smaragd
    bg       = { 0.065, 0.072, 0.082, 0.93 },
    panel    = { 0.095, 0.105, 0.120, 0.97 },
    row      = { 0.125, 0.137, 0.155, 0.92 },
    rowCur   = { 0.180, 0.160, 0.110, 0.97 },
    border   = { 0.230, 0.245, 0.270, 1.00 },
    text     = { 0.94, 0.93, 0.90 },
    muted    = { 0.62, 0.63, 0.66 },
    done     = { 0.30, 0.86, 0.50 },
    warn     = { 1.00, 0.55, 0.20 },
    bad      = { 1.00, 0.30, 0.30 },
    alliance = { 0.30, 0.56, 1.00 },
    horde    = { 0.90, 0.26, 0.22 },
    path     = { 1.00, 0.76, 0.28 },
    pathNew  = { 0.70, 0.72, 0.78 },
}
LP.FONT = "Fonts\\FRIZQT__.TTF"

------------------------------------------------------------------------
-- Standardwerte
------------------------------------------------------------------------
local DEFAULTS = {
    forever         = true,    -- Regeln von WoW Forever (Questlog 40, Dungeon-EP); aus = normaler Classic-Server
    protocol        = true,    -- Fehler-Protokoll fuer Tester (bleibt lokal)
    wegeAuto        = true,    -- 3.12.12: Wegdaten (ohne Namen) beim Ausloggen fuer die Pruefung bereitlegen (GSWEGE1)
    -- Automatik
    autoAccept      = true,
    autoTurnin      = true,
    usePack         = true,
    useQuestie      = true,
    language        = "auto",  -- "auto" (Spielsprache) oder de/en/fr/es/mx/pt/it/ru/ko/cn/tw
    autoSellGrey    = true,    -- graue Gegenstaende beim Haendler verkaufen
    -- Aktionen mit echten Folgen (Entscheid des Nutzers 3.12.5): Reparieren und Auto-Flug ab Werk an, Nachkaufen und
    -- Belohnung anlegen ab Werk aus (das Addon weist einmal darauf hin). Bestehende Einstellungen bleiben, wie sie sind.
    autoRepair      = true,    -- beim Haendler automatisch reparieren (ab Werk an – Entscheid des Nutzers 3.12.5)
    autoFly         = true,    -- beim Flugmeister direkt zum geplanten Ziel fliegen (ab Werk an – Entscheid des Nutzers 3.12.5)
    useHearth       = true,    -- Ruhestein einplanen (binden und benutzen)
    safeMode        = false,   -- Sicherer Modus: Elite und deutlich hoehere Gegner meiden, warnen
    groupSync       = true,    -- Fortschritt mit der Gruppe teilen und anzeigen
    showTimer       = true,    -- EP pro Stunde und Zeit bis zum naechsten Level anzeigen
    showNewTag      = true,    -- neue WoW-Forever-Quests markieren
    showActionBar   = true,    -- Knoepfe "Ziel anvisieren" und "Questgegenstand"
    platesQuest     = true,    -- Questfortschritt ueber den Namensplaketten der Gegner
    -- Karten & Questgegenstaende
    mapAreas        = true,    -- Questgebiete auf Minikarte und Weltkarte
    mapAvailable    = true,    -- "!" fuer annehmbare Quests
    objPins         = true,    -- Fundstellen von Questgegenstaenden
    objArrow        = true,    -- Pfeil zur naechsten Fundstelle
    objAlert        = true,    -- Hinweis "Questgegenstand in der Naehe"
    tooltips        = true,    -- Tooltip-Hinweise bei Gegnern, Gegenstaenden, Objekten
    -- Vorraete & Taschen
    restock         = false,   -- beim Haendler nachkaufen (ab Werk aus, Hinweis beim Haendler – 3.12.5)
    restockFood     = true,
    restockWater    = true,
    restockWaterMage = false,  -- Magier zaubern Wasser selbst
    restockAmmo     = true,
    restockPetFood  = true,
    foodAmount      = 20,
    waterAmount     = 20,
    ammoAmount      = 1000,
    petFoodAmount   = 20,
    restockMaxPct   = 25,      -- hoechstens so viel Prozent des Goldes je Einkauf
    autoEquipRewards = false,  -- Questbelohnung anlegen, wenn sie ein Upgrade ist (ab Werk aus, Hinweis bei Upgrade – 3.12.5)
    bagCleanup      = true,    -- Hinweis: Gegenstaende ohne Nutzen
    -- Zeit & Sitzung
    showEta         = true,    -- Zeit-Schaetzung je Ziel und Zone
    showRested      = true,    -- Erholt-Bonus anzeigen
    showHearthCD    = true,    -- Ruhestein-Abklingzeit anzeigen
    welcomeSummary  = true,    -- "Wo war ich?" beim Einloggen
    turninReminder  = true,    -- Hinweis bei offenen Abgaben beim Verlassen einer Zone
    logoutSummary   = true,    -- Bilanz beim Ausloggen
    summaryGuild    = false,   -- Bilanz auch in den Gildenchat
    -- Hinweise
    hintClassQuests = true,
    hintClass       = true,
    hintTrainer     = true,
    hintMount       = true,
    mountGold       = 100,     -- Gold fuer Reitlehre + Reittier auf Level 40
    hintProfessions = true,
    -- Gruppe
    groupFinderText = true,    -- Text fuer die Gruppensuche anbieten
    findPartners    = true,    -- LevelPilot-Spieler mit derselben Elite-Quest finden
    -- Anzeige
    compactMode     = false,   -- Guide als eine einzige Zeile
    platesAll       = false,   -- ... fuer alle offenen Quests im Log (sonst nur der aktuelle Schritt)
    dungeons        = true,    -- Dungeon-Quests einplanen
    dungeonMin      = 2,       -- Dungeon-Lauf ab so vielen Quests im Log
    dungeonMobXP    = 0,       -- Monster-EP in Dungeons in % (0 = automatisch: Forever 36 % vorlaeufig bzw. gemessen, Classic 100 %)
    dungeonQuestXP  = 0,       -- EP von Dungeon-Quests in % (0 = automatisch: Forever 150 % vorlaeufig, Classic 100 %)
    speedLevel      = 2,       -- Speedrun-Strenge: 1 locker, 2 mittel, 3 streng (3.10: Standard mittel)
    questLogMax     = 0,       -- Questlog-Groesse (0 = automatisch: Forever 40, Classic 20)
    -- Anzeige
    showArrow       = true,
    showMinimapPath = true,
    showMapPath     = true,
    terrainPath     = true,    -- Wegfuehrung dem Gelaende anpassen (Gelaendekarte aus dem Datenpaket)
    showMinimapBtn  = true,
    locked          = false,
    scale           = 1.0,
    stepsShown      = 5,
    minimapAngle    = 200,
    framePos        = false,
    frameW          = nil,     -- Breite des Guide-Fensters (nil = Standard)
    frameH          = nil,     -- feste Hoehe (nil = automatisch nach Inhalt)
    arrowPos        = false,
    centerPos       = false,
    -- Aufzeichnung & Austausch
    recordPaths     = true,
    recordQuests    = true,
    shareGroup      = true,
    shareGuild      = true,
    shareChannel    = true,
    shareSeed       = false,   -- eigene Daten fuer die Startdatenbank freigeben (wird einmal gefragt)
    shareSeedAsked  = false,
    -- Assistent
    advDurability   = true,
    advBags         = true,
    advUpgrades     = true,
    advAmmo         = true,
    advTalents      = true,
    advTrainer      = true,
    advRested       = true,    -- 3.12.39 LP-N1: Pause ausserhalb des Gasthauses (Erholt-Bonus)
    advWeapon       = true,    -- 3.12.39 LP-N1: Waffenfertigkeit der angelegten Waffe niedrig
    advGrind        = true,    -- 3.12.41 LP-N1 3: Stelle abgegrast -> andere Stelle anbieten
    durWarn         = 30,
    bagWarn         = 3,
    ammoWarn        = 200,
    cmdHint         = true,    -- 3.12.27: Befehlsliste beim Tippen von /lp
    messages        = true,    -- 3.12.31 ML1: Schalter "Meldungen" (aus = LevelPilot meldet nichts von selbst)
    cmdUse          = {},      -- 3.12.27: wie oft welcher Befehl benutzt wurde (Reihenfolge der Liste)
    marktTeilen     = true,    -- 3.12.28 MN2: Marktdaten teilen (GoldSentinelMarkt, anonym, nur Preise)
    -- Datenbestaende (werden von den Modulen gefuellt)
    qdb      = {},   -- aufgezeichnete Quests [id] = {...}
    graph    = {},   -- Wegenetz
    vendors  = {},   -- bekannte Haendler/Reparatur/Gasthaus
    taxi     = {},   -- Flugpunkte (Ort, accountweit)
    wegeSent = {},   -- 3.12.12: was schon als GSWEGE1 bereitgelegt wurde
    festLog  = {},   -- 3.12.12: FEST-Ereignisse { map, x, y, t, blocked } (7 Tage)
    npcPos   = {},   -- 3.12.11: echte Orte von Questgebern [NPC-ID] = { Karte, x, y, t = Zeit, o = { Karte, x, y } (Datenpaket) }
    net      = {},   -- Statistik Austausch
}

local CHAR_DEFAULTS = {
    ignored   = {},    -- [questID] = true (vom Spieler uebersprungen)
    notOffered = {},   -- [questID] = Zeitpunkt (NPC bot die Quest nicht an)
    doneKeys  = {},    -- manuell erledigte Schritte [key] = true
    focusZone = false, -- manuell gewaehlte Zone (uiMapID) oder false = automatisch
    turnedIn  = {},    -- [questID] = true
    taxiKnown = {},    -- [Flugpunkt] = true (dieser Charakter kennt ihn)
    fpVisited = {},    -- ["Flugmeister:Karte"] = true (Flugpunkt bereits geholt)
    dungeonRun = {},   -- [Dungeon-AreaID] = Level beim letzten Lauf / Zurueckstellen
    inDungeon = false, -- AreaID des Dungeons, in dem man gerade ist
    mode      = "normal", -- "normal" oder "speed" (Speedrun auf 60)
    bind      = false,    -- Bindeort des Ruhesteins { map, x, y, name }
    levelTimes = {},      -- [Level] = Spielzeit in Sekunden fuer dieses Level
    trainerLevel = 0,
    collapsed = false,
    hidden    = false,
    lastHints = {},
    optHints  = {},       -- einmalige Hinweise auf ausgeschaltete Optionen: [restock/autoEquip] = true (gezeigt) oder Level
}

-- Schluessel, die Einstellungen sind (keine Datentabellen, keine Fensterpositionen, nicht die Sprache)
LP.SETTING_KEYS = {}

local function ApplyDefaults(target, defaults)
    for k, v in pairs(defaults) do
        if target[k] == nil then
            if type(v) == "table" then
                target[k] = {}
                ApplyDefaults(target[k], v)
            else
                target[k] = v
            end
        end
    end
end

------------------------------------------------------------------------
-- Event-Verteiler
------------------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
LP.eventFrame = eventFrame
LP.handlers = {}

function LP:On(event, fn)
    if not self.handlers[event] then
        self.handlers[event] = {}
        eventFrame:RegisterEvent(event)
    end
    table.insert(self.handlers[event], fn)
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
    local list = LP.handlers[event]
    if not list then return end
    for i = 1, #list do
        local ok, err = pcall(list[i], event, ...)
        if not ok then LP:Error(event, err) end
    end
end)

-- Interne Nachrichten zwischen Modulen
LP.callbacks = {}
function LP:Listen(msg, fn)
    self.callbacks[msg] = self.callbacks[msg] or {}
    table.insert(self.callbacks[msg], fn)
end
function LP:Fire(msg, ...)
    local list = self.callbacks[msg]
    if not list then return end
    for i = 1, #list do
        local ok, err = pcall(list[i], ...)
        if not ok then
            LP:Debug(LP.L["Fehler in "] .. msg .. ": " .. tostring(err))
            LP.errorCount = (LP.errorCount or 0) + 1
            LP.Report("Fire " .. tostring(msg), err)
        end
    end
end

------------------------------------------------------------------------
-- Hilfsfunktionen
------------------------------------------------------------------------
-- 3.12.31 ML1: EINE Weiche fuer alle Meldungen. Schalter "Meldungen" (LP.db.messages, Standard an).
--   LP:Print(msg)        = ungefragter Hinweis (Chat)            -> bei AUS unterdrueckt
--   LP:Reply(msg)        = Antwort auf eine eigene Handlung      -> immer (Ausnahmen 1 und 2 des Auftrags)
--   LP:Screen(msg, …)    = Meldung in der Bildschirmmitte (+Ton) -> bei AUS unterdrueckt
--   LP.UI:Toast, Advisor-Hinweise: pruefen LP:MessagesOn()
-- Alles, was waehrend eines /lp-Befehls ausgegeben wird, gilt als Antwort (LP:AsReply).
-- Ausgabe nur ueber LP.out (die Testroutine setzt eine eigene Tabelle ein und zaehlt mit).
-- LP.sink = die echte Ausgabe (die Testroutine setzt eine eigene Tabelle ein und zaehlt mit).
-- LP.out  = einziger Weg zur Ausgabe; zaehlt "durchgerutscht", wenn bei AUS etwas ausser einer Antwort hinausgeht
--           (z. B. ein Aufruf, der die Weiche umgeht).
LP.sink = {
    chat = function(t) if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(t) end end,
    screen = function(t, r, g, b) if UIErrorsFrame and UIErrorsFrame.AddMessage then UIErrorsFrame:AddMessage(t, r, g, b) end end,
    sound = function(id) if PlaySound and id then pcall(PlaySound, id) end end,
}
LP.msgStats = { suppressed = 0, leaked = 0 }
local replyDepth = 0

function LP:MessagesOn() return not (LP.db and LP.db.messages == false) end
function LP:InReply() return replyDepth > 0 end

local function Out(kind)
    return function(...)
        if not LP:MessagesOn() and replyDepth == 0 then LP.msgStats.leaked = LP.msgStats.leaked + 1 end
        return LP.sink[kind](...)
    end
end
LP.out = { chat = Out("chat"), screen = Out("screen"), sound = Out("sound") }

-- fn als Antwort auf eine Handlung des Spielers ausfuehren (Befehl, Klick); Fehler werden weitergereicht
function LP:AsReply(fn, ...)
    replyDepth = replyDepth + 1
    local r = { pcall(fn, ...) }
    replyDepth = replyDepth - 1
    if not r[1] then error(r[2], 0) end
    return unpack(r, 2)
end

local function Emit(kind, ...) LP.out[kind](...) end

function LP:Print(msg)
    if not self:MessagesOn() and replyDepth == 0 then
        LP.msgStats.suppressed = LP.msgStats.suppressed + 1
        return
    end
    Emit("chat", LP.L["|cffffb238Level|r|cff3dd694Pilot|r: "] .. tostring(msg))
end

-- Antwort auf eine eigene Handlung des Spielers (Befehl, Klick, Fehler darauf): immer sichtbar
function LP:Reply(msg)
    replyDepth = replyDepth + 1
    local ok, err = pcall(LP.out.chat, LP.L["|cffffb238Level|r|cff3dd694Pilot|r: "] .. tostring(msg))
    replyDepth = replyDepth - 1
    if not ok then error(err, 0) end
end

-- Zeile ohne Vorsatz (z. B. Diagnose-Liste) als Antwort
function LP:ReplyRaw(msg)
    replyDepth = replyDepth + 1
    local ok, err = pcall(LP.out.chat, tostring(msg))
    replyDepth = replyDepth - 1
    if not ok then error(err, 0) end
end

-- ungefragte Meldung in der Bildschirmmitte, optional mit Ton
function LP:Screen(msg, r, g, b, sound)
    if not self:MessagesOn() and replyDepth == 0 then
        LP.msgStats.suppressed = LP.msgStats.suppressed + 1
        return false
    end
    Emit("screen", msg, r, g, b)
    if sound then Emit("sound", sound) end
    return true
end

-- Zeile fuer Testbericht und Diagnose (ML1)
-- 3.12.33 ML1-2: ueber die Sprachtabelle (erscheint in /lp diag und im Testbericht)
function LP:MessagesLine()
    local L = LP.L
    return L("MELDUNGEN: %s · unterdrückt %d · durchgerutscht %d", self:MessagesOn() and L["an"] or L["aus"],
        LP.msgStats.suppressed, LP.msgStats.leaked)
end

------------------------------------------------------------------------
-- Testmodus (virtuelle Reise, Selbsttest mit Reise, Debug): nur fuer GoldSentinel.
-- Erkannt am BattleTag (gespeichert nur als Pruefsumme, nicht als Klartext). Liefert das Spiel keinen BattleTag
-- (Battle.net nicht verfuegbar), gilt die Liste der Charaktere als Ersatz.
-- Hinweis: Addons sind offener Code - das ist keine Sicherung, sondern haelt die Bedienung fuer alle anderen
-- uebersichtlich.
------------------------------------------------------------------------
local DEV_TAGS = { [1913314458] = true }
-- 3.12.20: Entwickler-Charakter nur als Prüfsumme (keine Spielernamen im öffentlichen Repo)
local DEV_CHARS = { [212689612] = true }
local function TagHash(tag)
    local t = tag:gsub("%s", ""):lower()
    local h = 5381
    for i = 1, #t do h = (h * 33 + t:byte(i)) % 4294967296 end
    return h
end
LP.TagHash = TagHash
function LP:IsDev()
    if self._dev then return true end
    local ok, tagSeen = false, false
    if BNGetInfo then
        local okc, _, tag = pcall(BNGetInfo)
        if okc and type(tag) == "string" and tag ~= "" then
            tagSeen = true
            ok = DEV_TAGS[TagHash(tag)] or false
        end
    end
    if not ok and not tagSeen then
        local n = LP.SafeValue(UnitName("player"))
        ok = type(n) == "string" and DEV_CHARS[TagHash(n)] or false
    end
    self.devTagSeen = tagSeen
    if ok then self._dev = true end          -- nur das Ja merken (Battle.net kann spaeter bereit sein)
    return ok and true or false
end
function LP:DevOnly()
    if self:IsDev() then return true end
    self:Reply(self.L["Diese Funktion gehört zum Testmodus und ist nur für den Entwickler freigeschaltet."])
    return false
end

-- Spielversion und geschuetzte Werte: gemeinsame Erkennung aller GoldSentinel-Addons (GoldSentinelGame.lua)
LP.Game = _G.GoldSentinelGame
-- Wert, der im Kampf geschuetzt sein kann ("secret value", moderner Client): nil statt eines Wertes, mit dem man
-- nicht rechnen, vergleichen oder verketten darf. Ohne GoldSentinelGame: unveraendert.
function LP.SafeValue(v)
    local G = LP.Game
    if G then return G.Safe(v) end
    return v
end
-- gleicher Charakter? (Forever: Vor- und Nachname; ohne GoldSentinelGame: Name ohne Realm wie bisher)
function LP.SameName(a, b)
    local G = LP.Game
    if G then return G.SameName(a, b) end
    local sa = type(a) == "string" and (a:match("^([^%-]+)") or a)
    local sb = type(b) == "string" and (b:match("^([^%-]+)") or b)
    return sa ~= nil and sa == sb
end

LP.debug = false
function LP:Debug(msg)
    if LP.debug then self:Reply("|cff888888" .. tostring(msg) .. "|r") end     -- nur nach /lp debug (eigener Befehl)
end

function LP:PlayerFaction()
    return UnitFactionGroup("player") == "Horde" and "Horde" or "Alliance"
end

function LP:Now()
    return time()
end

-- Bit-Test ohne 32-Bit-Grenze (Skyborne-Masken haben Bit 32/33)
function LP.HasBit(mask, bitValue)
    if not mask or mask == 0 or not bitValue or bitValue == 0 then return false end
    return math.floor(mask / bitValue) % 2 == 1
end

-- Fehler an GoldSentinelTest melden (Testberichte); nie Namen oder Inhalte, nur Ort und Lua-Meldung
function LP.Report(where, err)
    local GT = _G.GoldSentinelTest
    if GT and GT.Error and LP.trackingErrors then pcall(GT.Error, "LevelPilot", tostring(where), tostring(err)) end
end

-- pcall mit Meldung an GoldSentinelTest (3.12.6): fuer Stellen, die bisher still abgefangen haben
function LP.Try(where, fn, ...)
    local r = { pcall(fn, ...) }
    if not r[1] then LP.Report(where, r[2]) end
    return unpack(r, 1, table.maxn(r))
end

-- Fehler sichtbar melden (jede Meldung nur einmal pro Sitzung); gezaehlt und gemeldet wird jeder Aufruf
LP.errors = {}
LP.errorCount = 0
function LP:Error(where, err)
    local msg = tostring(err)
    where = tostring(where)
    self.lastError = where .. ": " .. msg
    self.errorCount = (self.errorCount or 0) + 1
    LP.Report(where, msg)
    if self.errors[msg] then return end
    self.errors[msg] = true
    self:Print(LP.L["|cffff5555Fehler in "] .. where .. ":|r " .. msg)
    self:Print(LP.L["Bitte diese Meldung an den Autor schicken. /lp diag zeigt weitere Infos."])
end

function LP:Safe(where, fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok then self:Error(where, err) end
    return ok
end

-- Gedrosselter Aufruf: fn hoechstens alle "delay" Sekunden
-- Generation (Testroutine): Rueckrufe aus einer frueheren Generation werden verworfen
LP.testGen = 0
function LP:Throttle(key, delay, fn)
    self._throttle = self._throttle or {}
    local t = self._throttle[key]
    if t then t.pending = true return end
    local gen = LP.testGen
    self._throttle[key] = { pending = false }
    C_Timer.After(delay, function()
        local entry = self._throttle[key]
        self._throttle[key] = nil
        if gen ~= LP.testGen then return end
        LP:Safe(key, fn)
        if entry and entry.pending then self:Throttle(key, delay, fn) end
    end)
    LP:Safe(key, fn)
end

-- Wiederkehrender Zeitgeber, immer geschuetzt (ein Fehler wiederholt sich nicht jede Sekunde als Lua-Fehler)
LP.tickers = {}
function LP:Ticker(name, interval, fn)
    local t = C_Timer.NewTicker(interval, function() LP:Safe(name, fn) end)
    self.tickers[#self.tickers + 1] = { name = name, interval = interval, fn = fn, ticker = t }
    return t
end

-- Kampf? Eigene Funktion, damit die Testroutine die Kampfsperre ohne Eingriff ins Spiel umschalten kann
function LP:InCombat()
    if self.testCombat ~= nil then return self.testCombat and true or false end
    if InCombatLockdown and InCombatLockdown() then return true end
    if UnitAffectingCombat and LP.SafeValue(UnitAffectingCombat("player")) then return true end
    return false
end

-- Lange Rechnungen in Haeppchen: innerhalb der Coroutine der virtuellen Reise kurz an das Spiel abgeben,
-- wenn das Zeitbudget dieses Bildes verbraucht ist ("script ran too long" vermeiden).
-- Nur an Stellen, die sicher nicht in einem pcall laufen (kind = "plan" oder "graph", vom Aufrufer freigegeben).
function LP:Yield(kind)
    -- 3.12.24: Arbeit in Portionen (LP.Jobs) gibt nach dem Budget dieses Bildes ab
    if LP.Jobs and LP.Jobs.Current() then LP.Jobs.Yield(kind) return end
    local co = self.yieldCo
    if not co or not self.yieldOK or not self.yieldOK[kind] then return end
    if coroutine.running() ~= co or not debugprofilestop then return end
    if debugprofilestop() - (self.sliceStart or 0) > (self.sliceBudget or 12) then
        local t = debugprofilestop()
        coroutine.yield()
        self.yieldPaused = (self.yieldPaused or 0) + (debugprofilestop() - t)   -- Pausenzeit nicht als Rechenzeit zaehlen
    end
end

-- Zonennamen vergleichen: Karte und Spiel schreiben manche Namen verschieden ("Das Brachland" / "Brachland",
-- "The Barrens" / "Barrens"). Gleich, wenn einer im anderen als ganzes Wort steckt.
function LP:SameZoneName(a, b)
    if not a or not b then return true end
    local function norm(s) return (" " .. s:lower():gsub("[%p]", " "):gsub("%s+", " ") .. " ") end
    local x, y = norm(a), norm(b)
    return x == y or x:find(y, 1, true) ~= nil or y:find(x, 1, true) ~= nil
end

-- Level fuer Planung und Anzeige: bei der virtuellen Reise das Level des gedachten Charakters
function LP:PlayerLevel()
    local v = self.Virtual
    if v and v.active and v.s then return v.s.level end
    return LP:RealLevel()
end

-- 3.12.19: echte Stufe des Spielers; geschuetzter Wert -> zuletzt gelesene Stufe (sonst 1)
function LP:RealLevel()
    local l = LP.SafeValue(UnitLevel and UnitLevel("player"))
    if type(l) == "number" and l > 0 then LP.lastLevel = l return l end
    return LP.lastLevel or 1
end

-- 3.12.19: weitere Abfragen, die im modernen Client geschuetzt sein koennten (nil = nicht lesbar)
function LP.Facing()
    local f = GetPlayerFacing and LP.SafeValue(GetPlayerFacing())
    return type(f) == "number" and f or nil
end
function LP.Indoors()
    local v = IsIndoors and LP.SafeValue(IsIndoors())
    return v ~= nil and v ~= false
end
function LP.Resting()
    local v = IsResting and LP.SafeValue(IsResting())
    return v ~= nil and v ~= false
end
function LP.UnitSpeed(unit)
    local v = GetUnitSpeed and LP.SafeValue(GetUnitSpeed(unit or "player"))
    return type(v) == "number" and v or nil
end

-- eigene EP und EP bis zum Level; geschuetzte Werte (moderner Client) -> 0 bzw. 1 (3.12.6)
function LP:PlayerXP()
    local S = LP.SafeValue
    local xp, mx = S(UnitXP and UnitXP("player")), S(UnitXPMax and UnitXPMax("player"))
    local readable = type(xp) == "number" and type(mx) == "number"
    if type(xp) ~= "number" then xp = 0 end
    if type(mx) ~= "number" or mx <= 0 then mx = 1 end
    return xp, mx, readable
end

function LP:FormatDist(yards)
    if not yards then return "?" end
    yards = math.floor(yards + 0.5)
    if yards >= 1000 then return string.format("%.1f km", yards * 0.9144 / 1000) end
    return yards .. LP.L[" Yards"]
end

------------------------------------------------------------------------
-- Initialisierung
------------------------------------------------------------------------
LP.modules = {}
function LP:RegisterModule(name, mod)
    self.modules[#self.modules + 1] = { name = name, mod = mod }
    self[name] = mod
end

-- Gespeicherte Daten laden (acc = LevelPilotDB, char = LevelPilotCharDB). Auch fuer die Testroutine mit Testtabellen
-- aufrufbar; danach dort erneut mit den echten Tabellen (ApplyDefaults fuellt nur fehlende Werte).
LP.CHAR_DEFAULTS = CHAR_DEFAULTS
LP.ApplyDefaults = ApplyDefaults
-- Beschaedigte Eintraege (falscher Typ) beim Laden ueberspringen oder ersetzen, nie benutzen (3.12.6, T129).
-- Geloescht wird nur, was ohnehin unbrauchbar ist (z. B. ein Quest-Eintrag, der keine Tabelle ist).
local function Sanitize(acc, char)
    local function tbl(t, k) if type(t[k]) ~= "table" then t[k] = nil end end
    local function onlyTables(t)
        if type(t) ~= "table" then return end
        for k, v in pairs(t) do if type(v) ~= "table" then t[k] = nil end end
    end
    local function field(e, k, kind) if e[k] ~= nil and type(e[k]) ~= kind then e[k] = nil end end
    for _, k in ipairs({ "qdb", "vendors", "taxi", "caves", "graph", "calib", "net", "protocolLog" }) do tbl(acc, k) end
    if type(acc.qdb) == "table" then
        onlyTables(acc.qdb)
        for _, e in pairs(acc.qdb) do
            field(e, "n", "string") field(e, "l", "number") field(e, "f", "string") field(e, "x", "number")
            field(e, "xl", "number") field(e, "dg", "number") field(e, "s", "table") field(e, "e", "table") field(e, "o", "table")
            field(e, "by", "number") field(e, "c", "number") field(e, "rl", "number")
        end
    end
    tbl(acc, "npcPos") tbl(acc, "wegeSent") tbl(acc, "festLog") tbl(acc, "wegeExport")
    if type(acc.festLog) == "table" then onlyTables(acc.festLog) end
    onlyTables(acc.vendors) onlyTables(acc.taxi) onlyTables(acc.caves) onlyTables(acc.npcPos)
    if type(acc.graph) == "table" then tbl(acc.graph, "nodes") tbl(acc.graph, "edges") end
    if type(acc.calib) == "table" then
        for _, k in ipairs({ "killxp", "kills", "drops", "mobs", "netDrops", "netMobs", "need" }) do tbl(acc.calib, k) end
        for _, k in ipairs({ "killxp", "kills", "drops" }) do
            local t = acc.calib[k]
            for key, v in pairs(t or {}) do
                if type(v) ~= "table" or (v.n ~= nil and type(v.n) ~= "number") or (v.sum ~= nil and type(v.sum) ~= "number")
                   or (v.k ~= nil and type(v.k) ~= "number") or (v.g ~= nil and type(v.g) ~= "number") then t[key] = nil end
            end
        end
        if type(acc.calib.dungeonxp) == "table" and (type(acc.calib.dungeonxp.n) ~= "number" or type(acc.calib.dungeonxp.sum) ~= "number") then
            acc.calib.dungeonxp = nil
        end
    end
    if type(acc.net) == "table" then tbl(acc.net, "peers") end
    if type(acc.protocolLog) == "table" then
        tbl(acc.protocolLog, "entries")
        onlyTables(acc.protocolLog.entries)
    end
    for _, k in ipairs({ "ignored", "doneKeys", "notOffered", "dungeonRun", "levelTimes", "fpVisited", "settings", "optHints" }) do tbl(char, k) end
    if type(char.levelTimes) == "table" then
        for k, v in pairs(char.levelTimes) do if type(k) ~= "number" or type(v) ~= "number" then char.levelTimes[k] = nil end end
    end
    tbl(char, "bind") tbl(char, "backup")
end
LP.Sanitize = Sanitize

function LP:LoadSaved(acc, char)
    Sanitize(acc, char)
    ApplyDefaults(acc, DEFAULTS)
    LP.DEFAULTS = DEFAULTS
    -- 3.10: Speedrun-Standard "mittel" statt "streng" (einmalig; wer danach "streng" waehlt, behaelt es)
    if not acc.speedLevelV2 then
        if acc.speedLevel == 3 then acc.speedLevel = 2 end
        acc.speedLevelV2 = true
    end
    for k, v in pairs(DEFAULTS) do
        if type(v) ~= "table" and k ~= "language" and not k:find("Pos$") then LP.SETTING_KEYS[k] = true end
    end
    ApplyDefaults(char, CHAR_DEFAULTS)
    LP.char = char
    -- Einstellungen wahlweise pro Charakter: LP.db liest/schreibt Einstellungen dann im Charakter,
    -- gesammelte Daten (Quests, Wege, ...) bleiben immer accountweit
    if type(LP.char.settings) ~= "table" then LP.char.settings = {} end
    LP.db = setmetatable({}, {
        __index = function(_, k)
            if k == "ownSettings" then return LP.char.ownSettings or false end
            if LP.SETTING_KEYS[k] and LP.char.ownSettings then
                local v = LP.char.settings[k]
                if v ~= nil then return v end
            end
            return acc[k]
        end,
        __newindex = function(_, k, v)
            if k == "ownSettings" then
                if v and not LP.char.ownSettings then
                    for key in pairs(LP.SETTING_KEYS) do LP.char.settings[key] = acc[key] end
                end
                LP.char.ownSettings = v and true or nil
                return
            end
            if LP.SETTING_KEYS[k] and LP.char.ownSettings then LP.char.settings[k] = v else acc[k] = v end
        end,
    })
    if LP.db.language ~= "auto" and not LP.LanguageInfo[LP.db.language] then LP.db.language = "auto" end
    -- gespeicherte Sprache, die dieses Spiel nicht anzeigen kann (Schrift fehlt): zurueck auf Automatisch
    if LP.db.language ~= "auto" and not LP:CanDisplay(LP.db.language) then LP.db.language = "auto" end
    LP:ResetLanguageCache()
    LP:ApplyFont()                 -- Schrift passend zur Sprache, bevor Fenster entstehen
end

-- 3.12.28 MN1/MN2: GoldSentinelMarkt anmelden und den Schalter "Marktdaten teilen" uebertragen.
-- Die Datei liest nur mit (ruft ReplicateItems nie selbst auf); ohne C_AuctionHouse tut sie nichts.
function LP:MarktAttach(db)
    local GM = GoldSentinelMarkt
    if type(GM) ~= "table" or type(GM.Attach) ~= "function" or type(db) ~= "table" then return false end
    local ok = pcall(GM.Attach, "LevelPilot", db)
    if ok then LP.marktDB = db self:MarktSync() end
    return ok
end

function LP:MarktSync()
    local GM = GoldSentinelMarkt
    if type(GM) ~= "table" or type(GM.SetShare) ~= "function" or not LP.marktDB then return end
    pcall(GM.SetShare, "LevelPilot", not (LP.db and LP.db.marktTeilen == false))
end

-- (bewusst ohne _G: die Testroutine simuliert "Datei fehlt" ueber setfenv)
-- Zeile fuer Testbericht und Diagnose (MN3): Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher
function LP:MarktLine()
    local GM = GoldSentinelMarkt
    if type(GM) ~= "table" then return "MARKT-NETZ: Datei fehlt" end
    local s = type(GM.Stats) == "function" and GM.Stats() or {}
    local ok, on = pcall(GM.IsShareOn)
    local own = LP.db and LP.db.marktTeilen ~= false
    local items = 0
    local st = GM.store
    if type(st) == "table" and type(st.f) == "table" then
        for _, f in pairs(st.f) do for _ in pairs(type(f.i) == "table" and f.i or {}) do items = items + 1 end end
    end
    local bytes = 0
    if type(st) == "table" then
        for _, f in pairs(type(st.f) == "table" and st.f or {}) do
            for _, v in pairs(type(f.i) == "table" and f.i or {}) do bytes = bytes + (type(v) == "string" and #v or 0) + 8 end
        end
        for _, l in ipairs(type(st.export) == "table" and st.export or {}) do bytes = bytes + #tostring(l) end
    end
    local apiOk = GM.api and type(GM.api.ah) == "function" and GM.api.ah() ~= nil
    return string.format("MARKT-NETZ: v%s · %s (LevelPilot %s)%s · Scans mitgelesen %d · gesendet %d · empfangen %d · Speicher %d Items, %.0f KB",
        tostring(GM.VERSION), (ok and on) and "an" or "aus", own and "an" or "aus", apiOk and "" or " · ohne AH-API",
        tonumber(s.scans) or 0, tonumber(s.sent) or 0, tonumber(s.received) or 0, items, bytes / 1024)
end

LP:On("ADDON_LOADED", function(_, name)
    if name ~= ADDON then return end
    LevelPilotDB = LevelPilotDB or {}
    LevelPilotCharDB = LevelPilotCharDB or {}
    LP:LoadSaved(LevelPilotDB, LevelPilotCharDB)
    -- Testberichte und Lua-Fehler (GoldSentinelTest): immer die echte Tabelle, nie den Proxy LP.db; nur einmal
    -- 3.12.28 MN1: gemeinsames Marktdaten-Netz (fehlt die Datei oder die AH-API, bleibt es still aus)
    LP:MarktAttach(LevelPilotDB)
    if _G.GoldSentinelTest and _G.GoldSentinelTest.TrackErrors then
        LP.trackingErrors = _G.GoldSentinelTest.TrackErrors("LevelPilot", LP.version, LevelPilotDB) and true or false
    end
end)

LP:On("PLAYER_LOGIN", function()
    if LP.Perf then LP.Perf.loginT = GetTime() end
    for _, m in ipairs(LP.modules) do
        if m.mod.Init then
            local t0 = LP.Perf and LP.Perf.clock()
            local ok, err = pcall(m.mod.Init, m.mod)
            if t0 then LP.Perf.Add("start", LP.Perf.clock() - t0) end
            if not ok then
                LP:Print(LP.L["|cffff5555Modul "] .. m.name .. LP.L[" konnte nicht starten:|r "] .. tostring(err))
                if LP.Protocol then pcall(LP.Protocol.Add, LP.Protocol, "error", "Init " .. m.name .. ": " .. tostring(err)) end
                LP.initErrors = LP.initErrors or {}
                LP.initErrors[m.name] = tostring(err)
                LP.Report("Init " .. m.name, err)
            end
        end
    end
    if LP.Perf and LP.Perf.Setup then LP.Try("Zeitmessung", LP.Perf.Setup) end
    LP:Print("v" .. LP.version .. LP.L[" geladen. Linksklick auf den Minimap-Button = Guide, Rechtsklick = Zentrale."])
    LP:Fire("READY")
end)

------------------------------------------------------------------------
-- Slash-Befehle (optional, alles geht auch per Maus)
------------------------------------------------------------------------
-- Sprache einstellen ("auto" oder ein Kuerzel aus LP.LANGUAGES); voll wirksam nach /reload
function LP:SetLanguage(code)
    code = code and code:lower()
    if code ~= "auto" then
        local found
        for _, l in ipairs(LP.LANGUAGES) do
            if l.code == code then found = l.code end
            for _, loc in ipairs(l.locales) do if loc:lower() == code then found = l.code end end
        end
        code = found
    end
    if not code then
        -- nur Sprachen, die das Spiel anzeigen kann (wie in der Zentrale)
        local list = { "auto" }
        for _, l in ipairs(LP.LANGUAGES) do if LP:CanDisplay(l.code) then list[#list + 1] = l.code end end
        local cur = LP.db.language or "auto"
        local info = LP.LanguageInfo and LP.LanguageInfo[LP:Language()]
        LP:Print(LP.L("Sprache: %s (%s). Ändern mit /lp lang <Kürzel>: %s", cur == "auto" and LP.L["Automatisch"] or cur,
            info and info.name or LP:Language(), table.concat(list, ", ")))
        return false
    end
    if not LP:CanDisplay(code) then
        LP:Print(LP.L("%s kann dein Spiel nicht anzeigen – die Schrift dafür fehlt.", LP.LanguageInfo[code].name))
        return false
    end
    local oldLang = LP:Language()
    LP.db.language = code
    LP:ResetLanguageCache()
    LP:ApplyFont()
    local info = LP.LanguageInfo[LP:Language()]
    LP:Reply(LP.L("Sprache: %s", code == "auto" and (LP.L["Automatisch"] .. " – " .. info.name) or info.name))
    -- alles sofort umstellen: feste Beschriftungen, Guide, Zentrale, Hinweise
    if LP.Names and LP.Names.LanguageChanged then pcall(LP.Names.LanguageChanged, LP.Names) end
    if LP.QuestDB and LP.QuestDB.RefreshTexts then pcall(LP.QuestDB.RefreshTexts, LP.QuestDB) end
    if LP.UI and LP.UI.ClearToasts then pcall(LP.UI.ClearToasts, LP.UI) end
    if LP.UI and LP.UI.Relabel then pcall(LP.UI.Relabel, LP.UI, oldLang) end
    if LP.Planner and LP.Planner.Replan then pcall(LP.Planner.Replan, LP.Planner) end   -- Schritt-Texte neu
    if LP.Advisor and LP.Advisor.Run then pcall(LP.Advisor.Run, LP.Advisor) end
    if LP.UI and LP.UI.Refresh then pcall(LP.UI.Refresh, LP.UI) end
    local _, fontOK = LP:FontFor(LP:Language())
    if not fontOK then
        -- in der Spielsprache, damit man den Hinweis sicher lesen kann
        LP:Reply(LP.LocaleLookup(LP:ClientLanguage(), "Hinweis: Diese Sprache braucht eine Schrift, die dein Spielclient eventuell nicht hat. Fehlen Zeichen, stelle wieder \"Automatisch\" ein."))
    end
    if LP.Center and LP.Center.Refresh then LP.Center:Refresh() end
    return true
end

SLASH_LEVELPILOT1 = "/lp"
SLASH_LEVELPILOT2 = "/levelpilot"
-- 3.12.27 (BL1): EINE Befehlstabelle fuer den Slash-Handler und die Befehlsliste beim Tippen (CmdHint.lua).
-- Felder: [1] deutsches Wort, [2] englisches Wort, [3] Beschreibung (Sprachtabelle), words = alle Woerter, die der
-- Handler versteht, args = Befehl nimmt einen Zusatz ("weg 45 60"), prefix = Wortanfang genuegt ("protokollleer"),
-- dev = nur fuer den Entwickler in der Liste, run(msg, rest) fuehrt aus.
local function Rest(msg) return msg:match("^%S+%s+(.+)$") end
LP.COMMANDS = {
    { "", "", "Leitfenster ein/aus", words = { "" }, run = function() LP.UI:Toggle() end },
    { "zentrale", "center", "Zentrale mit allen Einstellungen öffnen", run = function() LP.Center:Toggle() end },
    { "plan", "plan", "Route neu planen", run = function() LP.Planner:Replan(true) end },
    { "modus", "mode", "zwischen Normal und Speedrun wechseln", run = function() LP.Planner:ToggleMode() end },
    { "speed", "speedrun", "Speedrun-Modus", words = { "speed", "speedrun" }, run = function() LP.Planner:SetMode("speed") end },
    { "normal", "normal", "Normal-Modus", run = function() LP.Planner:SetMode("normal") end },
    { "zurück", "undo", "zuletzt übersprungenen Schritt zurückholen", words = { "zurück", "zurueck", "undo" },
      run = function() LP.Engine:Unignore() end },
    { "weg 45 60", "way 45 60", "Wegpunkt auf der Karte setzen (x y)", words = { "weg", "way" }, args = true,
      run = function(msg)
          local x, y = msg:match("^%a+ ([%d%.]+)[ ,]+([%d%.]+)")
          if x and LP.Comfort then LP.Comfort:SetWaypoint(tonumber(x), tonumber(y)) end
      end },
    { "suche <was>", "find <what>", "nächsten Händler, Gasthaus, Flugmeister … suchen", words = { "such", "find" }, args = true, prefix = true,
      run = function(msg) if LP.Comfort then LP.Comfort:FindNearest(Rest(msg)) end end },
    { "sprache <kürzel>", "lang <code>", "Sprache von LevelPilot (auto, de, en, fr …)", words = { "sprache", "lang" }, args = true, prefix = true,
      run = function(msg) LP:SetLanguage(msg:match("^%a+%s+(%S+)")) end },
    { "teilen", "share", "offene Quests mit der Gruppe teilen", run = function() if LP.Social then LP.Social:ShareQuests() end end },
    { "gruppe", "lfg", "Text für die Gruppensuche", words = { "gruppe", "lfg" },
      run = function() if LP.Social and not LP.Social:OpenGroupChat() then LP:Print(LP.L["Für den aktuellen Schritt wird keine Gruppe gebraucht."]) end end },
    { "bilanz", "summary", "Bilanz der Sitzung (bilanz gilde: auch in den Gildenchat)", words = { "bilanz", "summary" }, args = true, prefix = true,
      run = function(msg) if LP.Session then LP.Session:Summary(msg:find("gild") or msg:find("guild")) end end },
    { "kompakt", "compact", "Leitfenster als eine Zeile", run = function()
          LP.db.compactMode = not LP.db.compactMode
          if LP.UI then LP.UI:Refresh() end
      end },
    { "grau", "grey", "graue Gegenstände automatisch verkaufen an/aus", words = { "grau", "grey", "gray", "junk" }, run = function()
          LP.db.autoSellGrey = not LP.db.autoSellGrey
          LP:Print(LP.L("Graue Gegenstände automatisch verkaufen: %s", LP.db.autoSellGrey and LP.L["an"] or LP.L["aus"]))
      end },
    { "wege", "ways", "gelernte Wege anzeigen und zum Einsenden bereitlegen", words = { "wege", "ways" }, args = true, prefix = true,
      run = function(msg) LP.Graph:ShowWege(msg:match("^%a+%s+(.+)$")) end },
    { "protokoll", "log", "Diagnose-Protokoll (protokoll leer: löschen)", words = { "protokoll", "log" }, args = true, prefix = true,
      run = function(msg) if msg:find("leer") or msg:find("clear") then LP.Protocol:Clear() else LP.Protocol:Show() end end },
    { "diag", "diagnose", "Diagnose der Route", words = { "diag", "diagnose" }, run = function() LP.Planner:Diagnose() end },
    { "sync test", "sync test", "wer antwortet im Austausch? (Gilde, Gruppe)", words = { "sync test", "sync" },
      run = function() LP.Comm:SyncTest() end },
    { "messen", "measure", "Messwerte anzeigen", run = function() LP.Measure:Show() end },
    { "clienttest", "clienttest", "geführter Test der neuen Funktionen im Spiel", words = { "clienttest", "client" },
      run = function() LP.ClientTest:Start() end },
    { "test", "selftest", "Selbsttest", words = { "test", "selbsttest", "selftest" }, run = function() LP.SelfTest:Show(false) end },
    { "spenden", "donate", "LevelPilot unterstützen", words = { "spenden", "donate", "support" }, run = function() LP.Donate.Show() end },
    { "reset", "reset", "Fensterpositionen zurücksetzen (lädt neu)", run = function()
          LP.db.framePos, LP.db.arrowPos, LP.db.centerPos = false, false, false
          LP.Act.Call("ReloadUI", ReloadUI)
      end },
    -- Entwickler (Testmodus)
    { "testroutine", "testroutine", "Testroutine (testroutine a … k, lang)", words = { "testroutine", "testroutinen" }, args = true,
      prefix = true, dev = true,
      run = function(msg) if LP.TestRoutine then LP.TestRoutine:Command(msg:match("^%a+%s+(.+)$")) end end },
    { "test reise", "test journey", "Selbsttest mit virtueller Reise", words = { "test reise", "test journey" }, dev = true,
      run = function() if LP:DevOnly() then LP.SelfTest:Show(true) end end },
    { "reise", "journey", "virtuelle Reise (reise hier, zuschauen, vergleich, bericht, stopp)", words = { "reise", "journey" },
      args = true, prefix = true, dev = true,
      run = function(msg)
          local arg = msg:match("^%a+%s+(%a+)")
          local stop = arg == "stop" or arg == "stopp"
          if not stop and not LP.Virtual.active and not LP:DevOnly() then return end   -- Testmodus (Anhalten geht immer)
          if stop then LP.Virtual:Stop()
          elseif arg == "vergleich" or arg == "vergleichen" or arg == "compare" then
              if not LP.Virtual:CompareModes() then LP.Virtual:ShowWindow() end
          elseif arg == "bericht" or arg == "report" then
              LP.Backup:ShowText(LP.L["Virtuelle Reise – Bericht"], LP.L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."],
                  LP.Virtual.active and LP.Virtual:Report("running") or (LP.Virtual.lastReport or LP.Virtual:Report()))
          elseif LP.Virtual.active then LP.Virtual:ShowWindow()
          else LP.Virtual:Start((arg == "hier" or arg == "here") and "here" or "start", { watch = (arg == "zuschauen" or arg == "watch") }) end
      end },
    { "debug", "debug", "Debug-Ausgaben an/aus", dev = true, run = function()
          if not LP:DevOnly() then return end
          LP.debug = not LP.debug
          LP:Print(LP.L["Debug "] .. (LP.debug and LP.L["an"] or LP.L["aus"]))
      end },
}

-- Wort -> Eintrag. Genaues Wort zuerst (auch zweiteilige wie "test reise", "sync test"), dann Befehle mit Zusatz
-- (Wort + Leerzeichen), dann Wortanfang (prefix). Rueckgabe: Eintrag oder nil (= Leitfenster)
function LP:FindCommand(msg)
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local function words(c) return c.words or { c[1], c[2] } end
    for _, c in ipairs(LP.COMMANDS) do
        for _, w in ipairs(words(c)) do if msg == w then return c end end
    end
    local best, bestLen
    for _, c in ipairs(LP.COMMANDS) do
        for _, w in ipairs(words(c)) do
            if w ~= "" and (c.args and msg:sub(1, #w + 1) == w .. " " or c.prefix and msg:sub(1, #w) == w) then
                if not bestLen or #w > bestLen then best, bestLen = c, #w end
            end
        end
    end
    return best
end

SlashCmdList["LEVELPILOT"] = function(msg)
    -- BL3: frische Auswahl aus der Befehlsliste (Klick, dann Enter) statt des unvollstaendigen Worts
    if LP.CmdHint and LP.CmdHint.Resolve then msg = LP.CmdHint:Resolve(msg) end
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local c = LP:FindCommand(msg) or LP.COMMANDS[1]
    if LP.CmdHint and LP.CmdHint.Count then pcall(LP.CmdHint.Count, LP.CmdHint, msg) end
    LP:AsReply(c.run, msg)     -- 3.12.31 ML1: Ausgaben eines Befehls sind Antworten (auch bei "Meldungen" aus)
end
