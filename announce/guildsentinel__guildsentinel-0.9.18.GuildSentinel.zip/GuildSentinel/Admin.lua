-- GuildSentinel - Admin.lua
-- Fenster "Gildenverwaltung" (anweisung-gildenverwaltung.txt, Wunsch des Nutzers 9. Nov. 2026)
--
-- Zugang: Knopf "Verwaltung (GuildSentinel)" neben Blizzards Gildenfenster (Taste J bleibt unverändert) und
-- /gs verwaltung. Der Knopf ist ein eigener Frame (Eltern UIParent), nur an das Blizzard-Fenster geankert; am
-- Blizzard-Fenster wird nichts ersetzt, nur HookScript (OnShow/OnHide). Load-on-demand-Fenster (Communities) werden
-- beim Laden ihres Addons angehängt.
--
-- Berechtigung: nach den Rechten im Spiel (über ns.API): Gildenmeister, Einladen, Befördern, Degradieren, Entfernen,
-- Offiziersnotiz bearbeiten. Jeder Knopf nur aktiv, wenn das Spiel genau dieses Recht gibt. Zusätzlich eine lokale
-- Zugriffsliste des Gildenmeisters (GuildSentinelDB.admin[Gilde].access – nur SavedVariables dieses Kontos, nie
-- gesendet, nie im Protokoll/Testbericht): Diese Charaktere sehen das Fenster; die Knöpfe folgen trotzdem den
-- Rechten im Spiel.
--
-- Aktionen: nur direkt aus dem Klick bzw. der Bestätigung (StaticPopup = Klick des Spielers), nie aus Timern,
-- nie im Kampf; alles über ns.Act (die Testroutine schreibt dort nur mit). Im Testmodus nur "[Test] …".
--
-- Passwort für "Gildenleitung übergeben": Schutz gegen versehentliche Klicks, kein echter Sicherheitsschutz (der
-- echte Schutz sind die Rechte im Spiel). Gespeichert wird nur eine Prüfsumme mit Salz (kein Klartext), nur lokal.
-- Eingabe maskiert; 3 Fehlversuche -> 5 Minuten Sperre; ändern nur mit dem alten Passwort. Nie ausgegeben.

local ADDON, ns = ...
local L = ns.L
local UI = ns.UI

local Ad = {}
ns.Admin = Ad

Ad.MAX_FAILS = 3
Ad.LOCK_SECONDS = 300
Ad.ROUNDS = 2000

local GOLD, GREEN, RED, GRAY = "|cffffd100", "|cff66dd66", "|cffff6666", "|cff9aa0a6"

------------------------------------------------------------
-- Daten (nur lokal): GuildSentinelDB.admin[guildKey] = { access = { [Name] = true }, pw = { s = Salz, h = Prüfsumme },
--                                                      fails = n, lockUntil = Zeit, showButton = true|false }
------------------------------------------------------------
function Ad.Data()
	if not GuildSentinelDB then return nil end
	-- Testmodus: nur im Speicher (die erfundene Gilde wird nie gespeichert)
	if ns.Test and ns.Test:Active() then
		Ad.testData = Ad.testData or { access = {} }
		return Ad.testData
	end
	local key = ns.guildKey
	if not key then return nil end
	GuildSentinelDB.admin = type(GuildSentinelDB.admin) == "table" and GuildSentinelDB.admin or {}
	local d = GuildSentinelDB.admin[key]
	if type(d) ~= "table" then d = {}; GuildSentinelDB.admin[key] = d end
	if type(d.access) ~= "table" then d.access = {} end
	return d
end

------------------------------------------------------------
-- Prüfsumme (zwei 32-bit-Hashes, ROUNDS Runden über Salz + Passwort; reines Lua 5.1 ohne bit-Bibliothek)
------------------------------------------------------------
local M32 = 4294967296
local function Mix(h, s, mul)
	for i = 1, #s do h = (h * mul + s:byte(i)) % M32 end
	return h
end
function Ad.Hash(salt, pw)
	local h1, h2 = 5381, 2166136261
	local s = tostring(salt) .. "\0" .. tostring(pw)
	for r = 1, Ad.ROUNDS do
		h1 = Mix(h1, s, 33)
		h2 = Mix(h2, s, 131)
		s = string.format("%08x%08x", h1, h2)
	end
	return s
end

local function NewSalt()
	local t = {}
	for i = 1, 16 do t[i] = string.format("%x", math.random(0, 15)) end
	return table.concat(t) .. string.format("%x", math.floor((time and time() or 0) % 65536))
end

function Ad.HasPassword()
	local d = Ad.Data()
	return d and type(d.pw) == "table" and type(d.pw.h) == "string" and true or false
end

-- gesperrt? Rückgabe: Sekunden bis zur Freigabe oder nil
function Ad.LockedFor()
	local d = Ad.Data()
	if not d or not d.lockUntil then return nil end
	local left = d.lockUntil - ns.Now()
	if left > 0 then return left end
	d.lockUntil, d.fails = nil, 0
	return nil
end

-- Passwort prüfen (zählt Fehlversuche). Rückgabe: true | false, Grund
function Ad.CheckPassword(pw)
	local d = Ad.Data()
	if not d then return false, "data" end
	if Ad.LockedFor() then return false, "locked" end
	if not Ad.HasPassword() then return false, "none" end
	if type(pw) == "string" and pw ~= "" and Ad.Hash(d.pw.s, pw) == d.pw.h then
		d.fails = 0
		return true
	end
	d.fails = (d.fails or 0) + 1
	if d.fails >= Ad.MAX_FAILS then d.lockUntil = ns.Now() + Ad.LOCK_SECONDS end
	return false, "wrong"
end

-- Passwort festlegen (zweimal eingegeben) bzw. ändern (dann mit dem alten). Nur der Gildenmeister.
function Ad.SetPassword(old, new1, new2)
	local d = Ad.Data()
	if not d then return false, "data" end
	if not Ad.IsLeader() then return false, "rights" end
	if type(new1) ~= "string" or #new1 < 4 then return false, "short" end
	if new1 ~= new2 then return false, "mismatch" end
	if Ad.HasPassword() then
		local ok, why = Ad.CheckPassword(old)
		if not ok then return false, why end
	end
	local salt = NewSalt()
	d.pw = { s = salt, h = Ad.Hash(salt, new1) }
	d.fails, d.lockUntil = 0, nil
	Ad.unlocked = false
	return true
end

------------------------------------------------------------
-- Rechte (über ns.API; im Testmodus alles erlaubt, die Aktionen schreiben dann nur "[Test] …")
------------------------------------------------------------
local function Right(name)
	if ns.Test and ns.Test:Active() then return true end
	local A = ns.API
	if not (A.IsInGuild and A.IsInGuild()) then return false end
	local f = A[name]
	if not f then return false end
	local ok, r = pcall(f)
	return ok and r and not ns.IsSecret(r) and true or false
end
function Ad.IsLeader() return Right("IsGuildLeader") end
function Ad.Rights()
	return {
		leader = Right("IsGuildLeader"),
		invite = Right("CanGuildInvite"),
		promote = Right("CanGuildPromote"),
		demote = Right("CanGuildDemote"),
		remove = Right("CanGuildRemove"),
		officer = Right("C_CanEditOfficerNote") or Right("CanEditOfficerNote"),
	}
end

-- darf das Fenster sehen: irgendein Recht der Gildenleitung im Spiel oder (lokal) in der Zugriffsliste
function Ad.CanOpen()
	local r = Ad.Rights()
	if r.leader or r.invite or r.promote or r.demote or r.remove or r.officer then return true end
	local d = Ad.Data()
	local me = ns.Me()
	return d and type(me) == "string" and d.access[me] == true or false
end

-- eigener Rang (0 = Gildenmeister) und Anzahl Ränge
local function MyRank()
	local e = ns.Roster.byName[ns.Me()]
	return e and e.ri
end
local function NumRanks()
	local f = ns.API.GuildControlGetNumRanks
	local ok, n = false, nil
	if f then ok, n = pcall(f) end
	if ok and type(n) == "number" and not ns.IsSecret(n) and n > 0 then return n end
	-- ohne Abfrage: aus der Liste, mindestens die 5 Ränge einer neuen Gilde (das Spiel lehnt Unmögliches selbst ab)
	local m = 5
	for _, e in ipairs(ns.Roster.list) do if (e.ri or 0) + 1 > m then m = e.ri + 1 end end
	return m
end
local function RankName(ri)
	local f = ns.API.GuildControlGetRankName
	if f then
		local ok, n = pcall(f, ri + 1)
		if ok and type(n) == "string" and n ~= "" and not ns.IsSecret(n) then return n end
	end
	for _, e in ipairs(ns.Roster.list) do if e.ri == ri and e.rank then return e.rank end end
	return "#" .. tostring(ri)
end
Ad.RankName = RankName
Ad.NumRanks = NumRanks

-- was ist mit diesem Mitglied erlaubt? (nicht über den eigenen Rang)
function Ad.Allowed(e)
	local r = Ad.Rights()
	local my = MyRank()
	local out = {}
	if not e or ns.Same(e.name, ns.Me()) then return out end
	local test = ns.Test and ns.Test:Active()
	if my == nil and test then my = 0 end
	local ri = e.ri or 99
	if my ~= nil then
		out.promote = r.promote and ri > my + 1
		out.demote = r.demote and ri > my and ri < NumRanks() - 1
		out.remove = r.remove and ri > my
	end
	out.leader = r.leader
	return out
end

------------------------------------------------------------
-- Aktionen (nur aus dem Klick; ns.Act; im Testmodus "[Test]")
------------------------------------------------------------
-- Funktion über ns.API: modern (C_GuildInfo.X) zuerst, alte als Rückfall
local function Fn(modern, old)
	local A = ns.API
	return A["C_" .. old] or A[old]
end
Ad.Fn = Fn

local function Guard(what)
	if ns.InCombat() then ns:Print(L["Im Kampf nicht möglich – bitte nach dem Kampf noch einmal."]) return false end
	if ns.Blocked(what) then return false end
	return true
end

local function Done(kind, ok)
	if ns.Diag then ns.Diag("VERWALTUNG", kind .. (ok and " ausgelöst" or " nicht möglich")) end
	if ns.GuildRoster and ok then C_Timer.After(1, function() ns.GuildRoster() end) end
end

function Ad.Invite(name)
	name = ns.Trim(name or "")
	if name == "" then return false end
	if not Ad.Rights().invite then ns:Print(L["Dein Rang darf niemanden einladen."]) Done("Einladen", false) return false end
	if not Guard(L["Einladen"] .. ": " .. name) then return false end
	local fn = Fn("Invite", "GuildInvite")
	if not fn then Done("Einladen", false) return false end
	ns.Act("GuildInvite", fn, name)
	Done("Einladen", true)
	return true
end

function Ad.Promote(e)
	if not (e and Ad.Allowed(e).promote) then Done("Befördern", false) return false end
	if not Guard(L["Befördern"] .. ": " .. e.name) then return false end
	local fn = Fn("Promote", "GuildPromote")
	if not fn then Done("Befördern", false) return false end
	ns.Act("GuildPromote", fn, e.name)
	Done("Befördern", true)
	return true
end

function Ad.Demote(e)
	if not (e and Ad.Allowed(e).demote) then Done("Degradieren", false) return false end
	if not Guard(L["Degradieren"] .. ": " .. e.name) then return false end
	local fn = Fn("Demote", "GuildDemote")
	if not fn then Done("Degradieren", false) return false end
	ns.Act("GuildDemote", fn, e.name)
	Done("Degradieren", true)
	return true
end

function Ad.Remove(e)
	if not (e and Ad.Allowed(e).remove) then Done("Entfernen", false) return false end
	if not Guard(L["Entfernen"] .. ": " .. e.name) then return false end
	local fn = Fn("Uninvite", "GuildUninvite")
	if not fn then Done("Entfernen", false) return false end
	ns.Act("GuildUninvite", fn, e.name)
	Done("Entfernen", true)
	return true
end

-- nur nach richtigem Passwort (Ad.unlocked) und nur für den Gildenmeister
function Ad.SetLeader(e)
	if not (e and Ad.Allowed(e).leader) then Done("Leitung", false) return false end
	if not Ad.unlocked then ns:Print(L["Gesperrt – erst das Passwort eingeben."]) Done("Leitung", false) return false end
	if not Guard(L["Gildenleitung übergeben"] .. ": " .. e.name) then return false end
	local fn = Fn("SetLeader", "GuildSetLeader")
	if not fn then Done("Leitung", false) return false end
	ns.Act("GuildSetLeader", fn, e.name)
	Ad.unlocked = false
	Done("Leitung", true)
	return true
end

------------------------------------------------------------
-- Fenster
------------------------------------------------------------
local function Status()
	local r = Ad.Rights()
	local parts = {}
	local function add(ok, text) parts[#parts + 1] = (ok and GREEN or GRAY) .. text .. "|r" end
	add(r.leader, L["Gildenmeister"]); add(r.invite, L["Einladen"]); add(r.promote, L["Befördern"])
	add(r.demote, L["Degradieren"]); add(r.remove, L["Entfernen"])
	return L["Deine Rechte im Spiel:"] .. " " .. table.concat(parts, " · ")
end

function Ad:Build()
	if self.frame then return self.frame end
	local f = CreateFrame("Frame", "GuildSentinelAdmin", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(720, 470)
	f:SetPoint("CENTER", 0, 30)
	f:SetFrameStrata("HIGH")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function() f:StartMoving() end)
	f:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
	UI.Box(f, 0.05, 0.06, 0.08, 0.98, 0.9, 0.7, 0.2, 0.8)
	tinsert(UISpecialFrames, "GuildSentinelAdmin")
	f:Hide()
	if ns.RegisterUI then ns.RegisterUI(f) end

	local title = UI:Label(f, L["Gildenverwaltung"], "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -14)
	local close = UI:Button(f, L["Schließen"], 90, 22, function() f:Hide() end)
	close:SetPoint("TOPRIGHT", -12, -10)
	f.rights = UI:Label(f, "", "GameFontHighlightSmall")
	f.rights:SetPoint("TOPLEFT", 16, -38)
	f.rights:SetWidth(680)
	f.rights:SetJustifyH("LEFT")

	-- Einladen
	local inv = UI:Edit(f, 200, 24, L["Name"])
	inv:SetPoint("TOPLEFT", 16, -60)
	f.invEdit = inv
	local target = UI:Button(f, L["Ziel übernehmen"], 130, 24, function()
		local n = UnitExists and UnitExists("target") and UnitIsPlayer and UnitIsPlayer("target") and UnitName("target")
		if n and not ns.IsSecret(n) then inv:SetText(n) end
	end)
	target:SetPoint("LEFT", inv, "RIGHT", 6, 0)
	f.inviteBtn = UI:Button(f, L["Einladen"], 110, 24, function()
		local n = ns.Trim(inv.edit:GetText())
		if n == "" then return end
		UI:Confirm(string.format(L["%s in die Gilde einladen?"], n), function() if Ad.Invite(n) then inv:SetText("") end end)
	end, true)
	f.inviteBtn:SetPoint("LEFT", target, "RIGHT", 6, 0)

	-- Mitgliederliste mit Suche
	local search = UI:Edit(f, 300, 24, L["Suchen"])
	search:SetPoint("TOPLEFT", 16, -94)
	search.onChange = function() Ad:Refresh() end
	f.search = search
	f.list = UI:List(f, {
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "rank", title = L["Rang"], width = 110 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "on", title = L["online"] },
	}, {
		rowH = 20,
		key = function(e) return e.name end,
		render = function(e)
			return { e.name, e.rank or "", tostring(e.level or ""), e.online and (GREEN .. L["online"] .. "|r") or GRAY .. "–|r" }
		end,
		onClick = function() Ad:RefreshSelected() end,
		empty = L["Keine Mitglieder gefunden."],
	})
	f.list:SetPoint("TOPLEFT", 16, -124)
	f.list:SetSize(390, 330)

	-- rechts: ausgewähltes Mitglied
	local right = CreateFrame("Frame", nil, f)
	right:SetPoint("TOPLEFT", f.list, "TOPRIGHT", 14, 0)
	right:SetSize(286, 330)
	f.sel = UI:Label(right, "", "GameFontNormal")
	f.sel:SetPoint("TOPLEFT", 0, 0)
	f.sel:SetWidth(286)
	f.sel:SetJustifyH("LEFT")
	f.promote = UI:Button(right, L["Befördern"], 138, 24, function()
		local e = f.list:Selected()
		if not e then return end
		UI:Confirm(string.format(L["%s befördern (%s -> %s)?"], e.name, RankName(e.ri), RankName(e.ri - 1)), function() Ad.Promote(e) end)
	end)
	f.promote:SetPoint("TOPLEFT", 0, -28)
	f.demote = UI:Button(right, L["Degradieren"], 138, 24, function()
		local e = f.list:Selected()
		if not e then return end
		UI:Confirm(string.format(L["%s degradieren (%s -> %s)?"], e.name, RankName(e.ri), RankName(e.ri + 1)), function() Ad.Demote(e) end)
	end)
	f.demote:SetPoint("LEFT", f.promote, "RIGHT", 8, 0)
	f.remove = UI:Button(right, L["Entfernen"], 284, 24, function()
		local e = f.list:Selected()
		if not e then return end
		UI:Confirm(string.format(L["Wirklich %s aus der Gilde entfernen?"], e.name), function() Ad.Remove(e) end)
	end)
	f.remove:SetPoint("TOPLEFT", f.promote, "BOTTOMLEFT", 0, -6)

	-- Gildenleitung übergeben (nur Gildenmeister, nur mit Passwort)
	local h = UI:Header(right, L["Gildenleitung übergeben"])
	h:SetPoint("TOPLEFT", f.remove, "BOTTOMLEFT", 0, -16)
	f.pw = UI:Edit(right, 180, 24, L["Passwort"])
	f.pw:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	pcall(function() f.pw.edit:SetPassword(true) end)
	f.unlock = UI:Button(right, L["Entsperren"], 98, 24, function()
		local ok, why = Ad.CheckPassword(f.pw.edit:GetText())
		f.pw:SetText("")
		Ad.unlocked = ok and true or false
		if not ok then
			if why == "locked" or Ad.LockedFor() then ns:Print(string.format(L["Zu viele Fehlversuche – gesperrt für %d Minuten."], math.ceil((Ad.LockedFor() or Ad.LOCK_SECONDS) / 60)))
			elseif why == "none" then ns:Print(L["Lege zuerst ein Passwort fest."])
			else ns:Print(L["Falsches Passwort."]) end
		end
		Ad:Refresh()
	end)
	f.unlock:SetPoint("LEFT", f.pw, "RIGHT", 6, 0)
	f.leader = UI:Button(right, L["Gildenleitung übergeben"], 284, 24, function()
		local e = f.list:Selected()
		if not e or not Ad.unlocked then return end
		UI:Confirm(string.format(L["Gildenleitung wirklich an %s übergeben? Du verlierst den Rang Gildenmeister."], e.name), function()
			-- zweite Rückfrage erst nach dem Schliessen der ersten; ausgeführt wird erst beim Klick auf "Ja" der zweiten
			C_Timer.After(0.1, function()
				UI:Confirm(string.format(L["Letzte Rückfrage: %s wird Gildenmeister. Fortfahren?"], e.name), function() Ad.SetLeader(e); Ad:Refresh() end)
			end)
		end)
	end)
	f.leader:SetPoint("TOPLEFT", f.pw, "BOTTOMLEFT", 0, -6)
	f.setPw = UI:Button(right, L["Passwort festlegen/ändern"], 284, 22, function() Ad:AskPassword() end)
	f.setPw:SetPoint("TOPLEFT", f.leader, "BOTTOMLEFT", 0, -6)

	-- lokale Zugriffsliste (nur Gildenmeister)
	local h2 = UI:Header(right, L["Zugriff (nur auf diesem Computer)"])
	h2:SetPoint("TOPLEFT", f.setPw, "BOTTOMLEFT", 0, -14)
	f.accEdit = UI:Edit(right, 180, 22, L["Name"])
	f.accEdit:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	f.accAdd = UI:Button(right, L["Hinzufügen"], 98, 22, function()
		local n = ns.Proper(ns.Trim(f.accEdit.edit:GetText()))
		local d = Ad.Data()
		if n and n ~= "" and d and Ad.IsLeader() then d.access[n] = true; f.accEdit:SetText("") end
		Ad:Refresh()
	end)
	f.accAdd:SetPoint("LEFT", f.accEdit, "RIGHT", 6, 0)
	f.accList = UI:Label(right, "", "GameFontHighlightSmall")
	f.accList:SetPoint("TOPLEFT", f.accEdit, "BOTTOMLEFT", 0, -4)
	f.accList:SetWidth(284)
	f.accList:SetJustifyH("LEFT")
	f.accDel = UI:Button(right, L["Liste leeren"], 98, 20, function()
		local d = Ad.Data()
		if d and Ad.IsLeader() then UI:Confirm(L["Zugriffsliste leeren?"], function() wipe(d.access); Ad:Refresh() end) end
	end)
	f.accDel:SetPoint("TOPRIGHT", f.accEdit, "BOTTOMRIGHT", 104, -4)

	f.showBtn = UI:Check(f, L["Verwaltungsknopf auf der Gildenseite"], function()
		local d = Ad.Data() return not d or d.showButton ~= false
	end, function(v)
		local d = Ad.Data() if d then d.showButton = v and true or false end
		Ad:UpdateButton()
	end)
	f.showBtn:SetPoint("BOTTOMLEFT", 14, 8)

	f:SetScript("OnShow", function() Ad:Refresh() end)
	f:SetScript("OnHide", function() Ad.unlocked = false end)
	self.frame = f
	return f
end

-- Passwort festlegen: zweimal eingeben (bei vorhandenem Passwort zuerst das alte). Eingaben maskiert.
function Ad:AskPassword()
	if not Ad.IsLeader() then ns:Print(L["Nur der Gildenmeister kann das Passwort festlegen."]) return end
	local old
	local function Second(first)
		UI:AskSecret(L["Neues Passwort wiederholen:"], function(second)
			local ok, why = Ad.SetPassword(old, first, second)
			if ok then ns:Print(L["Passwort gespeichert (nur als Prüfsumme auf diesem Computer)."])
			elseif why == "mismatch" then ns:Print(L["Die beiden Eingaben sind verschieden."])
			elseif why == "short" then ns:Print(L["Mindestens 4 Zeichen."])
			elseif why == "locked" then ns:Print(string.format(L["Zu viele Fehlversuche – gesperrt für %d Minuten."], math.ceil((Ad.LockedFor() or 0) / 60)))
			else ns:Print(L["Falsches Passwort."]) end
			Ad:Refresh()
		end)
	end
	local function First()
		UI:AskSecret(L["Neues Passwort (mindestens 4 Zeichen):"], Second)
	end
	if Ad.HasPassword() then
		UI:AskSecret(L["Altes Passwort:"], function(o) old = o; First() end)
	else
		First()
	end
end

function Ad:Data_List()
	local q = self.frame and ns.Trim(self.frame.search.edit:GetText()):lower() or ""
	local out = {}
	for _, e in ipairs(ns.Roster.list) do
		if q == "" or e.name:lower():find(q, 1, true) or (e.rank or ""):lower():find(q, 1, true) then out[#out + 1] = e end
	end
	table.sort(out, function(a, b)
		if (a.ri or 99) ~= (b.ri or 99) then return (a.ri or 99) < (b.ri or 99) end
		return a.name < b.name
	end)
	return out
end

function Ad:RefreshSelected()
	local f = self.frame
	if not f then return end
	local e = f.list:Selected()
	local a = Ad.Allowed(e)
	f.sel:SetText(e and (GOLD .. e.name .. "|r  " .. GRAY .. (e.rank or "") .. "|r") or GRAY .. L["Mitglied in der Liste wählen."] .. "|r")
	f.promote:SetEnabled(a.promote and true or false)
	f.demote:SetEnabled(a.demote and true or false)
	f.remove:SetEnabled(a.remove and true or false)
	local leader = Ad.IsLeader()
	local locked = Ad.LockedFor()
	f.pw:SetShown(leader); f.unlock:SetShown(leader); f.leader:SetShown(leader); f.setPw:SetShown(leader)
	f.unlock:SetEnabled(leader and not locked and Ad.HasPassword() and not Ad.unlocked)
	f.leader:SetEnabled((a.leader and Ad.unlocked and e ~= nil) and true or false)
	f.leader:SetText(Ad.unlocked and L["Gildenleitung übergeben"] or (locked and string.format(L["Gesperrt (%d min)"], math.ceil(locked / 60)) or (L["Gildenleitung übergeben"] .. " (" .. L["gesperrt"] .. ")")))
	f.accEdit:SetShown(leader); f.accAdd:SetShown(leader); f.accDel:SetShown(leader); f.accList:SetShown(leader)
end

function Ad:Refresh()
	local f = self.frame
	if not f or not f:IsShown() then return end
	if not Ad.CanOpen() then f:Hide() ns:Print(L["Nur für Gildenleitung und Offiziere."]) return end
	f.rights:SetText(Status())
	f.inviteBtn:SetEnabled(Ad.Rights().invite)
	f.list:SetData(self:Data_List())
	local d = Ad.Data()
	local names = {}
	for n in pairs(d and d.access or {}) do names[#names + 1] = n end
	table.sort(names)
	f.accList:SetText(#names > 0 and table.concat(names, ", ") or GRAY .. L["(leer)"] .. "|r")
	self:RefreshSelected()
end

function Ad:Open()
	if not ns.InGuild() then ns:Print(L["Diese Seite gibt es nur, wenn du in einer Gilde bist."]) return end
	if not Ad.CanOpen() then ns:Print(L["Nur für Gildenleitung und Offiziere."]) return end
	self:Build():Show()
	self:Refresh()
end

function Ad:Toggle()
	if self.frame and self.frame:IsShown() then self.frame:Hide() else self:Open() end
end

------------------------------------------------------------
-- Knopf neben Blizzards Gildenfenster (eigener Frame, nur geankert; Blizzard-Fenster nur per HookScript)
------------------------------------------------------------
Ad.HOSTS = { "CommunitiesFrame", "GuildFrame", "FriendsFrame" }

-- Fenster, die Blizzard rechts neben dem Gildenfenster öffnet (Mitglied-Details, Rangverwaltung)
function Ad.Popups()
	local out = {}
	for _, n in ipairs({ "GuildMemberDetailFrame", "GuildControlPopupFrame", "GuildInfoFrame" }) do
		if _G[n] then out[#out + 1] = _G[n] end
	end
	local cf = _G.CommunitiesFrame
	-- rawget: Kindfenster (parentKey) liegen direkt in der Tabelle; keine Methode des Fensters anfragen
	local child = type(cf) == "table" and rawget(cf, "GuildMemberDetailFrame")
	if child then out[#out + 1] = child end
	return out
end
function Ad.PopupShown()
	for _, x in ipairs(Ad.Popups()) do
		local ok, shown = pcall(function() return x:IsShown() end)
		if ok and shown then return true end
	end
	return false
end

local function HostShown()
	for _, n in ipairs(Ad.HOSTS) do
		local h = _G[n]
		if h and h:IsShown() then
			-- FriendsFrame nur, wenn dort gerade die Gilde zu sehen ist (Classic: Reiter Gilde)
			if n ~= "FriendsFrame" or (GuildFrame and GuildFrame:IsShown()) then return h end
		end
	end
	return nil
end

function Ad:UpdateButton()
	local b = self.button
	if not b then return end
	local d = Ad.Data()
	local host = HostShown()
	if not host or (d and d.showButton == false) or not ns.InGuild() then b:Hide() return end
	b:ClearAllPoints()
	if Ad.PopupShown() then
		-- unter das Gildenfenster, rechtsbündig (oben rechts liegen dann Blizzards Detail-/Rangfenster)
		b:SetPoint("TOPRIGHT", host, "BOTTOMRIGHT", 0, -2)
	else
		b:SetPoint("TOPLEFT", host, "TOPRIGHT", 2, -28)
	end
	local ok = Ad.CanOpen()
	b:SetEnabled(ok)
	b.tip = ok and L["Gildenverwaltung von GuildSentinel öffnen"] or L["Nur für Gildenleitung und Offiziere."]
	b:Show()
end

function Ad:MakeButton()
	if self.button then return self.button end
	local b = UI:Button(UIParent, L["Verwaltung (GuildSentinel)"], 170, 24, function() Ad:Toggle() end, true)
	b:SetFrameStrata("HIGH")
	b:Hide()
	pcall(function() b:SetMotionScriptsWhileDisabled(true) end)
	b:HookScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(self.tip or "", 1, 1, 1, 1, true)
		GameTooltip:Show()
	end)
	b:HookScript("OnLeave", function() GameTooltip:Hide() end)
	_G.GuildSentinelAdminButton = b
	if ns.RegisterUI then ns.RegisterUI(b) end
	self.button = b
	return b
end

Ad.hooked = {}
function Ad:HookHosts()
	for _, n in ipairs(self.HOSTS) do
		local h = _G[n]
		if h and not self.hooked[n] and h.HookScript then
			self.hooked[n] = true
			h:HookScript("OnShow", function() Ad:MakeButton(); Ad:UpdateButton() end)
			h:HookScript("OnHide", function() Ad:UpdateButton() end)
		end
	end
	-- Blizzards Detail- und Rangfenster öffnen rechts am Gildenfenster: dann weicht der Knopf nach unten aus
	for _, x in ipairs(Ad.Popups()) do
		local key = tostring(x)
		if not self.hooked[key] and x.HookScript then
			self.hooked[key] = true
			x:HookScript("OnShow", function() Ad:UpdateButton() end)
			x:HookScript("OnHide", function() Ad:UpdateButton() end)
		end
	end
end

ns:On("PLAYER_LOGIN", function() Ad:HookHosts() end)
ns:On("ADDON_LOADED", function(name)
	if name == "Blizzard_Communities" or name == "Blizzard_GuildUI" then Ad:HookHosts() end
end)
ns:On("GUILD_ROSTER_UPDATE", function()
	if Ad.frame and Ad.frame:IsShown() then Ad:Refresh() end
	if Ad.button and Ad.button:IsShown() then Ad:UpdateButton() end
end)
