-- GuildSentinel - Goals.lua
-- Gemeinsame Ziele der Gilde:
--   * Wochenziel: z. B. "Diese Woche 150 Stufen als Gilde" – Fortschrittsbalken, Ansage im Gildenchat, wenn es
--     geschafft ist. Die Woche beginnt mittwochs (Raid-Reset in Europa). Offiziere legen das Ziel fest.
--   * Meilensteine: "5 Mitglieder auf 60", "Alle Tanks für den Geschmolzenen Kern eingestimmt", "25 Mitglieder",
--     Erstkills aus RaidMaster … Jeder Meilenstein wird einmal im Gildenchat gefeiert und bleibt in der Liste.
--
--   G.goal = { target, t, by }          G.goalDone[Woche] = Zeit
--   G.miles[Schlüssel] = Zeit (erreicht)

local ADDON, ns = ...
local L = ns.L
local Go = {}
ns.Goals = Go

Go.DEFAULT_TARGET = 150

------------------------------------------------------------
-- Woche (beginnt Mittwoch 0 Uhr Ortszeit)
------------------------------------------------------------
function Go:WeekStart(now)
	now = now or ns.Now()
	local d = date("*t", now)
	local wd = ((d.wday + 5) % 7) + 1           -- 1 = Montag … 7 = Sonntag
	local back = (wd - 3) % 7                   -- Tage seit Mittwoch
	return time({ year = d.year, month = d.month, day = d.day - back, hour = 0, min = 0, sec = 0 })
end

function Go:WeekKey(now)
	return date("%Y%m%d", self:WeekStart(now))
end

function Go:Target()
	local g = ns.G()
	return (g.goal and tonumber(g.goal.target)) or self.DEFAULT_TARGET
end

function Go:SetTarget(n)
	local g = ns.guild
	if not g then return end
	if not ns.IsOfficer() then ns:Print(L["Das Wochenziel können nur Offiziere ändern."]) return end
	g.goal = { target = math.max(1, math.min(5000, math.floor(tonumber(n) or self.DEFAULT_TARGET))), t = ns.Now(), by = ns.Me() }
	ns.Comm:Send("GOAL", g.goal)
	ns:Fire("GS_GOALS")
end

ns.Comm:Register("GOAL", function(sender, d)
	local g = ns.guild
	local x = ns.Roster.byName[sender]
	if not g or type(d.t) ~= "number" or not (x and x.ri <= 1) then return end
	if g.goal and (g.goal.t or 0) >= d.t then return end
	g.goal = { target = tonumber(d.target) or Go.DEFAULT_TARGET, t = d.t, by = d.by or sender }
	ns:Fire("GS_GOALS")
end)

-- Stufen, die die Gilde seit Wochenbeginn erreicht hat (alle Charaktere): Summe, Liste der Fleißigsten
function Go:WeekLevels(now)
	local start = self:WeekStart(now)
	local total, by = 0, {}
	for name, lv in pairs(ns.G().levels) do
		if ns.Roster.byName[name] then
			local n = 0
			for _, t in pairs(lv) do if t and t >= start then n = n + 1 end end
			if n > 0 then
				total = total + n
				local m = ns.Roster:MainOf(name) or name
				by[m] = (by[m] or 0) + n
			end
		end
	end
	local top = {}
	for name, n in pairs(by) do top[#top + 1] = { name = name, n = n } end
	table.sort(top, function(a, b) if a.n == b.n then return a.name < b.name end return a.n > b.n end)
	return total, top
end

function Go:CheckWeek()
	local g = ns.guild
	if not g or not ns.db.annGoal then return end
	local key = self:WeekKey()
	if g.goalDone[key] then return end
	local total = self:WeekLevels()
	local target = self:Target()
	if total >= target then
		local ck = "goal:" .. key
		ns.Claim(ck, function()
			g.goalDone[key] = ns.Now()
			ns.Announce(string.format(L["Wochenziel geschafft: %d Stufen als Gilde diese Woche – stark!"], total))
		end)
	end
end

------------------------------------------------------------
-- Meilensteine
------------------------------------------------------------
-- jeder Prüfer liefert { { key, text } } für alles, was erreicht ist
Go.CHECKS = {}

local function Count(fn)
	local n = 0
	for _, e in ipairs(ns.Roster.list) do if fn(e) then n = n + 1 end end
	return n
end

-- Mitglieder auf 60 (nur Mains)
table.insert(Go.CHECKS, function()
	local out = {}
	local n = Count(function(e) return e.level >= ns.Roster.MAX_LEVEL and not ns.Roster:IsAlt(e.name) end)
	for _, step in ipairs({ 1, 5, 10, 20, 30, 40 }) do
		if n >= step then
			out[#out + 1] = { key = "max:" .. step, text = step == 1 and L["Das erste Gildenmitglied ist auf 60"] or string.format(L["%d Mitglieder auf 60"], step) }
		end
	end
	return out
end)

-- Mitgliederzahl (Spieler, nicht Charaktere)
table.insert(Go.CHECKS, function()
	local out = {}
	local _, _, mains = ns.Roster:Stats()
	for _, step in ipairs({ 10, 25, 50, 100, 200 }) do
		if mains >= step then out[#out + 1] = { key = "mem:" .. step, text = string.format(L["%d Spieler in der Gilde"], step) } end
	end
	return out
end)

-- Raid-Zugänge: alle Tanks / 40 Spieler für einen Raid eingestimmt (nur bekannte Daten zählen)
table.insert(Go.CHECKS, function()
	local out = {}
	for _, a in ipairs(ns.Attune.LIST) do
		if a.raid then
			local tanks, tanksOk, ok = 0, 0, 0
			for _, e in ipairs(ns.Roster.list) do
				if e.level >= (a.level or 55) and not ns.Roster:IsAlt(e.name) then
					local st = ns.Attune:Status(e.name, a.key)
					if st then ok = ok + 1 end
					if ns.Comp:Role(e.name, e.class) == "tank" and select(2, ns.Comp:Role(e.name, e.class)) ~= "guess" then
						tanks = tanks + 1
						if st then tanksOk = tanksOk + 1 end
					end
				end
			end
			if tanks >= 2 and tanksOk == tanks then
				out[#out + 1] = { key = "tanks:" .. a.key, text = string.format(L["Alle Tanks für %s eingestimmt"], L[a.name]) }
			end
			for _, step in ipairs({ 20, 40 }) do
				if ok >= step then out[#out + 1] = { key = "att:" .. a.key .. ":" .. step, text = string.format(L["%d Spieler für %s eingestimmt"], step, L[a.name]) } end
			end
		end
	end
	return out
end)

-- Erstkills aus RaidMaster
table.insert(Go.CHECKS, function()
	local out = {}
	for _, b in ipairs(ns.Links:FirstKills()) do
		out[#out + 1] = { key = "kill:" .. tostring(b.id), text = string.format(L["Erstkill: %s"], b.name), quiet = true }
	end
	return out
end)

-- Wochenziel geschafft (zählt als Meilenstein beim ersten Mal)
table.insert(Go.CHECKS, function()
	if next(ns.G().goalDone) then return { { key = "goal:first", text = L["Das erste Wochenziel geschafft"] } } end
	return {}
end)

function Go:Reached()
	local out = {}
	for _, fn in ipairs(self.CHECKS) do
		local ok, list = pcall(fn)
		if ok then for _, m in ipairs(list) do out[#out + 1] = m end end
	end
	return out
end

-- neue Meilensteine merken und (einmal, von einem) im Gildenchat feiern
function Go:CheckMiles()
	local g = ns.guild
	if not g or not next(ns.Roster.byName) then return end
	local first = not g.milesInit
	for _, m in ipairs(self:Reached()) do
		if not g.miles[m.key] then
			g.miles[m.key] = ns.Now()
			g.milesText = g.milesText or {}
			g.milesText[m.key] = m.text
			-- beim allerersten Durchlauf nichts ansagen (sonst käme alles Bisherige auf einmal)
			if not first and not m.quiet and ns.db.annMiles then
				ns.Claim("mile:" .. m.key, function() ns.Announce(string.format(L["Gilden-Meilenstein: %s!"], m.text)) end)
			end
		end
	end
	g.milesInit = true
	ns:Fire("GS_GOALS")
end

-- erreichte Meilensteine (neueste zuerst): { { key, text, t } }
function Go:Miles()
	local g = ns.G()
	local texts = {}
	for _, m in ipairs(self:Reached()) do texts[m.key] = m.text end
	local out = {}
	for key, t in pairs(g.miles) do
		out[#out + 1] = { key = key, text = texts[key] or (g.milesText and g.milesText[key]) or key, t = t }
	end
	table.sort(out, function(a, b) if a.t == b.t then return a.text < b.text end return a.t > b.t end)
	return out
end

ns.Comm:Register("MILES", function(sender, d)
	local g = ns.guild
	if not g or type(d.m) ~= "table" then return end
	for key, t in pairs(d.m) do
		t = tonumber(t)
		if type(key) == "string" and t and (not g.miles[key] or t < g.miles[key]) then g.miles[key] = t end
	end
	if type(d.w) == "table" then
		for key, t in pairs(d.w) do if type(key) == "string" and tonumber(t) then g.goalDone[key] = g.goalDone[key] or tonumber(t) end end
	end
	ns:Fire("GS_GOALS")
end)

ns:Listen("GS_ROSTER", function()
	if Go.pending then return end
	Go.pending = true
	C_Timer.After(5, function()
		Go.pending = false
		Go:CheckMiles()
		Go:CheckWeek()
	end)
end)
ns:Listen("GS_ATTUNE", function() C_Timer.After(5, function() Go:CheckMiles() end) end)
