-- GuildSentinel - Events.lua
-- Gildentermine im Spiel – für alles außer Raids (die laufen über RaidMaster und Discord): PvP-Abend,
-- Gildentreffen, Dungeon-Nacht, Weltboss … Jedes Mitglied kann einen Termin anlegen, alle sagen per Klick zu,
-- ab oder "vielleicht". 15 Minuten vorher erinnert GuildSentinel alle, die zugesagt haben.
-- Ist RaidMaster installiert, steht der nächste Raid aus der Discord-Anmeldung mit in der Liste (nur zur Info).
--
--   G.events[id] = { id, by, title, kind, t = Beginn, d = Dauer (Min.), note, u, del, r = { [Main] = { s, t } } }
--   s: "yes", "maybe", "no"

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local E = {}
ns.Events = E

E.REMIND = 15 * 60
E.KINDS = {
	{ key = "pvp", n = N["PvP-Abend"] },
	{ key = "meet", n = N["Gildentreffen"] },
	{ key = "dungeon", n = N["Dungeon-Nacht"] },
	{ key = "worldboss", n = N["Weltboss"] },
	{ key = "farm", n = N["Farmen"] },
	{ key = "fun", n = N["Spaß-Event"] },
	{ key = "other", n = N["Sonstiges"] },
}
E.BY_KEY = {}
for _, k in ipairs(E.KINDS) do E.BY_KEY[k.key] = k end

function E:KindName(key)
	local k = self.BY_KEY[key]
	return k and L[k.n] or L["Sonstiges"]
end

function E:Voter(name)
	return ns.Roster:MainOf(name) or name
end

local counter = 0

-- t = Serverzeit des Beginns
function E:Create(title, kind, t, dur, note)
	local g = ns.guild
	if not g then return end
	title = ns.Trim(title)
	if title == "" then title = self:KindName(kind) end
	if not t or t < ns.Now() - 600 then ns:Print(L["Der Termin liegt in der Vergangenheit."]) return end
	counter = counter + 1
	local e = { id = ns.Me() .. ns.Now() .. counter, by = ns.Me(), title = title:sub(1, 60), kind = self.BY_KEY[kind] and kind or "other",
		t = math.floor(t), d = math.max(15, math.min(600, tonumber(dur) or 120)), note = ns.Trim(note):sub(1, 150), u = ns.Now(), r = {} }
	e.r[self:Voter(ns.Me())] = { s = "yes", t = ns.Now() }
	g.events[e.id] = e
	ns.Comm:Send("EVT", self:Wire(e))
	ns:Fire("GS_EVENTS")
	return e
end

function E:Wire(e)
	return { id = e.id, by = e.by, title = e.title, kind = e.kind, t = e.t, d = e.d, note = e.note, u = e.u, del = e.del }
end

function E:CanEdit(e)
	return e and (ns.Same(e.by, ns.Me()) or ns.IsOfficer())
end

function E:Cancel(id)
	local e = ns.G().events[id]
	if not e or not self:CanEdit(e) then return end
	e.del, e.u = true, ns.Now()
	ns.Comm:Send("EVT", self:Wire(e))
	ns:Fire("GS_EVENTS")
end

function E:Reply(id, s)
	local e = ns.G().events[id]
	if not e or e.del or (s ~= "yes" and s ~= "maybe" and s ~= "no") then return end
	e.r = e.r or {}
	e.r[self:Voter(ns.Me())] = { s = s, t = ns.Now() }
	ns.Comm:Send("EVTR", { id = id, s = s, t = ns.Now() })
	ns:Fire("GS_EVENTS")
end

local function StoreEvent(d)
	local g = ns.guild
	if not g or type(d) ~= "table" or type(d.id) ~= "string" or type(d.t) ~= "number" or type(d.by) ~= "string" then return false, nil end
	local u = tonumber(d.u) or 0
	local old = g.events[d.id]
	if old and (old.u or 0) >= u then return false, old end
	g.events[d.id] = {
		id = d.id, by = d.by, title = type(d.title) == "string" and d.title:sub(1, 60) or "?", kind = E.BY_KEY[d.kind] and d.kind or "other",
		t = d.t, d = tonumber(d.d) or 120, note = type(d.note) == "string" and d.note:sub(1, 150) or "", u = u, del = d.del and true or nil,
		r = old and old.r or {}, reminded = old and old.reminded,
	}
	return true, old
end
E.StoreEvent = StoreEvent

ns.Comm:Register("EVT", function(sender, d)
	-- ändern darf nur, wer ihn angelegt hat, oder ein Offizier (oberste zwei Ränge)
	local old = type(d.id) == "string" and ns.G().events[d.id]
	local x = ns.Roster.byName[sender]
	if old and not ns.Same(old.by, sender) and not (x and x.ri <= 1) then return end
	local ok, prev = StoreEvent(d)
	if ok then
		local e = ns.G().events[d.id]
		if not prev and not e.del and e.t > ns.Now() then
			ns:Print(string.format(L["Neuer Gildentermin: %s am %s (von %s) – /gs termine"], e.title, ns.Date(e.t), e.by))
		end
		ns:Fire("GS_EVENTS")
	end
end)

ns.Comm:Register("EVTR", function(sender, d)
	local e = type(d.id) == "string" and ns.G().events[d.id]
	if not e or e.del or (d.s ~= "yes" and d.s ~= "maybe" and d.s ~= "no") then return end
	local who = E:Voter(sender)
	local t = tonumber(d.t) or ns.Now()
	local old = e.r[who]
	if old and (old.t or 0) > t then return end
	e.r[who] = { s = d.s, t = t }
	ns:Fire("GS_EVENTS")
end)

-- beim Abgleich: alle kommenden Termine mit Antworten
ns.Comm:Register("EVTS", function(sender, d)
	if type(d.e) ~= "table" then return end
	for _, x in pairs(d.e) do
		StoreEvent(x)
		local e = type(x.id) == "string" and ns.G().events[x.id]
		if e and type(x.r) == "table" then
			for who, r in pairs(x.r) do
				if type(who) == "string" and type(r) == "table" and (r.s == "yes" or r.s == "maybe" or r.s == "no") then
					local old = e.r[who]
					if not old or (old.t or 0) < (tonumber(r.t) or 0) then e.r[who] = { s = r.s, t = tonumber(r.t) or 0 } end
				end
			end
		end
	end
	ns:Fire("GS_EVENTS")
end)

function E:SyncData()
	local out = {}
	for id, e in pairs(ns.G().events) do
		if e.t + (e.d or 120) * 60 > ns.Now() then
			local w = self:Wire(e)
			w.r = e.r
			out[id] = w
		end
	end
	return out
end

------------------------------------------------------------
-- Abfragen
------------------------------------------------------------
function E:Counts(e)
	local c = { yes = 0, maybe = 0, no = 0 }
	local names = { yes = {}, maybe = {}, no = {} }
	for who, r in pairs(e.r or {}) do
		if c[r.s] then
			c[r.s] = c[r.s] + 1
			names[r.s][#names[r.s] + 1] = who
		end
	end
	for _, l in pairs(names) do table.sort(l) end
	return c, names
end

function E:MyReply(e)
	local r = e.r and e.r[self:Voter(ns.Me())]
	return r and r.s or nil
end

-- kommende Termine (inkl. laufende), nächster zuerst; dazu der nächste Raid aus RaidMaster
function E:Upcoming(includeRaid)
	local out = {}
	local now = ns.Now()
	for _, e in pairs(ns.G().events) do
		if not e.del and e.t + (e.d or 120) * 60 > now then out[#out + 1] = e end
	end
	if includeRaid then
		local raid = ns.Links:NextRaid()
		if raid then
			out[#out + 1] = { id = "raidmaster", raid = true, title = raid.title, t = raid.t, d = 180, kind = "raid",
				note = string.format(L["Anmeldung im Discord (RaidMaster): %d angemeldet"], raid.signed), r = {} }
		end
	end
	table.sort(out, function(a, b) return a.t < b.t end)
	return out
end

function E:OpenCount()
	local n = 0
	for _, e in ipairs(self:Upcoming(false)) do
		if not self:MyReply(e) and e.t > ns.Now() then n = n + 1 end
	end
	return n
end

------------------------------------------------------------
-- Erinnerung 15 Minuten vorher
------------------------------------------------------------
function E:CheckReminders()
	local now = ns.Now()
	for _, e in pairs(ns.G().events) do
		local mine = self:MyReply(e)
		if not e.del and not e.reminded and (mine == "yes" or mine == "maybe") and e.t > now and e.t - now <= self.REMIND then
			e.reminded = true
			ns:Print(string.format(L["Gleich geht's los: %s in %d Minuten!"], e.title, math.max(1, math.floor((e.t - now) / 60 + 0.5))))
			if RaidNotice_AddMessage and RaidWarningFrame and ChatTypeInfo then
				pcall(RaidNotice_AddMessage, RaidWarningFrame, ns.TITLE .. ": " .. e.title, ChatTypeInfo["RAID_WARNING"])
			end
			if PlaySound and SOUNDKIT and SOUNDKIT.RAID_WARNING then pcall(PlaySound, SOUNDKIT.RAID_WARNING) end
		end
	end
end

C_Timer.NewTicker(30, function() if ns.guild then E:CheckReminders() end end)

ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = ns.Now() - 7 * 86400
	for id, e in pairs(g.events) do if e.t < limit then g.events[id] = nil end end
	C_Timer.After(40, function()
		local n = E:OpenCount()
		if n > 0 then ns:Print(string.format(L["%d Gildentermin(e) ohne deine Antwort – /gs termine"], n)) end
	end)
end)

-- Datum/Uhrzeit aus Eingaben: Tag ("heute", "morgen", "TT.MM.") und "HH:MM" -> Serverzeit
function E:ParseWhen(dayText, timeText)
	local now = ns.Now()
	local d = date("*t", now)
	dayText = ns.Trim(dayText):lower()
	local h, m = ns.Trim(timeText):match("^(%d%d?)[:%.](%d%d)$")
	if not h then h = ns.Trim(timeText):match("^(%d%d?)$"); m = 0 end
	h, m = tonumber(h), tonumber(m)
	if not h or h > 23 or m > 59 then return nil end
	local t = { year = d.year, month = d.month, day = d.day, hour = h, min = m, sec = 0 }
	if dayText == "" or dayText == L["heute"]:lower() or dayText == "heute" or dayText == "today" then
	elseif dayText == L["morgen"]:lower() or dayText == "morgen" or dayText == "tomorrow" then
		t.day = t.day + 1
	else
		local dd, mm = dayText:match("^(%d%d?)%.(%d%d?)%.?$")
		if not dd then mm, dd = dayText:match("^(%d%d?)/(%d%d?)$") end
		dd, mm = tonumber(dd), tonumber(mm)
		if not dd or not mm then return nil end
		t.day, t.month = dd, mm
		if time(t) < now - 86400 then t.year = t.year + 1 end
	end
	return time(t)
end
