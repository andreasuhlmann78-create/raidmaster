-- GuildSentinel - RaidMaster.lua
-- Zusammenarbeit mit RaidMaster: Ist RaidMaster installiert, nutzt GuildSentinel dessen Daten, statt sie
-- ein zweites Mal einzulesen und zu verschicken.
--   * Berufe: RaidMaster liest die Berufsfenster und schickt sie an die Gilde (RaidMasterDB.prof, gleiches Format).
--     GuildSentinel zeigt sie an und schickt selbst keine eigenen Berufe mehr.
--   * Twinks: Die Twinks aus Discord (/twink) bzw. aus RaidMaster haben Vorrang. Setzt ein Offizier in
--     GuildSentinel einen Twink, wird er auch in RaidMaster eingetragen.

local ADDON, ns = ...
local X = {}
ns.RMI = X

local function RM()
	local rm = _G.RaidMaster
	if type(rm) == "table" and type(rm.db) == "table" then return rm end
	return nil
end

function X:Active()
	return RM() ~= nil
end

function X:Version()
	local rm = RM()
	return rm and rm.VERSION or nil
end

-- Berufe aller Addon-Nutzer, die RaidMaster kennt
function X:Profs()
	local rm = RM()
	if not rm or type(rm.db.prof) ~= "table" then return nil end
	return rm.db.prof
end

-- Main laut RaidMaster (nil = kein Twink oder unbekannt)
function X:MainOf(name)
	local rm = RM()
	if not rm or not rm.DKP or not rm.DKP.MainOf or type(rm.db.data) ~= "table" then return nil end
	local ok, main = pcall(rm.DKP.MainOf, name)
	if ok and type(main) == "string" and main ~= "" then return main end
	return nil
end

function X:CanEdit()
	local rm = RM()
	if not rm or not rm.CanEdit then return false end
	local ok, can = pcall(rm.CanEdit)
	return ok and can and true or false
end

-- Twink auch in RaidMaster setzen (main = nil löst die Verknüpfung); nur mit Offiziersrechten
function X:SetMain(twink, main)
	local rm = RM()
	if not rm or not rm.DKP or not rm.DKP.SetMain or not self:CanEdit() then return false end
	local ok, res = pcall(rm.DKP.SetMain, twink, main, true)
	return ok and res
end


-- Rolle aus der Skillung, die RaidMaster kennt: "tank", "heal" oder "dps" (nil = unbekannt)
function X:Role(name)
	local rm = RM()
	if not rm or not rm.Spec or not rm.Spec.Role or type(rm.db.specs) ~= "table" then return nil end
	local ok, role = pcall(rm.Spec.Role, name)
	if not ok or not role then return nil end
	if role == "tank" or role == "heal" then return role end
	if role == "melee" or role == "ranged" or role == "dps" then return "dps" end
	return nil
end
