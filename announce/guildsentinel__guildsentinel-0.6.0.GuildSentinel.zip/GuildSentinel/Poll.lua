-- GuildSentinel - Poll.lua
-- Umfragen: Ein Offizier stellt eine Frage mit 2 bis 8 Antworten ("Raid lieber Mittwoch oder Donnerstag?").
-- Alle mit GuildSentinel stimmen per Klick ab; jeder Spieler hat eine Stimme (Twinks zählen für den Main) und
-- kann sie bis zum Ende ändern. Das Ergebnis sieht man live.
--
--   G.polls[id] = { id, by, q, o = { Antworten }, t, exp, anon, closed, votes = { [Main] = { o = Nr., t } } }

local ADDON, ns = ...
local L = ns.L
local Po = {}
ns.Poll = Po

Po.MAX_OPTIONS = 8
Po.DURATIONS = { { h = 1 }, { h = 24 }, { h = 72 }, { h = 168 } }

function Po:CanCreate()
	return ns.IsOfficer()
end

function Po:IsOpen(p)
	return p and not p.closed and (p.exp or 0) > ns.Now()
end

-- wer stimmt ab: der Main (eine Stimme pro Spieler)
function Po:Voter(name)
	return ns.Roster:MainOf(name) or name
end

local counter = 0

function Po:Create(question, options, hours, anon)
	local g = ns.guild
	if not g then return end
	if not self:CanCreate() then ns:Print(L["Umfragen können nur Offiziere starten."]) return end
	question = ns.Trim(question)
	local opts = {}
	for _, o in ipairs(options or {}) do
		o = ns.Trim(o)
		if o ~= "" and #opts < self.MAX_OPTIONS then opts[#opts + 1] = o:sub(1, 60) end
	end
	if question == "" or #opts < 2 then
		ns:Print(L["Eine Umfrage braucht eine Frage und mindestens zwei Antworten."])
		return
	end
	counter = counter + 1
	local now = ns.Now()
	local p = { id = ns.Me() .. now .. counter, by = ns.Me(), q = question:sub(1, 200), o = opts, t = now,
		exp = now + (tonumber(hours) or 24) * 3600, anon = anon and true or nil, votes = {} }
	g.polls[p.id] = p
	ns.Comm:Send("POLL", self:Wire(p))
	ns:Fire("GS_POLL")
	return p
end

function Po:Wire(p)
	return { id = p.id, by = p.by, q = p.q, o = p.o, t = p.t, exp = p.exp, anon = p.anon, closed = p.closed }
end

function Po:Vote(id, option)
	local p = ns.G().polls[id]
	if not self:IsOpen(p) or not p.o[option] then return end
	local voter = self:Voter(ns.Me())
	p.votes[voter] = { o = option, t = ns.Now() }
	ns.Comm:Send("VOTE", { id = id, o = option, t = ns.Now() })
	ns:Fire("GS_POLL")
end

function Po:CanClose(p)
	return p and (ns.Same(p.by, ns.Me()) or ns.IsOfficer())
end

function Po:Close(id)
	local p = ns.G().polls[id]
	if not p or not self:CanClose(p) then return end
	p.closed = true
	ns.Comm:Send("POLLX", { id = id })
	ns:Fire("GS_POLL")
end

-- Ergebnis: counts[Nr.] = Stimmen, total, voters[Nr.] = { Namen }, mine = meine Wahl
function Po:Results(p)
	local counts, voters, total = {}, {}, 0
	for i = 1, #p.o do counts[i] = 0; voters[i] = {} end
	for who, v in pairs(p.votes or {}) do
		if counts[v.o] then
			counts[v.o] = counts[v.o] + 1
			voters[v.o][#voters[v.o] + 1] = who
			total = total + 1
		end
	end
	for i = 1, #p.o do table.sort(voters[i]) end
	local mine = p.votes[self:Voter(ns.Me())]
	return counts, total, voters, mine and mine.o or nil
end

function Po:List()
	local out = {}
	local limit = ns.Now() - 14 * 86400
	for _, p in pairs(ns.G().polls) do
		if (p.exp or 0) > limit then out[#out + 1] = p end
	end
	table.sort(out, function(a, b)
		local ao, bo = self:IsOpen(a), self:IsOpen(b)
		if ao ~= bo then return ao end
		return (a.t or 0) > (b.t or 0)
	end)
	return out
end

function Po:OpenUnvoted()
	local n = 0
	local me = self:Voter(ns.Me())
	for _, p in ipairs(self:List()) do
		if self:IsOpen(p) and not p.votes[me] then n = n + 1 end
	end
	return n
end

------------------------------------------------------------
-- Empfangen
------------------------------------------------------------
function Po:Store(d)
	local g = ns.guild
	if not g or type(d.id) ~= "string" or type(d.q) ~= "string" or type(d.o) ~= "table" then return false end
	local old = g.polls[d.id]
	local opts = {}
	for i = 1, self.MAX_OPTIONS do if type(d.o[i]) == "string" then opts[i] = d.o[i] end end
	if #opts < 2 then return false end
	g.polls[d.id] = {
		id = d.id, by = type(d.by) == "string" and d.by or "?", q = d.q, o = opts, t = tonumber(d.t) or ns.Now(),
		exp = tonumber(d.exp) or (ns.Now() + 86400), anon = d.anon and true or nil,
		closed = (d.closed or (old and old.closed)) and true or nil, votes = old and old.votes or {},
	}
	return not old
end

ns.Comm:Register("POLL", function(sender, d)
	if Po:Store(d) then
		local p = ns.G().polls[d.id]
		if Po:IsOpen(p) then
			ns:Print(string.format(L["Neue Umfrage von %s: %s – abstimmen: /gs umfrage"], p.by, p.q))
		end
	end
	ns:Fire("GS_POLL")
end)

ns.Comm:Register("VOTE", function(sender, d)
	local p = type(d.id) == "string" and ns.G().polls[d.id]
	if not p or not Po:IsOpen(p) or not p.o[tonumber(d.o) or 0] then return end
	local voter = Po:Voter(sender)
	local t = tonumber(d.t) or ns.Now()
	local old = p.votes[voter]
	if old and (old.t or 0) > t then return end
	p.votes[voter] = { o = tonumber(d.o), t = t }
	ns:Fire("GS_POLL")
end)

ns.Comm:Register("POLLX", function(sender, d)
	local p = type(d.id) == "string" and ns.G().polls[d.id]
	if not p then return end
	-- beenden darf der Ersteller oder jemand aus den beiden obersten Rängen (Gildenmeister, Offiziere)
	local x = ns.Roster.byName[sender]
	if ns.Same(p.by, sender) or (x and x.ri <= 1) then
		p.closed = true
		ns:Fire("GS_POLL")
	end
end)

-- beim Abgleich: Umfragen mit allen Stimmen
ns.Comm:Register("POLLS", function(sender, d)
	if type(d.e) ~= "table" then return end
	for _, x in pairs(d.e) do
		if type(x) == "table" then
			Po:Store(x)
			local p = type(x.id) == "string" and ns.G().polls[x.id]
			if p and type(x.votes) == "table" then
				for who, v in pairs(x.votes) do
					if type(who) == "string" and type(v) == "table" and p.o[tonumber(v.o) or 0] then
						local old = p.votes[who]
						if not old or (old.t or 0) < (tonumber(v.t) or 0) then p.votes[who] = { o = tonumber(v.o), t = tonumber(v.t) or 0 } end
					end
				end
			end
		end
	end
	ns:Fire("GS_POLL")
end)

function Po:SyncData()
	local e = {}
	for _, p in ipairs(self:List()) do
		local w = self:Wire(p)
		w.votes = p.votes
		e[p.id] = w
	end
	return e
end

-- alte Umfragen nach 30 Tagen vergessen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = ns.Now() - 30 * 86400
	for id, p in pairs(g.polls) do if (p.exp or 0) < limit then g.polls[id] = nil end end
	C_Timer.After(30, function()
		local n = Po:OpenUnvoted()
		if n > 0 then ns:Print(string.format(L["%d offene Umfrage(n) – abstimmen: /gs umfrage"], n)) end
	end)
end)
