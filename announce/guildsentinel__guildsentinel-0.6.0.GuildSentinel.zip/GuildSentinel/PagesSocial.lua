-- GuildSentinel - PagesSocial.lua
-- Seiten: Termine, Brett (Dienste, Biete, Suche) und Addons (Vernetzung mit allen GoldSentinel-Addons).

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI

local GREEN, GRAY, GOLD, ORANGE, RED = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933", "|cffff5555"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end
local function WhenShown(key, fn)
	return function(...) if UI:IsPageShown(key) then fn(...) end end
end

local WEEKDAY = { N["So"], N["Mo"], N["Di"], N["Mi"], N["Do"], N["Fr"], N["Sa"] }
local function When(t)
	local d = date("*t", t)
	return L[WEEKDAY[d.wday]] .. " " .. ns.Date(t)
end

------------------------------------------------------------
-- Seite: Termine
------------------------------------------------------------
local Ev = { key = "events", order = 22, icon = "Interface\\Icons\\INV_Misc_PocketWatch_01" }
Ev.title = N["Termine"]
Ev.form = { kind = "pvp", dur = 120 }
Ev.badge = function()
	local n = ns.Events:OpenCount()
	return n > 0 and (GOLD .. n .. "|r") or ""
end

function Ev.build(p)
	Ev.panel = p
	local E = ns.Events
	local h = UI:Header(p, L["Neuer Termin"])
	h:SetPoint("TOPLEFT", 0, 0)
	local kind = UI:Dropdown(p, 150, function()
		local out = {}
		for _, k in ipairs(E.KINDS) do out[#out + 1] = { value = k.key, text = L[k.n] } end
		return out
	end, function() return Ev.form.kind end, function(v) Ev.form.kind = v end)
	kind:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	Ev.titleEdit = UI:Edit(p, 220, 24, L["Titel, z. B. 'PvP in Tarrens Mühle'"], false, 60)
	Ev.titleEdit:SetPoint("LEFT", kind, "RIGHT", 8, 0)
	Ev.dayEdit = UI:Edit(p, 90, 24, L["heute"], false, 10)
	Ev.dayEdit:SetPoint("LEFT", Ev.titleEdit, "RIGHT", 8, 0)
	UI.Tip(Ev.dayEdit, L["Tag"], L["heute, morgen oder ein Datum wie 15.11."])
	Ev.timeEdit = UI:Edit(p, 70, 24, "20:00", false, 5)
	Ev.timeEdit:SetPoint("LEFT", Ev.dayEdit, "RIGHT", 6, 0)
	local dur = UI:Dropdown(p, 100, function()
		return { { value = 60, text = L["1 Std."] }, { value = 120, text = L["2 Std."] }, { value = 180, text = L["3 Std."] }, { value = 240, text = L["4 Std."] } }
	end, function() return Ev.form.dur end, function(v) Ev.form.dur = v end)
	dur:SetPoint("LEFT", Ev.timeEdit, "RIGHT", 6, 0)
	Ev.noteEdit = UI:Edit(p, 480, 24, L["Notiz (optional), z. B. 'Treffpunkt Orgrimmar, Tor'"], false, 150)
	Ev.noteEdit:SetPoint("TOPLEFT", kind, "BOTTOMLEFT", 0, -8)
	Ev.create = UI:Button(p, L["Termin anlegen"], 160, 24, function()
		local t = E:ParseWhen(Ev.dayEdit:GetText(), Ev.timeEdit:GetText() ~= "" and Ev.timeEdit:GetText() or "20:00")
		if not t then ns:Print(L["Tag oder Uhrzeit nicht erkannt. Beispiele: heute 20:00, morgen 19:30, 15.11. 21:00"]) return end
		if E:Create(Ev.titleEdit:GetText(), Ev.form.kind, t, Ev.form.dur, Ev.noteEdit:GetText()) then
			Ev.titleEdit:SetText("")
			Ev.noteEdit:SetText("")
		end
	end, true)
	Ev.create:SetPoint("LEFT", Ev.noteEdit, "RIGHT", 8, 0)

	Ev.list = UI:List(p, {
		{ key = "when", title = L["Wann"], width = 150 },
		{ key = "title", title = L["Was"], width = 230 },
		{ key = "by", title = L["Von"], width = 100 },
		{ key = "n", title = L["Zusagen"], width = 90, align = "CENTER" },
		{ key = "me", title = L["Du"] },
	}, {
		rowH = 22,
		key = function(e) return e.id end,
		render = function(e)
			local when = When(e.t)
			if e.t <= ns.Now() then when = GREEN .. L["läuft"] .. "|r " .. Gray(date("%H:%M", e.t)) end
			local title = (e.raid and (ORANGE .. "[RaidMaster]|r ") or (Gray("[" .. E:KindName(e.kind) .. "] "))) .. e.title
			if e.raid then return { when, title, "", Gray("–"), Gray(L["Anmeldung im Discord"]) } end
			local c = E:Counts(e)
			local mine = E:MyReply(e)
			local me = (mine == "yes" and (GREEN .. L["dabei"] .. "|r")) or (mine == "maybe" and (GOLD .. L["vielleicht"] .. "|r")) or (mine == "no" and (RED .. L["nein"] .. "|r")) or (ORANGE .. L["offen"] .. "|r")
			return { when, title, e.by or "", GREEN .. c.yes .. "|r" .. Gray(" / " .. c.maybe), me }
		end,
		onClick = function() Ev:ShowDetail() end,
		empty = L["Keine Termine. Leg oben einen an – alle mit GuildSentinel bekommen einen Hinweis."],
	})
	Ev.list:SetPoint("TOPLEFT", 0, -72)
	Ev.list:SetPoint("RIGHT")
	Ev.list:SetHeight(230)

	local d = CreateFrame("Frame", nil, p, UI.BACKDROP)
	d:SetPoint("TOPLEFT", Ev.list, "BOTTOMLEFT", 0, -8)
	d:SetPoint("BOTTOMRIGHT")
	UI.Box(d, 0.07, 0.08, 0.11, 1, 0.18, 0.2, 0.25, 1)
	Ev.detail = d
	d.title = UI:Label(d, "", "GameFontNormalLarge")
	d.title:SetPoint("TOPLEFT", 12, -10)
	d.info = UI:Label(d, "", "GameFontHighlightSmall")
	d.info:SetPoint("TOPLEFT", d.title, "BOTTOMLEFT", 0, -6)
	d.info:SetWidth(520)
	d.info:SetJustifyV("TOP")
	local x = -10
	local function Btn(text, s)
		local b = UI:Button(d, text, 110, 26, function()
			local e = Ev.list:Selected()
			if e and not e.raid then ns.Events:Reply(e.id, s) end
		end, s == "yes")
		b:SetPoint("TOPRIGHT", x, -10)
		x = x - 116
		return b
	end
	d.no = Btn(L["Absagen"], "no")
	d.maybe = Btn(L["Vielleicht"], "maybe")
	d.yes = Btn(L["Ich bin dabei"], "yes")
	d.cancel = UI:Button(d, L["Termin absagen"], 140, 24, function()
		local e = Ev.list:Selected()
		if e and not e.raid then UI:Confirm(string.format(L["Termin '%s' für alle absagen?"], e.title), function() ns.Events:Cancel(e.id) end) end
	end)
	d.cancel:SetPoint("BOTTOMRIGHT", -10, 10)
	d.announce = UI:Button(d, L["Im Gildenchat ankündigen"], 190, 24, function()
		local e = Ev.list:Selected()
		if e and not e.raid then
			ns.Announce(string.format(L["Gildentermin: %s am %s – zusagen mit GuildSentinel (/gs termine) oder hier im Chat!"], e.title, When(e.t)))
		end
	end)
	d.announce:SetPoint("RIGHT", d.cancel, "LEFT", -8, 0)
end

function Ev:ShowDetail()
	local d = self.detail
	local e = self.list:Selected()
	if not e then
		local list = ns.Events:Upcoming(true)
		e = list[1]
		if e then self.list.selectedKey = e.id; self.list:Draw() end
	end
	local has = e ~= nil and not e.raid
	for _, b in ipairs({ d.yes, d.maybe, d.no, d.announce }) do b:SetEnabled(has) end
	d.cancel:SetShown(has and ns.Events:CanEdit(e))
	if not e then
		d.title:SetText(Gray(L["Wähle einen Termin."]))
		d.info:SetText("")
		return
	end
	d.title:SetText(e.title)
	if e.raid then
		d.info:SetText(When(e.t) .. "\n" .. (e.note or "") .. "\n" .. Gray(L["Raids laufen über RaidMaster und die Anmeldung im Discord."]))
		return
	end
	local c, names = ns.Events:Counts(e)
	local lines = {
		When(e.t) .. Gray(string.format(L[" · %d Min. · %s · von %s"], e.d or 120, ns.Events:KindName(e.kind), e.by or "?")),
	}
	if e.note and e.note ~= "" then lines[#lines + 1] = e.note end
	lines[#lines + 1] = GREEN .. string.format(L["Dabei (%d): "], c.yes) .. "|r" .. (#names.yes > 0 and table.concat(names.yes, ", ") or Gray("–"))
	lines[#lines + 1] = GOLD .. string.format(L["Vielleicht (%d): "], c.maybe) .. "|r" .. (#names.maybe > 0 and table.concat(names.maybe, ", ") or Gray("–"))
	lines[#lines + 1] = RED .. string.format(L["Nein (%d): "], c.no) .. "|r" .. (#names.no > 0 and table.concat(names.no, ", ") or Gray("–"))
	d.info:SetText(table.concat(lines, "\n"))
end

function Ev:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.list:SetData(ns.Events:Upcoming(true))
	self:ShowDetail()
end

Ev.onShow = function() Ev:Refresh() end
ns:Listen("GS_EVENTS", WhenShown("events", function() Ev:Refresh() end))
ns:Listen("GS_EVENTS", function() UI:RefreshHeader() end)
UI:AddPage(Ev)

------------------------------------------------------------
-- Seite: Brett (Dienste, Biete, Suche)
------------------------------------------------------------
local Bd = { key = "board", order = 24, icon = "Interface\\Icons\\INV_Letter_15" }
Bd.title = N["Brett"]
Bd.view = "svc"
Bd.query = ""
Bd.sel = {}
Bd.badge = function()
	local n = #ns.Board:Offers()
	return n > 0 and (GREEN .. n .. "|r") or ""
end

function Bd.build(p)
	Bd.panel = p
	Bd.tabs = UI:Tabs(p, {
		{ key = "svc", text = L["Dienste"] },
		{ key = "offer", text = L["Biete"] },
		{ key = "want", text = L["Suche"] },
	}, function(key) Bd.view = key; Bd:Refresh() end)
	Bd.tabs:SetPoint("TOPLEFT")
	Bd.tabs:SetPoint("TOPRIGHT")

	-- Dienste -------------------------------------------
	local sv = CreateFrame("Frame", nil, p)
	sv:SetPoint("TOPLEFT", 0, -34)
	sv:SetPoint("BOTTOMRIGHT")
	Bd.svcView = sv
	local h = UI:Header(sv, L["Ich biete gerade an"])
	h:SetPoint("TOPLEFT", 0, 0)
	Bd.svcHint = UI:Label(sv, "", "GameFontHighlightSmall")
	Bd.svcHint:SetPoint("LEFT", h, "RIGHT", 12, 0)
	Bd.svcHolder = CreateFrame("Frame", nil, sv)
	Bd.svcHolder:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	Bd.svcHolder:SetSize(780, 52)
	Bd.svcChecks = {}
	Bd.svcText = UI:Edit(sv, 330, 24, L["Eigenes Angebot, z. B. 'Fahrstuhl Schwarzfelstiefen'"], false, 60)
	Bd.svcText:SetPoint("TOPLEFT", Bd.svcHolder, "BOTTOMLEFT", 0, -4)
	Bd.svcOn = UI:Button(sv, L["Anbieten (2 Std.)"], 170, 24, function()
		local keys = {}
		for k, v in pairs(Bd.sel) do if v then keys[k] = true end end
		ns.Board:SetOffer(keys, Bd.svcText:GetText())
	end, true)
	Bd.svcOn:SetPoint("LEFT", Bd.svcText, "RIGHT", 8, 0)
	Bd.svcOff = UI:Button(sv, L["Nicht mehr anbieten"], 170, 24, function() ns.Board:ClearOffer(); Bd.sel = {}; Bd:Refresh() end)
	Bd.svcOff:SetPoint("LEFT", Bd.svcOn, "RIGHT", 8, 0)
	local h2 = UI:Header(sv, L["Gerade im Angebot (online)"])
	h2:SetPoint("TOPLEFT", Bd.svcText, "BOTTOMLEFT", 0, -16)
	Bd.svcList = UI:List(sv, {
		{ key = "name", title = L["Wer"], width = 150 },
		{ key = "what", title = L["Bietet an"] },
		{ key = "zone", title = L["Wo"], width = 150 },
		{ key = "t", title = L["Seit"], width = 90 },
	}, {
		key = function(o) return o.name end,
		render = function(o) return { ns.Colored(o.name, o.class), ns.Board:OffersText(o), Gray(o.zone or ""), Gray(ns.Ago(o.t)) } end,
		onClick = function() Bd:UpdateButtons() end,
		empty = L["Gerade bietet niemand etwas an. Magier, Hexenmeister, Schurken und Verzauberer: oben anhaken!"],
	})
	Bd.svcList:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	Bd.svcList:SetPoint("BOTTOMRIGHT", 0, 40)
	Bd.svcAsk = UI:Button(sv, L["Anfragen"], 140, 28, function()
		local o = Bd.svcList:Selected()
		if o then ns.Board:AskService(o) end
	end, true)
	Bd.svcAsk:SetPoint("BOTTOMRIGHT", 0, 4)
	Bd.svcInvite = UI:Button(sv, L["In Gruppe einladen"], 150, 28, function()
		local o = Bd.svcList:Selected()
		local fn = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
		if o and fn then fn(o.name) end
	end)
	Bd.svcInvite:SetPoint("RIGHT", Bd.svcAsk, "LEFT", -8, 0)

	-- Biete / Suche (gemeinsame Ansicht) ----------------
	local mv = CreateFrame("Frame", nil, p)
	mv:SetPoint("TOPLEFT", 0, -34)
	mv:SetPoint("BOTTOMRIGHT")
	Bd.mktView = mv
	Bd.mItem = UI:Edit(mv, 250, 24, L["Item-Name oder Shift-Klick auf ein Item"])
	Bd.mItem:SetPoint("TOPLEFT")
	UI:AcceptLinks(Bd.mItem)
	Bd.mCount = UI:Edit(mv, 46, 24, "1")
	Bd.mCount:SetPoint("LEFT", Bd.mItem, "RIGHT", 6, 0)
	Bd.mCount.edit:SetNumeric(true)
	Bd.mPrice = UI:Edit(mv, 80, 24, L["Preis (G)"], false, 8)
	Bd.mPrice:SetPoint("LEFT", Bd.mCount, "RIGHT", 6, 0)
	Bd.mNote = UI:Edit(mv, 190, 24, L["Notiz (optional)"], false, 80)
	Bd.mNote:SetPoint("LEFT", Bd.mPrice, "RIGHT", 6, 0)
	Bd.mPost = UI:Button(mv, "", 170, 24, function() Bd:Post() end, true)
	Bd.mPost:SetPoint("LEFT", Bd.mNote, "RIGHT", 8, 0)
	Bd.mItem.onEnter = function() Bd:Post() end
	Bd.mSearch = UI:Edit(mv, 250, 24, L["Brett durchsuchen"])
	Bd.mSearch:SetPoint("TOPLEFT", Bd.mItem, "BOTTOMLEFT", 0, -8)
	Bd.mSearch.onChange = function(t) Bd.query = t; Bd:Refresh() end
	Bd.mInfo = UI:Label(mv, "", "GameFontHighlightSmall")
	Bd.mInfo:SetPoint("LEFT", Bd.mSearch, "RIGHT", 12, 0)
	Bd.mInfo:SetPoint("RIGHT")
	Bd.mktList = UI:List(mv, {
		{ key = "item", title = L["Item"], icon = true },
		{ key = "c", title = L["Anzahl"], width = 55, align = "CENTER" },
		{ key = "p", title = L["Preis"], width = 110, align = "RIGHT" },
		{ key = "mv", title = L["Marktwert"], width = 110, align = "RIGHT" },
		{ key = "by", title = L["Von"], width = 110 },
		{ key = "t", title = L["Wann"], width = 80 },
	}, {
		rowH = 22,
		key = function(e) return e.id end,
		icon = function(e) return (e.i or 0) > 0 and ns.ItemIcon(e.i) or nil end,
		render = function(e)
			local n, q
			if (e.i or 0) > 0 then
				local _
				n, _, q = ns.Item(e.i)
			end
			local c = q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
			local name = (c and c.hex or "|cffffffff") .. (n or e.n) .. "|r"
			if e.note and e.note ~= "" then name = name .. Gray(" – " .. e.note) end
			if #ns.Board:Matches(e) > 0 then name = name .. " " .. GREEN .. L["(passt!)"] .. "|r" end
			local mvv = ns.Board:MarketValue(e)
			local by = ns.Colored(e.by, ns.G().roster[e.by] and ns.G().roster[e.by].c)
			return { name, tostring(e.c), (e.p or 0) > 0 and ns.Money(e.p) or Gray(L["VB"]), mvv and ns.Money(mvv) or Gray("–"), by, Gray(ns.Ago(e.t)) }
		end,
		onClick = function() Bd:UpdateButtons() end,
		onEnter = function(row, e)
			if (e.i or 0) > 0 then
				GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink("item:" .. e.i)
				GameTooltip:Show()
			end
		end,
		empty = L["Noch nichts auf dem Brett."],
	})
	Bd.mktList:SetPoint("TOPLEFT", 0, -64)
	Bd.mktList:SetPoint("BOTTOMRIGHT", 0, 40)
	Bd.mContact = UI:Button(mv, L["Anflüstern"], 140, 28, function()
		local e = Bd.mktList:Selected()
		if e then ns.Board:Contact(e) end
	end, true)
	Bd.mContact:SetPoint("BOTTOMRIGHT", 0, 4)
	Bd.mRemove = UI:Button(mv, L["Entfernen"], 120, 28, function()
		local e = Bd.mktList:Selected()
		if e then ns.Board:Remove(e.id); Bd.mktList:ClearSelection() end
	end)
	Bd.mRemove:SetPoint("RIGHT", Bd.mContact, "LEFT", -8, 0)
	Bd.mHint = UI:Label(mv, Gray(L["Keine Gildenbank: gehandelt wird direkt zwischen den Spielern. Einträge bleiben 7 Tage."]), "GameFontHighlightSmall")
	Bd.mHint:SetPoint("BOTTOMLEFT", 0, 12)
	Bd.mHint:SetPoint("RIGHT", Bd.mRemove, "LEFT", -12, 0)

	Bd.tabs:Select("svc")
end

function Bd:Post()
	local text = ns.Trim(self.mItem:GetText())
	if text == "" then return end
	local id = ns.ItemID(text)
	local name = text:match("%[(.-)%]")
	if not id then
		local _, link = ns.GetItemInfo(text)
		id = ns.ItemID(link)
		name = text
	end
	local ptext = (self.mPrice:GetText() or ""):gsub(",", ".")
	local gold = tonumber(ptext) or 0
	ns.Board:Post(self.view, id or 0, name or text, tonumber(self.mCount:GetText()) or 1, math.floor(gold * 10000), self.mNote:GetText())
	for _, e in ipairs({ self.mItem, self.mCount, self.mPrice, self.mNote }) do e:SetText("") end
	self.mItem:ClearFocus()
end

function Bd:BuildChecks()
	for _, c in ipairs(self.svcChecks) do c:Hide() end
	local mine = ns.Board:MyServices()
	local offer = ns.Board:MyOffer()
	if offer and not self.selInit then
		for k in pairs(offer.k or {}) do self.sel[k] = true end
		self.selInit = true
	end
	for i, s in ipairs(mine) do
		local c = self.svcChecks[i]
		if not c then
			c = UI:Check(self.svcHolder, "", function() return c and c.key and Bd.sel[c.key] end, function(v) if c and c.key then Bd.sel[c.key] = v end end)
			self.svcChecks[i] = c
		end
		c.key = s.key
		c.text:SetText(L[s.n])
		c:SetHitRectInsets(0, -(c.text:GetStringWidth() + 10), 0, 0)
		c:ClearAllPoints()
		c:SetPoint("TOPLEFT", ((i - 1) % 4) * 195, -math.floor((i - 1) / 4) * 24)
		c.Refresh()
		c:Show()
	end
end

function Bd:UpdateButtons()
	local o = self.svcList:Selected()
	self.svcAsk:SetEnabled(o ~= nil and not ns.Same(o.name, ns.Me()))
	self.svcInvite:SetEnabled(o ~= nil and not ns.Same(o.name, ns.Me()))
	local e = self.mktList:Selected()
	self.mContact:SetEnabled(e ~= nil and not ns.Same(e.by, ns.Me()))
	self.mRemove:SetEnabled(e ~= nil and ns.Board:CanEdit(e))
	self.svcOff:SetEnabled(ns.Board:MyOffer() ~= nil)
end

function Bd:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.svcView:SetShown(self.view == "svc")
	self.mktView:SetShown(self.view ~= "svc")
	if self.view == "svc" then
		self:BuildChecks()
		local offer = ns.Board:MyOffer()
		self.svcHint:SetText(offer and (GREEN .. string.format(L["Dein Angebot läuft bis %s."], date("%H:%M", offer.u)) .. "|r")
			or Gray(L["Klassen-Dienste erkennt GuildSentinel am Zauberbuch."]))
		if not self.svcText.edit:HasFocus() then self.svcText:SetText(offer and offer.x or "") end
		self.svcList:SetData(ns.Board:Offers())
	else
		local list = ns.Board:List(self.view, self.query)
		self.mktList:SetData(list)
		self.mPost:SetText(self.view == "offer" and L["Ich biete an"] or L["Ich suche"])
		local hasAhp = ns.Links:Loaded("AHAnalyzerPro")
		self.mInfo:SetText(Gray(string.format(L["%d Einträge"], #list)) .. (hasAhp and "" or ("  " .. Gray(L["Mit AH Analyzer Pro steht der Marktwert dabei."]))))
	end
	self:UpdateButtons()
end

Bd.onShow = function(_, arg)
	if arg then Bd.tabs:Select(arg) else Bd:Refresh() end
end
ns:Listen("GS_BOARD", WhenShown("board", function() Bd:Refresh() end))
ns:Listen("GS_ROSTER", WhenShown("board", function() if Bd.view == "svc" then Bd:Refresh() end end))
ns:Listen("GS_ITEMS", WhenShown("board", function() if Bd.view ~= "svc" then Bd.mktList:Draw() end end))
ns:Listen("GS_BOARD", function() UI:RefreshHeader() end)
UI:AddPage(Bd)

------------------------------------------------------------
-- Seite: Addons (Addon's by GoldSentinel)
------------------------------------------------------------
local Ad = { key = "addons", order = 85, icon = "Interface\\Icons\\INV_Misc_Gear_08" }
Ad.title = N["Addons"]

function Ad.build(p)
	Ad.panel = p
	local h = UI:Header(p, L["Addon's by GoldSentinel"])
	h:SetPoint("TOPLEFT", 0, 0)
	local hint = UI:Label(p, Gray(L["GuildSentinel arbeitet mit allen Addons von GoldSentinel zusammen. Hier siehst du, was du installiert hast – und wer in der Gilde welches Addon nutzt."]), "GameFontHighlightSmall")
	hint:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	hint:SetWidth(780)
	Ad.rows = {}
	for i, a in ipairs(ns.Links.LIST) do
		local r = CreateFrame("Frame", nil, p, UI.BACKDROP)
		r:SetHeight(64)
		r:SetPoint("TOPLEFT", 0, -46 - (i - 1) * 70)
		r:SetPoint("RIGHT")
		UI.Box(r, 0.07, 0.08, 0.11, 1, 0.18, 0.2, 0.25, 1)
		r.name = UI:Label(r, a.name, "GameFontNormalLarge")
		r.name:SetPoint("TOPLEFT", 12, -8)
		r.state = UI:Label(r, "", "GameFontHighlightSmall")
		r.state:SetPoint("LEFT", r.name, "RIGHT", 10, 0)
		r.what = UI:Label(r, "", "GameFontHighlightSmall")
		r.what:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -4)
		r.what:SetWidth(560)
		r.users = UI:Label(r, "", "GameFontDisableSmall")
		r.users:SetPoint("TOPLEFT", r.what, "BOTTOMLEFT", 0, -3)
		r.users:SetWidth(560)
		r.users:SetWordWrap(false)
		r.open = UI:Button(r, L["Öffnen"], 110, 26, function() if not ns.Links:Open(a.key) then ns:Print(L["Konnte das Addon nicht öffnen."]) end end, true)
		r.open:SetPoint("RIGHT", -12, 0)
		r.key = a.key
		Ad.rows[i] = r
	end
end

-- was GuildSentinel mit dem Addon macht
local USES = {
	RaidMaster = N["Berufe, Twinks, Rollen aus der Skillung, nächster Raid bei den Terminen, Erstkills als Meilensteine"],
	AHAnalyzerPro = N["Marktwert bei Biete/Suche und bei den Abklingzeiten der Berufe"],
	BuffSentinel = N["erkennt deine Klassen-Dienste fürs Brett (Portale, Beschwören, Schlösser knacken …)"],
	ThreatSentinel = N["deine Rolle (Tank in Verteidigungshaltung / Bärengestalt) für Aufstellung und Gruppensuche"],
	LevelPilot = N["Elite-Quests aus deinem Questlog für die Gruppensuche, Mitspieler mit derselben Quest"],
}

function Ad:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	local usage = {}
	for _, u in ipairs(ns.Links:Usage()) do usage[u.key] = u end
	for _, r in ipairs(self.rows) do
		local u = usage[r.key]
		local mine = u and u.mine
		if mine then
			r.state:SetText(GREEN .. "v" .. mine .. "|r" .. ((u.newest and u.newest ~= mine) and (" " .. ORANGE .. string.format(L["(neuer: %s)"], u.newest) .. "|r") or ""))
		else
			r.state:SetText(Gray(L["nicht installiert"]))
		end
		r.what:SetText((u and u.what or "") .. Gray(" – " .. L[USES[r.key]]))
		local names = {}
		for _, x in ipairs(u and u.users or {}) do
			names[#names + 1] = (x.old and ORANGE or "") .. x.name .. " " .. x.v .. (x.old and "|r" or "")
		end
		r.users:SetText(#names > 0 and (string.format(L["In der Gilde (%d): "], #names) .. table.concat(names, ", ")) or L["In der Gilde: noch niemand bekannt"])
		r.open:SetEnabled(mine ~= nil)
	end
end

Ad.onShow = function()
	if IsInGuild() and (not Ad.lastQ or GetTime() - Ad.lastQ > 300) then
		Ad.lastQ = GetTime()
		ns.Comm:Send("ADDONSQ", {})
	end
	Ad:Refresh()
end
ns:Listen("GS_ADDONS", WhenShown("addons", function() Ad:Refresh() end))
UI:AddPage(Ad)
