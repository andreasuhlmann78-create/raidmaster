-- GuildSentinel - Progress.lua
-- Fortschritt der Gilde:
--   * Leveling-Rennen: Rangliste nach Stufe (wer zuerst da war, steht vorne), Stufen der letzten 7 Tage,
--     Meilensteine im Gildenchat (10, 20, 30, 40 = Reittier, 50, 60) und "Erster der Gilde auf 60".
--     Die Stufen kommen aus der Gildenliste – dafür braucht niemand das Addon.
--   * Raid-Zugänge und Dungeon-Schlüssel: Jeder mit GuildSentinel liest seine abgeschlossenen Zugangsquests
--     und Schlüssel (Taschen, Bank, Schlüsselbund) und teilt sie.
--   * Jubiläen: 1, 3, 6 Monate, 1 und 2 Jahre in der Gilde – Glückwunsch im Gildenchat.
-- Ansagen macht immer nur einer (ns.Claim), auch wenn viele das Addon haben.

local ADDON, ns = ...
local L = ns.L
local N = ns.N

------------------------------------------------------------
-- Leveling-Rennen
------------------------------------------------------------
local Race = {}
ns.Race = Race

Race.MILESTONES = { 10, 20, 30, 40, 50, 60 }

-- Zeitpunkt, an dem jemand eine Stufe erreicht hat (nil/0 = unbekannt)
function Race:LevelTime(name, level)
	local lv = ns.G().levels[name]
	local t = lv and lv[level]
	return (t and t > 0) and t or nil
end

-- Stufe vor x Tagen (soweit bekannt)
function Race:LevelAt(name, t)
	local lv = ns.G().levels[name]
	if not lv then return nil end
	local best
	for l, when in pairs(lv) do
		if when and when > 0 and when <= t and (not best or l > best) then best = l end
	end
	return best
end

-- Rangliste: { { name, class, level, t, gain } } – höchste Stufe zuerst, bei gleicher Stufe wer zuerst da war
function Race:Ranking(mainsOnly)
	local out = {}
	local weekAgo = ns.Now() - 7 * 86400
	for _, e in ipairs(ns.Roster.list) do
		if not mainsOnly or not ns.Roster:IsAlt(e.name) then
			local t = self:LevelTime(e.name, e.level)
			local before = self:LevelAt(e.name, weekAgo)
			out[#out + 1] = {
				name = e.name, class = e.class, level = e.level, t = t, online = e.online,
				gain = before and (e.level - before) or nil,
			}
		end
	end
	table.sort(out, function(a, b)
		if a.level ~= b.level then return a.level > b.level end
		if (a.t ~= nil) ~= (b.t ~= nil) then return a.t ~= nil end
		if a.t and b.t and a.t ~= b.t then return a.t < b.t end
		return a.name < b.name
	end)
	for i, x in ipairs(out) do x.rank = i end
	return out
end

function Race:First60()
	return ns.G().race.first60
end

-- Meilenstein-Text
function Race:MilestoneText(name, level, first)
	if first then return string.format(L["%s ist das erste Gildenmitglied auf Stufe %d – herzlichen Glückwunsch!"], name, level) end
	if level >= ns.Roster.MAX_LEVEL then return string.format(L["%s hat die Maximalstufe %d erreicht – herzlichen Glückwunsch!"], name, level) end
	if level == 40 then return string.format(L["%s hat Stufe 40 erreicht – Zeit fürs erste Reittier! Glückwunsch!"], name) end
	return string.format(L["%s hat Stufe %d erreicht – Glückwunsch!"], name, level)
end

ns:Listen("GS_LEVEL", function(name, old, new, live)
	local g = ns.guild
	if not g then return end
	-- "Erster auf 60" merken (nur wenn sonst noch niemand 60 ist)
	local max = ns.Roster.MAX_LEVEL
	local first = false
	if new >= max and old < max and not g.race.first60 then
		local others = 0
		for _, e in ipairs(ns.Roster.list) do
			if e.level >= max and e.name ~= name then others = others + 1 end
		end
		if others == 0 then
			g.race.first60 = { n = name, t = ns.Now() }
			first = true
		end
	end
	if not live or not ns.db.annLevels or ns.Roster:IsAlt(name) then return end
	-- höchsten überschrittenen Meilenstein ansagen
	local m
	for _, lvl in ipairs(Race.MILESTONES) do
		if old < lvl and new >= lvl and ns.db.annMilestones[lvl] then m = lvl end
	end
	if first and ns.db.annFirst then m = new end
	if not m then return end
	local key = "lvl:" .. name .. ":" .. m
	if g.ann[key] then return end
	ns.Claim(key, function()
		g.ann[key] = ns.Now()
		ns.Announce(Race:MilestoneText(name, m, first and ns.db.annFirst))
	end)
end)

------------------------------------------------------------
-- Jubiläen
------------------------------------------------------------
local Jub = {}
ns.Jubilee = Jub

Jub.STEPS = { { m = 1, key = "1m" }, { m = 3, key = "3m" }, { m = 6, key = "6m" }, { m = 12, key = "1y" }, { m = 24, key = "2y" } }
Jub.WINDOW = 7 * 86400     -- so lange nach dem Tag wird noch gratuliert (falls er erst später online ist)

function Jub:JoinDate(name)
	local g = ns.G()
	local f = g.firstSeen[name]
	local r = g.roster[name]
	if r and r.first and r.first > 0 and (not f or r.first < f) then f = r.first end
	return (f and f > 0) and f or nil
end

-- Datum + Monate (Kalendermonate, Tag bleibt)
function Jub:AddMonths(t, months)
	local d = date("*t", t)
	d.month = d.month + months
	return time(d)
end

function Jub:StepText(m)
	if m == 1 then return L["einem Monat"] end
	if m == 3 then return L["drei Monaten"] end
	if m == 6 then return L["einem halben Jahr"] end
	if m == 12 then return L["einem Jahr"] end
	return L["zwei Jahren"]
end

-- fällige Jubiläen: { { name, m, key } }
function Jub:Due(now)
	now = now or ns.Now()
	local out = {}
	for _, e in ipairs(ns.Roster.list) do
		local join = self:JoinDate(e.name)
		if join and e.online and not ns.Roster:IsAlt(e.name) then
			for _, st in ipairs(self.STEPS) do
				local at = self:AddMonths(join, st.m)
				if now >= at and now - at <= self.WINDOW then
					out[#out + 1] = { name = e.name, m = st.m, key = "jub:" .. e.name .. ":" .. st.key }
				end
			end
		end
	end
	return out
end

function Jub:Check()
	local g = ns.guild
	if not g or not ns.db.annJubilee then return end
	for _, j in ipairs(self:Due()) do
		if not g.ann[j.key] then
			ns.Claim(j.key, function()
				g.ann[j.key] = ns.Now()
				ns.Announce(string.format(L["%s ist seit %s in der Gilde <%s> – danke, dass du dabei bist!"], j.name, self:StepText(j.m), ns.GuildName() or ""))
			end)
		end
	end
end

ns:Listen("GS_LOGIN", function()
	C_Timer.After(90, function() Jub:Check() end)
end)
C_Timer.NewTicker(1800, function() Jub:Check() end)

-- angesagt hat jemand anderes: merken (damit es nach dem Neuladen nicht noch einmal kommt)
ns:Listen("GS_CLAIM", function(key)
	local g = ns.guild
	if g and type(key) == "string" and (key:find("^lvl:") or key:find("^jub:")) then g.ann[key] = g.ann[key] or ns.Now() end
end)

-- alte Ansagen nach einem Jahr vergessen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = ns.Now() - 400 * 86400
	for k, t in pairs(g.ann) do if t < limit then g.ann[k] = nil end end
end)

------------------------------------------------------------
-- Raid-Zugänge
------------------------------------------------------------
local Att = {}
ns.Attune = Att

-- Zugangsquests (Classic). Mehrere IDs: eine davon reicht (z. B. Horde / Allianz).
Att.LIST = {
	{ key = "ubrs", short = "UBRS", name = N["Obere Schwarzfelsspitze"], quests = { 4743 }, items = { 12344 }, level = 55 },   -- Siegel des Aufstiegs
	{ key = "mc", short = "MC", name = N["Geschmolzener Kern"], quests = { 7848 }, level = 55, raid = true },                -- Einstimmung auf den Kern
	{ key = "ony", short = "Ony", name = N["Onyxias Hort"], quests = { 6602, 6502 }, items = { 16309 }, level = 55, raid = true }, -- Blut des schwarzen Großdrachen (H) / Drachenfeueramulett (A)
	{ key = "bwl", short = "BWL", name = N["Pechschwingenhort"], quests = { 7761 }, level = 58, raid = true },               -- Schwarzfausts Befehl
	-- Dungeon-Schlüssel (Gegenstand in Taschen, Bank oder Schlüsselbund)
	{ key = "brdkey", short = "BRD", name = N["Schattenschmiedeschlüssel"], items = { 11000 }, level = 50, isKey = true },
	{ key = "scholokey", short = "Scholo", name = N["Schlüssel zur Scholomance (Skelettschlüssel)"], items = { 13704 }, level = 55, isKey = true },
	{ key = "dmkey", short = "DM", name = N["Mondsichelschlüssel (Düsterbruch)"], items = { 18249 }, level = 55, isKey = true },
	{ key = "stratkey", short = "Strat", name = N["Schlüssel zur Stadt (Stratholme)"], items = { 12382 }, level = 55, isKey = true },
}

local function QuestDone(id)
	if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then return C_QuestLog.IsQuestFlaggedCompleted(id) and true or false end
	if IsQuestFlaggedCompleted then return IsQuestFlaggedCompleted(id) and true or false end
	return false
end

local function HasItem(id)
	local fn = (C_Item and C_Item.GetItemCount) or GetItemCount
	return fn and (fn(id, true) or 0) > 0
end

function Att:Mine()
	local k = {}
	for _, a in ipairs(self.LIST) do
		for _, q in ipairs(a.quests or {}) do
			if QuestDone(q) then k[a.key] = true break end
		end
		if not k[a.key] then
			for _, id in ipairs(a.items or {}) do
				if HasItem(id) then k[a.key] = true break end
			end
		end
	end
	return k
end

function Att:Scan(force)
	local g = ns.guild
	if not g then return end
	local k = self:Mine()
	local old = g.attune[ns.Me()]
	local changed = not old
	if old then
		for _, a in ipairs(self.LIST) do
			if (old.k[a.key] and true or false) ~= (k[a.key] and true or false) then changed = true end
		end
	end
	if changed or force then
		g.attune[ns.Me()] = { t = ns.Now(), k = k }
		ns.Comm:Send("ATT", { k = k, t = ns.Now() })
		ns:Fire("GS_ATTUNE")
	end
end

function Att:Store(name, t, k)
	local g = ns.guild
	if not g or type(k) ~= "table" or type(t) ~= "number" or ns.Same(name, ns.Me()) then return false end
	local old = g.attune[name]
	if old and (old.t or 0) >= t then return false end
	local clean = {}
	for _, a in ipairs(self.LIST) do if k[a.key] then clean[a.key] = true end end
	g.attune[name] = { t = t, k = clean }
	return true
end

ns.Comm:Register("ATT", function(sender, d)
	if Att:Store(sender, d.t, d.k) then ns:Fire("GS_ATTUNE") end
end)

-- beim Abgleich: viele auf einmal
ns.Comm:Register("ATTS", function(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for name, v in pairs(d.e) do
		if type(name) == "string" and type(v) == "table" and Att:Store(name, v.t, v.k) then any = true end
	end
	if any then ns:Fire("GS_ATTUNE") end
end)

-- true = hat den Zugang, false = hat ihn nicht, nil = unbekannt (kein Addon)
function Att:Status(name, key)
	local a = ns.G().attune[name]
	if not a then return nil end
	return a.k[key] and true or false
end

-- Tabelle für die Anzeige: Mitglieder ab Stufe minLevel
function Att:Rows(minLevel, mainsOnly)
	local out = {}
	for _, e in ipairs(ns.Roster.list) do
		if e.level >= (minLevel or 0) and (not mainsOnly or not ns.Roster:IsAlt(e.name)) then
			out[#out + 1] = { name = e.name, class = e.class, level = e.level, online = e.online, known = ns.G().attune[e.name] ~= nil }
		end
	end
	table.sort(out, function(a, b)
		if a.known ~= b.known then return a.known end
		if a.level ~= b.level then return a.level > b.level end
		return a.name < b.name
	end)
	return out
end

-- Zusammenfassung je Zugang: hat / hat nicht / unbekannt
function Att:Summary(rows)
	local s = {}
	for _, a in ipairs(self.LIST) do s[a.key] = { yes = 0, no = 0, unknown = 0 } end
	for _, r in ipairs(rows) do
		for _, a in ipairs(self.LIST) do
			local st = self:Status(r.name, a.key)
			if st == true then s[a.key].yes = s[a.key].yes + 1
			elseif st == false then s[a.key].no = s[a.key].no + 1
			else s[a.key].unknown = s[a.key].unknown + 1 end
		end
	end
	return s
end

ns:Listen("GS_LOGIN", function() C_Timer.After(15, function() Att:Scan(true) end) end)
ns:On("QUEST_TURNED_IN", function() C_Timer.After(2, function() Att:Scan() end) end)
ns:On("BAG_UPDATE_DELAYED", function()
	if Att.bagPending then return end
	Att.bagPending = true
	C_Timer.After(5, function() Att.bagPending = false; Att:Scan() end)
end)
