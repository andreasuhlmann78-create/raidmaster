GuildSentinel 0.9.59 – guild tool for Classic Era, WoW Forever and Burning Crusade Classic
=====================================================================================

INSTALLATION
- Copy the folder "GuildSentinel" into your AddOns folder (...\Interface\AddOns\GuildSentinel).
  When updating, replace the old folder – your saved data is kept.
- Open it with the minimap button (left-click) or /gs. Everything works with the mouse.
- The more guild members use the addon, the more complete everything gets. Data syncs automatically on login.

LANGUAGE
- On start GuildSentinel uses the language of your game client: English, German, French, Spanish (ES/MX), Italian,
  Portuguese (BR), Russian, Korean, Chinese (simplified/traditional).
- Settings > Options > General > "Language": choose another language (German, English, French, Spanish, Italian, Portuguese;
  Russian, Korean and Chinese only on a client in that language). "Same as the game client" goes back.

NEW IN 0.9.59
- The same guild on different home realms (WoW Forever) is now ONE guild: old guild data is merged once.
- The Members page opens without stutter; text placeholders as a small "Placeholders (?)" button with explanations in the tooltip.
- Easier to read: selected row with an accent stripe, brighter version number; "Who's free" fits the window in every language.

NEW IN 0.9.58
- Large guilds (100+ members): the member list is read in small portions – no more stutter every 30 seconds.
- Title bar on the right redone: flat close X, "Support" as a small icon.

NEW IN 0.9.57
- New options (Settings > Options): sections on the left, only their options on the right in one column, a search box on top. Every option in exactly one place, the explanation is in the tooltip. Your settings stay as they were.

NEW IN 0.9.56
- Weekly review and milestones: only real first kills (with raid log); nothing from other addons' test routines. Wrong entries are removed once. "1 new member" instead of "1 new members".

NEW IN 0.9.55
- More robust with damaged guild data (no Lua error during sync).

NEW IN 0.9.54
- Faster in large guilds (inactive); full texts in tooltips for edit boxes; numbers never cut off in any language.

NEW IN 0.9.53
- Tooltips no longer cover buttons (shown next to the window); numbers and times in tables are never cut off.

NEW IN 0.9.52
- Fix: guild masters and officers can promote, demote and remove from the right-click menu again.

NEW IN 0.9.51
- Developer only: /gs testroutine alles and a clearer checklist. No change for players.

NEW IN 0.9.50
- Developer only: in-game checklist (/gs checklist). No change for players.

NEW IN 0.9.49
- Shared file GoldSentinelDev version 2 (privacy, no change for players).

NEW IN 0.9.48
- /gs clienttest: small fix (the ban list check leaves everything exactly as before).

NEW IN 0.9.47
- /gs clienttest: guided in-game test, four short questions, result in /gs log.

NEW IN 0.9.46
- The window opens much faster the first time (pages are built when you select them).

NEW IN 0.9.45
- Members returning after 30 days are reported (history, chat for officers).
- Note changes (public, officer note) appear in the history with old → new.

NEW IN 0.9.44
- Ban list for officers (Leadership > Ban list): no automatic reply, inviting blocked, warning on join. Banned players
  never get a message from GuildSentinel.

NEW IN 0.9.43
- Ages stated in applicant messages are made unreadable before they are stored.
- Option "Delete closed applications after 90 days" (on by default).

NEW IN 0.9.42
- Tooltip for guild members: in the guild since when, and last rank change.
- Closed applications are deleted automatically after 90 days (open ones stay).

NEW IN 0.9.41
- Applicants who were not contacted automatically because of the limit show "whisper yourself" on the Recruitment page –
  until you whisper them yourself.

NEW IN 0.9.40
- Protection against whisper floods: automatic replies to strangers go to at most 5 new applicants in 10 minutes; beyond
  that only a hint in your own chat. Known applicants no longer get the fixed reply text again every 10 minutes.
- Market data network version 7: much less memory and no long stutter when passing on a scan.

NEW IN 0.9.39
- Recruitment: "Choose suggestion" offers several ready-made ad texts (short, friendly, build-up, raid, with Discord tag,
  without Discord …) – each ends with "– whisper me: /w <name> guild". This part is never cut when shortening; if your
  own text lacks it, a hint offers to append it.

NEW IN 0.9.38
- Market data network version 2: no more stutter during AHSentinel's full scan. The "Share market data" tick shows the real state.

NEW IN 0.9.37
- Market data network: GuildSentinel quietly reads along auction house full scans of other addons (prices only, no
  names) and shares them anonymously. Turn off under Settings > "Share market data (anonymous, prices only)".
- The age block now also applies to Guild management > Invite.

NEW IN 0.9.36
- Applications: age question "How old are you?" asked last (minimum age adjustable, default 16, 0 = off). Below the
  minimum age a friendly whisper declines and inviting is blocked; unclear answers are left to an officer. Only
  "16+" / "under 16" / "unclear" is stored, never the age.
- Ad: in phase Build-up the default text names it ("… is being built up and is looking for players of all classes").
  New placeholder {phase}. Own text without {wanted}: hint with "Apply". Preview right above the button.

NEW IN 0.9.35
- The Discord bot now also learns about an open recruitment phase suggestion (no names).

NEW IN 0.9.34
- Command list while typing: /gs in chat shows all commands with a description, every letter filters, most used on
  top. Click or Tab selects, Enter runs it. Can be turned off in the settings.

NEW IN 0.9.33
- Fix: the button in the "Guild action" window now works when "Cast action keybinds on key down" is turned off.

NEW IN 0.9.32
- Thorough tests in /gs testroutine: situations (1 to 500 members, rights, first and last names, no guild), player-like
  flows, default values, 1000 random cases for the basic rules and a report per area. No visible changes.

NEW IN 0.9.31
- Recruitment in phases (Members > Line-up): Build-up – the ad looks for "players of all classes"; Transition –
  "all classes, especially …"; Raid – the gaps of the line-up. Default: Build-up. The line-up targets stay unchanged
  and apply from phase Raid.
- Raid readiness for a target raid: "Raid-ready (Onyxia's Lair): 23 of 40 active at level 55+ · Tanks 2/4 · Healers 5/10"
  with an estimate. From 60 % / 100 % officers get a suggestion – the phase only changes after an officer confirms.
- Milestone "Guild is raid-ready" in the chronicle (announcement can be turned off).

NEW IN 0.9.30
- Right-click a member (Members, Who is where, Applicants, Leadership): whisper, group invite, promote, demote, set rank
  (step by step), assign alt, note, officer note, absence, thanks, mentor, remove, guild leadership. What your rank may
  not do is shown in grey with the reason.
- Promote, demote, remove and guild leadership go through the "Guild action" window: you click its button and Blizzard's
  own command carries it out (the game forbids addons to call them directly). Done only once the game confirms it.
  Shift/Ctrl-click selects several members – one click per member.
- Promotion: option "Suggest the main's rank for alts". Leadership > Rank rights: button "Edit ranks in the game".

NEW IN 0.9.29
- "Invite to guild" puts "/ginvite <name>" into the chat input, you invite with Enter (WoW Forever forbids addons
  to invite directly). "Invited" only once the game confirms the invite.

NEW IN 0.9.28
- Ad: "Suggestion 2" button with your Discord server tag ({tag}, field "Server tag"); tip about permanent Discord invites.

NEW IN 0.9.27
- Russian ad: capital letter at the start of the sentence.

NEW IN 0.9.26
- Ad: capital letter after a removed Discord part; an unchanged old default text is replaced by the new one.

NEW IN 0.9.25
- New default recruitment ad with {fraktion}; {gesucht} is only the list; without Discord "Discord: …" disappears.
  Your own ad texts stay unchanged.

NEW IN 0.9.24
- Recruitment ad: long texts fit into the chat input (at most 251 characters) and count after sending.

NEW IN 0.9.23
- Recruitment ad: "Prepare ad" puts the text into the chat input, you send it with Enter (WoW Forever blocks addons
  from writing into channels).

NEW IN 0.9.22
- Professions page: click a member to see their recipes, with a filter bar by type (Blacksmithing: Head, Chest,
  Hands, Weapons …; Alchemy: Elixirs, Healing potions, Rejuvenation potions, Transmutes …; Enchanting by slot).

NEW IN 0.9.21
- Whisper network (GoldSentinelSync 2): the group finder "whole server" reaches players of other guilds again. Only
  the group finder goes into the network, everything else stays in the guild.
- Share error reports with the developer – only with your consent (/gstest).

NEW IN 0.9.20
- Addon messages only through guild, group/raid and whispers (shared sync file) – no custom channel any more, works in
  all game versions. Please everybody update to 0.9.20.
- Group finder "Guild and group" instead of "whole server"; recruitment ads only in Blizzard channels; /gs sync test.
- Professions: while levelling, sent at most every 5 minutes; offline members read more reliably.

NEW IN 0.9.19
- Professions arrive automatically in both directions: your own professions are always sent by GuildSentinel (also
  with RaidMaster), names are matched the same way everywhere, every member sends their own after logging in.
- Fully automatic: guild profession list with offline members, new recipes right away, recipe check without the
  window, Blizzard's guild recipes (where allowed).
- Professions page: "2 guild members have …", "1 of 4", "Recipes unknown", "+2 more according to the game".

NEW IN 0.9.18
- Professions of all members: collapsed professions in the game's guild profession list are now opened briefly and
  read (not in combat, not while the guild window is open). Otherwise the Professions page shows the count per profession.
- Guild management: the right game function on every client; the button no longer covers Blizzard's guild pop-ups.

NEW IN 0.9.17
- Guild management for guild leadership and officers: button "Management (GuildSentinel)" next to the guild window
  (J) or /gs verwaltung. Invite, promote, demote, remove (with confirmation) – following your rights in the game.
  Hand over leadership only as Guild Master and only with a password (set twice; 3 failed attempts lock it for
  5 minutes). The password protects against accidental clicks and is stored only as a checksum on your PC.

NEW IN 0.9.16
- Professions of all members automatically: where the game knows the guild's professions, GuildSentinel reads the
  skill levels of every member – also without the addon. Recipes still come only from players with GuildSentinel
  who have opened their profession window once (WoW does not allow anything else).
- New members share their professions right after joining.

NEW IN 0.9.15
- Diagnostic log: /gs protokoll shows what went wrong in the game (slow pages, blocked actions, errors – no names).
  The RaidMaster uploader sends it to the developer.

NEW IN 0.9.14
- Big guilds: Overview and Leadership no longer stutter with hundreds of members.
- Professions button on WoW Forever: no more "action blocked"; if the window does not open, you get a hint.
- Achievements/Chronicle: damaged profession data no longer breaks the page.

NEW IN 0.9.13
- Language selectable for everyone under Settings > General (on start GuildSentinel still uses the client language).

NEW IN 0.9.12
- Developer only: language switch for screenshots under Settings > Test mode (replaced in 0.9.13).

NEW IN 0.9.11
- Bank character: stock to Discord (optional, off by default). On your guild's bank character, tick
  "Bank character (stock to Discord)" under Settings > General. Opening the bank, the mailbox and – where the game
  has one – the guild bank then reads the stock (read only, never in combat). The RaidMaster uploader sends it with
  the next upload, and the RaidMaster bot shows it in #gildenbank and with /bank.
- Alt notes with first and last names on Korean and Chinese clients are recognised again.
- Changing the main removes the old alt label completely (also "Alt: First Last" and "Reroll de …").
- Event sync: one damaged entry no longer discards the other events.

NEW IN 0.9.10
- Alt notes in your client language: notes that GuildSentinel writes itself ("Reroll de …", "… 的分身" etc.) are
  recognised again on French, Spanish, Italian, Portuguese, Korean and Chinese clients. If the label does not fit
  into the short guild note (Russian), GuildSentinel writes "Alt: Name".
- AHSentinel (formerly AH Analyzer Pro) is recognised under its new folder name.
- Applicant whispers in combat (WoW Forever): more than 30 whispers in one fight are counted in the notice.
- More robust against damaged data (event sync, events, thanks).
- Test mode (developer only): no server channel, nothing delayed after stopping, real settings stay untouched.
  New: /gs testroutine or the "Test everything" button with a report for the review. Nothing changes for players.

NEW IN 0.9.9 (fixes from the review)
- Officer rights: players who may only read officer notes no longer count as officers (assigning mentors and
  reporting absence for others stay with the leadership).
- Applicant whispers in combat (WoW Forever): if a message stays protected after combat, GuildSentinel reports once
  how many could not be read – nothing is lost silently any more.
- Player tooltip: the combat lock applies to every modern client (WoW Forever, Retail).
- Absence and thanks from others are only accepted when the sender matches exactly.

NEW IN 0.9.8
- Shared game-version detection (GoldSentinelGame.lua) updated to version 2: it also wins over early, withdrawn
  copies that other GoldSentinel addons briefly shipped. Nothing changes for players.

NEW IN 0.9.7
- Built in the shared game-version detection of all GoldSentinel addons (GoldSentinelGame.lua): Classic Era, WoW
  Forever and TBC are detected the same way everywhere, with the shared guard against secret values in combat and
  the first/last name comparison. /gsgame shows what was detected. Nothing changes for players.

NEW IN 0.9.5
- WoW Forever: protection against "secret values" in combat (player tooltip, addon messages, cooldowns). Applicants
  who whisper during combat are added after combat instead of being lost.
- First and last names (WoW Forever): names are written correctly ("Testa Beispiel"), notes like "Alt of Testa
  Beispiel" are recognised, and a unique first name alone is enough (alts, thanks, mentor).
- Whispering "First Last" opens the whisper box for the full name.
- Modern APIs first (C_ChatInfo, C_GuildInfo, C_SpellBook), the old ones as fallback.

NEW IN 0.9.4
- Without a guild: instead of empty pages the overview shows a hint. GuildSentinel is a guild tool – members, events,
  board, polls, progress, professions, recruitment and group finder appear as soon as you are in a guild. Without a
  guild, My week, Addons and Settings remain. Joining or leaving takes effect right away.

NEW IN 0.9.3
- Guild name: the guild master can set a name for GuildSentinel under Leadership > Rank rights. It applies to everyone
  in the guild with the addon (ad {guild}, chronicle, rules, welcome guide, header). Empty = name from the game. Only
  the guild master can change it; messages from anyone else are ignored.

NEW IN 0.9.2
- Professions on WoW Forever: GuildSentinel now also reads the new (retail-style) profession window. The game client
  decides which way is used: WoW Forever the new window, Classic Era and TBC the classic one as before. Linked
  professions, guild professions and NPC windows are not read.
- The "Open next profession" button opens the new window directly on WoW Forever if needed.
- Settings > Test mode (developer only) shows the game client and profession window ("modern (Forever)" / "classic").

NEW IN 0.9.1
- Test mode is now developer-only: the Settings > Test mode tab and /gs test only appear for the developer account
  (shared detection of all GoldSentinel addons, GoldSentinelDev). Nothing else changes for everyone else.

NEW IN 0.9.0
- Group finder > Who's free: one click flags you as free for dungeon, raid, quest group or PvP (1, 2 or 4 hours).
  Everyone with GuildSentinel sees who is free – with level, item level and zone. In dungeons, raids and
  battlegrounds you automatically show as busy. After posting a search, GuildSentinel tells you how many are free.
- "I'll join" sends your item level: the searcher sees it in the replies and in chat.
- Leadership > Bulk actions (officers): remove inactive players by rule (offline 30–365 days, from which rank,
  keep max level) or promote several suggestions at once. Always a checklist first; the game only allows one step
  per click, so each click on "Next" performs exactly one.
- Leadership > GRM import: take over alts, join dates and personal notes from Guild Roster Manager
  (GRM must be enabled). Preview first; anything already in GuildSentinel stays.

NEW IN 0.8.3
- “Support” button at the top of the window (next to Close) and in Settings > General: shows the PayPal link
  to copy. Also with /gs donate. Only opens when you click it – no reminders, no ads in chat.

NEW IN 0.8.2
- Guild achievements: singular for the first weekly goal; names that are too long use a smaller font instead of being cut off.
- Professions: old raw-material entries from earlier versions (e.g. Felweed as "Alchemy") are removed when opened.

NEW IN 0.8.1
- Settings > Features: three columns, all switches and the button fit into the window.
- Leadership > Probation: "Promote" only with at least 40 % online days since joining (at least 3); percentage in the list.
- Leadership > Rank rights: test mode shows the test guild's ranks.
- Overview: departures count the same as Leadership > Departures; shorter "players online" text; hidden tiles leave no gap.
- My week: singular ("1 elixir"), clear markers (green + ready, orange ! missing), resistances on their own line.
- Chronicle: no duplicate entries, reported departures included; Discord export starts at the top.
- Guild achievements: wider name column.
- Loot wishes: dungeon preselected for your level, visible hint without a dungeon.
- Questions: "Remove" asks first; shorter field, "Show solved" fits.
- Addons page: heading "Addons by GoldSentinel".
- Professions: raw materials (e.g. Felweed) are removed from the watch list.
- Test mode: "Guild milestone" adds new max-level members instead of changing test characters.

NEW IN 0.8.0
- All game languages: German, English, French, Spanish (Spain and Mexico), Italian, Portuguese (Brazil), Russian,
  Korean, Chinese (simplified and traditional). The language always follows the game client – there is no language
  setting any more.
- Overview (new start page): guild health at a glance – active players vs. last month, joins and departures, who will
  soon be inactive, open applicants, probations due, weekly goal, next event and "For you" (events without your reply,
  polls, crafting requests, open questions). Click a tile to open the page.
- Leadership (officers only):
  * Probation: online days, events attended and thanks since joining; when it ends: "Promote" or "Talk".
  * Suggest mentor: who is online at similar times as the newcomer.
  * Departures with reason: date, last level, rank, reason ("moved to guild X").
  * Officer notes with history: longer, dated entries per player – only sent to officers with GuildSentinel.
  * Rank rights: which rank may do what (names from the game; the game only shows them to the guild leadership).
- My week: saved raids and heroic dungeons per character with time left, dailies today; raid prep (attunements,
  flasks/elixirs/potions, class reagents, durability, resistances).
- Board > Loot wishes: who needs what from which dungeon – the group finder shows "3 with loot wish".
- Board > Questions: "Who knows …?" – answers; "Helped" gives the writer a thanks point.
- Progress > Achievements (guild achievements with progress bars) and Chronicle (timeline, export for Discord).
- Weekly recap in guild chat after the Wednesday reset (can be turned off).
- Welcome guide for new members (once): key rules, mentor, commands.
- Test mode: "Click through everything" opens every page and tab and triggers all events.
- Improved: Escape closes an open dropdown first; watched recipes take the profession from the item data (herbs and
  ores are rejected); unknown ad placeholders are marked red; the level-up test event raises exactly one character by
  one level.

NEW IN 0.7.0
- Runs in all Classic clients: Classic Era (1.15), WoW Forever (1.60, paladins and shamans on both
  factions) and Burning Crusade Classic /
  Anniversary (2.5). In TBC GuildSentinel knows level 70, paladins and shamans on both factions, 25-player raids,
  the Outland dungeons, attunements (Karazhan, Serpentshrine, Tempest Keep, Hyjal, Black Temple), dungeon and
  heroic keys, portals to Silvermoon/Exodar/Shattrath, primal mooncloth, shadowcloth and spellcloth, TBC raid
  recipes and the first mount at 30.
- WoW Forever: the group finder knows the 9 new dungeons (Hall of Thanes to Shaper's Terrace) and the raids
  Barrow Deeps (10), Hyjal Summit (20) and Onyxia's Lair (40), sorted by level.
- Group finder with zone: every search and every reply shows where the player currently is.
- Long selection lists (e.g. all dungeons) are shown in several columns.
- Turn features on and off (Settings > Features): whatever is off disappears from the window, sends nothing and
  accepts nothing – e.g. board, events, thanks, cooldowns, mentors …
- Test mode (developer only, Settings > Test mode or /gs test): fills GuildSentinel with a made-up guild so you can try everything
  – even on your own. Buttons trigger events (new event, matching offer, alt in guild chat, level-up, milestone,
  applicant …). Nothing is sent in test mode; whatever would go to chat is shown with [Test] in your chat window.
  Your real data stays untouched.
- Fixed: error when showing prices on the board and market values for cooldowns.

NEW IN 0.6.0
- Who's where (Members > Who's where): all online members by zone, your zone on top – for meeting up, summoning
  and world bosses. Anyone currently offering portals or summons is shown too.
- Board (/gs board):
  * Services: mages (portals, food), warlocks (summoning, soulstone), rogues (lockpicking), enchanters – tick,
    "Offer", everyone sees it. Lasts up to 2 hours and ends when you log out.
  * Offers/wanted between members: offer or look for items, with price and note. If a request matches an offer,
    both get a notice. Not a guild bank – trading happens directly between players.
- Guild events (/gs events): PvP night, guild meeting, dungeon night, world boss … Anyone can create events,
  everyone replies yes, no or maybe with one click. Reminder with sound 15 minutes before.
  Raids stay with RaidMaster and the Discord sign-up – the next raid is only shown for information.
- Report absence: /gs away 14 vacation (or select a member > "Away …"). Members marked away don't show up as
  inactive and aren't suggested for promotion. /gs away 0 = back.
- Mentors for new members: officers assign a mentor; both get a notice.
- Write alts into the guild note: "Alt of …" into the public note (select a member, or all at once under Export)
  – so everyone without GuildSentinel sees it too. Needs the right to edit public notes.
- Guild chat with main names: when an alt writes, the main is shown in gray in front. "has come online" gets
  "(Alt of …)" or "(marked away)" added. Both can be turned off.
- Thanks: "Say thanks" (right-click a member or /gs thanks name) – once a day per player.
  Ranking under Progress > Helpful.
- Cooldowns (Professions > Cooldowns): transmutes, mooncloth, salt shaker – who is ready, who when?
  "Ask" prepares the whisper.
- Attunements & keys: now with Shadowforge Key, Skeleton Key, Crescent Key and Key to the City.
- Guild goals (Progress > Guild goals): weekly goal ("150 levels as a guild", week starts Wednesday) and guild
  milestones (members at 60, member count, raid attunements, first kills from RaidMaster) with announcements.
- New "Addons" page: all GoldSentinel addons – what you have installed, who in the guild uses which one,
  who has an old version, open with one click.

NEW IN 0.5.1
- (0.5.1) Language setting – since 0.8.0 the game language is always used.
- English names for the ad placeholders: {guild}, {members}, {wanted}, {crafters}, {player}.

NEW IN 0.5.0
- Polls: officers ask, everyone with the addon votes with one click, results are live (Polls page, /gs poll)
- Composition (Members > Composition): classes and roles per level range, raid target and what's missing.
  New placeholder {wanted} in the ad, e.g. "Looking for: Shamans, Tanks, Warlocks."
- Application questions: after the automatic reply the addon asks a few questions, one at a time.
  The answers are shown with the applicant (hover the name).
- Player tooltip: rank, main or alts, role, professions and raid attunements of guild members
- Professions > Gaps: important raid recipes nobody in the guild can craft. Placeholder {crafters} in the ad.
- Professions > Requests: add crafting requests; anyone who can craft it gets a notice and takes it with one click.

MEMBERS
- List with level, class, rank, zone or "last online" and notes. Search, filter by class/rank, online only,
  show or hide alts. Right-click a member for actions.
- Alts: a public note like "Alt: Name" (or "Main: Name", "Twink von Name") is detected automatically.
  Otherwise: select a member > "Alt of …", or pick your own main under Settings.
- Personal note for every member (only you see it).
- History: joined, left, removed, promoted, demoted, reached 60, accepted the guild rules.
- Inactive: who hasn't been online for 14/30/60/90 days (only if none of their alts were online either).
- Online times: overview by weekday and hour of when most players are online – great for picking raid times.
  GuildSentinel samples every 5 minutes; samples from everyone with the addon are combined.
- Promotion: the guild leadership sets per rank when someone gets suggested (days in guild, level, online days
  out of the last 14). Promote with one click – but always by hand.
- Composition: classes and roles per level range (1–29, 30–49, 50–59, 60) compared with a target for a 40-player
  raid. Click a row to change the target. Role: chosen by the player, from the talent spec (RaidMaster) or
  estimated from class (tanks are never estimated).
- Export: the member list as text (alts listed with their main) or as a table (CSV) to copy.

GROUP FINDER
- Pick a dungeon or activity, tick the roles you need, open spots, note – "Start search".
- "guild only" or "whole server": then your search goes to the guild, your group and, through the whisper network of
  the GoldSentinel addons, to players of other guilds. There is no custom channel any more since 0.9.20.
- Players whose level and role fit get a notice in chat (optionally with sound). "I'll join" tells the searcher,
  who sees all replies and invites with one click.
- A search runs for 60 minutes. Set your role right at the search (Group finder page).

POLLS
- Officers ask a question with 2 to 8 answers (runs 1 hour to 7 days, optionally secret).
- Everyone with GuildSentinel gets a notice and votes with one click; you can change your vote until the end.
  Each player has one vote – alts count for their main.

PROGRESS
- Leveling race: ranking by level – at the same level, whoever got there first ranks higher. Plus levels gained in
  the last 7 days. Levels come from the guild roster, nobody needs the addon for this.
- Guild chat announcements: level 10, 20, 30, 40 (mount!), 50, 60 and "first guild member to reach 60".
- Raid attunements: Upper Blackrock Spire, Molten Core, Onyxia's Lair, Blackwing Lair. Everyone with GuildSentinel
  shares their completed attunement quests; without the addon it shows "?".

RECRUITMENT
- Ad text with placeholders {guild}, {faction}, {name}, {discord}, {tag} (Discord server tag, only shown together with a Discord link), {members}, {online}, {wanted} (what's missing) and
  {crafters} (professions needed) – the German names ({gilde}, {gesucht} …) work too – and a preview. Each click on "Prepare ad" puts the text into the
  chat input for one channel ("/5 …") and you send it with Enter; the next click takes the next channel. Quick:
  right-click the minimap button.
- Applicants: anyone who whispers you a keyword (e.g. "guild") lands in the list and gets an automatic reply if you
  like. Then the addon asks the application questions (custom questions possible, one per line).
  From there: invite, whisper, decline.
- Welcome new members and celebrate anniversaries (1, 3, 6 months, 1 and 2 years) in guild chat.
- Guild rules: officers write them and send them to everyone. Everyone with GuildSentinel sees them on login and
  accepts with one click. The leadership sees who is still missing.
- Announcements are made by only one player, even if many have the addon. Alts are not announced.
- The guild name is always read from the game – if the name changes, all texts follow.

PROFESSIONS
- Directory: everyone opens their profession windows once (or clicks "Scan …"). Then the whole guild knows who can
  craft what. Search by recipe or item, overview per profession, "Ask to craft" with one click.
- Requests: add requests (shift-click the item). Whoever can craft it gets a notice and takes the request; the
  requester is told. Requests stay for 14 days.
- Gaps: fire, nature, shadow, frost and arcane protection potions, flasks, elixirs, transmutes, mooncloth,
  dark iron, dynamite … – who can craft it, what's missing? Add more recipes with shift-click.

PLAYER TOOLTIP
- Hover a guild member: rank, main or alts, role, professions and raid attunements. Applicants are marked.
  Can be turned off under Settings.

WORKING WITH THE OTHER GOLDSENTINEL ADDONS (all optional, GuildSentinel also works on its own)
- RaidMaster: professions and alts also come from RaidMaster; GuildSentinel sends your own professions itself. Alts from Discord (/twink) take
  priority; if an officer sets an alt here, it is saved in RaidMaster too. Roles from talent specs, the next raid
  in events, first kills as guild milestones.
- AH Analyzer Pro: market value on the board and for profession cooldowns.
- BuffSentinel: detects your class services for the board.
- ThreatSentinel: your role (tank in Defensive Stance/Bear Form or the chosen role) for composition and group finder.
- LevelPilot: elite quests from your quest log as a group search with one click, players with the same quest.
- "Addons" page: overview and open with one click.

COMMANDS (everything also works with the mouse)
  /gs                 open/close the window
  /gs group           group finder
  /gs events          guild events
  /gs board           board (services, offers/wanted)
  /gs where           who's where
  /gs thanks <name>   say thanks
  /gs away <days> [note]  report absence (0 = back)
  /gs poll            polls
  /gs progress        leveling race
  /gs attune          raid attunements
  /gs rules           show the guild rules
  /gs find <recipe>   profession search
  /gs ad              open the ad page (prepare: button there or right-click the minimap button)
  /gs test            test mode on/off (developer only)
  /gs donate          support GuildSentinel (PayPal link to copy; also: the “Support” button at the top of the window)

© GoldSentinel – All rights reserved.
