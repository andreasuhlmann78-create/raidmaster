-- GuildSentinel - Pruefliste.lua
-- Prüfliste im Spiel (Entscheid des Nutzers 16.11.2026 06:47, Auftrag der Prüf-Sitzung 06:49): die offenen Punkte
-- "IM CLIENT PRÜFEN" als Liste, die selbst merkt, was erledigt ist. Nur im Entwicklermodus (GoldSentinelDev);
-- sonst gibt der gemeinsame Baustein eine leere Liste zurück (Spieler sehen nichts, keine Kosten).
-- Befehl: /gs prüfliste (auch /gs pruefliste). Reihenfolge = wie man sie im Spiel am besten nacheinander macht.
-- Erledigt wird ein Punkt über ns.PLHit("ID", "Messwert") an der Stelle, wo die Funktion wirklich benutzt wurde,
-- über auto() bei Messbarem, sonst mit OK / Nicht OK.

local ADDON, ns = ...
-- Texte bewusst nur Deutsch: die Prüfliste sieht nur der Entwickler (Entwicklermodus), wie der Baustein selbst.

local function AllPagesBuilt()
	local UI = ns.UI
	if not UI or not UI.frame then return nil end
	local built, on = 0, 0
	for i, p in ipairs(UI.pages) do
		if UI:PageOn(p) then
			on = on + 1
			if UI.panels[i] and UI.panels[i].built then built = built + 1 end
		end
	end
	if built == on then return true, string.format("%d von %d Seiten", built, on) end
	return nil
end

ns.PL_POINTS = {
	{ id = "TESTROUTINE", since = "0.9.50", title = "Testroutine im Spiel",
		todo = "Tippe /gs entwickler, dann /gs testroutine und warte, bis der Bericht erscheint (etwa eine Minute).",
		expect = "Am Ende steht „OK … · FEHLER 0“ und „Sandbox OK“. Der Punkt hakt sich selbst ab." },
	{ id = "SEITEN", since = "0.9.46", title = "Alle Seiten öffnen",
		todo = "Öffne GuildSentinel (/gs) und klicke links jede Seite einmal an.",
		expect = "Jede Seite zeigt Inhalt, nichts leer oder abgeschnitten. Der Punkt hakt sich ab, sobald alle Seiten einmal offen waren.",
		auto = AllPagesBuilt },
	{ id = "GSW2", since = "0.9.39", title = "Werbetext-Vorschlag wählen",
		todo = "Rekrutierung > Werbung: Knopf „Vorschlag wählen“, dann einen Vorschlag anklicken.",
		expect = "Die Liste zeigt je Vorschlag die Zeichenzahl; nach dem Klick steht der Text im Feld und endet mit „/w <dein Name> gilde“." },
	{ id = "GSW1", since = "0.9.39", title = "Flüster-Teil anhängen",
		todo = "Rekrutierung > Werbung: schreibe einen eigenen Text ohne „/w“ ins Feld und klicke den Knopf „Übernehmen“ beim gelben Hinweis.",
		expect = "Der gelbe Hinweis fragt nach „/w {name} gilde“; nach „Übernehmen“ steht der Teil am Ende deines Textes." },
	{ id = "WERBUNG", since = "0.9.29", title = "Werbung posten",
		todo = "Rekrutierung > Werbung: „Werbung vorbereiten“, dann in der Chat-Eingabe Enter drücken.",
		expect = "Der Text erscheint im Kanal, KEIN Fenster „Aktion blockiert“; danach steht „zuletzt gepostet“." },
	{ id = "MENU", since = "0.9.30", title = "Rechtsklick-Menü bei Mitgliedern",
		todo = "Mitglieder: Rechtsklick auf ein Mitglied.",
		expect = "Ein Menü mit den Einträgen deiner Rechte; nicht erlaubte sind grau mit Grund." },
	{ id = "RANG", since = "0.9.33", title = "Befördern über „Gilden-Aktion“",
		todo = "Rechtsklick auf einen Twink > Befördern, im Fenster „Gilden-Aktion“ den Knopf drücken (danach wieder degradieren).",
		expect = "Kein Fenster „Aktion blockiert“; der Rang ändert sich, das Fenster zeigt „Erledigt“. Genau eine Beförderung." },
	{ id = "EINLADEN", since = "0.9.29", title = "Bewerber einladen",
		todo = "Rekrutierung > Bewerber: einen Bewerber wählen, „In die Gilde einladen“, dann in der Chat-Eingabe Enter.",
		expect = "„/ginvite <Name>“ steht in der Chat-Eingabe; nach Enter kein „geblockt“, Status wechselt auf „eingeladen“." },
	{ id = "ALTER", since = "0.9.36", title = "Altersfrage mit Zweitcharakter",
		todo = "Mit einem Zweitcharakter dir „gilde“ flüstern und die Fragen beantworten; bei „Wie alt bist du?“ z. B. „17“.",
		expect = "Bewerberliste zeigt „16+“ (bei „15“: Absage und „abgelehnt (Alter)“). Gespeichert wird nur 16+ / unter 16 / unklar." },
	{ id = "SPERRLISTE", since = "0.9.44", title = "Sperrliste: sperren und entfernen",
		todo = "Leitung > Sperrliste: Name „Testname“, Grund „Test“, „Sperren“; dann den Eintrag markieren und „Von der Sperrliste nehmen“.",
		expect = "Der Eintrag erscheint in der Liste und verschwindet wieder; im Chat je eine Zeile." },
	{ id = "TOOLTIP", since = "0.9.42", title = "Tooltip „In der Gilde seit“",
		todo = "Fahr mit der Maus über ein Gildenmitglied (im Spiel oder in der Gildenliste).",
		expect = "Im Tooltip steht „In der Gilde seit <Datum>“ (und, falls bekannt, „Zuletzt befördert …“)." },
	{ id = "NOTIZ", since = "0.9.45", title = "Notiz ändern -> Verlauf",
		todo = "Ändere im Gildenfenster eine öffentliche Notiz (z. B. deine eigene) und warte 20 Sekunden.",
		expect = "Mitglieder > Verlauf zeigt „öffentliche Notiz geändert“ mit alt → neu." },
	{ id = "MARKT", since = "0.9.38", title = "Haken „Marktdaten teilen“",
		todo = "Einstellungen öffnen und den Haken „Marktdaten teilen“ ansehen.",
		expect = "Haken und grauer Hinweis daneben sind ganz lesbar, nichts überlappt." },
	{ id = "TIPPEN", since = "0.9.34", title = "Befehlsliste beim Tippen",
		todo = "Tippe im Chat „/gs “ (mit Leerzeichen).",
		expect = "Über dem Eingabefeld erscheint die Liste aller Befehle; Klick wählt, Enter führt aus." },
}

ns.PL = GoldSentinelPruefliste and GoldSentinelPruefliste:Register("GuildSentinel", {
	db = function() return GuildSentinelDB end,
	version = function() return ns.version end,
	points = ns.PL_POINTS,
})

-- Testbericht (/gs protokoll): eine Kopfzeile und eine Zeile je Punkt
function ns.PLReportLines()
	if ns.PL and ns.PL.ReportLines then
		local ok, lines = pcall(ns.PL.ReportLines, ns.PL)
		if ok and type(lines) == "table" then return lines end
	end
	return {}
end

-- Speicherplatz gleich nach dem Laden anlegen (der Baustein legt ihn sonst beim ersten Lesen an – z. B. mitten in der
-- Testroutine, deren Sandbox das als Änderung sähe). Ohne Entwicklermodus: leere Liste, nichts angelegt.
ns:Listen("GS_LOGIN", function()
	if ns.PL and ns.PL.Store then pcall(ns.PL.Store, ns.PL) end
end)
