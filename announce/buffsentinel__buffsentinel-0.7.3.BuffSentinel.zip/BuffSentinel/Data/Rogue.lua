-- BuffSentinel - Data/Rogue.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

-- Gift-Gegenstände Classic-Familie, bester Rang zuerst (Wrath, TBC, Era; Cata nutzt die Basis-IDs)
local INSTANT = { 43231, 43230, 21927, 8928, 8927, 8926, 6950, 6949, 6947 }
local DEADLY  = { 43233, 43232, 22054, 22053, 20844, 8985, 8984, 2893, 2892 }
local function Join(a, b)
    local t = {}
    for _, v in ipairs(a) do t[#t + 1] = v end
    for _, v in ipairs(b) do t[#t + 1] = v end
    return t
end

BS.ClassData.ROGUE = {
    specNames       = { "Meucheln", "Kampf", "Täuschung" },
    specNamesModern = { "Meucheln", "Kampf", "Täuschung" },
    icon = "Interface\\Icons\\Ability_Rogue_DualWeild",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        { key = "poison_mh",   kind = "buff", weapon = "main", items = Join(INSTANT, DEADLY),
          icon = "Interface\\Icons\\Ability_Poisons", label = "Gift Haupthand", alert = "GIFT HAUPTHAND!" },
        { key = "poison_oh",   kind = "buff", weapon = "off", items = Join(DEADLY, INSTANT),
          icon = "Interface\\Icons\\Ability_Rogue_DualWeild", label = "Gift Nebenhand", alert = "GIFT NEBENHAND!" },
        { key = "snd",         kind = "buff", spell = 5171, mode = "combat", specs = { 2 }, optional = true },

        -- Procs
        { key = "riposte",     kind = "proc", spell = 14251, trigger = "parry", window = 5, reactive = true, specs = { 2 } },
        { key = "ambush_ct",   kind = "proc", spell = 8676, reactive = true, forever = true,
          talents = { "Cutthroat" }, label = "Cutthroat » Hinterhalt", alert = "HINTERHALT!" },

        -- Cooldowns
        { key = "coldblood",   kind = "cd", spell = 14177, specs = { 1 } },
        { key = "mutilate",    kind = "cd", spell = 1329,  min = 3, specs = { 1 }, optional = true },
        { key = "vendetta",    kind = "cd", spell = 79140, min = 4, specs = { 1 } },
        { key = "adrenaline",  kind = "cd", spell = 13750, specs = { 2 } },
        { key = "bladeflurry", kind = "cd", spell = 13877, specs = { 2 } },
        { key = "killspree",   kind = "cd", spell = 51690, min = 3, specs = { 2 } },
        { key = "premed",      kind = "cd", spell = 14183, specs = { 3 } },
        { key = "prep",        kind = "cd", spell = 14185, specs = { 3 } },
        { key = "shadowstep",  kind = "cd", spell = 36554, min = 2, specs = { 3 } },
        { key = "shadowdance", kind = "cd", spell = 51713, min = 3, specs = { 3 } },
        { key = "kick",        kind = "cd", spell = 1766 },
        { key = "kidney",      kind = "cd", spell = 408 },
        { key = "gouge",       kind = "cd", spell = 1776, max = 3 },
        { key = "evasion",     kind = "cd", spell = 5277 },
        { key = "sprint",      kind = "cd", spell = 2983 },
        { key = "vanish",      kind = "cd", spell = 1856 },
        { key = "cloak",       kind = "cd", spell = 31224, min = 2 },
        { key = "blind",       kind = "cd", spell = 2094 },
        { key = "tricks",      kind = "cd", spell = 57934, min = 3 },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP: Gifte sind Buffs auf dir)
        ----------------------------------------------------------------
        { key = "m_lethal",    kind = "buff", v = "modern", max = 5, spell = { 2823, 8679 }, auras = { 2823, 8679 },
          label = "Tödliches Gift", alert = "GIFT!" },
        { key = "m_nonlethal", kind = "buff", v = "modern", max = 5, spell = { 3408, 5761, 108211, 108215 },
          auras = { 3408, 5761, 108211, 108215 }, label = "Nicht-tödliches Gift", alert = "GIFT 2!", optional = true },
        { key = "r_lethal",    kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true,
          spell = { 2823, 315584, 8679, 381664 }, auras = { 2823, 315584, 8679, 381664 },
          label = "Tödliches Gift", alert = "GIFT!" },
        { key = "r_nonlethal", kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true,
          spell = { 381637, 3408, 5761 }, auras = { 381637, 3408, 5761 },
          label = "Nicht-tödliches Gift", alert = "GIFT 2!" },
        { key = "m_snd",       kind = "buff", v = "modern", spell = 5171, mode = "combat", optional = true },

        { key = "m_blindside", kind = "proc", v = "modern", spell = 111240, procAuras = { 121153 }, specs = { 1 } },
        { key = "m_dispatch",  kind = "proc", v = "modern", spell = 111240, targetBelow = 35, specs = { 1 } },

        { key = "m_vendetta",  kind = "cd", v = "modern", spell = 79140, specs = { 1 } },
        { key = "m_adrenaline",kind = "cd", v = "modern", spell = 13750, specs = { 2 } },
        { key = "m_killspree", kind = "cd", v = "modern", spell = 51690, specs = { 2 } },
        { key = "m_shdance",   kind = "cd", v = "modern", spell = 51713, specs = { 3 } },
        { key = "m_premed",    kind = "cd", v = "modern", spell = 14183, specs = { 3 } },
        { key = "m_blades",    kind = "cd", v = "modern", spell = 121471 },
        { key = "m_vanish",    kind = "cd", v = "modern", spell = 1856 },
        { key = "m_evasion",   kind = "cd", v = "modern", spell = 5277 },
        { key = "m_cloak",     kind = "cd", v = "modern", spell = 31224 },
        { key = "m_kick",      kind = "cd", v = "modern", spell = 1766 },
        { key = "m_kidney",    kind = "cd", v = "modern", spell = 408 },
        { key = "m_sprint",    kind = "cd", v = "modern", spell = 2983 },
        { key = "m_tricks",    kind = "cd", v = "modern", spell = 57934 },
        { key = "m_prep",      kind = "cd", v = "modern", spell = 14185 },
        { key = "m_shadowstep",kind = "cd", v = "modern", spell = 36554 },
    },
}
