-- BuffSentinel - Data/Paladin.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

-- Siegel (Classic-Familie): jedes Siegel zählt als vorhanden
local SEALS = { 21084, 20154, 20375, 21082, 20165, 20166, 20164, 31801, 31892, 53736 }

BS.ClassData.PALADIN = {
    specNames       = { "Heilig", "Schutz", "Vergeltung" },
    specNamesModern = { "Heilig", "Schutz", "Vergeltung" },
    icon = "Interface\\Icons\\Spell_Holy_HolyBolt",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        -- Siegel: Schutz/Vergeltung -> Rechtschaffenheit/Befehl, Heilig -> Weisheit/Licht
        { key = "seal",       kind = "buff", spell = { 20154, 21084, 20375 }, noForever = true,
          spellBySpec = { [1] = { 20166, 20165, 20154, 21084 }, [3] = { 20375, 31801, 31892, 20154, 21084 } },
          auras = SEALS, label = "Siegel", alert = "SIEGEL!", mode = "combat" },
        -- WoW Forever: neues Siegel der Wut (Tank-Siegel mit Absorb und Spott-Richturteil)
        { key = "seal_f",     kind = "buff", forever = true, spell = { 20154, 21084, 20375 },
          spellBySpec = { [1] = { 20166, 20165, 20154, 21084 }, [2] = { "Seal of Fury", 20154, 21084 },
                          [3] = { 20375, 20154, 21084 } },
          auras = { 21084, 20154, 20375, 21082, 20165, 20166, 20164, "Seal of Fury" },
          label = "Siegel", alert = "SIEGEL!", mode = "combat" },
        { key = "aura",       kind = "buff", spell = { 465, 7294, 19746, 19876 }, auras = { 465, 7294, 19746, 19876, 19888, 19891, 20218, 32223 },
          label = "Aura", alert = "AURA!" },
        { key = "rfury",      kind = "buff", spell = 25780, specs = { 2 } },
        { key = "kings",      kind = "buff", spell = 20217, group = true, groupSpell = 25898, optional = true },
        { key = "might",      kind = "buff", spell = 19740, group = true, groupSpell = 25782, optional = true },
        { key = "wisdom",     kind = "buff", spell = 19742, group = true, groupSpell = 25894, manaOnly = true, optional = true },

        -- Procs
        { key = "hammerwrath",kind = "proc", spell = 24275, targetBelow = 20, reactive = true, min = 1 },
        { key = "artofwar",   kind = "proc", spell = 879, procAuras = { 59578 }, min = 3, specs = { 3 },
          talents = { "The Art of War", "Die Kunst des Krieges" }, alert = "EXORZISMUS!" },
        { key = "grandcrus",  kind = "proc", spell = 31935, procAuras = { 85416 }, min = 4, specs = { 2 },
          talents = { "Grand Crusader", "Großer Kreuzfahrer" }, alert = "SCHILD DES RÄCHERS!" },
        { key = "infusion",   kind = "proc", spell = 19750, procAuras = { 54149 }, min = 3, specs = { 1 },
          talents = { "Infusion of Light", "Lichtenergie" }, alert = "LICHTBLITZ!" },
        { key = "divpurpose", kind = "proc", spell = 85256, procAuras = { 90174 }, min = 4, specs = { 3 },
          talents = { "Divine Purpose", "Göttliche Bestimmung" }, alert = "URTEIL DES TEMPLERS!" },
        -- WoW Forever: Lichtenergie – Krit von Heiliger Schock/Lichtblitz -> nächstes Heiliges Licht schneller
        { key = "infusion_f", kind = "proc", spell = 635, procAuras = { "Infusion of Light" }, forever = true, specs = { 1 },
          talents = { "Infusion of Light" }, label = "Lichtenergie", alert = "HEILIGES LICHT!" },

        -- Cooldowns
        { key = "judgement",  kind = "cd", spell = 20271 },
        { key = "crusader",   kind = "cd", spell = 35395, min = 2, specs = { 3 } },
        { key = "dstorm",     kind = "cd", spell = 53385, min = 3, specs = { 3 } },
        { key = "templar",    kind = "cd", spell = 85256, min = 4, specs = { 3 } },
        { key = "holyshock",  kind = "cd", spell = 20473, specs = { 1 } },
        { key = "divfavor",   kind = "cd", spell = 20216, specs = { 1 }, max = 3 },
        { key = "divillum",   kind = "cd", spell = 31842, min = 2, specs = { 1 } },
        { key = "consecrate", kind = "cd", spell = 26573, specs = { 2 } },
        { key = "holyshield", kind = "cd", spell = 20925, specs = { 2 }, max = 3 },
        { key = "avengershld",kind = "cd", spell = 31935, min = 2, specs = { 2 } },
        { key = "hammerright",kind = "cd", spell = 53595, min = 3, specs = { 2 } },
        { key = "ardent",     kind = "cd", spell = 31850, min = 4, specs = { 2 } },
        { key = "avenging",   kind = "cd", spell = 31884, min = 2 },
        { key = "hoj",        kind = "cd", spell = 853 },
        { key = "rebuke",     kind = "cd", spell = 96231, min = 4 },
        { key = "divprot",    kind = "cd", spell = 498 },
        { key = "divshield",  kind = "cd", spell = 642 },
        { key = "layonhands", kind = "cd", spell = 633 },
        -- WoW Forever: neue Fähigkeiten (Talent-Goldmedaillen)
        { key = "holystrike", kind = "cd", spell = "Holy Strike", forever = true },
        { key = "lightsvigil",kind = "cd", spell = "Light's Vigil", forever = true, specs = { 1 } },
        { key = "voicetruth", kind = "cd", spell = "Voice of Truth", forever = true, specs = { 1 } },
        { key = "swiftjudge", kind = "cd", spell = "Swift Judgement", forever = true, specs = { 2 } },
        { key = "bulwark",    kind = "cd", spell = "Templar's Bulwark", forever = true, specs = { 2 } },
        { key = "consecr_f",  kind = "cd", spell = 26573, forever = true, optional = true,
          label = "Weihe (in Forever für alle)" },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP, Retail)
        ----------------------------------------------------------------
        { key = "m_kings",    kind = "buff", v = "modern", spell = 20217, max = 5, group = true },
        { key = "m_might",    kind = "buff", v = "modern", spell = 19740, max = 5, group = true, optional = true },
        { key = "m_rfury",    kind = "buff", v = "modern", spell = 25780, max = 5, specs = { 2 } },
        { key = "m_aura",     kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true,
          spell = { 465, 317920, 32223 }, auras = { 465, 317920, 32223 }, label = "Aura", alert = "AURA!" },

        { key = "m_hammerwr", kind = "proc", v = "modern", spell = 24275, targetBelow = 20, reactive = true },
        { key = "m_artofwar", kind = "proc", v = "modern", spell = 879, procAuras = { 59578 }, specs = { 3 } },
        { key = "m_divpurp",  kind = "proc", v = "modern", spell = 85256, procAuras = { 90174 }, specs = { 3 } },
        { key = "m_grandcr",  kind = "proc", v = "modern", spell = 31935, procAuras = { 85416 }, specs = { 2 } },
        { key = "m_infusion", kind = "proc", v = "modern", spell = 82326, procAuras = { 54149 }, specs = { 1 } },

        { key = "m_crusader", kind = "cd", v = "modern", spell = 35395 },
        { key = "m_judgment", kind = "cd", v = "modern", spell = 20271 },
        { key = "m_holyshock",kind = "cd", v = "modern", spell = 20473, specs = { 1 } },
        { key = "m_hotr",     kind = "cd", v = "modern", spell = 53595, specs = { 2 } },
        { key = "m_avshield", kind = "cd", v = "modern", spell = 31935, specs = { 2 } },
        { key = "m_ardent",   kind = "cd", v = "modern", spell = 31850, specs = { 2 } },
        { key = "m_dstorm",   kind = "cd", v = "modern", spell = 53385, specs = { 3 } },
        { key = "m_avenging", kind = "cd", v = "modern", spell = 31884 },
        { key = "m_guardian", kind = "cd", v = "modern", spell = 86659 },
        { key = "m_holyaveng",kind = "cd", v = "modern", spell = 105809 },
        { key = "m_lhammer",  kind = "cd", v = "modern", spell = 114158 },
        { key = "m_execsent", kind = "cd", v = "modern", spell = 114157 },
        { key = "m_divfavor", kind = "cd", v = "modern", spell = 31842, specs = { 1 } },
        { key = "m_divprot",  kind = "cd", v = "modern", spell = 498 },
        { key = "m_divshield",kind = "cd", v = "modern", spell = 642 },
        { key = "m_loh",      kind = "cd", v = "modern", spell = 633 },
        { key = "m_hoj",      kind = "cd", v = "modern", spell = 853 },
        { key = "m_rebuke",   kind = "cd", v = "modern", spell = 96231 },
    },
}
