-- GuildSentinel - RaidReady.lua
-- Rekrutierung in Phasen (anweisung-rekrutierung-phasen.txt, RP1–RP8; Entscheid des Nutzers 13. Nov. 2026)
--
-- Drei Phasen je Gilde (G.recruitPhase = { p, raid, t, by }, über die Gilde geteilt, ändern nur GM/Offiziere):
--   build  Aufbau:   {gesucht} = "Mitstreiter aller Klassen"; die Aufstellung wird nicht benutzt
--   trans  Übergang: {gesucht} = "Mitstreiter aller Klassen, besonders <bis 3 Lücken>"
--   raid   Raid:     {gesucht} = die Lücken der Aufstellung wie bisher (Comp:WantedList)
-- Die Vorgaben der Aufstellung (G.comp) bleiben immer unverändert; sie gelten erst in der Phase Raid für {gesucht},
-- zählen aber jederzeit für die Raidfähigkeit.
--
-- Raidfähig für den Ziel-Raid: aktive Mains (Stufe >= Mindeststufe der Aufstellung, in den letzten 14 Tagen online;
-- Twinks nur mit "Twinks mitzählen") >= Raidgrösse und Rollen gedeckt (Tanks/Heiler aus den Vorgaben, skaliert auf
-- die Raidgrösse; ohne Vorgabe Grösse/10 bzw. Grösse/5). Erfüllungsgrad = Minimum aus Anzahl- und Rollen-Anteil.
--
-- Umschalten nie automatisch: ab 60 % Vorschlag "Übergang", ab 100 % "Raid" – erst die Bestätigung eines Offiziers
-- schaltet. Zurück erst, wenn der Erfüllungsgrad 7 Tage lang unter der Schwelle der Phase lag (G.rpHist, je Tag ein
-- Wert). Raidfähig zum ersten Mal: Meilenstein in der Chronik und (Einstellung, Standard an) eine Ansage von einem.
-- Beim Ausloggen: GuildSentinelDB.raidReady ohne Namen für Uploader und Discord-Bot.

local ADDON, ns = ...
local L = ns.L
local N = ns.N

local RP = {}
ns.RaidReady = RP

RP.TRANS, RP.RAID = 60, 100      -- Schwellen in Prozent
RP.BACK_DAYS = 7                 -- so lange unter der Schwelle, bevor "zurück" vorgeschlagen wird
RP.ACTIVE_DAYS = 14              -- aktiv = in diesen Tagen online
RP.HIST_DAYS = 40
RP.LATER = 86400                 -- "Später": einen Tag nicht mehr fragen

-- Ziel-Raids (Grössen wie RaidMasterBot/forever_raids.json; bei neuen Raids hier nachführen)
RP.RAIDS = ns.Game.TBC and {
	{ key = "kara", n = N["Karazhan"], size = 10 },
	{ key = "gruul", n = N["Gruuls Unterschlupf"], size = 25 },
	{ key = "mag", n = N["Magtheridons Kammer"], size = 25 },
	{ key = "ssc", n = N["Höhle des Schlangenschreins"], size = 25 },
	{ key = "tk", n = N["Festung der Stürme"], size = 25 },
} or {
	{ key = "ony", n = N["Onyxias Hort"], size = 40 },
	{ key = "mc", n = N["Molten Core"], size = 40 },
	{ key = "barrow", n = N["Barrow Deeps"], size = 10 },
	{ key = "hyjal", n = N["Hyjalgipfel"], size = 20 },
	{ key = "zg", n = N["Zul'Gurub"], size = 20 },
	{ key = "aq20", n = N["Ruinen von Ahn'Qiraj"], size = 20 },
	{ key = "bwl", n = N["Pechschwingenhort"], size = 40 },
	{ key = "aq40", n = N["Tempel von Ahn'Qiraj"], size = 40 },
	{ key = "naxx", n = N["Naxxramas"], size = 40 },
}

local PHASE_NAME = { build = N["Aufbau"], trans = N["Übergang"], raid = N["Raid"] }
function RP.PhaseName(p) return L[PHASE_NAME[p] or PHASE_NAME.build] end

function RP:RaidInfo(key)
	for _, r in ipairs(self.RAIDS) do if r.key == key then return r end end
	return self.RAIDS[1]
end

------------------------------------------------------------
-- Zustand (geteilt)
------------------------------------------------------------
function RP:State()
	local g = ns.G()
	local s = g.recruitPhase
	-- Standard für bestehende und neue Gilden: Aufbau (wird erst gespeichert, wenn ein Offizier etwas einstellt)
	if type(s) ~= "table" or not PHASE_NAME[s.p] then return { p = "build", raid = self.RAIDS[1].key, t = 0 } end
	if not s.raid or self:RaidInfo(s.raid).key ~= s.raid then return { p = s.p, raid = self.RAIDS[1].key, t = s.t, by = s.by } end
	return s
end
function RP:Phase() return self:State().p end

-- Offizier? Eigene Rechte im Spiel; für Nachrichten anderer: Rang 0/1 oder nicht tiefer als ich (wenn ich Offizier bin)
local function SenderIsOfficer(sender)
	local e = ns.Roster.byName[sender]
	if not e or type(e.ri) ~= "number" then return false end
	if e.ri <= 1 then return true end
	local me = ns.Roster.byName[ns.Me()]
	return ns.IsOfficer() and me and type(me.ri) == "number" and e.ri <= me.ri or false
end
RP.SenderIsOfficer = SenderIsOfficer

-- Phase und/oder Ziel-Raid setzen: nur GM/Offiziere (Bestätigung = Klick eines Offiziers)
function RP:Set(phase, raid)
	if not ns.guild then return false end
	if not ns.IsOfficer() then ns:Print(L["Die Rekrutierungsphase können nur Gildenmeister und Offiziere ändern."]) return false end
	local s = self:State()
	phase = PHASE_NAME[phase] and phase or s.p
	raid = (raid and self:RaidInfo(raid).key == raid) and raid or s.raid
	local changedRaid = raid ~= s.raid
	ns.G().recruitPhase = { p = phase, raid = raid, t = ns.Now(), by = ns.Me() }
	if changedRaid then ns.G().rpHist = nil end
	ns.G().rpSince = nil
	ns.Comm:Send("RPHASE", { p = phase, raid = raid, t = ns.G().recruitPhase.t })
	ns:Fire("GS_COMP")
	return true
end

ns.Comm:Register("RPHASE", function(sender, d)
	local g = ns.guild
	if not g or type(d) ~= "table" or not PHASE_NAME[d.p] or type(d.t) ~= "number" or type(d.raid) ~= "string" then return end
	if not SenderIsOfficer(sender) then return end
	local s = g.recruitPhase
	if type(s) == "table" and (s.t or 0) >= d.t then return end
	if RP:RaidInfo(d.raid).key ~= d.raid then return end
	if type(s) == "table" and s.raid ~= d.raid then g.rpHist = nil end
	g.recruitPhase = { p = d.p, raid = d.raid, t = d.t, by = sender }
	ns:Fire("GS_COMP")
end)

-- wer die Phase kennt, gibt sie nach dem Einloggen weiter (neue Mitglieder bekommen sie so auch)
ns:Listen("GS_LOGIN", function()
	C_Timer.After(28, function()
		local g = ns.guild
		local s = g and g.recruitPhase
		if type(s) == "table" and (s.t or 0) > 0 and ns.InGuild() and ns.IsOfficer() then
			ns.Comm:Send("RPHASE", { p = s.p, raid = s.raid, t = s.t })
		end
	end)
end)

------------------------------------------------------------
-- Messen
------------------------------------------------------------
local function Ceil(x) return math.floor(x + 0.999999) end

-- Soll-Werte für Tanks und Heiler: Vorgabe der Aufstellung (auf den 40er/25er-Raid bezogen) auf die Raidgrösse
-- umgerechnet; ohne Vorgabe Grösse/10 bzw. Grösse/5
function RP:RoleTargets(size)
	local base = ns.Game.RAID_SIZE or 40
	local function T(key, div)
		local w = ns.Comp:Want(key)
		if type(w) == "number" and w > 0 then return math.max(1, Ceil(w * size / base)) end
		return math.max(1, Ceil(size / div))
	end
	return T("tank", 10), T("heal", 5)
end

-- { raid, name, size, min, active, tanks, tanksSoll, heals, healsSoll, pct }
function RP:Measure(raidKey)
	local r = self:RaidInfo(raidKey or self:State().raid)
	local s = ns.Comp:Settings()
	local now = ns.Now()
	local active, tanks, heals = 0, 0, 0
	for _, e in ipairs(ns.Roster.list) do
		if (s.alts or not ns.Roster:IsAlt(e.name)) and (e.level or 0) >= s.min then
			local seen = e.online and now or (type(e.seen) == "number" and e.seen or 0)
			if now - seen <= self.ACTIVE_DAYS * 86400 then
				active = active + 1
				local role = ns.Comp:Role(e.name, e.class)
				if role == "tank" then tanks = tanks + 1 elseif role == "heal" then heals = heals + 1 end
			end
		end
	end
	local tSoll, hSoll = self:RoleTargets(r.size)
	local count = math.min(1, active / r.size)
	local roles = math.min(1, tanks / tSoll, heals / hSoll)
	local pct = math.floor(math.min(count, roles) * 100 + 1e-6)
	return { raid = r.key, name = L[r.n], size = r.size, min = s.min, active = active, tanks = tanks, tanksSoll = tSoll,
		heals = heals, healsSoll = hSoll, pct = pct }
end

------------------------------------------------------------
-- {gesucht} je Phase
------------------------------------------------------------
function RP:Wanted()
	local p = self:Phase()
	if p == "raid" then return ns.Comp:WantedList() end
	if p == "trans" and #ns.Comp:Missing() > 0 then
		return string.format(L["Mitstreiter aller Klassen, besonders %s"], ns.Comp:WantedList(3))
	end
	return L["Mitstreiter aller Klassen"]
end

------------------------------------------------------------
-- Verlauf (ein Wert je Tag) und Vorschläge
------------------------------------------------------------
local function Day(t) return math.floor(t / 86400) end

function RP:Sample(m)
	local g = ns.guild
	if not g or not next(ns.Roster.byName) then return end
	m = m or self:Measure()
	if type(g.rpHist) ~= "table" or g.rpHist.raid ~= m.raid then g.rpHist = { raid = m.raid, d = {}, n = {} } end
	local today = Day(ns.Now())
	g.rpHist.d[today] = m.pct
	g.rpHist.n = g.rpHist.n or {}
	g.rpHist.n[today] = m.active
	for d in pairs(g.rpHist.d) do if d < today - self.HIST_DAYS then g.rpHist.d[d] = nil; g.rpHist.n[d] = nil end end
end

-- seit wie vielen Tagen liegt der Erfüllungsgrad ohne Unterbrechung unter der Schwelle? (nur Tage seit der letzten
-- Umschaltung zählen)
function RP:DaysBelow(threshold)
	local g = ns.G()
	local h = g.rpHist
	if type(h) ~= "table" or type(h.d) ~= "table" then return 0 end
	local since = Day(self:State().t or 0)
	local days = {}
	for d in pairs(h.d) do if d >= since then days[#days + 1] = d end end
	table.sort(days)
	if #days == 0 then return 0 end
	local start
	for i = #days, 1, -1 do
		if h.d[days[i]] < threshold then start = days[i] else break end
	end
	if not start then return 0 end
	return Day(ns.Now()) - start
end

-- Vorschlag: Zielphase, Richtung ("up"/"down") | nil
function RP:Suggestion(m)
	m = m or self:Measure()
	local p = self:Phase()
	if p == "build" then
		if m.pct >= self.RAID then return "raid", "up" end
		if m.pct >= self.TRANS then return "trans", "up" end
	elseif p == "trans" then
		if m.pct >= self.RAID then return "raid", "up" end
		if self:DaysBelow(self.TRANS) >= self.BACK_DAYS then return "build", "down" end
	elseif p == "raid" then
		if self:DaysBelow(self.RAID) >= self.BACK_DAYS then return (m.pct >= self.TRANS) and "trans" or "build", "down" end
	end
	return nil
end

-- offener Vorschlag für diesen Spieler (Offiziere; "Später" blendet einen Tag aus)
function RP:Pending()
	if not ns.IsOfficer() then return nil end
	local to, dir = self:Suggestion()
	if not to then return nil end
	local key = to .. ":" .. self:State().raid
	local later = type(ns.db.rpLater) == "table" and ns.db.rpLater[key]
	if later and ns.Now() - later < self.LATER then return nil end
	return to, dir
end

function RP:Later()
	local to = self:Suggestion()
	if not to then return end
	ns.db.rpLater = type(ns.db.rpLater) == "table" and ns.db.rpLater or {}
	ns.db.rpLater[to .. ":" .. self:State().raid] = ns.Now()
	ns:Fire("GS_COMP")
end

function RP:Confirm()
	local to = self:Suggestion()
	if not to then return false end
	return self:Set(to)
end

-- Hinweis an die Offiziere: einmal je Vorschlag im Offizierschat (nur einer sagt an, Testmodus über ns.Chat)
function RP:Notify()
	local g = ns.guild
	if not g or not ns.IsOfficer() then return end
	local to, dir = self:Suggestion()
	if not to then return end
	local key = "rp:" .. to .. ":" .. self:State().raid .. ":" .. tostring(self:State().t or 0)
	g.rpSaid = type(g.rpSaid) == "table" and g.rpSaid or {}
	if g.rpSaid[key] then return end
	g.rpSaid[key] = ns.Now()
	local m = self:Measure()
	ns.Claim(key, function()
		ns.Chat(string.format(L["GuildSentinel: Vorschlag Rekrutierungsphase %s (%s %d%%) – bitte in GuildSentinel bestätigen."], RP.PhaseName(to), m.name, m.pct), "OFFICER")
	end)
end

------------------------------------------------------------
-- Fortschritt und Schätzung (RP6)
------------------------------------------------------------
-- Wochen bis raidfähig: aus dem Leveling-Rennen (Stufen der letzten 14 Tage je Main unter der Mindeststufe).
-- nil, "measure" = noch keine 7 Tage Daten; nil, "none" = beim jetzigen Tempo nicht absehbar
function RP:Estimate(m)
	m = m or self:Measure()
	local missing = m.size - m.active
	if missing <= 0 then return 0 end
	local g = ns.G()
	local now = ns.Now()
	local oldest
	for _, lv in pairs(g.levels or {}) do
		if type(lv) == "table" then
			for _, t in pairs(lv) do if type(t) == "number" and t > 0 and (not oldest or t < oldest) then oldest = t end end
		end
	end
	if not oldest or now - oldest < 7 * 86400 then return nil, "measure" end
	local s = ns.Comp:Settings()
	local etas = {}
	for _, e in ipairs(ns.Roster.list) do
		if (s.alts or not ns.Roster:IsAlt(e.name)) and (e.level or 0) < s.min then
			local seen = e.online and now or (type(e.seen) == "number" and e.seen or 0)
			local gain = ns.Race:Gain(e.name, now - 14 * 86400)
			if now - seen <= self.ACTIVE_DAYS * 86400 and gain and gain > 0 then
				etas[#etas + 1] = (s.min - e.level) / (gain / 14)
			end
		end
	end
	if #etas < missing then return nil, "none" end
	table.sort(etas)
	return math.max(1, Ceil(etas[missing] / 7))
end

function RP:ProgressText(m)
	m = m or self:Measure()
	local t = string.format(L["Raidfähig (%s): %d von %d aktiv auf Stufe %d+ · Tanks %d/%d · Heiler %d/%d · Phase %s"],
		m.name, m.active, m.size, m.min, m.tanks, m.tanksSoll, m.heals, m.healsSoll, RP.PhaseName(self:Phase()))
	if m.pct >= 100 then return t .. " · " .. L["raidfähig"] end
	local w, why = self:Estimate(m)
	if w then
		t = t .. " · " .. string.format(L["beim jetzigen Tempo in ~%d Wochen"], w)
	elseif why == "measure" then
		t = t .. " · " .. L["Schätzung: messe noch"]
	end
	return t
end

------------------------------------------------------------
-- Meilenstein (RP7) und Zusammenfassung für Discord (RP8)
------------------------------------------------------------
function RP:CheckMilestone(m)
	local g = ns.guild
	if not g or m.pct < 100 then return end
	g.miles = g.miles or {}
	local key = "raidready:" .. m.raid
	if g.miles[key] then return end
	g.miles[key] = ns.Now()
	g.milesText = g.milesText or {}
	local text = string.format(L["Gilde ist raidfähig (%s)"], m.name)
	g.milesText[key] = text
	if ns.db.annRaidReady ~= false then
		ns.Claim("mile:" .. key, function() ns.Announce(string.format(L["Gilden-Meilenstein: %s!"], text)) end)
	end
	ns:Fire("GS_GOALS")
end

-- ohne Namen: Ziel-Raid, Phase, Zahlen, Schätzung
function RP:Summary()
	local m = self:Measure()
	local w = self:Estimate(m)
	return { raid = m.raid, phase = self:Phase(), aktiv = m.active, groesse = m.size, tanks = m.tanks, tanksSoll = m.tanksSoll,
		heiler = m.heals, heilerSoll = m.healsSoll, pct = m.pct, wochen = w, t = ns.Now() }
end

ns:On("PLAYER_LOGOUT", function()
	if not (GuildSentinelDB and ns.guild and next(ns.Roster.byName)) then return end
	if ns.Test and ns.Test:Active() then return end
	local ok, s = pcall(RP.Summary, RP)
	if ok and s then GuildSentinelDB.raidReady = s end
end)

-- Auswertung nach Änderungen der Gildenliste (gebündelt)
function RP:Update()
	if not ns.guild or not next(ns.Roster.byName) then return end
	if ns.Test and ns.Test:Active() then return end
	local m = self:Measure()
	self:Sample(m)
	self:CheckMilestone(m)
	self:Notify()
end

ns:Listen("GS_ROSTER", function()
	if RP.pending then return end
	RP.pending = true
	C_Timer.After(8, function() RP.pending = nil; RP:Update() end)
end)
