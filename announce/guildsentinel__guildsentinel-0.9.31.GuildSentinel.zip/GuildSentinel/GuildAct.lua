-- GuildSentinel - GuildAct.lua
-- Geschützte Gilden-Aktionen sicher ausführen (GV1/RV3, 13. Nov. 2026)
--
-- In WoW Forever verbietet das Spiel Addons das direkte Einladen in die Gilde (ADDON_ACTION_FORBIDDEN, auch mit
-- Mausklick). Befördern, Degradieren, Entfernen und Gildenleitung übergeben sind sehr wahrscheinlich ebenso geschützt.
-- Deshalb ruft GuildSentinel diese Funktionen NIE direkt auf:
--   * Einladen: "/ginvite <Name>" kommt in die Chat-Eingabe (ns.OpenGuildInvite, Recruit.lua), Senden mit Enter.
--   * Befördern / Degradieren / Entfernen / Leitung: ein sicherer Knopf (SecureActionButtonTemplate, type "macro",
--     macrotext "/gpromote <Name>" usw.) im Fenster "Gilden-Aktion". Den klickt der Spieler selbst – Blizzards eigene
--     Befehle führen die Aktion aus. Attribute werden nur ausserhalb des Kampfs gesetzt.
--   * Jeder Schritt ist ein eigener Klick ("Befördern – noch 2 Stufen bis Offizier"), auch bei mehreren Mitgliedern
--     ("3 von 5 erledigt"). Nie mehrere geschützte Aufrufe aus einem Klick.
--   * Erledigt ist ein Schritt erst, wenn das Spiel ihn bestätigt (Systemmeldung oder neuer Rang in der Gildenliste).
--     Ohne Bestätigung nach GA.TIMEOUT Sekunden: "nicht ausgeführt" mit Grund, der Schritt kann wiederholt werden.
--   * Testmodus: der Knopf führt nichts aus, nur "[Test] /gpromote …".
-- Jede bestätigte Rang-Änderung kommt in den Rang-Verlauf (G.rankLog: wer, wen, von -> nach, Zeit). Namen nur im Spiel,
-- nie im Diagnose-Protokoll.

local ADDON, ns = ...
local L = ns.L
local UI = ns.UI

local GA = {}
ns.GuildAct = GA

GA.TIMEOUT = 6
GA.LOG_MAX = 100

local GOLD, GREEN, RED, GRAY = "|cffffd100", "|cff66dd66", "|cffff6666", "|cff9aa0a6"

-- geschützte Gilden-Funktionen: nie direkt aus Addon-Code (Testroutine und Grundregeln prüfen diese Liste)
GA.PROTECTED = {
	"GuildInvite", "GuildUninvite", "GuildPromote", "GuildDemote", "GuildSetLeader",
	"C_GuildInfo.Invite", "C_GuildInfo.Uninvite", "C_GuildInfo.Promote", "C_GuildInfo.Demote", "C_GuildInfo.SetLeader",
}

-- Befehle des Spiels (Name der Blizzard-Variablen, Rückfall)
GA.KINDS = {
	promote = { slash = "SLASH_GUILD_PROMOTE1", def = "/gpromote" },
	demote = { slash = "SLASH_GUILD_DEMOTE1", def = "/gdemote" },
	remove = { slash = "SLASH_GUILD_UNINVITE1", def = "/gremove" },
	leader = { slash = "SLASH_GUILD_LEADER1", def = "/gleader" },
}

local function KindLabel(kind)
	if kind == "promote" then return L["Befördern"]
	elseif kind == "demote" then return L["Degradieren"]
	elseif kind == "remove" then return L["Aus der Gilde entfernen"]
	elseif kind == "leader" then return L["Gildenleitung übergeben"] end
	return kind
end
GA.KindLabel = KindLabel

-- "/gpromote Vorname Nachname": der Befehl nimmt den ganzen Rest der Zeile, Namen mit Leerzeichen gehen so
function GA.Macro(kind, name)
	local k = GA.KINDS[kind]
	if not k or type(name) ~= "string" or name == "" then return nil end
	local cmd = _G[k.slash]
	if type(cmd) ~= "string" or cmd:sub(1, 1) ~= "/" then cmd = k.def end
	-- Zeilenumbrüche würden einen zweiten Befehl ergeben
	name = name:gsub("[\r\n]", "")
	return cmd .. " " .. name
end

local function RankOf(name)
	local e = ns.Roster and ns.Roster.byName[name]
	return e and e.ri
end
local function MyRank()
	if ns.Test and ns.Test:Active() and RankOf(ns.Me()) == nil then return 0 end
	return RankOf(ns.Me())
end
local function NumRanks() return ns.Admin and ns.Admin.NumRanks() or 10 end
local function RankName(ri) return ns.Admin and ns.Admin.RankName(ri) or ("#" .. tostring(ri)) end
GA.MyRank = MyRank

------------------------------------------------------------
-- Schritte planen
------------------------------------------------------------
-- Rang setzen (RV4): Liste der Schritte vom aktuellen bis zum Zielrang. Nie über den eigenen Rang hinaus, nie
-- Gildenmeister (Rang 0), nie unter den untersten Rang. Rückgabe: Schritte | nil, Grund
function GA.RankSteps(name, target)
	local cur = RankOf(name)
	local my = MyRank()
	if cur == nil then return nil, "unknown" end
	if my == nil then return nil, "rights" end
	if type(target) ~= "number" then return nil, "target" end
	if target == cur then return nil, "same" end
	if target <= 0 or target <= my then return nil, "above" end
	if target > NumRanks() - 1 then return nil, "below" end
	if cur <= my then return nil, "above" end
	local r = ns.Admin and ns.Admin.Rights() or {}
	local steps = {}
	if target < cur then
		if not r.promote then return nil, "rights" end
		for ri = cur, target + 1, -1 do steps[#steps + 1] = { kind = "promote", name = name, from = ri, to = ri - 1 } end
	else
		if not r.demote then return nil, "rights" end
		for ri = cur, target - 1 do steps[#steps + 1] = { kind = "demote", name = name, from = ri, to = ri + 1 } end
	end
	return steps
end

-- ein Schritt je Mitglied (Mehrfachauswahl, Sammelaktion)
function GA.Steps(kind, names)
	local out = {}
	for _, n in ipairs(names or {}) do
		local ri = RankOf(n)
		local to = ri and ((kind == "promote" and ri - 1) or (kind == "demote" and ri + 1)) or nil
		out[#out + 1] = { kind = kind, name = n, from = ri, to = to }
	end
	return out
end

-- Text eines Schritts ("Befördern: Name (Mitglied -> Veteran) – noch 2 Stufen bis Offizier")
function GA.StepText(q, i)
	local s = q.steps[i]
	if not s then return "" end
	local t = KindLabel(s.kind) .. ": " .. s.name
	if (s.kind == "promote" or s.kind == "demote") and s.from and s.to then
		t = t .. " (" .. RankName(s.from) .. " -> " .. RankName(s.to) .. ")"
	end
	if q.target ~= nil then
		local left = #q.steps - i
		if left > 0 then t = t .. " – " .. string.format(L["noch %d Stufen bis %s"], left + 1, RankName(q.target)) end
	end
	return t
end

------------------------------------------------------------
-- Ablauf
------------------------------------------------------------
-- steps: Liste aus GA.RankSteps / GA.Steps; target: Zielrang (nur für den Text)
function GA:Start(steps, target)
	if type(steps) ~= "table" or #steps == 0 then return false end
	-- das Fenster enthält einen geschützten Knopf: im Kampf darf es weder auf- noch zugehen
	if ns.InCombat() then ns:Print(L["Im Kampf nicht möglich – bitte nach dem Kampf noch einmal."]) return false end
	self.queue = { steps = steps, i = 1, done = 0, failed = 0, target = target }
	self.pending = nil
	self:Show()
	self:Prepare()
	return true
end

function GA:Cancel()
	self.queue, self.pending = nil, nil
	if self.frame then
		if ns.InCombat() then self.hideAfterCombat = true else self.frame:Hide() end
	end
	ns:Fire("GS_GUILDACT")
end

function GA:Current()
	local q = self.queue
	return q and q.steps[q.i] or nil
end

-- Knopf für den aktuellen Schritt vorbereiten (nur ausserhalb des Kampfs)
function GA:Prepare()
	local f = self.frame
	local s = self:Current()
	if not f then return end
	if not s then
		local q = self.queue
		f.step:SetText(q and string.format(L["Fertig: %d von %d erledigt."], q.done, #q.steps) or "")
		f.btn.text:SetText(L["Schließen"])
		if not ns.InCombat() then f.btn:SetAttribute("type", nil) end
		f.btn.finished = true
		return
	end
	f.btn.finished = nil
	f.step:SetText(GA.StepText(self.queue, self.queue.i))
	f.count:SetText(string.format(L["%d von %d erledigt"], self.queue.done, #self.queue.steps))
	if ns.InCombat() then
		f.btn.text:SetText(GRAY .. L["nicht im Kampf"] .. "|r")
		f.status:SetText(GRAY .. L["Im Kampf nicht möglich – bitte nach dem Kampf noch einmal."] .. "|r")
		self.waitCombat = true
		return
	end
	self.waitCombat = nil
	local macro = GA.Macro(s.kind, s.name)
	f.btn:SetAttribute("type", "macro")
	f.btn:SetAttribute("macrotext", macro)
	GA.lastMacro = macro
	f.btn.text:SetText(KindLabel(s.kind) .. ": " .. s.name)
	if not self.pending then f.status:SetText(GRAY .. L["Zum Ausführen auf den Knopf klicken."] .. "|r") end
end

-- vor dem Klick (Blizzard führt danach den Makro-Text aus)
function GA.PreClick(b)
	if ns.InCombat() then return end
	if b.finished or GA.pending then b:SetAttribute("type", nil) return end
	if ns.Test and ns.Test:Active() then b:SetAttribute("type", nil) return end
	local s = GA:Current()
	if s then b:SetAttribute("type", "macro"); b:SetAttribute("macrotext", GA.Macro(s.kind, s.name)) end
end

-- nach dem Klick: auf die Bestätigung des Spiels warten
function GA.PostClick(b)
	if b.finished then GA:Cancel() return end
	if GA.pending or ns.InCombat() then return end
	local s = GA:Current()
	if not s then return end
	if ns.Test and ns.Test:Active() then
		ns.Test:Log("GUILDACT", s.name, GA.Macro(s.kind, s.name))
		if s.kind == "promote" and ns.Test.Promote then ns.Test:Promote(s.name)
		elseif s.kind == "remove" and ns.Test.Kick then ns.Test:Kick(s.name) end
		GA:Confirmed(true)
		return
	end
	GA.pending = { step = s, t = GetTime(), q = GA.queue }
	GA.frame.status:SetText(GOLD .. L["Warte auf die Bestätigung des Spiels …"] .. "|r")
	if ns.Diag then ns.Diag("VERWALTUNG", s.kind .. " über sicheren Knopf") end
	if ns.GuildRoster then C_Timer.After(1, function() ns.GuildRoster() end) end
	local pend = GA.pending
	C_Timer.After(GA.TIMEOUT, function() if GA.pending == pend then GA:TimedOut() end end)
end

function GA:TimedOut()
	local p = self.pending
	self.pending = nil
	if not p or not self.queue then return end
	self.queue.failed = self.queue.failed + 1
	if self.frame then
		self.frame.status:SetText(RED .. L["Nicht ausgeführt – das Spiel hat nichts bestätigt (Recht, Rang oder Name?). Noch einmal klicken zum Wiederholen."] .. "|r")
	end
	if ns.Diag then ns.Diag("VERWALTUNG", p.step.kind .. " ohne Bestätigung") end
	self:Prepare()
end

-- Bestätigung: Schritt erledigt, in den Verlauf, nächster Schritt
function GA:Confirmed(test)
	local q = self.queue
	local s = self:Current()
	self.pending = nil
	if not (q and s) then return end
	q.done = q.done + 1
	if not test then GA.LogRank(s) end
	q.i = q.i + 1
	if self.frame then
		self.frame.status:SetText(GREEN .. (test and "[Test] " or "") .. string.format(L["Erledigt: %s"], KindLabel(s.kind) .. " " .. s.name) .. "|r")
		self.frame.count:SetText(string.format(L["%d von %d erledigt"], q.done, #q.steps))
	end
	if s.kind == "promote" or s.kind == "demote" then ns:Fire("GS_PROMO") end
	self:Prepare()
	ns:Fire("GS_GUILDACT")
end

-- hat das Spiel den wartenden Schritt ausgeführt? (aus der Gildenliste)
function GA:CheckRoster()
	local p = self.pending
	if not p then return false end
	local s = p.step
	local ri = RankOf(s.name)
	local ok = (s.kind == "promote" and ri ~= nil and s.to ~= nil and ri <= s.to)
		or (s.kind == "demote" and ri ~= nil and s.to ~= nil and ri >= s.to)
		or (s.kind == "remove" and ri == nil and ns.Roster and #ns.Roster.list > 0)
		or (s.kind == "leader" and ri == 0)
	if ok then self:Confirmed() end
	return ok
end

-- Systemmeldungen des Spiels: Befördert/Degradiert/Entfernt/Neuer Gildenmeister mit dem Namen des wartenden Schritts
local PAT
local function Patterns()
	if PAT then return PAT end
	PAT = {}
	local function add(kind, g)
		local p = type(g) == "string" and ns.ToPattern and ns.ToPattern(g)
		if p then PAT[#PAT + 1] = { kind = kind, p = p } end
	end
	add("promote", ERR_GUILD_PROMOTE_SSS)
	add("demote", ERR_GUILD_DEMOTE_SSS)
	add("remove", ERR_GUILD_REMOVE_SS)
	add("leader", ERR_GUILD_LEADER_CHANGED_SS)
	return PAT
end

function GA.OnSystem(msg)
	local p = GA.pending
	if not p or type(msg) ~= "string" or ns.IsSecret(msg) then return false end
	for _, x in ipairs(Patterns()) do
		if x.kind == p.step.kind then
			local a, b, c = msg:match(x.p)
			for _, n in ipairs({ a, b, c }) do
				if type(n) == "string" and ns.Same(ns.Short(n), p.step.name) then GA:Confirmed() return true end
			end
		end
	end
	return false
end

ns:On("CHAT_MSG_SYSTEM", function(msg) GA.OnSystem(msg) end)
ns:Listen("GS_ROSTER", function() GA:CheckRoster() end)
ns:On("PLAYER_REGEN_ENABLED", function()
	if GA.hideAfterCombat then
		GA.hideAfterCombat = nil
		if GA.frame and not GA.queue then GA.frame:Hide() end
	end
	if GA.waitCombat then GA:Prepare() end
end)

-- Rang-Verlauf (RV5): wer, wen, von -> nach, Zeit; nur in den Gildendaten im Spiel
function GA.LogRank(s)
	if not ns.guild then return end
	local g = ns.G()
	g.rankLog = type(g.rankLog) == "table" and g.rankLog or {}
	local from = s.from and RankName(s.from) or ""
	local to = s.to and RankName(s.to) or (s.kind == "remove" and "–" or s.kind == "leader" and RankName(0) or "")
	table.insert(g.rankLog, 1, { t = ns.Now(), by = ns.Me(), n = s.name, k = s.kind, f = from, to = to })
	while #g.rankLog > GA.LOG_MAX do table.remove(g.rankLog) end
end

------------------------------------------------------------
-- Fenster "Gilden-Aktion" mit dem sicheren Knopf
------------------------------------------------------------
function GA:Build()
	if self.frame then return self.frame end
	local f = CreateFrame("Frame", "GuildSentinelGuildAct", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(460, 150)
	f:SetPoint("CENTER", 0, 120)
	f:SetFrameStrata("DIALOG")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function() f:StartMoving() end)
	f:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
	UI.Box(f, 0.05, 0.06, 0.08, 0.98, 0.9, 0.7, 0.2, 0.8)
	f:Hide()
	local title = UI:Label(f, L["Gilden-Aktion"], "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 14, -12)
	f.count = UI:Label(f, "", "GameFontHighlightSmall")
	f.count:SetPoint("TOPRIGHT", -14, -16)
	f.step = UI:Label(f, "", "GameFontHighlight")
	f.step:SetPoint("TOPLEFT", 14, -40)
	f.step:SetWidth(432)
	f.step:SetJustifyH("LEFT")

	-- sicherer Knopf: Blizzards Befehl wird vom Klick des Spielers ausgeführt
	local tpl = "SecureActionButtonTemplate" .. (UI.BACKDROP and ("," .. UI.BACKDROP) or "")
	local b = CreateFrame("Button", "GuildSentinelGuildActButton", f, tpl)
	b:SetSize(300, 28)
	b:SetPoint("TOPLEFT", 14, -72)
	UI.Box(b, 0.9 * 0.45, 0.7 * 0.45, 0.2 * 0.45, 1, 0.9, 0.7, 0.2, 0.9)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	b.text:SetPoint("LEFT", 8, 0)
	b.text:SetPoint("RIGHT", -8, 0)
	b.text:SetWordWrap(false)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetPoint("TOPLEFT", 1, -1)
	hl:SetPoint("BOTTOMRIGHT", -1, 1)
	hl:SetTexture(UI.WHITE)
	hl:SetVertexColor(1, 1, 1, 0.08)
	b:RegisterForClicks("AnyUp", "AnyDown")
	b:SetScript("PreClick", GA.PreClick)
	b:SetScript("PostClick", GA.PostClick)
	f.btn = b
	local cancel = UI:Button(f, L["Abbrechen"], 120, 28, function() GA:Cancel() end)
	cancel:SetPoint("LEFT", b, "RIGHT", 12, 0)
	f.status = UI:Label(f, "", "GameFontHighlightSmall")
	f.status:SetPoint("TOPLEFT", 14, -110)
	f.status:SetWidth(432)
	f.status:SetJustifyH("LEFT")
	if ns.RegisterUI then ns.RegisterUI(f) end
	self.frame = f
	return f
end

function GA:Show()
	local f = self:Build()
	f.status:SetText("")
	f:Show()
end

------------------------------------------------------------
-- Einstiege
------------------------------------------------------------
local function Reason(why)
	if why == "above" then return L["Nicht über den eigenen Rang und nie zum Gildenmeister."]
	elseif why == "rights" then return L["Dein Rang hat dieses Recht im Spiel nicht."]
	elseif why == "same" then return L["Hat diesen Rang schon."]
	elseif why == "below" then return L["Diesen Rang gibt es nicht."] end
	return L["Mitglied nicht in der Gildenliste."]
end
GA.Reason = Reason

function GA:SetRank(name, target)
	local steps, why = GA.RankSteps(name, target)
	if not steps then ns:Print(Reason(why)) return false end
	return self:Start(steps, target)
end

-- eine Aktion für ein oder mehrere Mitglieder (je Mitglied ein Klick)
function GA:Run(kind, names)
	if type(names) == "string" then names = { names } end
	return self:Start(GA.Steps(kind, names))
end
