-- ThreatSentinel - Core.lua
-- Grundlagen: Einstellungen, Profile, Ereignisse, Zauber, Gruppe, Rollen, Tank-Erkennung.

local ADDON, ns = ...
local L = ns.L

ns.version = "1.7.4"
ns.modules = {}
ns.testMode = false
ns.groupUnits = { "player" }
ns.groupNames = {}
ns.syncRoles = {}
ns.ccNames = {}
ns.defensives = {}
ns.fakeNames = {}
ns.tauntMode = nil
ns.backupSpells = {}
ns.liveTest = false
ns.nameToUnit = {}
ns.spellIdByName = {}
ns.cdTrack = {}
ns.compat = {}
ns.simSecret = false   -- Testzentrale: Forever-Sperren simulieren
-- Retail (Midnight, Interface ab 110000): nur zum Testen der Sperren, die WoW Forever übernimmt
ns.isRetail = (select(4, GetBuildInfo()) or 0) >= 110000

------------------------------------------------------------
-- Standardwerte
------------------------------------------------------------
ns.defaults = {
	enabled = true,
	activeOnlyTank = true,
	activeSolo = false,
	autoEnableNameplates = true,
	myRole = "AUTO",
	tauntOverride = "",

	-- Plaketten
	heldPlateAlpha = 0.35,
	heldHealthAlpha = 1,
	heldScale = 0.8,
	outOfCombatMode = "normal",
	warnThreshold = 90,
	loosePulse = true,
	looseFire = true,       -- lose Plaketten brennen
	looseScale = 1.25,
	borderSize = 3,
	colorDD = { 1, 0.1, 0.1, 1 },   -- Aggro bei einem Spieler: rot (und Flammen)
	colorHealer = { 1, 0.1, 0.1, 1 },
	colorWarn = { 1, 0.5, 0, 1 },   -- Vorwarnung "bald Aggro": orange, blinkt
	warnBlink = true,
	colorRegain = { 0.2, 1, 0.2, 1 },
	colorClaimed = { 0.3, 0.6, 1, 1 },
	showHints = true,
	deficitThreshold = 90,
	showSunder = true,
	showTankStripe = true,
	ignoreCC = true,
	petsSafe = true,
	healerHeuristic = true,

	-- Töne
	sound = true,
	soundHealer = "fx_hupe",    -- Aggro an einen Spieler (nicht Tank): Hupe
	soundDD = "fx_hupe",
	soundRegain = "ts_regain",
	soundResist = "none",       -- Standard: nur Aggroverlust hat einen Ton
	soundEmergency = "none",
	soundWarn = "none",         -- Vorwarnung (gelber Rand)
	soundDDWarn = "none",       -- DD-Ansicht: du ziehst gleich die Aggro
	soundChannel = "Master",
	regainSound = false,

	-- Meldungen
	chatChannel = "TANKS",
	announceResist = true,
	announceCC = true,
	ccMinDuration = 1.5,
	aoeHint = true,
	aoeThreshold = 3,
	healerRange = true,
	emergency = true,
	emergencyHP = 30,
	centerSize = 20,
	centerY = 120,
	regainText = false,
	keyHintDone = false,

	-- Sync
	sync = true,
	ownerGrace = 2.5,

	-- HUD und DD-Ansicht
	hud = true,
	hudLocked = true,
	-- am rechten Rand, damit nichts über den Namensplaketten liegt
	hudPoint = { "RIGHT", "UIParent", "RIGHT", -60, 140 },
	hudScale = 1,
	hudMaxRows = 5,
	ddView = true,
	ddWarn = 90,
	ddSound = true,
	ddPoint = { "CENTER", "UIParent", "CENTER", 0, -200 },
	ddScale = 1,
	ddWidth = 190,

	-- Aggrometer
	meter = true,
	meterOnlyTank = false,
	meterRows = 6,
	meterPoint = { "RIGHT", "UIParent", "RIGHT", -60, -20 },
	meterScale = 1,
	meterWidth = 230,

	-- Ini-Prüfung: Testprotokoll läuft automatisch, solange du eine Instanz tankst
	dungeonCheck = true,
	dungeonCheckRaid = false,
	dungeonShots = false,

	-- Testzentrale
	testPreview = true,
	testPetTank = false,    -- Live-Test: das eigene Pet ist der Tank (Jäger / Hexer); der Testassistent schaltet es ein
	guide = {},             -- Testassistent: Fortschritt und Ergebnisse

	-- gelernte Abklingzeiten (Ersatz, wenn das Spiel sie im Kampf verbirgt)
	cdLearned = {},

	-- Minimap
	minimapShow = true,
	minimapAngle = 220,
}

------------------------------------------------------------
-- Schutz vor geschützten Werten ("Secrets", WoW Forever / Midnight)
-- Mit geschützten Werten darf ein Addon nicht rechnen oder vergleichen - das gäbe Lua-Fehler.
-- Jeder Wert, der geschützt sein kann, wird vorher geprüft; dann greift ein Ersatzweg.
------------------------------------------------------------
local issecret = issecretvalue or function() return false end

-- Kategorien, die die Testzentrale als "geschützt" simulieren kann
ns.SIM = {
	threatValues = true, cooldowns = true, auras = true, selfAuras = true, guid = true,
	health = true, combatlog = true, strata = true, range = true, sync = true,
}

function ns.IsSecret(v, cat)
	if issecret(v) then return true end
	if ns.simSecret and cat and ns.SIM[cat] and v ~= nil then return true end
	return false
end

-- Wert oder Ersatz, falls geschützt
function ns.Safe(v, default, cat)
	if ns.IsSecret(v, cat) then return default, true end
	return v, false
end

-- Merkt sich, ob eine Funktion normal läuft ("ok"), einen Ersatzweg nutzt ("fallback")
-- oder abgeschaltet ist ("off"). Die Diagnose zeigt das an.
ns.COMPAT_ORDER = {
	"threat", "threatValues", "cooldowns", "mobAuras", "selfAuras", "combatlog",
	"guid", "sync", "chat", "health", "range", "strata",
}
local SEVERITY = { ok = 1, fallback = 2, off = 3 }
function ns:Compat(feature, mode)
	local c = self.compat[feature]
	if not c then
		c = { worst = mode }
		self.compat[feature] = c
	end
	c.mode = mode
	c.t = GetTime()
	if SEVERITY[mode] > SEVERITY[c.worst] then c.worst = mode end
end

function ns:ResetCompat()
	wipe(self.compat)
end

------------------------------------------------------------
-- Hilfsfunktionen
------------------------------------------------------------
function ns:Print(msg)
	DEFAULT_CHAT_FRAME:AddMessage("|cff3fa7ffThreatSentinel|r: " .. tostring(msg))
end

local function MergeDefaults(dst, src)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			MergeDefaults(dst[k], v)
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
end

function ns.SpellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	if GetSpellInfo then return (GetSpellInfo(id)) end
end

function ns.SpellIcon(spell)
	if C_Spell and C_Spell.GetSpellTexture then return C_Spell.GetSpellTexture(spell) end
	if GetSpellTexture then return GetSpellTexture(spell) end
end

-- Abklingzeit roh lesen: start, dauer, lesbar?
local function ReadCooldown(spell)
	local start, dur
	local ok = pcall(function()
		if GetSpellCooldown then
			start, dur = GetSpellCooldown(spell)
		elseif C_Spell and C_Spell.GetSpellCooldown then
			local info = C_Spell.GetSpellCooldown(spell)
			if info then start, dur = info.startTime, info.duration end
		end
	end)
	if not ok or ns.IsSecret(start, "cooldowns") or ns.IsSecret(dur, "cooldowns") then return nil, nil, false end
	return start, dur, true
end
ns.ReadCooldown = ReadCooldown

-- Restliche Abklingzeit in Sekunden. Verbirgt das Spiel sie im Kampf, rechnet das Addon
-- selbst mit: ab dem eigenen Wirken plus der bekannten Dauer.
function ns.SpellCD(spell)
	if not spell then return 0 end
	-- Pet-Spott: das Spiel liefert die Abklingzeit von Pet-Zaubern nicht über den Namen - selbst messen
	if ns.tauntMode == "pet" and spell == ns.tauntSpell then
		local e = ns.cdTrack[spell]
		return e and math.max(0, e - GetTime()) or 0
	end
	local start, dur, ok = ReadCooldown(spell)
	if ok then
		ns:Compat("cooldowns", "ok")
		if not start or start == 0 or not dur or dur <= 1.6 then return 0 end
		return math.max(0, start + dur - GetTime())
	end
	ns:Compat("cooldowns", "fallback")
	local e = ns.cdTrack[spell]
	if e then return math.max(0, e - GetTime()) end
	return 0
end

-- Bekannte Grund-Abklingzeiten (Sekunden) als letzter Ersatz
local BASE_CD = {
	[355] = 10, [694] = 120, [1161] = 600, [6795] = 10, [5209] = 600,
	[871] = 1800, [12975] = 600, [22842] = 180, [31789] = 15, [20271] = 10,
	[498] = 300, [642] = 300, [633] = 3600,
	[2649] = 5, [3716] = 5,
	-- Retail (Test)
	[62124] = 8, [56222] = 8, [185245] = 8, [115546] = 8, [48792] = 120, [187827] = 180, [115203] = 360,
}
function ns:BaseCooldown(name)
	local learned = self.db and self.db.cdLearned and self.db.cdLearned[name]
	if learned then return learned end
	local id = self.spellIdByName[name]
	if id and GetSpellBaseCooldown then
		local ok, ms = pcall(GetSpellBaseCooldown, id)
		if ok and not issecret(ms) and type(ms) == "number" and ms > 1600 then return ms / 1000 end
	end
	return id and BASE_CD[id] or nil
end

-- true / false / nil (unbekannt oder geschützt)
function ns.SpellInRange(spell, unit)
	if not spell then return nil end
	local ok, r = pcall(function()
		if IsSpellInRange then return IsSpellInRange(spell, unit) end
		if C_Spell and C_Spell.IsSpellInRange then return C_Spell.IsSpellInRange(spell, unit) end
	end)
	if not ok then return nil end
	if ns.IsSecret(r, "range") then ns:Compat("range", "off") return nil end
	if r == nil then return nil end
	ns:Compat("range", "ok")
	if type(r) == "boolean" then return r end
	return r == 1
end

-- Gibt name, stapel, spellId einer Aura zurück (Werte können geschützt sein!)
function ns.Aura(unit, index, filter)
	if filter == "HARMFUL" and UnitDebuff then
		local name, _, count, _, _, _, _, _, _, id = UnitDebuff(unit, index)
		return name, count, id
	elseif filter == "HELPFUL" and UnitBuff then
		local name, _, count, _, _, _, _, _, _, id = UnitBuff(unit, index)
		return name, count, id
	elseif C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
		local a = C_UnitAuras.GetAuraDataByIndex(unit, index, filter)
		if a then return a.name, a.applications, a.spellId end
	end
end

-- Sucht eine Aura auf einer Einheit. Rückgabe: gefunden (true/false), lesbar (true/false)
function ns:FindAura(unit, filter, ids, names, cat)
	for i = 1, 40 do
		local ok, name, _, id = pcall(ns.Aura, unit, i, filter)
		if not ok then return false, false end
		if ns.IsSecret(name, cat) or ns.IsSecret(id, cat) then return false, false end
		if not name then return false, true end
		if (id and ids[id]) or (names and names[name]) then return true, true end
	end
	return false, true
end

-- Schlüssel eines Mobs: GUID, oder die Plakette, falls die GUID geschützt ist
function ns:MobKey(unit)
	local guid = UnitGUID(unit)
	if ns.IsSecret(guid, "guid") then
		ns:Compat("guid", "fallback")
		return "plate:" .. unit, false
	end
	if guid then ns:Compat("guid", "ok") end
	return guid, true
end

-- Ist das Mausziel bzw. Ziel diese Plakette? (geschützte Antworten = nein)
function ns:SameUnit(a, b)
	local ok, r = pcall(UnitIsUnit, a, b)
	if not ok then return false end
	return ns.Safe(r, false) and true or false
end

-- Plakette (nameplateN), die gerade dem Mausziel bzw. Ziel entspricht
function ns:PlateFor(token)
	if not ns.Safe(UnitExists(token), false) then return nil end
	if C_NamePlate and C_NamePlate.GetNamePlateForUnit then
		local ok, plate = pcall(C_NamePlate.GetNamePlateForUnit, token)
		if ok and plate and not ns.IsSecret(plate.namePlateUnitToken) and plate.namePlateUnitToken then
			return plate.namePlateUnitToken
		end
	end
	for unit in pairs(ns.mobs or {}) do
		if ns:SameUnit(unit, token) then return unit end
	end
end

function ns:SpellbookHas(name)
	if not name or name == "" then return false end
	local lname = name:lower()
	if GetNumSpellTabs and GetSpellTabInfo and GetSpellBookItemName then
		for tab = 1, GetNumSpellTabs() do
			local _, _, offset, num = GetSpellTabInfo(tab)
			for i = offset + 1, offset + num do
				local n = GetSpellBookItemName(i, BOOKTYPE_SPELL or "spell")
				if n and n:lower() == lname then return true end
			end
		end
	elseif C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines then
		for tab = 1, C_SpellBook.GetNumSpellBookSkillLines() do
			local info = C_SpellBook.GetSpellBookSkillLineInfo(tab)
			if info then
				for i = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
					local n = C_SpellBook.GetSpellBookItemName(i, Enum.SpellBookSpellBank.Player)
					if n and n:lower() == lname then return true end
				end
			end
		end
	end
	return false
end

function ns:FullName(unit)
	local name, realm = UnitName(unit)
	if not name then return nil end
	if realm and realm ~= "" then return name .. "-" .. realm end
	return name
end

-- Name der aktiven Gestalt / Haltung mit ID, z. B. "Bärengestalt (5)"
function ns:FormName()
	local form = "-"
	if GetShapeshiftFormID then
		local ok, id = pcall(GetShapeshiftFormID)
		if ok and not ns.IsSecret(id) then form = tostring(id or 0) end
	end
	for i = 1, (GetNumShapeshiftForms and GetNumShapeshiftForms() or 0) do
		local ok, _, active, _, spellID = pcall(GetShapeshiftFormInfo, i)
		if ok and not ns.IsSecret(active) and active and not ns.IsSecret(spellID) then
			local n = spellID and ns.SpellName(spellID)
			if n then form = n .. " (" .. form .. ")" end
			break
		end
	end
	if form == "0" then form = "none (0)" end
	return form
end

-- Spezialisierung (nur Retail), z. B. "Wächter (TANK)"
function ns:SpecName()
	if GetSpecialization and GetSpecializationInfo then
		local ok, idx = pcall(GetSpecialization)
		if ok and idx and not ns.IsSecret(idx) then
			local ok2, _, name, _, _, role = pcall(GetSpecializationInfo, idx)
			if ok2 and name and not ns.IsSecret(name) then return name .. " (" .. tostring(ns.Safe(role, "?")) .. ")" end
		end
	end
	return "-"
end

-- "Zerreissen reicht" / "Zermalmen reicht" / "Bedrohung reicht" je nach Klasse
function ns:DeficitText()
	if self.class == "WARRIOR" then return L.DEFICIT_WARRIOR end
	if self.class == "DRUID" and not self.isRetail then return L.DEFICIT_DRUID end
	return L.DEFICIT_OTHER
end

function ns:InGroupByName(name)
	if not name then return false end
	return self.groupNames[name] or self.fakeNames[name] or false
end

------------------------------------------------------------
-- Klassen-Zauber
------------------------------------------------------------
ns.CLASS_SPELLS = {
	-- backup = Ersatz, wenn der Spott widerstanden wurde
	WARRIOR = { taunt = { 355 }, aoe = { 1161 }, backup = { 694, 1161 }, defensive = { 871, 12975 } },
	DRUID   = { taunt = { 6795 }, aoe = { 5209 }, backup = { 5209 }, defensive = { 22842 } },
	-- Paladin: kein normaler Spott.
	--   WoW Forever: Richturteil (20271) verspottet nur mit aktivem Siegel der Wut (1311649, Beta-Stand)
	--   TBC: Rechtschaffene Verteidigung (31789) wird auf den angegriffenen MITSPIELER gewirkt
	--   Classic Era: kein Spott - nur Warnungen
	-- Erkennung über Spell-IDs, nicht über Namen.
	-- nur Retail (zum Testen der Forever-Sperren): Todesritter, Dämonenjäger, Mönch
	-- nur für den Live-Test "Pet ist der Tank": Knurren (Jäger) / Qual (Leerwandler, Hexer)
	HUNTER      = { taunt = {}, petTaunt = 2649, aoe = {}, defensive = {} },
	WARLOCK     = { taunt = {}, petTaunt = 3716, aoe = {}, defensive = {} },
	DEATHKNIGHT = { taunt = { 56222 }, aoe = {}, defensive = { 48792 } },
	DEMONHUNTER = { taunt = { 185245 }, aoe = {}, defensive = { 187827 } },
	MONK        = { taunt = { 115546 }, aoe = {}, defensive = { 115203 } },
	PALADIN = {
		-- Hand der Abrechnung gibt es nur in Retail; in Classic/Forever wird sie nicht gefunden
		taunt = { 62124 },
		sealTaunt = { seal = 1311649, judgement = 20271 },
		friendlyTaunt = { 31789 },
		aoe = {},
		defensive = { 498, 642, 633 },
	},
}

-- Kontrolleffekte, bei denen ein Mob ignoriert wird
local CC_IDS = {
	118, 12824, 12825, 12826, 28271, 28272,  -- Verwandlung
	6770, 2070, 11297,                       -- Kopfnuss
	9484, 9485, 10955,                       -- Untote fesseln
	2637, 18657, 18658,                      -- Winterschlaf
	3355, 14308, 14309,                      -- Eiskältefalle
	1776, 1777, 8629, 11285, 11286,          -- Solarplexus
	2094,                                    -- Blenden
	6358,                                    -- Verführung
	710, 18647,                              -- Verbannen
	20066,                                   -- Buße
	1513, 14326, 14327,                      -- Wildtier ängstigen
	19386, 24132, 24133,                     -- Stich des Flügeldrachen
}

function ns:BuildCCNames()
	wipe(self.ccNames)
	for _, id in ipairs(CC_IDS) do
		local n = ns.SpellName(id)
		if n then self.ccNames[n] = true end
	end
end

-- Kennt der Spieler den Zauber mit dieser ID?
function ns:KnowsSpell(id)
	if IsPlayerSpell and IsPlayerSpell(id) then return true end
	if IsSpellKnown and IsSpellKnown(id) then return true end
	local n = ns.SpellName(id)
	return n and ns:SpellbookHas(n) or false
end

-- Siegel der Wut aktiv? (Paladin in WoW Forever) - über die Aura-ID, Name nur als Ersatz
function ns:HasSealOfFury()
	if not self.sealId then return false end
	local found, readable = self:FindAura("player", "HELPFUL", { [self.sealId] = true },
		self.sealName and { [self.sealName] = true } or nil, "selfAuras")
	if readable then
		self:Compat("selfAuras", "ok")
		if found then self.sealSeen = GetTime() end
		return found
	end
	-- Ersatz: eigenes Wirken des Siegels mitzählen (Siegel halten 30 s, Richturteil verbraucht es)
	self:Compat("selfAuras", "fallback")
	return (self.sealUntil or 0) > GetTime()
end

-- Kann der Spott gerade wirken? (Paladin mit Siegel-Spott braucht das Siegel)
function ns:TauntUsable()
	if not self.tauntSpell then return false end
	if self.tauntMode == "seal" then return self:HasSealOfFury() end
	return true
end

-- tauntMode: "hostile" (Spott auf den Mob), "friendly" (auf den angegriffenen Mitspieler),
--            "seal" (Richturteil mit Siegel der Wut), nil (kein Spott)
function ns:UpdateSpells()
	local def = self.CLASS_SPELLS[self.class] or {}
	local function firstKnown(ids)
		for _, id in ipairs(ids or {}) do
			if ns:KnowsSpell(id) then return ns.SpellName(id) end
		end
	end
	self.tauntSpell, self.tauntMode, self.sealId, self.sealName = nil, nil, nil, nil
	local over = self.db.tauntOverride
	if over and over ~= "" then
		self.tauntSpell, self.tauntMode = over, "hostile"
	else
		local hostile = firstKnown(def.taunt)
		if hostile then
			self.tauntSpell, self.tauntMode = hostile, "hostile"
		elseif def.petTaunt then
			-- Spott des Pets (wird mit /cast vom Pet gewirkt)
			self.tauntSpell, self.tauntMode = ns.SpellName(def.petTaunt), "pet"
		elseif def.sealTaunt and ns:KnowsSpell(def.sealTaunt.seal) and ns:KnowsSpell(def.sealTaunt.judgement) then
			self.tauntSpell, self.tauntMode = ns.SpellName(def.sealTaunt.judgement), "seal"
			self.sealId, self.sealName = def.sealTaunt.seal, ns.SpellName(def.sealTaunt.seal)
		else
			local friendly = firstKnown(def.friendlyTaunt)
			if friendly then self.tauntSpell, self.tauntMode = friendly, "friendly" end
		end
	end
	self.aoeSpell = firstKnown(def.aoe)
	self.backupSpells = {}
	for _, id in ipairs(def.backup or {}) do
		local n = ns.SpellName(id)
		if n and ns:SpellbookHas(n) then table.insert(self.backupSpells, n) end
	end
	wipe(self.defensives)
	for _, id in ipairs(def.defensive or {}) do
		local n = ns.SpellName(id)
		if n and ns:SpellbookHas(n) then table.insert(self.defensives, n) end
	end
	self.sunderName = ns.SpellName(7386)

	-- Namen -> Grund-IDs (für das Mitrechnen der Abklingzeiten)
	wipe(self.spellIdByName)
	local function map(ids) for _, id in ipairs(ids or {}) do
		local n = ns.SpellName(id)
		if n then self.spellIdByName[n] = id end
	end end
	map(def.taunt); map(def.aoe)
	if def.petTaunt then map({ def.petTaunt }) end; map(def.backup); map(def.defensive); map(def.friendlyTaunt)
	if def.sealTaunt then map({ def.sealTaunt.judgement, def.sealTaunt.seal }) end
	map({ 7386, 25780 })
	-- eigener Spott-Name aus den Einstellungen: ID ermitteln, damit die Abklingzeit mitgerechnet wird
	if over and over ~= "" and not self.spellIdByName[over] then
		local id
		if C_Spell and C_Spell.GetSpellInfo then
			local ok, info = pcall(C_Spell.GetSpellInfo, over)
			if ok and type(info) == "table" and not ns.IsSecret(info.spellID) then id = info.spellID end
		elseif GetSpellInfo then
			id = select(7, GetSpellInfo(over))
		end
		id = id or (def.taunt and def.taunt[1]) or (def.friendlyTaunt and def.friendlyTaunt[1])
		if id then self.spellIdByName[over] = id end
	end
	if self.Taunt then self.Taunt:UpdateMacros() end
end

------------------------------------------------------------
-- Tank-Erkennung
------------------------------------------------------------
local stanceCache, stanceCacheTime = false, 0
local TANK_FORMS = { WARRIOR = { [18] = true }, DRUID = { [5] = true, [8] = true } }

local function ReadStance(class)
	-- Retail: Tank ist, wer eine Tank-Spezialisierung hat
	if ns.isRetail and GetSpecialization and GetSpecializationRole then
		local ok, spec = pcall(GetSpecialization)
		if ok and spec and not issecret(spec) then
			local ok2, role = pcall(GetSpecializationRole, spec)
			if ok2 and not issecret(role) then
				if role ~= "TANK" then return false end
				-- Wächter-Druide nur in Bärengestalt (Katze, Reisen, Menschengestalt zählen nicht)
				if class == "DRUID" then
					local ok3, form = pcall(GetShapeshiftFormID)
					if not ok3 or issecret(form) then return nil end
					return form == 5 or form == 8
				end
				return true
			end
		end
	end
	if class == "WARRIOR" or class == "DRUID" then
		if GetShapeshiftFormID then
			local ok, id = pcall(GetShapeshiftFormID)
			if ok and not issecret(id) and id and TANK_FORMS[class][id] then return true end
		end
		for i = 1, (GetNumShapeshiftForms() or 0) do
			local ok, _, active, _, spellID = pcall(GetShapeshiftFormInfo, i)
			if not ok or issecret(active) or issecret(spellID) then return nil end
			if active then
				if class == "WARRIOR" and spellID == 71 then return true end
				if class == "DRUID" and (spellID == 5487 or spellID == 9634) then return true end
			end
		end
		return false
	elseif class == "PALADIN" then
		local fury = ns.SpellName(25780)
		local found, readable = ns:FindAura("player", "HELPFUL", { [25780] = true }, fury and { [fury] = true } or nil, "selfAuras")
		if not readable then return nil end
		return found
	end
	return false
end

function ns:IsTankStance()
	local now = GetTime()
	if now - stanceCacheTime < 0.1 then return stanceCache end
	stanceCacheTime = now
	local result = ReadStance(self.class)
	if result == nil then
		-- geschützt: letzten bekannten Stand behalten; Rechtschaffener Zorn hält 30 Minuten
		self:Compat("selfAuras", "fallback")
		if self.class == "PALADIN" and (self.rfCast or 0) > now - 1800 then result = true
		else result = stanceCache end
	end
	stanceCache = result and true or false
	return stanceCache
end

-- Wer ist "der Tank", aus dessen Sicht das Addon urteilt?
-- Normal: du selbst. Im Live-Test mit "Pet ist der Tank": dein Pet.
function ns:TankUnit()
	if self.liveTest and self.db and self.db.testPetTank and UnitExists("pet")
		and not ns.Safe(UnitIsDeadOrGhost("pet"), false) and not self:IsTankStance() then
		return "pet"
	end
	return "player"
end

-- Pet-Spott zählt nur im Live-Test mit "Pet ist der Tank" - nie im normalen Spiel
function ns:PetTankActive()
	return self.tauntMode == "pet" and self.liveTest and self:TankUnit() == "pet"
end

function ns:IsActive()
	local db = self.db
	if not db or not db.enabled then return false end
	if self.testMode or self.liveTest then return true end
	if not IsInGroup() and not db.activeSolo then return false end
	if db.activeOnlyTank and not self:IsTankStance() then return false end
	return true
end

------------------------------------------------------------
-- Gruppe und Rollen
------------------------------------------------------------
function ns:UpdateGroup()
	local units, names, toUnit = {}, {}, {}
	local function add(u) if UnitExists(u) then units[#units + 1] = u end end
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do add("raid" .. i); add("raidpet" .. i) end
	else
		units[1] = "player"
		add("pet")
		for i = 1, GetNumSubgroupMembers() do add("party" .. i); add("partypet" .. i) end
	end
	for _, u in ipairs(units) do
		if UnitIsPlayer(u) then
			local n = self:FullName(u)
			if n then names[n] = true; toUnit[n] = u end
		end
	end
	self.groupUnits = units
	self.groupNames = names
	self.nameToUnit = toUnit
end

local roleCache = {}
function ns:ClearRoleCache() wipe(roleCache) end

function ns:GuessRole(unit)
	if not self.db.healerHeuristic then return "DAMAGER" end
	local _, class = UnitClass(unit)
	if (class == "PRIEST" or class == "SHAMAN" or class == "PALADIN" or class == "DRUID") and UnitPowerType(unit) == 0 then
		return "HEALER"
	end
	return "DAMAGER"
end

function ns:MyRole()
	if self:IsTankStance() then return "TANK" end
	local r = self.db.myRole
	if r == "HEALER" or r == "DAMAGER" then return r end
	return self:GuessRole("player")
end

function ns:GetRole(unit)
	local c = roleCache[unit]
	if c then return c end
	local r
	if not UnitIsPlayer(unit) then
		-- Live-Test: Begleiter zählen als DD, damit man solo echte Aggroverluste sieht
		r = self.liveTest and "DAMAGER" or "PET"
	elseif UnitIsUnit(unit, "player") then
		r = self:MyRole()
	else
		local s = self.syncRoles[self:FullName(unit) or ""]
		if s and GetTime() - s.t < 90 then
			r = s.role
		elseif GetPartyAssignment and GetPartyAssignment("MAINTANK", unit) then
			r = "TANK"
		else
			local ra = UnitGroupRolesAssigned and UnitGroupRolesAssigned(unit)
			if ra and ra ~= "NONE" then r = ra else r = self:GuessRole(unit) end
		end
	end
	roleCache[unit] = r
	return r
end

function ns:IsSafeUnit(unit)
	local r = self:GetRole(unit)
	return r == "TANK" or (r == "PET" and self.db.petsSafe)
end

------------------------------------------------------------
-- Profile
------------------------------------------------------------
function ns:InitDB()
	ThreatSentinelDB = ThreatSentinelDB or {}
	local DB = ThreatSentinelDB
	DB.profiles = DB.profiles or {}
	DB.chars = DB.chars or {}
	self.charKey = (UnitName("player") or "?") .. " - " .. (GetRealmName() or "?")
	local pname = DB.chars[self.charKey] or self.charKey
	DB.chars[self.charKey] = pname
	DB.profiles[pname] = DB.profiles[pname] or {}
	MergeDefaults(DB.profiles[pname], self.defaults)
	self.db = DB.profiles[pname]
	self:Migrate(self.db)
	self.profileName = pname
end

-- Alte Standardwerte auf die neuen umstellen (nur wenn sie nie geändert wurden)
local OLD_SOUNDS = { soundHealer = "raidwarning", soundDD = "alarm", soundRegain = "click", soundResist = "readycheck" }
function ns:Migrate(db)
	local v = db.schema or 1
	if v < 2 then
		if db.heldPlateAlpha == 0 then db.heldPlateAlpha = 0.35 end
		if db.chatChannel == "GROUP" then db.chatChannel = "TANKS" end
		for k, old in pairs(OLD_SOUNDS) do
			if db[k] == old then db[k] = self.defaults[k] end
		end
	end
	if v < 3 then
		-- alte Standardplätze (mitten im Bild) auf die neuen umstellen, selbst verschobene bleiben
		local function was(p, x, y)
			return type(p) == "table" and p[1] == "CENTER" and p[3] == "CENTER" and p[4] == x and p[5] == y
		end
		if was(db.hudPoint, 320, -120) then db.hudPoint = CopyTable(self.defaults.hudPoint) end
		if was(db.meterPoint, 320, 60) then db.meterPoint = CopyTable(self.defaults.meterPoint) end
	end
	if v < 4 then
		-- Aggrometer und DD-Ansicht haben eine eigene Grösse (bisher die des HUD)
		if type(db.hudScale) == "number" then
			db.meterScale = db.hudScale
			db.ddScale = db.hudScale
		end
		-- Verschieben geht jetzt über den Knopf "Anzeigen verschieben"; die alte Entsperr-Option entfällt
		db.hudLocked = true
		-- die Warnung der DD-Ansicht hat einen eigenen Ton: selbst gewählten DD-Ton übernehmen
		if db.soundDD and db.soundDD ~= self.defaults.soundDD then db.soundDDWarn = db.soundDD end
	end
	if v < 5 then
		-- 1.7.2: Töne standardmässig nur bei Aggroverlust; Vorwarnung orange.
		-- Nur ändern, was noch auf dem alten Standard steht.
		if db.soundResist == "ts_resist" then db.soundResist = "none" end
		if db.soundEmergency == "ts_emergency" then db.soundEmergency = "none" end
		if db.soundDDWarn == "ts_warn" then db.soundDDWarn = "none" end
		if db.regainSound == true then db.regainSound = false end
		local w = db.colorWarn
		if type(w) == "table" and w[1] == 1 and w[2] == 0.9 and w[3] == 0 then
			db.colorWarn = { 1, 0.5, 0, 1 }
		end
	end
	if v < 6 then
		-- 1.7.3: Aggroverlust an einen Spieler hupt (nur, wenn noch der alte Standardton eingestellt ist)
		if db.soundHealer == "ts_healer" then db.soundHealer = "fx_hupe" end
		if db.soundDD == "ts_dd" then db.soundDD = "fx_hupe" end
	end
	if v < 7 then
		-- 1.7.4: Aggro bei einem DD rot statt orange (orange = bald Aggro)
		local c = db.colorDD
		if type(c) == "table" and c[1] == 1 and c[2] == 0.55 and c[3] == 0 then db.colorDD = { 1, 0.1, 0.1, 1 } end
	end
	db.schema = 7
end

-- Voreinstellungen: Dezent / Standard / Laut
ns.PRESETS = {
	quiet = {
		heldPlateAlpha = 0.5, heldScale = 0.9, looseScale = 1.1, loosePulse = false, borderSize = 2,
		regainSound = false, centerSize = 16, aoeHint = false, healerRange = false,
	},
	standard = {
		heldPlateAlpha = 0.35, heldScale = 0.8, looseScale = 1.25, loosePulse = true, borderSize = 3,
		regainSound = false, centerSize = 20, aoeHint = true, healerRange = true,
	},
	loud = {
		heldPlateAlpha = 0.2, heldScale = 0.75, looseScale = 1.4, loosePulse = true, borderSize = 4,
		regainSound = true, centerSize = 26, aoeHint = true, healerRange = true,
	},
}

function ns:ApplyPreset(name)
	local p = self.PRESETS[name]
	if not p then return end
	for k, v in pairs(p) do self.db[k] = v end
	self:ApplySettings()
end

-- Bosskampf? (für "Meldungen nur bei Bossen")
function ns:IsBossFight()
	if UnitExists("boss1") then return true end
	for _, u in ipairs({ "target", "focus", "targettarget" }) do
		if UnitExists(u) and ns.Safe(UnitCanAttack("player", u), false) and ns.Safe(UnitAffectingCombat(u), false) then
			local lvl = ns.Safe(UnitLevel(u), 0)
			local cls = ns.Safe(UnitClassification(u), "")
			if lvl == -1 or cls == "worldboss" then return true end
		end
	end
	return false
end

function ns:IsSharedProfile()
	return ThreatSentinelDB and ThreatSentinelDB.chars[self.charKey] == "Global"
end

function ns:UseSharedProfile(shared)
	local DB = ThreatSentinelDB
	if shared then
		if not DB.profiles.Global then DB.profiles.Global = CopyTable(self.db) end
		DB.chars[self.charKey] = "Global"
	else
		DB.profiles[self.charKey] = DB.profiles[self.charKey] or CopyTable(self.db)
		DB.chars[self.charKey] = self.charKey
	end
	ReloadUI()
end

function ns:ResetPositions()
	self.db.hudPoint = CopyTable(self.defaults.hudPoint)
	self.db.ddPoint = CopyTable(self.defaults.ddPoint)
	self.db.meterPoint = CopyTable(self.defaults.meterPoint)
	self:ApplySettings()
end

function ns:ApplySettings()
	if self.HUD and self.HUD.f then self.HUD:ApplySettings() end
	if self.DD and self.DD.f then self.DD:ApplySettings() end
	if self.Alerts and self.Alerts.center then self.Alerts:ApplySettings() end
	if self.Meter and self.Meter.f then self.Meter:ApplySettings() end
	if self.Options and self.Options.UpdateMinimap then self.Options:UpdateMinimap() end
end

------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
local handlers = {}

-- Unbekannte Events (gibt es nicht in jedem Client, z. B. LEARNED_SPELL_IN_TAB in 2.5.6)
-- werden übersprungen, statt das Laden abzubrechen.
-- Rückgabe: true, wenn das Ereignis angemeldet werden konnte
function ns:On(event, fn)
	if not handlers[event] then
		if not pcall(eventFrame.RegisterEvent, eventFrame, event) then return false end
		handlers[event] = {}
	end
	table.insert(handlers[event], fn)
	return true
end

-- Fehler eines Teils melden, ohne das Addon anzuhalten (Diagnose zeigt den letzten Fehler)
ns.errorCount = 0
local lastErrorPrint = 0
function ns:ReportError(err)
	self.errorCount = self.errorCount + 1
	self.lastError = tostring(err)
	if self.Test and self.Test.IsTesting and self.Test:IsTesting() and GetTime() - lastErrorPrint > 10 then
		lastErrorPrint = GetTime()
		self:Print("|cffff5050" .. self.lastError .. "|r")
	end
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
	local list = handlers[event]
	if not list then return end
	for i = 1, #list do
		local ok, err = pcall(list[i], event, ...)
		if not ok then ns:ReportError(err) end
	end
end)

ns:On("ADDON_LOADED", function(_, name)
	if name ~= ADDON then return end
	ns.class = select(2, UnitClass("player"))
	ns.playerName = UnitName("player")
	ns:InitDB()
	for _, m in ipairs(ns.modules) do
		if m.Init then m:Init() end
	end
end)

ns:On("PLAYER_LOGIN", function()
	ns.playerGUID = UnitGUID("player")
	ns:BuildCCNames()
	ns:UpdateGroup()
	ns:UpdateSpells()
	if ns.db.autoEnableNameplates and not InCombatLockdown() then
		SetCVar("nameplateShowEnemies", "1")
	end
	for _, m in ipairs(ns.modules) do
		if m.Login then m:Login() end
	end
	ns:Print(L.LOADED)
end)

local spellsPending = false
local function QueueSpellUpdate()
	if spellsPending then return end
	spellsPending = true
	C_Timer.After(0.5, function()
		spellsPending = false
		ns:UpdateSpells()
	end)
end
ns:On("SPELLS_CHANGED", QueueSpellUpdate)
ns:On("LEARNED_SPELL_IN_TAB", QueueSpellUpdate)

local function GroupChanged()
	ns:UpdateGroup()
	ns:ClearRoleCache()
end
ns:On("GROUP_ROSTER_UPDATE", GroupChanged)
ns:On("UNIT_PET", GroupChanged)
ns:On("PLAYER_ENTERING_WORLD", GroupChanged)

-- Haltung / Gestalt geändert: Sync informieren
local lastTank
local function StanceChanged()
	stanceCacheTime = 0
	local now = ns:IsTankStance()
	if now ~= lastTank then
		lastTank = now
		ns:ClearRoleCache()
		if ns.Sync then ns.Sync:Hello(true) end
	end
end
ns:On("UPDATE_SHAPESHIFT_FORM", StanceChanged)
ns:On("UNIT_AURA", function(_, unit) if unit == "player" then StanceChanged() end end)

-- Test- und Entwicklerfunktionen (Testzentrale, Testassistent, Testprotokoll, Ini-Prüfung)
-- sind nur für den Entwickler sichtbar (GoldSentinelDev.lua, gemeinsam für alle GoldSentinel-Addons)
function ns:IsDev()
	local d = GoldSentinelDev
	return type(d) == "table" and d.IsDev and d:IsDev() or false
end

-- prüfen und sonst einen Hinweis im Chat zeigen
function ns:RequireDev()
	local d = GoldSentinelDev
	if type(d) == "table" and d.Require then return d:Require("ThreatSentinel") end
	return false
end

-- Befehle als Ersatz zum Minimap-Knopf
SLASH_THREATSENTINEL1 = "/ts"
SLASH_THREATSENTINEL2 = "/threatsentinel"
SlashCmdList.THREATSENTINEL = function(msg)
	msg = (msg or ""):lower()
	local cmd, arg = msg:match("^(%S+)%s*(.*)$")
	if cmd == "log" then
		ns.Log:Command(arg)
	elseif msg == "test" then
		ns.Test:ToggleWindow()
	elseif msg == "guide" or msg == "assistent" then
		ns.Guide:Start()
	elseif msg == "spenden" or msg == "donate" or msg == "support" then
		ns.Donate.Show()
	elseif msg == "verschieben" or msg == "move" then
		ns.Mover:Toggle()
	else
		ns.Options:Toggle()
	end
end
