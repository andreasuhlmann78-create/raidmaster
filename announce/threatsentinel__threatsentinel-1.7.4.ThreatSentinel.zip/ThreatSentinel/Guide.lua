-- ThreatSentinel - Guide.lua
-- Testassistent: führt dich im Spiel Schritt für Schritt durch alle Funktionen.
-- Gedacht für Jäger (oder Hexer mit Leerwandler) in Classic Era: Das Pet ist der Tank,
-- du bist der DD, der ihm die Aggro wegnimmt.
--
-- Schritt-Arten:
--   auto     erkennt selbst, wann der Schritt geschafft ist (Signal oder Prüfung)
--   confirm  fragt dich: "Stimmt das?" - Ja / Nein
--   info     zeigt ein Ergebnis an, weiter mit "Weiter"
-- Fortschritt und Ergebnisse werden gespeichert (auch über /reload hinweg) und
-- erscheinen im Bericht der Testzentrale.

local ADDON, ns = ...
local L = ns.L

local G = {}
ns.Guide = G
table.insert(ns.modules, G)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil
local ACCENT = { 0.25, 0.65, 1 }

G.signals = {}

function G:Signal(name)
	self.signals[name] = GetTime()
end

local function Got(name)
	return (G.signals[name] or 0) >= (G.stepStart or math.huge)
end

local function AnyMob(state)
	for _, m in pairs(ns.mobs) do
		if m.state == state then return true end
	end
	return false
end

-- "Aggro zurück" nach dem letzten Aggroverlust (auch wenn es schon vor dem Schritt passiert ist)
local function RegainAfterLoose(since)
	local lo, re = G.signals.loose or 0, G.signals.regain or 0
	return lo >= (since or 0) and re > lo
end

local function PetName()
	return ns.Safe(UnitName("pet"), "?") or "?"
end

local function HasPet()
	return UnitExists("pet") and not ns.Safe(UnitIsDeadOrGhost("pet"), false)
end

------------------------------------------------------------
-- Die Schritte
------------------------------------------------------------
local STEPS = {
	{ id = "pet", kind = "auto",
		setup = function()
			ns.db.testPetTank = true
			if not ns.Log.on then ns.Log:SetOn(true) end
			if not ns.liveTest then ns.Test:SetLive(true) end
			if ns.testMode then ns.Test:SetDemo(false) end
			if ns.simSecret then ns.Test:SetSimulation(false) end
		end,
		check = function() return HasPet() end },
	{ id = "held", kind = "auto",
		setup = function() G.looseFrom = GetTime() end,
		check = function() return AnyMob("HELD") or AnyMob("WARN") end },
	{ id = "heldlook", kind = "confirm" },
	{ id = "warn", kind = "auto", skippable = true,
		check = function() return AnyMob("WARN") end },
	{ id = "loose", kind = "auto",
		check = function() return Got("loose") or AnyMob("LOOSE") end },
	{ id = "looselook", kind = "confirm" },
	-- automatisch: Mobs leben im Test oft nur ~10 s, nachträglich ist das HUD meist schon leer
	{ id = "hud", kind = "auto",
		check = function() return (G.signals.hud or 0) >= (G.looseFrom or 0) and G.signals.hud ~= nil end },
	{ id = "regain", kind = "auto",
		check = function() return RegainAfterLoose(G.looseFrom) end },
	{ id = "regainlook", kind = "confirm" },
	{ id = "meter", kind = "confirm" },
	{ id = "ddview", kind = "confirm" },
	{ id = "bind", kind = "auto",
		skipIf = function() return not ns.tauntSpell end,
		action = { label = "GUIDE_ACT_KEYS", fn = function() ns.Options:OpenPage(5) end },
		check = function() return ns.Taunt:GetKey("taunt") ~= nil end },
	{ id = "tauntkey", kind = "auto", signal = "taunt",
		skipIf = function() return not ns.tauntSpell or not ns.Taunt:GetKey("taunt") end },
	{ id = "cdhint", kind = "confirm", skippable = true,
		-- beim Pet-Knurren (nur 5 s, Hinweis zeigt meist "Bedrohung reicht") nicht sinnvoll prüfbar
		skipIf = function() return not ns.tauntSpell or ns.tauntMode == "pet" end },
	{ id = "resist", kind = "auto", signal = "resist", skippable = true,
		skipIf = function() return not ns.tauntSpell end },
	{ id = "cc", kind = "auto", skippable = true,
		skipIf = function() return ns.class ~= "HUNTER" or not ns:KnowsSpell(1513) end,
		check = function() return AnyMob("CC") end },
	{ id = "alerts", kind = "auto", signal = "allalerts",
		setup = function() if not (ns.Test.frame and ns.Test.frame:IsShown()) then ns.Test:ToggleWindow() end end },
	{ id = "simloose", kind = "auto",
		setup = function()
			if ns.Test.frame and ns.Test.frame:IsShown() then ns.Test.frame:Hide() end
			if not ns.simSecret then ns.Test:SetSimulation(true) end
			G.simFrom = GetTime()
		end,
		check = function() return Got("loose") or AnyMob("LOOSE") end },
	{ id = "simregain", kind = "auto",
		check = function() return RegainAfterLoose(G.simFrom) end },
	{ id = "simcompat", kind = "confirm",
		setup = function() if not (ns.Test.frame and ns.Test.frame:IsShown()) then ns.Test:ToggleWindow() end end },
	{ id = "errors", kind = "info",
		setup = function(step)
			local blocked = ns.blocked and #ns.blocked or 0
			step.autoResult = (ns.errorCount == 0 and blocked == 0) and "ok" or "fail"
			step.extra = string.format(L.GUIDE_ERRORS_RESULT, ns.errorCount, blocked)
		end },
	{ id = "done", kind = "info",
		setup = function()
			if ns.simSecret then ns.Test:SetSimulation(false) end
			if ns.liveTest then ns.Test:SetLive(false) end
			ns.db.testPetTank = false
			-- Protokoll beenden: das Addon zeigt dann im Spiel den Rapport
			if ns.Log.on then ns.Log:SetOn(false) else ns.Log:ShowSummary() end
		end,
		action = { label = "GUIDE_ACT_REPORT", fn = function() ns.Test:ShowReport() end } },
}
G.STEPS = STEPS

------------------------------------------------------------
-- Fenster (oben am Bildschirmrand, verschiebbar)
------------------------------------------------------------
local function Btn(parent, w, onClick)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(w, 22)
	b:SetScript("OnClick", onClick)
	return b
end

function G:Build()
	local f = CreateFrame("Frame", "ThreatSentinelGuide", UIParent, BACKDROP)
	f:SetSize(470, 150)
	f:SetPoint("TOP", UIParent, "TOP", 0, -40)
	f:SetFrameStrata("FULLSCREEN")   -- über der Testzentrale, unter den Testmeldungen
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		f:SetBackdropColor(0.05, 0.06, 0.08, 0.92)
		f:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.8)
	end

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.title:SetPoint("TOPLEFT", 10, -8)
	f.title:SetTextColor(ACCENT[1] + 0.15, ACCENT[2] + 0.1, 1)
	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() G:Pause() end)

	f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.text:SetPoint("TOPLEFT", 10, -28)
	f.text:SetWidth(450)
	f.text:SetJustifyH("LEFT")
	if f.text.SetWordWrap then f.text:SetWordWrap(true) end

	f.status = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.status:SetPoint("BOTTOMLEFT", 10, 36)

	f.b1 = Btn(f, 110, function() G:Button(1) end)
	f.b1:SetPoint("BOTTOMLEFT", 10, 8)
	f.b2 = Btn(f, 110, function() G:Button(2) end)
	f.b2:SetPoint("LEFT", f.b1, "RIGHT", 6, 0)
	f.b3 = Btn(f, 110, function() G:Button(3) end)
	f.b3:SetPoint("LEFT", f.b2, "RIGHT", 6, 0)
	f.b4 = Btn(f, 110, function() G:Button(4) end)
	f.b4:SetPoint("LEFT", f.b3, "RIGHT", 6, 0)

	f:Hide()
	self.f = f

	-- Prüfung der automatischen Schritte alle 0.25 s
	local acc = 0
	f:SetScript("OnUpdate", function(_, e)
		acc = acc + e
		if acc < 0.25 then return end
		acc = 0
		G:Poll()
	end)
end

------------------------------------------------------------
-- Ablauf
------------------------------------------------------------
local function State()
	ns.db.guide = ns.db.guide or {}
	local g = ns.db.guide
	g.results = g.results or {}
	return g
end

function G:Start()
	if not ns:RequireDev() then return end
	if not self.f then self:Build() end
	local g = State()
	if not g.step or g.step > #STEPS then
		g.step = 1
		wipe(g.results)
	end
	self.f:Show()
	-- nach /reload oder Pause: Testumgebung für den aktuellen Schritt wiederherstellen
	local step = STEPS[g.step]
	if g.step > 1 and step and step.id ~= "done" then
		ns.db.testPetTank = true
		if ns.testMode then ns.Test:SetDemo(false) end
		if not ns.liveTest then ns.Test:SetLive(true) end
		G.looseFrom = G.looseFrom or 0
		local simStep = step.id == "simloose" or step.id == "simregain" or step.id == "simcompat"
		if simStep and not ns.simSecret then ns.Test:SetSimulation(true) end
		if step.id == "simregain" then G.simFrom = 0 end
	end
	self:Enter(g.step)
end

function G:Pause()
	if self.f then self.f:Hide() end
	if ns.simSecret then ns.Test:SetSimulation(false) end
	ns:Print(L.GUIDE_PAUSED)
end

function G:Restart()
	local g = State()
	g.step = 1
	wipe(g.results)
	self:Enter(1)
end

function G:Enter(i)
	local g = State()
	g.step = i
	local step = STEPS[i]
	if not step then
		g.step = #STEPS + 1
		return self:Render()
	end
	self.stepStart = GetTime()
	self.doneAt = nil
	step.autoResult, step.extra = nil, nil

	if step.skipIf and step.skipIf() then
		g.results[step.id] = "n/a"
		return self:Enter(i + 1)
	end
	if step.setup then step.setup(step) end
	self:Render()
end

function G:Finish(result)
	local g = State()
	local step = STEPS[g.step]
	if not step then return end
	g.results[step.id] = result
	if result == "ok" then ns.Alerts:Play("ts_regain", "guide" .. GetTime()) end
	if g.step < #STEPS then
		self:Enter(g.step + 1)
	else
		g.step = #STEPS + 1
		self:Render()
	end
end

function G:Poll()
	local g = State()
	local step = STEPS[g.step]
	if not step or step.kind ~= "auto" or self.doneAt then return end
	local done = false
	if step.signal then done = Got(step.signal)
	elseif step.check then
		local ok, r = pcall(step.check)
		done = ok and r
	end
	if done then
		self.doneAt = GetTime()
		self.f.status:SetText("|cff40ff40" .. L.GUIDE_DETECTED .. "|r")
		C_Timer.After(1.5, function()
			if G.doneAt and STEPS[State().step] == step then G:Finish("ok") end
		end)
	end
end

-- Knöpfe je nach Schritt-Art
function G:Button(n)
	local fn = self.buttons and self.buttons[n]
	if fn then fn() end
end

function G:Render()
	local f, g = self.f, State()
	local step = STEPS[g.step]
	local buttons = {}
	local function set(n, label, fn)
		local b = f["b" .. n]
		if label then
			b:SetText(label)
			b:Show()
			buttons[n] = fn
		else
			b:Hide()
		end
	end

	if not step then
		f.title:SetText(L.GUIDE_TITLE .. " - " .. L.GUIDE_FINISHED)
		f.text:SetText(L.GUIDE_FINISHED_TEXT)
		f.status:SetText(self:Summary())
		set(1, L.GUIDE_ACT_REPORT, function() ns.Test:ShowReport() end)
		set(2, L.GUIDE_RESTART, function() G:Restart() end)
		set(3, nil); set(4, nil)
		self.buttons = buttons
		return
	end

	f.title:SetText(string.format("%s - %s %d/%d: %s", L.GUIDE_TITLE, L.GUIDE_STEP, g.step, #STEPS, L["GT_" .. step.id]))
	local me = ns.Safe(UnitName("player"), "?") or "?"
	local text = L["GD_" .. step.id]
	text = text:gsub("{pet}", PetName()):gsub("{taunt}", ns.tauntSpell or "-"):gsub("{me}", me)
	if step.extra then text = text .. "\n\n" .. step.extra end
	f.text:SetText(text)

	if step.kind == "auto" then
		f.status:SetText("|cffffd100" .. L.GUIDE_WAITING .. "|r")
		set(1, L.GUIDE_SKIP, function() G:Finish("skip") end)
		set(2, L.GUIDE_FAIL, function() G:Finish("fail") end)
		if step.action then set(3, L[step.action.label], step.action.fn) else set(3, nil) end
		set(4, nil)
	elseif step.kind == "confirm" then
		f.status:SetText("|cffffd100" .. L.GUIDE_QUESTION .. "|r")
		set(1, L.GUIDE_YES, function() G:Finish("ok") end)
		set(2, L.GUIDE_NO, function() G:Finish("fail") end)
		set(3, L.GUIDE_SKIP, function() G:Finish("skip") end)
		set(4, nil)
	else
		local r = step.autoResult
		if r == "ok" then f.status:SetText("|cff40ff40" .. L.GUIDE_RESULT_OK .. "|r")
		elseif r == "fail" then f.status:SetText("|cffff5050" .. L.GUIDE_RESULT_FAIL .. "|r")
		else f.status:SetText("") end
		set(1, L.GUIDE_NEXT, function() G:Finish(step.autoResult or "ok") end)
		if step.action then set(2, L[step.action.label], step.action.fn) else set(2, nil) end
		set(3, nil); set(4, nil)
	end
	self.buttons = buttons

	-- Höhe an den Text anpassen
	local h = 28 + (f.text:GetStringHeight() or 40) + 60
	f:SetHeight(math.max(130, h))
end

function G:Summary()
	local g = State()
	local ok, fail, skip, na = 0, 0, 0, 0
	for _, step in ipairs(STEPS) do
		local r = g.results[step.id]
		if step.kind ~= "info" or step.id == "errors" then
			if r == "ok" then ok = ok + 1
			elseif r == "fail" then fail = fail + 1
			elseif r == "skip" then skip = skip + 1
			elseif r == "n/a" then na = na + 1 end
		end
	end
	return string.format(L.GUIDE_SUMMARY, ok, fail, skip, na)
end

-- Zeilen für den Bericht der Testzentrale
function G:ReportLines()
	local g = ns.db and ns.db.guide
	if not g or not g.results or not next(g.results) then return {} end
	local parts = {}
	for i, step in ipairs(STEPS) do
		local r = g.results[step.id]
		if r then parts[#parts + 1] = i .. " " .. step.id .. "=" .. r end
	end
	local lines = { "Guide: " .. table.concat(parts, ", ") }
	local failed = {}
	for _, step in ipairs(STEPS) do
		if g.results[step.id] == "fail" then failed[#failed + 1] = step.id end
	end
	if #failed > 0 then lines[2] = "Guide failed: " .. table.concat(failed, ", ") end
	return lines
end
