-- ThreatSentinel - Meter.lua
-- Aggrometer: Bedrohungsliste deines Ziels.
-- Jeder Wert zeigt, wie nah ein Spieler am Ziehen der Aggro ist: 100 % = er zieht jetzt.
-- Die Classic-Regel ist eingerechnet (Nahkampf zieht bei 110 %, Fernkampf bei 130 % der Tank-Bedrohung).
-- Als Tank siehst du deinen Vorsprung auf den Spieler, der am nächsten dran ist.

local ADDON, ns = ...
local L = ns.L

local M = {}
ns.Meter = M
table.insert(ns.modules, M)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BAR_TEX = "Interface\\TargetingFrame\\UI-StatusBar"
local ROW_H = 16
local SCALE_MAX = 110   -- 100 % (= zieht) sitzt kurz vor dem Balkenende

-- Klassen, die meist im Nahkampf stehen (nur für den Ersatz, falls das Spiel keinen Anteil liefert)
local MELEE = { WARRIOR = true, ROGUE = true, PALADIN = true, DRUID = true, SHAMAN = false }

function M:Init()
	local f = CreateFrame("Frame", "ThreatSentinelMeter", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(ns.db.meterWidth or 230, 26)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.03, 0.04, 0.06, 0.6)
	f:SetBackdropBorderColor(0.25, 0.65, 1, 0.5)
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		ns.Mover:SavePoint(self, "meterPoint")
	end)

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.title:SetPoint("TOPLEFT", 6, -5)
	f.title:SetPoint("TOPRIGHT", -96, -5)
	f.title:SetJustifyH("LEFT")
	if f.title.SetWordWrap then f.title:SetWordWrap(false) end
	f.lead = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.lead:SetPoint("TOPRIGHT", -6, -5)
	f.lead:SetWidth(88)
	f.lead:SetJustifyH("RIGHT")
	if f.lead.SetWordWrap then f.lead:SetWordWrap(false) end

	f.rows = {}
	f:Hide()
	self.f = f
	ns.Mover:Attach(f, "meter")
	self:ApplySettings()
end

function M:ApplySettings()
	local f, db = self.f, ns.db
	if not f then return end
	local p = db.meterPoint
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[3], p[4], p[5])
	f:SetWidth(self:Width())
	for _, r in ipairs(f.rows) do self:LayoutRow(r) end
	f:SetScale(db.meterScale or 1)
	f:EnableMouse(ns:Unlocked())
end

function M:Width()
	return math.max(160, math.min(400, ns.db.meterWidth or 230))
end

-- Breite einer Zeile und Lage der 100-%-Markierung (die Breite ist einstellbar)
function M:LayoutRow(r)
	local w = self:Width() - 8
	r:SetSize(w, ROW_H - 2)
	r.mark:ClearAllPoints()
	r.mark:SetPoint("TOP", r, "TOPLEFT", w * 100 / SCALE_MAX, 0)
	r.mark:SetPoint("BOTTOM", r, "BOTTOMLEFT", w * 100 / SCALE_MAX, 0)
end

function M:Row(i)
	local f = self.f
	local r = f.rows[i]
	if r then return r end
	r = CreateFrame("StatusBar", nil, f)
	r:SetPoint("TOPLEFT", 4, -20 - (i - 1) * ROW_H)
	r:SetStatusBarTexture(BAR_TEX)
	r:SetMinMaxValues(0, SCALE_MAX)
	r.bg = r:CreateTexture(nil, "BACKGROUND")
	r.bg:SetAllPoints()
	r.bg:SetTexture(WHITE)
	r.bg:SetVertexColor(1, 1, 1, 0.06)
	-- Markierung bei 100 %: hier zieht der Spieler die Aggro
	r.mark = r:CreateTexture(nil, "OVERLAY")
	r.mark:SetTexture(WHITE)
	r.mark:SetVertexColor(1, 0.3, 0.3, 0.6)
	r.mark:SetWidth(1)
	r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.name:SetPoint("LEFT", 4, 0)
	r.name:SetPoint("RIGHT", -44, 0)
	r.name:SetJustifyH("LEFT")
	if r.name.SetWordWrap then r.name:SetWordWrap(false) end
	r.value = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.value:SetPoint("RIGHT", -4, 0)
	self:LayoutRow(r)
	f.rows[i] = r
	return r
end

local function ClassColor(class)
	local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
	if c then return c.r, c.g, c.b end
	return 0.6, 0.6, 0.6
end

-- Anteil bis zum Ziehen (100 = zieht). Das Spiel liefert ihn direkt (scaled);
-- sonst Ersatz aus dem Rohwert mit der 110/130-%-Regel.
local function PullPercent(u, scaled, raw, class)
	if scaled then return scaled end
	if not raw then return 0 end
	local melee = (not UnitIsPlayer(u)) or MELEE[class or ""]
	return raw / (melee and 110 or 130) * 100
end

-- Liefert die Liste und ob die Werte geschützt sind.
-- Geschützt (Forever, z. B. bei Bossen): keine Sortierung nach Wert möglich -
-- der Tank steht oben, die Zahlen zeigt das Spiel selbst an, die Farbe kommt aus dem Status.
function M:Collect()
	local list, secret = {}, false
	for _, u in ipairs(ns.groupUnits) do
		local ok, isTanking, status, scaled, raw = pcall(UnitDetailedThreatSituation, u, "target")
		if ok and (ns.IsSecret(scaled, "threatValues") or ns.IsSecret(raw, "threatValues") or ns.IsSecret(isTanking)) then
			secret = true
			if ns.IsSecret(scaled, "threatValues") or scaled ~= nil then
				local name = UnitName(u) or "?"
				local class = UnitIsPlayer(u) and select(2, UnitClass(u)) or nil
				list[#list + 1] = {
					name = name, class = ns.Safe(class, nil), pull = scaled, secret = true,
					tanking = ns.Safe(isTanking, false), status = ns.Safe(status, 0) or 0,
					me = UnitIsUnit(u, "player"), isTank = UnitIsUnit(u, ns:TankUnit()),
				}
			end
		elseif ok and status and (scaled or raw) then
			local name = UnitName(u) or "?"
			local class
			if UnitIsPlayer(u) then
				class = select(2, UnitClass(u))
			else
				name = name .. " (" .. L.PET .. ")"
			end
			list[#list + 1] = {
				name = name, class = class, pull = PullPercent(u, scaled, raw, class),
				tanking = isTanking, me = UnitIsUnit(u, "player"), isTank = UnitIsUnit(u, ns:TankUnit()),
			}
		end
	end
	if secret then
		ns:Compat("threatValues", "fallback")
		for _, e in ipairs(list) do e.secret = true end
		table.sort(list, function(a, b)
			if a.tanking ~= b.tanking then return a.tanking end
			return (a.status or 0) > (b.status or 0)
		end)
		return list, true
	end
	table.sort(list, function(a, b)
		if a.tanking ~= b.tanking then return a.tanking end
		return a.pull > b.pull
	end)
	return list, false
end

local TEST_LIST
local function TestList()
	if not TEST_LIST then
		TEST_LIST = {
			{ name = ns.playerName or "Du", class = ns.class, pull = 100, tanking = true, me = true },
			{ name = "Torben", class = "ROGUE", pull = 80 },
			{ name = "Mira", class = "MAGE", pull = 62 },
			{ name = "Anna", class = "PRIEST", pull = 41 },
			{ name = "Grimbar", class = "WARRIOR", pull = 30 },
			{ name = "Wolf (" .. L.PET .. ")", pull = 12 },
		}
	end
	-- leichte Bewegung, damit man die Balken arbeiten sieht
	local t = GetTime()
	TEST_LIST[2].pull = 80 + math.sin(t * 0.9) * 18
	TEST_LIST[3].pull = 62 + math.sin(t * 0.6 + 1) * 14
	return TEST_LIST
end

function M:Render(list, targetName, secret)
	local f, db = self.f, ns.db
	f.title:SetText(string.format(L.METER_TITLE, targetName or "?"))

	-- Vorsprung des Tanks: wie weit der nächste Spieler noch vom Ziehen entfernt ist
	local tank, best = nil, 0
	for _, e in ipairs(list) do
		if e.tanking then tank = e elseif not secret and e.pull > best then best = e.pull end
	end
	if secret then
		-- Werte geschützt: kein Vorsprung berechenbar, nur Warnung aus dem Status
		local danger = tank and tank.isTank and (tank.status or 0) == 2
		f.lead:SetText(danger and L.METER_LEAD_NONE or "")
		f.lead:SetTextColor(1, 0.3, 0.3)
	elseif tank and tank.isTank then
		local lead = 100 - best
		if lead <= 5 then
			f.lead:SetText(L.METER_LEAD_NONE)
			f.lead:SetTextColor(1, 0.3, 0.3)
		else
			f.lead:SetText(string.format(L.METER_LEAD, math.floor(lead + 0.5)))
			if lead < 20 then f.lead:SetTextColor(1, 0.85, 0.2)
			else f.lead:SetTextColor(0.3, 1, 0.4) end
		end
	else
		f.lead:SetText("")
	end

	-- Anzeigen: die obersten Zeilen, du selbst immer dabei
	local maxRows = db.meterRows
	local shown = {}
	for i = 1, math.min(#list, maxRows) do shown[i] = list[i] end
	local meShown = false
	for _, e in ipairs(shown) do if e.me then meShown = true end end
	if not meShown then
		for _, e in ipairs(list) do
			if e.me then shown[math.min(#shown + 1, maxRows)] = e break end
		end
	end

	for i, e in ipairs(shown) do
		local r = self:Row(i)
		local cr, cg, cb = ClassColor(e.class)
		r:SetStatusBarColor(cr, cg, cb, 0.85)
		r.name:SetText((e.me and "> " or "") .. e.name)
		if e.tanking then
			r:SetValue(100)
			r.value:SetText(L.METER_AGGRO)
			r.value:SetTextColor(1, 0.35, 0.35)
		elseif e.secret then
			-- geschützter Wert: Balken und Zahl setzt das Spiel, Farbe aus dem Status
			r:SetValue(e.pull)
			r.value:SetText(string.format("%.0f%%", e.pull))
			if (e.status or 0) >= 1 then r.value:SetTextColor(1, 0.35, 0.35) else r.value:SetTextColor(1, 1, 1) end
		else
			r:SetValue(math.min(e.pull, SCALE_MAX))
			r.value:SetText(string.format("%d%%", math.floor(e.pull + 0.5)))
			if e.pull >= ns.db.warnThreshold then r.value:SetTextColor(1, 0.35, 0.35)
			else r.value:SetTextColor(1, 1, 1) end
		end
		r:Show()
	end
	for i = #shown + 1, #f.rows do f.rows[i]:Hide() end
	f:SetHeight(24 + #shown * ROW_H)
	f:Show()
end

function M:Tick()
	local f, db = self.f, ns.db
	if not f then return end
	-- Testmodus und Verschieben: Beispielliste (auch als Tank / wenn ausgeschaltet beim Verschieben)
	if ns.moveMode or (ns.testMode and db.enabled and db.meter) then
		self:Render(TestList(), L.TEST_TARGET)
		return
	end

	if db.meterOnlyTank and not ns:IsTankStance() then f:Hide() return end

	if not db.enabled or not db.meter then f:Hide() return end

	if ns:Unlocked() and not UnitAffectingCombat("player") then
		f.title:SetText(L.METER_DRAG)
		f.lead:SetText("")
		for i = 1, #f.rows do f.rows[i]:Hide() end
		f:SetHeight(24)
		f:Show()
		return
	end

	if not UnitExists("target") or not ns.Safe(UnitCanAttack("player", "target"), false) or ns.Safe(UnitIsDeadOrGhost("target"), true) then
		f:Hide()
		return
	end
	local list, secret = self:Collect()
	if #list == 0 then f:Hide() return end
	self:Render(list, UnitName("target"), secret)
end
