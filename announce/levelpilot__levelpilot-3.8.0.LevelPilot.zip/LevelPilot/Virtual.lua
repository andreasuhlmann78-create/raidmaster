-- LevelPilot - Virtuelle Reise: LevelPilot laesst einen gedachten Charakter seine eigene Route laufen
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Zum Testen im Spiel, ohne zu spielen: Der echte Charakter bewegt sich nicht, es wird nichts
-- angeklickt, angenommen oder gekauft. LevelPilot plant mit dem gedachten Charakter (Level, Position,
-- Questlog nur im Speicher), "geht" jeden Weg ueber sein Wegenetz, nimmt Quests an, erledigt und gibt sie
-- ab und sammelt EP nach den Classic-Regeln – bis Level 60.
-- Geprueft wird dabei mit den echten Karten- und Wegedaten des Spiels: Gibt es einen Weg? Ist er
-- plausibel (keine riesigen Luftlinien, keine Spruenge)? Bleibt der Plan haengen? Stimmen Zonen und Namen?
-- Waehrend der Reise wird nichts aufgezeichnet und nichts geteilt; die echten Daten bleiben unberuehrt.
-- Ansicht: "Zuschauen" zeigt jeden Weg auf der Weltkarte, "Schnell" rechnet ohne Pause durch.

local _, LP = ...
local L = LP.L
local V = {}
LP:RegisterModule("Virtual", V)

V.active = false
V.s = nil

-- EP je Level (Classic)
local XPNEED = { 400, 900, 1400, 2100, 2800, 3600, 4500, 5400, 6500, 7600, 8800, 10100, 11400, 12900, 14400,
    16000, 17700, 19400, 21300, 23200, 25200, 27300, 29400, 31700, 34000, 36400, 38900, 41400, 44300, 47400,
    50800, 54500, 58600, 62800, 67100, 71600, 76100, 80800, 85700, 90700, 95800, 101000, 106300, 111800,
    117500, 123200, 129100, 135100, 141200, 147500, 153900, 160400, 167100, 173900, 180800, 187900, 195000,
    202300, 209800 }
-- Startgebiete nach Volk
local START = {
    Human = { 1429, 48.2, 42.9 }, Dwarf = { 1426, 29.9, 71.2 }, Gnome = { 1426, 29.9, 71.2 },
    NightElf = { 1438, 58.6, 44.6 }, Orc = { 1411, 43.3, 68.5 }, Troll = { 1411, 43.3, 68.5 },
    Scourge = { 1420, 30.2, 71.7 }, Tauren = { 1412, 44.2, 76.1 },
}
local KIND_SECS = { kill = 420, item = 540, object = 180, explore = 60 }
local RUN = 7                  -- Yards pro Sekunde zu Fuss
local LONG_DIRECT = 1500       -- Luftlinie (ohne bekannten Weg) laenger als das wird notiert
local MAX_STEPS = 6000

------------------------------------------------------------------------
-- Gedachter Zustand und Umleitungen
------------------------------------------------------------------------
local saved = {}

local function QuestObjs(id)
    local q = LP.QuestDB:Get(id)
    local objs = {}
    for _, o in ipairs(q and q.objectives or {}) do
        if o.kind ~= "rec" then
            local name = o.text
            if LP.Names then
                if o.kind == "item" and o.item then name = LP.Names:Item(o.item) or name
                elseif o.kind == "kill" and o.ids and o.ids[1] then name = LP.Names:Npc(o.ids[1]) or name
                elseif o.kind == "object" and o.objId then name = LP.Names:Object(o.objId) or name end
            end
            if not name and o.kind == "item" and o.item then name = GetItemInfo and GetItemInfo(o.item) end
            objs[#objs + 1] = { text = (name or L["Ziel"]) .. ": 0/1", finished = false, have = 0, need = 1,
                                type = ({ kill = "monster", item = "item", object = "object", explore = "event" })[o.kind],
                                kind = o.kind, elite = o.elite }
        end
    end
    return objs, q
end

local function Install()
    local s = V.s
    local API, Geo = LP.API, LP.Geo
    saved.Quests, saved.Objectives, saved.QuestCount = API.Quests, API.Objectives, API.QuestCount
    saved.IsQuestDone, saved.Player, saved.char = API.IsQuestDone, Geo.Player, LP.char
    saved.HearthReady = API.HearthReady
    -- eigener Ruhestein des gedachten Charakters: 60 min Abklingzeit in Spielzeit der Reise
    API.HearthReady = function() return not s.hearthAt or (s.clock - s.hearthAt) >= 3600 end
    API.Quests = function()
        local out = {}
        for i, q in ipairs(s.log) do
            out[#out + 1] = { index = i, id = q.id, title = q.title, complete = q.complete, failed = false, level = q.level }
        end
        return out
    end
    API.Objectives = function(index)
        local q = s.log[index]
        local out = {}
        for _, o in ipairs(q and q.objs or {}) do
            out[#out + 1] = { text = o.text, finished = o.finished, have = o.have, need = o.need, type = o.type }
        end
        return out
    end
    API.QuestCount = function() return #s.log end
    API.IsQuestDone = function(id)
        if s.done[id] then return true end
        if s.doneFallback then return s.doneFallback(id) end       -- ab hier: echte erledigte Quests zaehlen
        return false
    end
    Geo.Player = function()
        local i, n, w = Geo:ToWorld(s.map, s.x, s.y)
        return i, n, w, s.map, s.x, s.y
    end
    -- eigener Charakter-Speicher: Fortschritt der echten Figur bleibt unberuehrt
    local real = LP.char
    local c = {}
    for k, v in pairs(real) do
        if type(v) == "table" and k ~= "settings" then c[k] = {} else c[k] = v end
    end
    c.bind, c.inDungeon, c.focusZone, c.mode = false, false, false, real.mode
    -- ab hier: Fortschritt der echten Figur uebernehmen (erledigte Quests, Flugpunkte, Bindeort)
    if s.here then
        for k, v in pairs(real) do
            if type(v) == "table" and k ~= "settings" then for kk, vv in pairs(v) do c[k][kk] = vv end end
        end
        c.bind = real.bind
    end
    LP.char = c
    s.char = c
    -- Flugpunkte: eigene Liste, die echte bleibt unveraendert (bekannte Knoten werden mitbenutzt)
    saved.taxi = LevelPilotDB.taxi
    s.taxi = setmetatable({}, { __index = saved.taxi or {} })
    LevelPilotDB.taxi = s.taxi
end

local function Uninstall()
    local API, Geo = LP.API, LP.Geo
    if saved.Quests then
        API.Quests, API.Objectives, API.QuestCount = saved.Quests, saved.Objectives, saved.QuestCount
        API.IsQuestDone, Geo.Player = saved.IsQuestDone, saved.Player
        if saved.HearthReady then API.HearthReady = saved.HearthReady end
        LP.char = saved.char
        LevelPilotDB.taxi = saved.taxi
    end
    wipe(saved)
end

------------------------------------------------------------------------
-- Ereignisse der Reise
------------------------------------------------------------------------
local function Note(kind, text)
    local s = V.s
    local list = s.problems
    local key = kind .. text
    if s.seen[key] then s.seen[key].n = s.seen[key].n + 1 return end
    local e = { kind = kind, text = text, lvl = s.level, map = s.map, x = s.x, y = s.y, n = 1 }
    s.seen[key] = e
    list[#list + 1] = e
end

local function GainXP(xp)
    local s = V.s
    s.xp = s.xp + xp
    while s.level < 60 and s.xp >= s.xpMax do
        s.xp = s.xp - s.xpMax
        s.level = s.level + 1
        s.xpMax = XPNEED[s.level] or 1
        s.levelAt[s.level] = { t = s.clock, q = s.quests, zone = s.map }
        LP.Planner:BuildCandidates()
    end
    if s.level >= 60 then s.xp = 0 end
end

local function QuestXP(id)
    local d = _G.LevelPilotData
    local r = d and d.Q and d.Q[id]
    local base = r and r.x or 0
    local ql = r and r.l or V.s.level
    if base <= 0 then return math.floor(40 + V.s.level * 30) end
    local mult = math.max(1, math.min(10, 2 * (ql - V.s.level) + 20))
    return math.floor(base * mult / 10)
end

-- Weg gehen: Laenge ueber das Wegenetz; Auffaelligkeiten werden notiert
local function Travel(map, x, y, what)
    local s = V.s
    if not map or not x then return end
    local pi, pn, pw, pmap = LP.Geo:Player()
    local ti, tn, tw = LP.Geo:ToWorld(map, x, y)
    if pi and ti then
        LP.yieldOK = { graph = true }
        local path, kind = LP.Graph:Path(pi, pn, pw, pmap, ti, tn, tw, map)
        LP.yieldOK = nil
        if not path then
            Note("nopath", L("Kein Weg: %s » %s (%s)", LP.Geo:MapName(pmap), LP.Geo:MapName(map), tostring(what)))
            s.nopath = s.nopath + 1
        else
            local d = 0
            for i = 2, #path do
                local a, b = path[i - 1], path[i]
                if a[1] == b[1] then
                    local seg = math.sqrt((a[2] - b[2]) ^ 2 + (a[3] - b[3]) ^ 2)
                    d = d + seg
                    -- Abschnitt ohne bekannten Weg (Luftlinie): der Zone zuordnen, in der er beginnt
                    if (b.via == "v" or kind == "direct") and seg > LONG_DIRECT then
                        local zm = a[4] or b[4] or map
                        local z = s.direct[zm] or { n = 0, max = 0 }
                        s.direct[zm] = z
                        z.n = z.n + 1
                        if seg > z.max then z.max, z.what, z.lvl, z.fx, z.fy = seg, what, s.level, s.x, s.y end
                    end
                else
                    d = d + 1000
                end
            end
            s.dist = s.dist + d
            s.clock = s.clock + d / (s.level >= 40 and RUN * 1.6 or RUN)
            if V.watch then V.lastPath = path end
        end
    elseif not ti then
        Note("nomap", L("Ziel ohne Weltkoordinaten: %s (%s)", LP.Geo:MapName(map), tostring(what)))
    end
    if map ~= s.map then
        local z = s.zones[#s.zones]
        if not z or z.map ~= map then
            local st = s.current
            s.zones[#s.zones + 1] = { map = map, lvl = s.level, what = what, t = st and st.t, id = st and st.id }
        end
    end
    s.map, s.x, s.y = map, x, y
end

local function LogIndex(id)
    for i, q in ipairs(V.s.log) do if q.id == id then return i, q end end
end

local last, same = nil, 0
-- ein Schritt der Reise; false = Reise zu Ende
local function Step()
    local s = V.s
    if s.level >= 60 then return false end
    if s.steps >= MAX_STEPS then Note("limit", L["Abbruch: zu viele Schritte"]) return false end
    s.steps = s.steps + 1
    local t0 = debugprofilestop and debugprofilestop() or 0
    LP.yieldOK = { plan = true }
    LP.Planner:DoReplan()               -- direkt: in der Coroutine darf die Planung pausieren
    LP.yieldOK = nil
    local ms = debugprofilestop and (debugprofilestop() - t0) or 0
    s.planMs = (s.planMs or 0) + ms
    s.planN = (s.planN or 0) + 1
    local st = LP.Engine:Current()
    s.current = st
    if not st then
        Note("noroute", L("Keine Schritte geplant auf Level %d", s.level))
        GainXP(math.floor((45 + 5 * s.level) * 2.2 * 10))   -- 10 Minuten Monster
        s.clock = s.clock + 600
        s.grind = s.grind + 1
        return true
    end
    if st.key == "NODATA" or st.key == "NOPOS" then
        Note("noroute", L("Planung ohne Daten oder Position (%s) – Reise beendet", st.key))
        return false
    end
    local key = st.key .. ":" .. #s.log .. ":" .. s.level .. ":" .. s.xp
    if key == last then same = same + 1 else same, last = 0, key end
    if same >= 4 then
        Note("stall", L("Plan hängt bei %s „%s“ – übersprungen", st.t, tostring(st.q or st.text or st.key):sub(1, 50)))
        LP.Engine:Skip(st)
        s.skipped = s.skipped + 1
        same = 0
        return true
    end
    local what = st.q or st.text or st.npc or st.t
    if st.t == "ACCEPT" then
        Travel(st.map, st.x, st.y, what)
        if #s.log < LP.API.MaxQuests() and not LogIndex(st.id) then
            local objs, q = QuestObjs(st.id)
            s.log[#s.log + 1] = { id = st.id, title = st.q or (q and q.name) or ("#" .. st.id), level = q and q.level or s.level,
                                  complete = #objs == 0, objs = objs, elite = q and q.elite, escort = q and q.escort }
            s.accepted = s.accepted + 1
        else
            s.char.notOffered[st.id] = LP:Now()
        end
        s.clock = s.clock + 10
    elseif st.t == "COMPLETE" then
        local i, q = LogIndex(st.id)
        if not q then
            Note("error", L("Erledigen ohne Quest im Log: %s", tostring(st.q or st.id)))
            LP.Engine:Skip(st)
        else
            Travel(st.map, st.x, st.y, what)
            local secs, kills = 90, 3
            for oi, o in ipairs(q.objs) do
                if not o.finished then
                    o.finished, o.have = true, 1
                    o.text = o.text:gsub("0/1", "1/1")
                    secs = (KIND_SECS[o.kind] or 150) + (o.elite and 900 or 0) + ((oi == 1 and q.escort) and 480 or 0)
                    kills = (o.kind == "kill" or o.kind == "item") and 8 or 1
                    break
                end
            end
            local done = true
            for _, o in ipairs(q.objs) do if not o.finished then done = false end end
            q.complete = done
            s.clock = s.clock + secs
            GainXP(math.floor((45 + 5 * s.level) * kills * 0.9))
        end
    elseif st.t == "TURNIN" then
        local i, q = LogIndex(st.id)
        Travel(st.map, st.x, st.y, what)
        if q then
            table.remove(s.log, i)
            s.done[st.id] = true
            s.char.turnedIn[st.id] = true
            s.quests = s.quests + 1
            local dq = LP.QuestDB:Get(st.id)
            GainXP(math.floor(QuestXP(st.id) * ((dq and dq.dungeon) and 2.16 or 1)))
        else
            Note("error", L("Abgeben ohne Quest im Log: %s", tostring(st.q or st.id)))
            LP.Engine:Skip(st)
        end
        s.clock = s.clock + 10
    elseif st.t == "LEVEL" then
        GainXP(math.floor((45 + 5 * s.level) * 2.2 * 10))
        s.clock = s.clock + 600
        s.grind = s.grind + 1
    elseif st.t == "FP" then
        Travel(st.map, st.x, st.y, what)
        -- Flugpunkt lernen: bekannter Knoten an dieser Stelle, sonst ein eigener Knoten am Flugmeister
        local fi, fn, fw = LP.Geo:ToWorld(st.map, st.x, st.y)
        local node, nd
        for name, tx in pairs(saved.taxi or {}) do
            if type(tx) == "table" and tx.map then
                local ti, tn, tw = LP.Geo:ToWorld(tx.map, tx.x, tx.y)
                if ti and ti == fi then
                    local d = LP.Geo:Dist(fn, fw, tn, tw)
                    if d < 200 and (not nd or d < nd) then node, nd = name, d end
                end
            end
        end
        if not node and st.npc then
            node = st.npc
            s.taxi[node] = { name = node, map = st.map, x = st.x, y = st.y }
        end
        if node then s.char.taxiKnown[node] = true end
        s.char.fpVisited[(st.npc or "?") .. ":" .. tostring(st.map)] = true
        s.char.doneKeys[st.key] = true
        s.clock = s.clock + 10
    elseif st.t == "FLY" then
        Travel(st.map, st.x, st.y, what)
        local dest = LP.db.taxi and LP.db.taxi[st.text]
        if dest and dest.map then
            s.clock = s.clock + 120
            s.flights = s.flights + 1
            s.map, s.x, s.y = dest.map, dest.x, dest.y
        else
            Note("fly", L("Flugziel unbekannt: %s", tostring(st.text)))
        end
        s.char.doneKeys[st.key] = true
    elseif st.t == "BIND" then
        Travel(st.map, st.x, st.y, what)
        s.char.bind = { map = st.map, x = st.x, y = st.y, name = st.text }
        s.char.doneKeys[st.key] = true
    elseif st.t == "HEARTH" then
        local b = s.char.bind
        if b and b.map then s.map, s.x, s.y = b.map, b.x, b.y s.clock = s.clock + 20 s.hearths = s.hearths + 1 s.hearthAt = s.clock end
        s.char.doneKeys[st.key] = true
    elseif st.t == "DUNGEON" and not st.inside then
        Travel(st.map, st.x, st.y, what)
        local n = 0
        for _, q in ipairs(s.log) do
            local dq = LP.QuestDB:Get(q.id)
            if dq and dq.dungeon and (dq.dungeon == st.area) then
                for _, o in ipairs(q.objs) do o.finished, o.have = true, 1 end
                q.complete = true
                n = n + 1
            end
        end
        if n == 0 then
            Note("dungeon", L("Dungeon ohne passende Quests im Log: %s", tostring(st.q)))
            LP.Engine:Skip(st)
        else
            s.dungeons[#s.dungeons + 1] = L("L%d %s (%d Quests)", s.level, tostring(st.q), n)
            s.clock = s.clock + 45 * 60 + 7 * 60 * n
            GainXP(math.floor((45 + 5 * s.level) * 60 * 0.3))
        end
        s.char.dungeonRun[st.area] = s.level
    else
        if st.map and st.x then Travel(st.map, st.x, st.y, what) end
        s.char.doneKeys[st.key] = true
        LP.Engine:Skip(st)
    end
    return true
end
V.Step = Step

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
local ticker
local function Finish(reason)
    if ticker then if ticker.Cancel then ticker:Cancel() end ticker = nil end V.token = (V.token or 0) + 1
    LP.yieldCo, LP.yieldOK = nil, nil
    local report = V:Report(reason)
    V.lastReport = report
    V.active = false
    Uninstall()
    LP.Planner:BuildCandidates()
    LP.Planner:Replan(true)
    if LP.Nav then LP.Nav:Recalc(true) end
    if LP.UI then LP.UI:Refresh() end
    V:UpdateWindow()
    if LP.Protocol then
        local p = 0
        for _, e in ipairs(V.s.problems) do if e.kind ~= "limit" then p = p + 1 end end
        LP.Protocol:Add("session", L("Virtuelle Reise L%d–%d: %d Auffälligkeit(en)", V.s.startLevel, V.s.level, p))
    end
    LP:Print(L["Virtuelle Reise beendet – Bericht mit „Bericht“ oder /lp reise bericht."])
    if V.onDone then local cb = V.onDone V.onDone = nil pcall(cb, report, V.s) return report end
    if not V.silent then LP.Backup:ShowText(L["Virtuelle Reise – Bericht"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."], report) end
    return report
end

-- startLevel: 1 = ab Startgebiet; "here" = ab aktuellem Level und Ort des echten Charakters
function V:Start(mode, opts)
    if self.active then return end
    opts = opts or {}
    local _, race = UnitRace("player")
    local here = (mode == "here")
    local level = here and (UnitLevel("player") or 1) or 1
    local s = {
        level = level, xp = 0, xpMax = XPNEED[level] or 1, log = {}, done = {}, clock = 0, steps = 0,
        quests = 0, accepted = 0, dist = 0, nopath = 0, skipped = 0, grind = 0, flights = 0, hearths = 0,
        slowest = 0, problems = {}, seen = {}, zones = {}, levelAt = {}, dungeons = {}, direct = {}, startLevel = level,
        startTime = GetTime(),
    }
    s.here = here
    if here then
        local _, _, _, map, x, y = LP.Geo:Player()
        s.map, s.x, s.y = map, x, y
        -- echtes Questlog als Ausgangspunkt (Stand jetzt), echte EP
        for _, q in ipairs(LP.API.Quests()) do
            local objs = {}
            for _, o in ipairs(LP.API.Objectives(q.index)) do
                objs[#objs + 1] = { text = o.text or "?", finished = o.finished, have = o.have or 0, need = o.need or 1, type = o.type,
                                    kind = ({ monster = "kill", item = "item", object = "object", event = "explore" })[o.type or ""] or "item" }
            end
            local dq = LP.QuestDB:Get(q.id)
            s.log[#s.log + 1] = { id = q.id, title = q.title, level = q.level or level, complete = q.complete, objs = objs,
                                  elite = dq and dq.elite, escort = dq and dq.escort }
        end
        s.xp = UnitXP and UnitXP("player") or 0
        s.xpMax = UnitXPMax and UnitXPMax("player") or s.xpMax
        local realDone = LP.API.IsQuestDone
        s.doneFallback = realDone
    end
    if not s.map then
        local st = START[race] or START.Human
        s.map, s.x, s.y = st[1], st[2], st[3]
    end
    self.s = s
    self.active = true
    self.watch = opts.watch and true or false
    self.silent = opts.silent
    self.paused = false
    self.stopRequested = false
    self.maxLevel = opts.maxLevel
    self.onDone = opts.onDone
    last, same = nil, 0
    Install()
    LP.Planner:BuildCandidates()
    s.levelAt[level] = { t = 0, q = 0, zone = s.map }
    s.zones[1] = { map = s.map, lvl = level }
    LP:Print(L("Virtuelle Reise ab Level %d in %s gestartet. Dein Charakter bewegt sich nicht; es wird nichts aufgezeichnet.", level, LP.Geo:MapName(s.map)))
    self:ShowWindow()
    local wait = 0
    V.token = (V.token or 0) + 1
    local token = V.token
    local function body()
        while V.active and not V.stopRequested do
            local more = Step()
            if not more or (V.maxLevel and V.s.level >= V.maxLevel) then break end
            if V.watch then coroutine.yield("watch") end
        end
    end
    local co = coroutine.create(body)
    LP.yieldCo = co
    ticker = C_Timer.NewTicker(0.05, function()
        if token ~= V.token or not V.active then return end
        if V.stopRequested then V.stopRequested = false Finish("stop") return end
        if V.paused then return end
        if V.watch then
            wait = wait - 0.05
            if wait > 0 then return end
            wait = V.watchDelay or 1.5
        end
        LP.sliceStart = debugprofilestop and debugprofilestop() or 0
        LP.sliceBudget = 12
        local ok, err = coroutine.resume(co)
        LP.yieldOK = nil
        if not ok then
            -- Fehler in einem Schritt: notieren, Schritt auslassen, weiter
            Note("error", L("Fehler in der Reise: %s", tostring(err)))
            pcall(LP.Engine.Skip, LP.Engine, V.s.current)
            co = coroutine.create(body)
            LP.yieldCo = co
        elseif coroutine.status(co) == "dead" then
            Finish(V.s.level >= 60 and "done" or "stop")
            return
        end
        if V.watch then
            if LP.Nav then pcall(LP.Nav.Recalc, LP.Nav, true) end
            if WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame.SetMapID then pcall(WorldMapFrame.SetMapID, WorldMapFrame, V.s.map) end
            if LP.UI then pcall(LP.UI.Refresh, LP.UI) end
        end
        V:UpdateWindow()
    end)
end

-- Sofort zurueckbauen ohne Bericht und Neuplanung (Ausloggen, /reload): echte Tabellen muessen
-- gespeichert werden, nie die virtuellen Kopien
function V:Abort()
    if not self.active then return end
    if ticker then if ticker.Cancel then ticker:Cancel() end ticker = nil end
    V.token = (V.token or 0) + 1
    LP.yieldCo, LP.yieldOK = nil, nil
    self.active = false
    Uninstall()
end

-- echte Charakterdaten (auch waehrend einer Reise)
function V:RealChar() return (self.active and saved.char) or LP.char end

LP:On("PLAYER_LOGOUT", function() V:Abort() end)

function V:Stop()
    if not self.active then return end
    if ticker and LP.yieldCo and coroutine.running() == LP.yieldCo then
        self.stopRequested = true          -- aus der Reise selbst: der naechste Takt beendet sie sauber
        self.paused = false
        return
    end
    -- Knopf / Befehl: sofort beenden; die angehaltene Planung wird verworfen
    V.token = (V.token or 0) + 1
    LP.yieldCo, LP.yieldOK = nil, nil
    return Finish("stop")
end

-- ganze Reise ohne Ticker (Selbsttest / Testumgebung)
function V:RunAll(mode, maxLevel)
    self:Start(mode, { silent = true })
    if ticker then if ticker.Cancel then ticker:Cancel() end ticker = nil end V.token = (V.token or 0) + 1
    LP.yieldCo = nil
    while self.active and self.s.level < (maxLevel or 60) do
        local ok, more = pcall(Step)
        if not ok then Note("error", L("Fehler in der Reise: %s", tostring(more))) LP.Engine:Skip(LP.Engine:Current()) more = true end
        if not more then break end
    end
    return Finish(self.s.level >= 60 and "done" or "stop")
end

------------------------------------------------------------------------
-- Bericht
------------------------------------------------------------------------
local function Dur(sec)
    sec = math.floor(sec or 0)
    return L("%d h %02d min", math.floor(sec / 3600), math.floor(sec / 60) % 60)
end

function V:Report(reason)
    local s = self.s
    if not s then return L["Noch keine virtuelle Reise."] end
    local out = {}
    local function add(l) out[#out + 1] = tostring(l):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "") end
    local _, class = UnitClass("player")
    local _, race = UnitRace("player")
    add(L("LevelPilot – virtuelle Reise · v%s · %s", LP.version, date("%d.%m.%Y %H:%M")))
    add(L("Charakter %s %s %s · Modus %s · Client %s · Sprache %s", tostring(race), tostring(class), tostring(LP:PlayerFaction()),
        (LP.Planner.IsSpeed and LP.Planner:IsSpeed()) and L["Speedrun"] or L["Normal"], tostring(GetLocale and GetLocale()), tostring(LP:Language())))
    add(L("Level %d » %d%s · Schritte %d · Quests %d abgegeben (%d angenommen) · Weg %.0f km · Flüge %d · Ruhestein %d",
        s.startLevel, s.level, reason == "stop" and L[" (abgebrochen)"] or "", s.steps, s.quests, s.accepted, s.dist * 0.9144 / 1000, s.flights, s.hearths))
    add(L("Geschätzte Spielzeit %s · Grinden %d× 10 min · übersprungen %d · ohne Weg %d · Planung im Schnitt %d ms je Schritt · Dauer %ds",
        Dur(s.clock), s.grind, s.skipped, s.nopath, math.floor((s.planMs or 0) / math.max(1, s.planN or 1)), math.floor(GetTime() - s.startTime)))
    add("")
    add(L("== Auffälligkeiten (%d)", #s.problems))
    if #s.problems == 0 then add(L["  keine"]) end
    local CODE = { nopath = L["KEIN WEG"], direct = L["LUFTLINIE"], stall = L["HÄNGT"], noroute = L["ROUTE"], error = L["FEHLER"],
                   fly = L["FLUG"], dungeon = L["DUNGEON"], nomap = L["KARTE"], limit = L["ABBRUCH"] }
    for _, e in ipairs(s.problems) do
        add(string.format("  [%s]%s L%d %s %.1f,%.1f | %s", CODE[e.kind] or e.kind, e.n > 1 and (" ×" .. e.n) or "", e.lvl,
            LP.Geo:MapName(e.map), e.x or 0, e.y or 0, e.text))
    end
    local dz = {}
    for map, z in pairs(s.direct) do dz[#dz + 1] = { map = map, z = z } end
    table.sort(dz, function(a, b) return a.z.n > b.z.n end)
    add("")
    add(L("== Lange Luftlinien (über %d Yards ohne bekannten Weg) je Zone", LONG_DIRECT))
    if #dz == 0 then add(L["  keine"]) end
    for _, e in ipairs(dz) do
        add(L("  %s: %d×, längste %d Yards (L%d, von %.1f,%.1f zu „%s“)", LP.Geo:MapName(e.map), e.z.n, math.floor(e.z.max), e.z.lvl or 0,
            e.z.fx or 0, e.z.fy or 0, tostring(e.z.what)))
    end
    add("")
    add(L["== Level (Zeit seit Start, Quests, Zone)"])
    local lv = {}
    for l, e in pairs(s.levelAt) do lv[#lv + 1] = l end
    table.sort(lv)
    for _, l in ipairs(lv) do
        local e = s.levelAt[l]
        add(string.format("  L%-2d %s  Q%-4d %s", l, Dur(e.t), e.q, LP.Geo:MapName(e.zone)))
    end
    add("")
    add(L["== Zonen in Reihenfolge"])
    local z = {}
    for _, e in ipairs(s.zones) do z[#z + 1] = "L" .. e.lvl .. " " .. LP.Geo:MapName(e.map) end
    for i = 1, #z, 6 do add("  " .. table.concat(z, " » ", i, math.min(#z, i + 5))) end
    if #s.dungeons > 0 then
        add("")
        add(L["== Dungeons"])
        for _, d in ipairs(s.dungeons) do add("  " .. d) end
    end
    return table.concat(out, "\n")
end

------------------------------------------------------------------------
-- Fenster
------------------------------------------------------------------------
local win
function V:ShowWindow()
    if not CreateFrame or not LP.UI then return end
    if not win then
        local UI, C = LP.UI, LP.colors
        win = CreateFrame("Frame", "LevelPilotVirtualFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        win:SetSize(330, 118)
        win:SetPoint("TOP", 0, -120)
        win:SetFrameStrata("DIALOG")
        win:EnableMouse(true)
        win:SetMovable(true)
        win:RegisterForDrag("LeftButton")
        win:SetScript("OnDragStart", win.StartMoving)
        win:SetScript("OnDragStop", win.StopMovingOrSizing)
        UI:Skin(win, C.panel, C.accent)
        win.title = UI:Text(win, 13, C.accent)
        win.title:SetPoint("TOPLEFT", 12, -10)
        win.title:SetText(L["Virtuelle Reise"])
        win.text = UI:Text(win, 11, C.text)
        win.text:SetPoint("TOPLEFT", 12, -30)
        win.text:SetWidth(306)
        local b1 = UI:Button(win, L["Pause"], 72, 22, function()
            V.paused = not V.paused
            V:UpdateWindow()
        end)
        b1:SetPoint("BOTTOMLEFT", 10, 10)
        win.bPause = b1
        local b2 = UI:Button(win, L["Zuschauen"], 76, 22, function()
            V.watch = not V.watch
            if V.watch and WorldMapFrame and not WorldMapFrame:IsShown() and ToggleWorldMap then pcall(ToggleWorldMap) end
            V:UpdateWindow()
        end, L["Zuschauen: jeder Weg wird auf der Weltkarte gezeigt (langsam). Schnell: ohne Pause durchrechnen."])
        b2:SetPoint("LEFT", b1, "RIGHT", 6, 0)
        win.bWatch = b2
        local b3 = UI:Button(win, L["Stopp"], 60, 22, function() V:Stop() end)
        b3:SetPoint("LEFT", b2, "RIGHT", 6, 0)
        win.bStop = b3
        local b4 = UI:Button(win, L["Bericht"], 70, 22, function()
            LP.Backup:ShowText(L["Virtuelle Reise – Bericht"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."],
                V.active and V:Report("running") or (V.lastReport or V:Report()))
        end)
        b4:SetPoint("LEFT", b3, "RIGHT", 6, 0)
        local close = UI:Button(win, "x", 20, 20, function() win:Hide() end, L["Schliessen"])
        close:SetPoint("TOPRIGHT", -6, -6)
    end
    win:Show()
    self:UpdateWindow()
end

function V:UpdateWindow()
    if not win or not win:IsShown() then return end
    local s = self.s
    if not s then win.text:SetText("") return end
    local st = s.current
    local status = self.active and (self.paused and L["pausiert"] or (self.watch and L["zuschauen"] or L["schnell"])) or L["beendet"]
    win.text:SetText(L("Level %d · %d Quests · %d Schritte · %s", s.level, s.quests, s.steps, status)
        .. "\n" .. LP.Geo:MapName(s.map) .. (st and ("\n|cff9c9ea6" .. (LP.UI:StepText(st, false):match("^[^\n]*") or "") .. "|r") or "")
        .. "\n" .. L("Auffälligkeiten: %d", #s.problems))
    win.bPause.label:SetText(self.paused and L["Weiter"] or L["Pause"])
    win.bWatch.label:SetText(self.watch and L["Schnell"] or L["Zuschauen"])
    -- nach dem Ende nur noch Bericht und Schliessen
    local on = self.active
    win.bPause:SetShown(on) win.bWatch:SetShown(on) win.bStop:SetShown(on)
    if not on then win.text:SetText(L("Beendet: Level %d · %d Quests · %d Schritte", s.level, s.quests, s.steps) .. "\n" .. L("Auffälligkeiten: %d", #s.problems)) end
end

function V:Init()
    -- falls das Spiel mitten in einer Reise neu geladen wird: nichts bleibt umgeleitet
    LP:On("PLAYER_LOGOUT", function() if V.active then pcall(Uninstall) end end)
end
