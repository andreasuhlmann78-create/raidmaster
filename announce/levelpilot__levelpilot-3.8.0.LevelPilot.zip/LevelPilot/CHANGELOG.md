# LevelPilot changelog

## 3.8.0
Fixes from the in-game test report of 3.7.0. Route and path changes apply to normal play, not only to the
virtual journey.
- Route: quests in the other faction's home zones that are open to everyone (e.g. Westfall for the Horde),
  PvP quests and battleground quests (Alterac Valley, Warsong Gulch, Arathi Basin) are no longer planned.
- Route: fewer zone and continent hops. Below level 12 you stay on your own continent; a zone on another
  continent only becomes the focus with at least 5 tasks and clearly more value than anything left here.
- Speedrun: the way to a quest giver now only affects the order, not whether a quest is skipped – before,
  standing in a capital far from quest givers could leave you grinding for hours (L28–50 in Thunder Bluff).
- WoW Forever is the default: quest log 40, dungeon monster XP about 30 %, dungeon quest XP about ×2
  (setting "WoW Forever server" under Settings » Server & dungeons).
- Zone check: "Das Brachland" and "Brachland" count as the same zone (no more ZONE entries).
- Virtual journey: planning is spread over several frames ("script ran too long" is gone), Stop ends it at
  once, it uses flight paths and its own hearthstone cooldown, quest levels are coloured by the journey's
  level, "Journey from here" takes over your real quest log, the window shows the result after the end.
- Data safety: logging out or /reload during a virtual journey restores your real flight paths and
  character data first, so nothing virtual is ever saved.
- Error log: entries are stored as keys and shown in the current language, sorted newest first; the
  self-test shows log entries as a hint instead of OK. Obsolete "language pack MISSING" entries are removed.
- Display: settings hint no longer overlaps "Support the addon"; objective names instead of "?"; the time
  estimate includes the remaining path.

## 3.7.0
- New: self-test (/lp test or control center » Data » Self-test) checks all functions in the game – modules,
  data package, language and names, position and zone, planning, path to the current step, display, map,
  nameplates, target button, comfort, sharing, error log – and shows a report to copy.
- New: virtual journey 1–60 (/lp reise, or "Journey from here" with /lp reise hier). An imaginary character
  runs LevelPilot's whole route with the game's real map and path data: accepts, completes and turns in
  quests, earns XP by Classic rules, flies and uses the hearthstone. Your character does not move; nothing
  is recorded or shared. "Watch" shows every path on the world map, "Fast" computes straight through.
  The report lists missing paths, long straight lines per zone, stuck plans, levels and zones.
- Fixed: Searing Gorge had no zone transition – found by the virtual journey; it is now connected to the
  Burning Steppes through Blackrock Mountain.

## 3.6.0
- Fixed: translated quest, NPC, item, object and zone names did not appear in the game, because WoW only
  detects new AddOn folders after a full restart. The names are now part of the data package itself
  (LevelPilot Data 1.6.0, Data/Names_*.lua) – a /reload is enough, and there are only two folders again.
- Languages your game can't display are released from memory at login.
- Target button: uses the enemy names of your game's language (before, non-English games got the
  English names and /targetexact found nothing).
- The separate folders LevelPilot_Data_deDE … from 3.5.x are no longer needed and can be deleted.

## 3.5.3
- Changed: the language selection only offers languages your game can display. LevelPilot measures it:
  a missing font draws every character as an identical box, so if all sample characters of a language
  are as wide as a surely missing character, that language is hidden. On European and Russian clients
  Korean and Chinese are hidden; on clients that have those fonts everything stays available.
- A saved language that can't be displayed falls back to "Automatic"; /lp lang refuses it with a reason.
- Fixed: language buttons keep their own script font (e.g. "Русский" no longer turned into boxes).

## 3.5.2
- Fixed: no more language mix. Vendor, innkeeper and flight master names, enemy names in the safe mode
  warning, the navigation arrow, nameplate texts and time units (h/min) now follow the chosen language.
  Hint pop-ups in the old language are closed when you switch.
- Fixed: buttons shrink their font instead of cutting off long words (e.g. Russian "Automatic").
- Fixed: the status bar measures its real text height, so long status lines are no longer cut off.
- Fixed: Russian font has no middle dot "·" – it is replaced, no more empty boxes.
- New: if a language pack can't be loaded, LevelPilot says why (most often: WoW must be fully restarted
  once after new AddOn folders were added – /reload is not enough). /lp diag shows the language packs.

## 3.5.1
- Packaging: one single download (LevelPilot.zip) now contains the addon, the data package and all
  language packs. Extract everything into Interface/AddOns.

## 3.5.0
- New: quest, NPC, item, object and zone names follow the language you choose in LevelPilot – no longer
  the language of your game client. Translations come from QuestieDB (GPLv3) as language packs in the
  data package (LevelPilot Data 1.5.0: LevelPilot_Data_deDE, _frFR, _esES, _esMX, _ptBR, _ruRU, _koKR,
  _zhCN, _zhTW). Only the packs that are needed are loaded. English uses the names of the data package;
  Italian has no Questie translation and shows English names.
- Quest objectives from the quest log are shown in the chosen language as well ("Name: 3/7").
- In your game's own language, the titles the game shows are kept; quests not yet in your log no longer
  appear in English.
- Target macros keep the names the game knows, so targeting still works in any language.

## 3.4.5
- Fixed: switching the language now updates every label in the guide window and the control center
  immediately – no /reload needed – and switching back restores everything. Words that share one
  translation (e.g. German "Austausch" and "Teilen" are both "Compartir" in Spanish) no longer come
  back wrong. Steps, hints and data source info are rebuilt in the new language as well.

## 3.4.4
- Changed: vendors now get every grey item – weapons, armour and junk. Items whose data the game had
  not loaded yet (often weapons from earlier sessions) used to stay in the bags; they are now sold too.
  Only items needed for a running quest or that start a quest are kept. The chat message shows the
  real amount earned.

## 3.4.3
- Fixed: the guide window header no longer cuts off text. The zone name has its own line across the
  full width, the "Normal / Skip / Replan" buttons moved to a separate row, and the XP line wraps
  instead of being hidden behind the buttons.
- Fixed: the status bar grows with its text and keeps clear of the resize grip.
- Fixed: the replan button showed an empty box (the ↻ glyph is missing in the game fonts) – it now uses
  an arrow icon. Arrows "→" in texts were replaced by "»" for the same reason.

## 3.4.2
- New: **Support** button in the guide window's title bar (a coin icon when the window is narrow), a
  "Support the addon" line in Settings and `/lp donate` (also `/lp spenden`, `/lp support`). It shows the
  PayPal link to copy – it never opens on its own and never posts anything in chat.

## 3.4.1
- New: error log for testers. LevelPilot quietly notes Lua errors, wrongly detected zones, unknown
  position, planning in the wrong zone, missing paths, being stuck, very long steps, deaths, slow
  planning and login/logout. `/lp protokoll` shows it as text to copy; it stays on your computer and
  contains no names or login data. Can be switched off under Extras.

## 3.4.0
- New control center tab "Extras": quest item locations with arrow and alert, quest tooltips, automatic
  restocking of food/water/ammo/pet food, auto-equip of reward upgrades, gold per hour, best level times,
  time estimates, rested/hearthstone status, "where was I?" on login, turn-in reminders, logout summary,
  corpse arrow, class quest and trainer cost hints, mount gold planning, quest sharing, group finder
  text, elite partner search, compact mode and per-character settings.
- Fixed: corpse arrow position, gold per hour counting.
