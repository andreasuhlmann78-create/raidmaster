if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Kern
-- Datenbank, Markt-Scan, Preisverlauf, Trends, Marktwert (Median),
-- Händlerpreise, Export, Befehle
--
-- WICHTIG: Alle Dateien des Addons benutzen NUR die globale
-- Tabelle "AHAnalyzerPro". Keine weiteren Namensräume.
-- ============================================================

local ADDON_NAME = ...

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetItemIcon = GetItemIcon or (C_Item and C_Item.GetItemIconByID)
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local L = A.L

A.version = "0.65.414"
A.DONATE_URL = "https://www.paypal.com/ncp/payment/46R68N2BF7BTY"   -- Spenden (PayPal)
A.ICON = "Interface\\AddOns\\AHSentinel\\Media\\Icon"     -- eigenes Icon (Waage)
A.ADDON_NAME = ADDON_NAME or "AHSentinel"
A.SCAN_COOLDOWN = 900          -- Server erlaubt nur alle 15 Minuten einen Scan
A.DB_VERSION = 4
A.MAX_HISTORY = 300            -- max. Preis-Einträge pro Item
A.HISTORY_DAYS = 90            -- ältere Einträge werden gelöscht
A.MARKET_DAYS = 14             -- Marktwert = Median der Preise dieser Tage
A.FRESH_SECONDS = 2 * 3600     -- so lange gilt ein Preis als aktuell (für Händler-Schnäppchen)

-- ------------------------------------------------------------
-- Ausgabe
-- ------------------------------------------------------------
-- Test- und Entwicklerfunktionen (Selbsttest, Testmodus) nur für den Entwickler (GoldSentinelDev.lua)
-- TEST-DEV1 (Entscheid des Nutzers 14.11. 18:19 "der Test sollte nur bei mir laufen"): Entwickler-Modus nur über einen
-- versteckten Schalter "/ahs entwickler an|aus" (kontoweit in AHSentinelDB, Standard AUS, keine Namen im Code).
-- Aus: Testroutine/Selbsttest/Testmodus/Spieltest/Protokoll gesperrt und nicht in der Befehlsliste, kein Knopf "Test",
-- Selbstkontrollen (SK1), Diagnose-Protokoll, Ereignis-Zeitmessung und Sniper-Takt-Zähler laufen nicht.
function A:IsDev()
    return self.devOn == true
end
function A:DevRefresh()
    self.devOn = (self.db and self.db.entwickler == true) or false
    return self.devOn
end
function A:SetDev(on)
    if not self.db then return false end
    if on and not self.db.entwickler then
        -- Speicher von AHSentinel beim Einschalten (bis hierher lief der Messcode nicht) - Vergleich im Testbericht
        local kb = self.Vollscan and self.Vollscan.AddonKB and self.Vollscan:AddonKB() or nil
        self.db.devSince = { t = time(), kb = kb and math.floor(kb + 0.5) or nil }
    end
    self.db.entwickler = on and true or nil
    self:DevRefresh()
    if self.UI and self.UI.UpdateHeaderStatus then pcall(self.UI.UpdateHeaderStatus, self.UI) end
    return self.devOn
end
function A:RequireDev()
    if self:IsDev() then return true end
    self.devBlocked = (self.devBlocked or 0) + 1
    self:Print(L["Diese Funktion gehört zum Testmodus und ist nicht freigeschaltet."])
    return false
end

function A:Print(msg)
    local p = self:Global("print") or print                            -- TAINT-1 (0.65.330): Test fängt über apiOverride ab
    p("|cff00d1d1[AHSentinel]|r " .. tostring(msg))
end

-- Abgefangene Fehler zusätzlich an die Prüfung melden (GoldSentinelTest.lua); die Chat-Ausgabe bleibt, wie sie ist.
function A:ReportError(where, msg)
    local GT = _G.GoldSentinelTest
    if GT and GT.Error then pcall(GT.Error, "AHSentinel", where, msg) end
end

-- Erwartete Fehler (SafeCall-Hilfen der Module): nur melden, wenn eine vorhandene Funktion einen Lua-Fehler wirft,
-- und dann höchstens einmal je Funktion und Sitzung.
A.reportedOnce = {}
function A:ReportOnce(key, where, msg)
    if key == nil or self.reportedOnce[key] then return end
    self.reportedOnce[key] = true
    self:ReportError(where, msg)
end

-- Simulation: Testmodus oder Testroutine. Aktionen mit Folgen (Händler, Post, Preis-Sync) werden dann nur protokolliert.
function A:Simulated()
    return (self.TestMode and self.TestMode.active) or (self.TestRoutine and self.TestRoutine.running) or false
end

-- Kampf: die Testroutine schaltet A.testCombat um (statt InCombatLockdown zu ersetzen - kein Taint)
function A:InCombat()
    if self.testCombat ~= nil then return self.testCombat and true or false end
    local G = _G.GoldSentinelGame
    if G and G.InCombat then return G.InCombat() and true or false end
    return (InCombatLockdown and InCombatLockdown()) and true or false
end

-- Nahtstelle für die Testroutine: A.apiOverride setzt NUR die Testroutine (false = "Funktion fehlt").
-- Ohne Test liefert A:Global(name) einfach die Funktion des Spiels.
function A:Global(name)
    local o = self.apiOverride
    if o then
        local v = o[name]
        if v == false then return nil end
        if v ~= nil then return v end
    end
    return _G[name]
end

-- Briefkasten: alle Zugriffe des Addons laufen hier durch. Normal direkt an WoW;
-- im Testmodus ersetzt A.TestMode diese Funktionen durch einen Test-Briefkasten.
A.Inbox = {}
for _, fn in ipairs({ "GetInboxNumItems", "GetInboxHeaderInfo", "GetInboxInvoiceInfo", "GetInboxItem",
    "GetInboxItemLink", "TakeInboxMoney", "TakeInboxItem" }) do
    A.Inbox[fn] = function(...)
        local real = A:Global(fn)
        if real then return real(...) end
    end
end
function A.Inbox.Available()
    -- Test-Briefkasten (Testmodus oder Testroutine) zählt als vorhanden
    if A.TestMode and (A.TestMode.active or A.TestMode.realInbox) then return true end
    return A:Global("GetInboxNumItems") ~= nil and A:Global("TakeInboxMoney") ~= nil
end

-- Meldung groß in der Bildschirmmitte (wie eine Schlachtzugwarnung), mit Ton wenn erlaubt
function A:ScreenMessage(text, r, g, b, sound)
    text = "AHSentinel: " .. tostring(text)
    if self.TestMode and self.TestMode.active then text = "[Test] " .. text end
    local color = { r = r or 1, g = g or 0.82, b = b or 0 }
    local shown = false
    if RaidNotice_AddMessage and RaidWarningFrame then
        shown = pcall(RaidNotice_AddMessage, RaidWarningFrame, text, color)
    end
    if not shown and UIErrorsFrame and UIErrorsFrame.AddMessage then
        pcall(UIErrorsFrame.AddMessage, UIErrorsFrame, text, color.r, color.g, color.b)
    end
    if sound and self.db and self.db.settings.alertSound and PlaySound then
        pcall(PlaySound, 888)      -- gut hörbarer Klang (auch wenn man gerade woanders hinschaut)
    end
    self.lastScreenMessage = text
end

-- ------------------------------------------------------------
-- Internes Nachrichtensystem (Kern -> Oberfläche)
-- Ereignisse: SCAN_STARTED, SCAN_PROGRESS, SCAN_FINISHED,
--             SCAN_FAILED, DATA_CHANGED, WATCHLIST_CHANGED
-- ------------------------------------------------------------
A.listeners = A.listeners or {}

-- SN-EIGEN-2 (Befund 19:08 Punkt 7, T895 im Spiel "Empfänger ? von …"): WoW hat kein debug.getinfo - die Stelle eines Empfängers
-- wird darum schon beim Anmelden gemerkt (debugstack: Datei:Zeile des A:On-Aufrufs), nur einmal je Empfänger.
A.listenerAt = A.listenerAt or {}
function A:On(event, fn)
    self.listeners[event] = self.listeners[event] or {}
    table.insert(self.listeners[event], fn)
    -- BEFUND HOCH 18.11. 06:40 (Ladefehler 0.65.335–0.65.341): "local a, b = x and s:match()" liefert in Lua nur EINEN Wert
    -- (and kürzt auf einen) - line war immer nil, file .. ":" .. line warf beim Laden. Jetzt: match nur in einem if, beide Werte
    -- geprüft, und die ganze Fundstellen-Merkung in pcall - A:On wirft nie.
    local ds = self.debugstackTest or _G.debugstack      -- debugstackTest: Naht für T910 (keine Blizzard-Globale beschreiben)
    if type(ds) == "function" and type(fn) == "function" then
        pcall(function()
            -- Stufen wie im Spiel: 1 diese Funktion, 2 pcall [C], 3 A:On, 4 der Aufrufer von A:On (= Fundstelle des Empfängers)
            local txt = ds(4, 1, 0)
            if type(txt) == "string" then
                local file, line = txt:match("([%w_]+%.lua)\"?%]?:(%d+)")
                if file and line then self.listenerAt[fn] = file .. ":" .. line end
            end
        end)
    end
end
-- Stelle eines Empfängers: gemerkt beim Anmelden, sonst debug.getinfo (nur ausserhalb von WoW), sonst "?"
function A:ListenerWhere(fn)
    local w = self.listenerAt[fn]
    if w then return w end
    if debug and debug.getinfo then
        local okI, info = pcall(debug.getinfo, fn, "S")
        if okI and info then return tostring(info.short_src):match("[^/\\]*$") .. ":" .. tostring(info.linedefined) end
    end
    return "?"
end

-- VF1c: Ereignis in einer Hintergrund-Aufgabe an die Empfänger verteilen - zwischen zwei Empfängern abgeben
-- (sonst laufen alle Empfänger von SCAN_FINISHED in EINEM Frame: Messung 154 ms). Langsame Empfänger ins Protokoll.
function A:FireSpread(event, ...)
    if not self.yieldOK then return self:Fire(event, ...) end
    local list = self.listeners[event]
    if not list then return end
    local args = { ... }
    local n = select("#", ...)
    for idx, fn in ipairs(list) do
        self:Pause()
        local t0 = debugprofilestop and debugprofilestop() or 0
        self.yieldOK = false
        local firing = self.firing                                      -- VL1: Auslöser (kein Pausieren dazwischen)
        self.firing = event
        local ok, err = pcall(fn, unpack(args, 1, n))
        self.firing = firing
        self.yieldOK = true
        if not ok then
            self:Print(L["Fehler bei "] .. event .. ": " .. tostring(err))
            self:ReportError("Fire:" .. tostring(event), err)
        end
        local ms = debugprofilestop and (debugprofilestop() - t0) or 0
        if ms > 16 and self.Diag then
            local where = "#" .. idx .. " " .. self:ListenerWhere(fn)
            pcall(self.Diag.Add, self.Diag, "LANGSAM", string.format("Empfänger %s von %s · %.0f ms", where, event, ms))
        end
    end
end

-- TB172-2 (Nachlauf/Warten auf Server 775–879 ms, "Ursache mit Zeitmessung belegen"): Ereignis-Rahmen der grossen Module
-- messen. Dauert ein Aufruf > 16 ms, wird er gemerkt (A.lastSlowEvent: Modul, Ereignis, ms, Zeit); der Vollscan schreibt ihn
-- zur längsten Lücke. Ohne Eintrag in dieser Lücke lag die Zeit ausserhalb von AHSentinel (Spiel/anderes Addon).
-- VS-BILD-2 (0.65.320, Prüfung Supervisor 17.11.: "eigene OnUpdate-Skripte ebenfalls messen, sonst bleibt Rest mehrdeutig"):
-- Die Module holen sich CreateFrame und C_Timer über diese Hüllen (local CreateFrame, C_Timer = A.OwnCreateFrame …). Nur während
-- einer Vollscan-Messung (A.frameOwn) wird die Zeit jedes eigenen OnUpdate-/OnEvent-Skripts und jedes eigenen Zeitgebers in
-- A.frameOwn.upd bzw. .ev gezählt; sonst wird die Funktion unverändert aufgerufen. Frames mit A:TimeFrame zählen dort (nicht doppelt).
-- VS-EIGEN: neuer Speicher eines eigenen Aufrufs (ohne Bereinigung) in fo.kb, sonst fo.kbLost
local function OwnKB(fo, kb0)
    local kb1 = collectgarbage("count")
    if kb1 < kb0 then fo.kbLost = (fo.kbLost or 0) + 1 else fo.kb = (fo.kb or 0) + (kb1 - kb0) end
end
A.OwnKB = OwnKB
-- SN-GC (Ingametest 19.11. 12:25, Sniper T617/T734 "eigene Arbeit max 114 ms, Skripte 114"; Laptop, Lua-Speicher bis 808 MB): fiel der
-- Lua-Speicher während eines eigenen Aufrufs, lief darin eine Speicherbereinigung (aller Addons) - deren Dauer steckt in der gemessenen
-- Zeit. Zeit solcher Aufrufe zusätzlich in fo.gc (Teilmenge), damit Prüfungen die eigene Rechenzeit OHNE Bereinigung bewerten können.
local function OwnGC(fo, kb0, ms)
    if collectgarbage("count") < kb0 then fo.gc, fo.gcN = (fo.gc or 0) + ms, (fo.gcN or 0) + 1 end
end
A.OwnGC = OwnGC
local function OwnDone(fo, key, t0, kb0, ...)
    local ms = debugprofilestop() - t0
    fo[key] = (fo[key] or 0) + ms
    if key == "ev" then fo.evN = (fo.evN or 0) + 1 end
    OwnGC(fo, kb0, ms)
    OwnKB(fo, kb0)
    return ...
end
-- SN-GC: Herkunft eines langsamen eigenen Skripts (Datei:Zeile, einmal je Funktion; ohne debug.getinfo im Spiel: "?")
local function FnWhere(fn)
    local ok, info = pcall(function() return debug and debug.getinfo and debug.getinfo(fn, "S") end)
    if ok and type(info) == "table" and info.short_src then
        return (tostring(info.short_src):match("([^/\\]+)$") or "?") .. ":" .. tostring(info.linedefined)
    end
    return "?"
end
-- AHS-I6 (Ingametest 0.65.387, Sniper S13 "Skripte 105 ms", Stelle unbekannt): WoW hat kein debug.getinfo -> FnWhere lieferte im Spiel
-- "?". Die Stelle wird darum beim Einhüllen gemerkt (debugstack: Datei:Zeile des SetScript-/C_Timer-Aufrufs im Modul), sonst der
-- Rahmen-Name. Stufen: 1 DefAt, 2 OwnWrap, 3 SetScript-Hülle bzw. OwnTimer.After/NewTimer/NewTicker, 4 Aufrufer im Modul.
-- Kosten (Nachbau: 0,15 ms je Hülle; gemerkt in den ersten 60 s nach dem Laden lag T126 im Median ~1 ms höher, weil Oberflächen-
-- Portionen dann Hüllen anlegen): gemerkt wird NUR beim Laden der Dateien (vor ADDON_LOADED, A.db noch nicht da) - die Rahmen und
-- Skripte der Module, einmalig. Später angelegte Hüllen heissen nach dem Rahmen-Namen bzw. "Zeitgeber/Rahmen (Stelle nicht gemerkt)".
local function DefAt()
    if A.db and not A.defAtTest then return nil end            -- defAtTest: Naht nur für die Prüfung T1007
    local ds = A.debugstackTest or _G.debugstack
    if type(ds) ~= "function" then return nil end
    local txt = ds(4, 1, 0)
    if type(txt) ~= "string" then return nil end
    local file, line = txt:match("([%w_]+%.lua)\"?%]?:(%d+)")
    if file and line then return file .. ":" .. line end
    return nil
end
local function WrapWhere(w)
    if w.where then return w.where end
    local x = w.def
    if not x and w.frame then
        local okN, n = pcall(function() return w.frame.GetName and w.frame:GetName() end)
        if okN and type(n) == "string" then x = "Rahmen " .. n end
    end
    if not x then
        local fw = FnWhere(w.fn)
        if fw ~= "?" then x = fw end
    end
    w.where = x or (w.frame and "Rahmen ohne Namen (Stelle nicht gemerkt)" or "Zeitgeber (Stelle nicht gemerkt)")
    return w.where
end
A.OwnWrapWhere = WrapWhere
-- ohne neue Funktion je Aufruf (die Messung soll selbst keinen Speicher anlegen): w = { fn, where } je Hülle
-- AHS-I6: (1) langsamster eigener Aufruf JE BILD (fo.fSlowMs/fo.fSlowW/fo.fN, vom Bild-Zähler je Bild zurückgesetzt) - vorher nur der
-- grösste der ganzen Messung (fo.slow), darum fehlte beim Bild mit 105 ms die Stelle. (2) Verschachtelte eigene Aufrufe (ein eigenes
-- Skript löst synchron ein anderes eigenes aus) zählen nur im äussersten (fo.busy = GetTime() beim Eintritt) - sonst doppelt. Brach ein
-- Aufruf mit Fehler ab, gibt A.OwnFrameReset die Sperre im NÄCHSTEN Bild frei (GetTime anders) - keine Sperre ohne Zeitlimit; ein
-- noch laufender Aufruf im selben Bild (der Bild-Zähler ist selbst ein eigenes Skript) bleibt gesperrt.
local function OwnAfter(w, fo, key, t0, kb0, ...)
    local ms = debugprofilestop() - t0
    fo.busy = nil
    fo.fN = (fo.fN or 0) + 1
    if ms > (fo.fSlowMs or 0) then fo.fSlowMs, fo.fSlowW, fo.fSlowGC = ms, w, collectgarbage("count") < kb0 end
    if ms > 16 then
        local sl = fo.slow
        if not sl or ms > sl.ms then
            fo.slow = { ms = ms, at = WrapWhere(w), gc = collectgarbage("count") < kb0, t = GetTime and GetTime() or 0 }
        end
    end
    return OwnDone(fo, key, t0, kb0, ...)
end
local function OwnWrap(fn, key, frame)
    local w = { fn = fn, frame = frame, def = DefAt() }
    return function(...)
        local fo = A.frameOwn
        if not fo or not debugprofilestop or (key == "ev" and frame and frame.ahsTimed) or fo.busy then return fn(...) end
        fo.busy = GetTime and GetTime() or true
        local t0, kb0 = debugprofilestop(), collectgarbage("count")
        return OwnAfter(w, fo, key, t0, kb0, fn(...))
    end
end
A.OwnWrap = OwnWrap
-- AHS-I6: je Bild aufrufen - liefert den langsamsten eigenen Aufruf dieses Bilds (Stelle, ms, mit Bereinigung?, Anzahl Aufrufe) und
-- setzt die Bild-Werte zurück
function A.OwnFrameReset(fo)
    if not fo then return nil end
    local w, ms, gc, n = fo.fSlowW, fo.fSlowMs, fo.fSlowGC, fo.fN
    fo.fSlowW, fo.fSlowMs, fo.fSlowGC, fo.fN = nil, nil, nil, nil
    if fo.busy and fo.busy ~= (GetTime and GetTime() or true) then fo.busy = nil end
    if not w then return nil end
    return WrapWhere(w), ms, gc, n or 0
end
local OWN_SCRIPT = { OnUpdate = "upd", OnEvent = "ev" }
function A.OwnCreateFrame(...)
    local f = CreateFrame(...)
    if type(f) ~= "table" or not f.SetScript then return f end
    -- HUELLE-SICHER (0.65.322, Nachfrage Supervisor 0.65.320): geschützte Rahmen (Vorlage mit "Secure", z. B. der Entzauber-Knopf
    -- SecureActionButtonTemplate) bekommen KEINE Hülle - an ihnen ändert sich nichts (keine eigene Methode auf dem Rahmen, kein Taint)
    local template = select(4, ...)
    if type(template) == "string" and template:find("Secure", 1, true) then return f end
    local set, hook = f.SetScript, f.HookScript
    f.SetScript = function(self, what, fn)
        local key = OWN_SCRIPT[what]
        if key and type(fn) == "function" then fn = OwnWrap(fn, key, self) end
        return set(self, what, fn)
    end
    if hook then
        f.HookScript = function(self, what, fn)
            local key = OWN_SCRIPT[what]
            if key and type(fn) == "function" then fn = OwnWrap(fn, key, self) end
            return hook(self, what, fn)
        end
    end
    return f
end
if _G.C_Timer then
    A.OwnTimer = setmetatable({
        After = function(sec, fn) return _G.C_Timer.After(sec, type(fn) == "function" and OwnWrap(fn, "upd") or fn) end,
        NewTimer = function(sec, fn, ...) return _G.C_Timer.NewTimer(sec, type(fn) == "function" and OwnWrap(fn, "upd") or fn, ...) end,
        NewTicker = function(sec, fn, ...) return _G.C_Timer.NewTicker(sec, type(fn) == "function" and OwnWrap(fn, "upd") or fn, ...) end,
    }, { __index = function(_, k) return _G.C_Timer[k] end })
end
local C_Timer = A.OwnTimer or C_Timer      -- VS-BILD-2: eigene Zeitgeber dieser Datei (CreateFrame hier nicht: jobFrame zählt schon als Aufgabe)

function A:TimeFrame(frame, label)
    if not (frame and frame.GetScript and frame.SetScript) then return end
    local orig = frame:GetScript("OnEvent")
    if not orig or frame.ahsTimed then return end
    frame.ahsTimed = true
    frame:SetScript("OnEvent", function(f, event, ...)
        -- TEST-DEV1: Messung nur beim Entwickler; VS-BILD (0.65.318): auch während einer Vollscan-Messung (A.frameOwn)
        local fo = A.frameOwn
        if fo and fo.busy then fo = nil end                       -- AHS-I6: in einem eigenen Skript ausgelöst - zählt dort (nicht doppelt)
        if not (A.devOn or fo) then return orig(f, event, ...) end
        -- TB172-2a (0.65.237): "Clock" ist erst weiter unten lokal -> hier war es eine undefinierte Globale (nil), die Messung
        -- lief nie. Echte Uhr direkt (Ereignis-Dauer, nicht Zeitbudget).
        local t0 = debugprofilestop and debugprofilestop()
        local kb0 = fo and collectgarbage("count")
        orig(f, event, ...)
        local gcIn = fo and collectgarbage("count") < kb0          -- SN-GC: Bereinigung lief im Aufruf
        if fo then OwnKB(fo, kb0) end
        if t0 then
            local ms = debugprofilestop() - t0
            if fo then
                fo.ev, fo.evN = fo.ev + ms, fo.evN + 1
                if gcIn then fo.gc, fo.gcN = (fo.gc or 0) + ms, (fo.gcN or 0) + 1 end
            end
            if ms > 16 and A.devOn then                               -- gemerkt wie bisher nur beim Entwickler (T812)
                local s = A.lastSlowEvent
                if not s or ms > (s.ms or 0) or (GetTime() - (s.t or 0)) > 1 then
                    A.lastSlowEvent = { t = GetTime(), at = label, ev = tostring(event), ms = ms }
                end
            end
        end
    end)
end
function A:Fire(event, ...)
    local list = self.listeners[event]
    if not list then return end
    local yieldOK = self.yieldOK
    self.yieldOK = false            -- innerhalb von pcall darf eine Aufgabe nicht pausieren
    local firing = self.firing      -- VL1: laufendes Ereignis (Auslöser von Aktualisierungen im Protokoll), danach zurück
    self.firing = event
    -- TB125-3: beim Start (READY) jeden Empfänger messen -> die langsamsten mit Datei:Zeile (Testbericht T630)
    -- SN-EIGEN (0.65.320, Ingametest 17.11. T617: "Kern/ITEM_SEARCH_RESULTS_UPDATED ×32 bis 49 ms" ohne Empfänger): im
    -- Entwicklermodus jeden Empfänger messen; über 16 ms ins Protokoll LANGSAM mit Datei:Zeile des Empfängers
    local clock = (event == "READY" or self.devOn) and debugprofilestop or nil
    local times = (event == "READY" and clock) and {} or nil
    for _, fn in ipairs(list) do
        local t0 = clock and clock()
        local ok, err = pcall(fn, ...)
        if not ok then
            self:Print(L["Fehler bei "] .. event .. ": " .. tostring(err))
            self:ReportError("Fire:" .. tostring(event), err)
        end
        if clock and not times then
            local ms = clock() - t0
            if ms > 16 and self.Diag then
                local where = self:ListenerWhere(fn)
                pcall(self.Diag.Add, self.Diag, "LANGSAM", string.format("Empfänger %s von %s · %.0f ms", where, event, ms))
            end
        elseif clock then
            local ms = clock() - t0
            if ms >= 2 then
                times[#times + 1] = { ms = ms, at = self:ListenerWhere(fn) }
            end
        end
    end
    if times then
        table.sort(times, function(a, b) return a.ms > b.ms end)
        while #times > 5 do table.remove(times) end
        self.readyTimes = times
    end
    self.firing = firing
    self.yieldOK = yieldOK
end

-- ------------------------------------------------------------
-- Aufgaben im Hintergrund (gegen Ruckeln)
-- Große Arbeiten (Scan auswerten, lange Listen aufbauen) laufen in kleinen
-- Portionen: pro Frame nur wenige Millisekunden, der Rest im nächsten Frame.
--   A:Job(name, fn)  - Aufgabe starten (gleicher Name ersetzt eine wartende)
--   A:Pause()        - in langen Schleifen aufrufen: gibt die Zeit ab, wenn
--                      das Frame-Budget aufgebraucht ist (außerhalb einer
--                      Aufgabe macht es nichts)
-- ------------------------------------------------------------
A.FRAME_BUDGET = 6              -- Millisekunden Rechenzeit pro Frame für Hintergrund-Aufgaben
A.jobs = {}
A.yieldOK = false
local jobStart = 0
local jobMem0 = 0                       -- Punkt 4: Lua-Speicher zu Beginn des Bildes (Speicherbereinigung im Bild erkennen)
local pauseCount = 0
-- S92-DET (Supervisor 22:18): Uhr der Zeitbudgets austauschbar (Testnaht A.budgetClock, nur Nachbildung); im Spiel unverändert
-- debugprofilestop. Mit einer festen Arbeits-Uhr erledigen die Hintergrund-Aufgaben in jedem Lauf dieselbe Arbeit je Bild.
local Clock = debugprofilestop and function() return (A.budgetClock or debugprofilestop)() end or nil

-- ------------------------------------------------------------
-- Takt-Messwerte (Antwort Supervisor 17.11. 22:10: eigene Aufgaben dürfen bleiben, wenn sie dieselben Messwerte liefern wie
-- GoldSentinelTakt): je Bild mit Hintergrund-Arbeit das längste Bild mit Etikett, Zählung über 5/16/40 ms, "Abgabe nicht möglich"
-- (C-Grenze wie pcall/sort/gsub im Stapel - Lua 5.1 kann dort nicht abgeben; dann wird NICHT abgegeben, sondern gezählt) und
-- "Abgabe gescheitert" (eine Abgabe endete mit Fehler, ohne zurückzukommen). Gleiche Erkennung wie GoldSentinelTakt (Stapel lesen,
-- je Coroutine geeicht), aber nur dann, wenn wirklich abgegeben würde (höchstens einmal je Bild und Aufgabe).
-- ------------------------------------------------------------
A.takt = { frames = 0, over5 = 0, over16 = 0, over40 = 0, maxMs = 0, maxAt = nil, blocked = 0, blockedAt = {}, failed = 0, failedAt = {} }
local cBase = setmetatable({}, { __mode = "k" })
local function TaktStack()
    local ds = _G.debugstack
    if type(ds) == "function" then
        local v = ds(3, 100, 0)
        if type(v) == "string" then return v end
    end
    if debug and debug.traceback then
        local v = debug.traceback("", 3)
        if type(v) == "string" then return v end
    end
    return ""
end
-- T459 M3 (Freigabe Supervisor 26.11. 09:02): Zeilen mit "[C]" zählen OHNE einen Teiltext je Stapelzeile (vorher gmatch: je Zeile ein
-- neuer Text, ~563 Abgaben je Vollscan). Gleiche Regel: Zeilen mit "debugstack" oder "traceback" zählen nicht.
local function CCount(txt)
    local n, pos = 0, 1
    while true do
        local s = string.find(txt, "[C]", pos, true)
        if not s then break end
        local ls = s
        while ls > 1 and string.byte(txt, ls - 1) ~= 10 do ls = ls - 1 end
        local le = string.find(txt, "\n", s, true) or (#txt + 1)
        local d = string.find(txt, "debugstack", ls, true)
        local t = string.find(txt, "traceback", ls, true)
        if not ((d and d < le) or (t and t < le)) then n = n + 1 end
        pos = le
    end
    return n
end
A.CCount = CCount
local function TaktCalibrate()
    local co = coroutine.running()
    if co then cBase[co] = CCount(TaktStack()) end
end
local function TaktNote(kind, at)
    local tk = A.takt
    tk[kind] = (tk[kind] or 0) + 1
    local list = tk[kind .. "At"]
    if #list < 10 then
        for _, v in ipairs(list) do if v == at then return end end
        list[#list + 1] = at
    end
end
-- Coroutine einer Aufgabe (auch A:PCall): zuerst eichen, dann die Arbeit
local function TaktCo(fn)
    return coroutine.create(function(...)
        TaktCalibrate()
        return fn(...)
    end)
end
A.TaktCo = TaktCo
function A:TaktSnap()
    local tk = self.takt
    return { frames = tk.frames, over5 = tk.over5, over16 = tk.over16, over40 = tk.over40, blocked = tk.blocked, failed = tk.failed }
end
-- Zusammenfassung (wie GoldSentinelTakt.Summary); since = A:TaktSnap() von vorher (Zählungen ab dann; längstes Bild seit Reset)
function A:TaktSummary(since)
    local tk = self.takt
    local z = since or {}
    return string.format("Takt: %d Bilder · längstes %.1f ms (%s) · über 5/16/40 ms: %d/%d/%d · Abgabe nicht möglich %d%s · gescheitert %d%s",
        tk.frames - (z.frames or 0), tk.maxMs, tostring(tk.maxAt or "-"), tk.over5 - (z.over5 or 0), tk.over16 - (z.over16 or 0),
        tk.over40 - (z.over40 or 0), tk.blocked - (z.blocked or 0), #tk.blockedAt > 0 and (" (" .. table.concat(tk.blockedAt, ", ") .. ")") or "",
        tk.failed - (z.failed or 0), #tk.failedAt > 0 and (" (" .. table.concat(tk.failedAt, ", ") .. ")") or "")
end
function A:TaktReset()
    local tk = self.takt
    tk.maxMs, tk.maxAt = 0, nil
    return self:TaktSnap()
end

-- budget (ms, optional): eigenes Zeitbudget je Frame für diese Aufgabe (VF1: Vollscan Standard 4 ms)
function A:Job(name, fn, budget)
    for i = #self.jobs, 1, -1 do
        local j = self.jobs[i]
        if j.name == name and not j.started then table.remove(self.jobs, i) end
    end
    table.insert(self.jobs, { name = name, co = TaktCo(fn), budget = budget, queued = GetTime and GetTime() or 0 })
end
-- GSL2-3 (Supervisor 15.11. 15:35: forecast-eval 35× und cache:today 20× bei offenem AH während des Snipens): solange der
-- Sniper scharf ist und das AH offen, warten Prognose-Auswertung und Zwischenspeicher-Aufgaben (noch nicht begonnene),
-- höchstens SNIPE_DEFER_MAX s je Aufgabe (keine Sperre ohne Zeitlimit). Begonnene laufen in ihren Pausen weiter.
A.SNIPE_DEFER_MAX = 120
A.snipeDeferred = 0
-- SN-RUHE1 (a) (Nutzer 15:53 "ja bitte"): Ruhemodus pausiert alle Hintergrund-Rechnungen, die beim Snipen nicht gebraucht
-- werden. Sniper, sichtbares Fenster, Scan-Auswertung, Buchhaltung, Senden und Testroutine laufen weiter.
A.QUIET_JOBS = { "forecast", "cache:", "ketten:", "pd7", "kern:", "learn:", "core:", "craft-top", "de:matdiag", "hist:flat",
    "merge:market", "names", "timing" }
A.quietPaused = {}                    -- [Name] = true: in diesem Bild aufgeschoben (Anzeige "n Aufgaben pausiert")
local function QuietJob(n)
    for _, p in ipairs(A.QUIET_JOBS) do if n:sub(1, #p) == p then return true end end
    return false
end
function A:SnipeDefer(j)
    if self.TestRoutine and self.TestRoutine.running and not self.snipeDeferTest then return false end   -- Messungen der Tests
    local n = j.name or ""
    local Sn = self.Sniper
    if not (Sn and Sn.IsArmed and self:IsAHOpen() and Sn:IsArmed()) then return false end
    -- Ruhemodus (Standard an): ganze Liste, Zeitlimit QUIET_MAX ab Beginn des Ruhemodus, danach laufen sie in ihren
    -- kleinen Schritten trotzdem (keine Sperre ohne Zeitlimit).
    -- GSL6-1 (= GSL5-2, Supervisor 18:35, Code-Beleg "if j.started then return false end"): auch eine schon BEGONNENE
    -- Aufgabe der Liste hält zwischen zwei Schritten an (coroutine wird nicht fortgesetzt) und läuft nach dem Ruhemodus an
    -- derselben Stelle weiter - nichts wird verworfen.
    if Sn.QuietOn and Sn:QuietOn() then
        if not QuietJob(n) then return false end
        if Sn:QuietOver() then return false end
        self.quietPaused[n] = true
        return true
    end
    -- Ruhemodus aus: wie 0.65.196 (GSL2-3) nur Prognose und Zwischenspeicher (noch nicht begonnene), höchstens SNIPE_DEFER_MAX s
    if j.started then return false end
    if n ~= "forecast-eval" and n:sub(1, 6) ~= "cache:" then return false end
    return (GetTime() - (j.queued or 0)) < self.SNIPE_DEFER_MAX
end
-- T459-WARTEN (Ingametest 18.11. 17:01: Vollscan 58 MB eigener Speicher, grösster Posten "Warten auf Server" 33 MB; T458 nennt
-- cache:today:10 als längstes Bild im Vollscan. Nachbau mit echten Daten: läuft "Heute tun" gerade neu, legt es im Scan 11 MB an,
-- die Prognose 2,5 MB): während eines Vollscans warten Zwischenspeicher und Prognose (auch begonnene, zwischen zwei Schritten) -
-- nach dem Scan rechnen sie ohnehin mit den neuen Daten. Zeitlimit SCAN_DEFER_MAX s ab Scan-Beginn (keine Sperre ohne Zeitlimit).
A.SCAN_DEFER_MAX = 300
function A:ScanDefer(j)
    local VS = self.FullScan
    local run = VS and VS.running
    if not run then return false end
    local n = j.name or ""
    if n ~= "forecast-eval" and n:sub(1, 6) ~= "cache:" then return false end
    local t0 = type(run) == "table" and tonumber(run.t0)
    if t0 and GetTime() - t0 >= self.SCAN_DEFER_MAX then return false end
    return true
end
function A:Budget() return self.curBudget or self.FRAME_BUDGET end

-- pcall, das in einer Hintergrund-Aufgabe pausieren darf (Protokoll 10.11.: LANGSAM cache:today 413 ms).
-- In Lua 5.1 bricht coroutine.yield innerhalb von pcall ab ("attempt to yield across C-call boundary"): Die Funktion
-- lieferte dann still nichts, und der Rest der Aufgabe lief ohne Pause in einem Frame. Hier läuft fn in einer eigenen
-- Coroutine - resume fängt Fehler wie pcall, und jede Pause wird an die Aufgabe weitergereicht.
function A:PCall(fn, ...)
    if not self.yieldOK then return pcall(fn, ...) end
    local co = TaktCo(fn)
    local res = { coroutine.resume(co, ...) }
    while res[1] and coroutine.status(co) == "suspended" do
        coroutine.yield()                       -- yieldOK ist hier schon false (A:Pause); RunJobs setzt es wieder
        res = { coroutine.resume(co) }
    end
    return unpack(res, 1, table.maxn(res))
end

function A:HasJob(name)
    for _, j in ipairs(self.jobs) do if j.name == name then return true end end
    return false
end

local lastPauseT = 0
-- T373 (TS111.1-c): längster Einzelschritt (Zeit zwischen zwei Pausen) mit der Stelle, an der er endete - im Protokoll
-- LANGSAM und in der Messung der Testroutine. Die Stelle wird nur bei langen Schritten bestimmt (selten, billig).
A.LONG_STEP_MS = 8
local function StepWhere(level)
    -- direkt aufrufen (kein pcall: das wäre eine eigene Stufe im Stapel); beide werfen keinen Fehler
    local ds = _G.debugstack
    local txt
    if type(ds) == "function" then
        txt = ds(level, 1, 0)
    elseif debug and debug.traceback then
        local v = debug.traceback("", level)
        if type(v) == "string" then
            for line in v:gmatch("[^\n]+") do
                if line:find("%.lua\"?%]?:%d+") then txt = line; break end
            end
        end
    end
    if type(txt) ~= "string" then return "?" end
    local file, line = txt:match("([%w_]+%.lua)\"?%]?:(%d+)")
    return file and (file .. ":" .. line) or txt:sub(1, 60)
end
-- Punkt 4 (T126/T373, Befund 19:08: Bilder bis 20,6 ms, Schritt 13 ms "bis UI_MarketView.lua:690"; im Nachbau mit echten Daten dieselben
-- Schritte < 2 ms): Verdacht, zu messen - die Lua-Speicherbereinigung (im Spiel ~500 MB Lua-Speicher, Abschluss-Schritt unteilbar) fällt
-- in den Schritt. gc = true: während des Schritts sank der Lua-Speicher (= eine Bereinigung lief); steht im Protokoll und in T126/T373.
local lastPauseMem = 0
-- AHS-W1 (Ingametest 26.11. 15:47: "cache:warm · längster Schritt 14 ms bis :4479 · mit Speicherbereinigung"): üblicher Schritt OHNE
-- Bereinigung je Aufgabe (gleitender Mittelwert) - die LANGSAM-Zeile nennt damit den Anteil der Bereinigung (Schritt − üblich).
local avgJob, avgStep = nil, 0
local function NoteLongStep(ms, where, gc)
    local ls = A.longStep
    if not ls or ms > ls.ms then A.longStep = { ms = ms, at = where, job = A.currentJob, gc = gc or nil, base = gc and avgStep or nil } end
end
A.StepWhere = StepWhere
function A:Pause()
    if not self.yieldOK then return end
    self.jobPortion = (self.jobPortion or 0) + 1          -- F3: Schritte je Frame (Protokoll LANGSAM)
    if Clock then
        -- X5 (Befund 0.65.86, T373 16,2 ms): vorausschauend - passt der nächste Schritt (so lang wie der letzte) nicht
        -- mehr ins Budget, schon jetzt abgeben. Sonst konnte ein Frame Budget + ein ganzer langer Schritt werden.
        local now = Clock()
        local step = now - math.max(lastPauseT, jobStart)
        lastPauseT = now
        local mem = collectgarbage("count")
        local gc = mem < lastPauseMem
        lastPauseMem = mem
        if avgJob ~= self.currentJob then avgJob, avgStep = self.currentJob, step
        elseif not gc then avgStep = avgStep * 0.9 + step * 0.1 end
        if step > self.LONG_STEP_MS then NoteLongStep(step, StepWhere(3), gc) end
        if now - jobStart + step < (self.curBudget or self.FRAME_BUDGET) then return end
    else
        pauseCount = pauseCount + 1
        if pauseCount < 200 then return end
    end
    pauseCount = 0
    -- Takt: kann hier überhaupt abgegeben werden? (C-Grenze im Stapel dieser Coroutine -> nicht abgeben, zählen)
    local co = coroutine.running()
    local base = co and cBase[co]
    if base and CCount(TaktStack()) > base then
        TaktNote("blocked", StepWhere(3))
        return
    end
    local tk = self.takt
    if tk.pending then TaktNote("failed", tk.pending); tk.pending = nil end
    tk.pending = tostring(self.currentJob)
    self.yieldOK = false
    self.jobPortion = 0
    coroutine.yield()
    tk.pending = nil
    self.yieldOK = true
end
-- FEED-P (Entscheid Supervisor 17.11., 0.65.307): sofort abgeben, auch wenn das Bild-Budget noch nicht voll ist - für Arbeit mit
-- eigener, kleinerer Portionsgrenze (VS:FeedNet ≤ 4 ms am Stück). Ausserhalb einer Hintergrund-Aufgabe: nichts (false).
function A:YieldNow()
    if not self.yieldOK then return false end
    local co = coroutine.running()
    local base = co and cBase[co]
    if base and CCount(TaktStack()) > base then TaktNote("blocked", StepWhere(3)); return false end
    pauseCount = 0
    self.yieldOK = false
    self.jobPortion = 0
    coroutine.yield()
    self.yieldOK = true
    if Clock then lastPauseT = Clock(); lastPauseMem = collectgarbage("count") end
    return true
end
A.TaktCCount, A.TaktStack = CCount, TaktStack          -- Testnaht (T907)

local jobFrame = CreateFrame("Frame")
local RunJobs
jobFrame:SetScript("OnUpdate", function()
    if #A.jobs == 0 then return end
    -- GSL2-3: nur aufgeschobene Aufgaben (Snipen) -> nichts gerechnet, kein Frame für Messung/Protokoll
    if RunJobs() == false then return end
    if not Clock then return end
    local d = Clock() - jobStart
    local kbNow = collectgarbage("count")
    local gcFrame = kbNow < jobMem0                                -- Punkt 4: in diesem Bild lief eine Speicherbereinigung
    local fo = A.frameOwn                    -- VS-BILD (0.65.318): eigene Rechenzeit je Bild für die Vollscan-Messung
    if fo then
        fo.job = fo.job + d
        -- VS-EIGEN (Ingametest 18.11. 09:29, T459 285 MB): EIGENER neuer Speicher je Bild (Hintergrund-Aufgaben), getrennt vom
        -- ganzen Lua-Speicher (alle Addons + Spiel); Bilder mit Bereinigung nicht zählbar (kbLost)
        if gcFrame then
            fo.kbLost = (fo.kbLost or 0) + 1
            fo.gc, fo.gcN = (fo.gc or 0) + d, (fo.gcN or 0) + 1          -- SN-GC: Aufgaben-Zeit dieses Bilds mit Bereinigung
        else
            fo.kb = (fo.kb or 0) + (kbNow - jobMem0)
        end
    end
    -- Takt-Messwerte: jedes Bild mit Hintergrund-Arbeit
    local tk = A.takt
    tk.frames = tk.frames + 1
    if d > 5 then tk.over5 = tk.over5 + 1 end
    if d > 16 then tk.over16 = tk.over16 + 1 end
    if d > 40 then tk.over40 = tk.over40 + 1 end
    if d > tk.maxMs then
        local ls0 = A.longStep
        tk.maxMs, tk.maxAt = d, tostring(A.currentJob) .. (ls0 and (" bis " .. tostring(ls0.at)) or "")
    end
    -- Testroutine (T126): längste Rechenzeit pro Frame messen (nur wenn eingeschaltet)
    local m = A.jobMeasure
    if m then
        if d > (m.max or 0) then m.max = d; m.maxJob = A.currentJob end
        m.frames = (m.frames or 0) + 1
        -- T126 (Entscheid Supervisor 17.11.): die drei längsten Bilder merken (absteigend) - bewertet wird der mittlere davon
        local top = m.top or {}
        m.top = top
        if #top < 3 or d > top[#top] then
            top[#top + 1] = d
            table.sort(top, function(x, y) return x > y end)
            if #top > 3 then top[4] = nil end
        end
        -- Punkt 4: Bilder über der Grenze mit Speicherbereinigung getrennt zählen (Ursache im Bericht, Verdacht zu messen)
        if d > (A.FRAME_BUDGET or 6) + 2 then
            m.over = (m.over or 0) + 1
            if gcFrame then m.overGC = (m.overGC or 0) + 1 end
        end
        -- W3 (Befund 10.11. 13:50): je Aufgabe getrennt, damit eine Prüfung nur ihre eigene Aufgabe bewertet
        m.jobs = m.jobs or {}
        local key = tostring(A.currentJob)
        if d > (m.jobs[key] or 0) then m.jobs[key] = d end
    end
    -- Diagnose-Protokoll: ein Frame Hintergrund-Arbeit über 16 ms
    -- F3: dazu die Schritte (A:Pause-Aufrufe) dieses Frames - 0 oder 1 Schritt bei hoher Zeit = Schleife ohne Pause
    local ls = A.longStep
    if m and ls then
        m.steps = m.steps or {}
        local key = tostring(ls.job)
        if not m.steps[key] or ls.ms > m.steps[key].ms then m.steps[key] = { ms = ls.ms, at = ls.at, gc = ls.gc } end
    end
    if A.Diag and d > A.Diag.SLOW_MS then
        pcall(A.Diag.Add, A.Diag, "LANGSAM", "Hintergrund-Aufgabe " .. tostring(A.currentJob) .. " · " .. tostring(A.jobPortion or 0) .. " Schritte"
            .. (ls and string.format(" · längster Schritt %.0f ms bis %s", ls.ms, tostring(ls.at)) or "")
            .. ((gcFrame or (ls and ls.gc)) and " · mit Speicherbereinigung" or "")
            .. ((ls and ls.gc and ls.base) and string.format(" (davon Bereinigung ~%.0f ms, Schritt sonst ~%.1f ms)", math.max(0, ls.ms - ls.base), ls.base) or ""), d)
    end
    -- TB125-1: letzter Frame der Hintergrund-Aufgaben (für die Ursache einer Vollscan-Lücke), Tabelle wiederverwendet
    local lf = A.lastJobFrame
    if not lf then lf = {}; A.lastJobFrame = lf end
    lf.t, lf.d, lf.job, lf.at, lf.ms, lf.n = GetTime(), d, A.currentJob, ls and ls.at or nil, ls and ls.ms or nil, A.jobPortion or 0
    A.jobPortion = 0
    A.longStep = nil
end)
local jobKeyCache = setmetatable({}, { __mode = "k" })
RunJobs = function()
    jobStart = Clock and Clock() or 0
    jobMem0 = collectgarbage("count")
    pauseCount = 0
    local ran = false                       -- GSL2-3: false = in diesem Frame nur aufgeschobene Aufgaben
    if next(A.quietPaused) then wipe(A.quietPaused) end
    while #A.jobs > 0 do
        -- GSL2-3: aufschiebbare Aufgaben beim Snipen überspringen (Reihenfolge der übrigen bleibt)
        local idx = 1
        while A.jobs[idx] and (A:SnipeDefer(A.jobs[idx]) or A:ScanDefer(A.jobs[idx])) do idx = idx + 1 end
        if not A.jobs[idx] then A.snipeDeferred = A.snipeDeferred + 1; return ran end
        if idx > 1 then table.insert(A.jobs, 1, table.remove(A.jobs, idx)); A.snipeDeferred = A.snipeDeferred + 1 end
        local j = A.jobs[1]
        ran = true
        j.started = true
        A.currentJob = j.name
        A.curBudget = j.budget
        A.yieldOK = true
        -- T647 (Ursache belegt 16.11.): ein Schritt beginnt beim Fortsetzen DIESER Aufgabe. Vorher zählte der erste Schritt einer
        -- Aufgabe, die im selben Bild nach einer anderen lief, ab der letzten Pause der anderen (Schluss-Stück + Wechsel) -
        -- gemessen wurden "9,1 ms bis Extras.lua:279", obwohl ein Schritt dort höchstens 0,6 ms braucht.
        if Clock then lastPauseT = Clock(); lastPauseMem = collectgarbage("count") end
        local kbJ0 = A.frameOwn and collectgarbage("count")
        local ok, err = coroutine.resume(j.co)
        A.yieldOK = false
        -- VS-JOBKB (Ingametest 18.11. 14:40, T459 Spiel 27 MB / Nachbau 13 MB): eigener neuer Speicher JE AUFGABE während einer
        -- Vollscan-Messung (Bilder mit Bereinigung nicht zählbar) - zeigt, welche Aufgaben im Spiel mitlaufen (Oberfläche, Heute tun …)
        if kbJ0 and A.frameOwn then                 -- SN-EIGEN: die Zählung kann in der Aufgabe enden (Sniper-Beobachtung)
            local fo = A.frameOwn
            local dk = collectgarbage("count") - kbJ0
            local key = jobKeyCache[j.name]
            if not key then key = tostring(j.name):gsub(":%d+$", ""); jobKeyCache[j.name] = key end   -- ohne neue Zeichenkette je Bild
            if dk >= 0 then fo.byJob = fo.byJob or {}; fo.byJob[key] = (fo.byJob[key] or 0) + dk end
        end
        -- T373: Schluss-Stück einer Aufgabe (nach der letzten Pause bis zum Ende) zählt auch als Schritt
        if Clock and coroutine.status(j.co) == "dead" then
            local tail = Clock() - math.max(lastPauseT, jobStart)
            if tail > A.LONG_STEP_MS then NoteLongStep(tail, "Ende " .. tostring(j.name)) end
        end
        if not ok then
            table.remove(A.jobs, 1)
            A:Print(L["Fehler bei "] .. tostring(j.name) .. ": " .. tostring(err))
            A:ReportError("Job:" .. tostring(j.name), err)
        elseif coroutine.status(j.co) == "dead" then
            table.remove(A.jobs, 1)
        else
            return          -- Budget aufgebraucht: im nächsten Frame weiter
        end
        if Clock and Clock() - jobStart >= (j.budget or A.FRAME_BUDGET) then A.curBudget = nil; return end
        A.curBudget = nil
    end
end

-- ------------------------------------------------------------
-- Hilfsfunktionen
-- ------------------------------------------------------------
-- Tagesbeginn (00:00 Ortszeit) eines Zeitpunkts - ohne time(tabelle): Befund 20:15 (A1), time({ ... }) gibt im Client
-- für Zeiten vor 1970 (z. B. Zeitraum "alles" = 0) nil zurück. Immer eine Zahl.
-- VS-EIGEN (Nachbau 18.11. mit echten Daten, 2. Vollscan: 42,6 MB neuer Speicher in "Verfolgung V4" durch 63 017 Aufrufe -
-- date("*t") legt je Aufruf eine Tabelle an): Tagesbeginn je Viertelstunde (UTC) zwischenspeichern. Zeitzonen und Sommerzeit-
-- Wechsel liegen auf Vielfachen von 15 Minuten, Mitternacht also nie IN einer Viertelstunde -> gleicher Tagesbeginn für die ganze
-- Viertelstunde (exakt, nicht genähert). Höchstens 4096 Einträge (dann neu), nur Zahlen.
local dayCache, dayCacheN = {}, 0
function A:DayStart(t)
    t = tonumber(t) or time()
    if t < 2 * 86400 then return 0 end
    local b = math.floor(t / 900)
    local ds = dayCache[b]
    if ds then return ds end
    local t0 = b * 900
    local ok, d = pcall(date, "*t", t0)
    if ok and type(d) == "table" and d.hour and d.min and d.sec then
        ds = t0 - (d.hour * 3600 + d.min * 60 + d.sec)
    else
        return t - t % 86400
    end
    if dayCacheN >= 4096 then dayCache, dayCacheN = {}, 0 end
    dayCache[b], dayCacheN = ds, dayCacheN + 1
    return ds
end
function A:DayStartUncached(t)                     -- Testnaht (T911): die Rechnung ohne Zwischenspeicher
    t = tonumber(t) or time()
    if t < 2 * 86400 then return 0 end
    local ok, d = pcall(date, "*t", t)
    if ok and type(d) == "table" and d.hour and d.min and d.sec then
        return t - (d.hour * 3600 + d.min * 60 + d.sec)
    end
    return t - t % 86400
end

local function DeepCopy(t)
    if type(t) ~= "table" then return t end
    local c = {}
    for k, v in pairs(t) do c[k] = DeepCopy(v) end
    return c
end

local function FillDefaults(target, source)
    for k, v in pairs(source) do
        if target[k] == nil then
            target[k] = DeepCopy(v)
        elseif type(v) == "table" and type(target[k]) == "table" then
            FillDefaults(target[k], v)
        end
    end
end

function A:CountTable(t)
    local n = 0
    if type(t) == "table" then
        for _ in pairs(t) do n = n + 1 end
    end
    return n
end

-- ------------------------------------------------------------
-- WoW-Währung: Gold, Silber, Kupfer
-- 1 Gold = 100 Silber, 1 Silber = 100 Kupfer. Intern wird immer in Kupfer gerechnet.
-- Anzeige wahlweise mit den WoW-Münzsymbolen (Standard) oder mit Buchstaben.
-- ------------------------------------------------------------
local COIN_ICONS = {
    "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t",
    "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t",
    "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
}
local COIN_COLORS = { "ffd700", "c7c7cf", "eda55f" }

-- Kurzzeichen für Gold / Silber / Kupfer je Sprache des Addons
A.COIN_LETTERS = {
    deDE = { "g", "s", "c" },  enUS = { "g", "s", "c" },  frFR = { "po", "pa", "pc" },
    esES = { "o", "p", "c" },  esMX = { "o", "p", "c" },  ptBR = { "o", "p", "c" },
    itIT = { "o", "a", "r" },  ruRU = { "з", "с", "м" },  koKR = { "골", "실", "코" },
    zhCN = { "金", "银", "铜" }, zhTW = { "金", "銀", "銅" },
}

-- Eingabe: alle Kurzzeichen aller Sprachen -> 1 (Gold), 2 (Silber), 3 (Kupfer)
local UNIT_INDEX = {}
for _, letters in pairs(A.COIN_LETTERS) do
    for i, u in ipairs(letters) do UNIT_INDEX[u] = i end
end
-- "k" = Kupfer aus älteren Eingaben (bis 0.65.10 schrieb das Addon auf Deutsch "78k")
for u, i in pairs({ gold = 1, silber = 2, silver = 2, kupfer = 3, copper = 3, ["с"] = 2, ["c"] = 3, k = 3,
                   ["골드"] = 1, ["실버"] = 2, ["코퍼"] = 3, ["金币"] = 1, ["银币"] = 2, ["铜币"] = 3,
                   ["金幣"] = 1, ["銀幣"] = 2, ["銅幣"] = 3 }) do UNIT_INDEX[u] = i end

function A:SplitMoney(copper)
    copper = math.floor(math.abs(copper or 0) + 0.5)
    return math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
end

function A:CoinUnit(i)
    if self.db and self.db.settings.moneyStyle == "letters" then
        local letters = self.COIN_LETTERS[self.uiLang or "enUS"] or self.COIN_LETTERS.enUS
        return letters[i], true
    end
    return COIN_ICONS[i], false
end

-- Kupfer -> "12 [Gold] 34 [Silber] 56 [Kupfer]"
-- compact = true für schmale Spalten: ab 100 Gold nur Gold, ab 1 Gold ohne Kupfer
function A:FormatMoney(copper, compact)
    if not copper then return "|cff888888-|r" end
    local negative = copper < 0
    local g, s, c = self:SplitMoney(copper)
    local show = { g > 0, s > 0, c > 0 }
    if compact then
        if g >= 100 then show = { true, false, false }
        elseif g > 0 then show = { true, s > 0, false } end
    end
    if not (show[1] or show[2] or show[3]) then show[3] = true end   -- 0 Kupfer
    -- TB192 (Nutzer 14:39: "2g 64c" für 2g00s64 liest sich wie 2g64): lückenlos ab der grössten Stelle - Gold und Kupfer
    -- sichtbar, Silber 0 -> "00"
    local values = { g, s, c }
    if show[1] and show[3] and not show[2] then show[2], values[2] = true, "00" end
    local parts = {}
    for i = 1, 3 do
        if show[i] then
            local unit, isLetter = self:CoinUnit(i)
            if isLetter then
                table.insert(parts, "|cff" .. COIN_COLORS[i] .. values[i] .. unit .. "|r")
            else
                table.insert(parts, values[i] .. unit)
            end
        end
    end
    local text = table.concat(parts, " ")
    if negative then text = "-" .. text end
    return text
end

-- Text ohne Farben und Symbole (Münzsymbole werden zu g/s/c) - für Berichte und schmale Spalten
function A:PlainText(text)
    if type(text) ~= "string" then return text end
    local letters = self.COIN_LETTERS[self.uiLang or "enUS"] or self.COIN_LETTERS.enUS
    for i = 1, 3 do
        local icon = COIN_ICONS[i]
        local a, b = 1, nil
        while true do
            a, b = text:find(icon, 1, true)
            if not a then break end
            text = text:sub(1, a - 1) .. letters[i] .. text:sub(b + 1)
        end
    end
    text = text:gsub("|T.-|t", ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    return text
end

-- Kupfer -> Text zum Eintippen/Bearbeiten ("12g 50s 3c", ohne Farben). In allen Sprachen g/s/c, nie "k"
-- ("78k" wurde als 78 000 gelesen). Eingaben in jeder Sprache versteht ParseGold weiter.
A.INPUT_LETTERS = { "g", "s", "c" }
function A:FormatMoneyInput(copper)
    if not copper or copper <= 0 then return "" end
    local letters = self.INPUT_LETTERS
    local g, s, c = self:SplitMoney(copper)
    local parts = {}
    if g > 0 then table.insert(parts, g .. letters[1]) end
    if s > 0 then table.insert(parts, s .. letters[2]) end
    if c > 0 then table.insert(parts, c .. letters[3]) end
    return table.concat(parts, " ")
end

-- frühere Kurzform (z.B. "12.34g") -> jetzt ebenfalls Gold/Silber/Kupfer, kompakt
function A:FormatGoldShort(copper)
    if not copper then return "-" end
    return self:FormatMoney(copper, true)
end

-- Text -> Kupfer. Versteht:
--   "12.5" / "12,5"         = Gold mit Nachkommastellen
--   "12g 50s 3c", "12g50s"  = Gold, Silber, Kupfer (Kurzzeichen jeder Sprache: g/s/c, po/pa/pc, з/с/м, 金/银/铜 ...)
function A:ParseGold(text)
    if not text then return nil end
    text = string.lower(tostring(text)):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    text = text:gsub("|t[^|]*|t", ""):gsub("%s+", " ")
    if text:match("^%s*$") then return nil end
    local total, units, plain = 0, 0, nil
    for num, unit in text:gmatch("([%d%.,]+)%s*([^%d%s%.,]*)") do
        local n = tonumber((num:gsub(",", ".")))
        if not n then return nil end
        if unit == "" then
            if plain or units > 0 then return nil end
            plain = n
        else
            local i = UNIT_INDEX[unit]
            if not i then return nil end
            total = total + n * ({ 10000, 100, 1 })[i]
            units = units + 1
        end
    end
    if plain and units > 0 then return nil end
    if plain then total = plain * 10000 end
    total = math.floor(total + 0.5)
    if total <= 0 then return nil end
    return total
end

-- SN-EIN1 (Entscheid des Nutzers 15:45, Gold-Sicherheit): Zahl ohne Einheit je nach Feld. plain = "copper" (Höchstpreise
-- beim Kaufen: "22" = 22c), "gold" (Budget: "6" = 6g, wie ParseGold), "none" (Preise beim Verkaufen: ohne Einheit nicht
-- deuten -> nil, zweiter Wert "einheit"). Mit Einheit überall gleich. ParseGold bleibt für alte Aufrufer unverändert.
function A:ParseMoney(text, plain)
    if not text then return nil end
    local t = string.lower(tostring(text)):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|t[^|]*|t", "")
    local hasUnit = t:find("[^%d%s%.,]") ~= nil
    if hasUnit or plain == nil or plain == "gold" then return self:ParseGold(text) end
    if t:match("^%s*$") then return nil end
    if plain == "none" then return nil, "einheit" end
    local n = tonumber((t:gsub("%s+", ""):gsub(",", ".")))
    if not n or n <= 0 then return nil end
    return math.floor(n + 0.5)
end

-- Zeitdifferenz lesbar
function A:FormatAgo(timestamp)
    if not timestamp or timestamp == 0 then return L["nie"] end
    local diff = time() - timestamp
    if diff < 60 then return string.format(L["vor %d Sek."], diff) end
    if diff < 3600 then return string.format(L["vor %d Min."], math.floor(diff / 60)) end
    if diff < 86400 then return string.format(L["vor %d Std."], math.floor(diff / 3600)) end
    return string.format(L["vor %d Tagen"], math.floor(diff / 86400))
end

function A:FormatDuration(seconds)
    seconds = math.max(0, math.floor(seconds or 0))
    return string.format("%d:%02d", math.floor(seconds / 60), seconds % 60)
end

-- Prozentwert farbig
function A:FormatPercent(value)
    if not value then return "|cff666666-|r" end
    if value > 0.05 then
        return string.format("|cff33dd55+%.1f%%|r", value)
    elseif value < -0.05 then
        return string.format("|cffff5544%.1f%%|r", value)
    end
    return "|cffaaaaaa0.0%|r"
end

-- ------------------------------------------------------------
-- Datenbank
-- ------------------------------------------------------------
local DEFAULTS = {
    dbVersion = 4,
    marketData = {},      -- [itemID] = { name, history = { {t, p, q}, ... } }
    watchlist = {},       -- [itemID] = { name, buyBelow, sellAbove, added }
    scanLog = {},         -- letzte Scans { t, items, duration }
    lastScanTime = 0,     -- time() des letzten Scan-Starts
    totalScans = 0,
    lastOwnScan = nil,    -- { t, data = { [itemID] = { price, qty } } }
    markets = {},         -- [Server|Fraktion] = { data, own, recv, mixed } (Preise je Auktionshaus, 0.65.30)
    names = {},           -- [Sprache][itemID] = Item-Name (alle WoW-Sprachen)
    namesSent = {},       -- [itemID] = zuletzt geteilt (time())
    vendorPrices = {},    -- [itemID] = Händlerpreis pro Stück in Kupfer (0 = nicht verkaufbar)
    vendorBuy = {},       -- [itemID] = was ein Händler pro Stück VERLANGT (beim Händler gelesen)
    vendorCost = {},      -- [itemID] = { gold, qty, costs = { { kind, id, name, amount } }, t } (Händler-Artikel gegen Währung)
    deStats = {},         -- [Gruppe] = { n = Entzauberungen, mats = { [itemID] = { times, total } } } (gelernt)
    deShared = {},        -- [Kürzel "#..."] = { t, g = { [Gruppe] = { n, mats } } } (von anderen geteilt, keine Namen)
    chars = {},           -- [Name-Realm] = { name, realm, class, money, gold = { {t, m} }, bags, bank }
    sync = {
        enabled = true,
        received = 0,     -- empfangene Preise gesamt
        lastReceived = 0,
        peers = {},       -- [Kürzel] = zuletzt gehört (time()), keine Namen
    },
    settings = {
        buttonPos = nil,
        windowPos = nil,
        alertSound = true,
        minQuantityForTrends = 1,
        theme = "classic",        -- "classic" (wie das Auktionshaus) oder "modern"
        scale = 1,                -- Fenstergröße
        helpSeen = false,         -- Willkommens-Hilfe schon gezeigt
        lastTab = nil,            -- zuletzt geöffneter Reiter
        sniperFilters = false,    -- Sniper-Filter aufgeklappt
        ahIntegration = false,    -- false = eigenes Fenster (Standard), true = im Auktionshaus-Fenster
        tooltipInfo = true,       -- Preis, Ø 7 Tage und Trend im Item-Tooltip
        tooltipChartDays = 7,     -- Preisdiagramm unter dem Item-Tooltip (0 = aus, 1 / 7 / 30 Tage)
        tooltipVendor = true,     -- Händlerpreis im Item-Tooltip
        craftPanel = true,        -- Gewinn-Fenster neben dem Berufsfenster
        tooltipChars = true,      -- Bestand deiner Twinks im Item-Tooltip
        tooltipDE = true,         -- Entzauberungswert im Item-Tooltip
        tooltipDEMode = "mats",   -- Entzaubern im Tooltip: "short" / "mats" (Standard) / "all"
        openWithAH = true,        -- Hauptfenster mit dem Auktionshaus öffnen und schliessen
        mailButtons = true,       -- Knöpfe "AH-Post abholen" am Briefkasten
        chartEMA = true,          -- EMA-Linien im Tab Charts
        ahSize = nil,             -- gemessene Größe des Auktionshaus-Fensters { w, h }
        moneyStyle = "icons",     -- Geldanzeige: "icons" (Münzsymbole) oder "letters" (g/s/c ...)
        nameLocale = "auto",      -- Sprache der angezeigten Item-Namen ("auto" = wie der Client)
        nameLocaleChosen = false, -- true, sobald der Spieler selbst eine Sprache gewählt hat
        uiLanguage = "auto",      -- Sprache des Addons ("auto" = wie der Client, sonst "deDE"/"enUS")
    },
    lists = {
        items = {},               -- [Name] = { created, entries = { [itemID] = { qty, added } } }
        tolerance = 100,          -- Max-Preis der Sniper-Ziele aus einer Liste: % vom Marktwert
    },
    ledger = {
        entries = {},             -- Buchungen { t, kind = "sale"/"buy"/"deposit", itemID, name, qty, amount, cut, refund, player, src }
        seen = {},                -- [Schlüssel] = Zeit: schon gebuchte Rechnungen aus dem Briefkasten
        period = "7",             -- zuletzt gewählter Zeitraum
    },
    seller = {
        undercut = "copper",      -- unterbieten um: "copper" (1 Kupfer), "p1" (1 %), "p5" (5 %)
        duration = 2,             -- zuletzt gewählte Dauer (1 kurz, 2 mittel, 3 lang)
        items = {},               -- [itemID] = { price, duration, qty } zuletzt benutzt
    },
    watcher = {
        enabled = false,          -- Schnäppchen-Wächter an/aus
        threshold = 50,           -- Treffer, wenn Preis <= x % vom Marktwert
        minValue = 10,            -- nur Waren mit Marktwert ab x Kupfer pro Stück
        budget = 500000,          -- höchstens so viel Kupfer pro Schnäppchen (50 Gold)
        interval = 20,            -- Sekunden zwischen zwei Runden
        mode = "combined",        -- "combined" = alle Kategorien in einer Suche, "single" = einzeln
        cats = {                  -- Kategorien (nur Handwerkswaren, keine Ausrüstung)
            herb = true, metal = true, cloth = true, leather = true, enchanting = true,
            elemental = true, gems = true, cooking = true, consumable = false,
        },
        found = 0,                -- bestätigte Schnäppchen gesamt
    },
    sniper = {
        targets = {},                                 -- [key] = Ziel (Item oder Suchbegriff, Preis, Menge, Budget, Filter)
        binds = { "MOUSEWHEELUP", "MOUSEWHEELDOWN" }, -- Kauf-Auslöser im Sniper-Modus
        armed = false,                                -- Sniper-Modus an/aus
        interval = 0,                                 -- Sekunden zwischen zwei Suchen (0 = so oft der Server erlaubt)
        instantBuy = true,                            -- Waren mit EINER Raste kaufen (Preis wird vorab geholt)
        imported = false,                             -- alte Watchlist-Ziele übernommen
    },
}
A.DEFAULTS = DEFAULTS     -- nur lesen (Diagnose-Protokoll: geänderte Einstellungen)

-- Alte Daten (Version 3.x) so weit wie möglich übernehmen
local function MigrateOldMarketData(old)
    local new = {}
    if type(old) ~= "table" then return new end
    for itemID, entry in pairs(old) do
        local id = tonumber(itemID)
        if id and type(entry) == "table" and type(entry.history) == "table" then
            local hist = {}
            for _, h in ipairs(entry.history) do
                if type(h) == "table" and h.price and (h.time or h.timestamp) then
                    table.insert(hist, { t = h.time or h.timestamp, p = h.price, q = h.quantity or h.qty or 0 })
                end
            end
            if #hist > 0 then
                table.sort(hist, function(a, b) return a.t < b.t end)
                new[id] = { name = entry.name, history = hist }
            end
        end
    end
    return new
end

-- Beschädigte Einträge entfernen (z. B. nach einem Absturz beim Speichern), damit kein Reiter und kein Tooltip
-- an einem einzelnen kaputten Wert scheitert. Gesunde Daten bleiben unverändert. Liefert die Zahl der Reparaturen.
-- Preisverläufe: nur erster und letzter Eintrag werden geprüft (schnell beim Einloggen); ist einer kaputt, wird
-- der ganze Verlauf dieses Items gefiltert.
function A:RepairDB(db)
    if type(db) ~= "table" then return 0 end
    local n = 0
    local function okPoint(e) return type(e) == "table" and type(e.t) == "number" and type(e.p) == "number" end
    if type(db.marketData) ~= "table" then db.marketData = {}; n = n + 1 end
    -- keine Namen speichern (0.65.26): Absender geteilter Entzauberungen und Sync-Mitspieler nur als Kürzel
    if type(db.sync) == "table" and type(db.sync.peers) == "table" then
        for k in pairs(db.sync.peers) do if type(k) ~= "string" or k:sub(1, 1) ~= "#" then db.sync.peers[k] = nil end end
    end
    if A.Disenchant and A.Disenchant.MigrateShared then pcall(A.Disenchant.MigrateShared, A.Disenchant, db.deShared) end
    db.depositLog, db.depositHistory = nil, nil   -- Messung der Einstellgebühr (0.65.17-0.65.20), gestrichen mit der Regel vom 9. Nov.
    for id, e in pairs(db.marketData) do
        if type(e) ~= "table" then
            db.marketData[id] = nil; n = n + 1
        elseif type(e.history) ~= "table" then
            if type(e.hf) ~= "table" then e.history = {}; n = n + 1 end      -- RF-M1: flache Liste zählt als Verlauf
        else
            local h = e.history
            if #h > 0 and not (okPoint(h[1]) and okPoint(h[#h])) then
                local keep = {}
                for _, x in ipairs(h) do if okPoint(x) then keep[#keep + 1] = x end end
                e.history = keep; n = n + 1
            end
        end
    end
    local function onlyTables(t)
        if type(t) ~= "table" then return end
        for k, v in pairs(t) do if type(v) ~= "table" then t[k] = nil; n = n + 1 end end
    end
    onlyTables(db.chars)
    onlyTables(db.vendorCost)
    if type(db.sniper) == "table" then onlyTables(db.sniper.targets) end
    if type(db.lists) == "table" then onlyTables(db.lists.items) end
    if type(db.ledger) == "table" and type(db.ledger.entries) == "table" then
        local keep = {}
        for _, e in ipairs(db.ledger.entries) do if type(e) == "table" then keep[#keep + 1] = e else n = n + 1 end end
        if #keep ~= #db.ledger.entries then db.ledger.entries = keep end
    end
    if db.recipes ~= nil and type(db.recipes) ~= "table" then db.recipes = {}; n = n + 1 end
    if type(db.recipes) == "table" then onlyTables(db.recipes) end
    if db.settings and db.settings.lastSub ~= nil and type(db.settings.lastSub) ~= "table" then db.settings.lastSub = nil; n = n + 1 end
    return n
end

-- MN1/MN2: GoldSentinelMarkt (shared/, byte-gleich) - Anmeldung und Schalter "Marktdaten teilen" (Standard an)
function A:MarketNet() local G = _G.GoldSentinelMarkt; return type(G) == "table" and G or nil end
function A:AttachMarketNet()
    local G = self:MarketNet()
    if not (G and G.Attach and type(AHSentinelDB) == "table") then return false end
    G.Attach("AHSentinel", AHSentinelDB)
    return true
end
function A:MarketShareOn()
    local G = self:MarketNet()
    local db = G and G.hosts and G.hosts.AHSentinel
    return (type(db) == "table" and not db.gsMarktAus) and true or false
end
function A:SetMarketShare(on)
    local G = self:MarketNet()
    if not (G and G.SetShare) then return false end
    G.SetShare("AHSentinel", on and true or false)
    return true
end
-- MN3: Testbericht-Zeile "MARKT-NETZ" (Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher)
function A:MarketNetLine()
    local G = self:MarketNet()
    if not G then return "MARKT-NETZ: Datei fehlt (aus)" end
    local st = (G.Stats and G.Stats()) or {}
    local kb = 0
    local g = type(AHSentinelDB) == "table" and AHSentinelDB.gsMarkt
    if type(g) == "table" then
        for _, f in pairs(g.f or {}) do for _, v in pairs(type(f) == "table" and f.i or {}) do kb = kb + #tostring(v) + 12 end end
        for _, line in ipairs(g.export or {}) do kb = kb + #tostring(line) end
    end
    return string.format("MARKT-NETZ: Version %s · %s · Vollscans mitgelesen %d · weitergegeben (Feed) %d · Vergleiche %d · gesendet %d · empfangen %d (angenommen %d) · Speicher ~%d KB",
        tostring(G.VERSION or "?"), self:MarketShareOn() and "an" or "aus", st.scans or 0, st.fed or 0, st.compared or 0,
        st.sent or 0, st.received or 0, st.accepted or 0, math.floor(kb / 1024 + 0.5))
end

function A:InitDB()
    -- Umbenennung AH Analyzer Pro -> AHSentinel (0.62.0): die alten Daten liegen in AHAnalyzerProDB,
    -- geladen vom Übergangs-Ordner "AHAnalyzerPro". Einmal übernehmen, dort nur einen Vermerk lassen.
    if type(AHSentinelDB) ~= "table" and type(AHAnalyzerProDB) == "table" and not AHAnalyzerProDB.migratedTo
        and AHAnalyzerProDB.marketData then
        AHSentinelDB = AHAnalyzerProDB
        AHAnalyzerProDB = { migratedTo = "AHSentinel", time = time() }
        self.migratedFromOld = true
    end
    if type(AHSentinelDB) ~= "table" then
        AHSentinelDB = DeepCopy(DEFAULTS)
    elseif AHSentinelDB.dbVersion ~= self.DB_VERSION then
        local old = AHSentinelDB
        AHSentinelDB = DeepCopy(DEFAULTS)
        AHSentinelDB.marketData = MigrateOldMarketData(old.marketData)
        if type(old.settings) == "table" then
            AHSentinelDB.settings.windowPos = nil
        end
        self:Print(L["Datenbank auf Version 4 umgestellt."])
    end
    FillDefaults(AHSentinelDB, DEFAULTS)
    self.repairedDB = self:RepairDB(AHSentinelDB)
    -- Vorsichtshalber: Cooldown-Zeit muss eine time()-Zeit sein, keine GetTime()-Zeit
    if (AHSentinelDB.lastScanTime or 0) > time() + 60 then
        AHSentinelDB.lastScanTime = 0
    end
    self.db = AHSentinelDB
    self:DevRefresh()                    -- TEST-DEV1: Entwickler-Modus (Schalter, kontoweit)
    -- 0.59.27: Addon-Fenster ist standardmäßig vom Auktionshaus gelöst (eigenes, frei vergrößerbares Fenster)
    if not self.db.settings.detachedWindow then
        self.db.settings.ahIntegration = false
        self.db.settings.detachedWindow = true
    end
    -- 0.59.20: Sniper sucht standardmäßig so oft wie möglich (alter Standard 3 Sek.)
    local sn = self.db.sniper
    if sn and not sn.fastSearch then
        if sn.interval == 3 then sn.interval = 0 end
        sn.fastSearch = true
    end
    -- Item-Namen folgen der Client-Sprache, solange der Spieler nichts anderes gewählt hat
    if not self.db.settings.nameLocaleChosen then self.db.settings.nameLocale = "auto" end
    self:ApplyUILanguage()
    -- Fehler des Addons auch im normalen Spiel zählen (GoldSentinelTest.lua). Nach jedem InitDB neu, weil
    -- InitDB AHSentinelDB durch eine neue Tabelle ersetzen kann (Migration).
    local GT = _G.GoldSentinelTest
    if GT and GT.TrackErrors then pcall(GT.TrackErrors, "AHSentinel", self.version, self.db) end
end

-- ------------------------------------------------------------
-- Item-Infos
-- ------------------------------------------------------------
-- Name in der Sprache deines WoW-Clients (für die Suche im Auktionshaus)
-- GSL8-1 (Protokoll 8: nach dem Vollscan 2 800–9 300 GET_ITEM_INFO_RECEIVED je 2 s, Bilder bis 446 ms): GetItemInfo für ein
-- Item, das der Client noch nicht kennt, schickt eine Anfrage an den Server. Höchstens ITEM_REQ_PER_S solche neuen Anfragen je
-- Sekunde (über alle Aufgaben); darüber liefert der Aufrufer für dieses Mal nichts (eingebaute Namen / später). Bekannte Items
-- sind nie begrenzt. Zähler je Aufgabe (A.currentJob) für den Beleg im Diagnose-Protokoll (ITEMINFO, höchstens 1× je Minute).
A.ITEM_REQ_PER_S = 200
A.itemReq = { win = 0, n = 0, sent = 0, deferred = 0, byJob = {}, logT = 0 }
function A:ItemInfoAllowed(itemID)
    local C = _G.C_Item
    if not (C and C.IsItemDataCachedByID) or type(itemID) ~= "number" then return true end
    local ok, cached = pcall(C.IsItemDataCachedByID, itemID)
    if not ok or cached ~= false then return true end
    local r = self.itemReq
    local now = GetTime()
    if now - r.win >= 1 then r.win, r.n = now, 0 end
    local job = self.currentJob or "-"
    if r.n >= self.ITEM_REQ_PER_S then
        r.deferred = r.deferred + 1
        return false
    end
    r.n, r.sent = r.n + 1, r.sent + 1
    r.byJob[job] = (r.byJob[job] or 0) + 1
    if self.Diag and now - r.logT >= 60 and r.sent >= 200 then
        r.logT = now
        local parts = {}
        for k, v in pairs(r.byJob) do parts[#parts + 1] = k .. " " .. v end
        table.sort(parts)
        pcall(self.Diag.Add, self.Diag, "ITEMINFO", string.format("neue Item-Anfragen %d (zurückgestellt %d) · je Aufgabe: %s", r.sent, r.deferred, table.concat(parts, ", "):sub(1, 180)))
    end
    return true
end
function A:GetClientItemName(itemID)
    local entry = self.db and self.db.marketData[itemID]
    if entry and entry.name and not entry.name:find("^Item #") then
        return entry.name
    end
    local name = GetItemInfo and self:ItemInfoAllowed(itemID) and GetItemInfo(itemID)       -- GSL8-1
    if name then
        if entry then entry.name = name end
        if self.Names then self.Names:Learn(itemID, name) end
        return name
    end
    -- Client kennt das Item (noch) nicht: im Hintergrund nachladen (Retail), dann erscheint der Name beim nächsten Aufbau
    self:QueueItemLoad(itemID)
    -- eingebaute Namensliste in der Client-Sprache
    local builtin = self.Names and self.Names:BuiltinGet(itemID, self.Names:ClientLocale())
    if builtin then return builtin end
    return (entry and entry.name) or ("Item #" .. tostring(itemID))
end

-- ------------------------------------------------------------
-- Retail (12.x): Item-Daten kennt der Client erst nach einer Anfrage beim Server.
-- Der Komplett-Scan liefert nur Item-IDs - ohne Nachladen stünde überall "Item #12345".
-- Gedrosselt nachladen (40 pro Sekunde), damit der Server nicht überlastet wird.
-- Classic braucht das nicht: dort lädt GetItemInfo selbst nach.
-- ------------------------------------------------------------
local LOAD_PER_TICK, LOAD_TICK = 10, 0.25
local loadQueue, loadQueued, loadHead, loadFrame = {}, {}, 1, nil
local NEED_LOAD = (_G.GetItemInfo == nil) and C_Item ~= nil and C_Item.RequestLoadItemDataByID ~= nil
A.NEED_ITEM_LOAD = NEED_LOAD

function A:QueueItemLoad(itemID)
    if not NEED_LOAD or type(itemID) ~= "number" or itemID <= 0 or loadQueued[itemID] then return end
    loadQueued[itemID] = true
    loadQueue[#loadQueue + 1] = itemID
    if not loadFrame then
        loadFrame = CreateFrame("Frame")
        local acc = 0
        loadFrame:SetScript("OnUpdate", function(f, dt)
            acc = acc + (dt or 0)
            if acc < LOAD_TICK then return end
            acc = 0
            for _ = 1, LOAD_PER_TICK do
                local id = loadQueue[loadHead]
                if not id then
                    wipe(loadQueue); loadHead = 1
                    f:Hide()
                    return
                end
                loadQueue[loadHead] = nil
                loadHead = loadHead + 1
                pcall(C_Item.RequestLoadItemDataByID, id)
            end
        end)
    end
    loadFrame:Show()
end

-- noch offene Nachlade-Anfragen (für Selbsttest/Diagnose)
function A:PendingItemLoads()
    return math.max(0, #loadQueue - loadHead + 1)
end

-- Name in der gewählten Anzeigesprache (Standard Englisch).
-- Unbekannt in dieser Sprache -> Name aus dem eigenen Client.
function A:GetItemName(itemID)
    local N = self.Names
    if N and self.db then
        local loc = N:DisplayLocale()
        if loc ~= N:ClientLocale() then
            local nm = N:Get(itemID, loc)
            if nm then return nm end
        end
    end
    local nm = self:GetClientItemName(itemID)
    -- Chinesische Schrift hat keine Umlaute: fehlt der Name in der Sprache, lesbar umschreiben (ö -> oe)
    if nm and (self.uiLang == "zhCN" or self.uiLang == "zhTW") and nm:find("[\195]") then
        nm = self:Transliterate(nm)
    end
    return nm
end

local TRANSLIT = {
    ["ä"] = "ae", ["ö"] = "oe", ["ü"] = "ue", ["Ä"] = "Ae", ["Ö"] = "Oe", ["Ü"] = "Ue", ["ß"] = "ss",
    ["é"] = "e", ["è"] = "e", ["ê"] = "e", ["à"] = "a", ["â"] = "a", ["ç"] = "c", ["î"] = "i", ["ï"] = "i",
    ["ô"] = "o", ["û"] = "u", ["ù"] = "u", ["ñ"] = "n", ["á"] = "a", ["í"] = "i", ["ó"] = "o", ["ú"] = "u",
    ["ã"] = "a", ["õ"] = "o", ["É"] = "E", ["À"] = "A", ["Ç"] = "C",
}
-- Latein-Sonderzeichen in einfache Buchstaben umschreiben (für Schriften ohne diese Zeichen)
function A:Transliterate(s)
    if type(s) ~= "string" then return s end
    return (s:gsub("\195[\128-\191]", function(c) return TRANSLIT[c] or c end))
end

function A:GetItemIcon(itemID)
    if GetItemIcon then
        local ok, icon = pcall(GetItemIcon, itemID)
        if ok and icon then return icon end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

-- Item per Name in den Marktdaten finden (exakt, sonst eindeutiger Teiltreffer)
-- Item per Name (jede Sprache), Item-ID oder Item-Link finden.
-- Rückgabe: itemID oder nil, Anzahl passender Items
function A:FindItemByName(text)
    if not text or text == "" or not self.db then return nil end
    if self.Names then return self.Names:Resolve(text) end
    return tonumber(text)
end

-- ------------------------------------------------------------
-- Gebote unter Wert: jedes Gebot, das irgendwo gelesen wird (Komplett-Scan im alten
-- Auktionshaus, Einzelsuchen im Einkauf/Sniper/Preisprüfung), wird gemerkt, wenn es
-- deutlich unter dem Marktwert liegt. Der Profit-Reiter zeigt sie ("Gebote unter Wert").
-- ------------------------------------------------------------
A.BID_PREFILTER = 0.7          -- nur merken, wenn das nächste Gebot <= 70 % des Marktwerts ist
A.BID_MAX = 600                -- höchstens so viele merken (älteste fliegen raus)

-- timeLeft: Restzeit in Sekunden (Obergrenze), mv: Marktwert pro Stück (optional, sonst berechnet)
function A:NoteBid(itemID, nextBid, qty, timeLeft, buyout, isMine, mv)
    if not (self.db and itemID and nextBid and nextBid > 0) or isMine then return false end
    qty = math.max(1, qty or 1)
    mv = mv or self:GetMarketValue(itemID)
    if not mv or mv <= 0 then return false end
    if nextBid / qty > mv * self.BID_PREFILTER then return false end
    local bids = self.db.bids
    if not bids then bids = {}; self.db.bids = bids end
    local now = time()
    local key = itemID .. ":" .. qty .. ":" .. (buyout or 0) .. ":" .. math.floor(timeLeft or 0) .. ":" .. nextBid
    local e = bids[key]
    if not e then
        e = {}
        bids[key] = e
        self.bidCount = (self.bidCount or 0) + 1
    end
    e.itemID, e.nextBid, e.qty, e.buyout = itemID, nextBid, qty, buyout
    e.seen = now
    e.endsBy = now + (timeLeft or 43200)
    -- bidCount fehlt, wenn die Gebote aus der gespeicherten Datei stammen: dann einmal zählen
    if not self.bidCount then self:PruneBids(false) end
    if (self.bidCount or 0) > (self.BID_MAX or 600) then self:PruneBids(true) end
    return true
end

function A:PruneBids(hard)
    local bids = self.db and self.db.bids
    if not bids then return end
    local now, n, list = time(), 0, {}
    for k, e in pairs(bids) do
        if (e.endsBy or 0) < now or now - (e.seen or 0) > 2 * 86400 then bids[k] = nil
        else n = n + 1; table.insert(list, { k = k, seen = e.seen or 0 }) end
    end
    if hard and n > self.BID_MAX then
        table.sort(list, function(a, b) return a.seen < b.seen end)
        for i = 1, n - self.BID_MAX do bids[list[i].k] = nil end
        n = self.BID_MAX
    end
    self.bidCount = n
end

-- Gebote, die mindestens threshold % unter dem Marktwert liegen (noch nicht abgelaufen)
function A:GetBidDeals(threshold)
    self:PruneBids()
    local out = {}
    for _, e in pairs(self.db and self.db.bids or {}) do
        local mv = self:GetMarketValue(e.itemID)
        if mv and mv > 0 then
            local unit = e.nextBid / e.qty
            local discount = (mv - unit) / mv * 100
            if discount >= (threshold or 30) then
                table.insert(out, {
                    itemID = e.itemID, name = self:GetItemName(e.itemID), price = math.floor(unit + 0.5), ref = mv,
                    -- WoW Forever: die Einstellgebühr fürs Weiterverkaufen wird nie erstattet
                    discount = discount, profit = math.floor(self:NetSale(e.itemID, self:RealPrice(e.itemID, { noCurrent = true }) or mv, 1) - unit),
                    quantity = e.qty,
                    nextBid = e.nextBid, endsBy = e.endsBy, seen = e.seen, bidDeal = true,
                })
            end
        end
    end
    return out
end

-- ------------------------------------------------------------
-- Preisverlauf und Kennzahlen
-- ------------------------------------------------------------
-- fromSync = true: Preis kam von einem Mitspieler
-- Gibt true zurück, wenn ein neuer Eintrag entstanden ist
-- unverified = true: verdächtig billiger Waren-Preis (mögliches Lockangebot), zählt erst nach Bestätigung
function A:RecordPrice(itemID, price, quantity, timestamp, fromSync, unverified)
    -- VF4 (T21 "Marktwerte <= 0"): ein Preis von 0 oder weniger ist kein Preis (nil statt 0 speichern = gar nicht)
    if type(price) ~= "number" or price <= 0 then return nil end
    local db = self.db
    local entry = db.marketData[itemID]
    if not entry then
        entry = { hf = {} }
        db.marketData[itemID] = entry
    end
    if not entry.name or entry.name:find("^Item #") then
        entry.name = (GetItemInfo and GetItemInfo(itemID)) or entry.name or ("Item #" .. itemID)
        if entry.name:find("^Item #") then self:QueueItemLoad(itemID) end
    end

    local F = self:HistFlat(entry)                         -- RF-M1: flache Liste (5 Werte je Eintrag)
    local n = #F / 5
    -- Doppelte vermeiden: gibt es schon einen Eintrag innerhalb von 2 Minuten, nicht erneut speichern
    for i = n, 1, -1 do
        local ti = F[(i - 1) * 5 + 1]
        local d = ti - timestamp
        if d < 0 then d = -d end
        if d <= 120 then return false end
        if ti < timestamp - 120 then break end
    end

    local fl = (fromSync and 2 or 0) + (unverified and 1 or 0)
    self.priceVersion = (self.priceVersion or 0) + 1        -- Prüfsumme "Preise geändert" (Gewinn-Fenster, Punkt G)
    self:InvalidateMarket(itemID)
    if self.InvalidateLiquidity then self:InvalidateLiquidity(itemID) end

    -- zeitlich sortiert einfügen (Sync-Daten können älter sein als eigene)
    local pos = n + 1
    while pos > 1 and F[(pos - 2) * 5 + 1] > timestamp do pos = pos - 1 end
    for k = n * 5, (pos - 1) * 5 + 1, -1 do F[k + 5] = F[k] end
    local b = (pos - 1) * 5
    F[b + 1], F[b + 2], F[b + 3], F[b + 4], F[b + 5] = timestamp, price, quantity or 0, 0, fl
    n = n + 1

    -- vorne kürzen (zu alt oder zu viele)
    local cutoff = time() - self.HISTORY_DAYS * 86400
    local drop = 0
    while drop < n and (F[drop * 5 + 1] < cutoff or n - drop > self.MAX_HISTORY) do drop = drop + 1 end
    if drop > 0 then
        local m = (n - drop) * 5
        for k = 1, m do F[k] = F[k + drop * 5] end
        for k = n * 5, m + 1, -1 do F[k] = nil end
    end
    return true
end

-- PD7 (Befund PC-Daten 0.65.94): SavedVariables 21,7 MB, fast nur Preisverlauf. Verdichten statt alles behalten:
-- volle Auflösung 48 Std., danach 1 Wert je Stunde bis 7 Tage, danach 1 Wert je Tag bis 60 Tage, älter weg.
-- Items ohne neuen Eintrag seit 30 Tagen: nur Tageswerte. Ein verdichteter Wert = Median der bestätigten Preise des
-- Abschnitts (Menge: Median), Zeit = letzter Eintrag; nur unbestätigte im Abschnitt -> einer davon, weiter unbestätigt.
-- Der Rhythmus (A.Timing, JK2) hat seine Stunden-/Wochentagswerte schon beim Scan bekommen.
A.COMPACT_FULL = 48 * 3600
A.COMPACT_HOURLY = 7 * 86400
A.COMPACT_KEEP = 60 * 86400
A.COMPACT_IDLE = 30 * 86400
local function MedianOf(list)
    table.sort(list)
    local n = #list
    if n == 0 then return nil end
    if n % 2 == 1 then return list[(n + 1) / 2] end
    return math.floor((list[n / 2] + list[n / 2 + 1]) / 2 + 0.5)
end
function A:CompactHistory(h, now)
    if type(h) ~= "table" or #h < 2 then return h, 0 end
    now = now or time()
    local last = h[#h].t or 0
    local idle = now - last > self.COMPACT_IDLE
    local out, removed = {}, 0
    local bucketKey, bucket = nil, nil
    local function flush()
        if not bucket then return end
        if #bucket == 1 then out[#out + 1] = bucket[1]
        else
            local ps, qs, lastE, anyUsable = {}, {}, bucket[#bucket], false
            for _, e in ipairs(bucket) do if not e.u then anyUsable = true; ps[#ps + 1] = e.p; qs[#qs + 1] = e.q or 0 end end
            if anyUsable then
                out[#out + 1] = { t = lastE.t, p = MedianOf(ps), q = MedianOf(qs) or 0, c = #ps }
            else
                out[#out + 1] = lastE
            end
            removed = removed + #bucket - 1
        end
        bucket, bucketKey = nil, nil
    end
    for _, e in ipairs(h) do
        local age = now - (e.t or 0)
        local key
        if age > self.COMPACT_KEEP then removed = removed + 1
        else
            if idle or age > self.COMPACT_HOURLY then key = "d" .. math.floor((e.t or 0) / 86400)
            elseif age > self.COMPACT_FULL then key = "h" .. math.floor((e.t or 0) / 3600) end
            if key then
                if key ~= bucketKey then flush(); bucketKey, bucket = key, {} end
                bucket[#bucket + 1] = e
            else
                flush()
                out[#out + 1] = e
            end
        end
    end
    flush()
    return out, removed
end
-- alle Items in Portionen (Job); zurück: Einträge vorher, nachher
function A:CompactAll(now, md)
    md = md or (self.db and self.db.marketData)
    if not md then return 0, 0 end
    now = now or time()
    local before, after, i = 0, 0, 0
    for id, entry in pairs(md) do
        if type(entry) == "table" and (type(entry.history) == "table" or type(entry.hf) == "table") then
            -- RF-M1: flache Liste; nur Items, die wirklich verdichtet werden, kurz als Tabellen rechnen
            local F = self:HistFlat(entry)
            local n = #F / 5
            before = before + n
            if self:NeedsCompact(F, now) then
                local nh = self:CompactHistory(A.HistFlatToRows(F), now)
                entry.hf = A.HistRowsToFlat(nh)
                self:InvalidateMarket(id)
            end
            after = after + #entry.hf / 5
        end
        i = i + 1
        -- SN-TR-2 (Protokoll 0.65.265 "pd7 · längster Schritt 17-36 ms bis :1268", Nachbau s264_pd7_portions 71,7 ms): je Item
        -- abgeben statt alle 50 (A:Pause ist billig und gibt nur ab, wenn das Zeitbudget des Bildes voll ist)
        self:Pause()
    end
    return before, after
end
-- RF-M1: würde CompactHistory etwas ändern? (gleiche Regeln, ohne Tabellen zu bauen)
function A:NeedsCompact(F, now)
    local n = #F / 5
    if n < 2 then return false end
    now = now or time()
    local idle = now - (F[(n - 1) * 5 + 1] or 0) > self.COMPACT_IDLE
    local prevKey
    for i = 1, n do
        local t = F[(i - 1) * 5 + 1] or 0
        local age = now - t
        if age > self.COMPACT_KEEP then return true end
        local key
        -- Zahlen statt Zeichenketten (kein Abfall je Eintrag): Tag negativ, Stunde positiv
        if idle or age > self.COMPACT_HOURLY then key = -(math.floor(t / 86400) + 1)
        elseif age > self.COMPACT_FULL then key = math.floor(t / 3600) + 1 end
        if key and key == prevKey then return true end
        prevKey = key
    end
    return false
end
-- grobe Grösse je Bereich (KB) für den Bericht: Zeichen der serialisierten Felder geschätzt
-- pause (RUCKEL-3, 0.65.320, Nachbau echte Daten: pd7 11–17 ms am Stück): in der Hintergrund-Aufgabe je 500 Einträge eine Pause
function A:DataSizes(pause)
    local db = self.db or {}
    local sz = {}
    local nH = 0
    local k = 0
    for _, e in pairs(db.marketData or {}) do
        nH = nH + #(e.history or {}) + (type(e.hf) == "table" and #e.hf / 5 or 0)
        k = k + 1
        if pause and k % 500 == 0 then self:Pause() end
    end
    sz.verlauf = math.floor(nH * 42 / 1024)                       -- ~42 Bytes je Zeile "{t=..,p=..,q=..},"
    local function strs(t)
        local b = 0
        for _, v in pairs(t or {}) do
            if type(v) == "string" then b = b + #v + 4 end
            k = k + 1
            if pause and k % 500 == 0 then self:Pause() end
        end
        return math.floor(b / 1024)
    end
    sz.rhythmus = strs(db.timing and db.timing.items)
    sz.prognose = strs(db.forecast and db.forecast.list)
    sz.buchungen = math.floor(#((db.ledger and db.ledger.entries) or {}) * 90 / 1024)
    return sz, nH
end
A:On("READY", function()
    if A:Simulated() then return end
    C_Timer.After(90, function()
        if not A.db or (A.TestRoutine and A.TestRoutine.running) then return end
        local job = function()
            local sz0, n0 = A:DataSizes(true)
            local before, after = A:CompactAll()
            local sz1, n1 = A:DataSizes(true)
            A.db.compactLog = { t = time(), v = tostring(A.version), before = before, after = after, kb0 = sz0.verlauf, kb1 = sz1.verlauf }
            if A.Diag and before ~= after then
                pcall(A.Diag.Add, A.Diag, "PD7", string.format("Preisverlauf verdichtet: %d -> %d Zeilen (~%d -> ~%d KB)", before, after, sz0.verlauf, sz1.verlauf))
            end
        end
        if A.Job then A:Job("pd7", job) else pcall(job) end
    end)
end)

-- ------------------------------------------------------------
-- RF-M1 (Prüf-Sitzung 14.11. 00:15, Freigabe Nutzer 00:10): Preisverlauf zur LAUFZEIT kompakt.
-- Statt einer Tabelle je Eintrag {t,p,q} hält jedes Item EINE flache Zahlenliste entry.hf mit 5 Werten je Eintrag:
--   t, p, q, c (0 = keiner), f (Kennzeichen: 1 unbestätigt, 2 Sync, 4 ohne Menge, 8 nachgeprüft)
-- Gespeichert wird unverändert: beim Ausloggen wird hf wieder zu entry.history (Tabellen), PD7 packt wie bisher.
-- Beim Laden wird entry.history beim ersten Zugriff (bzw. in einer Hintergrund-Aufgabe in Portionen) zu hf.
-- Lesen: F, n = A:HF(itemID); Eintrag i: b = (i - 1) * 5 -> F[b+1] t, F[b+2] p, F[b+3] q, F[b+4] c, F[b+5] f.
-- A:GetHistory(itemID) liefert weiter Tabellen (frisch erzeugt) - nur für einzelne Items (Grafik, Tooltip).
-- ------------------------------------------------------------
local HS = 5
A.HS = HS
local EMPTY_F = setmetatable({}, { __newindex = function() error("A:HF: leere Liste ist nur zum Lesen") end })
local function RowsToFlat(rows)
    local F, k = {}, 0
    for i = 1, #rows do
        local e = rows[i]
        if type(e) == "table" and type(e.t) == "number" and type(e.p) == "number" then
            local q = tonumber(e.q)
            F[k + 1], F[k + 2], F[k + 3], F[k + 4] = e.t, e.p, q or 0, tonumber(e.c) or 0
            F[k + 5] = (e.u and 1 or 0) + (e.s and 2 or 0) + (q == nil and 4 or 0) + (e.v and 8 or 0)
            k = k + HS
        end
    end
    return F
end
local function FlatRow(F, i)
    local b = (i - 1) * HS
    local f = F[b + 5] or 0
    local e = { t = F[b + 1], p = F[b + 2] }
    if f % 8 < 4 then e.q = F[b + 3] end
    if (F[b + 4] or 0) ~= 0 then e.c = F[b + 4] end
    if f % 2 == 1 then e.u = 1 end
    if f % 4 >= 2 then e.s = 1 end
    if f >= 8 then e.v = 1 end
    return e
end
local function FlatToRows(F, from, to)
    local out = {}
    for i = from or 1, to or (#F / HS) do out[#out + 1] = FlatRow(F, i) end
    return out
end
A.HistRowsToFlat, A.HistFlatToRows, A.HistFlatRow = RowsToFlat, FlatToRows, FlatRow
-- Eintrag i bestätigt? (wie A.Usable für Tabellen)
function A.HUsable(F, i) return (F[(i - 1) * HS + 5] or 0) % 2 == 0 end
-- Tabellen -> flach (ohne PD7). Leere Tabelle neben vorhandener flacher Liste ändert nichts (RepairDB)
local function Flat(entry)
    local h = entry.history
    if type(h) == "table" then
        if not (entry.hf and #h == 0) then entry.hf = RowsToFlat(h) end
        entry.history = nil
    end
    local F = entry.hf
    if type(F) ~= "table" then F = {}; entry.hf = F end
    return F
end
A.HistFlatRaw = Flat
function A:HistFlat(entry)
    -- TB118-2: Preisverlauf wird nach dem Laden in Portionen entpackt - dieses Item bei Bedarf sofort
    if entry.hz and self.PD7 and self.PD7.loading then pcall(self.PD7.LoadEntry, self.PD7, entry) end
    return Flat(entry)
end
local RealGetHistory
-- flache Liste eines Items und Anzahl Einträge (nur lesen; schreiben nur RecordPrice/VerifyPrice/Verdichtung)
-- TB138b-2: läuft die Testroutine (auch beim Aufräumen bis nach dem Sandbox-Vergleich)? Dann keine echten Daten schreiben
function A:InTestRoutine()
    local TR = self.TestRoutine
    return TR and (TR.running or TR.finishing) and true or false
end
function A:HF(itemID)
    if self.GetHistory ~= RealGetHistory then            -- Testroutine: Ersatz-Verlauf (Tabellen) als flache Liste
        local F = RowsToFlat(self:GetHistory(itemID) or {})
        return F, #F / HS
    end
    local entry = self.db and self.db.marketData[itemID]
    if not entry then return EMPTY_F, 0 end
    local F = self:HistFlat(entry)
    return F, #F / HS
end
function A:HistCount(itemID) local _, n = self:HF(itemID); return n end
function A:GetHistory(itemID)
    local entry = self.db and self.db.marketData[itemID]
    if not entry then return {} end
    return FlatToRows(self:HistFlat(entry))
end
RealGetHistory = A.GetHistory
-- alle Märkte: flach -> Tabellen (beim Ausloggen, vor PD7). Zurück: Items, Einträge
function A:HistToRowsAll(db)
    db = db or self.db
    if type(db) ~= "table" then return 0, 0 end
    local items, rows = 0, 0
    local function one(md)
        if type(md) ~= "table" then return end
        for _, entry in pairs(md) do
            if type(entry) == "table" and type(entry.hf) == "table" then
                local okR, h = pcall(FlatToRows, entry.hf)
                if okR then
                    -- noch nicht entpacktes PD7-Paket: nur der neue Teil steht in hf (wie vorher in history)
                    entry.history, entry.hf = h, nil
                    items, rows = items + 1, rows + #h
                end
            end
        end
    end
    for _, m in pairs(db.markets or {}) do if type(m) == "table" then one(m.data) end end
    one(db.marketData)
    return items, rows
end
-- Hintergrund: alle Items eines Markts in Portionen flach machen (nach dem Laden / PD7)
function A:HistFlatAll(md, pause)
    md = md or (self.db and self.db.marketData)
    local n = 0
    for _, entry in pairs(md or {}) do
        if type(entry) == "table" and type(entry.history) == "table" and not (entry.hz and self.PD7 and self.PD7.loading) then
            Flat(entry); n = n + 1
            if pause then self:Pause() end                    -- TB125-1: je Item (Pause misst selbst das Bild-Budget)
        end
    end
    return n
end
-- nach dem Einloggen: übrige Items des aktiven Markts in Portionen flach machen (der Rest beim ersten Zugriff)
A:On("READY", function()
    if C_Timer and C_Timer.After then
        C_Timer.After(30, function()
            if A.Job then A:Job("hist:flat", function()
                local okF, n = pcall(A.HistFlatAll, A, nil, true)
                A.histFlatDone = { t = time(), n = okF and n or -1 }
            end) end
        end)
    end
end)
-- Objekte im Preisverlauf (Tabellen) zählen: für den Tempo-Test / T-RFM1
function A:HistObjects(md)
    md = md or (self.db and self.db.marketData)
    local items, tables, rows = 0, 0, 0
    for _, entry in pairs(md or {}) do
        if type(entry) == "table" then
            items = items + 1
            if type(entry.hf) == "table" then tables, rows = tables + 1, rows + #entry.hf / HS end
            if type(entry.history) == "table" then tables, rows = tables + 1 + #entry.history, rows + #entry.history end
        end
    end
    return tables, items, rows
end

-- Zählt ein Eintrag für Preise und Statistik? Unbestätigte (mögliche Lockangebote) nicht.
local function Usable(e) return e and not e.u end
A.Usable = Usable

-- letzter bestätigter Eintrag (Index)
local function LastUsable(h, before)
    for i = (before or #h), 1, -1 do
        if Usable(h[i]) then return i end
    end
    return nil
end
-- RF-M1: dasselbe auf der flachen Liste
local function FUs(F, i) return (F[(i - 1) * 5 + 5] or 0) % 2 == 0 end
local function FQ(F, i) local b = (i - 1) * 5; if (F[b + 5] or 0) % 8 >= 4 then return nil end return F[b + 3] end
local function FLast(F, n, before)
    for i = (before or n), 1, -1 do if FUs(F, i) then return i end end
    return nil
end
A.HQ, A.HLastUsable = FQ, FLast

function A:GetCurrent(itemID)
    local F, n = self:HF(itemID)
    local i = FLast(F, n)
    if i then
        local b = (i - 1) * 5
        -- S3 (Entscheid 21.11. 18:52): neuester Preis fremd (Sync), aber ein eigener aus derselben Stunde da -> der eigene gilt
        if (F[b + 5] or 0) % 4 >= 2 then
            local h = math.floor(F[b + 1] / 3600)
            for k = i - 1, 1, -1 do
                local c = (k - 1) * 5
                if math.floor(F[c + 1] / 3600) ~= h then break end
                local f = F[c + 5] or 0
                if f % 2 == 0 and f % 4 < 2 and (F[c + 2] or 0) > 0 then return F[c + 2], FQ(F, k), F[c + 1] end
            end
        end
        return F[b + 2], FQ(F, i), F[b + 1]
    end
    return nil
end

-- Veränderung zum vorherigen Scan in %
function A:GetChangeSinceLastScan(itemID)
    local F, n = self:HF(itemID)
    -- nur vollständige Scans vergleichen (ein Seiten-Scan sieht oft nur einen Teil der Angebote)
    local full = self.FullScanTimes and self:FullScanTimes(time() - (self.LIQ_DAYS or 14) * 86400)
    local anyFull = full and next(full)
    local i, j
    for k = n, 1, -1 do
        if FUs(F, k) and (not anyFull or full[F[(k - 1) * 5 + 1]]) then
            if not i then i = k elseif not j then j = k; break end
        end
    end
    if not j then return nil end
    local prev, cur = F[(j - 1) * 5 + 2], F[(i - 1) * 5 + 2]
    if not prev or prev <= 0 then return nil end
    return (cur - prev) / prev * 100
end

-- Veränderung über einen Zeitraum in %
-- Vergleich: aktueller Preis gegen den letzten Preis, der mindestens
-- "seconds" alt ist. Gibt es so alte Daten noch nicht -> nil.
function A:GetTrend(itemID, seconds)
    local F, n = self:HF(itemID)
    local ci = FLast(F, n)
    if not ci then return nil end
    local curT, curP = F[(ci - 1) * 5 + 1], F[(ci - 1) * 5 + 2]
    local limit = curT - seconds
    local refP = nil
    for i = ci - 1, 1, -1 do
        if FUs(F, i) and F[(i - 1) * 5 + 1] <= limit then
            refP = F[(i - 1) * 5 + 2]
            break
        end
    end
    if not refP or refP <= 0 then return nil end
    -- AHS-T750/OVF1 (Ingametest 25.11. 13:01, belegt Bericht 0.65.400): "Tagebuch eines Schurken" mit einem einzigen Angebot zum
    -- Höchstpreis des Auktionshauses (99 999 999 999 Kupfer = 9 999 999g 99s 99c) -> Trend "+10526315689 %" (Lücken-Spalte abgeschnitten,
    -- %d-Überlauf). Ein Angebot zum Höchstpreis ist kein Marktpreis: kein Trend. (Nur dieser Fall - IsOddPrice wäre zu breit:
    -- 309 von 7 532 Items verlören den Trend, gemessen.)
    if curP >= A.AH_MAX_PRICE or refP >= A.AH_MAX_PRICE then return nil end
    return (curP - refP) / refP * 100
end
A.AH_MAX_PRICE = 99999999999            -- Höchstpreis im Auktionshaus (Kupfer), siehe CF3

-- Median einer Zahlenliste (die Liste wird dabei sortiert)
local function Median(values)
    local n = #values
    if n == 0 then return nil end
    table.sort(values)
    if n % 2 == 1 then return values[(n + 1) / 2] end
    return (values[n / 2] + values[n / 2 + 1]) / 2
end
A.Median = Median

-- Durchschnitt, Median und Min/Max im Zeitraum. seconds = nil -> alles
function A:GetStats(itemID, seconds)
    local F, nF = self:HF(itemID)
    if nF == 0 then return nil end
    local limit = seconds and (time() - seconds) or 0
    local sum, n, minP, maxP = 0, 0, nil, nil
    local values = {}
    for i = 1, nF do
        local b = (i - 1) * 5
        if F[b + 1] >= limit and F[b + 5] % 2 == 0 then
            local p = F[b + 2]
            sum = sum + p
            n = n + 1
            values[n] = p
            if not minP or p < minP then minP = p end
            if not maxP or p > maxP then maxP = p end
        end
    end
    if n == 0 then return nil end
    return { avg = sum / n, median = Median(values), min = minP, max = maxP, count = n }
end

-- ------------------------------------------------------------
-- Marktwert: gewichteter Median der Preise der letzten 14 Tage.
-- Der Median ist robust: ein einzelnes Wucher- oder Lockangebot verschiebt ihn kaum.
-- Neuere Preise zählen stärker (Halbwertszeit MARKET_HALFLIFE Tage), damit der Wert einem
-- Preissturz nicht tagelang hinterherhinkt. Mondpreise (…99s 99c), die mehr als das
-- Dreifache des normalen Medians betragen, zählen gar nicht.
-- Gibt es weniger als 3 Preise in 14 Tagen, zählen die letzten 3.
-- ------------------------------------------------------------
A.MARKET_HALFLIFE = 3
local marketCache = {}
function A:ClearMarketCache() wipe(marketCache) end
function A:MarketCacheTable() return marketCache end

-- S92-JOBS (Entscheid Supervisor 23:03): ein Item ungültig machen = Eintrag behalten, als ungültig markieren (n = -1; kein
-- Verlauf hat -1 Einträge). Vorher entfernt -> nach jedem Vollscan je Item eine neue Speicher-Tabelle (~375 Byte).
function A:InvalidateMarket(itemID)
    if itemID then
        local c = marketCache[itemID]
        if c then c.n = -1 end
    else wipe(marketCache) end
end

-- Median mit Gewichten: list = { {v=, w=}, ... }
local function WeightedMedian(list)
    if #list == 0 then return nil end
    table.sort(list, function(a, b) return a.v < b.v end)
    local total = 0
    for _, e in ipairs(list) do total = total + e.w end
    local acc, half = 0, total / 2
    for i, e in ipairs(list) do
        acc = acc + e.w
        if acc > half + 1e-9 then return e.v end
        if math.abs(acc - half) <= 1e-9 then
            local nx = list[i + 1]
            return nx and (e.v + nx.v) / 2 or e.v
        end
    end
    return list[#list].v
end
A.WeightedMedian = WeightedMedian

A.BAIT_QTY = 2
A.BAIT_FACTOR = 0.6
-- H9: seit wie vielen Sekunden liegen die bestätigten Scan-Preise ununterbrochen über thr? (nil = jetzt nicht darüber)
function A:HighSince(itemID, thr)
    local F, n = self:HF(itemID)
    local since
    for i = n, 1, -1 do
        local b = (i - 1) * 5
        if F[b + 5] % 2 == 0 then
            if F[b + 2] > thr then since = F[b + 1] else break end
        end
    end
    return since and math.max(0, time() - since) or nil
end

-- TB138b-3 (Messung 14.11.: nach einem Vollscan ~8 KB Müll je Item, 50 MB bei 6000 Items -> Speicherbereinigungen):
-- gleiche Rechnung wie bisher, aber ohne neue Tabellen je Aufruf (wiederverwendete Hilfs-Listen, Cache-Eintrag wiederverwendet)
local MV_V, MV_T, MV_Q, MV_W, MV_A, MV_B, MV_N = {}, {}, {}, {}, {}, {}, {}
local HV, HQ, HT, HN = {}, {}, 0, 0             -- G4: Preise einer Stunde (Hilfslisten, ohne neue Tabellen je Aufruf)
local HS, HOWN = {}, false                      -- S3: Sync-Kennzeichen je Preis, eigener Preis in dieser Stunde?
-- G4: die gesammelte Stunde als EINEN Kandidaten anhängen (Median nach Preis); zurück: neue r, m
local function HourFlush(r, m)
    if HN == 0 then return r, m end
    -- S3 (Entscheid 21.11. 18:52): liegt in der Stunde ein eigener Preis vor, zählen fremde (Sync) Preise dieser Stunde nicht
    if HOWN then
        local k = 0
        for a = 1, HN do if not HS[a] then k = k + 1; HV[k], HQ[k] = HV[a], HQ[a] end end
        HN = k
    end
    HOWN = false
    for a = 2, HN do
        local v, q, j = HV[a], HQ[a], a - 1
        while j >= 1 and HV[j] > v do HV[j + 1], HQ[j + 1] = HV[j], HQ[j]; j = j - 1 end
        HV[j + 1], HQ[j + 1] = v, q
    end
    local k = math.floor((HN + 1) / 2)
    r = r + 1; MV_V[r], MV_T[r], MV_Q[r] = HV[k], HT, HQ[k]
    m = m + 1; MV_A[m] = r
    HN = 0
    return r, m
end
local MV_NN = 0
local function MvSortCmp(x, y) return MV_V[x] < MV_V[y] end
local function MvMedianOf(idx, m, pred)       -- Median der Werte MV_V[idx[k]] (k ≤ m, pred optional) wie Median(): sortiert
    local c = 0
    for k = 1, m do
        local v = MV_V[idx[k]]
        if not pred or pred(v) then c = c + 1; MV_N[c] = v end
    end
    for k = c + 1, MV_NN do MV_N[k] = nil end
    MV_NN = c
    if c == 0 then return nil end
    table.sort(MV_N)
    if c % 2 == 1 then return MV_N[(c + 1) / 2] end
    return (MV_N[c / 2] + MV_N[c / 2 + 1]) / 2
end
local function MvPlain(v) return not A:IsOddPrice(v) end
local function MvSetCache(itemID, n, last, first, hour, v)
    local c = marketCache[itemID]
    if c then c.n, c.last, c.first, c.hour, c.v = n, last, first, hour, v
    else marketCache[itemID] = { n = n, last = last, first = first, hour = hour, v = v } end
end
-- TT3: Anzahl gültiger Preise in den letzten MARKET_DAYS Tagen und der älteste der 3 neuesten Preise (für "nicht bekannt")
function A:MarketValueInfo(itemID)
    local F, n = self:HF(itemID)
    local limit = time() - self.MARKET_DAYS * 86400
    -- G4: gezählt wird je Stunde (wie A:GetMarketValue)
    local in14, k, oldest, lastH = 0, 0, nil, nil
    for i = n, 1, -1 do
        local b = (i - 1) * 5
        if F[b + 5] % 2 == 0 and (F[b + 2] or 0) > 0 then
            local h = math.floor(F[b + 1] / 3600)
            if h ~= lastH then
                lastH = h
                if F[b + 1] >= limit then in14 = in14 + 1 end
                k = k + 1
                if k <= 3 then oldest = F[b + 1] end
            end
        end
    end
    return { n = in14, all = k, oldest = oldest, known = in14 >= 3 }
end
function A:GetMarketValue(itemID)
    local F, n = self:HF(itemID)
    if n == 0 then return nil end
    local firstT, lastT = F[1], F[(n - 1) * 5 + 1]
    local hour = math.floor(time() / 3600)
    local perPrice = self.mvPerPrice                         -- G9-Vergleich (Testroutine T948): alte Rechnung ohne Stunden-Bündelung
    local c = marketCache[itemID]
    if not perPrice and c and c.n == n and c.last == lastT and c.first == firstT and c.hour == hour then
        return c.v
    end
    local now = time()
    local limit = now - self.MARKET_DAYS * 86400
    -- Kandidaten (neueste zuerst): Zeile r -> MV_V/T/Q[r]; Liste = Indizes in MV_A[1..m]
    -- G4 (Auftrag 21.11. 16:25): je Stunde EIN Wert (Median der Preise dieser Stunde), damit zwei gleichzeitige Scans (eigen + Gilde,
    -- Vollscan + Preisprüfung) nicht doppelt Gewicht haben. Zeitpunkt = neuester Preis der Stunde, Menge = die des Median-Preises.
    local m, r = 0, 0
    local hk = nil
    HN, HOWN = 0, false
    for i = n, 1, -1 do
        local b = (i - 1) * 5
        if F[b + 1] < limit then break end
        if F[b + 5] % 2 == 0 and (F[b + 2] or 0) > 0 then          -- VF4: nie 0
            local h = perPrice and i or math.floor(F[b + 1] / 3600)
            if h ~= hk then r, m = HourFlush(r, m); hk = h; HT = F[b + 1] end
            HN = HN + 1; HV[HN], HQ[HN] = F[b + 2], FQ(F, i) or -1
            local sy = F[b + 5] % 4 >= 2
            HS[HN] = sy
            if not sy and not perPrice then HOWN = true end
        end
    end
    r, m = HourFlush(r, m)
    -- TT3 (Auftrag Tooltip 21.11. 09:20): unter 3 Preisen in 14 Tagen ist der Marktwert unbekannt und rechnet NIRGENDS mit
    -- (vorher: die 3 neuesten, egal wie alt). A:MarketValueInfo sagt, warum (Anzahl, ältester Preis).
    if m < 3 then m = 0 end
    if m == 0 then
        if not perPrice then MvSetCache(itemID, n, lastT, firstT, hour, nil) end
        return nil
    end
    local idx, spare = MV_A, MV_B
    -- Mondpreise entfernen (nur wenn deutlich über dem normalen Median und noch etwas übrig bleibt)
    local med = MvMedianOf(idx, m, MvPlain)
    local k2 = 0
    for k = 1, m do
        local v = MV_V[idx[k]]
        if not (self:IsOddPrice(v) and med and v > med * 3) then k2 = k2 + 1; spare[k2] = idx[k] end
    end
    if k2 > 0 then idx, spare, m = spare, idx, k2 end
    -- T-HF10 (H9): Lockangebote aus dem Verlauf (höchstens BAIT_QTY Stück, unter BAIT_FACTOR × Median), mind. 3 übrig
    local allMed = MvMedianOf(idx, m)
    if allMed then
        local other = spare
        local k3 = 0
        for k = 1, m do
            local x = idx[k]
            local q = MV_Q[x]
            if q == -1 then q = 99 end
            if not (q <= self.BAIT_QTY and MV_V[x] < allMed * self.BAIT_FACTOR) then k3 = k3 + 1; other[k3] = x end
        end
        if k3 >= 3 and k3 < m then idx, spare, m = other, idx, k3 end
    end
    -- neuere Preise stärker gewichten (bezogen auf den neuesten Eintrag)
    local newest = MV_T[idx[1]]
    for k = 1, m do if MV_T[idx[k]] > newest then newest = MV_T[idx[k]] end end
    local hl = (self.MARKET_HALFLIFE or 3) * 86400
    -- gewichteter Median (wie WeightedMedian): nach Preis sortieren - Liste exakt auf m Einträge kürzen
    for k = m + 1, #idx do idx[k] = nil end
    for k = 1, m do MV_W[idx[k]] = 0.5 ^ ((newest - MV_T[idx[k]]) / hl) end
    table.sort(idx, MvSortCmp)
    local total = 0
    for k = 1, m do total = total + MV_W[idx[k]] end
    local acc, half, v = 0, total / 2, nil
    for k = 1, m do
        local x = idx[k]
        acc = acc + MV_W[x]
        if acc > half + 1e-9 then v = MV_V[x]; break end
        if math.abs(acc - half) <= 1e-9 then
            local nx = idx[k + 1]
            v = nx and (MV_V[x] + MV_V[nx]) / 2 or MV_V[x]
            break
        end
    end
    if v == nil then v = MV_V[idx[m]] end
    if v then v = math.floor(v + 0.5) end
    if v and v <= 0 then v = nil end                       -- VF4: Marktwert nie 0 oder negativ (nil = unbekannt)
    if not perPrice then MvSetCache(itemID, n, lastT, firstT, hour, v) end
    return v
end
-- Preis eingebrochen? Die letzten zwei Preise (mind. 6 Std. auseinander, beide aus den letzten
-- 4 Tagen) liegen unter 60 % des Marktwerts. Ein einzelnes billiges Angebot gilt noch nicht als Einbruch.
A.CRASH_FACTOR = 0.6
function A:IsCrashed(itemID)
    local mv = self:GetMarketValue(itemID)
    if not mv or mv <= 0 then return false end
    local F, n = self:HF(itemID)
    local i = FLast(F, n)
    if not i then return false end
    local curT, curP = F[(i - 1) * 5 + 1], F[(i - 1) * 5 + 2]
    if curT < time() - 4 * 86400 or curP >= mv * self.CRASH_FACTOR then return false end
    for k = i - 1, 1, -1 do
        local b = (k - 1) * 5
        if F[b + 5] % 2 == 0 and F[b + 1] <= curT - 6 * 3600 then
            if F[b + 1] < time() - 4 * 86400 then return false end
            return F[b + 2] < mv * self.CRASH_FACTOR
        end
    end
    return false
end

-- Was ein Verkauf heute realistisch bringt (pro Stück, vor Gebühr): höchstens Marktwert, und
-- höchstens 5 % über dem günstigsten aktuellen Angebot (letzte 3 Tage) - teurer kauft keiner.
-- ------------------------------------------------------------
-- Rechenwert eines Items (Entscheid des Nutzers 9. Nov. 15:39, Korrektur K3): der LETZTE SCAN.
--   Wert je Stück = günstigstes Angebot aus dem letzten Scan (bzw. der letzten Suche, wenn neuer)   source "ah" ("Scan")
--   kein Abzug von 1c, keine Deckelung auf den Median. Nur zwei Schutzregeln:
--   (a) Ausreisser (unter OUTLIER_LOW × Median, z. B. Einzelstück zu 1c): nächstes Angebot, das kein Ausreisser ist
--       (aus den zuletzt gesehenen Angeboten des Items), sonst der Median
--   (b) Item im letzten Scan nicht vorhanden: Markt-Median                                          source "market"
-- Der eigene Ø-Verkaufspreis ist nur Statistik (info.sale, Tooltip mit Shift), nie der Rechenwert.
-- Preis älter als PRICE_OLD_HOURS -> old = true ("Preis alt", nur Anzeige).
-- ------------------------------------------------------------
A.PRICE_OLD_HOURS = 6
A.OUTLIER_LOW, A.OUTLIER_HIGH = 0.10, 3.00
A.SALE_DAYS = 14
A.SCAN_SLACK = 300            -- Sekunden: Preis gilt als "im letzten Scan", wenn er nicht älter als der Scan ist

-- nächstes Angebot über der Ausreisser-Grenze aus den zuletzt gesehenen Angeboten (Verkaufen/Einkauf)
function A:NextRealOffer(itemID, floor)
    local lists = {}
    local pr = self.Seller and self.Seller.prices and self.Seller.prices[itemID]
    if pr and pr.listings then lists[#lists + 1] = pr.listings end
    local d = self.Buy and self.Buy.detail
    if d and d.itemID == itemID and d.listings then lists[#lists + 1] = d.listings end
    local best
    for _, list in ipairs(lists) do
        for _, l in ipairs(list) do
            local unit = l.price or l.unitPrice or (l.buyout and (l.qty or 1) > 0 and l.buyout / (l.qty or 1)) or nil
            if unit and unit >= floor and not l.own and (not best or unit < best) then best = unit end
        end
    end
    return best and math.floor(best + 0.5) or nil
end

-- opts.noCurrent = true: das aktuelle günstigste Angebot NICHT als Wert nehmen (z. B. Schnäppchen/Flips: genau dieses
-- Angebot kauft man ja - der Wiederverkauf richtet sich nach dem Median)
function A:PriceInfo(itemID, opts)
    if not itemID then return nil end
    local median = self:GetMarketValue(itemID)
    local cur, _, t = self:GetCurrent(itemID)
    local info = { median = median, current = cur, currentTime = t }
    local age = t and (time() - t) or nil
    info.old = age ~= nil and age > self.PRICE_OLD_HOURS * 3600
    -- Statistik: eigener Ø-Verkaufspreis (nie Rechenwert)
    info.sale = self.Ledger and self.Ledger.AverageSalePrice and self.Ledger:AverageSalePrice(itemID, self.SALE_DAYS) or nil
    -- im letzten Scan vorhanden? (oder neuer, z. B. aus einer Suche)
    local lastScan = self.db and self.db.lastScanTime or 0
    local inScan = cur and cur > 0 and t and (lastScan == 0 or t >= lastScan - self.SCAN_SLACK)
    info.inScan = inScan and true or false
    if inScan and not (opts and opts.noCurrent) then
        if median and median > 0 and cur < median * self.OUTLIER_LOW then
            info.unsure = true
            local nxt = self:NextRealOffer(itemID, median * self.OUTLIER_LOW)
            if nxt then info.value, info.source = nxt, "ah"
            else info.value, info.source = median, "market" end
        else
            info.value, info.source = cur, "ah"
        end
    elseif median then
        info.value, info.source = median, "market"
    elseif cur and cur > 0 and not (opts and opts.noCurrent) then
        info.value, info.source = cur, "ah"
    end
    -- MN5: A:PriceInfo bleibt unverändert (heisser Pfad, tausende Aufrufe je Rechnung); Netz-Werte nur über A:NetPrice
    if not info.value then return nil end
    return info
end
-- MN5 (Masterplan 2.2): Netz-Wert eines Items NUR als Zusatz-Angabe: { preis, menge, t, quelle = "netz", alter } - nur fremde
-- Werte, die NEUER sind als der eigene Scan des Items (sonst nil); höchstens NET_MAX_AGE alt. Nie Rechenwert: die Rangfolge
-- "eigener frischer Scan > Netz > Schätzung" für Werte wartet auf die Freigabe (Gold-Sicherheit: fremde Werte dürfen nie
-- einen Kauf auslösen).
A.NET_MAX_AGE = 6 * 3600
function A:NetPrice(itemID)
    local G = self:MarketNet()
    if not (G and G.Get and self:MarketShareOn()) then return nil end
    local e = G.Get(itemID)
    if not (e and e.quelle == "netz" and e.preis and e.preis > 0 and e.t) then return nil end
    local age = time() - e.t
    if age < 0 or age > self.NET_MAX_AGE then return nil end
    local _, _, own = self:GetCurrent(itemID)
    if own and own >= e.t then return nil end
    return { preis = e.preis, menge = e.menge, t = e.t, quelle = "netz", alter = age }
end
-- MN5 (Antwort Supervisor 18:22, Phase 7): eigener Weg NUR für den Markt-Reiter - eigener Wert (A:PriceInfo, unverändert)
-- oder, wenn es keinen eigenen gibt, der Netz-Wert als "unsicher" (Herkunft "netz", Alter). A:PriceInfo, Tooltip, API und
-- Buchhaltung nehmen nie Netz-Werte; ein Netz-Wert löst nie einen Kauf aus.
function A:PriceInfoNet(itemID)
    local i = self:PriceInfo(itemID)
    if i then return i end
    local n = self:NetPrice(itemID)
    if not n then return nil end
    return { value = n.preis, source = "netz", unsure = true, netAge = n.alter, netQty = n.menge, currentTime = n.t }
end
-- ------------------------------------------------------------
-- EINE Preisfunktion für alles (Anweisung "Werte stimmen" Punkt 8): Tooltip, Gewinn-Fenster, Schnäppchen, Flips,
-- Heute tun, Entzaubern (Block und Summe), Inventarwert, Vergleich mit dem Händler. Kein Fenster rechnet selbst.
-- Andere Addons (ProfessionSentinel): AHAnalyzerPro:RealPrice(itemID) / AHAnalyzerPro:RealValue(itemID, qty)
-- ------------------------------------------------------------
-- Wert pro Stück (brutto, vor Gebühren); ohne Daten nil. Zweiter Rückgabewert: PriceInfo (Quelle, Median ...)
function A:RealPrice(itemID, opts)
    local i = self:PriceInfo(itemID, opts)
    return i and i.value, i
end

-- Wert von qty Stück NACH Gebühren, mindestens der Händlerpreis (Punkt 7: was man sicher bekommt)
-- zurück: Gesamtwert, Wert pro Stück (brutto), PriceInfo, true wenn der Händler mehr zahlt
function A:RealValue(itemID, qty, opts)
    qty = qty or 1
    local price, info = self:RealPrice(itemID, opts)
    local vendor = self:GetVendorPrice(itemID)
    local vendorUnsure
    if type(vendor) == "number" and vendor > 0 and not self:VendorSafe(itemID, vendor) then vendor, vendorUnsure = 0, true end   -- TU1-HAENDLER
    vendor = (type(vendor) == "number" and vendor > 0) and vendor * qty or 0
    if info and vendorUnsure then info.vendorUnsure = true end
    if not price then
        if vendor > 0 then return vendor, nil, nil, true end
        return nil
    end
    local net = self:NetSale(itemID, price, qty, opts and opts.auctions)
    -- B3: in Forever geht bei jeder Einstellung ohne Verkauf die Einzahlung verloren (erwarteter Verlust)
    -- Angebot und Absatz (10.11.): N aus Warteschlange und Absatz, "kaum" -> Verkaufen nicht der beste Weg
    if not (opts and opts.noRelist) then
        local listings, why, outlook = self:ExpectedListings(itemID, qty, price)
        info.outlook = outlook
        if self:IsForever() and listings > 1 then
            local extra = self:ExpectedDepositLoss(itemID, qty, listings)
            if extra > 0 then
                net = net - extra
                info.listings, info.relistCost, info.relistWhy = listings, extra, why
            end
        end
        if self:IsForever() and outlook and outlook.rare and why ~= "own" then
            info.rare = true
            if vendor > 0 then return vendor, price, info, true end
        end
    end
    if vendor > net then return vendor, price, info, true end
    return net, price, info, false
end

-- Laufzeit-Vorbelegung (Anweisung "Gebühren klassisch" E1, nur Forever): Stunden (2/8/24) und Grund.
--   24 Std. kostet nicht mehr als 2 Std. (Minimum 1s greift)           -> 24 Std.
--   sonst gemessene Verkaufsdauer: Median < 2 Std. -> 2, < 8 Std. -> 8, sonst 24
--   ohne Messung: Mehrkosten von 24 Std. unter 5 % des Preises -> 24, sonst 8
-- Standard-Laufzeit (Wunsch des Nutzers 10.11. 07:25, Anweisung D1-D5): Einstellung "Standard-Laufzeit", Stufe 1/2/3,
-- Standard Stufe 1 (Forever 2 Std.; altes AH: die kürzeste Stufe, Beschriftung aus dem Spiel). Gilt für den Reiter
-- Verkaufen, Serie, Neu einstellen, Heute tun und alle Rechnungen (Einzahlung, Angebot und Absatz).
function A:StandardDurationStep()
    local d = self.db and self.db.settings and tonumber(self.db.settings.defaultDuration)
    if d == 1 or d == 2 or d == 3 then return d end
    return 1
end

-- Rückgabe: Stunden der Standard-Laufzeit (nur Forever, sonst nil) und ein Hinweis (D3: "24 Std. kostet gleich viel")
function A:DefaultDuration(itemID, qty)
    if not (itemID and self:IsForever()) then return nil end
    qty = math.max(1, qty or 1)
    local step = self:StandardDurationStep()
    local hours = self.DURATION_HOURS[step] or 2
    local why
    if step ~= 3 then
        local size = self:AuctionSize(itemID, qty)
        local auctions = math.max(1, math.ceil(qty / math.max(size, 1)))
        local d0 = self:ListingDeposit(itemID, qty, hours, auctions)
        local d24 = self:ListingDeposit(itemID, qty, 24, auctions)
        if d24 <= d0 then why = L["24 Std. kostet gleich viel"] end
    end
    return hours, why
end

-- MR8 (Antwort Supervisor 21:02, F4/F5): Laufzeit passend zum Spielrhythmus vorwählen - nur mit gelerntem Rhythmus und
-- Option "Laufzeit vorwählen" (Standard an). Noch ≥ 2 Std. übliche Spielzeit -> 2 Std. (Stufe 1); sonst (Ende < 2 Std. oder
-- nächstes Login > 1 Tag) -> 24 Std. (Stufe 3). Rückgabe: Stufe, Grund-Text (mit Einzahlung beider Laufzeiten) oder nil.
function A:RhythmDuration(itemID, qty, depositOf)
    if not (self.db and self.db.settings) or self.db.settings.rhythmDuration == false then return nil end
    local Act = self.Activity
    if not (Act and Act.SessionLeft) then return nil end
    local okL, left, r = pcall(Act.SessionLeft, Act)
    if not (okL and left and r) then return nil end
    local step, reason
    if left >= 7200 then
        step = 1
        reason = string.format(L["du spielst voraussichtlich noch %d Std."], math.floor(left / 3600))
    else
        step = 3
        reason = (r.days or 1) > 1 and string.format(L["du bist voraussichtlich %s weg"], string.format(L["~%d Tage"], r.days))
            or L["du bist voraussichtlich bis morgen weg"]
    end
    local other = (step == 1) and 3 or 1
    local d1 = depositOf and depositOf(step)
    local d2 = depositOf and depositOf(other)
    local lab = (self.Seller and self.Seller.DurationLabel) and self.Seller:DurationLabel(step) or (self.DURATION_HOURS[step] .. " h")
    local why = lab .. ": " .. reason
    if d1 and d2 then why = why .. " – " .. string.format(L["Einzahlung %s statt %s"], self:FormatMoney(d1), self:FormatMoney(d2)) end
    return step, why
end

-- Nachprüfung 08:40 Punkt 1 (HOCH): Laufzeit für die BEWERTUNG (Absatz, Einzahlungsrisiko, RealValue). Mit 2 Std. wäre
-- schon ab 14 Std. Wartezeit N = 7 (sechs verlorene Einzahlungen). Kostet 24 Std. gleich viel (Mindesteinzahlung), rechnet
-- die Bewertung mit 24 Std. - so stellt man es dann auch ein; sonst die Standard-Laufzeit. Das Fenster bleibt bei der
-- Standard-Laufzeit. Andere Versionen: wie bisher 24 Std.
function A:EvalHours(itemID, qty)
    local std = self.DURATION_HOURS[self:StandardDurationStep()] or 24
    if not (itemID and self:IsForever()) or std >= 24 then return 24 end
    qty = math.max(1, qty or 1)
    local ok, h = pcall(function()
        local size = self:AuctionSize(itemID, qty)
        local auctions = math.max(1, math.ceil(qty / math.max(size, 1)))
        local d0 = self:ListingDeposit(itemID, qty, std, auctions)
        local d24 = self:ListingDeposit(itemID, qty, 24, auctions)
        if d24 and d0 and d24 <= d0 then return 24 end
        return std
    end)
    return (ok and h) or std
end

-- ------------------------------------------------------------
-- Angebot und Absatz (Anweisung 10.11. 06:30, Wunsch des Nutzers): wie oft muss man einstellen, bis es verkauft ist?
--   Q  Warteschlange: Stück zu meinem Preis oder billiger, ohne Lockangebote und eigene Auktionen. Aus der letzten
--      Suche (Verkaufen-Reiter, Angebotsliste) wenn frisch, sonst alle Stück des letzten Scans (der Scan des modernen
--      Auktionshauses kennt je Item nur Gesamtmenge und Mindestpreis) minus eigene aktive Auktionen.
--   S  Absatz pro Tag: eigene Verkäufe (Buchhaltung, ab 3 Verkäufen) bevorzugt, sonst Markt (GetLiquidity.perDay,
--      ANNAHME "verschwunden = halb verkauft" - vermutet, Protokoll ABSATZ zum Prüfen). Unter 6 Scans oder unter
--      1 Tag Daten: unsicher.
--   W  Wartezeit in Tagen = (Q + eigene Menge) / S
--   N  erwartete Einstellungen = max(1, aufrunden(W / Laufzeit in Tagen)), höchstens RELIST_MAX
--   kaum: W > 7 Tage oder (S unbekannt und Q >= 20) -> Verkaufen ist nicht der beste Weg (RealValue: Händler).
-- Eigene Einstell-Quote der Buchhaltung (ab 3 Einstellungen) bleibt die gemessene Grösse und geht vor.
-- Rückgabe ExpectedListings: erwartete Einstellungen (1 .. RELIST_MAX), Grund ("own" / "queue" / nil), Ausblick
-- ------------------------------------------------------------
A.RELIST_MAX = 7
A.SELL_CAP = 0.2              -- G2: höchstens 20 % der Menge im letzten Scan pro Tag (vermutet, Protokoll ABSATZ prüft)
A.RARE_DAYS = 7
A.RARE_QUEUE = 20
A.OUTLOOK_SEARCH_AGE = 3600       -- so lange gilt die Angebotsliste einer Suche als frisch (Sekunden)
local outlookCache, absatzLogged = {}, {}
local salesIndex, salesIndexKey
function A:ResetOutlook() wipe(outlookCache); salesIndexKey = nil end

-- eigene Verkäufe pro Tag (Buchhaltung, 30 Tage, ab 3 Verkäufen), sonst nil
-- Index je Item (einmal je Buchhaltungs-Stand und Stunde gebaut, nicht je Item über alle Buchungen)
function A:OwnSalesPerDay(itemID)
    local db = self.db and self.db.ledger
    if not (db and db.entries and itemID) then return nil end
    local now = time()
    local key = #db.entries .. ":" .. math.floor(now / 3600)
    if salesIndexKey ~= key then
        salesIndex, salesIndexKey = {}, key
        local from = now - 30 * 86400
        for _, e in ipairs(db.entries) do
            if e.kind == "sale" and e.itemID and (e.t or 0) >= from then
                local x = salesIndex[e.itemID]
                if not x then x = { n = 0, qty = 0, first = e.t }; salesIndex[e.itemID] = x end
                x.n, x.qty = x.n + 1, x.qty + (e.qty or 1)
                if e.t < x.first then x.first = e.t end
            end
        end
    end
    local x = salesIndex[itemID]
    if not x or x.n < 3 then return nil end
    -- Stufe 2 L3: seltene Verkäufe (> 35 % Tage ohne Verkauf) mit Croston/SBA statt Summe/Tage
    local Ln = self.Learn
    if Ln and Ln.Croston then
        local okC, c = pcall(Ln.Croston, Ln, itemID, now)
        if okC and c then return c end
    end
    return x.qty / math.max(7, (now - x.first) / 86400)
end

-- Warteschlange Q zum Preis price (nil: alle Angebote); Quelle "search" / "scan"
function A:SellQueue(itemID, price)
    local Se = self.Seller
    local pr = Se and Se.prices and Se.prices[itemID]
    if pr and pr.listings and pr.stamp and time() - pr.stamp <= self.OUTLOOK_SEARCH_AGE then
        local q = 0
        for _, l in ipairs(pr.listings) do
            if not l.bait and (not price or (l.price or 0) <= price) then
                q = q + math.max(0, (l.qty or 0) - (l.own and (l.ownQty or l.qty or 0) or 0))
            end
        end
        return q, "search"
    end
    -- Schnell-Vollscan (V2): exakte Warteschlange aus der Preisleiter (Stück zu diesem Preis oder billiger)
    local VS = self.FullScan
    if VS and VS.Queue then
        local okQ, q, src = pcall(VS.Queue, VS, itemID, price)
        if okQ and q then return q, src end
    end
    local _, total, t = self:GetCurrent(itemID)
    if not total or not t or time() - t > 2 * 86400 then return nil, nil end
    local own = 0
    for _, o in ipairs(Se and Se.owned or {}) do
        if not o.sold and o.itemID == itemID then own = own + (o.qty or 0) end
    end
    return math.max(0, total - own), "scan"
end

function A:SellOutlook(itemID, qty, price)
    if not itemID then return nil end
    qty = math.max(1, math.floor(qty or 1))
    local key = itemID .. ":" .. qty .. ":" .. tostring(price)
    -- E3-Auflage: waysVer dazu - werden die Lern-Faktoren fertig (oder Wege/Lernen umgestellt), gilt der Zwischenspeicher nicht mehr
    local stamp = table.concat({ self.priceVersion or 0, self.db and self.db.lastScanTime or 0, self.waysVer or 0,
        math.floor(time() / 600), self.Seller and self.Seller.prices and self.Seller.prices[itemID] and self.Seller.prices[itemID].stamp or 0 }, "|")
    local c = outlookCache[key]
    if c and c.stamp == stamp then return c.v end
    local v = { qty = qty }
    -- Preis: der eigene Verkaufspreis (Vorschlag/Markt), wenn nicht angegeben
    if not price then
        local okP, p = pcall(self.RealPrice, self, itemID)
        if okP then price = p end
    end
    v.queue, v.queueSource = self:SellQueue(itemID, price)
    -- Befund F1 (10.11. 07:15): S immer aus dem MARKT (Q ist der ganze Markt). Eigene Verkäufe nur als Untergrenze
    -- (eigener Absatz > Markt-S -> Annahme "halb verkauft" zu klein) und: wer es selbst laufend verkauft, bei dem ist es
    -- nie "kaum".
    local own = self:OwnSalesPerDay(itemID)
    v.ownPerDay = own
    local ok, l = pcall(self.GetLiquidity, self, itemID)
    if ok and l and l.perDay and l.perDay > 0 then
        v.perDayRaw = l.perDay
        v.perDay, v.perDaySource = l.perDay, "market"
        v.unsure = (l.scans or 0) < 6 or (l.span or 0) < 1
        -- G2 (Befund 07:30): Auktionen laufen höchstens 24 Std. - jeden Tag verschwindet fast der ganze Bestand, auch
        -- ohne Verkauf. Darum Markt-Absatz höchstens SELL_CAP (20 %, VERMUTET) der Menge im letzten Scan pro Tag.
        local _, nowQty = self:GetCurrent(itemID)
        -- Stufe 2 L3: gelernter Faktor der Warengruppe (gemessen / alte Schätzung, ab 5 Items) statt des festen Deckels
        local Ln = self.Learn
        local okF, fac = false, nil
        if Ln and Ln.MarketFactor and self.Forecast then okF, fac = pcall(Ln.MarketFactor, Ln, self.Forecast:Group(itemID)) end
        -- E3-Auflage (Supervisor 22:45, Punkt 3): ohne Faktor, weil "learn:factor" noch läuft -> Ergebnis VORLÄUFIG (nie gemerkt,
        -- API liefert nil, Sniper wartet). Sobald die Faktoren da sind, rechnen alle Zwischenspeicher neu (A.waysVer).
        if not (okF and fac) and l.perDaySource ~= "gemessen" and Ln and Ln.FactorPending and Ln:FactorPending() then v.provisional = true end
        if l.perDaySource == "gemessen" then
            v.perDaySource = "measured"                 -- 0.65.111 S2: gemessen, kein Faktor/Deckel darauf
        elseif okF and fac then
            v.perDay, v.perDaySource, v.learnedFactor = l.perDay * fac, "market, gelernt", fac
        elseif nowQty and nowQty > 0 then
            v.cap = nowQty * self.SELL_CAP
            if v.perDay > v.cap then v.perDay, v.perDaySource = v.cap, "market, Deckel" end
        end
        if own and own > v.perDay then v.perDay, v.perDaySource = own, "own>market" end
    end
    -- V5 (Vollscan): gemessener Markt-Absatz (verschwundene Auktionen mit langer Restzeit, ab 3 Tagen Daten) geht vor
    -- der Schätzung "halb verkauft"/Deckel; eigene Verkäufe bleiben die Untergrenze
    local VS = self.FullScan
    local okM, measured, msrc, mdays, mplayers, mcapped = false, nil, nil, nil, nil, nil
    -- Phase 2 "alle": eigene Messung mit Vorwissen "alle Spieler" (VS:SalesRate), ohne eigene Messung "alle Spieler" allein
    if VS and VS.SalesRate then okM, measured, msrc, mdays, mplayers, mcapped = pcall(VS.SalesRate, VS, itemID) end
    -- MU1-5: Absatz über dem ganzen Angebot -> auf das Angebot begrenzt und "unsicher" (grau)
    if okM and measured and mcapped then v.perDayCapped = true end
    if okM and measured and msrc == "alle" then
        v.perDayRaw, v.cap = v.perDayRaw or measured, nil
        v.perDay, v.perDaySource, v.measuredDays, v.allPlayers, v.unsure = measured, "alle", mdays, mplayers, mcapped == true
        if own and own > measured then v.perDay, v.perDaySource = own, "own>market" end
    elseif okM and measured and measured <= 0 then
        v.perDay, v.perDaySource, v.measuredDays, v.cap = nil, "measured", mdays, nil
        v.measuredZero, v.unsure = true, false
        if own then v.perDay, v.perDaySource = own, "own" end
    elseif okM and measured then
        v.perDayRaw, v.cap = v.perDayRaw or measured, nil
        v.perDay, v.perDaySource, v.measuredDays, v.unsure = measured, "measured", mdays, mcapped == true
        if msrc == "gemessen+alle" then v.allPlayers = mplayers end
        if own and own > measured then v.perDay, v.perDaySource = own, "own>market" end
    elseif ok and l and l.perDay and l.perDay > 0 then
        -- (Markt geschätzt, siehe oben)
    elseif own then
        v.perDay, v.perDaySource, v.unsure = own, "own", true
    else
        v.unsure = true
        -- gemessen "nichts verkauft" (mind. 2 Scans über Zeit, Absatz 0) - ohne Messung (1 Scan) kein Urteil
        v.measuredZero = ok and l and l.perDay == 0 and (l.scans or 0) >= 2
    end
    local hours = self:EvalHours(itemID, qty)
    v.hours = hours
    -- G1: eigene Erfahrung zuerst - ab 3 Einstellungen gilt die eigene Verkaufsquote (verkauft / eingestellt), kein Deckel
    local Le = self.Ledger
    if Le and Le.PostRate then
        local okR, posts, sales = pcall(Le.PostRate, Le, itemID, 30)
        if okR and posts and posts >= 3 then v.ownPosts, v.ownSales = posts, sales end
    end
    if v.ownPosts then
        local rate = math.max(1 / self.RELIST_MAX, math.min(1, v.ownSales / v.ownPosts))
        v.listings, v.listingsSource, v.rare = 1 / rate, "own", false
        if v.queue and v.perDay then v.wait = (v.queue + qty) / v.perDay end
    elseif v.queue and v.perDay then
        v.wait = (v.queue + qty) / v.perDay
        -- Stufe 2 L10: gelernter Dauer-Faktor der Warengruppe (Selbstkorrektur, gedämpft)
        local Ln = self.Learn
        if Ln and Ln.Corr and self.Forecast then
            local okC, fd = pcall(Ln.Corr, Ln, self.Forecast:Group(itemID))
            if okC and fd and fd ~= 1 then v.wait, v.durFactor = v.wait * fd, fd end
        end
        v.listings = math.min(self.RELIST_MAX, math.max(1, math.ceil(v.wait / (hours / 24) - 1e-9)))
        v.rare = v.wait > self.RARE_DAYS
    elseif v.queue and v.measuredZero and v.queue >= self.RARE_QUEUE then
        -- A4: Absatz unbekannt (gemessen 0) bei langer Warteschlange -> "kaum"; N ohne Absatz nicht schätzbar: 1
        v.rare, v.listings = true, 1
    else
        v.listings = 1
    end
    if own then v.rare = false end          -- F1: selbst regelmässig verkauft -> nie "kaum"
    if v.provisional then return v end              -- E3-Auflage: vorläufig nie merken
    outlookCache.n = (outlookCache.n or 0) + (c and 0 or 1)
    if outlookCache.n > 20000 then wipe(outlookCache) end
    outlookCache[key] = { stamp = stamp, v = v }
    return v
end

-- A7: einmal je Item und Tag ins Protokoll (ohne Namen) - Annahme "verschwunden = halb verkauft" prüfen. Nur für Items,
-- die der Spieler ansieht (Tooltip, Verkaufen-Reiter), nie für ganze Listen.
function A:LogAbsatz(itemID)
    if not (self.Diag and itemID) or (self.TestRoutine and self.TestRoutine.running) then return end
    local day = math.floor(time() / 86400)
    if absatzLogged[itemID] == day then return end
    local ok, v = pcall(self.SellOutlook, self, itemID, 1)
    if not (ok and v and v.queue) then return end
    absatzLogged[itemID] = day
    -- G4: dazu S roh (vor dem Deckel), Deckel, eigene Quote, Laufzeit
    pcall(self.Diag.Add, self.Diag, "ABSATZ", string.format("Item %d · Q %d (%s) · S %s (%s%s) · S roh %s · Deckel %s · eigene Quote %s · Laufzeit %d Std. · W %s · N %s%s",
        itemID, v.queue, v.queueSource == "scan" and "scan, Q gesamt" or tostring(v.queueSource),
        v.perDay and string.format("%.1f", v.perDay) or "?", tostring(v.perDaySource or "-"), v.unsure and ", unsicher" or "",
        v.perDayRaw and string.format("%.1f", v.perDayRaw) or "-", v.cap and string.format("%.1f", v.cap) or "-",
        v.ownPosts and string.format("%d/%d", v.ownSales or 0, v.ownPosts) or "-", v.hours or 0,
        v.wait and string.format("%.1f", v.wait) or "?", string.format("%.1f", v.listings or 1), v.rare and " · kaum" or ""))
end


-- ------------------------------------------------------------
-- Befund Markt/Heute-Flip (10.11. 12:55, HOCH): EIN realistischer Wiederverkaufspreis für alle Stellen (Heute, Flippen,
-- Detail, Wächter). Der Marktwert ist ein ANGEBOTSPREIS (markt-strategie.md Abschnitt 2) und kann veraltet sein.
--   H1 Preis = der Stufenpreis der Angebotsliste (knapp unterboten), vor dem weniger Stück liegen als Absatz × Laufzeit;
--      höchstens gelernter Normalpreis (L4), höchstens Marktwert. Ohne Angebotsliste: min(Marktwert, Mindestpreis × 1,15).
--      buyPrice/buyQty: die Stück, die man selbst kauft, sind danach nicht mehr im Angebot.
--   H2 Preissturz (A:IsCrashed) oder Flutung (Menge >= 3× 14-Tage-Ø) -> kein Flip.
--   H4 ehrlicher Gewinn: (Preis × (1 − AH-Anteil) − Kaufpreis − Einzahlungsverlust je Stück) × Menge,
--      Menge höchstens Absatz × Laufzeit × eigener Anteil (MARKET_SHARE).
-- ------------------------------------------------------------
A.RESALE_NO_LADDER = 1.15
A.FLOOD_FACTOR = 3

-- Angebotsliste als Stufen { {Stückpreis, Stück}, ... } aufsteigend, ohne Lockangebote und eigene; nil wenn keine
function A:OfferLadder(itemID)
    local Se = self.Seller
    local pr = Se and Se.prices and Se.prices[itemID]
    -- HT-ALT (Ingametest 18.11. 09:29, T72 "Silberrute 4s 88c, günstigstes Angebot 16c"): eine Suche gilt nur, solange es keinen
    -- NEUEREN Preis gibt. Belegt: Suche 09:11:58 (16c) – Markt-Scan 09:30:07 (4s 88c) – T72 danach nahm die 18 Min. alte Suche statt
    -- des Scans von eben (Vollscan 09:30:57 bestätigte 4s 88c). 60 s Rand: die Suche trägt selbst einen Preis ein (VerifyPrice).
    local _, _, curT = self:GetCurrent(itemID)
    local searchStale = pr and pr.stamp and curT and curT > pr.stamp + 60
    if pr and pr.listings and #pr.listings > 0 and pr.stamp and time() - pr.stamp <= self.OUTLOOK_SEARCH_AGE and not searchStale then
        local out = {}
        for _, l in ipairs(pr.listings) do
            if not l.bait and l.price then
                local q = math.max(0, (l.qty or 1) - (l.own and (l.ownQty or l.qty or 0) or 0))
                if q > 0 then out[#out + 1] = { l.price, q } end
            end
        end
        if #out > 0 then table.sort(out, function(a, b) return a[1] < b[1] end); return out, "search" end
    end
    local VS = self.FullScan
    if VS and VS.Ladder then
        local okL, s, age = pcall(VS.Ladder, VS, itemID)
        if okL and s and age and age <= (VS.QUEUE_AGE or 2 * 86400) and s.steps and #s.steps > 0 then
            local out, prev = {}, 0
            for _, st in ipairs(s.steps) do
                local q = st[2] - prev
                prev = st[2]
                if q > 0 then out[#out + 1] = { st[1], q } end
            end
            -- Rest über den gespeicherten Stufen: Menge bekannt, Preis nicht - als geschätzte Stufe markiert (3. Feld);
            -- der Wiederverkaufspreis nimmt sie nie (Befund Schein-Flip 10.11. 16:50, F1: 11s 39c = 1,5 × letzte Stufe)
            if s.qty and s.qty > prev and out[#out] then out[#out + 1] = { math.floor(out[#out][1] * 1.5), s.qty - prev, true } end
            -- HT-ALT2 (Ingametest 18.11. 19:55 PC, T72 "Fraktionsbanner 1s 25c, günstigstes Angebot 58c"): wie bei der Suche (HT-ALT) gilt
            -- die Vollscan-Leiter nicht unverändert, wenn es einen NEUEREN Preis gibt. Belegt (Nachbau mit den Daten 19:51): Leiter vom
            -- Vollscan 17.11. 19:10 (58c, 2 Stück) - Markt-Scan der Testroutine 1s 25c - OfferLadder lieferte 58c. Jetzt: ist der neuere
            -- Preis höher, sind die billigeren Stufen weg (verkauft/abgelaufen); ist er niedriger, steht er vorne (Menge unbekannt: 1).
            -- Bleiben nur geschätzte Stufen übrig, gibt es keine Leiter (dann zählt der aktuelle Preis).
            local cur, _, curT2 = self:GetCurrent(itemID)
            if cur and cur > 0 and curT2 and curT2 > time() - age + 60 and out[1] and cur ~= out[1][1] then
                if cur > out[1][1] then
                    local kept, real = {}, false
                    for _, st in ipairs(out) do
                        if st[1] >= cur then kept[#kept + 1] = st; if not st[3] then real = true end end
                    end
                    out = real and kept or {}
                else
                    table.insert(out, 1, { cur, 1 })
                end
                if #out > 0 then return out, "vollscan+scan" end
                out = {}
            end
            if #out > 0 then return out, "vollscan" end
        end
    end
    local B = self.Buy
    local d = B and B.detail
    if d and d.itemID == itemID and not d.loading and d.listings and #d.listings > 0 then
        local out = {}
        for _, l in ipairs(d.listings) do
            if not l.bait and not l.own and l.price then out[#out + 1] = { l.price, l.qty or 1 } end
        end
        if #out > 0 then table.sort(out, function(a, b) return a[1] < b[1] end); return out, "detail" end
    end
    return nil
end

-- Absatz pro Tag und Laufzeit (Stunden) für die Rechnung
function A:ResaleBasis(itemID)
    local ok, v = pcall(self.SellOutlook, self, itemID, 1)
    local perDay = ok and v and v.perDay or nil
    local hours = (ok and v and v.hours) or self:EvalHours(itemID, 1) or 24
    return perDay, hours
end

-- Rückgabe: realistischer Stückpreis (brutto), Quelle ("leiter"/"ohne leiter"), Info
-- noCap (H9): ohne Deckel durch Marktwert und gelernte Grenze (Materialpreis entscheidet selbst, siehe D:MatPrice)
function A:ResalePrice(itemID, buyPrice, buyQty, ladder, perDay, hours, noCap)
    local mv = self:GetMarketValue(itemID)
    local cur = self:GetCurrent(itemID)
    if not ladder then ladder = self:OfferLadder(itemID) end
    if not perDay and not hours then perDay, hours = self:ResaleBasis(itemID) end
    hours = hours or 24
    local price, src
    if ladder and #ladder > 0 then
        -- eigene Käufe aus der Liste nehmen (die billigsten zuerst)
        local steps = {}
        local left = buyQty
        for _, st in ipairs(ladder) do
            local q = st[2]
            if buyPrice and st[1] <= buyPrice then
                if left == nil then q = 0 else local take = math.min(q, left); q = q - take; left = left - take end
            end
            if q > 0 then steps[#steps + 1] = { st[1], q, st[3] } end
        end
        local sellable = (perDay or 0) * hours / 24
        local before = 0
        for _, st in ipairs(steps) do
            if st[3] then break end                    -- F1: geschätzte Rest-Stufe nie als Preis
            if before < sellable or not price then price = math.max(1, st[1] - 1) end
            before = before + st[2]
            if before >= sellable then break end
        end
        if not price then price = mv end
        src = "leiter"
        -- MH1310 (3): über dem Marktwert nur, wenn die Leiter dort VOLL ist (>= 3 Angebotsstufen oder >= 5 Stück) UND
        -- Absatz >= 1/Tag - sonst höchstens Marktwert (zwei teure Ausreisser bei ~0,4/Tag sind kein Wiederverkaufspreis)
        if not noCap and mv and mv > 0 and price and price > mv then
            local total = 0
            for _, st in ipairs(steps) do if not st[3] then total = total + st[2] end end
            local full = (#steps >= 3 or total >= 5) and (perDay or 0) >= 1
            if not full then price, src = math.floor(mv), "marktwert" end
        end
    else
        -- A5 (Entscheid 10.11. 15:54): ohne Preisleiter der letzte Scan-Preis (auch älter, dann Hinweis "alt");
        -- der Marktwert nur, wenn es gar keinen Scan gibt ("geschätzt")
        if cur then price, src = cur, "ohne leiter" else price, src = mv and math.floor(mv) or nil, "geschätzt" end
    end
    if not price then return nil end
    -- A2/A3: kein Deckel mit dem Marktwert (Durchschnitt) und kein Mischen mit gelernten Normalpreisen - der Marktwert
    -- ist nur noch Warnlampe (A:PriceHints). Die Kaufmarge (L7) und die Selbstkorrektur (L10) bleiben (A6).
    return price, src, { mv = mv, cur = cur, perDay = perDay, hours = hours }
end

-- A3/A5 (Entscheid 10.11. 15:54): Hinweise zum Preis, die Zahl wird dabei NICHT verändert
--   fresh  = aktueller Preis > 150 % des Marktwerts und jünger als 24 Std. (Stunden seit dem Sprung)
--   crash  = aktueller Preis < 60 % des Marktwerts (Stunden seit dem Einbruch)
--   old    = letzter Scan älter als 2 Std. (Stunden)
--   guess  = kein Scan, nur Marktwert ("geschätzt")
A.HINT_FRESH, A.HINT_CRASH, A.HINT_OLD_H = 1.5, 0.6, 2
A.mvChecked = A.mvChecked or {}
function A:LowSince(itemID, thr)
    local F, n = self:HF(itemID)
    local since
    for i = n, 1, -1 do
        local b = (i - 1) * 5
        if F[b + 5] % 2 == 0 then
            if F[b + 2] < thr then since = F[b + 1] else break end
        end
    end
    return since and math.max(0, time() - since) or nil
end
function A:PriceHints(itemID)
    local out = {}
    local cur, _, t = self:GetCurrent(itemID)
    local mv = self:GetMarketValue(itemID)
    if not cur then
        if mv then out.guess = true end
        return out
    end
    if t and time() - t > self.HINT_OLD_H * 3600 then out.old = math.floor((time() - t) / 3600 + 0.5) end
    local okB, bo = pcall(self.BuyoutInfo, self, itemID)                    -- D6
    if okB and bo then out.buyout = bo end
    if mv and mv > 0 then
        if cur > mv * self.HINT_FRESH then
            local since = self:HighSince(itemID, mv * self.HINT_FRESH)
            if since and since < 24 * 3600 then out.fresh = math.max(1, math.floor(since / 3600 + 0.5))
            elseif since and not self.mvChecked[itemID] then
                -- H9: Scan seit ≥ 24 Std. über 150 % des Marktwerts -> Marktwert prüfen (einmal je Item und Sitzung)
                self.mvChecked[itemID] = true
                if self.Diag then pcall(self.Diag.Add, self.Diag, "MARKTWERT-CHECK", string.format("Item %d: Scan %d seit %.0f Std. über 150 %% des Marktwerts %d",
                    itemID, cur, since / 3600, mv)) end
            end
        elseif cur < mv * self.HINT_CRASH then
            local since = self:LowSince(itemID, mv * self.HINT_CRASH)
            out.crash = since and math.max(1, math.floor(since / 3600 + 0.5)) or 1
        end
    end
    return out
end
function A:PriceHintText(h)
    if not h then return nil end
    local parts = {}
    if h.fresh then parts[#parts + 1] = string.format(L["Preis frisch gestiegen (seit %d Std.)"], h.fresh) end
    if h.crash then parts[#parts + 1] = string.format(L["Preis eingebrochen (seit %d Std.)"], h.crash) end
    if h.old then parts[#parts + 1] = string.format(L["alt (vor %d Std.)"], h.old) end
    if h.guess then parts[#parts + 1] = L["geschätzt"] end
    if h.buyout then parts[#parts + 1] = L["Aufkauf: zum Kaufen mit altem Preis gerechnet"] end
    if #parts == 0 then return nil end
    return table.concat(parts, ", ")
end

-- ------------------------------------------------------------
-- D6 (Nachtrag 18:20, Hinweis des Nutzers): AUFKAUF erkennen. Jemand kauft ein Material weg -> Menge bricht ein UND der
-- günstigste Preis springt. Startwerte (vermutet, nicht belegt - im Bericht messen): Menge -70 % in <= 6 Std. und Preis
-- >= +50 % über dem Marktwert. Kennzeichen bleibt, bis die Menge wieder >= 50 % der Menge davor ist oder der Preis
-- <= 120 % des Marktwerts. Ohne Mengeneinbruch (langsamer Anstieg) ist es kein Aufkauf.
-- Kaufen rechnet dann höchstens mit dem Preis vor dem Aufkauf; Verkaufen bleibt beim aktuellen Preis + Hinweis.
-- ------------------------------------------------------------
A.BUYOUT_QTY_DROP = 0.30        -- Menge danach <= 30 % der Menge davor (= -70 %)
A.BUYOUT_HOURS = 6
A.BUYOUT_PRICE = 1.50           -- Preis >= 150 % des Marktwerts
A.BUYOUT_END_QTY = 0.50
A.BUYOUT_END_PRICE = 1.20
A.BUYOUT_LOOKBACK = 72 * 3600   -- so weit zurück wird nach dem Einbruch gesucht
A.buyoutCache = {}
function A:BuyoutInfo(itemID)
    if not itemID then return nil end
    local now = GetTime and GetTime() or 0
    local c = self.buyoutCache[itemID]
    if c and now - c.at < 30 and c.ver == self.priceVersion then return c.info end
    local info = self:DetectBuyout(itemID)
    -- MP3 (Befund 11.11. 19:45): ein Kennzeichen bleibt, bis ein NEUERER Scan es widerlegt (Menge wieder >= 50 % der
    -- Menge davor oder Preis <= 120 % des Preises vor dem Aufkauf) - auch über Sitzungen und Tage
    local store = self:BuyoutStore()
    if info then
        if store then store[itemID] = { since = info.since, q0 = info.q0, p0 = info.p0, mv = info.mv } end
    elseif store and store[itemID] then
        local k = store[itemID]
        local F, n = self:HF(itemID)
        local ci = FLast(F, n) or n
        local cur = ci > 0 and A.HistFlatRow(F, ci) or nil
        if cur and cur.t and cur.t > (k.since or 0) and cur.q and cur.p
            and (cur.q >= (k.q0 or 0) * self.BUYOUT_END_QTY or cur.p <= (k.p0 or 0) * self.BUYOUT_END_PRICE) then
            store[itemID] = nil                                   -- widerlegt
        else
            info = { since = k.since, q0 = k.q0, p0 = k.p0, q1 = cur and cur.q or 0, p1 = cur and cur.p or 0, mv = k.mv, kept = true }
        end
    end
    self.buyoutCache[itemID] = { at = now, ver = self.priceVersion, info = info }
    return info
end
-- Speicher der Kennzeichen: echte Daten (db.buyouts, neue Tabelle) - in der Testroutine nur die Ersatztabelle
function A:BuyoutStore()
    if self.buyoutTestStore then return self.buyoutTestStore end
    if not self.db or self:Simulated() then return nil end
    self.db.buyouts = self.db.buyouts or {}
    return self.db.buyouts
end
function A:DetectBuyout(itemID)
    local F, n = self:HF(itemID)
    if n < 2 then return nil end
    local mv = self:GetMarketValue(itemID)
    if not (mv and mv > 0) then return nil end
    local ci = FLast(F, n) or n
    local curP, curQ, tNow = F[(ci - 1) * 5 + 2], FQ(F, ci), F[(ci - 1) * 5 + 1] or 0
    if not (curP and curQ) then return nil end
    -- noch gekennzeichnet? (aktueller Stand)
    if curP <= mv * self.BUYOUT_END_PRICE then return nil end
    -- den Einbruch suchen: Eintrag i mit Menge <= 30 % eines Eintrags j höchstens 6 Std. davor und Preis >= 150 % mv
    for i = n, 2, -1 do
        local eT, eP, eQ = F[(i - 1) * 5 + 1], F[(i - 1) * 5 + 2], FQ(F, i)
        if eT < tNow - self.BUYOUT_LOOKBACK then break end
        if eQ and eP >= mv * self.BUYOUT_PRICE then
            for j = i - 1, 1, -1 do
                local bT, bP, bQ = F[(j - 1) * 5 + 1], F[(j - 1) * 5 + 2], FQ(F, j)
                if bT < eT - self.BUYOUT_HOURS * 3600 then break end
                if bQ and bQ > 0 and eQ <= bQ * self.BUYOUT_QTY_DROP and bP < eP then
                    if curQ >= bQ * self.BUYOUT_END_QTY then return nil end          -- Menge wieder normal
                    return { since = eT, q0 = bQ, p0 = math.min(bP, mv), q1 = curQ, p1 = curP, mv = mv }
                end
            end
        end
    end
    return nil
end
function A:BuyoutText(itemID)
    local b = self:BuyoutInfo(itemID)
    if not b then return nil end
    return string.format(L["Aufkauf bei %s – mit altem Preis gerechnet"], self:GetItemName(itemID) or ("#" .. itemID)), b
end

-- H2: Preissturz oder Flutung -> Grund (Text) oder nil
function A:FlipBlocked(itemID)
    local okC, crashed = pcall(self.IsCrashed, self, itemID)
    if okC and crashed then return "crash" end
    local _, qty = self:GetCurrent(itemID)
    if qty and qty > 0 then
        local F, nF = self:HF(itemID)
        local from = time() - 14 * 86400
        local sum, n = 0, 0
        for i = nF, 1, -1 do
            if F[(i - 1) * 5 + 1] < from then break end
            local q = FQ(F, i)
            if q then sum, n = sum + q, n + 1 end
        end
        if n >= 3 and qty >= self.FLOOD_FACTOR * (sum / n) then return "flood" end
    end
    return nil
end

-- Flip-Prüfung (EINE Funktion für Heute, Flippen, Detail): ok, Info
-- Info: resale (Stückpreis), net (je Stück nach AH-Anteil und Einzahlungsverlust), limit (Kaufgrenze), qty, profit, why
function A:FlipCheck(itemID, price, wantQty)
    local r = { itemID = itemID, price = price }
    local blocked = self:FlipBlocked(itemID)
    if blocked then r.why = blocked; return false, r end
    local perDay, hours = self:ResaleBasis(itemID)
    local ladder = self:OfferLadder(itemID)
    -- F1 (Befund Schein-Flip 10.11. 16:50): ohne aktuelle Preisleiter KEIN Flip (Entscheid "aktueller Markt")
    if not (ladder and #ladder > 0) then r.why = "noladder"; return false, r end
    -- Menge (H4): höchstens Absatz × Laufzeit × eigener Anteil
    local cap = math.max(1, math.floor((perDay or 0) * (hours or 24) / 24 * (self.MARKET_SHARE or 0.25)))
    local qty = math.max(1, math.min(wantQty or cap, cap))
    -- F2: höchstens die Stückzahl, die wirklich bis zum Kaufpreis angeboten wird
    if price then
        local avail = 0
        for _, st in ipairs(ladder) do if not st[3] and st[1] <= price then avail = avail + st[2] end end
        if avail <= 0 then r.why = "nooffer"; return false, r end
        qty = math.min(qty, avail)
    end
    local resale = self:ResalePrice(itemID, price, qty, ladder, perDay, hours)
    if not resale then r.why = "nodata"; return false, r end
    local loss = 0
    local okN, n = pcall(self.ExpectedListings, self, itemID, qty, resale)
    if okN and n and n > 1 then
        local okL, l = pcall(self.ExpectedDepositLoss, self, itemID, qty, n)
        if okL and type(l) == "number" then loss = l / qty end
    end
    local net = resale * (1 - self:CutPct()) - loss
    local Ln = self.Learn
    local limit = math.floor(net)
    -- Antwort 01:03 Punkt 2: eine Flip-Grenze (MK:FlipLimitFromNet, RK5/RK6) für Heute, Markt und Sniper
    local MKf = self.Core
    if MKf and MKf.FlipLimitFromNet then limit = MKf:FlipLimitFromNet(limit, itemID) or 0
    elseif Ln and Ln.BuyLimit then limit = Ln:BuyLimit(limit, "e") or limit end
    r.resale, r.net, r.limit, r.qty, r.perDay, r.hours = resale, net, limit, qty, perDay, hours
    r.profit = math.floor((net - (price or 0)) * qty)
    if not price then r.why = "noprice"; return false, r end
    if price > limit or r.profit <= 0 then r.why = "limit"; return false, r end
    return true, r
end

-- P4: EINE Quelle - SellOutlook (eigene Quote G1 oder Warteschlange); Tooltip, Gewinn-Fenster, Protokoll gleich
function A:ExpectedListings(itemID, qty, price)
    local ok, v = pcall(self.SellOutlook, self, itemID, qty, price)
    if ok and v then
        if v.listingsSource == "own" then return v.listings, "own", v end
        if v.rare or v.listings > 1 then return v.listings, "queue", v end
        return 1, nil, v
    end
    return 1, nil
end

-- alte Schnittstelle (auch für andere Addons): Verkaufspreis pro Stück = realer Wert
function A:GetSalePrice(itemID)
    local v, info = self:RealPrice(itemID)
    if not v then return nil end
    return v, info and info.current or nil
end

-- ------------------------------------------------------------
-- Lockangebote bei Waren: ganz unten Angebote über genau 1 Stück.
-- Sie zählen nirgends für Preise, Statistik, Sniper oder Vorschläge.
-- ------------------------------------------------------------
A.BAIT_FACTOR = 0.7     -- Scan-Preis unter 70 % des Marktwerts -> nachprüfen
A.BAIT_REAL_QTY = 5     -- TT1317: Vollscan mit >= 5 Stück auf der günstigsten Stufe = echter Preis

-- ------------------------------------------------------------
-- ST2–ST4 (Befund 22.11. 09:00 "Stapel- statt Stückpreis"): EINE Stelle für den Stückpreis einer Zeile der Item-Suche
-- (C_AuctionHouse.GetItemSearchResultInfo). Belege aus den Spieldaten von 4 Rechnern (Stand 21.11. 18:54): GetItemInfo-Stapelgrösse
-- der Schredderanleitungs-Seiten ist auf keinem Rechner > 1 gemerkt (db.stackMem, 462–1069 Einträge, Leinenstoff/Wollstoff = 20), und
-- der Vollscan sieht JEDE Auktion dieser Seiten mit Menge 1 (Seite 11: 4 Rechner, alle Einträge "1:Preis"). Ein nicht stapelbares Item
-- kann keine Auktion mit 9 Stück haben -> eine Zeile "Menge 9" sind 9 Auktionen zu je buyoutAmount (der Forever-Server fasst gleiche
-- Angebote zusammen). Bisher wurde buyoutAmount / Menge gerechnet -> Stückpreis 9× zu klein (Seite 11 "1s16" statt 10s44, "18c" statt
-- 10s26), und daraus "jetzt günstig – kaufen (−98 %)". Regel: Stapelgrösse 1 -> Stückpreis = buyoutAmount, ein Kauf = 1 Stück;
-- Stapelgrösse > 1 -> buyoutAmount / Menge (echter Stapel) wie bisher; Stapelgrösse unbekannt -> wie bisher, aber gemeldet.
-- Messung (beides belegen statt annehmen): je Item einmal je Sitzung Protokoll STAPEL-ROH mit Stapelgrösse, Menge, buyoutAmount.
-- ------------------------------------------------------------
-- ST7 (Prüfung 23.11. 06:27, HOCH): db.stackMem merkte nur Stapelgrössen > 1 -> bei nicht geladener Iteminfo war die Stapelgrösse
-- eines NICHT stapelbaren Items unbekannt und RowUnit teilte wieder (Sniper: 5g70/30 = 19s "kaufbar"). Jetzt wird auch 1 gemerkt
-- (hier und in A:IsCommodity) und gelesen; bleibt sie unbekannt, meldet RowUnit das (5. Rückgabe) - Sniper kauft nicht, Verkaufen
-- macht keinen Vorschlag, kein bestätigter Preis - und fordert die Iteminfo an.
function A:MaxStack(itemID)
    if not itemID then return nil end
    if self.maxStackTest and self.maxStackTest[itemID] ~= nil then return self.maxStackTest[itemID] or nil end
    local mem = self.db and self.db.stackMem
    local ok, st = pcall(function() return select(8, GetItemInfo(itemID)) end)
    if ok and type(st) == "number" and st > 0 then
        if self.db and not self:InTestRoutine() and (type(mem) ~= "table" or mem[itemID] ~= st) then
            self.db.stackMem = type(mem) == "table" and mem or {}
            self.db.stackMem[itemID] = st
        end
        return st
    end
    if self.stackMemTest then mem = self.stackMemTest end
    local m = type(mem) == "table" and tonumber(mem[itemID])
    if m and m >= 1 then return m end
    return nil
end
-- ST7-a (Messauftrag 23.11. 12:05): Grösse von db.stackMem (Einträge, davon Stapelgrösse 1, Zeichen in der Spieldaten-Datei - aus dem
-- Speicherformat "\t[<id>] = <n>,\n" berechnet) beim Login und nach jedem Vollscan; die letzten 6 Stände in db.stackMemLog (Testbericht T1002)
function A:StackMemSize()
    local n, n1, chars = 0, 0, 0
    for k, v in pairs((self.db and self.db.stackMem) or {}) do
        n = n + 1
        if v == 1 then n1 = n1 + 1 end
        chars = chars + #string.format("\t[%s] = %s,\n", tostring(k), tostring(v))
    end
    return n, n1, chars
end
function A:NoteStackMem(when)
    if not self.db or self:InTestRoutine() then return end
    local n, n1, chars = self:StackMemSize()
    local log = self.db.stackMemLog or {}
    self.db.stackMemLog = log
    log[#log + 1] = string.format("%s %s: %d Einträge, davon Stapelgrösse 1: %d, %d Zeichen", date("%d.%m. %H:%M"), tostring(when), n, n1, chars)
    while #log > 6 do table.remove(log, 1) end
end
A:On("READY", function() pcall(A.NoteStackMem, A, "Login") end)
-- ST7: Iteminfo anfordern (einmal je Item und Minute)
A.stackAsked = A.stackAsked or {}
function A:RequestItemInfo(itemID)
    if not itemID or (self.stackAsked[itemID] and time() - self.stackAsked[itemID] < 60) then return end
    self.stackAsked[itemID] = time()
    local CI = _G.C_Item
    if CI and CI.RequestLoadItemDataByID then pcall(CI.RequestLoadItemDataByID, itemID) else pcall(GetItemInfo, itemID) end
end
A.stackRawSeen = A.stackRawSeen or {}
-- zurück: Stückpreis, Stück insgesamt, Stück je Kauf, Anzahl zusammengefasster Auktionen (nil = echter Stapel/unbekannt),
-- ST7: true = Stapelgrösse unbekannt bei Menge > 1 (Stückpreis NICHT verlässlich)
function A:RowUnit(itemID, buyout, qty, auctionID)
    qty = math.max(1, qty or 1)
    local st = self:MaxStack(itemID)
    if qty > 1 and itemID and not self.stackRawSeen[itemID] and self.Diag then
        self.stackRawSeen[itemID] = true
        pcall(self.Diag.Add, self.Diag, "STAPEL-ROH", string.format("Item %d · Stapelgrösse %s · Zeile: Menge %d, buyoutAmount %d, auctionID %s -> %s",
            itemID, tostring(st or "unbekannt"), qty, buyout or 0, tostring(auctionID or "-"),
            st == 1 and "Stückpreis = buyoutAmount (zusammengefasste Auktionen)" or "Stückpreis = buyoutAmount / Menge"))
    end
    if st == 1 and qty > 1 then
        if itemID and not self.stackCleaned[itemID] then self.stackCleaned[itemID] = true; pcall(self.CleanDivided, self, itemID) end
        return buyout, qty, 1, qty
    end
    if st == nil and qty > 1 then
        self:RequestItemInfo(itemID)
        return A.UnitRound(buyout, qty), qty, qty, nil, true
    end
    return A.UnitRound(buyout, qty), qty, qty, nil
end
-- ST2/ST4 Bereinigung: Preisprüfung/Sniper/Einkauf schrieben bei zusammengefassten Einzel-Auktionen buyoutAmount / Menge als
-- bestätigten Preis (A:VerifyPrice, Kennzeichen 8). Für ein Item, bei dem jetzt eine solche Zeile belegt ist (RowUnit, Stapelgrösse 1),
-- werden eigene bestätigte Preise der letzten 14 Tage, die unter einem Drittel des Medians aller eigenen bestätigten Preise liegen
-- (ältere geteilte Werte tragen kein eigenes Kennzeichen; die Vollscan-Preise sind die Mehrheit), auf "unbestätigt" gesetzt (zählen
-- nicht mehr, bleiben gespeichert). Einmal je Item und
-- Sitzung; Zahlen ins Protokoll STAPEL-BEREINIGT.
A.stackCleaned = A.stackCleaned or {}
-- N1: Zeitpunkt der Korrektur (erstes Laden ab 0.65.378) - Preise aus der Einzelsuche davor gelten als "vielleicht geteilt"
A:On("READY", function() if A.db and not A.db.stFixAt then A.db.stFixAt = time() end end)
function A:CleanDivided(itemID)
    local entry = self.db and self.db.marketData and self.db.marketData[itemID]
    local F = entry and self:HistFlat(entry) or {}
    local n = #F / 5
    local from = time() - 14 * 86400
    local scanP = {}
    for i = 1, n do
        local b = (i - 1) * 5
        local f = F[b + 5] or 0
        if F[b + 1] >= from and f % 2 == 0 and f % 4 < 2 and (F[b + 2] or 0) > 0 then scanP[#scanP + 1] = F[b + 2] end
    end
    table.sort(scanP)
    local med = #scanP >= 3 and scanP[math.floor((#scanP + 1) / 2)] or nil       -- unter 3 Preisen: nichts an den Preisen ändern
    local k, total = 0, 0
    for i = 1, med and n or 0 do
        local b = (i - 1) * 5
        local f = F[b + 5] or 0
        if F[b + 1] >= from and f % 2 == 0 and f % 4 < 2 then
            total = total + 1
            if (F[b + 2] or 0) * 3 < med then F[b + 5] = f + 1; k = k + 1 end
        end
    end
    -- N1 (Prüfung im Spiel 22.11. 09:30): Preise aus der Einzelsuche (Preisprüfung/Sniper/Einkauf) VOR der Korrektur (db.stFixAt) sind
    -- nicht immer unter einem Drittel des Medians (geteilt durch 2–3 Angebote). Scan-Preise sind belegbar: alle Items eines Scans tragen
    -- dieselbe Zeit (A:ProcessBest, db.scanLog). Jeder Nicht-Scan-Preis vor der Korrektur, der höchstens 60 % des nächsten Scan-Preises
    -- (±24 Std.) beträgt, wird "unbestätigt".
    local scanT = {}
    for _, e in ipairs((self.db and self.db.scanLog) or {}) do if e.t then scanT[e.t] = true end end
    local fixAt = self.db and self.db.stFixAt or time()
    local k2 = 0
    for i = 1, n do
        local b = (i - 1) * 5
        local t, f = F[b + 1], F[b + 5] or 0
        if t >= from and t < fixAt and not scanT[t] and f % 2 == 0 and f % 4 < 2 then
            local best, bd
            for j = 1, n do
                local c = (j - 1) * 5
                if scanT[F[c + 1]] and (F[c + 5] or 0) % 2 == 0 and (F[c + 5] or 0) % 4 < 2 then
                    local dd = math.abs(F[c + 1] - t)
                    if dd <= 86400 and (not bd or dd < bd) then best, bd = F[c + 2], dd end
                end
            end
            if best and (F[b + 2] or 0) <= best * 0.6 then F[b + 5] = f + 1; k2 = k2 + 1 end
        end
    end
    k = k + k2
    if k > 0 then self:InvalidateMarket(itemID) end
    -- Käufe über Sniper/Einkauf: bei Stapelgrösse 1 kauft ein Klick EINE Auktion = 1 Stück; gebucht wurde die Zeilen-Menge
    -- (zusammengefasste Auktionen) -> Menge 1, Betrag bleibt (Sicherung e.oldST)
    local nb = 0
    local led = self.db and self.db.ledger and self.db.ledger.entries
    for _, e in ipairs(led or {}) do
        if e.kind == "buy" and e.itemID == itemID and (e.qty or 1) > 1 and e.src ~= "mail" and not e.oldST then
            e.oldST = { qty = e.qty }; e.qty = 1; nb = nb + 1
        end
    end
    if nb > 0 then self:Fire("LEDGER_CHANGED") end
    self:NoteFix("STAPEL", "Preise je Item auf unbestätigt (CleanDivided), Summen", { items = 1, unbestaetigt = k, geprueft = total, kaeufe = nb }, true)   -- PM1-b
    if self.Diag then pcall(self.Diag.Add, self.Diag, "STAPEL-BEREINIGT", string.format("Item %d · %d von %d eigenen Preisen unbestätigt (Median %d aus %d Preisen) · Käufe Menge -> 1: %d",
        itemID, k, total, med or 0, #scanP, nb)) end
    return k, total, med, nb
end
-- ST1 (Befund 22.11. 08:55: Kopf "günstigstes 6c" abgerundet, Tabelle "7c" gerundet): EINE Regel für den Stückpreis überall -
-- kaufmännisch gerundet; Anzeige mit Bruchteil, wenn er unter 1s liegt und nicht ganz aufgeht ("6,9c")
function A.UnitRound(total, qty)
    qty = math.max(1, qty or 1)
    return math.floor(total / qty + 0.5)
end
function A:UnitText(total, qty)
    qty = math.max(1, qty or 1)
    local u = total / qty
    if qty > 1 and u < 100 and total % qty ~= 0 then
        local t = string.format("%.1fc", u)
        if GetLocale and GetLocale() ~= "enUS" and GetLocale() ~= "enGB" then t = t:gsub("%.", ",") end
        return t
    end
    return self:FormatMoney(A.UnitRound(total, qty))
end

-- Waren (stapelbar) oder Einzelstück?
-- Punkt 5 (Vollscan-Speicher, Nachbau echte Daten: 27 643 Aufrufe, 1,2 MB - GetItemInfo legt je Aufruf Name/Link an): Stapelgrösse
-- je Item gemerkt (ändert sich nie); unbekannt (Item noch nicht geladen) wird nicht gemerkt
local commodityCache = {}
function A:IsCommodityItem(itemID)
    if not (GetItemInfo and itemID) then return false end
    -- T459-TR (Ingametest 19.11. 06:35: Vollscan im Lauf 28,9 MB statt <= 10): in der Testroutine war der Zwischenspeicher für ALLE
    -- Items aus, d. h. je Item und Aufruf GetItemInfo (17 Rückgaben, Texte) - im Vollscan 2x je Item. Nachbau mit echten Daten: 971 KB
    -- nur dafür (im Spiel mit Text-Rückgaben mehr). Aus ist er jetzt nur noch für Test-Items (ab 900000000) und solange eine Prüfung
    -- die Spiel-Schnittstelle ersetzt (A.apiOverride); echte Items messen so wie beim Spieler.
    local testApi = self:InTestRoutine() and (self.apiOverride ~= nil or itemID >= 900000000)
    local c = commodityCache[itemID]
    if c ~= nil and not testApi then return c end
    local stack = select(8, GetItemInfo(itemID))
    if stack == nil then
        -- STAPEL-MERK: noch nicht geladen -> gemerkte Stapelgrösse (nicht in den Zwischenspeicher, der Client lädt nach)
        local mem = self.db and self.db.stackMem
        local m = type(mem) == "table" and tonumber(mem[itemID])
        return (m and m > 1) and true or false
    end
    if stack >= 1 and self.db and not self:InTestRoutine() then                 -- ST7: auch Stapelgrösse 1 merken
        local mem = self.db.stackMem
        if not mem or mem[itemID] ~= stack then self.db.stackMem = mem or {}; self.db.stackMem[itemID] = stack end
    end
    c = stack > 1
    if not testApi then commodityCache[itemID] = c end                  -- Prüfungen ersetzen GetItemInfo für Test-Items
    return c
end

-- Angebote (aufsteigend nach Preis): führende fremde 1-Stück-Angebote als Lockangebot markieren
-- ------------------------------------------------------------
-- S7 (Wunsch des Nutzers 10.11. 18:24): tote Angebote KOMPLETT ignorieren und ausblenden. Ein Angebot, dessen Kauf
-- fehlschlug oder das der Server nach "weg" wieder liefert, wird je auctionID für die Sitzung (höchstens 48 Std.)
-- aus jeder Suche entfernt: Sniper, Einkauf, Unterbietung - und zählt damit auch nicht für A:GetCurrent, die
-- Preisleiter aus Suchen, "% Markt" und den Sammelkauf. Waren ohne auctionID: dieselbe Kombination Preis+Menge nach
-- 2 Fehlschlägen. Eine NEUE auctionID zum gleichen Preis bleibt sichtbar und kaufbar.
-- ------------------------------------------------------------
A.DEAD_HIDE_TTL = 48 * 3600
A.DEAD_COMMODITY_FAILS = 2
A.deadOffers = A.deadOffers or { ids = {}, com = {}, comFails = {} }
local function DeadNow() return GetTime() end
local function ComKey(itemID, price, qty) return tostring(itemID) .. ":" .. tostring(price) .. ":" .. tostring(qty or 0) end

-- ausblenden; zurück: true, wenn neu ausgeblendet
function A:HideDeadOffer(itemID, auctionID, price, qty, why)
    local d = self.deadOffers
    local now = DeadNow()
    if auctionID then
        if d.ids[auctionID] and d.ids[auctionID].exp > now then return false end
        d.ids[auctionID] = { itemID = itemID, price = price, qty = qty, why = why or "?", exp = now + self.DEAD_HIDE_TTL }
    elseif itemID and price then
        local k = ComKey(itemID, price, qty)
        if d.com[k] and d.com[k].exp > now then return false end
        d.comFails[k] = (d.comFails[k] or 0) + 1
        if d.comFails[k] < self.DEAD_COMMODITY_FAILS then return false end
        d.com[k] = { itemID = itemID, price = price, qty = qty, why = why or "?", exp = now + self.DEAD_HIDE_TTL }
    else
        return false
    end
    if self.Diag then pcall(self.Diag.Add, self.Diag, "SNIPER-TOT-AUSGEBLENDET", string.format("Item %s · Preis %s · %s · Grund %s",
        tostring(itemID or "?"), tostring(price or "?"), auctionID and "Einzelangebot" or "Ware", tostring(why or "?"))) end
    return true
end

function A:IsDeadOffer(itemID, auctionID, price, qty)
    local d = self.deadOffers
    local e
    if auctionID then e = d.ids[auctionID]
    elseif itemID and price then e = d.com[ComKey(itemID, price, qty)] end
    return e ~= nil and e.exp > DeadNow()
end

-- tote Angebote aus einer Liste entfernen (an Ort und Stelle); zurück: Anzahl, entfernte Einträge
function A:FilterDead(itemID, listings)
    if not listings then return 0, {} end
    local d = self.deadOffers
    if next(d.ids) == nil and next(d.com) == nil then return 0, {} end
    local removed = {}
    for i = #listings, 1, -1 do
        local l = listings[i]
        if self:IsDeadOffer(itemID, l.auctionID, l.price, l.qty) then
            table.insert(removed, 1, table.remove(listings, i))
        end
    end
    return #removed, removed
end

-- ausgeblendete Angebote eines Items (für den Hinweis in der Statuszeile): { { price, why }, ... }
function A:DeadOffersOf(itemID)
    local out, now = {}, DeadNow()
    local d = self.deadOffers
    for _, e in pairs(d.ids) do if e.itemID == itemID and e.exp > now then out[#out + 1] = e end end
    for _, e in pairs(d.com) do if e.itemID == itemID and e.exp > now then out[#out + 1] = e end end
    table.sort(out, function(a, b) return (a.price or 0) < (b.price or 0) end)
    return out
end

-- abgelaufene Einträge entfernen (Hinweis 6e)
function A:CleanDeadOffers()
    local d, now, n = self.deadOffers, DeadNow(), 0
    for k, e in pairs(d.ids) do if e.exp <= now then d.ids[k] = nil; n = n + 1 end end
    for k, e in pairs(d.com) do if e.exp <= now then d.com[k] = nil; d.comFails[k] = nil; n = n + 1 end end
    return n
end

function A:MarkBait(listings)
    local n = 0
    for _, l in ipairs(listings) do
        if l.qty == 1 and not l.own and n < 5 then l.bait = true; n = n + 1 else break end
    end
    return n
end

-- Angebotsliste ohne Lockangebote (1 Stück ganz unten) - für die Anzeige
function A:NoBait(listings)
    local out = {}
    for _, l in ipairs(listings or {}) do if not l.bait then table.insert(out, l) end end
    return out
end

-- erstes echtes (fremdes, kein Lockangebot) Angebot
function A:FirstReal(listings)
    for _, l in ipairs(listings) do
        if not l.bait and not l.own then return l end
    end
    return nil
end

-- Preis nachgeprüft (Einzelsuche): den unbestätigten Scan-Eintrag korrigieren, sonst neu eintragen
function A:VerifyPrice(itemID, price, quantity)
    local entry = self.db and self.db.marketData[itemID]
    local now = time()
    if entry then
        local F = self:HistFlat(entry)
        for i = #F / 5, 1, -1 do
            local b = (i - 1) * 5
            if now - F[b + 1] > 1800 then break end
            local f = F[b + 5] or 0
            if f % 2 == 1 then
                -- unbestätigt -> nachgeprüft (u weg, v dazu); Menge nur ersetzen, wenn bekannt
                F[b + 2] = price
                if quantity then F[b + 3] = quantity; if f % 8 >= 4 then f = f - 4 end end
                f = f - 1
                if f < 8 then f = f + 8 end
                F[b + 5] = f
                self:InvalidateMarket(itemID)
                return true
            end
        end
    end
    -- ST4: neuer Eintrag aus der Einzelsuche ebenfalls als "nachgeprüft" (Kennzeichen 8) - so sind Preise aus Preisprüfung/Sniper/
    -- Einkauf von Vollscan-Preisen unterscheidbar (Bereinigung A:CleanDivided)
    local okR = self:RecordPrice(itemID, price, quantity, now)
    if okR and self.db.marketData[itemID] then
        local F = self:HistFlat(self.db.marketData[itemID])
        for i = #F / 5, 1, -1 do
            local b = (i - 1) * 5
            if F[b + 1] == now and F[b + 2] == price then
                if (F[b + 5] or 0) < 8 then F[b + 5] = (F[b + 5] or 0) + 8 end
                break
            end
            if F[b + 1] < now then break end
        end
    end
    return okR
end

-- verdächtig billig (nur Waren)?
function A:IsSuspicious(itemID, price)
    if not self:IsCommodityItem(itemID) then return false end
    local mv = self:GetMarketValue(itemID)
    return mv ~= nil and price < mv * self.BAIT_FACTOR
end

-- ------------------------------------------------------------
-- Zeitbasierte EMAs (exponentiell geglättet über eine Zeitspanne, nicht über
-- eine Anzahl Punkte - die Scans kommen unregelmäßig). Nur bestätigte Preise.
-- ------------------------------------------------------------
A.EMA = {
    { key = "6h", tau = 6 * 3600, label = "EMA 6 Std.", color = { 0.40, 0.75, 1.00 } },
    { key = "1d", tau = 86400, label = "EMA 1 Tag", color = { 1.00, 0.60, 0.20 } },
    { key = "7d", tau = 7 * 86400, label = "EMA 7 Tage", color = { 0.78, 0.45, 1.00 } },
}
A.EMA_MIN_POINTS = 10

function A:GetEMASeries(itemID, tau)
    local out, ema, lastT = {}, nil, nil
    local F, n = self:HF(itemID)
    for i = 1, n do
        local b = (i - 1) * 5
        if F[b + 5] % 2 == 0 then
            local t, p = F[b + 1], F[b + 2]
            if not ema then
                ema = p
            else
                local dt = math.max(0, t - lastT)
                ema = ema + (1 - math.exp(-dt / tau)) * (p - ema)
            end
            lastT = t
            out[#out + 1] = { t = t, v = ema }
        end
    end
    return out
end

function A:GetEMA(itemID, tau)
    local s = self:GetEMASeries(itemID, tau)
    if #s < self.EMA_MIN_POINTS then return nil end
    return s[#s].v
end

-- Kreuzungen der schnellen über/unter die langsame EMA: { {t, v, up = true/false}, ... }
function A:GetEMACrossings(itemID, fastTau, slowTau)
    local f, s = self:GetEMASeries(itemID, fastTau), self:GetEMASeries(itemID, slowTau)
    local out = {}
    if #f < self.EMA_MIN_POINTS then return out end
    local prev
    for i = 2, #f do
        local d = f[i].v - s[i].v
        if prev and d ~= 0 and (prev > 0) ~= (d > 0) then
            table.insert(out, { t = f[i].t, v = s[i].v, up = d > 0 })
        end
        if d ~= 0 then prev = d end
    end
    return out
end

-- Preis im Verhältnis zum Marktwert in Prozent (100 = üblicher Preis)
function A:GetMarketPercent(itemID, price)
    price = price or self:GetCurrent(itemID)
    local mv = self:GetMarketValue(itemID)
    if not price or not mv or mv <= 0 then return nil end
    return price / mv * 100
end

-- Prozent vom Marktwert farbig: grün = günstig, weiß = normal, orange/rot = teuer
function A:FormatMarketPercent(pct)
    if not pct then return "|cff666666-|r" end
    local color
    if pct <= 80 then color = "33dd55"
    elseif pct < 95 then color = "aadd88"
    elseif pct <= 110 then color = "dddddd"
    elseif pct <= 130 then color = "ffaa33"
    else color = "ff5544" end
    return string.format("|cff%s%d%%|r", color, math.floor(pct + 0.5))
end

-- ------------------------------------------------------------
-- Händlerpreis (Verkauf an einen NPC-Händler) pro Stück in Kupfer.
-- nil = noch unbekannt (Client kennt das Item noch nicht), 0 = nicht verkaufbar.
-- Einmal bekannt, bleibt er gespeichert.
-- ------------------------------------------------------------
-- HP1 (Blizzard-Hotfix 10.11.2026: Händlerpreise gesenkt, z. B. Eisengranate 5s -> 1s25): der Client (GetItemInfo,
-- sellPrice) gilt zuerst; die gemerkte Tabelle ist nur Rückfall, solange das Item noch nicht geladen ist. Weicht der
-- Client ab, wird die Tabelle nachgeführt (einmal je Sitzung und Item geprüft).
A.vendorChecked = A.vendorChecked or {}
A.vendorFromTable = A.vendorFromTable or {}     -- zuletzt nur aus der Tabelle (ungeprüft) geliefert
function A:GetVendorPrice(itemID)
    local db = self.db
    local known = db and db.vendorPrices and db.vendorPrices[itemID]
    if not itemID then return nil end
    if known and self.vendorChecked[itemID] then return known end
    local GII = self:Global("GetItemInfo") or GetItemInfo
    if GII then
        local info = { pcall(GII, itemID) }
        if info[1] and info[2] and type(info[12]) == "number" then
            if not self.vendorChecked[itemID] then self.vendorCheckedCount = (self.vendorCheckedCount or 0) + 1 end   -- MA3
            self.vendorChecked[itemID] = true
            self.vendorFromTable[itemID] = nil
            if known and known ~= info[12] then self.vendorDiffCount = (self.vendorDiffCount or 0) + 1 end
            if known ~= info[12] then self.vendorNew[itemID] = info[12] end                 -- G17: der Gilde fehlt dieser Wert evtl.
            if db and db.vendorPrices and known ~= info[12] then
                if known and self.Diag then pcall(self.Diag.Add, self.Diag, "HAENDLERPREIS", string.format("Item %d: Tabelle %d -> Spiel %d", itemID, known, info[12])) end
                db.vendorPrices[itemID] = info[12]
            end
            return info[12]
        end
    end
    -- G17 Teil 2: der eigene Client kennt das Item nicht (GetItemInfo noch ohne Antwort) -> Wert aus einem Gilden-Client, der es
    -- im Spiel gelesen hat; er geht der mitgelieferten Tabelle vor (die Tabelle kann seit dem Hotfix 10.11. veraltet sein).
    -- Eigener Spielwert geht immer vor (oben). Nur Ergänzung, nichts wird überschrieben.
    local g = db and db.vendorShared and db.vendorShared[itemID]
    if g then self.vendorFromGuild[itemID] = true; return g end
    if known then self.vendorFromTable[itemID] = true end
    return known
end
-- G17 Teil 2: im Spiel gelesene Händlerpreise, die von der Tabelle abweichen oder darin fehlen, an die Gilde
-- "W:<Zeit>:<Markt-Tag>;id,Preis;…" (nur neue seit dem letzten Senden, höchstens alle 10 Min.; keine Namen, keine Konto-Kennung nötig)
A.vendorNew = A.vendorNew or {}
A.vendorFromGuild = A.vendorFromGuild or {}
A.VENDOR_GAP = 600
function A:BroadcastVendor()
    local S = self.Sync
    if not (S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.SendNow and S.Enc) then return false end
    if self:InTestRoutine() or self:Simulated() then return false end
    local now = time()
    if self.vendorSent and now - self.vendorSent < self.VENDOR_GAP then return false end
    if not next(self.vendorNew) then return false end
    self.vendorSent = now
    local head = "W:" .. S.Enc(now) .. ":" .. self:MarketTag() .. ";"
    local chunk, size, sent = {}, #head, 0
    for id, p in pairs(self.vendorNew) do
        local part = S.Enc(id) .. "," .. S.Enc(p)
        if size + #part + 1 > S.MAX_MSG and #chunk > 0 then
            S.SendNow(head .. table.concat(chunk, ";")); sent = sent + 1
            chunk, size = {}, #head
        end
        chunk[#chunk + 1] = part
        size = size + #part + 1
    end
    if #chunk > 0 then S.SendNow(head .. table.concat(chunk, ";")); sent = sent + 1 end
    self.vendorNew = {}
    return sent > 0
end
-- Empfang: nur übernehmen, wenn der eigene Client das Item nicht selbst im Spiel gelesen hat (vendorChecked)
function A:HandleVendor(t, rest)
    local S = self.Sync
    local db = self.vendorTestDB or self.db
    if not (S and S.Dec and db and type(rest) == "string") then return -1 end
    local tag, data = rest:match("^(%w+);(.*)$")
    if not tag or tag ~= self:MarketTag() then return -1 end
    local now = time()
    if not t or t > now + 300 or t < now - 86400 then return -1 end
    db.vendorShared = db.vendorShared or {}
    local taken = 0
    for part in data:gmatch("[^;]+") do
        local a, b = part:match("^(%w+),(%w+)$")
        local id, p = S.Dec(a or ""), S.Dec(b or "")
        if id and p and p >= 0 and p < 100000000 and not self.vendorChecked[id] then
            db.vendorShared[id] = p
            taken = taken + 1
        end
    end
    return taken
end

-- ------------------------------------------------------------
-- Händler-Einkaufspreis: was ein Händler pro Stück VERLANGT.
-- Wird automatisch gelesen, sobald du ein Händlerfenster öffnest.
-- ------------------------------------------------------------
function A:GetVendorBuyPrice(itemID)
    return self.db and itemID and self.db.vendorBuy[itemID] or nil
end

-- Was kostet ein Händler-Artikel? Moderner Client: C_MerchantFrame.GetItemInfo (Tabelle),
-- sonst das alte GetMerchantItemInfo. Rückgabe: price, stackCount, numAvailable, hasExtendedCost
-- (alle Funktionen über A:API: ohne Testroutine sind das genau die Funktionen des Spiels)
local function MerchantItem(i)
    local CMF = A:Global("C_MerchantFrame")
    if CMF and CMF.GetItemInfo then
        local ok, info = pcall(CMF.GetItemInfo, i)
        if ok and type(info) == "table" then
            return info.price, info.stackCount, info.numAvailable, info.hasExtendedCost
        end
    end
    local getInfo = A:Global("GetMerchantItemInfo")
    if getInfo then
        local ok, _, _, price, quantity, numAvailable, _, _, extendedCost = pcall(getInfo, i)
        if ok then return price, quantity, numAvailable, extendedCost end
    end
    return nil
end

-- Kosten in Marken/Währungen/Gegenständen (z. B. Merchant's Favor): { { kind, id, name, amount }, ... }
local function MerchantCosts(i)
    local costInfo, costItem = A:Global("GetMerchantItemCostInfo"), A:Global("GetMerchantItemCostItem")
    if not (costInfo and costItem) then return nil end
    local ok, n = pcall(costInfo, i)
    if not ok or not n or n < 1 then return nil end
    local out = {}
    for k = 1, n do
        local ok2, _, amount, link, currencyName = pcall(costItem, i, k)
        if ok2 and amount and amount > 0 then
            local itemID = type(link) == "string" and tonumber(link:match("item:(%d+)"))
            local curID = type(link) == "string" and tonumber(link:match("currency:(%d+)"))
            local name = currencyName or (itemID and A:GetItemName(itemID)) or (type(link) == "string" and link:match("%[(.-)%]")) or "?"
            table.insert(out, { kind = itemID and "item" or "currency", id = itemID or curID, name = name, amount = amount })
        end
    end
    return #out > 0 and out or nil
end

-- Händler-Kosten eines Items: { gold = Kupfer (kann 0 sein), qty = Stück je Kauf, costs = {...}, t = Zeit } oder nil
-- (für Artikel, die (auch) Währung kosten, z. B. Merchant's Favor auf WoW Forever; ProfessionSentinel nutzt das)
function A:GetVendorCost(itemID)
    return self.db and self.db.vendorCost and itemID and self.db.vendorCost[itemID] or nil
end

function A:ScanMerchant()
    local CMF = self:Global("C_MerchantFrame")
    local count = self:Global("GetMerchantNumItems") or (CMF and CMF.GetNumItems)
    if not (self.db and count) then return 0 end
    local getLink, getID = self:Global("GetMerchantItemLink"), self:Global("GetMerchantItemID")
    self.db.vendorCost = self.db.vendorCost or {}
    local okN, n = pcall(count)
    n = okN and n or 0
    local found = 0
    for i = 1, n do
        local price, quantity, numAvailable, extendedCost = MerchantItem(i)
        local link = getLink and getLink(i)
        local id = type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
        if not id and getID then id = tonumber((select(2, pcall(getID, i)))) end
        local unlimited = (numAvailable == nil or numAvailable < 0)
        -- nur Gold-Preise (keine Marken/Abzeichen), nur unbegrenzt verfügbare Waren
        if id and price and price > 0 and not extendedCost and unlimited then
            local unit = math.max(1, math.floor(price / math.max(1, quantity or 1) + 0.5))
            local old = self.db.vendorBuy[id]
            if not old or unit < old then self.db.vendorBuy[id] = unit end
            found = found + 1
        end
        -- Währungskosten merken (der Gold-Preis zählt dafür nicht als Händlerpreis)
        if id and extendedCost then
            local costs = MerchantCosts(i)
            if costs then
                self.db.vendorCost[id] = { gold = price or 0, qty = math.max(1, quantity or 1), costs = costs, t = time() }
                found = found + 1
            end
        end
    end
    if found > 0 then self:Fire("DATA_CHANGED") end
    return found
end

-- Unglaubwürdiger Gewinn: ab 1000 % (Vergleichswert mehr als 11x so hoch wie der Preis).
-- Das sind fast immer Fehldaten (falscher Marktwert, Ausreißer, Platzhalter-Preise) - solche Items zeigen wir nicht als Schnäppchen.
A.ABSURD_PCT = 1000
function A:IsAbsurdProfit(price, ref)
    if not (price and ref) then return false end
    if price <= 0 then return ref > 0 end
    return (ref - price) / price * 100 >= self.ABSURD_PCT
end

-- ------------------------------------------------------------
-- Verkaufbarkeit (geschätzt aus der Scan-Historie)
-- Wir sehen keine Verkäufe, nur Angebote. Sinkt die angebotene Menge zwischen zwei Scans,
-- ist Ware verschwunden - meist verkauft (manchmal abgelaufen oder zurückgezogen).
-- Daraus: Abgänge pro Tag, wie oft das Item überhaupt da ist, und ein Vertrauen in den Marktwert.
-- ------------------------------------------------------------
A.LIQ_DAYS = 14
local liqCache = {}
function A:InvalidateLiquidity(itemID) if itemID then liqCache[itemID] = nil else wipe(liqCache) end end
-- Preisliste gewechselt (anderes Auktionshaus): alle Zwischenspeicher leeren
function A:ClearPriceCaches()
    wipe(liqCache)
    if self.ClearMarketCache then self:ClearMarketCache() end
end
-- RF (Caches begrenzen): Zwischenspeicher je Item für den Tempo-Test sichtbar machen und begrenzen
function A:LiqCacheTable() return liqCache end
-- S92-JOBS (Entscheid Supervisor 23:03): Grenze = Items im letzten Vollscan + 20 %, mindestens 4000, höchstens 20 000 (feste
-- Obergrenze, RF "Caches begrenzen" bleibt). Vorher fest 4000: mit mehr Items im AH wurde alle 10 Min. der ganze Marktwert-
-- Speicher geleert und neu gerechnet. A.CACHE_MAX_ITEMS (nil) = Testnaht für eine feste Grenze.
A.CACHE_MIN_ITEMS, A.CACHE_HARD_MAX = 4000, 20000
function A:CacheMaxItems()
    if self.CACHE_MAX_ITEMS then return self.CACHE_MAX_ITEMS end
    local n = 0
    local VS = self.FullScan
    local okS, st = pcall(function() return VS and VS.Data and VS:Data() end)
    if okS and type(st) == "table" and tonumber(st.lastGoodItems) then n = tonumber(st.lastGoodItems) end
    local log = self.db and self.db.scanLog
    local last = type(log) == "table" and log[#log]
    if n == 0 and type(last) == "table" and tonumber(last.items) then n = tonumber(last.items) end
    return math.min(self.CACHE_HARD_MAX, math.max(self.CACHE_MIN_ITEMS, math.floor(n * 1.2)))
end
function A:TrimCaches()
    local trimmed = {}
    local function cnt(t) local n = 0; for _ in pairs(t or {}) do n = n + 1 end; return n end
    local mc = self.MarketCacheTable and self:MarketCacheTable()
    local max = self:CacheMaxItems()
    for name, t in pairs({ markt = mc, absatz = liqCache, aufkauf = self.buyoutCache }) do
        if type(t) == "table" and cnt(t) > max then wipe(t); trimmed[#trimmed + 1] = name end
    end
    return trimmed
end
A:On("READY", function()
    if not (C_Timer and C_Timer.NewTicker) then return end
    C_Timer.NewTicker(600, function()                     -- alle 10 Min.: zu grosse Zwischenspeicher leeren
        if A.TestRoutine and A.TestRoutine.running then return end
        local ok, t = pcall(A.TrimCaches, A)
        if ok and t and #t > 0 then A.lastTrim = { t = time(), what = table.concat(t, ",") } end
    end)
end)

-- Schnapszahl wie 1299g 99s 99c oder 2499g 99s 99c: typischer Mondpreis
-- (Endung …99s 9xc oder genau …99s 00c)
function A:IsOddPrice(copper)
    if not copper or copper < 10000 then return false end
    local r = copper % 10000
    return r >= 9990 or r == 9900
end

-- Vollständige Scans: mind. 80 % der Items des größten Scans im Zeitraum. Seiten-Scans erfassen oft
-- nur einen Teil des Auktionshauses - fehlt dort Ware, sähe das wie ein riesiger Abverkauf aus.
local fullCache = { key = nil, set = nil, n = 0 }
function A:FullScanTimes(limit)
    local log = self.db and self.db.scanLog or {}
    local key = #log .. ":" .. tostring(log[#log] and log[#log].t) .. ":" .. math.floor(limit / 3600)
    if fullCache.key == key then return fullCache.set, fullCache.n end
    local maxItems = 0
    for _, s in ipairs(log) do if (s.t or 0) >= limit and (s.items or 0) > maxItems then maxItems = s.items end end
    local set, n = {}, 0
    for _, s in ipairs(log) do
        if (s.t or 0) >= limit and maxItems > 0 and not s.partial and (s.items or 0) >= maxItems * 0.8 then set[s.t] = true; n = n + 1 end
    end
    fullCache.key, fullCache.set, fullCache.n = key, set, n
    return set, n
end

-- liefert { scans, presence (0-1), perDay (Verkäufe/Tag, vorsichtig geschätzt), avgQty, conf, odd }
-- Nur Einträge aus vollständigen Scans zählen. Ein Rückgang der Menge zählt nur zur Hälfte als Verkauf
-- (der Rest ist abgelaufen oder zurückgezogen), und mehr als die Hälfte der üblichen Angebotsmenge
-- pro Tag wird nie angenommen.
function A:GetLiquidity(itemID)
    local F, n = self:HF(itemID)
    local c = liqCache[itemID]
    local hour = math.floor(time() / 3600)
    if c and c.n == n and c.hour == hour then return c.v end
    local now = time()
    local limit = now - self.LIQ_DAYS * 86400
    local full, fullN = self:FullScanTimes(limit)
    -- noch kein Scan im Protokoll (z. B. nur Preise von Mitspielern): alle Einträge zählen
    local useAll = fullN == 0
    local scans, drops, qsum, first, last, prev = 0, 0, 0, nil, nil, nil
    local prevQ, havePrev = nil, false
    for i = 1, n do
        local b = (i - 1) * 5
        local t = F[b + 1]
        if t >= limit and F[b + 5] % 2 == 0 and (useAll or full[t]) then
            local q = FQ(F, i)
            scans = scans + 1
            qsum = qsum + (q or 0)
            first = first or t
            last = t
            if havePrev and prevQ and q and q < prevQ then drops = drops + (prevQ - q) end
            prevQ, havePrev = q, true
        end
    end
    local prev = havePrev and { q = prevQ } or nil
    local span = (first and last and last > first) and math.max(1, (last - first) / 86400) or nil
    local avgQty = scans > 0 and qsum / scans or 0
    local perDay = span and (drops * 0.5) / span or nil
    if perDay then perDay = math.min(perDay, avgQty * 0.5) end
    -- K2 (Befund 10.11. 16:10): Plausibilitätsgrenze - höchstens 2 × Ø-Menge pro Tag und höchstens 25 % des aktuellen
    -- Angebots pro Stunde (= 6 × aktuelle Menge pro Tag); darüber gedeckelt und einmal protokolliert
    local curQty = prev and prev.q or nil
    local implausible
    if perDay then
        local capP = self:PlausibleRate(avgQty, curQty)
        if capP and perDay > capP then
            implausible = perDay
            self:NoteImplausible(itemID, perDay, "geschätzt")
            -- 0.65.111 S2: unplausible Schätzung -> "unbekannt" statt gedeckelter Zahl
            perDay = nil
        end
    end
    local v = {
        scans = scans,
        span = span,
        presence = useAll and (scans > 0 and 1 or 0) or math.min(1, scans / fullN),
        perDay = perDay,
        avgQty = avgQty,
        curQty = curQty,
        implausible = implausible,
    }
    local mv = self:GetMarketValue(itemID)
    v.odd = self:IsOddPrice(mv) or false
    v.crashed = self:IsCrashed(itemID)
    -- selten da, Mondpreis, Preis gerade eingebrochen, oder kaum angeboten und kaum verkauft UND nicht regelmäßig im AH
    if scans < 3 or v.presence < 0.3 or v.odd or v.crashed or (avgQty <= 2 and (perDay or 0) < 0.3 and v.presence < 0.6) then
        v.conf = "gering"
    elseif scans >= 6 and v.presence >= 0.6 and (perDay or 0) >= 1 then
        v.conf = "hoch"
    else
        v.conf = "mittel"
    end
    liqCache[itemID] = { n = n, hour = hour, v = v }
    -- 0.65.111 S2 (TB110: Schätzung ×3–×4,5 über dem gemessenen Absatz): GEMESSEN vor geschätzt - überall, wo der Absatz
    -- aus GetLiquidity kommt (Heute tun, Markt, Verkaufen, Prognose). Erst nach dem Zwischenspeichern (MeasuredRate liest
    -- avgQty über GetLiquidity).
    v.perDaySource = perDay and "geschätzt" or nil
    -- TS111.2: die UNABHÄNGIGE Schätzung bleibt immer in .estimate (für Lernfaktor und Vergleich) - sonst misst sich der
    -- Faktor selbst (seit 0.65.111 stand er überall auf 1.00 und "geschätzt" war gemessen × Abbruch-Faktor)
    v.estimate = perDay
    local VS = self.FullScan
    if VS and VS.SalesRate then
        local okM, m, src, days, players, capped = pcall(VS.SalesRate, VS, itemID)
        if okM and m and m > 0 then
            -- Phase 2 "alle": ohne eigene Messung "alle Spieler" (eigene Quelle, damit nichts es für eigene Messung hält)
            v.perDay, v.perDaySource = m, (src == "alle") and "alle" or "gemessen"
            v.perDayCapped = capped or nil                                -- MU1-5: auf das ganze Angebot begrenzt
            if src ~= "gemessen" then v.allPlayers, v.allDays = players, days end
        end
    end
    return v
end

-- K2: höchster plausibler Absatz pro Tag (2 × Ø-Menge, 25 % des aktuellen Angebots je Stunde) oder nil (ohne Mengen)
A.PLAUS_AVG = 2
A.PLAUS_HOURLY = 0.25
function A:PlausibleRate(avgQty, curQty)
    local cap
    if avgQty and avgQty > 0 then cap = avgQty * self.PLAUS_AVG end
    if curQty and curQty > 0 then
        local c2 = curQty * self.PLAUS_HOURLY * 24
        cap = cap and math.min(cap, c2) or c2
    end
    return cap
end
A.implausibleNoted = A.implausibleNoted or {}
function A:NoteImplausible(itemID, value, source)
    if self.implausibleNoted[itemID] then return end
    self.implausibleNoted[itemID] = true
    if self.Diag then pcall(self.Diag.Add, self.Diag, "ABSATZ-UNPLAUSIBEL", string.format("Item %s · %.1f/Tag · Quelle %s", tostring(itemID), value or 0, tostring(source))) end
end
-- K2: Absatz pro Tag mit ehrlicher Quelle: gemessen (Vollscan, ab 3 Tagen und 6 Std. Abdeckung, plausibel) sonst geschätzt
function A:PerDayInfo(itemID)
    local VS = self.FullScan
    if VS and VS.SalesRate then
        local ok, m, src, days, players, capped = pcall(VS.SalesRate, VS, itemID)
        if ok and m and m > 0 then
            local txt
            if src == "alle" then txt = string.format(L["alle Spieler (mind. %d), %d Tage"], players or 0, days or 0)
            elseif src == "gemessen+alle" then txt = string.format(L["gemessen, %d Tage + mind. %d Spieler"], days or 3, players or 0)
            else txt = string.format(L["gemessen, %d Tage"], days or 3) end
            -- MU1-5: auf das Angebot begrenzt -> grau "unsicher" (4. Wert true)
            if capped then return m, "|cff888888" .. L["unsicher (Absatz über dem Angebot begrenzt)"] .. "|r", true, true end
            return m, txt, true
        end
    end
    local l = self:GetLiquidity(itemID) or {}
    return l.perDay, L["geschätzt"], false
end

-- Kann man dem Marktwert für Kauf-/Verkaufsentscheidungen trauen?
function A:IsReliable(itemID)
    local l = self:GetLiquidity(itemID)
    return l.conf ~= "gering", l
end

-- erwarteter Gewinn pro Tag: Gewinn pro Stück x was man selbst davon pro Tag verkauft.
-- Man ist nicht der einzige Verkäufer: höchstens MARKET_SHARE der geschätzten Tagesverkäufe,
-- höchstens die verfügbare Menge und höchstens so viel, wie 20 % des eigenen Golds kaufen (price).
A.MARKET_SHARE = 0.25
-- K1 (Entscheid des Nutzers 10.11. 15:59): Markt rechnet höchstens mit diesem Anteil des Golds (Prozent, 1–50, Standard 25)
A.MARKET_CAPITAL_DEFAULT = 25
A.MARKET_CAPITAL_MAX = 50
function A:ClampCapitalPct(v)
    v = tonumber(v)
    if not v then return self.MARKET_CAPITAL_DEFAULT end
    return math.max(1, math.min(self.MARKET_CAPITAL_MAX, math.floor(v + 0.5)))
end
function A:MarketCapitalPct()
    local s = self.db and self.db.settings
    return self:ClampCapitalPct(s and s.marketCapital)
end
function A:SetMarketCapitalPct(v)
    local p = self:ClampCapitalPct(v)
    if self.db and self.db.settings then self.db.settings.marketCapital = p end
    if self.Comfort and self.Comfort.InvalidateToday then pcall(self.Comfort.InvalidateToday, self.Comfort) end
    return p
end

function A:ProfitPerDay(itemID, unitProfit, available, price)
    if not unitProfit or unitProfit <= 0 then return 0 end
    local l = self:GetLiquidity(itemID)
    local rate = (l.perDay or 0) * self.MARKET_SHARE
    if rate <= 0 then rate = 0.1 end
    if available and available > 0 then rate = math.min(rate, available) end
    if price and price > 0 and GetMoney then
        local share = self.Comfort and self.Comfort.TODAY_ITEM_SHARE or 0.2
        local afford = math.floor(GetMoney() * share / price)
        rate = math.min(rate, math.max(afford, 0.1))
    end
    return unitProfit * rate
end

-- Text für Tooltip und Listen: "~3/Tag" und Vertrauen
function A:LiquidityText(itemID)
    local l = self:GetLiquidity(itemID)
    local conf = (l.conf == "hoch" and "|cff33dd55" .. L["sicher"] .. "|r") or (l.conf == "mittel" and "|cffffcc33" .. L["mittel"] .. "|r")
        or "|cffff5544" .. L["unsicher"] .. "|r"
    local rate = l.perDay and (l.perDay >= 10 and string.format("~%d", math.floor(l.perDay + 0.5)) or string.format("~%.1f", l.perDay)) or "?"
    local text = string.format(L["%s/Tag verkauft (geschätzt), Marktwert %s"], rate, conf)
    if l.crashed then text = text .. " |cffff5544(" .. L["Preis gerade eingebrochen"] .. ")|r" end
    return text, l
end

-- ------------------------------------------------------------
-- Gebühren (Anweisung "Gebühren klassisch", 9. Nov. 14:30 - ersetzt die frühere Forever-Regel)
-- WoW Forever rechnet wie das klassische WoW (gemessen im Spiel, RECHNUNG 14:19):
--   beim Einstellen: Einzahlung = Händlerpreis × Menge × 5 % je 2 Std. (2/8/24 Std. = 5/20/60 %), in Forever
--                    mindestens 1 Silber je Auktion
--   beim Verkauf:    5 % vom Verkaufspreis ab, die Einzahlung kommt zurück
--   läuft ab:        Einzahlung verloren
-- Erwartete Kosten eines Verkaufs = 5 % + Einzahlung × (1 - p) / p (p = Verkaufschance je Einstellung).
-- Erkennung Forever: Interface 16000-19999 oder WOW_PROJECT_CAMELOT
-- ------------------------------------------------------------
A.FOREVER_MIN_FEE = 100       -- Mindest-Einzahlung je Auktion (Forever, Stand 9.11.) - nur Startwert, siehe A:MinDeposit
-- Blizzard hat angekündigt, das Minimum auf 1c zu senken (Hinweis 16:05, Regelwerk Abschnitt 1 und 9). Darum nie fest:
-- gemessen beim Einstellen (Se:RecordDeposit) und gemerkt in db.minDeposit.
function A:MinDeposit()
    local m = self.db and self.db.minDeposit
    if type(m) == "number" and m >= 1 then return m end
    return self.FOREVER_MIN_FEE
end
A.AH_FEE_PCT = 0.05           -- Fraktions-AH; neutrales AH 15 % (A:CutPct)
A.AH_FEE_PCT_NEUTRAL = 0.15   -- Beutebucht, Gadgetzan, Ewige Warte (Regelwerk Abschnitt 1, Quellen Wiki/AH Ledger)
-- H3: Anteil, den das AH beim Verkauf einbehält. Neutral, wenn das offene bzw. zuletzt benutzte AH neutral ist
-- (A.marketKey "Server|Neutral", gesetzt beim Öffnen des AH).
function A:CutPct()
    local k = self.marketKey
    if type(k) == "string" and k:sub(-8) == "|Neutral" then return self.AH_FEE_PCT_NEUTRAL end
    return self.AH_FEE_PCT
end
function A:IsNeutralAH()
    return self:CutPct() == self.AH_FEE_PCT_NEUTRAL
end
A.DEPOSIT_PCT_PER_2H = 0.05
A.DURATION_HOURS = { 2, 8, 24 }    -- Dauer-Stufe 1/2/3 -> Stunden
function A:IsForever()
    if self.forceForever ~= nil then return self.forceForever end      -- Selbsttest
    -- gemeinsame Erkennung aller GoldSentinel-Addons (GoldSentinelGame.lua); eigene Erkennung nur als Rückfall
    local G = _G.GoldSentinelGame
    if type(G) == "table" and G.flavor then return G.IsForever == true end
    if self._isForever == nil then
        local toc = GetBuildInfo and tonumber((select(4, GetBuildInfo()))) or 0
        local camelot = WOW_PROJECT_ID and WOW_PROJECT_CAMELOT and WOW_PROJECT_ID == WOW_PROJECT_CAMELOT
        self._isForever = (toc >= 16000 and toc < 20000) or camelot or false
    end
    return self._isForever
end
-- true = die Einzahlung kommt beim Verkauf zurück (alle Versionen, auch Forever)
function A:DepositRefunded() return true end

-- Stück pro Auktion für die Gebühr: ein voller Stapel (nicht stapelbar: 1)
-- STAPEL-MERK (Ingametest 18.11. 09:29, T292 "Leinenstoff -> 1 je Auktion (default)", T294 kein Gesamtwert): kurz nach dem
-- Einloggen kennt der Client viele Items noch nicht (GetItemInfo nil) -> Stapelgrösse 1, Ware wurde wie Einzelstück gerechnet.
-- Bekannte Stapelgrössen > 1 werden gemerkt (db.stackMem, nur Zahlen; ändert sich nie) und gelten, solange der Client das Item
-- noch nicht geladen hat. In der Testroutine wird nichts geschrieben (Sandbox).
function A:StackSize(itemID)
    if not itemID then return 1 end
    if GetItemInfo then
        local ok, _, _, _, _, _, _, _, stack = pcall(GetItemInfo, itemID)
        if ok and type(stack) == "number" and stack > 0 then
            local mem = self.db and self.db.stackMem
            if stack > 1 and self.db and not self:InTestRoutine() and (not mem or mem[itemID] ~= stack) then
                self.db.stackMem = mem or {}
                self.db.stackMem[itemID] = stack
            end
            return stack
        end
    end
    local mem = self.db and self.db.stackMem
    local m = type(mem) == "table" and tonumber(mem[itemID])
    if m and m > 1 then return m end
    return 1
end

-- Alt (bis 0.65.41): Forever-Gebühr EINER Auktion max(5 %, 1s). Bleibt nur für alte Aufrufe: jetzt 5 % vom Preis.
function A:ForeverAuctionFee(auctionTotal)
    return math.floor((auctionTotal or 0) * self:CutPct())        -- abgerundet (gemessen: 6279 -> 313)
end

-- Einzahlung beim Einstellen (B2): zuerst Blizzards eigener Wert (Auktionshaus offen), sonst die Formel aus dem
-- Händlerpreis. hours = 2/8/24 Stunden, auctions = Anzahl Auktionen (qty gleich verteilt).
function A:ListingDeposit(itemID, qty, hours, auctions)
    qty = math.max(1, qty or 1)
    hours = hours or 24
    auctions = math.max(1, math.floor(auctions or 1))
    local AH = self.AH
    if AH and self.IsAHOpen and self:IsAHOpen() and itemID and AH.CalculateCommodityDeposit and self:IsCommodityItem(itemID) then
        local step = (hours <= 2 and 1) or (hours <= 8 and 2) or 3
        local ok, dep = pcall(AH.CalculateCommodityDeposit, itemID, step, math.floor(qty / auctions))
        if ok and type(dep) == "number" and dep >= 0 then return dep * auctions, "blizzard" end
    end
    local vendor = self:GetVendorPrice(itemID)
    vendor = (type(vendor) == "number" and vendor > 0) and vendor or 0
    local pct = self.DEPOSIT_PCT_PER_2H * hours / 2
    local per = vendor * (qty / auctions) * pct
    local one = math.floor(per)
    if self:IsForever() then one = math.max(one, self:MinDeposit()) end
    return one * auctions, "formula"
end

-- Stabiler Name für andere Addons (ProfessionSentinel sucht AuctionFee / AHFee):
-- erwartete Verkaufskosten EINER Auktion = 5 % vom Gesamtpreis + erwarteter Einzahlungsverlust (B3, B4).
-- Aufruf: AHAnalyzerPro:AuctionFee(gesamt[, itemID, menge]) oder AHAnalyzerPro.AuctionFee(gesamt[, itemID, menge]).
function A.AuctionFee(a, b, c, d)
    local total, itemID, qty
    if a == A then total, itemID, qty = b, c, d else total, itemID, qty = a, b, c end
    local fee = math.floor((total or 0) * A:CutPct())                -- abgerundet (gemessen)
    if itemID then fee = fee + A:ExpectedDepositLoss(itemID, qty or 1) end
    return fee
end
A.AHFee = A.AuctionFee

-- AH-Anteil beim Verkauf: 5 % vom Verkaufspreis (alle Versionen; auctions nur noch für alte Aufrufe)
function A:SaleFee(itemID, unitPrice, qty, auctions)
    qty = qty or 1
    unitPrice = unitPrice or 0
    return math.floor(unitPrice * qty * self:CutPct())            -- abgerundet (gemessen: 6279 -> 313)
end

-- Erlös nach dem AH-Anteil (die Einzahlung, die bei Rücklauf verloren geht: ExpectedDepositLoss)
function A:NetSale(itemID, unitPrice, qty, auctions)
    local gross = (unitPrice or 0) * (qty or 1)
    return gross - self:SaleFee(itemID, unitPrice, qty, auctions)
end

-- Stück je Auktion (A:AuctionSize) - danach verteilt sich die Einzahlung je Auktion (Forever: Einzahlung beim Einstellen,
-- zurück beim Verkauf, verloren bei Ablauf; der AH-Anteil 5 % fällt beim Verkauf an, siehe A:FeePerPiece).
-- Befund 11:31/11:32 (HOCH): EINE feste, sichtbare Annahme, kein Wechsel ohne Hinweis:
--   1. selbst gewählt im Gewinn-Fenster (1 / 5 / 20 = Stapel), gemerkt je Item: A.db.settings.auctionSize[itemID]
--   2. gelernt: Median der letzten 10 eigenen Einstellungen (Buchhaltung, "deposit"-Buchungen: Stück je Auktion)
--   3. ohne Daten: 1 Stück (vorsichtig)
-- Nie mehr als ein voller Stapel - aber nur, wenn die Stapelgrösse wirklich bekannt ist (sonst kein Wechsel, sobald
-- GetItemInfo die Daten nachlädt). Zweiter Rückgabewert: Quelle "own" / "learned" / "default".
-- H1 (Befund 10.11. 07:35, belegt: "EINSTELLEN Item 10940 · Menge 162 · Auktionen 1"): Im modernen AH (Forever, Retail)
-- wird eine Ware als EINE Auktion mit beliebiger Menge eingestellt - ohne eigene/gelernte Grösse: die ganze Menge
-- (qty, sonst was in den Taschen liegt, mindestens ein Stapel), kein Deckel bei der Stapelgrösse. Altes AH (Era/TBC):
-- Stapel, Deckel bei der Stapelgrösse wie bisher. Einzelstücke: 1.
function A:AuctionSize(itemID, qty)
    local n, src
    local own = self.db and self.db.settings and self.db.settings.auctionSize
    if own and itemID and own[itemID] then n, src = own[itemID], "own" end
    if not n and itemID and self.Ledger and self.Ledger.PostSizes then
        local list = self.Ledger:PostSizes(itemID, 10)
        if #list > 0 then
            table.sort(list)
            n, src = list[math.floor((#list + 1) / 2)], "learned"
        end
    end
    local stack
    if itemID and GetItemInfo then
        local ok, name, _, _, _, _, _, _, st = pcall(GetItemInfo, itemID)
        if ok and name and type(st) == "number" and st >= 1 then stack = st end
    end
    -- STAPEL-MERK: Client kennt das Item noch nicht -> gemerkte Stapelgrösse (nur Waren > 1)
    if not stack and itemID then
        local mem = self.db and self.db.stackMem
        local m = type(mem) == "table" and tonumber(mem[itemID])
        if m and m > 1 then stack = m end
    end
    local modernWare = not self.AH_LEGACY and stack and stack > 1
    if not n and modernWare then
        local have = 0
        local f = self:Global("GetItemCount")
        if f then local okC, c = pcall(f, itemID); if okC and type(c) == "number" then have = c end end
        n, src = math.max(tonumber(qty) or 0, have, stack), "whole"
    end
    n, src = math.max(1, math.floor(tonumber(n) or 1)), src or "default"
    if stack and not modernWare then n = math.min(n, stack) end      -- Deckel nur im alten AH (Stapel)
    return n, src
end
-- Umschalter im Gewinn-Fenster: 1 -> 5 -> 20 (bzw. voller Stapel) -> wieder gelernt/1
function A:CycleAuctionSize(itemID)
    if not (self.db and itemID) then return end
    self.db.settings.auctionSize = self.db.settings.auctionSize or {}
    local own = self.db.settings.auctionSize
    local stack = self:StackSize(itemID)
    local steps = { 1, 5, math.max(1, math.min(20, stack)) }
    local cur = own[itemID]
    local nextV
    if not cur then nextV = steps[1]
    else
        for i, v in ipairs(steps) do if v == cur then nextV = steps[i + 1] end end
        if not nextV and cur ~= steps[#steps] then nextV = steps[1] end
    end
    own[itemID] = nextV            -- nil = wieder automatisch (gelernt bzw. 1)
    return nextV
end

-- Forever: erwartete Verkaufskosten je Stück = 5 % + erwarteter Einzahlungsverlust je Stück (Einzahlung je Auktion,
-- zurück beim Verkauf, verloren bei Ablauf; verteilt
-- sich auf die Stück je Auktion, A:AuctionSize). Andere Versionen: 0 (dort rechnen die alten Wege mit 5 %).
function A:FeePerPiece(itemID, unitPrice)
    if not self:IsForever() then return 0 end
    local per = itemID and self:AuctionSize(itemID) or 1
    local loss = itemID and self:ExpectedDepositLoss(itemID, per) or 0
    return (unitPrice or 0) * self:CutPct() + loss / per
end

-- H4: Netto-Verkaufswert je Stück = Rechenwert (letzter Scan) − AH-Anteil − Einzahlungsrisiko je Stück.
-- SN2115b: EINE Funktion "bester Weg" je Stück nach Gebühren. Alle Anzeigen (Gewinn-Zeile, "… bringt mehr",
-- "Max über Verkaufswert – jeder Kauf verliert ca. …", Sniper) holen ihre Zahl hieraus; keine Stelle rechnet selbst.
-- Eingaben: Entzaubern = D:DealValue (korrigierte Materialpreise; nicht bei veraltetem Hauptmaterial),
-- Verkaufen/Händler = A:RealValue(itemID, 1) (Gebühr, erwartete Neueinstellungen, Händler wenn er mehr zahlt).
-- DE30 (Entscheid des Nutzers 13.11. 22:57): Mindestgewinn für den Weg Entzaubern 30 % - EINE Konstante für alle
-- Stellen (DEBuy, Rechenkern MK:MinRoi/LimitFromNet, Tooltip, Sniper, Markt). Höhere Einstellungen bleiben möglich.
A.DE_MIN_GAIN = 30
-- DE30b ENDGÜLTIG (Entscheide des Nutzers 23:45–23:51): Mindestgewinn je Entzauber-Gruppe (Stufenband + Qualität =
-- welche Materialien herauskommen; Rüstung+Waffe zusammen):
--   gemessen gut (>= 30 Käufe, Gewinn gesamt = Summe Beute / Summe Einsatz − 1 >= 20 %)        -> 20 %
--   gemessen schlecht (>= 30 Käufe, Gewinn gesamt < 20 %)                                      -> 30 %
--   noch nicht gemessen: Tabelle verlässlich (Chance- und Mengenfaktor der gemessenen Gruppen
--   im gewichteten Mittel je innerhalb ±10 % von 1)                                             -> 20 %, sonst 25 %
-- Kein Budget-Deckel (Nutzer 23:49). Im Spiel sieht der Spieler nur "lohnt / lohnt nicht" - Gruppen und Regeln nur
-- im Testbericht.
A.DE_GAIN_PROVEN, A.DE_GAIN_UNPROVEN, A.DE_GAIN_BAD, A.DE_PROVEN_N, A.DE_TABLE_TOL = 20, 25, 30, 30, 0.10
-- ist die Entzauber-Tabelle verlässlich? (gewichtetes Mittel von Chance- und Mengenfaktor der gemessenen Gruppen)
function A:DETableReliable()
    local c = self.deTableRel
    if c and time() - c.t < 300 then return c.ok, c.cf, c.qf, c.n end
    local Fc = self.Forecast
    local okE, R = pcall(Fc and Fc.EvalCached or function() end, Fc)
    if not (okE and R and R.D and Fc.DEFactors) then return false end
    local wc, wq, w = 0, 0, 0
    for k, x in pairs(R.D) do
        if (x.n or 0) >= self.DE_PROVEN_N then
            local okF, cf, qf = pcall(Fc.DEFactors, Fc, k)
            if okF and cf and qf then wc, wq, w = wc + cf * x.n, wq + qf * x.n, w + x.n end
        end
    end
    local cf, qf = w > 0 and wc / w or nil, w > 0 and wq / w or nil
    local ok = cf ~= nil and math.abs(cf - 1) <= self.DE_TABLE_TOL and math.abs(qf - 1) <= self.DE_TABLE_TOL
    self.deTableRel = { t = time(), ok = ok, cf = cf, qf = qf, n = w }
    return ok, cf, qf, w
end
function A:DEGroupInfo(itemID)
    local D, Fc = self.Disenchant, self.Forecast
    if not (D and D.Prior and Fc and Fc.DEGroupStats and itemID) then return nil end
    local okP, _, dk = pcall(D.Prior, D, itemID)
    if not (okP and dk) then return nil end
    local group = Fc:DEGroupOf(dk)
    local g = Fc:DEGroupStats(group)
    local gain = (g and g.sBp > 0) and (g.sLvB / g.sBp - 1) or nil
    local proven = g and g.nB >= self.DE_PROVEN_N and gain ~= nil
    local minGain, why
    if proven then
        if gain >= self.DE_GAIN_PROVEN / 100 then minGain, why = self.DE_GAIN_PROVEN, "gemessen gut"
        else minGain, why = self.DE_GAIN_BAD, "gemessen schlecht" end
    else
        local rel = self:DETableReliable()
        if rel then minGain, why = self.DE_GAIN_PROVEN, "Tabelle verlässlich"
        else minGain, why = self.DE_GAIN_UNPROVEN, "Tabelle weicht ab" end
    end
    return { group = group, n = g and g.nB or 0, gain = gain, proven = proven and true or false, minGain = minGain, why = why }
end
function A:DEMinGain(itemID)
    -- WACH-1b: während einer Kandidaten-Prüfung (Disenchant.matCache) je Entzauber-Gruppe nur einmal (hängt nur an der Gruppe)
    local D = self.Disenchant
    local mc = D and D.MatCacheOn and D:MatCacheOn()          -- S28-LECK: nur für den Besitzer des Zwischenspeichers
    local key
    if mc and itemID then
        local okP, _, dk = pcall(D.Prior, D, itemID)
        key = okP and dk or nil
        mc.mg = mc.mg or {}
        if key and mc.mg[key] then return mc.mg[key] end
    end
    local ok, info = pcall(self.DEGroupInfo, self, itemID)
    local v = (ok and info) and info.minGain or (self.DE_MIN_GAIN or 30)
    if key then mc.mg[key] = v end
    return v
end
function A:ChooseWay(deNet, deStale, sellNet, vendorWins)
    local best, way
    if deNet and deNet > 0 and not deStale then best, way = deNet, "de" end
    if sellNet and (not best or sellNet > best) then best, way = sellNet, vendorWins and "vendor" or "sell" end
    if not best then return nil end
    return math.floor(best + 0.5), way
end
-- RK4 (anweisung-markt-reiter): Wege abwählbar (Einstellungen, Häkchen je Weg, Standard alle an).
-- way: "de" Entzaubern, "craft" Herstellen, "flip" AH-Wiederverkauf, "vendor" Händler-Flip
A.WAYS = { "de", "craft", "flip", "vendor" }
function A:WayOn(way)
    local s = self.db and self.db.settings
    local off = s and s.waysOff
    return not (type(off) == "table" and off[way] == true)
end
function A:SetWayOn(way, on)
    local s = self.db and self.db.settings
    if not s then return end
    s.waysOff = type(s.waysOff) == "table" and s.waysOff or {}
    s.waysOff[way] = (not on) and true or nil
    if not next(s.waysOff) then s.waysOff = nil end
    self.waysVer = (self.waysVer or 0) + 1                -- DataVersion: alle Zwischenspeicher (Lohnt bis, Markt) neu
    if self.Disenchant then self.Disenchant.accSkillT = nil end
    if self.Fire then pcall(self.Fire, self, "DATA_CHANGED") end
end

function A:BestWay(itemID)
    if not itemID then return nil end
    local deNet, deStale
    local D = self.Disenchant
    if D and D.Prior and D.DealValue and D:Prior(itemID) and (not D.WayDE or D:WayDE(itemID)) then
        local okD, _, net = pcall(D.DealValue, D, itemID)
        if okD and net and net > 0 then deNet = net end
        local okS, st = pcall(D.StaleMain, D, itemID)
        deStale = okS and st and true or false
    end
    local okR, rv, _, _, vw = pcall(self.RealValue, self, itemID, 1)
    if not okR then rv, vw = nil, nil end
    local v, way = self:ChooseWay(deNet, deStale, rv, vw)
    return v, way, { de = deNet, deStale = deStale, sell = rv, vendorWins = vw }
end

function A:NetSellValue(itemID)
    local v = itemID and self:RealPrice(itemID)
    if not v then return nil end
    if self:IsForever() then return v - (self:FeePerPiece(itemID, v) or 0) end
    return v * (1 - self:CutPct())
end

-- Alt (bis 0.65.17): bleibt für alte Aufrufe (gibt die Gebühr unverändert zurück).
function A:ApplyMinFee(deposit)
    return deposit
end

-- Einzahlung, die im Schnitt verloren geht (je Verkauf von qty Stück): Einzahlung × (1 - p) / p
-- p = Verkaufschance je Einstellung (eigene Quote, sonst Markt-Absatz; A:ExpectedListings = 1 / p).
-- Dauer: die Vorbelegung im Verkaufen-Fenster (A:DefaultDuration), sonst 24 Std.
function A:ExpectedDepositLoss(itemID, qty, listings)
    if not itemID then return 0 end
    if not self:IsForever() then
        -- andere Versionen unverändert (Blizzards Einzahlung, Dauer-Stufe 2, Verkaufschance sonst 50 %)
        local Se = self.Seller
        if not (Se and Se.Deposit) then return 0 end
        local ok, dep = pcall(Se.Deposit, Se, itemID, 2, qty or 1, true, nil)
        if not ok or not dep or dep <= 0 then return 0 end
        local p = 0.5
        local r = self.Comfort and self.Comfort.SellChance and self.Comfort:SellChance(itemID)
        if r and r.rate then p = math.max(0.1, math.min(1, r.rate / 100)) end
        return math.floor(dep * (1 - p) / p + 0.5)
    end
    local size = self:AuctionSize(itemID, qty)
    local auctions = math.max(1, math.ceil((qty or 1) / math.max(size, 1)))
    local hours = self:EvalHours(itemID, qty or 1)       -- Punkt 1: 24 Std., wenn gleich teuer
    local dep = self:ListingDeposit(itemID, qty or 1, hours, auctions)
    if not dep or dep <= 0 then return 0 end
    listings = listings or self:ExpectedListings(itemID, qty)
    return math.floor(dep * (listings - 1) + 0.5)
end

-- Liste ohne unglaubwürdige Gewinne (Felder price und ref)
function A:WithoutAbsurd(list, keepUnsure)
    local out = {}
    for _, d in ipairs(list or {}) do
        if not self:IsAbsurdProfit(d.price, d.ref) and not self:IsOddPrice(d.ref)
            and (keepUnsure or d.vendorDeal or d.deDeal or not d.itemID or self:IsReliable(d.itemID)) then
            table.insert(out, d)
        end
    end
    return out
end

-- Items, die im Auktionshaus gerade billiger sind als beim Händler.
-- Nur aktuelle Preise (letzte 2 Std.), damit keine alten Angebote auftauchen.
-- HP-2: alte Form für Profit-Reiter/Chat/Selbsttest - jetzt aus der EINEN Rechnung A:VendorDeals (bestätigter, plausibler
-- Händlerpreis; Menge = Stücke unter dem Händlerpreis je Preisstufe). profit = Gewinn je Stück am günstigsten Angebot,
-- total = Gewinn über alle diese Stücke, quantity = diese Stücke (atLeast = mindestens so viele, genaue Stufen fehlen)
function A:FindVendorDeals()
    local out = {}
    for _, d in ipairs(self:VendorDeals()) do
        out[#out + 1] = { itemID = d.itemID, name = d.name, price = d.price, vendor = d.vendor, quantity = d.qty,
            profit = d.vendor - d.price, pct = (d.vendor - d.price) / d.vendor * 100, total = d.profit, cost = d.cost,
            atLeast = d.atLeast, age = d.age, steps = d.steps, source = d.source }
    end
    return out
end

-- "Heute tun": Angebote UNTER dem Händlerverkaufspreis (kaufen und beim Händler verkaufen, kein AH-Anteil).
-- Quellen: letzter Scan, letzte Suche im Einkauf, aktuelle Angebote des gewählten Items (genau, je Angebot).
-- Nur Items mit Händlerpreis, nur frische Preise. Gewinn = (Händlerpreis - Kaufpreis) x Menge.
-- Ohne genaue Angebote ist nur der günstigste Preis bekannt: dann 1 Stück (mindestens, vorsichtig).
A.VENDOR_FLIP_MIN = 1000      -- Standard-Mindestgewinn je Angebot: 10 Silber
function A:VendorFlipMin()
    local v = self.db and self.db.settings and self.db.settings.vendorFlipMin
    if v == nil then return self.VENDOR_FLIP_MIN end
    return v
end
-- TU1 L-HAENDLER (Fall Eisengranate: AH 1s83, Händler-Tabelle 5s): Händlerpreis über dem Doppelten des Marktwerts ist
-- vermutlich falsch (sonst kauften alle zum Händler weg) -> keine Händler-Flips damit
function A:VendorPlausible(id, v)
    v = v or self:GetVendorPrice(id)
    if type(v) ~= "number" or v <= 0 then return false end
    -- MA3-G: beim echten Händlerverkauf gemessen abweichend -> Händler-Weg für dieses Item gesperrt (bis eine Messung stimmt)
    local X = self.Extras
    local vg = X and X.GoldData and X:GoldData()
    if vg and vg[id] and vg[id].bad then return false end
    local mv = self:GetMarketValue(id)
    return not (mv and mv > 0 and v > mv * 2)
end
-- TU1-HAENDLER (Supervisor 16.11. 23:10, Regel des Nutzers wirtschaft-forever §3 "Händlerpreis = Untergrenze dessen, was ein
-- Item SICHER wert ist"): Händlerpreis als Untergrenze / Weg "Händler" nur, wenn (a) vom Spiel bestätigt (GetItemInfo, nicht nur
-- Tabelle) ODER plausibel (<= 2 × Marktwert) UND (b) beim echten Händlerverkauf nicht abweichend gemessen (MA3-G).
-- Spiel-bestätigt bleibt immer Untergrenze (K3). Rückgabe: true/false, Grund ("gemessen" / "unbestaetigt")
function A:VendorSafe(id, v)
    v = v or self:GetVendorPrice(id)
    if type(v) ~= "number" or v <= 0 then return false end
    local X = self.Extras
    local vg = X and X.GoldData and X:GoldData()
    if vg and vg[id] and vg[id].bad then return false, "gemessen" end
    if not (self.vendorFromTable and self.vendorFromTable[id]) then return true end
    local mv = self:GetMarketValue(id)
    if mv and mv > 0 and v > mv * 2 then return false, "unbestaetigt" end
    return true
end
-- HP-2 (Nutzer 10:33): genaue Stufen unter dem Händlerpreis v für ein Item: { {Stückpreis, Stück}, ... } aufsteigend,
-- Zeitpunkt der Daten, Quelle, partial (= über den gespeicherten Stufen liegt noch Menge mit unbekanntem Preis).
-- Quellen (die jüngste gilt, alle nur frisch = höchstens FRESH_SECONDS alt): Angebote des Items im Einkauf (je Angebot,
-- ohne eigene und Lockangebote), Preisprüfung des Verkaufens, Preisleiter des letzten Vollscans. nil = keine genauen Daten.
function A:VendorSteps(itemID, v)
    local fresh = time() - self.FRESH_SECONDS
    local best
    local function consider(steps, t, source, partial)
        if not best or t > best.t then best = { steps = steps, t = t, source = source, partial = partial or false } end
    end
    local B = self.Buy
    local d = B and B.detail
    if d and d.itemID == itemID and d.listings and not d.loading and (d.time or 0) >= fresh then
        local st = {}
        for _, l in ipairs(d.listings) do
            local free = math.max(0, (l.qty or 1) - (l.ownQty or 0))
            if l.own and not l.ownQty then free = 0 end
            if not l.bait and l.price and l.price > 0 and l.price < v and free > 0 then st[#st + 1] = { l.price, free } end
        end
        consider(st, d.time, "angebote")
    end
    local Se = self.Seller
    local pr = Se and Se.prices and Se.prices[itemID]
    if pr and pr.listings and pr.stamp and pr.stamp >= fresh then
        local st = {}
        for _, l in ipairs(pr.listings) do
            if not l.bait and l.price and l.price > 0 and l.price < v then
                local q = math.max(0, (l.qty or 1) - (l.own and (l.ownQty or l.qty or 0) or 0))
                if q > 0 then st[#st + 1] = { l.price, q } end
            end
        end
        consider(st, pr.stamp, "suche")
    end
    local VS = self.FullScan
    if VS and VS.Ladder then
        local ok, ls, age = pcall(VS.Ladder, VS, itemID)
        if ok and ls and age and age <= self.FRESH_SECONDS and ls.steps and #ls.steps > 0 then
            local st, prev, last = {}, 0, nil
            for _, step in ipairs(ls.steps) do
                local q = step[2] - prev
                prev, last = step[2], step[1]
                if step[1] < v and q > 0 then st[#st + 1] = { step[1], q } end
            end
            -- Menge über der letzten gespeicherten Stufe: Preis unbekannt (nie geschätzt); liegt die letzte Stufe noch unter
            -- dem Händlerpreis, können es mehr Stücke sein -> "mindestens"
            consider(st, time() - age, "vollscan", (ls.qty or 0) > prev and last ~= nil and last < v)
        end
    end
    if not best then return nil end
    table.sort(best.steps, function(x, y) return x[1] < y[1] end)
    return best.steps, best.t, best.source, best.partial
end

-- HP-2: die EINE Rechnung für Händler-Schnäppchen (Profit-Reiter, "Heute tun", Markt > Händler, Sniper-"+").
-- Je Item: price = günstigstes Angebot, qty = Stücke unter dem Händlerpreis (genau je Stufe; ohne genaue Daten 1 und
-- atLeast), cost = Σ Stückpreis, profit = Σ (Händlerpreis − Stückpreis), age = Alter der Daten in Sekunden, steps.
-- Nur mit vom Spiel bestätigtem und plausiblem Händlerpreis (HP1), nur frische Preise.
function A:VendorDeals()
    local cand = {}
    local fresh = time() - self.FRESH_SECONDS
    local function vendorOf(id)
        local v = self:GetVendorPrice(id)
        if type(v) == "number" and v > 0 and not self.vendorFromTable[id] and self:VendorPlausible(id, v) then return v end
    end
    local function put(id, price, t, source)
        -- Tempo (s92, 0.65.224): erst die billige Prüfung (günstigstes Angebot unter dem Händlerpreis?), dann bestätigt und
        -- plausibel (VendorPlausible rechnet den Marktwert) - sonst lief der Marktwert für ALLE Items nach jedem Scan
        local raw = self:GetVendorPrice(id)
        if price and (type(raw) ~= "number" or price >= raw) then cand[id] = nil; return end
        local v = vendorOf(id)
        if not v then cand[id] = nil; return end
        -- günstigstes Angebot nicht unter dem Händlerpreis -> nichts darunter (Stufen nur prüfen, wenn es sich lohnt)
        if price and price >= v then cand[id] = nil; return end
        local steps, ts, src, partial = self:VendorSteps(id, v)
        local e
        if steps and ts >= (t or 0) - 120 then
            -- genaue Daten (mindestens so neu wie der Preis): genau diese Stücke; leer = nichts mehr unter dem Händlerpreis
            if #steps == 0 then cand[id] = nil; return end
            e = { steps = steps, t = ts, source = src, atLeast = partial, exact = true }
        else
            if not price or price <= 0 or price >= v then cand[id] = nil; return end
            -- nur der günstigste Preis bekannt (Menge gilt für ALLE Stufen): sicher ist 1 Stück zu diesem Preis
            e = { steps = { { price, 1 } }, t = t, source = source, atLeast = true, exact = false }
        end
        local qty, cost, profit = 0, 0, 0
        for _, st in ipairs(e.steps) do
            qty, cost, profit = qty + st[2], cost + st[1] * st[2], profit + (v - st[1]) * st[2]
        end
        e.itemID, e.vendor, e.price, e.qty, e.cost, e.profit = id, v, e.steps[1][1], qty, cost, profit
        e.age = math.max(0, time() - (e.t or time()))
        cand[id] = e
    end
    -- 1) letzter Scan
    if self.db and self.db.marketData then
        for itemID in pairs(self.db.marketData) do
            self:Pause()
            local price, _, t = self:GetCurrent(itemID)
            if price and t and t >= fresh then put(itemID, price, t, "scan") end
        end
    end
    -- 2) letzte Suche im Einkauf (neuer als der Scan)
    local B = self.Buy
    if B and B.results and (B.resultsTime or 0) >= fresh then
        for _, r in ipairs(B.results) do
            if r.itemID and r.price then put(r.itemID, r.price, B.resultsTime, "suche") end
        end
    end
    -- 3) Angebote des gewählten Items (genau je Angebot) - auch ohne Scan-Preis
    local d = B and B.detail
    if d and d.itemID and d.listings and not d.loading and (d.time or 0) >= fresh then put(d.itemID, nil, d.time, "angebote") end
    local out = {}
    for _, c in pairs(cand) do
        if c.profit > 0 then
            c.name = self:GetItemName(c.itemID)
            out[#out + 1] = c
        end
    end
    return out
end

-- HP-2: Händler-Schnäppchen auf ein Budget kürzen - günstigste Stufen zuerst, nie über das Budget.
-- Rückgabe: Stück, Kosten, Gewinn
function A:VendorCut(d, budget)
    local q, cost, profit = 0, 0, 0
    for _, st in ipairs(d.steps or {}) do
        local n = math.min(st[2], math.floor((budget - cost) / st[1]))
        if n <= 0 then break end
        q, cost, profit = q + n, cost + st[1] * n, profit + (d.vendor - st[1]) * n
        if n < st[2] then break end
    end
    return q, cost, profit
end

-- HP-2 "+" -> Sniper-Ziel (Entscheid Supervisor 21:48): Max = Händlerpreis − 1c (nie ≥ Händlerpreis); genaue Stufen: Menge =
-- diese Stücke, Budget = Σ ihrer Preise (mindestens ein Max); ohne genaue Stufen ("≥"): alles unter dem Händlerpreis bis zur
-- angebotenen Menge (max. 1000), Budget = Max × Menge. IMMER höchstens die Item-Grenze (je Item 10 % des Golds, MK:ItemBudget).
-- Rückgabe: maxPrice, qty, budget oder nil, Grund (Item-Grenze kleiner als ein Stück)
function A:VendorTargetPlan(itemID, vendor, quantity, cost, atLeast)
    local maxPrice = vendor - 1
    if maxPrice < 1 then return nil, "kein Händlerpreis" end
    local qty, budget
    if atLeast then
        local _, all = self:GetCurrent(itemID)
        qty = math.max(1, math.min(math.max(all or 0, quantity or 1), 1000))
        budget = maxPrice * qty
    else
        qty = math.max(1, math.min(quantity or 1, 1000))
        budget = math.max(maxPrice, math.min(cost or maxPrice * qty, maxPrice * qty))
    end
    local MK = self.Core
    local cap = MK and MK.ItemBudget and MK:ItemBudget() or nil
    if cap then
        if cap < maxPrice then return nil, "Item-Grenze" end
        if budget > cap then budget = cap end
    end
    return maxPrice, qty, budget
end

function A:VendorFlipOffers(minProfit, max)
    minProfit = minProfit or self:VendorFlipMin()
    local out = {}
    for _, c in ipairs(self:VendorDeals()) do
        if c.profit >= minProfit and c.profit > 0 then out[#out + 1] = c end
    end
    table.sort(out, function(a, b)
        if a.profit ~= b.profit then return a.profit > b.profit end
        return a.itemID < b.itemID
    end)
    for i = #out, (max or 10) + 1, -1 do out[i] = nil end
    return out
end

-- ------------------------------------------------------------
-- Zwischenspeicher für grosse Listen (Befund 20:15 A3: Marktliste 117 ms, "Heute tun" 314 ms bei 5220 Items):
-- gilt bis zum nächsten Datenstand. Ist er veraltet, kommt sofort der alte Stand zurück und der neue wird im
-- Hintergrund (A:Job, in Portionen) gerechnet; danach CACHE_UPDATED (die Oberfläche zeichnet neu). Nur ohne alten
-- Stand (erster Aufruf) oder mit fresh = true wird sofort gerechnet.
-- ------------------------------------------------------------
A.valueCache = {}
-- async = true (TB118-1, Anzeigen): nie synchron rechnen - ohne gültigen Stand im Hintergrund rechnen und den alten
-- (oder nil) zurückgeben; fertig -> CACHE_UPDATED. Sonst (Prüfungen, Berichte) wie bisher.
function A:CachedValue(name, version, compute, fresh, async)
    local c = self.valueCache[name]
    if c and c.version == version and not fresh then return c.value, true end
    if (fresh or not c) and not async then
        local v = compute()
        self.valueCache[name] = { version = version, value = v }
        return v, true
    end
    if not self:HasJob("cache:" .. name) then
        -- ohne pcall: in Lua 5.1 darf A:Pause nicht über ein pcall hinweg abgeben; Fehler meldet A:Job selbst
        self:Job("cache:" .. name, function()
            local v = compute()
            A.valueCache[name] = { version = version, value = v }
            A:Fire("CACHE_UPDATED", name)
        end)
    end
    return c and c.value or nil, false
end

function A:DataVersion()
    local led = self.db and self.db.ledger and self.db.ledger.entries
    return table.concat({ self.priceVersion or 0, self.db and self.db.lastScanTime or 0, led and #led or 0,
        tostring(self.marketKey), self.waysVer or 0 }, "|")
end

-- TB138b-3: Zeilen je Item wiederverwenden (vorher 6000+ neue Tabellen je Vollscan); Liste selbst ist neu
local itemRowPool = {}
local function BuildItemRows()
    local list = {}
    for itemID in pairs(A.db.marketData) do
        A:Pause()
        local price, qty, t = A:GetCurrent(itemID)
        if price then
            local r = itemRowPool[itemID]
            if not r then r = {}; itemRowPool[itemID] = r end
            r.itemID = itemID
            r.name = A:GetItemName(itemID)
            r.price = price
            r.quantity = qty or 0
            r.seen = t
            r.change = A:GetChangeSinceLastScan(itemID)
            r.day = A:GetTrend(itemID, 86400)
            r.week = A:GetTrend(itemID, 7 * 86400)
            r.month = A:GetTrend(itemID, 30 * 86400)
            r.points = A:HistCount(itemID)
            r.market = A:GetMarketValue(itemID)
            r.pct = A:GetMarketPercent(itemID, price)
            r.vendor = A:GetVendorPrice(itemID)
            list[#list + 1] = r
        end
    end
    -- Items, die es nicht mehr gibt (anderer Markt, Verdichtung): Zeile freigeben
    for id in pairs(itemRowPool) do if not A.db.marketData[id] then itemRowPool[id] = nil end end
    return list
end

-- Alle Items als Liste mit Kennzahlen (für Tabellen). Neue Liste (Zeilen geteilt, nur lesen); fresh = sofort rechnen.
function A:BuildItemList(filterText, fresh)
    if not self.db then return {} end
    local rows = self:CachedValue("itemlist", self:DataVersion(), BuildItemRows, fresh)
    local pq = self.Names and filterText and filterText ~= "" and self.Names:PrepareQuery(filterText) or nil
    local list = {}
    for i, r in ipairs(rows or {}) do
        if not pq or self.Names:Matches(r.itemID, pq) then list[#list + 1] = r end
        if i % 500 == 0 then self:Pause() end              -- T126-TÄTER: in einer Aufgabe Pausen (sonst ohne Wirkung)
    end
    return list
end

-- vorab im Hintergrund rechnen, sobald sich die Daten ändern (dann ist das Öffnen der Liste schnell)
A:On("SCAN_FINISHED", function() A:BuildItemList() end)
-- SANDBOX-2 (Supervisor 17.11.2026 08:30, 0.65.304): Test-IDs (ab 990000000, nie ein echtes Item) aus den EIGENEN Daten entfernen.
-- Belegt im Daten-Repo: T185 liess 14 Test-Händlerpreise (999990118–999990131) seit 12.11. in vendorPrices; T504 gab am 16.11. einen
-- nachgespielten Vollscan mit 1050 Test-Items (990018001–990019050) an den gemeinsamen Markt-Baustein (Ursachen behoben in 0.65.301 /
-- 0.65.304). Läuft bei jedem Laden (nur lesen, wenn nichts da ist), nie während der Testroutine; Protokoll TEST-IDS.
A.TEST_ID_MIN = 990000000
function A:PurgeTestIDs(db)
    local real = db == nil or db == self.db
    db = db or self.db
    if type(db) ~= "table" or (real and self.InTestRoutine and self:InTestRoutine()) then return nil end
    local min = self.TEST_ID_MIN
    local out = { vendor = 0, market = 0, gsm = 0, export = 0 }
    local function purge(t, key)
        if type(t) ~= "table" then return end
        for k in pairs(t) do
            local n = tonumber(k)
            if n and n >= min then t[k] = nil; out[key] = out[key] + 1 end
        end
    end
    purge(db.vendorPrices, "vendor")
    purge(db.marketData, "market")
    local g = db.gsMarkt
    if type(g) == "table" then
        for _, fac in pairs(type(g.f) == "table" and g.f or {}) do purge(type(fac) == "table" and fac.i, "gsm") end
        -- Export-Zeilen nur ganz entfernen, wenn ALLE Items Test-IDs sind (Basis 36, ab "gdf4w0"); gemischte bleiben (Protokoll)
        if type(g.export) == "table" then
            for i = #g.export, 1, -1 do
                local line = g.export[i]
                if type(line) == "string" then
                    local body = line:match("^GSMARKT%d*|[^|]*|[^|]*|[^|]*|[^|]*|[^|]*|[^|]*|(.*)$")
                    local test, real = 0, 0
                    for tok in (body or ""):gmatch("([%w]+),[^;]*") do
                        local n = tonumber(tok, 36)
                        if n and n >= min then test = test + 1 elseif n then real = real + 1 end
                    end
                    if test > 0 and real == 0 then table.remove(g.export, i); out.export = out.export + 1 end
                end
            end
        end
    end
    if out.vendor + out.market + out.gsm + out.export > 0 and self.Diag then
        pcall(self.Diag.Add, self.Diag, "TEST-IDS", string.format("entfernt: %d Händlerpreise, %d Marktdaten, %d gsMarkt-Items, %d Export-Zeilen",
            out.vendor, out.market, out.gsm, out.export))
    end
    return out
end
-- 5 s nach READY: nach /reload mitten in der Testroutine schreibt deren Sicherung (RecoverAfterReload) zuerst zurück
A:On("READY", function() if C_Timer and C_Timer.After then C_Timer.After(5, function() pcall(A.PurgeTestIDs, A) end) end end)
A:On("READY", function() if A.Job then A:Job("cache:warm", function() A:BuildItemList() end) end end)

-- ------------------------------------------------------------
-- Auktionshaus-Schnittstelle (abgesichert für Custom-Clients)
-- ------------------------------------------------------------
A.ahOpen = false

function A:IsAHOpen()
    -- Ereignisse (AUCTION_HOUSE_SHOW/CLOSED bzw. Öffnen/Schließen des Fensters) sind maßgeblich
    if self.ahOpen then return true end
    -- Rückfall, falls kein Ereignis kam: Auktionshaus-Fenster sichtbar
    -- (direkt nach dem Schließen ist es oft noch kurz sichtbar -> 1 Sek. ignorieren)
    local ah = (type(AuctionHouseFrame) == "table" and AuctionHouseFrame) or (type(AuctionFrame) == "table" and AuctionFrame)
    if ah and ah.IsShown and ah:IsShown() then
        return not self.ahClosedAt or (GetTime() - self.ahClosedAt) > 1
    end
    return false
end


function A:CheckAPI()
    local C = A.AH
    self.api = {
        C_AuctionHouse = C ~= nil,
        SendBrowseQuery = C ~= nil and C.SendBrowseQuery ~= nil,
        GetBrowseResults = C ~= nil and C.GetBrowseResults ~= nil,
        HasFullBrowseResults = C ~= nil and C.HasFullBrowseResults ~= nil,
        RequestMoreBrowseResults = C ~= nil and C.RequestMoreBrowseResults ~= nil,
        GetNumBrowseResults = C ~= nil and C.GetNumBrowseResults ~= nil,
    }
    return self.api
end

-- nur die Anzahl (billig) - die ganze Liste wird erst am Ende einmal abgeholt
local function SafeCountResults()
    if A.AH and A.AH.GetNumBrowseResults then
        local ok, n = pcall(A.AH.GetNumBrowseResults)
        if ok and type(n) == "number" then return n end
    end
    if not (A.AH and A.AH.GetBrowseResults) then return 0 end
    local ok, results = pcall(A.AH.GetBrowseResults)
    return (ok and type(results) == "table") and #results or 0
end

local function SafeGetResults()
    if not (A.AH and A.AH.GetBrowseResults) then return {} end
    local ok, results = pcall(A.AH.GetBrowseResults)
    if ok and type(results) == "table" then return results end
    return {}
end

local function SafeHasFull()
    if not (A.AH and A.AH.HasFullBrowseResults) then return nil end
    local ok, full = pcall(A.AH.HasFullBrowseResults)
    if ok then return full end
    return nil
end

local function SafeRequestMore()
    if not (A.AH and A.AH.RequestMoreBrowseResults) then return false end
    return (pcall(A.AH.RequestMoreBrowseResults))
end

-- ------------------------------------------------------------
-- Cooldown (15 Minuten, gespeichert mit time(), übersteht /reload und Neustart)
-- ------------------------------------------------------------
function A:GetCooldownRemaining()
    if not self.db then return 0 end
    local remaining = self.SCAN_COOLDOWN - (time() - (self.db.lastScanTime or 0))
    if remaining < 0 then remaining = 0 end
    return remaining
end

function A:IsScanReady()
    return self:GetCooldownRemaining() <= 0
end

-- ------------------------------------------------------------
-- Anfrage-Drossel des Servers: "bereit" für die nächste Anfrage?
-- (gibt es den Client-Aufruf nicht, gilt immer "bereit")
-- ------------------------------------------------------------
function A:QueryReady()
    local C = A.AH
    if C and C.IsThrottledMessageSystemReady then
        local ok, ready = pcall(C.IsThrottledMessageSystemReady)
        if ok then return ready and true or false end
    end
    return true
end

-- ------------------------------------------------------------
-- Gemeinsames Tempo für alle Suchen (Sniper, Wächter, Einkauf, Verkaufen):
-- immer an die Grenze, die der Server zulässt - und zwar selbst anpassend:
-- * Server meldet seine Drossel (modernes AH, Classic: CanSendAuctionQuery)
--   -> kein eigener Abstand, gesucht wird, sobald der Server "bereit" sagt
-- * sonst: Abstand wird nach jeder Antwort ein Stück kleiner (tastet sich an die
--   Grenze heran) und bei verworfenen Anfragen/Fehlern verdoppelt
-- So läuft es in jeder WoW-Version so schnell, wie der jeweilige Server es erlaubt.
-- ------------------------------------------------------------
local pace = { last = -100, errors = 0, answers = 0 }
A.pace = pace
A.GAP_MIN_THROTTLED = 0      -- Server sagt selbst, wann er bereit ist
A.GAP_MIN_FIXED = 0.2        -- ohne Drossel-Meldung: so knapp darf es höchstens werden
A.GAP_START_FIXED = 1.0      -- Startwert ohne Drossel-Meldung
A.GAP_MAX = 8                -- mehr Bremse gibt es nicht
A.GAP_SHRINK = 0.85          -- nach jeder Antwort: Abstand x 0,85
A.GAP_GROW = 2               -- nach einem Fehler: Abstand x 2
A.GAP_MAX_THROTTLED = 2      -- SN-B1 (Supervisor 00:36): mit Drossel-Schnittstelle entscheidet der Server, höchstens 2 s
A.GAP_OK_RESET = 2           -- SN-B1: mit Drossel-Schnittstelle nach 2 Antworten ohne Fehler wieder das Minimum
A.GAP_RESET = 10             -- SN-B1: 10 s ohne neuen Fehler -> Abstand wieder wie vor dem Fehler (nicht über Minuten abbauen)

function A:HasThrottleAPI()
    return A.AH ~= nil and A.AH.IsThrottledMessageSystemReady ~= nil
end

local function MinGap()
    return A:HasThrottleAPI() and A.GAP_MIN_THROTTLED or A.GAP_MIN_FIXED
end

function A:QueryGap()
    if not pace.gap then pace.gap = self:HasThrottleAPI() and self.GAP_MIN_THROTTLED or self.GAP_START_FIXED end
    -- SN-B1 (Nutzer 00:19 "nur noch alle 8 s"): nach einem Fehler wird der Abstand verdoppelt (bis 8 s). Bisher baute er sich nur
    -- je Antwort um 15 % ab - bei 8 s Abstand dauerte das Minuten. Jetzt: 10 s ohne neuen Fehler -> Abstand wie vor dem Fehler.
    if pace.errT and pace.gapBefore and GetTime() - pace.errT >= self.GAP_RESET then
        if pace.gap > pace.gapBefore then pace.gap = pace.gapBefore end
        pace.errT, pace.gapBefore, pace.errWhy = nil, nil, nil
    end
    return pace.gap
end
-- SN-B1: Grund des Wartens in Worten (Statuszeile des Snipers)
function A:QueryWaitText(prio)
    if not self:QueryReady() then return L["Server noch nicht bereit"] end
    if not self:QueryBudgetFree(prio) then return string.format(L["Server-Grenze erreicht (%d Suchen pro Minute)"], self.QUERY_LIMIT) end
    local gap = math.max(self:QueryGap(), self:QuerySpacing())
    if pace.errT and pace.gapBefore and pace.gap > pace.gapBefore then
        return string.format(L["Server bremst nach %s – Abstand %.1f s, wieder schnell in %d s"], tostring(pace.errWhy or L["Fehler"]), gap,
            math.max(0, math.ceil(self.GAP_RESET - (GetTime() - pace.errT))))
    end
    return L["Kurz warten (max. eine Suche alle "] .. string.format("%.1f", gap) .. L[" Sek.)."]
end
-- SN-B2/SN-B1: Kauf-Aufrufe (Reservieren, Bestätigen, Abbrechen, Sofortkauf) merken - eine AH-Fehlermeldung danach gehört
-- zum Kauf (Preis gestiegen, Angebot weg) und ist keine Server-Bremse für die Suchen
function A:NoteTrade() self.lastTradeT = GetTime() end
-- SN-B1 (Supervisor 00:36): eine Fehlermeldung des Auktionshauses ist nie eine Server-Bremse (Preis gestiegen, Angebot weg,
-- nicht genug Gold ...). Bremse nur bei AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED und Suchen ohne Antwort.
function A:AHErrorIsThrottle()
    return false
end

-- H2: höchstens 100 Suchen pro Minute (Forever, Hearthproof/Beta: "Search queries are restricted to 100 calls per
-- minute"). EIN gleitendes Fenster (60 s) für alle Suchen; Grenze 90 (Reserve). Der Sniper hat Vorrang: alle anderen
-- (Wächter, Scan, Einkauf, Preis prüfen) nur bis QUERY_LIMIT − QUERY_SNIPER_RESERVE.
A.QUERY_WINDOW = 60
A.QUERY_LIMIT = 90
A.QUERY_SNIPER_RESERVE = 10
A.QueryClock = function() return GetTime() end      -- Nahtstelle für Tests
pace.window = {}
function A:QueryLimit()
    if self:IsForever() then return self.QUERY_LIMIT end
    return nil
end
function A:QueriesLastMinute()
    local now, w = self.QueryClock(), pace.window
    while w[1] and now - w[1] >= self.QUERY_WINDOW do table.remove(w, 1) end
    return #w
end
function A:QueryBudgetFree(prio)
    local limit = self:QueryLimit()
    if not limit then return true end
    local cap = (prio == "sniper") and limit or (limit - self.QUERY_SNIPER_RESERVE)
    local n = self:QueriesLastMinute()
    if n < cap then return true end
    if not pace.limitNoted or self.QueryClock() - pace.limitNoted >= self.QUERY_WINDOW then
        pace.limitNoted = self.QueryClock()
        if self.Diag then self.Diag:Add("SUCHEN", string.format("Grenze erreicht: %d in 60 s (max je Minute = %d)", n, limit)) end
    end
    return false
end

-- gleichmässig verteilen statt 90 Suchen in wenigen Sekunden und dann eine Minute Stillstand (Sniper-Treffer
-- gelten nur 3 s, Anweisung 17:35 C2): mindestens 60 s / Grenze zwischen zwei Suchen
function A:QuerySpacing()
    local limit = self:QueryLimit()
    return limit and (self.QUERY_WINDOW / limit) or 0
end

-- UI-V1b: Sekunden, bis die nächste Suche erlaubt ist (0 = jetzt; Budget/Bereitschaft nicht eingerechnet)
function A:QueryWait()
    local gap = math.max(self:QueryGap(), self:QuerySpacing())
    return math.max(0, gap - (GetTime() - pace.last))
end
-- GSL3-2 (Supervisor 16:50, "den Spieler NIE blockieren"): der Spieler benutzt selbst einen anderen Reiter im AH (verkaufen,
-- suchen, Meine Auktionen) -> der Sniper pausiert seine Selbst-Suche USER_PAUSE s ab der letzten Eingabe (statt um die Drossel
-- zu konkurrieren); Rasten auf einen wartenden Treffer kaufen weiter.
A.USER_PAUSE = 30
function A:NoteUserAH(kind)
    if self.InTestRoutine and self:InTestRoutine() and not self.userAHTest then return end   -- Tests lösen keine Pause aus
    self.userAH = { t = GetTime(), kind = kind or "suchen" }
end
-- S4 (Befund 21.11. 06:35): "du suchst gerade" nur noch für Suchen AUSSERHALB von AHS (Blizzard-Fenster, andere Addons). Nachhaken an den
-- Suchbefehlen (hooksecurefunc: Blizzard läuft unverändert); eigene Aufrufe erkennt der Aufrufstapel (Datei im AHS-Ordner).
-- SearchForFavorites zählt nicht (Blizzard schickt sie beim Öffnen des AH von selbst).
A.BLIZZ_SEARCH = { SendBrowseQuery = "suchen", SendSearchQuery = "suchen", SearchForItemKeys = "suchen", SendSellSearchQuery = "verkaufen" }
function A:IsOwnCall(stack)
    stack = string.lower(stack or "")
    local dir = string.lower(self.ADDON_NAME or "AHSentinel")
    return stack:find("addons[/\\]" .. dir .. "[/\\]") ~= nil
end
function A:OnBlizzardSearch(fn, stack)
    if self:Simulated() and not self.userAHTest then return end                 -- Testroutine: nur T918 prüft das bewusst
    if self:IsOwnCall(stack) then return end
    self.blizzSearch = { fn = fn, t = GetTime() }
    self:NoteUserAH(self.BLIZZ_SEARCH[fn] or "suchen")
    if self.Diag then pcall(self.Diag.Add, self.Diag, "SNIPER-SUCHE", "Spieler-Suche ausserhalb AHS: " .. tostring(fn) .. " -> Sniper-Pause " .. self.USER_PAUSE .. " s") end
end
function A:HookBlizzardSearch()
    if self.searchHooked then return end
    local hook, ds = self:Global("hooksecurefunc"), _G.debugstack
    if not (hook and ds) then return end
    self.searchHooked = true
    local CA = self:Global("C_AuctionHouse")
    if CA and not self.AH_LEGACY then
        for fn in pairs(self.BLIZZ_SEARCH) do
            if type(CA[fn]) == "function" then
                pcall(hook, CA, fn, function() pcall(A.OnBlizzardSearch, A, fn, ds(2, 20, 0)) end)
            end
        end
    elseif type(self:Global("QueryAuctionItems")) == "function" then
        pcall(hook, "QueryAuctionItems", function() pcall(A.OnBlizzardSearch, A, "QueryAuctionItems", ds(2, 20, 0)) end)
    end
end
A:On("READY", function() pcall(A.HookBlizzardSearch, A) end)
function A:UserAHPause()
    local u = self.userAH
    if not u then return nil end
    local left = self.USER_PAUSE - (GetTime() - u.t)
    if left <= 0 then return nil end
    return left, u.kind
end
-- SN-RUHE1 (b): im Ruhemodus nur der Sniper; zurück: Grund oder nil. "user" = Suche, die der Spieler selbst angeklickt hat
-- (Einkauf-Suche, "Unterbietung prüfen", "Aktualisieren"): die geht weiter vor (Entscheid "Was du selbst suchst, geht vor",
-- Nachbildung s10_buy_priority); gesperrt sind die selbstständigen Anfragen (Hintergrund-Preisprüfung, automatisches
-- Aktualisieren von Meine Auktionen, Wächter, Scan-Wunsch) und der Scan-/Vollscan-Start.
function A:QuietBlocks(prio)
    if prio == "sniper" or prio == "user" then return nil end
    local Sn = self.Sniper
    if Sn and Sn.QuietOn and Sn:QuietOn() then return L["Sniper-Ruhemodus: nur der Sniper sucht (Sniper aus oder AH zu, dann geht es weiter)"] end
    return nil
end
function A:CanQueryNow(prio)
    if self:QuietBlocks(prio) then return false end
    -- GSL4-1 (b) (Verdacht, zu messen mit GSSniperLog 1.5): direkt nach einem Kauf 0,3 s keine eigene andere Anfrage
    local Sn = self.Sniper
    if prio ~= "sniper" and Sn and Sn.BuyQuiet and Sn:BuyQuiet() then return false end
    local gap = math.max(self:QueryGap(), self:QuerySpacing())
    return GetTime() - pace.last >= gap and self:QueryReady() and self:QueryBudgetFree(prio)
end

function A:NoteQuery()
    pace.last = GetTime()
    local limit = self:QueryLimit()
    if limit then
        local w = pace.window
        w[#w + 1] = self.QueryClock()
        if #w > limit * 2 then table.remove(w, 1) end
        if not pace.limitLogged and self.Diag then
            pace.limitLogged = true
            self.Diag:Add("SUCHEN", string.format("max je Minute = %d (Sniper hat Vorrang, andere bis %d)", limit, limit - self.QUERY_SNIPER_RESERVE))
        end
    end
end

-- Server hat eine Anfrage verworfen oder gemeckert: langsamer
function A:QueryError(why)
    pace.errors = pace.errors + 1
    local g = self:QueryGap()
    if not pace.gapBefore then pace.gapBefore = g end           -- SN-B1: Stand vor der Fehlerserie
    pace.errT, pace.errWhy, pace.okStreak = GetTime(), why, 0
    local max = self:HasThrottleAPI() and self.GAP_MAX_THROTTLED or self.GAP_MAX
    pace.gap = math.min(max, math.max(g * self.GAP_GROW, 0.3))
end

-- Antwort kam: wieder ein Stück schneller, bis zur Grenze
function A:QueryAnswered()
    pace.answers = pace.answers + 1
    local g = self:QueryGap() * self.GAP_SHRINK
    local min = MinGap()
    if g < min + 0.02 then g = min end
    -- SN-B1: mit Drossel-Schnittstelle nach GAP_OK_RESET Antworten ohne Fehler sofort wieder voll
    pace.okStreak = (pace.okStreak or 0) + 1
    if self:HasThrottleAPI() and pace.okStreak >= self.GAP_OK_RESET then
        g = min
        if pace.errT then pace.errT, pace.gapBefore, pace.errWhy = nil, nil, nil end
    end
    pace.gap = g
end

function A:GetSpeedText()
    return string.format(L["Tempo: %s, Abstand %.2f Sek. (passt sich an), Antworten %d, Fehler %d"],
        self:HasThrottleAPI() and L["Server-Drossel"] or L["selbst ermittelt"], self:QueryGap(), pace.answers, pace.errors)
end

-- ------------------------------------------------------------
-- Vollständiger Markt-Scan
-- Seiten werden nachgeladen, sobald der Server "Ergebnisse da" meldet
-- (und die Drossel bereit ist) - ohne feste Wartezeiten. Zur Sicherheit
-- gibt es weiterhin den Rückfall "Anzahl ändert sich nicht mehr".
-- ------------------------------------------------------------
local scan = { running = false }
A.scanState = scan
A.SCAN_MAX_PAGES = 400

-- läuft der Scan noch (oder wird er gerade ausgewertet)?
-- marketOnly (S2/T-SR4): nur der normale Markt-Scan, nicht der Schnell-Vollscan (ReplicateItems sperrt keine Item-Suche)
function A:IsScanning(marketOnly)
    if marketOnly then return (scan.running or scan.processing) and true or false end
    return scan.running or scan.processing or (self.FullScan and self.FullScan.running ~= nil) or false
end

-- silent = true: Ablehnung durch den Server nicht im Chat melden (Neuversuch aus dem Scan-Wunsch, TryWantedScan)
-- GSL5-5 (Protokoll 5: Vollscan 0,7 s nach Sniper AUS -> AN, Quelle zu klären): jede Scan-Start-Stelle prüft A:QuietBlocks()
-- im Moment des Starts. Zeile SCAN-START mit Weg und Sniper-/Ruhemodus-Zustand, damit das nächste Protokoll es belegt.
function A:NoteScanStart(way, kind)
    if not self.Diag then return end
    local Sn = self.Sniper
    local db = self.db and self.db.sniper
    self.Diag:Add("SCAN-START", string.format("%s · Weg %s · Sniper-Modus %s · Ruhemodus %s · AH offen %s", tostring(kind), tostring(way),
        tostring(db and db.armed and true or false), tostring(Sn and Sn.QuietOn and Sn:QuietOn() or false), tostring(self:IsAHOpen())))
end
function A:StartFullScan(silent)
    if not self.db then
        self:Print(L["Datenbank ist noch nicht bereit. Bitte kurz warten."])
        return false
    end
    if self:IsScanning() then
        self:Print(L["Es läuft bereits ein Scan."])
        return false
    end
    if not self:IsAHOpen() then
        self:Print(L["Bitte zuerst das Auktionshaus öffnen."])
        return false
    end
    -- SN-RUHE1 (b): beim Snipen kein Scan-Start (auch nicht über den Scan-Wunsch)
    local qb = self:QuietBlocks()
    if qb then
        if not silent then self:Print(qb) end
        return false
    end
    -- Schnell-Vollscan (Option, nur modernes Auktionshaus mit ReplicateItems): liest alle Einzelauktionen
    if self.FullScan and self.FullScan:Enabled() and not silent then
        if self.FullScan:Wait() == 0 then return self.FullScan:Start() end
        self:Print(string.format(L["Schnell-Vollscan erst wieder in %d Min. möglich - jetzt der normale Scan."], math.ceil(self.FullScan:Wait() / 60)))
    end
    if not (A.AH and A.AH.SendBrowseQuery) then
        self:Print(L["Dein Client unterstützt die Auktionshaus-Suche nicht (SendBrowseQuery fehlt)."])
        return false
    end
    if not self:IsScanReady() then
        self:Print(L["Scan noch gesperrt (Server-Limit). Wieder möglich in "] .. self:FormatDuration(self:GetCooldownRemaining()) .. L[" Min."])
        return false
    end
    -- Moderne API (WoW Forever, Retail): Ist der Server gerade mit anderen Anfragen ausgelastet oder läuft noch
    -- eine Wächter-Runde, wartet der Scan kurz und der Wächter pausiert - der Komplett-Scan hat Vorrang.
    if not A.AH_LEGACY and (not self:QueryReady() or (self.Watcher and self.Watcher.round)) then
        self:WantScan(nil, silent)
        return false
    end

    local ok, err = pcall(A.AH.SendBrowseQuery, {
        searchString = "",
        minLevel = 0,
        maxLevel = 0,
        filters = {},
        sorts = {},
    })
    pcall(self.NoteQuery, self)                        -- H2: zählt im gemeinsamen Kontingent
    if not ok then
        -- nur beim ersten Fehlschlag melden; Neuversuche (silent) bleiben still, sonst flutet ein bleibender Fehler den Chat
        if not silent or (self.scanWishRejects or 0) == 0 then self:Print(L["Scan konnte nicht gestartet werden: "] .. tostring(err)) end
        self.scanStartError = tostring(err)
        -- moderne API: abgelehnter Scan-Start -> Wächter pausieren und (begrenzt) nochmal versuchen
        if not A.AH_LEGACY then self:WantScan(true) end
        return false
    end

    self.scanWanted = nil
    self.scanWishRejects, self.scanWishNext, self.scanStartError = nil, nil, nil
    pcall(self.NoteScanStart, self, silent and "Wunsch/automatisch" or "Klick/Befehl", "normal")      -- GSL5-5
    scan.running = true
    scan.startedAt = GetTime()
    scan.lastCount = -1
    scan.lastChange = GetTime()
    scan.pages = 0
    scan.waitingMore = false
    scan.dirty = false

    self.db.lastScanTime = time()
    self:Print(L["Scan gestartet ..."])
    self:Fire("SCAN_STARTED")

    scan.ticker = C_Timer.NewTicker(0.1, function()
        local okPoll, errPoll = pcall(A.PollScan, A)
        if not okPoll then
            A:Print(L["Fehler während des Scans: "] .. tostring(errPoll))
            A:FinishScan(false)
        end
    end)
    return true
end

-- Scan-Wunsch (nur moderne API): Der Wächter pausiert, bis der Scan gestartet ist; sobald der Server bereit
-- ist und keine Wächter-Runde mehr läuft, startet der Scan von selbst. Höchstens 2 Minuten, dann verworfen.
-- Lehnt der Server den Scan-Start ab (Fehler in SendBrowseQuery), gibt es höchstens SCAN_WISH_RETRIES Neuversuche
-- mit mindestens SCAN_WISH_RETRY_GAP Sek. Abstand; danach eine Meldung, der Wunsch wird verworfen, der Wächter läuft weiter.
A.SCAN_WISH_SECONDS = 120
A.SCAN_WISH_RETRIES = 3
A.SCAN_WISH_RETRY_GAP = 2
function A:WantScan(rejected, quiet)
    local W = self.Watcher
    if W and W.HoldForScan then W:HoldForScan(self.SCAN_WISH_SECONDS) end
    if rejected then
        self.scanWishRejects = (self.scanWishRejects or 0) + 1
        self.scanWishNext = GetTime() + self.SCAN_WISH_RETRY_GAP
    end
    if self.scanWanted then return end
    self.scanWanted = GetTime()
    if not rejected and not quiet then self:Print(L["Server ist gerade ausgelastet - der Scan startet gleich von selbst (Wächter pausiert)."]) end
    if self.scanWishTicker then self.scanWishTicker:Cancel() end
    self.scanWishTicker = C_Timer.NewTicker(0.5, function(t) A:TryWantedScan() end)
end

-- Scan-Wunsch verwerfen; released = true: auch die 2-Minuten-Pause des Wächters aufheben
function A:DropScanWish(released)
    self.scanWanted = nil
    self.scanWishRejects, self.scanWishNext = nil, nil
    if self.scanWishTicker then self.scanWishTicker:Cancel(); self.scanWishTicker = nil end
    if released and self.Watcher and self.Watcher.ReleaseScanHold then self.Watcher:ReleaseScanHold() end
end

function A:TryWantedScan()
    local function stop() self:DropScanWish(false) end
    if not self.scanWanted then return stop() end
    if GetTime() - self.scanWanted > self.SCAN_WISH_SECONDS or not self:IsAHOpen() or self:IsScanning() then return stop() end
    -- Server lehnt den Start dauerhaft ab: einmal melden, Wunsch verwerfen, Wächter wieder laufen lassen
    if (self.scanWishRejects or 0) > self.SCAN_WISH_RETRIES then
        self:Print(string.format(L["Der Scan konnte nach %d Versuchen nicht gestartet werden - bitte später erneut versuchen (/ahs scan)."],
            self.SCAN_WISH_RETRIES + 1))
        return self:DropScanWish(true)
    end
    if self.scanWishNext and GetTime() < self.scanWishNext then return end
    if not self:QueryReady() or (self.Watcher and self.Watcher.round) then return end
    local wanted = self.scanWanted
    self.scanWanted = nil                       -- StartFullScan darf bei Ablehnung neu wünschen
    if self:StartFullScan(true) then return stop() end
    if self.scanWanted then
        self.scanWanted = wanted                -- erneut abgelehnt: die Frist läuft weiter
    else
        stop()                                  -- aus anderem Grund nicht gestartet (Meldung kam schon)
    end
end

-- Server meldet neue Ergebnisse
A:On("QUERY_READY", function()
    if scan.running then pcall(A.PollScan, A) end
    if A.scanWanted and not scan.running then pcall(A.TryWantedScan, A) end
end)

function A:OnBrowseResults(added)
    if scan.running then
        scan.dirty = true
        if added then scan.waitingMore = false end
    end
end

function A:PollScan()
    if not scan.running then return end
    local now = GetTime()
    local count = SafeCountResults()          -- nur zählen: die ganze Liste abzuholen kostet viel
    local elapsed = now - scan.startedAt

    if count ~= scan.lastCount then
        scan.lastCount = count
        scan.lastChange = now
        scan.waitingMore = false
        self:Fire("SCAN_PROGRESS", count, elapsed)
    end
    local full = SafeHasFull()

    -- 1) Client meldet: alles geladen
    if full == true and count > 0 then
        self:FinishScan(true)
        return
    end

    -- 2) weitere Seite anfordern, sobald möglich
    if count > 0 and full == false and not scan.waitingMore and scan.pages < self.SCAN_MAX_PAGES and self:QueryReady() then
        if SafeRequestMore() then
            scan.pages = scan.pages + 1
            scan.waitingMore = true
            scan.requestedAt = now
            return
        end
    end

    -- 3) Rückfall: Anzahl ändert sich länger nicht mehr
    local still = now - scan.lastChange
    if count > 0 and still >= 2 then
        if scan.waitingMore and still < 4 then return end
        if full ~= false or scan.pages >= self.SCAN_MAX_PAGES or still >= 4 then
            -- Client meldet "nicht alles geladen": halber Scan (Werte stimmen, Punkt 2)
            self:FinishScan(true, full == false)
            return
        end
    end

    -- 4) Sicherheits-Timeout: was da ist, zählt als halber Scan
    if elapsed > (A.AH_LEGACY and 900 or 120) then
        self:FinishScan(count > 0, true)
    end
end

function A:FinishScan(success, partial)
    if not scan.running then return end
    scan.running = false
    scan.partial = partial and true or nil
    if scan.ticker then
        scan.ticker:Cancel()
        scan.ticker = nil
    end

    if not success then
        self:Print(L["Scan ohne Ergebnis beendet."])
        self:ScreenMessage(L["Scan ohne Ergebnis beendet."], 1, 0.33, 0.27, false)
        self:Fire("SCAN_FAILED")
        return
    end

    -- Ergebnisse jetzt einmal abholen (danach darf das Auktionshaus auch zu sein),
    -- ausgewertet wird in Portionen über mehrere Frames - das Spiel ruckelt nicht
    local results = SafeGetResults()
    scan.processing = true
    scan.duration = GetTime() - scan.startedAt
    self:Job("scan", function() A:RunProcessScan(results) end)
end

-- A4 (Sniper "nie hängen", Perfektion "keine Sperre ohne Zeitlimit"): bricht die Auswertung mit einem Fehler ab, blieb
-- scan.processing für immer an -> A:IsScanning(true) wahr -> Sniper wartete ohne Ende ("wartet: Markt-Scan läuft"). Jetzt
-- wird die Sperre bei jedem Fehler gelöst (Protokoll SCAN), der Fehler geht weiter an die Fehlermeldung der Aufgabe.
function A:RunProcessScan(results)
    scan.processing = true
    local ok, err = self:PCall(self.ProcessScan, self, results)
    if not ok then
        scan.processing = false
        if self.Diag then pcall(self.Diag.Add, self.Diag, "SCAN", "Auswertung abgebrochen (" .. tostring(err) .. ") - Scan-Sperre gelöst") end
        self:Fire("SCAN_FAILED")
        error(err, 0)
    end
end

function A:ProcessScan(results)
    local now = time()
    local best = A.NewBest()   -- pro Item den günstigsten Preis und die Gesamtmenge (AHS-SP2 (ii): Listen statt Tabelle je Item)
    local bP, bQ = best.price, best.qty

    for i, r in ipairs(results) do
        local itemID = (type(r.itemKey) == "table" and r.itemKey.itemID) or r.itemID
        local price = r.minPrice or r.buyoutPrice
        if itemID and price and price > 0 then
            local qty = r.totalQuantity or r.quantity or 0
            -- S6-b (Prüfung 23.11. 06:38, Messung): 8 von 8 Sync-Fällen "stapel" kamen aus einem Teil-Scan (Browse) bei NICHT stapelbaren Items
            -- (Muster, Rüstung): fremder Preis ≈ Menge × eigener Stückpreis (z. B. 19999 bei 4 Stück, eigen 5000). Verdacht, zu messen: minPrice
            -- einer Browse-Zeile ist in Forever bei zusammengefassten Einzel-Auktionen die SUMME. Protokoll BROWSE-ROH je Item einmal je Sitzung
            -- (höchstens 30): minPrice, totalQuantity, Stapelgrösse, eigener Vollscan-Preis.
            if qty > 1 and (self.browseRawN or 0) < 30 and not (self.browseRawSeen and self.browseRawSeen[itemID]) and self.Diag then
                local st = self:MaxStack(itemID)
                if st == 1 then
                    self.browseRawSeen = self.browseRawSeen or {}
                    self.browseRawSeen[itemID] = true
                    self.browseRawN = (self.browseRawN or 0) + 1
                    local own = self.db and self.db.lastOwnScan and A.BestGet(self.db.lastOwnScan.data, itemID)   -- AHS-SP2 (ii)
                    pcall(self.Diag.Add, self.Diag, "BROWSE-ROH", string.format("Item %d · Stapelgrösse 1 · minPrice %d · totalQuantity %d · minPrice/Menge %d · eigener Scan %s",
                        itemID, price, qty, math.floor(price / qty + 0.5), tostring(own or "-")))
                end
            end
            local bp = bP[itemID]
            if not bp then
                bP[itemID], bQ[itemID] = price, qty
            else
                if price < bp then bP[itemID] = price end
                bQ[itemID] = bQ[itemID] + qty
            end
        end
        self:Pause()            -- TB108 S3 (T126 47,6 ms): jede Zeile eine mögliche Portion (A:Pause misst selbst, wann abgeben)
    end

    self:ProcessBest(best, #results, scan.duration or 0, { pages = scan.pages, partial = scan.partial,
        done = function() scan.processing = false end })
end

-- Preise eines Scans übernehmen (bisheriger Scan und Schnell-Vollscan): best = { [itemID] = { price, qty } }
-- info: pages, partial, replicate
-- TT1317: Scan-Preis als "unbestätigt" speichern? Vollscan mit echter Leiter (>= 5 Stück auf der günstigsten Stufe) nie.
-- AHS-SP2 (ii) (Plan Bericht 0852, freigegeben Supervisor 25.11. 08:51): Scan-Bestpreise ohne Tabelle je Item - vier Listen
-- { price = {[id]=Kupfer}, qty = {[id]=Menge}, minQty = {[id]=Menge der günstigsten Stufe}, u = {[id]=true} }. Gemessen (7000 Items):
-- 1 851 KB je Scan als Tabelle je Item gegen 960 KB als Listen. Alle Leser gehen über A.BestGet/A.BestIDs - beide lesen auch das ALTE
-- Format (db.lastOwnScan.data aus 0.65.396 und älter liegt so in den gespeicherten Daten).
function A.NewBest() return { price = {}, qty = {}, minQty = {}, u = {} } end
function A.IsBestSet(best)
    return type(best) == "table" and type(best.price) == "table" and type(best.qty) == "table"
end
-- price, qty, minQty, u (u immer true/false) - nil, wenn das Item fehlt
function A.BestGet(best, id)
    if type(best) ~= "table" then return nil end
    if A.IsBestSet(best) then
        local p = best.price[id]
        if p == nil then return nil end
        return p, best.qty[id], best.minQty and best.minQty[id], (best.u and best.u[id]) == true
    end
    local b = best[id]
    if type(b) ~= "table" then return nil end
    return b.price, b.qty, b.minQty, b.u == true
end
-- Tabelle, deren Schlüssel die itemIDs sind (für pairs)
function A.BestIDs(best)
    if A.IsBestSet(best) then return best.price end
    return type(best) == "table" and best or {}
end
function A.BestMarkU(best, id)
    if A.IsBestSet(best) then best.u = best.u or {}; best.u[id] = true
    elseif type(best) == "table" and type(best[id]) == "table" then best[id].u = true end
end
function A:ScanSuspiciousV(itemID, price, minQty, info)
    if info and info.replicate and (minQty or 0) >= self.BAIT_REAL_QTY then return false end
    return self:IsSuspicious(itemID, price) and true or false
end
function A:ScanSuspicious(itemID, b, info)
    return self:ScanSuspiciousV(itemID, b.price, b.minQty, info)
end
function A:ProcessBest(best, entries, duration, info)
    -- MP1 (niedrig): Art des LETZTEN Scans fürs Protokoll PREIS-ALT
    self.lastScanKind = (info and info.replicate) and "Vollscan" or "normal"
    info = info or {}
    local now = time()
    -- verdächtig billige Waren (mögliche Lockangebote): unbestätigt speichern und nachprüfen
    local suspicious = {}
    local itemCount = 0
    for itemID in pairs(A.BestIDs(best)) do
        -- TT1317: im Vollscan ist die ganze Preisleiter bekannt (führende 1-Stück-Lockangebote schon aussortiert). Liegen auf
        -- der günstigsten Stufe >= 5 Stück, ist der Preis echt (z. B. Preisrutsch der Levelwelle) - nicht "unbestätigt"
        -- speichern, sonst bleiben Materialien nach jedem Scan "geschätzt, unsicher".
        local price, qty, minQty, u = A.BestGet(best, itemID)          -- AHS-SP2 (ii): altes und neues Format
        if price then
            if self:ScanSuspiciousV(itemID, price, minQty, info) then
                u = true
                A.BestMarkU(best, itemID)
                local mv = self:GetMarketValue(itemID)
                table.insert(suspicious, { itemID = itemID, ratio = price / mv })
            end
            self:RecordPrice(itemID, price, qty, now, false, u or nil)
            itemCount = itemCount + 1
        end
        self:Pause()
    end

    self.db.totalScans = (self.db.totalScans or 0) + 1
    table.insert(self.db.scanLog, { t = now, items = itemCount, entries = entries, duration = duration, pages = info.pages,
        partial = info.partial, replicate = info.replicate })
    if info.partial then
        -- Werte stimmen, Punkt 2: fehlende Items sind nicht "weg" - ein halber Scan zählt nie als vollständig
        self:Print(L["Scan unvollständig: gefundene Preise sind gespeichert, fehlende Items gelten nicht als weg."])
        if self.Diag then self.Diag:Add("SCAN", string.format("halber Scan · %d Items · %d Einträge", itemCount, entries)) end
    end
    while #self.db.scanLog > 50 do table.remove(self.db.scanLog, 1) end

    -- eigenen Scan merken (für Mitspieler, die später online kommen)
    self.db.lastOwnScan = { t = now, data = best, partial = info.partial }
    if info.done then info.done() end

    self:Print(string.format(L["Scan fertig: %d Einträge, %d verschiedene Items (%.1f Sek.)."], entries, itemCount, duration))
    self:ScreenMessage(string.format(L["AH-Scan fertig: %d Items"], itemCount), 0.2, 0.87, 0.33, true)
    -- Nachprüfung: die auffälligsten zuerst, höchstens 60
    if #suspicious > 0 and self.Seller then
        -- Punkt 5: im Vollscan sind es tausende (Nachbau echte Daten: Sortieren 9,5 ms am Stück, im Sortieren keine Abgabe möglich) -
        -- nur die 60 auffälligsten werden gebraucht: Auswahl in Portionen statt alles sortieren (gleiches Ergebnis, gleiche Reihenfolge)
        local top = {}
        for i, e in ipairs(suspicious) do
            if #top < 60 or e.ratio < top[#top].ratio then
                local pos = #top + 1
                while pos > 1 and top[pos - 1].ratio > e.ratio do top[pos] = top[pos - 1]; pos = pos - 1 end
                top[pos] = e
                if #top > 60 then top[61] = nil end
            end
            if i % 200 == 0 then self:Pause() end
        end
        suspicious = top
        local n = math.min(#suspicious, 60)
        -- Punkt 5 (Befund 19:08, eigene Arbeit im Vollscan bis 37 ms): Nachbau mit echten Daten - längster Schritt 12,9 ms genau hier
        -- (bis zu 60 Nachprüfungen am Stück, jede mit eigener Meldung SELLER_CHANGED an alle Empfänger); jetzt leise mit Abgabe je
        -- Item und EINE Meldung danach
        -- T52-WARTET (Ingametest 18.11. 17:01: T52 "Status ?" - "Unterbietung prüfen" stand hinter bis zu 60 Nachprüfungen): die
        -- Nachprüfungen laufen in der Hintergrund-Liste der Preisprüfung (wie Materialpreise); Klicks und eigene Auktionen zuerst
        local Se = self.Seller
        for k = 1, n do
            if Se.CheckPriceBg then Se:CheckPriceBg(suspicious[k].itemID) else Se:CheckPrice(suspicious[k].itemID, nil, true) end
            self:Pause()
        end
        self:Fire("SELLER_CHANGED")
        self:Print(string.format(L["%d auffällig billige Waren werden nachgeprüft (Lockangebote zählen nicht)."], n))
    end
    self:Pause()
    local deals = self:FindVendorDeals()
    self.vendorDeals = deals
    if #deals > 0 then
        self:Print(string.format(L["|cff33dd55%d Items unter Händlerpreis|r - sicherer Gewinn, siehe Tab Profit"], #deals))
    end
    -- VF1c: Empfänger in Portionen (in einer Hintergrund-Aufgabe), nicht alle in einem Frame
    self:Pause()
    self:FireSpread("SCAN_FINISHED", itemCount, best, now)
    self:FireSpread("DATA_CHANGED")
    self:Pause()

    if self.Watchlist and self.Watchlist.CheckAlerts then
        self.Watchlist:CheckAlerts(true)
    end
end

function A:ResetScanState()
    if scan.ticker then scan.ticker:Cancel() end
    scan.ticker = nil
    scan.running = false
    scan.processing = false
    self:Print(L["Scan-Status zurückgesetzt."])
    self:Fire("SCAN_FAILED")
end

-- ------------------------------------------------------------
-- CSV-Export
-- ------------------------------------------------------------
-- Sortieren in Portionen (table.sort kann in Lua 5.1 nicht abgeben): stabile Merge-Sortierung, A:Pause alle 500 Vergleiche
-- (ausserhalb einer Aufgabe ohne Wirkung). Gleiches Ergebnis wie table.sort mit derselben Vergleichsfunktion (bei Gleichstand stabil).
-- SORT-POOL (0.65.346, s92: +500 KB Speicher je Vollscan durch neue Hilfslisten): Hilfslisten aus einem kleinen Vorrat (mehrere Aufgaben
-- können gleichzeitig mitten im Sortieren pausieren - darum je Aufruf eine eigene Liste, danach geleert zurück)
local sortPool = {}
function A:SortInPortions(list, less)
    local n = #list
    if n < 2 then return list end
    local buf = table.remove(sortPool) or {}
    local src, dst = list, buf
    local width, ops = 1, 0
    while width < n do
        local i = 1
        while i <= n do
            local mid, hi = math.min(i + width, n + 1), math.min(i + 2 * width, n + 1)
            local a, b, k = i, mid, i
            while a < mid and b < hi do
                if less(src[b], src[a]) then dst[k] = src[b]; b = b + 1 else dst[k] = src[a]; a = a + 1 end
                k = k + 1
                ops = ops + 1
                if ops % 500 == 0 then self:Pause() end
            end
            while a < mid do dst[k] = src[a]; a = a + 1; k = k + 1 end
            while b < hi do dst[k] = src[b]; b = b + 1; k = k + 1 end
            i = hi
        end
        src, dst = dst, src
        width = width * 2
    end
    if src ~= list then for i = 1, n do list[i] = src[i] end end
    for i = #buf, 1, -1 do buf[i] = nil end                  -- keine Verweise behalten
    if #sortPool < 4 then sortPool[#sortPool + 1] = buf end
    return list
end

-- LANG-3 (Nachbau echte Daten 63–76 ms am Stück: Item-Liste frisch + 7000 Zeilen formatieren): A:ExportCSV rechnet als
-- Hintergrund-Aufgabe "csv:export" in Portionen (A:Pause je 100 Zeilen; ausserhalb einer Aufgabe ohne Wirkung) und zeigt danach das
-- Fenster. BuildCSV selbst liefert wie bisher Text und Anzahl.
-- CF3: ganze Zahl als Text ohne "%d"-Überlauf; nil/unbegrenzt/ungültig -> ""
function A.CsvInt(v)
    if type(v) ~= "number" or v ~= v or v == math.huge or v == -math.huge then return "" end
    if v ~= math.floor(v) then return tostring(v) end                  -- Bruchteile wie bisher (tostring)
    return string.format("%.0f", v)
end
function A:BuildCSV()
    local lines = { "ItemID;Name;Preis_Kupfer;Preis_Gold;Menge;Aenderung_Scan_%;Trend_24h_%;Trend_7T_%;Trend_30T_%;Zuletzt_gesehen;Marktwert_Kupfer;Prozent_vom_Marktwert;Haendlerpreis_Kupfer" }
    local list = self:BuildItemList()
    self:Pause()
    self:SortInPortions(list, function(a, b) return a.name < b.name end)
    self:Pause()
    -- CF3 (CurseForge Spieler C 20.11.: "integer overflow attempting to store 99999999999"): 99'999'999'999c = 9'999'999g 99s 99c ist der
    -- Höchstpreis im Auktionshaus - ein Angebot zum Höchstpreis steht so im Preisverlauf (belegt: Daten-Repo MININT, Item 3973,
    -- history.p = 99999999999). "%d" verträgt im Spiel nur Zahlen bis 2'147'483'647 -> Ausgabe aller Zahlen als Text ("%.0f"),
    -- unbegrenzt/ungültig (math.huge, NaN) als leeres Feld.
    local function pct(v) return (type(v) == "number" and v == v and v ~= math.huge and v ~= -math.huge) and string.format("%.2f", v) or "" end
    for i, it in ipairs(list) do
        if i % 100 == 0 then self:Pause() end
        table.insert(lines, string.format("%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s",
            A.CsvInt(it.itemID), (tostring(it.name or ""):gsub(";", ",")), A.CsvInt(it.price), pct(type(it.price) == "number" and it.price / 10000 or nil), A.CsvInt(it.quantity),
            pct(it.change), pct(it.day), pct(it.week), pct(it.month),
            it.seen and date("%Y-%m-%d %H:%M", it.seen) or "",
            A.CsvInt(it.market), pct(it.pct), A.CsvInt(it.vendor)))
    end
    self:Pause()
    return table.concat(lines, "\n"), #list
end

function A:ExportCSV()
    if self.Job and self.PCall then
        if self:HasJob("csv:export") then return end
        self:Job("csv:export", function()
            local ok, text, count = self:PCall(self.BuildCSV, self)
            if not ok then
                self:Print(L["Fehler bei "] .. "CSV-Export: " .. tostring(text))
                return
            end
            self:YieldNow()                                   -- Fenster (Text setzen) im eigenen Bild
            self:ShowCSV(text, count)
        end)
        return
    end
    self:ShowCSV(self:BuildCSV())
end
function A:ShowCSV(text, count)
    if count == 0 then
        self:Print(L["Noch keine Daten zum Exportieren. Erst einen Scan machen."])
        return
    end
    if self.UI and self.UI.ShowTextWindow then
        self.UI:ShowTextWindow(L["CSV-Export ("] .. count .. L[" Items)  -  Strg+A, Strg+C zum Kopieren"], text)
    else
        self:Print(L["Export-Fenster nicht verfügbar."])
    end
end

-- ------------------------------------------------------------
-- Diagnose
-- ------------------------------------------------------------
function A:PrintDebug()
    self:Print(L["Version "] .. self.version .. L["  |  Interface "] .. tostring(select(4, GetBuildInfo())))
    local G = _G.GoldSentinelGame
    if type(G) == "table" and G.Status then self:Print(G.Status()) end
    if not self.db then
        self:Print(L["Datenbank: NICHT geladen"])
        return
    end
    -- Fehler des Addons (GoldSentinelTest.lua): seit dem letzten Bericht gezählt, Berichte noch nicht gemeldet
    local GT = _G.GoldSentinelTest
    if GT and GT.Pending then
        local nErr = 0
        for _, e in pairs(self.db.gsTest and self.db.gsTest.errors or {}) do if type(e) == "table" then nErr = nErr + (e.count or 1) end end
        self:Print(string.format(L["Fehler seit Login: %d · Berichte offen: %d"], nErr, GT.Pending(self.db)))
    end
    self:Print(L["Items in Datenbank: "] .. self:CountTable(self.db.marketData) .. L["  |  Scans gesamt: "] .. (self.db.totalScans or 0))
    self:Print(L["Letzter Scan: "] .. self:FormatAgo(self.db.lastScanTime) .. L["  |  Nächster Scan: "] ..
        (self:IsScanReady() and L["jetzt möglich"] or (L["in "] .. self:FormatDuration(self:GetCooldownRemaining()))))
    self:Print(L["Auktionshaus offen: "] .. tostring(self:IsAHOpen()) .. L["  |  Scan läuft: "] .. tostring(scan.running))
    local api = self:CheckAPI()
    local parts = {}
    for _, key in ipairs({ "C_AuctionHouse", "SendBrowseQuery", "GetBrowseResults", "HasFullBrowseResults", "RequestMoreBrowseResults", "GetNumBrowseResults" }) do
        table.insert(parts, key .. "=" .. (api[key] and L["|cff33dd55ja|r"] or L["|cffff5544nein|r"]))
    end
    self:Print(L["API: "] .. table.concat(parts, ", ") .. (A.AH_LEGACY and L[" (klassisches Auktionshaus)"] or ""))
    -- Händler-Kosten in Währung (z. B. Merchant's Favor) - braucht GetMerchantItemCostInfo/-Item
    local costOK = (GetMerchantItemCostInfo and GetMerchantItemCostItem) and true or false
    self:Print(L["Händler-Kosten lesbar: "] .. (costOK and L["|cff33dd55ja|r"] or L["|cffff5544nein|r"]))
    if self.UI and self.UI.GetTabDebug then
        self:Print(L["Tabs: "] .. self.UI:GetTabDebug())
    end
    self:Print(L["Button vorhanden: "] .. tostring(self.FloatingButton ~= nil and self.FloatingButton:IsShown()))
    if self.Sync and self.Sync.GetDebugText then
        self:Print(L["Sync: "] .. self.Sync:GetDebugText())
    end
    if self.Names then
        self:Print(L["Namen: "] .. self.Names:GetDebugText())
    end
    if self.Tooltip then
        self:Print("Tooltip: " .. self.Tooltip:GetDebugText())
    end
    if self.Sniper and self.Sniper.GetDebugText then
        self:Print(L["Sniper: "] .. self.Sniper:GetDebugText())
    end
    if self.Seller and self.Seller.GetDebugText then
        self:Print(L["Verkaufen: "] .. self.Seller:GetDebugText())
    end
    if self.Ledger and self.Ledger.GetDebugText then
        self:Print(L["Buchhaltung: "] .. self.Ledger:GetDebugText())
    end
    if self.Buy and self.Buy.GetDebugText then
        self:Print(L["Einkauf: "] .. self.Buy:GetDebugText())
    end
    if self.Watcher and self.Watcher.GetDebugText then
        self:Print(L["Wächter: "] .. self.Watcher:GetDebugText())
    end
    self:Print(self:GetSpeedText())
end

-- Auktionshaus geöffnet/geschlossen (aus Ereignis oder vom Fenster selbst)
function A:SetAHOpenState(open)
    open = open and true or false
    if self.ahOpen == open then return end
    self.ahOpen = open
    if open then
        -- Preise gehören zum Auktionshaus dieses Servers und dieser Fraktion (neutral: eigenes)
        pcall(self.ActivateMarket, self, self:MarketKey(true))
    else
        self.ahClosedAt = GetTime()
        if scan.running then
            self:FinishScan(SafeCountResults() > 0)
        end
        pcall(self.ActivateMarket, self, self:MarketKey(false))
    end
    self:Fire("AH_STATE")
end

-- ------------------------------------------------------------
-- Preise je Server und Fraktion/Auktionshaus (Anweisung "Werte stimmen" Punkt 1, 9. Nov.)
--   A.db.markets[Schlüssel] = { data = marketData, own = lastOwnScan, recv = lastScanTimeReceived, mixed }
--   Schlüssel = "Server|Horde" / "Server|Alliance" / "Server|Neutral" (neutrales AH: Beutebucht, Gadgetzan, Ewige Warte)
-- A.db.marketData / lastOwnScan zeigen auf den aktiven Teil; beim Ausloggen wandern sie zurück (keine doppelten
-- Tabellen in den SavedVariables).
-- ------------------------------------------------------------
A.NEUTRAL_MAPS = { [1446] = true, [1434] = true, [1452] = true }   -- Tanaris, Schlingendorntal, Winterquell (Classic-Karten)
-- über A:API (die Testroutine ersetzt nie Blizzard-Funktionen)
-- Ist das Addon Disenchantry geladen? (dann zeigt AHSentinel keinen zweiten Materialblock)
function A:DisenchantryLoaded()
    if self.apiOverride and self.apiOverride.DisenchantryLoaded ~= nil then return self.apiOverride.DisenchantryLoaded end
    local CA = _G.C_AddOns
    local f = (CA and CA.IsAddOnLoaded) or _G.IsAddOnLoaded
    if not f then return false end
    local ok, loaded = pcall(f, "Disenchantry")
    return ok and loaded and true or false
end

function A:PlayerFaction()
    local ufg = self:Global("UnitFactionGroup")
    local f = ufg and ufg("player")
    if f == "Horde" or f == "Alliance" then return f end
    return nil
end
-- atAH = true: beim Öffnen des Auktionshauses (neutraler Auktionator -> "Neutral")
-- G1 (Auftrag 21.11. 16:25, M7 belegt durch den Nutzer 16:08: "Das Auktionshaus ist für alle dasselbe"): EIN Markt je Fraktion –
-- Horde, Allianz, Neutral – ohne Realm-Namen (GetRealmName liefert in WoW Forever den Heimat-Realm, z. B. "… Realm 6" und "… Realm 2"
-- für dasselbe Auktionshaus). Neutral-Erkennung unverändert. Sync-Tag (A:MarketTag) folgt daraus (G8).
A.MARKET_ALL = "Alle"
function A:MarketKey(atAH)
    local realm = self.MARKET_ALL
    local f = self:PlayerFaction() or "?"
    if atAH then
        local ufg = self:Global("UnitFactionGroup")
        local npc = ufg and ufg("npc")
        local CM = self:Global("C_Map")
        local map = CM and CM.GetBestMapForUnit and CM.GetBestMapForUnit("player")
        if npc == "Neutral" or (npc == nil and map and self.NEUTRAL_MAPS[map]) then f = "Neutral" end
    end
    return realm .. "|" .. f
end
-- G3 (Auftrag 21.11. 16:25): Herkunft je Scan-Paket (nicht je Einzelpreis, sparsam): Zeit (Serverzeit des Scans), Quelle
-- "e" = eigen (eigenes Konto inkl. Twinks), "g" = Gilde mit Kennung (Hash, NIE Namen), Anzahl Preise. Je Markt höchstens
-- SCANS_KEEP Einträge, höchstens SCANS_DAYS Tage. Gleiches Paket (Zeit + Quelle + Kennung) nur einmal.
A.SCANS_KEEP, A.SCANS_DAYS = 2000, 30
function A:NoteScan(t, src, who, n)
    if self:InTestRoutine() and not self.scansTest then return false end
    local db = self.db
    local key = self.marketKey
    local m = self.scansTest or (db and key and db.markets and db.markets[key])
    if not (m and t) then return false end
    m.scans = m.scans or {}
    local L2 = m.scans
    local w = who and self:MarketTag("w:" .. tostring(who)) or ""
    local k = string.format("%d;%s;%s", math.floor(t), src, w)
    for i = #L2, math.max(1, #L2 - 50), -1 do if L2[i]:sub(1, #k + 1) == k .. ";" then return false end end
    L2[#L2 + 1] = k .. ";" .. math.floor(n or 0)
    local limit = time() - self.SCANS_DAYS * 86400
    while #L2 > 0 and (#L2 > self.SCANS_KEEP or (tonumber(L2[1]:match("^(%d+)")) or 0) < limit) do table.remove(L2, 1) end
    return true
end
-- G7: Abdeckung der letzten days Tage: Stunden (0–23) mit mindestens einem Scan, eigen / Gilde / zusammen
function A:Coverage(days)
    days = days or 7
    local db = self.db
    local m = self.scansTest or (db and self.marketKey and db.markets and db.markets[self.marketKey])
    local own, guild, all = {}, {}, {}
    local from = time() - days * 86400
    for _, s in ipairs((m and m.scans) or {}) do
        local t, src = s:match("^(%d+);(%a)")
        t = tonumber(t)
        if t and t >= from then
            local h = tonumber(date("%H", t))
            all[h] = true
            if src == "e" then own[h] = true else guild[h] = true end
        end
    end
    local function n(x) local c = 0 for _ in pairs(x) do c = c + 1 end return c end
    return n(all), n(own), n(guild)
end
function A:CoverageText(days)
    local a, o, g = self:Coverage(days or 7)
    return string.format(L["Abdeckung %d Tage: %d von 24 Std. (eigene %d, Gilde %d)"], days or 7, a, o, g)
end
-- G15 (Auftrag 21.11. 16:35): "kein Angebot um h Uhr" nur, wenn zu dieser Stunde genug Scans vorliegen. Grundlage sind NUR eigene
-- Vollscans ("e"): ein Vollscan sieht jedes Item im AH, also heisst "nicht gesehen" dort wirklich "kein Angebot". Gilden-Pakete
-- ("g") sind Preislisten und keine Vollscans - fehlt ein Item darin, sagt das nichts. Fenster höchstens 7 Tage (A.COMPACT_HOURLY:
-- ältere Preise sind auf einen je Tag verdichtet, die Stunde ist dann unbekannt). Gesehen = Preis in derselben oder der
-- vorherigen Stunde des Scans (der Scan wird am Ende vermerkt; Uhrzeit-Abweichung tolerieren).
-- zurück: Vollscans zu dieser Stunde (je Tag+Stunde einmal), davon mit Angebot dieses Items
A.HOUR_SCANS_MIN = 3
function A:HourOffer(itemID, h, days)
    days = math.min(days or 7, math.floor(self.COMPACT_HOURLY / 86400))
    local db = self.db
    local m = self.scansTest or (db and self.marketKey and db.markets and db.markets[self.marketKey])
    local from = time() - days * 86400
    local buckets, nb = {}, 0
    for _, s in ipairs((m and m.scans) or {}) do
        local t, src = s:match("^(%d+);(%a)")
        t = tonumber(t)
        if t and t >= from and src == "e" and tonumber(date("%H", t)) == h then
            local k = math.floor(t / 3600)
            if not buckets[k] then buckets[k] = true; nb = nb + 1 end
        end
    end
    if nb == 0 then return 0, 0 end
    local seenH = {}
    local F, n = self:HF(itemID)
    for i = n, 1, -1 do
        local t = F[(i - 1) * 5 + 1]
        if t < from - 3600 then break end
        seenH[math.floor(t / 3600)] = true
    end
    local seen = 0
    for k in pairs(buckets) do if seenH[k] or seenH[k - 1] then seen = seen + 1 end end
    return nb, seen
end
function A:HourOfferText(itemID, h)
    h = h or tonumber(date("%H"))
    local nb, seen = self:HourOffer(itemID, h)
    if nb < self.HOUR_SCANS_MIN then
        return string.format(L["Um %d Uhr: zu wenig Vollscans (%d von %d, 7 Tage)"], h, nb, self.HOUR_SCANS_MIN)
    end
    if seen == 0 then return string.format(L["Um %d Uhr kein Angebot (in %d Vollscans, 7 Tage)"], h, nb) end
    return string.format(L["Um %d Uhr Angebot in %d von %d Vollscans (7 Tage)"], h, seen, nb)
end
-- kurze Kennung für Sync-Nachrichten (nur Zahlen/Buchstaben, keine Namen)
function A:MarketTag(key)
    local s = tostring(key or self.marketKey or self:MarketKey(false)):lower()
    local h = 5381
    for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
    return self.Sync and self.Sync.Enc and self.Sync.Enc(h) or tostring(h)
end

function A:StoreMarket()
    local db, k = self.db, self.marketKey
    if not (db and k) then return end
    db.markets = db.markets or {}
    local m = db.markets[k] or {}
    m.data, m.own = db.marketData or {}, db.lastOwnScan
    m.recv = db.sync and db.sync.lastScanTimeReceived or nil
    db.markets[k] = m
end

function A:ActivateMarket(key)
    local db = self.db
    if not (db and key) then return false end
    db.markets = db.markets or {}
    -- erste Verwendung (bis 0.65.29 gab es nur EINE Preisliste): bestehende Daten prüfen und zuordnen
    if not db.marketsMigrated then
        db.marketsMigrated = true
        if type(db.marketData) == "table" and next(db.marketData) ~= nil then
            local seen, n = {}, 0
            for _, c in pairs(db.chars or {}) do
                if type(c) == "table" and c.realm and c.faction then
                    local ck = c.realm .. "|" .. c.faction
                    if not seen[ck] then seen[ck] = true; n = n + 1 end
                end
            end
            local m = { data = db.marketData, own = db.lastOwnScan, recv = db.sync and db.sync.lastScanTimeReceived }
            -- Charaktere auf mehreren Servern/Fraktionen: die alten Preise können gemischt sein
            if n > 1 then m.mixed = true; self.marketsMixed = true end
            db.markets[key] = m
            self.marketKey = key
            return true
        end
    end
    if self.marketKey == key then return true end
    self:StoreMarket()
    local m = db.markets[key]
    if not m then m = { data = {} }; db.markets[key] = m end
    db.marketData = m.data or {}
    m.data = db.marketData
    db.lastOwnScan = m.own
    if db.sync then db.sync.lastScanTimeReceived = m.recv end
    self.marketKey = key
    if self.ClearPriceCaches then self:ClearPriceCaches() end
    self:Fire("DATA_CHANGED")
    -- G2-a/G2a-a: alte Vereinigungen nachtragen - als Hintergrund-Aufgabe (Pause je Markt), nur wenn etwas fehlt
    if not self:InTestRoutine() and not self.backfillDone then
        self.backfillDone = true
        self:Job("markt:nachtragen", function() self:PCall(self.BackfillUnited, self, true) end)
    end
    pcall(self.StartUniteMarkets, self, key)                                         -- G2
    return true
end

-- ------------------------------------------------------------
-- G2 (Auftrag 21.11. 16:25): alte Märkte derselben Fraktion ("<Realm>|Horde", "|Horde") EINMALIG in den gemeinsamen Markt
-- ("Alle|Horde") übernehmen. Gleiche Beobachtung (Zeit, Preis, Menge) nur 1×. Sicherung: die alten Märkte bleiben unverändert
-- in db.markets stehen (nur m.mergedInto/m.mergedAt), zurückholbar; nichts wird gelöscht. Läuft als Hintergrund-Aufgabe in
-- Portionen (Bild-Budget, leistung.md). Zahlen vorher/nachher: db.marketsUnited[key] (Items, Einträge, Zeitraum, Doppelte).
-- ------------------------------------------------------------
local function UniteEntry(de, se, c)
    -- beide Einträge entpacken (PD7) und als flache Liste lesen
    if se.hz and A.PD7 then pcall(A.PD7.LoadEntry, A.PD7, se) end
    if de.hz and A.PD7 then pcall(A.PD7.LoadEntry, A.PD7, de) end
    local SF = A.HistFlatRaw(se)
    local DF = A.HistFlatRaw(de)
    local HS = A.HS
    local seen, rows = {}, {}
    local function add(F)
        for i = 1, #F / HS do
            local b = (i - 1) * HS
            local k = F[b + 1] .. ":" .. F[b + 2] .. ":" .. F[b + 3]
            if seen[k] then c.dup = c.dup + 1
            else
                seen[k] = true
                rows[#rows + 1] = { F[b + 1], F[b + 2], F[b + 3], F[b + 4], F[b + 5] }
            end
        end
    end
    add(DF); local nd = #rows
    add(SF)
    if #rows == nd then return false end
    table.sort(rows, function(x, y) if x[1] ~= y[1] then return x[1] < y[1] end return x[2] < y[2] end)
    local F = {}
    for i, r in ipairs(rows) do local b = (i - 1) * HS; for k = 1, HS do F[b + k] = r[k] end end
    de.hf, de.history = F, nil
    c.added = c.added + (#rows - nd)
    for k, v in pairs(se) do if k ~= "history" and k ~= "hf" and k ~= "hz" and k ~= "hzN" and k ~= "hzS" and de[k] == nil then de[k] = v end end
    return true
end
A.UniteEntry = UniteEntry
local function MarketStats(md)
    local items, entries, tMin, tMax = 0, 0, nil, nil
    for _, e in pairs(md or {}) do
        if type(e) == "table" then
            items = items + 1
            local F = (type(e.hf) == "table" and e.hf) or nil
            local n = F and #F / A.HS or (type(e.history) == "table" and #e.history or 0) + (e.hzN or 0)
            entries = entries + n
            if F and n > 0 then
                if not tMin or F[1] < tMin then tMin = F[1] end
                local tl = F[(n - 1) * A.HS + 1]
                if not tMax or tl > tMax then tMax = tl end
            end
        end
    end
    return items, entries, tMin, tMax
end
A.MarketStats = MarketStats
function A:UniteSources(key)
    local db = self.db
    local f = tostring(key):match("|(%a+)$")
    local out = {}
    if not (db and db.markets and f and f ~= "") then return out end
    for k, m in pairs(db.markets) do
        if k ~= key and type(m) == "table" and type(m.data) == "table" and not m.mergedInto and tostring(k):match("|(%a+)$") == f then
            out[#out + 1] = k
        end
    end
    table.sort(out)
    return out
end
-- PM1-b (Prüfung 23.11. 06:26): einmalige Bereinigungen schreiben ihre Zahlen dauerhaft nach db.fixLog (das Protokoll hält nur
-- ~230 Zeilen, PM1-BEREINIGT war schon weg); der Testbericht (T994) gibt sie aus. add = true: Zahlen zu einem Eintrag addieren.
function A:NoteFix(name, text, counts, add)
    if not (self.db and name) or self:InTestRoutine() then return end
    self.db.fixLog = self.db.fixLog or {}
    local e = self.db.fixLog[name]
    if add and e and type(e.c) == "table" and type(counts) == "table" then
        for k, v in pairs(counts) do e.c[k] = (e.c[k] or 0) + v end
        e.last, e.text = time(), text
        return
    end
    self.db.fixLog[name] = { t = time(), v = self.version, text = text, c = counts }
end
function A:FixLogLines()
    local out = {}
    for name, e in pairs((self.db and self.db.fixLog) or {}) do
        local cs = {}
        for k, v in pairs(type(e.c) == "table" and e.c or {}) do cs[#cs + 1] = k .. " " .. tostring(v) end
        table.sort(cs)
        out[#out + 1] = string.format("%s (%s, %s): %s%s", name, tostring(e.v or "?"), e.t and date("%d.%m. %H:%M", e.t) or "?",
            tostring(e.text or ""), #cs > 0 and (" [" .. table.concat(cs, ", ") .. "]") or "")
    end
    table.sort(out)
    return out
end
-- G2-a: Zeit eines gespeicherten eigenen Scans (Tabelle { t = … } oder, bei alten Ständen, Zahl)
local function OwnScanT(o)
    if type(o) == "table" then return tonumber(o.t) or 0 end
    return tonumber(o) or 0
end
A.OwnScanT = OwnScanT
-- G2-a: Märkte, die vor 0.65.383 vereint wurden, haben wegen des Fehlers kein db.marketsUnited -> einmalig aus dem heutigen Stand
-- nachtragen (Items/Einträge je alter Markt und je "Alle|…"; "vorher" ist nicht mehr bekannt -> nachgetragen = true)
-- G2a-a (Prüfung 23.11. 12:05): Dauer messen (ms im Protokoll); läuft als Hintergrund-Aufgabe mit Pause je Markt (pause = true)
function A:BackfillUnited(pause)
    local db = self.db
    if not (db and type(db.markets) == "table") then return 0 end
    local n = 0
    local clk = debugprofilestop
    local ms, msMax = 0, 0                                                  -- reine Rechenzeit (ohne Pausen), längster Block
    local function timed(md)
        local t = clk and clk()
        local a, b, c2, d2 = MarketStats(md)
        if t then local dt = clk() - t; ms = ms + dt; if dt > msMax then msMax = dt end end
        return a, b, c2, d2
    end
    for k, m in pairs(db.markets) do
        local key = type(m) == "table" and m.mergedInto
        if key and type(db.markets[key]) == "table" and not (db.marketsUnited and db.marketsUnited[key]) then
            local src = {}
            for k2, m2 in pairs(db.markets) do
                if type(m2) == "table" and m2.mergedInto == key then
                    if pause then self:Pause() end
                    local si, se = timed(m2.data)
                    src[#src + 1] = { key = k2, items = si, entries = se, at = m2.mergedAt }
                end
            end
            table.sort(src, function(a, b) return a.key < b.key end)
            local ai, ae, amin, amax = timed(db.markets[key].data)
            db.marketsUnited = db.marketsUnited or {}
            db.marketsUnited[key] = { t = time(), v = self.version, nachgetragen = true, sources = #src, src = src,
                after = { items = ai, entries = ae, tMin = amin, tMax = amax } }
            n = n + 1
            if self.Diag then
                local parts = {}
                for _, x in ipairs(src) do parts[#parts + 1] = string.format("%s: %d Items, %d Einträge", x.key, x.items, x.entries) end
                pcall(self.Diag.Add, self.Diag, "MARKT-VEREINT", string.format("%s nachgetragen: %d alte Märkte (%s) · Alle: %d Items, %d Einträge · Rechenzeit %s ms, längster Block %s ms",
                    tostring(key), #src, table.concat(parts, "; "), ai, ae, clk and string.format("%.1f", ms) or "-", clk and string.format("%.1f", msMax) or "-"))
            end
        end
    end
    return n
end
-- die eigentliche Arbeit (pause = Hintergrund-Aufgabe); zurück: Zählwerte
function A:UniteMarkets(key, pause)
    local db = self.db
    local tm = db.markets[key]
    if not (tm and type(tm.data) == "table") then return nil end
    local c = { sources = 0, items = 0, newItems = 0, added = 0, dup = 0 }
    local bi, be, bmin, bmax = MarketStats(tm.data)
    c.before = { items = bi, entries = be, tMin = bmin, tMax = bmax }
    local steps = 0
    for _, k in ipairs(self:UniteSources(key)) do
        local m = db.markets[k]
        c.sources = c.sources + 1
        local si, se = MarketStats(m.data)
        c[#c + 1] = { key = k, items = si, entries = se }
        for id, e in pairs(m.data) do
            steps = steps + 1
            if pause and steps % 40 == 0 then self:Pause() end
            if type(e) == "table" then
                local de = tm.data[id]
                if type(de) ~= "table" then
                    -- neues Item: als Kopie übernehmen (die Sicherung bleibt unverändert)
                    de = {}
                    tm.data[id] = de
                    c.newItems = c.newItems + 1
                end
                if UniteEntry(de, e, c) then c.items = c.items + 1 end
            end
        end
        m.mergedInto, m.mergedAt = key, time()
        -- G2-a (Prüfung 23.11. 06:37): m.own ist db.lastOwnScan (TABELLE { t, data, partial }), kein Zähler -> verglich Tabelle mit
        -- Zahl/Tabelle ("attempt to compare number with table") NACH mergedAt, d. h. je Lauf ein Markt, ohne marketsUnited/Meldung.
        if OwnScanT(m.own) > OwnScanT(tm.own) then tm.own = m.own end
    end
    local ai, ae, amin, amax = MarketStats(tm.data)
    c.after = { items = ai, entries = ae, tMin = amin, tMax = amax }
    return c
end
function A:StartUniteMarkets(key)
    local db = self.db
    if not (db and key and db.markets and db.markets[key]) then return false end
    if self.uniting or #self:UniteSources(key) == 0 then return false end
    if self.PD7 and self.PD7.loading then
        if C_Timer and C_Timer.After then C_Timer.After(2, function() pcall(A.StartUniteMarkets, A, key) end) end
        return false
    end
    self.uniting = true
    self:Job("markt:vereinen", function()
        local okU, c = self:PCall(self.UniteMarkets, self, key, true)
        self.uniting = nil
        if not okU then
            if self.Diag then pcall(self.Diag.Add, self.Diag, "FEHLER", "Märkte vereinen: " .. tostring(c)) end
            return
        end
        if not c then return end
        db.marketsUnited = db.marketsUnited or {}
        db.marketsUnited[key] = { t = time(), v = self.version, sources = c.sources, newItems = c.newItems, items = c.items, added = c.added,
            dup = c.dup, before = c.before, after = c.after }
        if self.Diag then
            pcall(self.Diag.Add, self.Diag, "MARKT-VEREINT", string.format("%s: %d alte Märkte · Items %d -> %d (%d neu) · Einträge %d -> %d (+%d, %d doppelt ausgelassen)",
                tostring(key):match("|(%a+)$") or "?", c.sources, c.before.items, c.after.items, c.newItems, c.before.entries, c.after.entries, c.added, c.dup))
        end
        if self.ClearPriceCaches then self:ClearPriceCaches() end
        self:Fire("DATA_CHANGED")
        self:Print(string.format(L["Marktdaten zusammengeführt: %d alte Märkte, %d Items, +%d Preise (%d doppelte ausgelassen). Die alten Daten bleiben als Sicherung."],
            c.sources, c.after.items, c.added, c.dup))
    end)
    return true
end

-- beim Ausloggen: aktiven Teil zurücklegen, damit die Preise nicht doppelt gespeichert werden
function A:ParkMarket()
    local db = self.db
    if not (db and self.marketKey) then return end
    self:StoreMarket()
    -- leere Tabelle statt nil: andere Module dürfen beim Ausloggen noch lesen
    db.marketData, db.lastOwnScan = {}, nil
    self.parkedKey = self.marketKey
    self.marketKey = nil
end

-- D2: Anzahl Items der aktiven Preisliste - auch nach ParkMarket (Ausloggen: das Diagnose-Paket entsteht danach)
function A:MarketItemCount()
    local db = self.db
    if not db then return 0 end
    local d = db.marketData
    if (type(d) ~= "table" or next(d) == nil) and self.parkedKey and db.markets and db.markets[self.parkedKey] then
        d = db.markets[self.parkedKey].data
    end
    return self:CountTable(d)
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
A.eventFrame = eventFrame      -- für die Testroutine

local function SafeRegister(event)
    return A:RegisterAHEvent(eventFrame, event)
end

SafeRegister("ADDON_LOADED")
SafeRegister("PLAYER_LOGIN")
SafeRegister("AUCTION_HOUSE_SHOW")
SafeRegister("AUCTION_HOUSE_CLOSED")
SafeRegister("MERCHANT_SHOW")
SafeRegister("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
SafeRegister("AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
SafeRegister("MERCHANT_UPDATE")
SafeRegister("COMMODITY_SEARCH_RESULTS_UPDATED")
SafeRegister("ITEM_SEARCH_RESULTS_UPDATED")
SafeRegister("AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
SafeRegister("AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED")
SafeRegister("AUCTION_HOUSE_SHOW_ERROR")
SafeRegister("PLAYER_LOGOUT")

eventFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == A.ADDON_NAME then
        local clock = debugprofilestop
        local t0 = clock and clock()
        A:InitDB()
        -- MN1 (anweisung-marktdaten-netz, Masterplan 2.2): gemeinsames Marktdaten-Netz anmelden (Daten in AHSentinelDB.gsMarkt).
        -- Fehlt die Datei (alter Stand) oder die AH-Schnittstelle, bleibt sie still aus.
        pcall(A.AttachMarketNet, A)
        -- PD7: kompakt gespeicherten Preisverlauf sofort entpacken und prüfen (vor allem anderen)
        if A.PD7 then pcall(A.PD7.StartLoad, A.PD7) end     -- TB118-2: in Portionen nach dem Laden
        A:CheckAPI()
        A.loadMs = { init = t0 and (clock() - t0) or nil }
    elseif event == "PLAYER_LOGIN" then
        if not A.db then A:InitDB() end
        pcall(A.ActivateMarket, A, A:MarketKey(false))
        if A.Activity and A.Activity.NoteLogin then pcall(A.Activity.NoteLogin, A.Activity) end      -- MR7: Rhythmus lernen
        if A.Activity and A.Activity.OnLogin then pcall(A.Activity.OnLogin, A.Activity) end          -- MR5: letzter Besuch
        if A.marketsMixed then
            A:Print(L["Hinweis: Deine bisherigen Preise stammen evtl. von mehreren Servern oder Fraktionen. Ab jetzt trennt AHSentinel die Preise je Server und Fraktion; der nächste Scan ersetzt sie."])
        end
        local clock = debugprofilestop
        local t1 = clock and clock()
        A:Fire("READY")
        A.loadMs = A.loadMs or {}
        A.loadMs.ready = t1 and (clock() - t1) or nil
        A:Print(L["Version "] .. A.version .. L[" geladen. Öffnen über den Münz-Button oder /ahs"] .. "  |cffaaaaaa(" .. L["/ahs help = alle Befehle"] .. ")|r")
        if A.migratedFromOld then
            A:Print(L["|cff33dd55AH Analyzer Pro heißt jetzt AHSentinel.|r Alle deine Daten wurden übernommen. Den Ordner 'AHAnalyzerPro' im AddOns-Ordner brauchst du nicht mehr und kannst ihn löschen."])
        elseif type(AHAnalyzerProDB) == "table" and AHAnalyzerProDB.migratedTo then
            -- Übergangs-Ordner noch da: kurz erinnern (einmal pro Sitzung)
            A:Print(L["Hinweis: Den alten Ordner 'AHAnalyzerPro' im AddOns-Ordner kannst du löschen - deine Daten sind in AHSentinel."])
        end
    elseif event == "PLAYER_LOGOUT" then
        if A.Activity and A.Activity.MarkSeen and not (A.Simulated and A:Simulated()) then pcall(A.Activity.MarkSeen, A.Activity) end   -- MR5
        pcall(A.ParkMarket, A)
        pcall(A.HistToRowsAll, A)                                 -- RF-M1: gespeichertes Format unverändert
        if A.PD7 then pcall(A.PD7.OnLogout, A.PD7) end              -- PD7: geprüfte Pakete schreiben
    elseif event == "AUCTION_HOUSE_SHOW" then
        A:SetAHOpenState(true)
    elseif event == "AUCTION_HOUSE_CLOSED" then
        A:SetAHOpenState(false)
    elseif event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
        A:QueryAnswered()
        A:OnBrowseResults(event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
        -- AHS-W1 (26.11.): bei ADDED liefert das Spiel die NEUEN Einträge mit (arg1) - der Wächter hängt sie an statt die ganze Liste neu zu holen
        A:Fire("BROWSE_RESULTS", event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED", event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" and arg1 or nil)
    elseif event == "COMMODITY_SEARCH_RESULTS_UPDATED" or event == "ITEM_SEARCH_RESULTS_UPDATED" then
        A:QueryAnswered()
        A:Fire("SEARCH_RESULTS", arg1)
    elseif event == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then
        A:Fire("QUERY_READY")
    elseif event == "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED" then
        A.lastThrottleDrop = GetTime()
        A:QueryError(L["verworfener Anfrage"])
        A:Fire("QUERY_DROPPED")                                       -- TB188-8: Sniper sendet seine Suche sofort neu
        if A.Watcher and A.Watcher.OnThrottleDrop then pcall(A.Watcher.OnThrottleDrop, A.Watcher) end
    elseif event == "AUCTION_HOUSE_SHOW_ERROR" then
        -- nur als Bremse werten, wenn gerade eine Suche lief
        -- SN-B1: Fehlermeldungen kurz nach einem eigenen Kauf-Aufruf (Preis gestiegen, Angebot weg) sind keine Bremse
        if A:AHErrorIsThrottle() then A:QueryError(L["Fehlermeldung des Auktionshauses"]) end
    elseif event == "MERCHANT_SHOW" or event == "MERCHANT_UPDATE" then
        -- kurz warten, bis der Händler seine Liste geladen hat
        C_Timer.After(0.3, function() pcall(A.ScanMerchant, A) end)
    end
end)
A:TimeFrame(eventFrame, "Kern")

-- ------------------------------------------------------------
-- Chat-Befehle (alles ist auch per Maus bedienbar)
-- ------------------------------------------------------------
-- Befehlsliste für den Chat (/ahs help): Befehl auf Deutsch / Englisch, Beschreibung
-- BL-A (BL1): EINE Befehlstabelle für Liste (Chat, Befehlsliste beim Tippen) UND Handler.
-- Felder: [1] deutsches Wort (Anzeige), [2] englisches Wort (Anzeige), [3] Beschreibung (Locale-Schlüssel),
--   w = alle Befehlswörter (Standard: [1] und [2]), arg = Zusatz nach dem Wort erlaubt, dev = nur für den Entwickler,
--   run = function(rest, msg) – rest: Text nach dem Befehlswort ("" wenn keiner), msg: ganze Eingabe (klein).
-- Der Slash-Handler sucht das längste passende Wort hier und ruft run – es gibt keine zweite Liste.
local function Arg1(msg) return msg:match("^%a+%s*(.*)$") end           -- Rest nach dem ersten Wort ("" möglich)
local function ArgOpt(msg) return msg:match("^%a+%s+(.*)$") end         -- Rest nach dem ersten Wort oder nil
A.COMMANDS = {
    { "", "", "Fenster öffnen / schließen", w = { "", "show" }, run = function() if A.UI then A.UI:Toggle() end end },
    { "scan", "scan", "Komplett-Scan des Marktes starten", run = function() A:StartFullScan() end },
    { "vollscan", "fullscan", "Schnell-Vollscan: alle Einzelauktionen (höchstens alle 15 Min.)", run = function() if A.FullScan then A.FullScan:Start() end end },
    { "vollscan messen", "fullscan measure", "Vollscan-Messung M1c: einmal je Sitzung kürzerer Abstand (mit Rückfrage)", arg = true,
        run = function(_, msg) if A.FullScan then A.FullScan:MeasureCommand(msg:match("^%a+%s+%a+%s*(.*)$")) end end },
    { "sniper", "sniper", "Sniper-Modus an / aus", run = function() if A.Sniper then A.Sniper:ToggleArmed() end end },
    { "listen", "lists", "Einkaufslisten", run = function() if A.UI then A.UI:ToggleLists() end end },
    { "optionen", "options", "Optionen", w = { "optionen", "options", "einstellungen", "config", "settings" }, run = function()
        if A.UI then A.UI:ShowOptions() end
        A.optViaCmd = time()                                                       -- HILFE-GRP-1
        if A.Pruefliste and A.Pruefliste.HelpCheck then A.Pruefliste:HelpCheck() end
    end },
    { "bilanz", "summary", "Tagesbilanz im Chat", w = { "bilanz", "summary", "daily" }, run = function() if A.Extras then A.Extras:ShowDailySummary(true) end end },
    { "buchhaltung neu", "books new", "Buchhaltung neu beginnen (Stichtag, mit Rückfrage)", w = { "buchhaltung", "books" }, arg = true,
        run = function(_, msg) if A.Books then A.Books:Command(Arg1(msg)) end end },
    { "doppelt", "doubles", "Doppelte Kaufbuchungen suchen (bereinigen / zurück)", arg = true,
        run = function(_, msg) if A.Ledger then A.Ledger:DoubleCommand(Arg1(msg)) end end },
    { "twinks", "alts", "Regeln für die Post an Twinks", w = { "twinks", "alts", "mailrules" }, run = function() if A.UI and A.UI.ShowMailRules then A.UI:ShowMailRules() end end },
    { "ziel 5000", "goal 5000", "Gold-Ziel setzen (ohne Zahl: Stand, 'aus': löschen)", w = { "ziel", "goal" }, arg = true,
        run = function(_, msg) if A.Comfort then A.Comfort:GoalCommand(ArgOpt(msg)) end end },
    { "raid", "raid", "Raid-Vorrat als Einkaufsliste", run = function()
        if A.Comfort then
            local ok, m, name = A.Comfort:CreateRaidList()
            A:Print(m)
            if ok and A.UI and A.UI.ShowLists then A.UI:ShowLists(name) end
        end
    end },
    { "minikarte", "minimap", "Knopf an der Minikarte an / aus", w = { "minikarte", "minimap", "knopf" }, run = function() A:ToggleMinimapButton() end },
    -- ESL1-Weg (16.11.): auch mit ProfessionSentinel (Gewinn-Fenster aus) - gewähltes Rezept des offenen Berufsfensters
    { "material", "materials", "Materialien des gewählten Rezepts als Einkaufsliste (Berufsfenster offen)",
        run = function() if A.Crafting then A.Crafting:SelectedToListCmd(false) end end },
    { "fehlt", "missing", "Nur fehlende Materialien des gewählten Rezepts als Einkaufsliste",
        run = function() if A.Crafting then A.Crafting:SelectedToListCmd(true) end end },
    -- Prüfliste im Spiel (Entscheid des Nutzers 16.11. 06:47): nur Entwicklermodus
    { "prüfliste", "checklist", "Prüfliste im Spiel (was im Spiel zu prüfen ist)", w = { "prüfliste", "pruefliste", "checklist" }, dev = true,
        run = function() if A.Pruefliste then A.Pruefliste:Open() end end },
    { "testroutine", "testroutine", "Testroutine (alle Prüfungen, Bericht an die Prüfung)", dev = true, arg = true, run = function(rest)
        -- Testroutine (GoldSentinelTest): /ahs testroutine [a-k|server|haendler|berufe|post|gildenbank|kampf|sniper|tempo]
        local a = rest and rest:match("^(%S+)")
        if A.TestRoutine then
            -- Wunsch des Nutzers (22:15): /ahs testroutine stop | abbrechen | cancel
            if a == "stop" or a == "abbrechen" or a == "cancel" then A.TestRoutine:Stop()
            elseif a == "echt" or a == "real" then
                -- TU5: Grundregeln an den eigenen Daten (nur lesen), Ergebnis im Chat und im Testbericht
                if A.Core and A.Core.RealCheck then A.Core:RealCheck(true) end
            elseif a == "sniper" and A.SniperTest then
                -- SN1951-ABNAHME: zuerst S4 (echter Testkauf nur nach Ja), dann Teil "sniper" der Testroutine
                A.SniperTest:Begin()
            else A.TestRoutine:Start(a) end
        end
    end },
    { "test", "test", "Selbsttest aller Funktionen (Auktionshaus offen)", w = { "test", "selbsttest", "selftest" }, dev = true, run = function()
        -- Kurzform: Testroutine-Teil "server" (Auktionshaus offen)
        if A.TestRoutine then
            if A:IsAHOpen() then A.TestRoutine:Start("server") else
                if A.SelfTest then A.SelfTest:ShowWindow() end
                A:Print(L["Für den Selbsttest erst das Auktionshaus öffnen (oder /ahs test daten für gespeicherte Daten)."])
            end
        end
    end },
    { "test daten", "test saved", "Selbsttest mit gespeicherten Daten (ohne Scan)", w = { "test daten", "test saved", "test gespeichert" }, dev = true,
        run = function() if A.TestRoutine then A.TestRoutine:Start("auto") end end },
    { "heute", "today", "Heute tun: was jetzt am meisten Gold bringt", run = function() if A.UI and A.UI.ShowToday then A.UI:ShowToday() end end },
    { "entzaubern", "disenchant", "Entzauber-Fenster: ein Klick = ein Teil entzaubern", w = { "entzaubern", "disenchant", "de" }, arg = true,
        run = function(_, msg) if A.DEWindow then A.DEWindow:Command(ArgOpt(msg)) end end },
    { "entzaubern freigeben", "disenchant unblock", "Sperrliste beim Entzaubern leeren (alle wieder erlaubt)",
        run = function(_, msg) if A.DEWindow then A.DEWindow:Command(ArgOpt(msg)) end end },
    { "testmodus", "testmode", "Testmodus an / aus (alles ausprobieren, Handel nur simuliert)", dev = true,
        run = function() if A.TestMode then A.TestMode:Toggle(); if A.SelfTest then A.SelfTest:ShowWindow() end end end },
    { "sync", "sync", "Preise mit Mitspielern teilen an / aus", run = function() if A.Sync then A.Sync:Toggle() end end },
    { "sync test", "sync test", "Sync prüfen: wer in Gilde/Gruppe hat AHSentinel?", run = function() if A.Sync then A.Sync:Test() end end },
    { "design", "design", "Design wechseln (Klassisch / Modern)", run = function() if A.UI then A.UI:ToggleTheme() end end },
    { "sprache", "language", "Sprache des Addons wechseln", w = { "sprache", "language", "lang" }, run = function()
        A:CycleUILanguage(1)
        A:Print(string.format(L["Sprache des Addons: %s"], A:UILanguageLabel()))   -- AHS-OVF1: über A.SafeString
    end },
    { "export", "export", "Alle Preise als CSV (zum Kopieren)", run = function() A:ExportCSV() end },
    { "spenden", "donate", "Addon unterstützen (PayPal-Link)", w = { "spenden", "donate", "support" }, run = function() if A.UI then A.UI:ShowDonate() end end },
    { "reset", "reset", "Fenster- und Knopf-Positionen zurücksetzen", run = function()
        if A.ResetButtonPosition then A:ResetButtonPosition() end
        if A.UI then A.UI:ResetPosition() end
    end },
    { "resetscan", "resetscan", "Scan-Stand zurücksetzen (hängender Scan)", run = function() A:ResetScanState() end },
    { "messreihe", "silvertest", "Silber-Messreihe (Fenster)", run = function() if A.SilverTest then A.SilverTest:Show() end end },
    { "handbuch", "manual", "Hilfe-Fenster mit Anleitung", w = { "handbuch", "manual", "anleitung" }, run = function() if A.UI then A.UI:ShowHelp("start") end end },
    { "debug", "debug", "Diagnose (für Fehlermeldungen)", run = function() A:PrintDebug() end },
    { "pd7", "pd7", "Kompakter Preisverlauf: Stand; „pd7 zurück“ schaltet ihn ab (solange die Sicherung da ist)", arg = true, run = function(rest)
        local P = A.PD7
        if not P then return end
        local a = rest and rest:match("^(%S+)")
        if a == "zurück" or a == "zurueck" or a == "undo" or a == "back" then
            local _, msg = P:Undo()
            A:Print(msg)
        else A:Print(P:Status()) end
    end },
    -- G2: Stand der Zusammenführung; "markt sicherung löschen" entfernt die alten Märkte (Sicherung) erst auf Wunsch
    { "markt", "market", "Gemeinsamer Markt: Stand der Zusammenführung; „markt sicherung löschen“ entfernt die alten Märkte", arg = true, run = function(rest)
        local db = A.db
        if not db then return end
        local a = rest and rest:lower() or ""
        if a:find("sicherung") and (a:find("lösch") or a:find("losch") or a:find("delete")) then
            local n = 0
            for k, m in pairs(db.markets or {}) do if type(m) == "table" and m.mergedInto then db.markets[k] = nil; n = n + 1 end end
            A:Print(string.format(L["%d alte Märkte (Sicherung) gelöscht."], n))
            return
        end
        local u = db.marketsUnited and db.marketsUnited[A.marketKey or ""]
        if u then
            A:Print(string.format(L["Gemeinsamer Markt %s: %d alte Märkte übernommen · Items %d -> %d · Preise %d -> %d (%d doppelte ausgelassen)"],
                tostring(A.marketKey), u.sources or 0, u.before and u.before.items or 0, u.after and u.after.items or 0,
                u.before and u.before.entries or 0, u.after and u.after.entries or 0, u.dup or 0))
        else
            A:Print(string.format(L["Gemeinsamer Markt %s: keine alten Märkte zum Übernehmen."], tostring(A.marketKey)))
        end
    end },
    -- CF1/ST3 (Präzisierung 22.11. 09:25: Stapelgrösse belegen): "/ahs stapel <Item-Link oder Nummer>" zeigt itemStackCount (GetItemInfo)
    { "stapel", "stack", "Stapelgrösse eines Items anzeigen (GetItemInfo): „stapel <Item-Link oder Nummer>“", arg = true, run = function(rest)
        local id = tonumber((rest or ""):match("item:(%d+)") or (rest or ""):match("(%d+)"))
        if not id then A:Print(L["Bitte Item-Link oder Item-Nummer angeben."]); return end
        local ok, name, _, _, _, _, _, _, st = pcall(GetItemInfo, id)
        A:Print(string.format(L["Item %d (%s): Stapelgrösse %s"], id, tostring(ok and name or "?"), tostring(ok and st or L["noch nicht geladen"])))
        if A.Diag then pcall(A.Diag.Add, A.Diag, "STAPEL-ROH", string.format("Befehl: Item %d · %s · itemStackCount %s", id, tostring(ok and name or "?"), tostring(ok and st or "-"))) end
    end },
    -- CF2: Gewinn-Fenster beim Beruf von selbst öffnen (Standard aus) / CF-AHS-6: Fehlbestand-Meldung im Chat (Standard an, 1 Zeile je Sitzung)
    { "gewinnfenster", "profitpanel", "Gewinn-Fenster beim Beruf: „gewinnfenster auto“ öffnet es von selbst (Standard: nur auf Klick, Knopf „AHS“)", arg = true, run = function(rest)
        local s = A.db.settings
        if rest == "auto" then s.craftAutoOpen = not (s.craftAutoOpen == true) end
        A:Print(s.craftAutoOpen and L["Gewinn-Fenster öffnet sich beim Beruf von selbst."] or L["Gewinn-Fenster nur auf Klick (Knopf „AHS“ am Berufsfenster)."])
    end },
    -- AHS-I2 e (T565, Ingametest 23.11.): englisches Wort "missing" gehörte schon "fehlt" (Rezept) -> eigenes Wort "shortage"
    { "fehlbestand", "shortage", "Buchhaltung: Chat-Hinweis bei Fehlbestand an/aus (höchstens eine Zeile je Sitzung)", run = function()
        local s = A.db.settings
        s.missingChat = (s.missingChat == false)
        A:Print(s.missingChat and L["Fehlbestand-Hinweis im Chat: an (höchstens eine Zeile je Sitzung)."] or L["Fehlbestand-Hinweis im Chat: aus."])
    end },
    -- G17: Gebührenregel aus den Verkaufs-Rechnungen (eigene + Gilde, ohne Namen)
    { "gebuehren", "fees", "Gebührenregel aus den Verkaufs-Rechnungen (eigene und Gilde) prüfen", w = { "gebuehren", "gebühren", "fees" }, run = function()
        if A.Mailer and A.Mailer.FeeText then A:Print(A.Mailer:FeeText()) end
    end },
    { "ahdebug", "ahdebug", "Auktionshaus-Diagnose im Chat", run = function() if A.UI then A.UI:PrintAHDebug() end end },
    { "ah", "ah", "Auktionshaus-Fenster des Addons erzwingen", run = function() if A.UI then A.UI:ForceAH() end end },
    { "protokoll", "log", "Diagnose-Protokoll (zum Kopieren, geht automatisch an die Prüfung)", w = { "protokoll", "log", "diag", "diagnose", "protocol" }, dev = true,
        run = function() if A.Diag then A.Diag:Show() end end },
    { "spieltest an", "playtest on", "Spieltest: prüft die Checkliste im Spiel selbst (an / aus / bericht)", w = { "spieltest", "playtest" }, arg = true, dev = true,
        run = function(_, msg) if A.Spieltest then A.Spieltest:Command(Arg1(msg)) end end },
    { "hilfe", "help", "Diese Liste", w = { "hilfe", "help", "?", "befehle", "commands" }, run = function() A:PrintCommands() end },
}

-- BL1: längstes passendes Befehlswort aus A.COMMANDS ("vollscan messen" vor "vollscan", "test daten" vor "test")
function A:CommandWords(c) return c.w or { c[1], c[2] } end
function A:FindCommand(msg)
    local best, bestW
    for _, c in ipairs(self.COMMANDS) do
        for _, w in ipairs(self:CommandWords(c)) do
            if msg == w or (c.arg and w ~= "" and msg:sub(1, #w + 1) == w .. " ") then
                if not bestW or #w > #bestW then best, bestW = c, w end
            end
        end
    end
    return best, bestW
end

-- CH-G (FREIGABE PHASE 8 Punkt 4, Nutzer 16.11. 14:10): gemeinsamer Aufbau aller GoldSentinel-Addons
-- (shared/wissen/befehle-gemeinsam.md): vier Gruppen Alltag, Einstellungen, Hilfe, Entwickler (nur im Entwicklermodus).
A.CMD_GROUPS = { "alltag", "einstellungen", "hilfe", "entwickler" }
A.CMD_GROUP_LABEL = { alltag = "Alltag", einstellungen = "Einstellungen", hilfe = "Hilfe", entwickler = "Entwickler" }
A.CMD_GROUP_OF = {
    optionen = "einstellungen", sprache = "einstellungen", minikarte = "einstellungen", reset = "einstellungen", design = "einstellungen",
    handbuch = "hilfe", debug = "hilfe", ahdebug = "hilfe", ah = "hilfe", resetscan = "hilfe", spenden = "hilfe", hilfe = "hilfe",
}
function A:CommandGroup(c)
    if c.dev then return "entwickler" end
    return c.grp or self.CMD_GROUP_OF[c[1]] or "alltag"
end
-- Zeilen der Hilfe (ohne Ausgabe; Testroutine liest sie)
function A:CommandLines(german, dev)
    local lines = {}
    for _, g in ipairs(self.CMD_GROUPS) do
        local first = true
        for _, c in ipairs(self.COMMANDS) do
            if self:CommandGroup(c) == g and (dev or not c.dev) then
                if first then
                    lines[#lines + 1] = " |cffffd100" .. L[self.CMD_GROUP_LABEL[g]] .. "|r"
                    first = false
                end
                local word = german and c[1] or c[2]
                local cmd = (word == "") and "/ahs" or ("/ahs " .. word)
                lines[#lines + 1] = string.format("   |cff33dd55%s|r  -  %s", cmd, L[c[3]])
            end
        end
    end
    return lines
end
function A:PrintCommands()
    local german = (self.uiLang or (GetLocale and GetLocale())) == "deDE"
    self:Print("|cffffd100" .. L["Befehle"] .. "|r  (" .. L["auch /ahanalyzer"] .. ")")
    local lines = self:CommandLines(german, self:IsDev())
    local p = self:Global("print") or print                             -- TAINT-1 (0.65.330)
    for _, line in ipairs(lines) do p(line) end
    self.helpShown = self:HelpStats(lines)
    if self.Pruefliste and self.Pruefliste.HelpCheck then self.Pruefliste:HelpCheck() end
end
-- HILFE-GRP-1: was gezeigt wurde, für die Prüfliste zählen (Gruppen-Überschriften, Befehle, doppelte Befehle)
function A:HelpStats(lines)
    local groups, cmds, dup, seen = 0, 0, 0, {}
    for _, line in ipairs(lines or {}) do
        local cmd = line:match("|cff33dd55(.-)|r  %-  ")
        if cmd then
            cmds = cmds + 1
            if seen[cmd] then dup = dup + 1 end
            seen[cmd] = true
        elseif line:find("|cffffd100", 1, true) then
            groups = groups + 1
        end
    end
    return { t = time(), groups = groups, cmds = cmds, dup = dup }
end

SLASH_AHANALYZERPRO1 = "/ahs"
SLASH_AHANALYZERPRO2 = "/ahsentinel"
SLASH_AHANALYZERPRO3 = "/ahp"            -- alter Name (AH Analyzer Pro) geht weiter
SLASH_AHANALYZERPRO4 = "/ahanalyzer"
SlashCmdList["AHANALYZERPRO"] = function(msg)
    msg = string.lower(msg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    -- TEST-DEV1: versteckter Schalter (nicht in der Liste)
    local sw = msg:match("^entwickler%s*(%a*)$") or msg:match("^developer%s*(%a*)$")
    if sw then
        if sw == "an" or sw == "on" then A:SetDev(true) elseif sw == "aus" or sw == "off" then A:SetDev(false) end
        A:Print(A:IsDev() and L["Entwickler-Modus: an"] or L["Entwickler-Modus: aus"])
        return
    end
    -- SN-RUHE1 (f): Ruhemodus an/aus (Standard an)
    local rq = msg:match("^ruhe%s*(%a*)$") or msg:match("^quiet%s*(%a*)$")
    if rq then
        if rq == "an" or rq == "on" then A.Sniper:SetQuiet(true) elseif rq == "aus" or rq == "off" then A.Sniper:SetQuiet(false) end
        A:Print(A.Sniper:QuietSetting() and L["Sniper-Ruhemodus: an"] or L["Sniper-Ruhemodus: aus"])
        return
    end
    -- P186-2: versteckter Schalter "nur ein Einzelkauf zur Zeit" (Entwickler, Standard aus)
    local ek = msg:match("^einzelkauf%s*(%a*)$")
    if ek then
        if not A:RequireDev() then return end
        if ek == "an" or ek == "on" then A.Sniper:SetSingleBuy(true) elseif ek == "aus" or ek == "off" then A.Sniper:SetSingleBuy(false) end
        A:Print(A.Sniper:SingleBuyOn() and L["Sniper: nur ein Einzelkauf zur Zeit - an"] or L["Sniper: nur ein Einzelkauf zur Zeit - aus (paralleles Senden)"])
        return
    end
    -- BL1: Entscheidung nur über A.COMMANDS (keine eigene Vergleichskette)
    local c, w = A:FindCommand(msg)
    -- Testfunktionen nur für den Entwickler (auch unbekannte "test…"-Wörter; Hinweis kommt von GoldSentinelDev)
    if (c and c.dev or (not c and msg:match("^test"))) and not A:RequireDev() then return end
    if not (c and c.run) then
        A:Print(string.format(L["Unbekannter Befehl: %s"], msg))
        A:PrintCommands()
        return
    end
    local rest = msg:sub(#w + 1):gsub("^%s+", "")
    c.run(rest, msg)
end
