-- ThreatSentinel - Threat.lua
-- Herzstück: wertet für jede Namensplakette aus, wer den Mob hat, und steuert Anzeige und Warnungen.
--
-- Zustände eines Mobs:
--   IDLE       nicht im Kampf mit der Gruppe
--   HELD       du hältst ihn
--   WARN       du hältst ihn, aber ein DD ist nahe dran
--   OTHERTANK  ein anderer Tank hält ihn
--   PETHELD    ein Begleiter hält ihn (gilt als sicher)
--   CC         Mob ist kontrolliert und wird ignoriert
--   LOOSE      Mob greift einen DD oder Heiler an

local ADDON, ns = ...
local L = ns.L

local T = {}
ns.Threat = T
table.insert(ns.modules, T)

local mobs = {}
ns.mobs = mobs
ns.owners = {}

local active = false
local TICK = 0.25

local ROLE_ORDER = { HEALER = 1, DAMAGER = 2, PET = 3 }

function T:Login()
	for _, plate in ipairs(C_NamePlate.GetNamePlates() or {}) do
		local u = plate.namePlateUnitToken
		if u then mobs[u] = { unit = u } end
	end
	C_Timer.NewTicker(TICK, function() T:Tick() end)
end

------------------------------------------------------------
-- Hinweistext unter einer losen Plakette
------------------------------------------------------------
function T:BuildHint(unit, m)
	local db = ns.db
	m.hint, m.far, m.tauntCD = nil, false, 0
	if m.claimedBy then m.hint = string.format(L.CLAIMED, m.claimedBy) return end
	if m.muted then m.hint = string.format(L.OWNER, m.ownerName or "?") return end

	local spell = ns.tauntSpell
	if spell then
		m.tauntCD = ns.SpellCD(spell)
		if ns.SpellInRange(spell, unit) == false then
			m.far = true
			m.hint = L.TOO_FAR
			return
		end
	end
	if m.myRaw and m.myRaw >= db.deficitThreshold then
		if ns.class == "WARRIOR" then m.hint = L.DEFICIT_WARRIOR
		elseif ns.class == "DRUID" then m.hint = L.DEFICIT_DRUID
		else m.hint = L.DEFICIT_OTHER end
		return
	end
	if not spell then return end
	if m.tauntCD > 0 then
		local other = ns.Sync:OtherTankReady()
		if other then
			m.hint = string.format(L.OTHER_TANK_READY, other)
		else
			m.hint = string.format(L.TAUNT_CD, math.ceil(m.tauntCD))
		end
	else
		m.hint = L.TAUNT_READY
	end
end

------------------------------------------------------------
-- Auswertung eines Mobs
------------------------------------------------------------
function T:Evaluate(unit, m)
	local db = ns.db
	local now = GetTime()
	local prev = m.state
	local guid = UnitGUID(unit)
	if guid ~= m.guid then
		m.guid = guid
		prev = nil
		m.looseSince = nil
		m.alerted = false
	end
	m.name = UnitName(unit)
	m.victim, m.victimRole, m.otherTank, m.claimedBy = nil, nil, nil, nil
	m.muted, m.ownerName, m.myRaw = false, nil, nil

	-- Schwächungszauber: Kontrolle und Rüstung zerreissen
	local cc, sunder = false, 0
	for i = 1, 40 do
		local name, count = ns.Aura(unit, i, "HARMFUL")
		if not name then break end
		if ns.ccNames[name] then cc = true end
		if name == ns.sunderName then sunder = (count and count > 0) and count or 1 end
	end
	m.sunder = sunder

	local state
	if not UnitCanAttack("player", unit) or UnitIsDeadOrGhost(unit) then
		state = "IDLE"
	elseif cc and db.ignoreCC then
		state = "CC"
	else
		local tankUnit, myRaw, maxOther, any = nil, nil, 0, false
		for _, u in ipairs(ns.groupUnits) do
			local isTanking, status, scaled, raw = UnitDetailedThreatSituation(u, unit)
			if status then
				any = true
				if isTanking then tankUnit = u end
				if UnitIsUnit(u, "player") then
					myRaw = raw
				elseif not isTanking and scaled and scaled > maxOther and not ns:IsSafeUnit(u) then
					maxOther = scaled
				end
			end
		end
		-- Ersatz, falls das Spiel keine Bedrohung liefert: Ziel des Mobs
		if not tankUnit and not any and UnitAffectingCombat(unit) then
			local tu = unit .. "target"
			if UnitExists(tu) then
				for _, u in ipairs(ns.groupUnits) do
					if UnitIsUnit(u, tu) then tankUnit = u break end
				end
			end
		end

		if not tankUnit then
			state = "IDLE"
		elseif UnitIsUnit(tankUnit, "player") then
			state = (maxOther >= db.warnThreshold) and "WARN" or "HELD"
			if guid then ns.owners[guid] = { name = ns.playerName, t = now } end
		else
			local role = ns:GetRole(tankUnit)
			if role == "TANK" then
				state = "OTHERTANK"
				m.otherTank = ns:FullName(tankUnit)
				if guid then ns.owners[guid] = { name = m.otherTank, t = now } end
			elseif role == "PET" and db.petsSafe then
				state = "PETHELD"
			else
				state = "LOOSE"
				m.victim = UnitName(tankUnit)
				m.victimRole = role
				m.myRaw = myRaw
			end
		end
	end

	m.state = state

	if state == "LOOSE" then
		if prev ~= "LOOSE" then m.looseSince = now end
		m.claimedBy = ns.Sync:Claim(guid)
		local owner = guid and ns.owners[guid]
		if db.sync and owner and owner.name ~= ns.playerName and ns.Sync:IsTank(owner.name)
			and (now - (m.looseSince or now)) < db.ownerGrace then
			m.muted = true
			m.ownerName = owner.name
		end
		self:BuildHint(unit, m)
		if not m.muted and not m.claimedBy and not m.alerted then
			m.alerted = true
			ns.Alerts:OnLoose(m)
		end
	else
		if prev == "LOOSE" and (state == "HELD" or state == "WARN") then
			ns.Alerts:OnRegain(unit, m)
		end
		m.alerted = false
		m.hint, m.far, m.tauntCD = nil, false, 0
	end
end

local function SortLoose(a, b)
	local ra, rb = ROLE_ORDER[a.victimRole] or 9, ROLE_ORDER[b.victimRole] or 9
	if ra ~= rb then return ra < rb end
	return (a.looseSince or 0) < (b.looseSince or 0)
end

------------------------------------------------------------
-- Regelmässiger Durchlauf
------------------------------------------------------------
function T:Tick()
	if not ns.db then return end
	ns:ClearRoleCache()
	ns.DD:Tick()
	ns.Meter:Tick()

	local nowActive = ns:IsActive()
	if nowActive ~= active then
		active = nowActive
		if not active then
			for unit, m in pairs(mobs) do
				ns.Plates:Restore(unit)
				m.state = nil
				m.alerted = false
			end
			-- Testmeldungen (Schlüssel "test") stehen lassen
			local c = ns.Alerts.center
			if c and c.key ~= "test" then ns.Alerts:ClearCenter() end
		end
	end
	if not active then
		ns.HUD:Update(nil, nil)
		return
	end

	if ns.testMode then
		ns.Test:Tick(mobs)
		return
	end

	local loose, heldOnMe = {}, 0
	for unit, m in pairs(mobs) do
		self:Evaluate(unit, m)
		ns.Plates:Update(unit, m)
		if m.state == "LOOSE" and not m.muted and not m.claimedBy then
			loose[#loose + 1] = m
		elseif m.state == "HELD" or m.state == "WARN" then
			heldOnMe = heldOnMe + 1
		end
	end
	table.sort(loose, SortLoose)
	ns.Alerts:Evaluate(loose, heldOnMe)
	ns.HUD:Update(loose, ns.Alerts.extras)
end

function T:EvalOne(unit)
	if not active or ns.testMode then return end
	local m = mobs[unit]
	if not m then return end
	self:Evaluate(unit, m)
	ns.Plates:Update(unit, m)
end

------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------
ns:On("NAME_PLATE_UNIT_ADDED", function(_, unit)
	mobs[unit] = { unit = unit }
	T:EvalOne(unit)
end)

ns:On("NAME_PLATE_UNIT_REMOVED", function(_, unit)
	ns.Plates:Restore(unit)
	mobs[unit] = nil
end)

ns:On("UNIT_THREAT_LIST_UPDATE", function(_, unit)
	if unit and mobs[unit] then T:EvalOne(unit) end
end)

ns:On("PLAYER_REGEN_ENABLED", function()
	local now = GetTime()
	for guid, o in pairs(ns.owners) do
		if now - o.t > 30 then ns.owners[guid] = nil end
	end
end)
