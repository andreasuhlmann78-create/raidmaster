# ThreatSentinel – Änderungen

## 1.2.2
- Behoben: Das Addon lud in TBC Classic Anniversary 2.5.6 nicht (ein unbekanntes Ereignis brach das Laden ab – /ts und der Minimap-Knopf fehlten). Unbekannte Ereignisse werden jetzt übersprungen.
- Interface 20506 (TBC Classic Anniversary 2.5.6) ergänzt – das Addon gilt nicht mehr als veraltet
- Der Pfeil in „» Name (Rolle)“ wird jetzt richtig angezeigt (das alte Zeichen fehlte in der WoW-Schrift)
- Testzentrale: Vorschau-Plaketten in zwei Reihen, sie überlappen sich nicht mehr
- Testmeldungen bleiben stehen, wenn die Demo beendet wird

## 1.2.1
- Neuer Knopf **Unterstützen** (PayPal) in der Titelleiste des Einstellungsfensters und „Addon unterstützen“ auf der Seite Allgemein. Auch mit `/ts spenden`. Öffnet sich nie von selbst.

## 1.2.0
- Neue **Testzentrale** (Rechtsklick auf den Minimap-Knopf oder `/ts test`): Demo mit Vorschau-Plaketten, Live-Test solo, jede Meldung einzeln, Tank-Sync-Simulation und Diagnose
- Läuft auf Classic Era / Anniversary und TBC Anniversary sowie WoW Forever

## 1.1.0
- Erste Version: lose Mobs leuchten, gehaltene werden ausgeblendet, Spott auf Mauszeiger, Aggrometer, Tank-Sync
