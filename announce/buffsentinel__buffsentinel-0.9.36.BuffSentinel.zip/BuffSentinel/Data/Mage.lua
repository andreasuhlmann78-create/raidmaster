-- BuffSentinel - Data/Mage.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
local L = BS.L
BS.ClassData = BS.ClassData or {}

local ARMORS = { 7302, 6117, 168, 30482 }   -- Eis-, Magische, Frost-, Glühende Rüstung

BS.ClassData.MAGE = {
    specNames       = { L.ARCANE, L.FIRE, L.FROST },
    specNamesModern = { L.ARCANE, L.FIRE, L.FROST },
    icon = "Interface\\Icons\\Spell_Holy_MagicalSentry",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        { key = "intellect", kind = "buff", spell = 1459, group = true, groupSpell = 23028, manaOnly = true },
        -- Leichte Federn für Langsamer Fall (Spieldaten bs-n1-rest.md Abschnitt 2: 130 -> 17056 in allen Zweigen): unter 5 ->
        -- Hinweis; optional (Standard aus), auch allein
        { key = "feathers",  kind = "buff", alertOnly = true, max = 3, optional = true, iconSpell = 130, label = L.SUPPLY_FEATHERS,
          alert = L.ALERT_FEATHERS, supply = { low = 5, hint = L.SUPPLY_HINT_FEATHERS, ranks = { { 130, 17056 } } } },
        -- Managem fehlt (Spieldaten shared/wissen/daten/bs-vorrat-naechste-punkte.md Abschnitt 1, Vereinigung aller Zweige):
        -- irgendein "Managem herbeizaubern" gelernt UND kein Managem in den Taschen -> Warnung (auch allein)
        { key = "managem",   kind = "buff", alertOnly = true, max = 3, iconSpell = 759, label = L.SUPPLY_MANAGEM,
          alert = L.ALERT_MANAGEM, supply = { low = 1, hint = L.SUPPLY_HINT_MANAGEM,
          anyOf = { 5514, 5513, 8007, 8008, 22044, 33312, 36799 },
          needAny = { 759, 1210, 3552, 3553, 3724, 10053, 10054, 10055, 10056, 27101, 27390, 36883, 42985, 42986 } } },
        -- Reagenz für Arkane Brillanz (BS-N1 Punkt 1, Tabelle shared/wissen/daten/reagenzien-gruppenbuffs.md): nur in der Gruppe
        { key = "r_powder",  kind = "buff", alertOnly = true, max = 3, iconSpell = 23028, label = L.SUPPLY_R_POWDER,
          alert = L.ALERT_REAGENT, supply = { low = 10, groupOnly = true, hint = L.SUPPLY_HINT_REAGENT,
          ranks = { { 61316, 17020 }, { 43002, 17020 }, { 27127, 17020 }, { 23028, 17020 } } } },
        -- Rüstung: Arkan -> Magische, Feuer -> Glühende (ab TBC), Frost -> Eisrüstung; jede Rüstung zählt
        { key = "armor",     kind = "buff", spell = { 7302, 30482, 6117, 168 },
          spellBySpec = { [1] = { 6117, 30482, 7302, 168 }, [2] = { 30482, 7302, 6117, 168 }, [3] = { 7302, 30482, 6117, 168 } },
          auras = ARMORS, label = L.ARMOR, alert = L.ARMOR_2 },

        -- Procs
        { key = "clearcasting", kind = "proc", procAuras = { 12536 }, specs = { 1 },
          spell = 116, spellBySpec = { [1] = 5143, [2] = 133, [3] = 116 },
          talents = { "Arcane Concentration", "Arkane Konzentration" }, label = L.CLEARCASTING, alert = L.ALERT_CLEARCASTING },
        -- Hot Streak: ab WotLK und in WoW Forever, nur Feuer
        { key = "hotstreak",  kind = "proc", spell = 11366, procAuras = { 48108, "Hot Streak", "Kampfeslust" },
          min = 3, alsoForever = true, specs = { 2 },
          talents = { "Hot Streak", "Kampfeslust" }, alert = L.ALERT_PYROBLAST },
        { key = "missilebarr",kind = "proc", spell = 5143, procAuras = { 44401 }, min = 3, specs = { 1 },
          talents = { "Missile Barrage", "Geschosssalve" }, alert = L.ARCANE_MISSILES },
        { key = "brainfreeze",kind = "proc", spell = 133, procAuras = { 57761 }, min = 3, specs = { 3 },
          talents = { "Brain Freeze", "Hirnfrost" }, alert = L.ALERT_FIREBALL },
        { key = "fingers",    kind = "proc", spell = 30455, procAuras = { 44544 }, min = 3, specs = { 3 },
          talents = { "Fingers of Frost", "Eisige Finger" }, alert = L.ALERT_ICE_LANCE },
        { key = "impact",     kind = "proc", spell = 2136, procAuras = { 64343 }, min = 3, specs = { 2 },
          talents = { "Impact", "Einschlag" }, alert = L.ALERT_FIRE_BLAST },

        -- Cooldowns Arkan
        { key = "presence",    kind = "cd", spell = 12043, specs = { 1 } },
        { key = "arcanepower", kind = "cd", spell = 12042, specs = { 1 } },
        { key = "abarrage",    kind = "cd", spell = 44425, min = 3, specs = { 1 } },
        -- Cooldowns Feuer
        { key = "fireblast",   kind = "cd", spell = 2136,  specs = { 2 } },
        { key = "combustion",  kind = "cd", spell = 11129, specs = { 2 } },
        { key = "blastwave",   kind = "cd", spell = 11113, specs = { 2 } },
        { key = "dragonbreath",kind = "cd", spell = 31661, min = 2, specs = { 2 } },
        -- Cooldowns Frost (IDs wechseln mit TBC)
        { key = "icebarrier",  kind = "cd", spell = 11426, specs = { 3 } },
        { key = "coldsnap",    kind = "cd", spell = 12472, max = 1, specs = { 3 } },
        { key = "coldsnap2",   kind = "cd", spell = 11958, min = 2, specs = { 3 } },
        { key = "icyveins",    kind = "cd", spell = 12472, min = 2, specs = { 3 } },
        { key = "waterele",    kind = "cd", spell = 31687, min = 2, specs = { 3 } },
        { key = "deepfreeze",  kind = "cd", spell = 44572, min = 3, specs = { 3 } },
        { key = "iceblock",    kind = "cd", spell = 11958, max = 1 },
        { key = "iceblock2",   kind = "cd", spell = 45438, min = 2 },
        -- Cooldowns alle
        { key = "counterspell",kind = "cd", spell = 2139 },
        { key = "blink",       kind = "cd", spell = 1953 },
        { key = "frostnova",   kind = "cd", spell = 122 },
        { key = "evocation",   kind = "cd", spell = 12051 },
        { key = "mirrorimage", kind = "cd", spell = 55342, min = 3 },
        { key = "timewarp",    kind = "cd", spell = 80353, min = 4 },
        { key = "arcaneblast_f", kind = "cd", spell = "Arcane Blast", specs = { 1 }, forever = true, optional = true },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP, Retail)
        ----------------------------------------------------------------
        { key = "m_brilliance", kind = "buff", v = "modern", spell = 1459, auras = { 1459, 61316 }, group = true, retail = true },
        { key = "m_armor",      kind = "buff", v = "modern", max = 5, spell = { 7302, 30482, 6117 },
          spellBySpec = { [1] = { 6117, 30482, 7302 }, [2] = { 30482, 6117, 7302 }, [3] = { 7302, 30482, 6117 } },
          auras = { 7302, 6117, 30482 }, label = L.ARMOR, alert = L.ARMOR_2 },

        { key = "m_hotstreak",  kind = "proc", v = "modern", spell = 11366, procAuras = { 48108 }, specs = { 2 } },
        { key = "m_brainfreeze",kind = "proc", v = "modern", spell = 44614, procAuras = { 57761 }, specs = { 3 } },
        { key = "m_fingers",    kind = "proc", v = "modern", spell = 30455, procAuras = { 44544 }, specs = { 3 } },
        { key = "m_missiles",   kind = "proc", v = "modern", spell = 5143, procAuras = { 79683 }, specs = { 1 } },

        { key = "m_apower",     kind = "cd", v = "modern", spell = 12042, specs = { 1 } },
        { key = "m_presence",   kind = "cd", v = "modern", spell = 12043 },
        { key = "m_evocation",  kind = "cd", v = "modern", spell = 12051 },
        { key = "m_combustion", kind = "cd", v = "modern", spell = 11129, specs = { 2 } },
        { key = "m_inferno",    kind = "cd", v = "modern", spell = 108853, specs = { 2 } },
        { key = "m_dbreath",    kind = "cd", v = "modern", spell = 31661, specs = { 2 } },
        { key = "m_icyveins",   kind = "cd", v = "modern", spell = 12472, specs = { 3 } },
        { key = "m_frozenorb",  kind = "cd", v = "modern", spell = 84714, specs = { 3 } },
        { key = "m_deepfreeze", kind = "cd", v = "modern", spell = 44572, specs = { 3 } },
        { key = "m_alter",      kind = "cd", v = "modern", spell = 108978 },
        { key = "m_mirror",     kind = "cd", v = "modern", spell = 55342 },
        { key = "m_coldsnap",   kind = "cd", v = "modern", spell = 11958 },
        { key = "m_icebarrier", kind = "cd", v = "modern", spell = 11426 },
        { key = "m_counter",    kind = "cd", v = "modern", spell = 2139 },
        { key = "m_blink",      kind = "cd", v = "modern", spell = 1953 },
        { key = "m_iceblock",   kind = "cd", v = "modern", spell = 45438 },
        { key = "m_timewarp",   kind = "cd", v = "modern", spell = 80353 },
    },
}
