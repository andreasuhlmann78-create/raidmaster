-- LevelPilot - Danger
-- Gefahrenkarte: hoechstes Level feindlicher Mobs je Gebiet (aus den Spawnpunkten des Datenpakets).
-- Pflichtregel: Die Route fuehrt nie zu Zielen und moeglichst nie ueber Wege, an denen Mobs 3 oder mehr
-- Level ueber dem Spielerlevel stehen. Elite-Mobs zaehlen 2 Level hoeher.

local _, LP = ...
local L = LP.L
local D = {}
LP:RegisterModule("Danger", D)

D.MAX_DIFF = 3            -- Mobs ab Spielerlevel + 3 sind tabu
D.ELITE_BONUS = 2         -- Elite zaehlt so viele Level mehr
D.pathRule = true         -- auch Wege durch gefaehrliche Gebiete meiden (Testumgebung kann es abschalten)
D.TOWN = 99               -- Ort der anderen Fraktion (Wachen): Sperrgebiet fuer jedes Level
local CELL = 100          -- Yards je Zelle
local SPREAD = 0          -- Nachbarzellen mitmarkieren (Mobs laufen umher, Aggro-Radius)
local ENTRANCE = 200      -- Yards um einen Dungeoneingang
local GUARD_LEVEL = 45    -- NPCs der anderen Fraktion ab diesem Level gelten als Wachen

local cells = nil         -- [inst] = { [key] = Level }
-- 3.13.1 (Ingametest 3.13.0 T150: Neuplanung Median 19,35 ms; Nachbau Untote Stufe 10 Unterstadt: Route 65 % der Planung, 92 gerade
-- Strecken bis 60 km = 61 000 Messpunkte): höchstes Level je Block aus BLOCK x BLOCK Zellen. Route springt über Blöcke, die das
-- Ergebnis nicht ändern können (genau dieselben Messpunkte, siehe D:Route)
local BLOCK = 16
local blocks = nil        -- [inst] = { [Blockschlüssel] = höchstes Level im Block }
local segCache, segCount = {}, 0

local function Key(n, w) return math.floor(n / CELL) * 100000 + math.floor(w / CELL) end

local function MyCode() return LP:PlayerFaction() == "Horde" and "H" or "A" end

-- effektives Level eines Mobs (Elite hoeher); nil fuer freundliche NPCs
function D:MobLevel(npc, id)
    if type(npc) ~= "table" or not npc.lo then return nil end
    if npc.f and npc.f ~= "" and npc.f:find(MyCode(), 1, true) then return nil end
    if npc.v then return nil end                              -- Haendler, Lehrer, Flugmeister ...
    -- Elite, Boss (seltene zaehlen nicht); NPCs der anderen Fraktion (Wachen, Questgeber) ohne Aufschlag
    local faction = npc.f and npc.f ~= ""
    local elite = not faction and (npc.rk == 1 or npc.rk == 3)
    -- echtes Level aus dem Spiel, wenn hoeher als im Datenpaket (WoW Forever)
    local lo = (id and LP.Calib) and LP.Calib:MobLo(id, npc.lo) or npc.lo
    return lo + (elite and self.ELITE_BONUS or 0)
end

-- Fuer die Gefahrenkarte: nur Mobs, die ein Gebiet besetzen (mehrere Spawnpunkte) oder Elite;
-- einzelne NPCs ohne Fraktion sind meist Questgeber, seltene Mobs wandern umher
local function Occupies(npc)
    if npc.rk == 2 or npc.rk == 4 then return false end
    local pts = 0
    for _, s in ipairs(npc.s or {}) do pts = pts + (#s - 1) / 2 end
    -- NPCs der anderen Fraktion nur als Gruppe (Wachen eines Ortes); einzelne sind Questgeber oder stehen
    -- in Schlachtfeldern, deren Spawns auf die Aussenzone umgerechnet sind (Bericht 3.9.0: "Mob 63" am Pass)
    if npc.f and npc.f ~= "" then return pts >= 3 end
    if npc.rk == 1 or npc.rk == 3 then return true end
    return pts >= 3
end

function D:Build()
    -- in eine eigene Tabelle bauen und erst am Ende einsetzen: wird der Aufbau unterbrochen (Stopp der Reise),
    -- bleibt keine halbe Karte uebrig
    local built, builtB = {}, {}
    local N = LevelPilotData and LevelPilotData.N
    if not N then cells, blocks = built, builtB wipe(segCache) segCount = 0 D.gen = (D.gen or 0) + 1 return end
    local Geo = LP.Geo
    -- Dungeoneingaenge: Elite-Spawns dort sind Dungeon-Mobs (stehen drinnen, nicht draussen)
    local ents = {}
    for _, d in pairs(LevelPilotData.D or {}) do
        for _, e in ipairs(d.e or {}) do
            local i, n, w = Geo:ToWorld(e[1], e[2], e[3])
            if i then ents[#ents + 1] = { i, n, w } end
        end
    end
    local function AtEntrance(inst, n, w)
        for _, e in ipairs(ents) do
            if e[1] == inst and math.abs(e[2] - n) < ENTRANCE and math.abs(e[3] - w) < ENTRANCE then return true end
        end
        return false
    end
    local count = 0
    for id, npc in pairs(N) do
        count = count + 1
        if count % 100 == 0 then LP:Yield("plan") end
        local lv = self:MobLevel(npc, id)
        -- Wachen eines Ortes der anderen Fraktion (Elite oder ab Level 45): Sperrgebiet fuer jedes Level;
        -- andere NPCs der Fraktion (z. B. Bauern von Hillsbrad = Questgegner der Horde) zaehlen mit ihrem Level
        if lv and npc.f and npc.f ~= "" and (npc.rk == 1 or npc.rk == 3 or npc.lo >= GUARD_LEVEL) then lv = self.TOWN end
        if lv and lv > 1 and Occupies(npc) then
            for _, s in ipairs(npc.s or {}) do
                local map = s[1]
                if Geo:Bounds(map) then
                    for i = 2, #s - 1, 2 do
                        local inst, n, w = Geo:ToWorld(map, s[i], s[i + 1])
                        if inst and not ((npc.rk == 1 or npc.rk == 3) and AtEntrance(inst, n, w)) then
                            local t = built[inst]
                            if not t then t = {} built[inst] = t end
                            local bt = builtB[inst]
                            if not bt then bt = {} builtB[inst] = bt end
                            local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
                            for dn = -SPREAD, SPREAD do
                                for dw = -SPREAD, SPREAD do
                                    local k = (cn + dn) * 100000 + (cw + dw)
                                    if (t[k] or 0) < lv then t[k] = lv end
                                    local bk = math.floor((cn + dn) / BLOCK) * 100000 + math.floor((cw + dw) / BLOCK)
                                    if (bt[bk] or 0) < lv then bt[bk] = lv end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    D.places = D.BuildPlaces(N, MyCode() == "H" and "A" or "H")
    cells, blocks = built, builtB
    wipe(segCache) segCount = 0
    D.gen = (D.gen or 0) + 1       -- 3.12.37: Stand der Gefahrenkarte (Zwischenspeicher an den Startwegen)
end

------------------------------------------------------------------------
-- 3.13.7 Entscheid des Nutzers 22.11. 16:57/16:58: "Alle Sperren aufheben und keine Wege mehr sperren ... ausser sie führen durch
-- Dörfer oder Städte der anderen Fraktion." Feste Ortsliste je Fraktion aus dem Datenpaket (Questie, GPL-3): Häufung von NPCs, die
-- NUR der anderen Fraktion freundlich sind (f = "A" bzw. "H"; neutrale Orte wie Beutebucht, Ratschet, Gadgetzan, Everlook haben
-- NPCs mit f = "AH" und zählen nicht). Kette: Spawnpunkte näher als D.PLACE_LINK Yards gehören zusammen; ein Ort braucht mindestens
-- D.PLACE_MIN Punkte von mindestens D.PLACE_NPCS verschiedenen ortsfesten NPCs (ein einzelner Flugmeister oder Lagerposten ist kein Ort).
-- Mittelpunkt = Schwerpunkt, Radius = weitester Punkt + D.PLACE_MARGIN. Gilt nur für WEGE (Segment, Route, PathDanger), nicht für
-- Ziele (D:At bleibt): Questziele in einem solchen Ort bleiben erreichbar. Ein Ort, in dem Start oder Ziel der Strecke liegt, zählt
-- bei Route/PathDanger nicht (man darf hinein und heraus, nur nicht hindurch). Wegsuche: Strecke durch den Ort = Level D.TOWN
-- (x25 teurer wie jedes Sperrgebiet) – es ist keine Sperre; gibt es keinen anderen Weg, führt er trotzdem hindurch.
------------------------------------------------------------------------
D.PLACE_LINK = 100        -- Yards
D.PLACE_MIN = 5           -- Spawnpunkte je Ort (3.13.8 LP-O1: 5 statt 6 – Steinkrallengipfel, Thalanaar, Valormok haben je 5)
D.PLACE_NPCS = 4          -- verschiedene NPCs je Ort
D.PLACE_MARGIN = 40       -- Yards Rand
D.PLACE_SPAWNS = 2        -- höchstens so viele Spawnpunkte je NPC (ortsfest)
function D.BuildPlaces(N, enemy)
    local Geo = LP.Geo
    local per = {}            -- [inst] = { {n, w, id}, ... }
    local count = 0
    for id, npc in pairs(N or {}) do
        count = count + 1
        if count % 200 == 0 then LP:Yield("plan") end
        -- nur ortsfeste NPCs (höchstens D.PLACE_SPAWNS Spawnpunkte: Händler, Lehrer, Questgeber, Wachposten). Gegner-Lager mit vielen
        -- Spawns (z. B. Kul-Tiras-Matrosen in Durotar, Bael'dun im Brachland, Bauern von Hillsbrad) sind Questgebiete, keine Orte –
        -- sie stehen mit ihrem Level in der Gefahrenkarte.
        local pts = 0
        if type(npc) == "table" and npc.f == enemy then for _, s in ipairs(npc.s or {}) do pts = pts + (#s - 1) / 2 end end
        if type(npc) == "table" and npc.f == enemy and pts <= D.PLACE_SPAWNS then
            for _, s in ipairs(npc.s or {}) do
                local map = s[1]
                if Geo:Bounds(map) then
                    for i = 2, #s - 1, 2 do
                        local inst, n, w = Geo:ToWorld(map, s[i], s[i + 1])
                        if inst then
                            local p = per[inst] or {}
                            per[inst] = p
                            p[#p + 1] = { n, w, id, map }
                        end
                    end
                end
            end
        end
    end
    -- Kette über ein Gitter (Zelle = D.PLACE_LINK): je Punkt nur die 9 Nachbarzellen prüfen (vorher alle Punkte: 189 ms am Stück)
    local out, link, link2 = {}, D.PLACE_LINK, D.PLACE_LINK * D.PLACE_LINK
    local ops = 0
    for inst, pts in pairs(per) do
        local grid = {}
        for idx, pnt in ipairs(pts) do
            local gk = math.floor(pnt[1] / link) * 100000 + math.floor(pnt[2] / link)
            local cell = grid[gk]
            if not cell then cell = {} grid[gk] = cell end
            cell[#cell + 1] = idx
        end
        local used = {}
        for a = 1, #pts do
            if not used[a] then
                used[a] = true
                local member, k = { pts[a] }, 1
                while k <= #member do
                    local m = member[k]
                    local gn, gw = math.floor(m[1] / link), math.floor(m[2] / link)
                    for dn = -1, 1 do
                        for dw = -1, 1 do
                            local cell = grid[(gn + dn) * 100000 + (gw + dw)]
                            if cell then
                                for _, b in ipairs(cell) do
                                    ops = ops + 1
                                    if ops % 200 == 0 then LP:Yield("plan") end
                                    if not used[b] then
                                        local qn, qw = pts[b][1] - m[1], pts[b][2] - m[2]
                                        if qn * qn + qw * qw <= link2 then used[b] = true member[#member + 1] = pts[b] end
                                    end
                                end
                            end
                        end
                    end
                    k = k + 1
                end
                local ids, nids = {}, 0
                for _, mm in ipairs(member) do if not ids[mm[3]] then ids[mm[3]] = true nids = nids + 1 end end
                if #member >= D.PLACE_MIN and nids >= D.PLACE_NPCS then
                    local sn, sw = 0, 0
                    for _, mm in ipairs(member) do sn, sw = sn + mm[1], sw + mm[2] end
                    local cn, cw = sn / #member, sw / #member
                    local r = 0
                    for _, mm in ipairs(member) do r = math.max(r, math.sqrt((mm[1] - cn) ^ 2 + (mm[2] - cw) ^ 2)) end
                    local list = out[inst] or {}
                    out[inst] = list
                    list[#list + 1] = { n = cn, w = cw, r = r + D.PLACE_MARGIN, map = member[1][4], npcs = nids, pts = #member }
                end
            end
        end
    end
    return out
end
-- Ort, in dem der Punkt liegt (oder nil)
function D:PlaceAt(inst, n, w)
    if not cells then self:Build() end
    for _, p in ipairs((self.places or {})[inst] or {}) do
        if (n - p.n) ^ 2 + (w - p.w) ^ 2 <= p.r * p.r then return p end
    end
    return nil
end
-- Führt die Strecke (ab skip Yards) durch einen Ort der anderen Fraktion? ex1/ex2 = ausgenommene Orte (Start/Ziel)
function D.PlaceHit(inst, n1, w1, n2, w2, skip, ex1, ex2)
    local list = D.places and D.places[inst]
    if not list then return false end
    local dn, dw = n2 - n1, w2 - w1
    local len2 = dn * dn + dw * dw
    local len = math.sqrt(len2)
    skip = skip or 0
    if len <= skip and skip > 0 then return false end
    local t0 = len > 0 and skip / len or 0
    for _, p in ipairs(list) do
        if p ~= ex1 and p ~= ex2 then
            local t = len2 > 0 and (((p.n - n1) * dn + (p.w - w1) * dw) / len2) or 0
            if t < t0 then t = t0 elseif t > 1 then t = 1 end
            local qn, qw = n1 + dn * t - p.n, w1 + dw * t - p.w
            if qn * qn + qw * qw <= p.r * p.r then return true, p end
        end
    end
    return false
end

function D:Ready() return cells ~= nil end
function D:Reset() cells, blocks = nil, nil D.places = nil wipe(segCache) segCount = 0 D.gen = (D.gen or 0) + 1 end
function D:CacheSize() return segCount end      -- 3.12.30 SP1 (Diagnose)

-- hoechstes Mob-Level an einem Weltpunkt (0 = nichts bekannt)
function D:At(inst, n, w)
    if not inst or not n then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    return t and t[Key(n, w)] or 0
end

function D:AtMap(map, x, y)
    local inst, n, w = LP.Geo:ToWorld(map, x, y)
    return self:At(inst, n, w)
end

-- hoechstes Mob-Level entlang einer Strecke, die ersten skip Yards ausgenommen (nicht zwischengespeichert).
-- stop (optional): sobald ein Level >= stop gefunden ist, sofort zurueck (der Aufrufer fragt nur "ab Grenze?").
-- 3.12.32 PF-A: dieselben Messpunkte wie bisher (n1 + dn * i / steps), aber ohne Funktionsaufruf je Punkt und
-- ohne die Punkte vor skip einzeln zu pruefen – kostete auf der Allianz (Elwynn L10) 95 % der Planungszeit.
local floor = math.floor
-- 3.13.1: Ergebnisse von Route je genauen Eingaben (Ort, Ziel, skip, stop) – gleiche Eingaben und gleiche Gefahrenkarte (D.gen) ergeben
-- genau dasselbe Ergebnis. Trifft bei jeder Neuplanung am selben Ort (Ticker alle 15 s im Stehen, T150). Schlüssel mit %.17g (jede Zahl
-- exakt, tostring rundet auf 14 Stellen). Höchstens ROUTE_CACHE_MAX Einträge, dann leer.
local routeCache, routeCount, routeGen = {}, 0, nil
local ROUTE_CACHE_MAX = 4000
D.routeStats = { hits = 0, miss = 0 }
local RouteRaw
function D:Route(inst, n1, w1, n2, w2, skip, stop)
    if not inst then return 0 end
    if not cells then self:Build() end
    if routeGen ~= D.gen then wipe(routeCache) routeCount, routeGen = 0, D.gen end
    local key = string.format("%s|%.17g|%.17g|%.17g|%.17g|%.17g|%s", tostring(inst), n1, w1, n2, w2, skip or 0, tostring(stop))
    local c = routeCache[key]
    if c then D.routeStats.hits = D.routeStats.hits + 1 return self:RoutePlaces(c, inst, n1, w1, n2, w2, skip) end
    D.routeStats.miss = D.routeStats.miss + 1
    local r = RouteRaw(self, inst, n1, w1, n2, w2, skip, stop)
    if routeCount >= ROUTE_CACHE_MAX then wipe(routeCache) routeCount = 0 end
    routeCache[key] = r
    routeCount = routeCount + 1
    return self:RoutePlaces(r, inst, n1, w1, n2, w2, skip)
end
-- 3.13.7: Ort der anderen Fraktion auf der Strecke (Start- und Zielort ausgenommen) zählt wie D.TOWN
function D:RoutePlaces(r, inst, n1, w1, n2, w2, skip)
    if r >= self.TOWN or not (self.places and self.places[inst]) then return r end
    if D.PlaceHit(inst, n1, w1, n2, w2, skip, self:PlaceAt(inst, n1, w1), self:PlaceAt(inst, n2, w2)) then return self.TOWN end
    return r
end
function D:RouteCacheReset() wipe(routeCache) routeCount = 0 end
-- 3.13.1: erster Messpunkt-Index > k, an dem der Block auf dieser Achse (Startwert o, Änderung d) nicht mehr b ist (steps + 1: nie).
-- Blockindex eines Messpunkts genau wie in Route: floor(floor((o + d * k / steps) / CELL) / BLOCK)
local function BlockExit(k, b, d, o, steps)
    if d == 0 then return steps + 1 end
    local edge = (d > 0 and (b + 1) or b) * BLOCK * CELL
    local e = (edge - o) * steps / d
    e = d > 0 and math.ceil(e) or (floor(e) + 1)
    if e ~= e or e > steps + 1 then e = steps + 1 end
    if e <= k then e = k + 1 end
    while e > k + 1 and floor(floor((o + d * (e - 1) / steps) / CELL) / BLOCK) ~= b do e = e - 1 end
    while e <= steps and floor(floor((o + d * e / steps) / CELL) / BLOCK) == b do e = e + 1 end
    return e
end
D.BlockExit = BlockExit
RouteRaw = function(self, inst, n1, w1, n2, w2, skip, stop)
    if not inst then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return 0 end
    skip = skip or 0
    local dn, dw = n2 - n1, w2 - w1
    local len = math.sqrt(dn * dn + dw * dw)
    if len <= skip then return 0 end
    local steps = math.max(1, math.ceil(len / (CELL * 0.5)))
    local mx = 0
    local i = 0
    if skip > 0 then
        -- erster Punkt mit len * i / steps >= skip (genau wie die bisherige Pruefung je Punkt)
        i = floor(skip * steps / len)
        if i > 0 and len * (i - 1) / steps >= skip then i = i - 1 end
        while len * i / steps < skip do i = i + 1 end
    end
    -- 3.13.1: Blöcke überspringen. Ein Block wird übersprungen, wenn sein höchstes Level das Ergebnis nicht ändern kann: <= mx
    -- (Ergebnis exakt gleich) oder mit stop < stop (der Aufrufer fragt nur "ab Grenze?"; T291 prüft beides gegen die Rechnung je
    -- Messpunkt). Gesprungen wird zum ersten Messpunkt ausserhalb des Blocks – berechnet mit derselben Formel wie jeder Messpunkt.
    -- Der Block je Achse ist im Messpunkt-Index monoton (Formel monoton in k), die Messpunkte eines Blocks liegen also am Stück.
    local bt = blocks and blocks[inst]
    if not bt then
        for k = i, steps do
            local v = t[floor((n1 + dn * k / steps) / CELL) * 100000 + floor((w1 + dw * k / steps) / CELL)]
            if v and v > mx then
                mx = v
                if stop and mx >= stop then return mx end
            end
        end
        return mx
    end
    local k = i
    while k <= steps do
        local cn = floor((n1 + dn * k / steps) / CELL)
        local cw = floor((w1 + dw * k / steps) / CELL)
        local bn, bw = floor(cn / BLOCK), floor(cw / BLOCK)
        local bmax = bt[bn * 100000 + bw] or 0
        if bmax <= mx or (stop and bmax < stop) then
            local en, ew = BlockExit(k, bn, dn, n1, steps), BlockExit(k, bw, dw, w1, steps)
            k = en < ew and en or ew
        else
            local v = t[cn * 100000 + cw]
            if v and v > mx then
                mx = v
                if stop and mx >= stop then return mx end
            end
            k = k + 1
        end
    end
    return mx
end

-- 3.12.71 ERA-1 (b): jede Zelle, die die Strecke beruehrt (Gitter-Durchlauf), statt Messpunkten alle 50 Yards.
-- Vorher wurde eine Zelle, deren Ecke die Strecke schneidet, nur getroffen, wenn ein Messpunkt hineinfiel: 30 Yards
-- weiter lag die Strecke "sicher" bzw. "gefaehrlich" (x25) – der Weg sprang zwischen zwei Varianten, der Pfeil drehte.
function D.CellsOnLine(t, n1, w1, n2, w2)
    local cn, cw = floor(n1 / CELL), floor(w1 / CELL)
    local en, ew = floor(n2 / CELL), floor(w2 / CELL)
    local dn, dw = n2 - n1, w2 - w1
    local sn, sw = dn > 0 and 1 or -1, dw > 0 and 1 or -1
    local inf = math.huge
    local tdn = dn ~= 0 and math.abs(CELL / dn) or inf
    local tdw = dw ~= 0 and math.abs(CELL / dw) or inf
    local tmn = dn ~= 0 and (((sn > 0) and (cn + 1) * CELL - n1 or n1 - cn * CELL) / math.abs(dn)) or inf
    local tmw = dw ~= 0 and (((sw > 0) and (cw + 1) * CELL - w1 or w1 - cw * CELL) / math.abs(dw)) or inf
    local mx = 0
    local guard = math.abs(en - cn) + math.abs(ew - cw) + 2
    while guard > 0 do
        local v = t[cn * 100000 + cw]
        if v and v > mx then mx = v end
        if cn == en and cw == ew then break end
        if tmn < tmw then cn, tmn = cn + sn, tmn + tdn
        else cw, tmw = cw + sw, tmw + tdw end
        guard = guard - 1
    end
    return mx
end

-- hoechstes Mob-Level entlang einer Strecke (zwischengespeichert)
function D:Segment(inst, n1, w1, n2, w2)
    if not inst then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return D.PlaceHit(inst, n1, w1, n2, w2) and self.TOWN or 0 end
    -- 3.12.71: Schluessel auf 1 Yard (vorher 40 Yards: zwei verschiedene Strecken teilten sich ein Ergebnis, je nachdem,
    -- welche zuerst gerechnet wurde). Knoten des Wegenetzes liegen fest, ihre Strecken treffen den Speicher weiter.
    local ck = inst .. ":" .. floor(n1 + 0.5) .. ":" .. floor(w1 + 0.5) .. ":" .. floor(n2 + 0.5) .. ":" .. floor(w2 + 0.5)
    local c = segCache[ck]
    if c then return c end
    local mx = D.CellsOnLine(t, n1, w1, n2, w2)
    if mx < self.TOWN and D.PlaceHit(inst, n1, w1, n2, w2) then mx = self.TOWN end      -- 3.13.7: Ort der anderen Fraktion
    if segCount > 50000 then wipe(segCache) segCount = 0 end
    segCache[ck] = mx
    segCount = segCount + 1
    return mx
end

-- Ist ein Mob dieses Levels fuer den Spieler erlaubt?
function D:OK(mobLevel, level)
    if not mobLevel then return true end
    return mobLevel < (level or LP:PlayerLevel() or 1) + self.MAX_DIFF
end

-- Level-Grenze (ab hier tabu)
function D:Limit(level) return (level or LP:PlayerLevel() or 1) + self.MAX_DIFF end

-- Gefahr entlang eines ganzen Weges (Punkte {inst, n, w, ...}). Die ersten skip Yards zaehlen nicht;
-- steht man schon in einem Gebiet mit zu starken Mobs (Level >= lim), zaehlt auch der Weg hinaus nicht
-- (hoechstens ESCAPE Yards) - entscheidend ist, nicht in ein solches Gebiet hineinzulaufen.
-- Liefert das hoechste Level und den Punkt (inst, n, w), an dem es auftritt.
local ESCAPE = 600
function D:PathDanger(path, skip, lim)
    if not path or #path < 2 then return 0 end
    if not cells then self:Build() end
    -- 3.13.7: Orte der anderen Fraktion (Start- und Zielort ausgenommen)
    local p1, pz = path[1], path[#path]
    local ex1 = type(p1) == "table" and p1[1] and self:PlaceAt(p1[1], p1[2], p1[3]) or nil
    local ex2 = type(pz) == "table" and pz[1] and self:PlaceAt(pz[1], pz[2], pz[3]) or nil
    local placeWalked = 0
    local pmx, pmi, pmn, pmw = 0, nil, nil, nil
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local via = b.via
        if pmx == 0 and a[1] == b[1] and via ~= "boat" and via ~= "zep" and via ~= "tram" and via ~= "portal" then
            local len = math.sqrt((b[2] - a[2]) ^ 2 + (b[3] - a[3]) ^ 2)
            local sk = math.max(0, (skip or 0) - placeWalked)
            local hit, p = D.PlaceHit(a[1], a[2], a[3], b[2], b[3], sk, ex1, ex2)
            if hit then pmx, pmi, pmn, pmw = self.TOWN, a[1], p.n, p.w end
            placeWalked = placeWalked + len
        end
    end
    local walked, escaping = 0, lim ~= nil
    local mx, mi, mn, mw = 0, nil, nil, nil
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local via = b.via
        if a[1] == b[1] and via ~= "boat" and via ~= "zep" and via ~= "tram" and via ~= "portal" then
            local t = cells and cells[a[1]]
            local dn, dw = b[2] - a[2], b[3] - a[3]
            local len = math.sqrt(dn * dn + dw * dw)
            local steps = math.max(1, math.ceil(len / (CELL * 0.5)))
            for k = 0, steps do
                local pos = walked + len * k / steps
                local n, w = a[2] + dn * k / steps, a[3] + dw * k / steps
                local v = t and t[Key(n, w)] or 0
                if escaping and (v < lim or pos > ESCAPE) then escaping = false end
                if pos >= (skip or 0) and not escaping and v > mx then mx, mi, mn, mw = v, a[1], n, w end
            end
            walked = walked + len
            if i % 4 == 0 then LP:Yield("graph") end
        end
    end
    if pmx > mx then return pmx, pmi, pmn, pmw end
    return mx, mi, mn, mw
end

-- Wo grinden? Naechste Zelle mit Mobs im passenden Level (eigenes Level -2 bis +1, also nicht grau und machbar)
-- im Umkreis; liefert inst, n, w und das Mob-Level
function D:GrindSpot(inst, n, w, level, radius)
    if not inst or not n then return nil end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return nil end
    radius = radius or 1500
    local lo, hi = level - 2, level + 1
    local r = math.ceil(radius / CELL)
    local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
    local best, bd, blv
    for dn = -r, r do
        for dw = -r, r do
            local v = t[(cn + dn) * 100000 + (cw + dw)]
            if v and v >= lo and v <= hi then
                local d = dn * dn + dw * dw
                if not bd or d < bd then best, bd, blv = { (cn + dn + 0.5) * CELL, (cw + dw + 0.5) * CELL }, d, v end
            end
        end
    end
    if not best then return nil end
    return inst, best[1], best[2], blv
end

-- Monster auf dem Weg, die man im Vorbeigehen mitnimmt (Speedrun): Zellen entlang des Weges mit Mobs, die EP
-- geben (nicht grau: hoechstens greyDiff unter dem Spieler) und machbar sind (hoechstens 2 Level darueber).
-- Liefert die Zahl der Kills (eine je Zelle, hoechstens eine je perYards) und die Summe ihrer Level.
function D:WayKills(path, level, greyDiff, perYards, minLevel)
    if not path or #path < 2 then return 0, 0 end
    if not cells then self:Build() end
    local lo, hi = level - (greyDiff or 5) + 1, level + 2
    local lo0 = lo                                   -- 3.13.8 LP-T1 (T174): Kandidaten ohne die Untergrenze minLevel zählen
    if minLevel and minLevel > lo then lo = minLevel end
    local seen, kills, sum, len = {}, 0, 0, 0
    local cand = 0
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local via = b.via
        if a[1] == b[1] and via ~= "boat" and via ~= "zep" and via ~= "tram" and via ~= "portal" then
            local t = cells and cells[a[1]]
            local dn, dw = b[2] - a[2], b[3] - a[3]
            local l = math.sqrt(dn * dn + dw * dw)
            len = len + l
            local steps = math.max(1, math.ceil(l / (CELL * 0.5)))
            for k = 0, steps do
                local key = Key(a[2] + dn * k / steps, a[3] + dw * k / steps)
                local v = t and t[key]
                if v and v >= lo0 and v <= hi and not seen[key] then
                    seen[key] = true
                    cand = cand + 1
                    if v >= lo then kills, sum = kills + 1, sum + v end
                end
            end
        end
    end
    local cap = math.floor(len / (perYards or 120))
    if kills > cap then sum, kills = sum * cap / math.max(1, kills), cap end
    return kills, sum, cand, cap
end

