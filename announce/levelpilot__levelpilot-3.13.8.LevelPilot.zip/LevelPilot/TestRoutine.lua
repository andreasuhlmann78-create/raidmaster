-- LevelPilot - Testroutine (/lp testroutine), Bericht über GoldSentinelTest
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Nur im Testmodus (LP:DevOnly). Läuft in Häppchen (höchstens 8 ms je Bild), nur ausserhalb des Kampfes.
-- Echte Daten: Sicherung vorher, Wiederherstellung in place nachher, Vergleich je Hauptschlüssel ("Sandbox").
-- Aktionen mit Folgen (Kaufen, Reparieren, Anlegen, Quests, Flug, Senden …) laufen über LP.Act und werden
-- während des Laufs nur mitgeschrieben (LP.Act.dry). Es wird keine Blizzard-Funktion ersetzt: Simulationen
-- laufen über setfenv auf eigene Funktionen, über eigene Tabellen (LP.API, LP.Game) und Köderwerte.
-- Ergebnisse nur über T:Check / T:Skip / T:Client. Testfall-IDs wie in testroutine-levelpilot.txt.

local _, LP = ...
local L = LP.L
local TR = {}
LP.TestRoutine = TR

local NOT_YET = "noch nicht automatisiert – folgt"
local ONLY_FOREVER = "LevelPilot nur für WoW Forever"

------------------------------------------------------------------------
-- Testfälle (ID, Bereich, Name) – über alle Versionen gleich
------------------------------------------------------------------------
TR.IDS = {
    { "T01", "A", "alle Module gestartet" },
    { "T02", "A", "Dateien ohne Modul geladen" },
    { "T03", "A", "Version .toc = Code" },
    { "T04", "A", "Version Datenpaket .toc = Code" },
    { "T05", "A", "Interface-Nummer passt zum Client" },
    { "T06", "A", "GoldSentinelGame Version 2 oder neuer" },
    { "T07", "A", "GoldSentinelTest geladen und angemeldet" },
    { "T08", "A", "echte Erkennung" },
    { "T09", "A", "Weichen mit SetTestFlavor(\"forever\")" },
    { "T10", "A", "Weichen mit SetTestFlavor(\"era\")" },
    { "T11", "A", "Weichen mit SetTestFlavor(\"tbc\")" },
    { "T12", "A", "Weichen mit SetTestFlavor(\"retail\")" },
    { "T13", "A", "SetTestFlavor(nil) stellt alles zurück" },
    { "T14", "A", "ohne GoldSentinelGame" },
    { "T15", "A", "Reihenfolge in der .toc" },
    { "T16", "B", "Fenster-Befehle" },
    { "T17", "B", "Modus-Befehle" },
    { "T18", "B", "Wegpunkt und Suche" },
    { "T19", "B", "Sprache per Befehl" },
    { "T20", "B", "Teilen, Gruppe, Bilanz" },
    { "T21", "B", "Protokoll, Diagnose, Messung, Selbsttest" },
    { "T22", "B", "Reise-Befehle" },
    { "T23", "B", "Debug, Zurück, Reset" },
    { "T24", "B", "unbekannter Befehl" },
    { "T25", "B", "Guide-Fenster LevelPilotFrame" },
    { "T26", "B", "Schritt-Menü LevelPilotStepMenu" },
    { "T27", "B", "Hinweise oben (Toasts) LevelPilotToasts" },
    { "T28", "B", "Minimap-Button LevelPilotMinimapButton" },
    { "T29", "B", "Pfeil LevelPilotArrow" },
    { "T30", "B", "Zentrale LevelPilotCenter, alle 8 Reiter" },
    { "T31", "B", "jede Option der Zentrale einmal an und aus" },
    { "T32", "B", "alle 12 Stepper" },
    { "T33", "B", "Sprachknöpfe" },
    { "T34", "B", "Zentrale » Daten: Knöpfe" },
    { "T35", "B", "Fenster der virtuellen Reise LevelPilotVirtualFrame" },
    { "T36", "B", "Gruppen-Panel LevelPilotGroupPanel" },
    { "T37", "B", "Aktionsleiste und Tastenbelegung" },
    { "T38", "B", "Spenden-Fenster" },
    { "T39", "B", "Planung" },
    { "T40", "B", "Planner:KillXPFormula – Werte" },
    { "T41", "B", "Planner:GreyLevel" },
    { "T42", "B", "Planner:GreenXPFactor / KillXP ohne Messung" },
    { "T43", "B", "Dungeon-Faktoren" },
    { "T44", "B", "Questlevel bei Quest-Kills" },
    { "T45", "B", "Speedrun-Filter" },
    { "T46", "B", "Dungeon-Übersicht" },
    { "T47", "B", "Diagnose" },
    { "T48", "B", "Engine-Funktionen" },
    { "T49", "B", "Automatik Annehmen/Abgeben/Gossip" },
    { "T50", "B", "Navigation" },
    { "T51", "B", "Wegenetz Graph" },
    { "T52", "B", "Gelände Terrain" },
    { "T53", "B", "Höhlen Caves" },
    { "T54", "B", "Gefahr Danger" },
    { "T55", "B", "Geo" },
    { "T56", "B", "QuestDB" },
    { "T57", "B", "Namen" },
    { "T58", "B", "Recorder (Aufzeichnung)" },
    { "T59", "B", "Comm: Kodieren und Empfangen" },
    { "T60", "B", "Comm: Begrenzung je Absender" },
    { "T61", "B", "Comm: Senden" },
    { "T62", "B", "Comm: Zonen-Abgleich" },
    { "T63", "B", "Gruppe (LvPilotG)" },
    { "T64", "B", "Social (Teilen, Gruppensuche, Partner)" },
    { "T65", "B", "Session" },
    { "T66", "B", "Comfort" },
    { "T67", "B", "Supply (Vorräte, Belohnung anlegen)" },
    { "T68", "B", "Advisor (Assistent)" },
    { "T69", "B", "Hints" },
    { "T70", "B", "Pins (Karte, Fundstellen)" },
    { "T71", "B", "Plates (Namensplaketten)" },
    { "T72", "B", "Tooltips" },
    { "T73", "B", "Calib (Lernwerte)" },
    { "T74", "B", "Calib: EP-Messung je Kill" },
    { "T75", "B", "Protocol (Fehler-Protokoll)" },
    { "T76", "B", "Backup (Sichern/Laden)" },
    { "T77", "B", "Measure (/lp messen)" },
    { "T78", "B", "Sprache: Hilfsfunktionen" },
    { "T79", "B", "Core-Hilfen" },
    { "T80", "B", "alle Ereignisse einmal" },
    { "T81", "B", "alle Ticker einmal" },
    { "T82", "B", "OnUpdate-Treiber" },
    { "T83", "B", "virtuelle Reise kurz" },
    { "T84", "B", "virtuelle Reise 1–60, beide Modi" },
    { "T85", "B", "Reise abbrechen" },
    { "T86", "B", "Datenpaket-Inhalt" },
    { "T87", "B", "Werkzeuge ausserhalb des Spiels (Tools/: Sicherung.ps1, Wiederherstellen.ps1, lp_sammeln.py …)" },
    { "T88", "C", "API.ItemCooldown mit geschützten start/duration (Ruhestein)" },
    { "T89", "C", "Recorder:RecordService mit geschütztem UnitName(\"npc\")" },
    { "T90", "C", "Tooltip-Hook OnShow mit geschütztem GameTooltipTextLeft1:GetText() und geschütztem tt:GetUnit()" },
    { "T91", "C", "Calib:OnLoot mit geschütztem Beute-Text" },
    { "T92", "C", "CHAT_MSG_ADDON mit geschütztem prefix/msg/sender (Comm und Group)" },
    { "T93", "C", "Plates:ForUnit mit geschütztem UnitName/UnitGUID" },
    { "T94", "C", "Calib:ReadTarget / OnXPUpdate mit geschütztem UnitLevel/UnitXP" },
    { "T95", "C", "Measure-Zeile mit geschütztem UnitClassification" },
    { "T96", "C", "Calib:ObserveUnit mit geschützter GUID und geschütztem Level" },
    { "T97", "C", "Namensvergleich mit geschütztem Namen" },
    { "T98", "C", "EP-Anzeige mit geschütztem UnitXP/UnitXPMax (UI-Ticker im Kampf)" },
    { "T99", "C", "geschützte Werte im echten Kampf" },
    { "T100", "C", "Questlog-Funktionen" },
    { "T101", "C", "API.GreenRange ohne C_QuestLog.GetTrivialRange und GetQuestGreenRange" },
    { "T102", "C", "Händler" },
    { "T103", "C", "Gegenstände" },
    { "T104", "C", "Taschen" },
    { "T105", "C", "Talentpunkte" },
    { "T106", "C", "Hints Known ohne IsSpellKnown/IsPlayerSpell" },
    { "T107", "C", "Gruppensuche ohne ChatFrame_OpenChat" },
    { "T108", "C", "Alter Kanal LevelPilotNet: nur verlassen, nie betreten" },
    { "T109", "C", "Jäger ohne GetPetHappiness/GetPetFoodTypes" },
    { "T110", "C", "Metadaten und AddOns" },
    { "T111", "C", "Gruppe sendet über GoldSentinelSync nur an die Gruppe" },
    { "T112", "C", "weitere alte Globals ohne Prüfung" },
    { "T113", "C", "Names: collectgarbage wirft" },
    { "T114", "C", "Aktionsleiste im Kampf" },
    { "T115", "C", "Belohnung anlegen und Hinweis-Knöpfe im Kampf" },
    { "T116", "C", "Testroutine und Kampf" },
    { "T117", "C", "ADDON_ACTION_BLOCKED für LevelPilot" },
    { "T118", "C", "Kampflog nicht angemeldet" },
    { "T119", "D", "Laden in Classic Era" },
    { "T120", "D", "Hinweis \"für WoW Forever gebaut\"" },
    { "T121", "D", "Weichen auf dem alten Weg" },
    { "T122", "D", "TBC und Retail" },
    { "T123", "E", "Neuinstallation (leere SavedVariables)" },
    { "T124", "E", "Migration Speedrun-Strenge (3.10)" },
    { "T125", "E", "Migration Sprache" },
    { "T126", "E", "Migration Protokoll" },
    { "T127", "E", "Überlagerung der Flugpunkte nach einem Abbruch" },
    { "T128", "E", "alte Fassung (Beispieldaten im Test)" },
    { "T129", "E", "beschädigte Einträge (nil, falscher Typ)" },
    { "T130", "E", "Datenpaket fehlt, falsches Format, zu alt" },
    { "T131", "E", "QuestieDB vorhanden, aber zu alt oder unvollständig" },
    { "T132", "E", "Einstellungen pro Charakter" },
    { "T133", "F", "Schlüssel in jeder Sprache vorhanden" },
    { "T134", "F", "Formatplatzhalter" },
    { "T135", "F", "Format mit Werten" },
    { "T136", "F", "jede Sprache aktivieren, Hauptfenster öffnen" },
    { "T137", "F", "Sprachen ohne Schrift" },
    { "T138", "F", "Namen je Sprache" },
    { "T139", "F", "Texte von GoldSentinelGame" },
    { "T140", "G", "gemeinsame Dateien mit anderen GoldSentinel-Addons" },
    { "T141", "G", "keine globalen Namen überschrieben" },
    { "T142", "G", "Fehler-Handler-Kette" },
    { "T143", "G", "Schnittstellen zu anderen GoldSentinel-Addons" },
    { "T144", "G", "Questie mit und ohne" },
    { "T145", "G", "Addon-Präfixe angemeldet" },
    { "T146", "H", "UI:Refresh (Ticker 1 s)" },
    { "T147", "H", "Engine:CheckSteps (Ticker 0,5 s)" },
    { "T148", "H", "Navigations-Treiber (OnUpdate alle 0,05 s: Nav:Recalc(false), Pfeil, Minikarte)" },
    { "T149", "H", "Pins-Treiber und Weltkarte" },
    { "T150", "H", "Planner:Replan(true) (Ticker 15 s und bei Ereignissen)" },
    { "T151", "H", "Graph:Path für eine lange Route (Orgrimmar -> Wegkreuz)" },
    { "T152", "H", "Drosselung bei \"vom Weg ab\"" },
    { "T153", "H", "Plaketten, Tooltip und Beobachtung je Einheit" },
    { "T154", "H", "Comm" },
    { "T155", "H", "Planung je Reiseschritt" },
    { "T156", "H", "alle 1-s-Ticker zusammen (ui, caves, recorder, session)" },
    { "T157", "H", "Speicher" },
    { "T158", "I", "absichtlicher Fehler über LP:Safe" },
    { "T159", "I", "Lua-Fehler ausserhalb eines pcall" },
    { "T160", "I", "Fehler in einem Ereignis-Handler" },
    { "T161", "I", "Fehler in einem LP:Fire-Listener" },
    { "T162", "I", "Modul-Startfehler in der Diagnose" },
    { "T163", "I", "Ticker-Fehler" },
    { "T164", "I", "Fehler der virtuellen Reise" },
    { "T165", "I", "Bericht gespeichert und datenschutzkonform" },
    { "T166", "I", "Testfall-IDs eindeutig und vollständig" },
    { "T167", "J", "[V Schritt 1] GoldSentinelGame unverändert und vor allen eigenen Dateien" },
    { "T168", "J", "[V Schritt 1] G.Status() in der Diagnose" },
    { "T169", "J", "[V Schritt 1] Namensvergleiche über G.SameName" },
    { "T170", "J", "[V Schritt 2.1] Datenpaket-Version passt" },
    { "T171", "J", "[V Launch] Interface-Nummer in beiden .toc" },
    { "T172", "J", "[Z1a] EP je Kill nach Levelunterschied" },
    { "T173", "J", "[Z1b] Abschlag für grüne Monster nur in Forever" },
    { "T174", "J", "[Z1c] Weg-Kills mit mittlerem Monsterlevel" },
    { "T175", "J", "[Z1d] Quest-Kills mit Questlevel" },
    { "T176", "J", "[Z2] Dungeon-Werte Forever 0,36 / 1,5, Classic 1,0" },
    { "T177", "J", "[Z3] Messung EP je Kill: geschützt, erholt, Gruppe" },
    { "T178", "J", "[Z4] Gruppen-EP-Hinweis in Forever" },
    { "T179", "J", "[Z5a] \"Zeit bis 60\" klar beschriftet" },
    { "T180", "J", "[Z5b] beide Modi vergleichen, echter Modus bleibt" },
    { "T181", "J", "[Z5c] Reisebericht nennt die Herkunft der Werte" },
    { "T182", "J", "[Z NICHT ÄNDERN] EP-Tabelle und Regeln unverändert" },
    { "T183", "J", "[Z Test 1] Zeiten 1–60 Normal und Speedrun" },
    { "T184", "J", "[K1] /lp reise bericht ohne Lua-Fehler (global L)" },
    { "T185", "J", "[K2] Ruhestein-Abklingzeit mit geschützten Werten" },
    { "T186", "J", "[K3] Recorder: geschützter NPC-Name" },
    { "T187", "J", "[K4] Tooltip-Titel und GetUnit geschützt" },
    { "T188", "J", "[K5] Calib:OnLoot geschützt" },
    { "T189", "J", "[K6] CHAT_MSG_ADDON geschützt (Comm und Group)" },
    { "T190", "J", "[K7] collectgarbage in Names mit pcall" },
    { "T191", "J", "[K8] Hints Known ohne Rückgabe true" },
    { "T192", "J", "[K9] Gruppen-Text ohne ChatFrame_OpenChat" },
    { "T193", "J", "[K10] alter Kanal LevelPilotNet nur verlassen" },
    { "T194", "J", "[K11] GreenRange mit UnitQuestTrivialLevelRange" },
    { "T195", "J", "[K12] Talent- und Jägerfunktionen" },
    { "T196", "J", "[K13] Dropraten ohne Kampflog" },
    { "T197", "J", "[K14] Navigation: 0,5 s Mindestpause auch bei \"off\", nicht neu rechnen auf Flügen" },
    { "T198", "J", "[K15] alle Ticker in LP:Safe" },
    { "T199", "J", "[K16] Protokoll mit beschädigtem Eintrag startet" },
    { "T200", "J", "[K17] Measure: UnitClassification geschützt" },
    { "T201", "J", "[K18] Tooltips nutzen LP.API.IsQuestDone" },
    { "T202", "J", "[K19] eigene Erkennung auf LP.Game umgeleitet" },
    { "T203", "J", "[K20] Mindestversion des Datenpakets" },
    { "T204", "J", "[K Frage] Standardwerte mit echten Folgen" },
    { "T205", "J", "[R] Datenpaket nur in der gemeinsamen ZIP" },
    -- 3.12.5: Grundeinstellung der Automatiken und einmalige Hinweise (anweisung-levelpilot-automatiken.txt)
    { "T206", "J", "[A1] Neuinstallation: Reparieren/Flug an, Nachkaufen/Belohnung aus" },
    { "T207", "J", "[A1] Bestehende Einstellungen bleiben" },
    { "T208", "J", "[A2a] Hinweis Nachkaufen einmal, nichts gekauft" },
    { "T209", "J", "[A2b] Hinweis Belohnung einmal, nichts gewählt oder angelegt" },
    { "T210", "J", "[A2c] Option an -> kein Hinweis" },
    { "T211", "J", "[A2d] Im Kampf -> kein Hinweis" },
    { "T212", "J", "[3.12.5-1] Drop-Messung: erneut geöffnete Leiche zählt nicht doppelt" },
    -- 3.12.6: offen-Punkt 2 (Berufszauber im Client)
    { "T213", "J", "[3.12.6-2] Berufszauber: C_SpellBook und IsPlayerSpell im Client" },
    -- 3.12.7: Routenbefund aus Mulgore und Lua-Fehler in CheckNav
    { "T214", "J", "[3.12.7-1] Abgabebereite Quests in der Nähe zuerst (Mulgore Fall 1 und 2)" },
    { "T215", "J", "[3.12.7-2] Kein Ziel und keine Linie im Gebirge (unplausible Orte)" },
    { "T216", "J", "[3.12.7-3] Protokoll CheckNav mit geschützten Werten" },
    -- 3.12.8: Thunder Bluff und Mulgore zusammen planen, Vorrang-Ziele nie vor nahe Abgaben
    { "T217", "J", "[3.12.8-1] Thunder Bluff und Mulgore: ein Fokus, kein FOKUS-Eintrag, Vorrang-Ziel nach nahen Abgaben" },
    -- 3.12.9: Linie nur über bekannte Wege
    { "T218", "J", "[3.12.9-1] Wegnetz statt Luftlinie: ohne bekannten Weg keine Linie, nur Pfeil \"Weg unbekannt\"" },    -- 3.12.10: Sackgassen nur aus reiner Laufzeit
    { "T219", "J", "[3.12.10-1] FEST nur bei Laufzeit: 10 min AFK, 2 min stehen + 1 min laufen, 4 min im Kreis" },    -- 3.12.11: echte NPC-Orte
    { "T220", "J", "[3.12.11-1] Echter Ort eines Questgebers korrigiert das Ziel" },    -- 3.12.12: Wegdaten zum Einsenden
    { "T221", "J", "[3.12.12-1] Wegdaten: /lp wege und GSWEGE1 ohne Namen, nur Neues, Grösse begrenzt" },    -- 3.12.13: erst die offenen Quests der Zone, dann gesammelt weiter
    { "T222", "J", "[3.12.13-1] Offene Quests in Mulgore vor Abgaben im Brachland" },    -- 3.12.14: geschützte Wahrheitswerte aus Unit*-Abfragen
    { "T223", "J", "[3.12.14-1] UnitIsAFK & Co. geschützt: kein Fehler, AFK über den eigenen Leerlauf" },    -- K. Oberfläche im echten Client (UICheck.lua, aus der Vorlage T18–T23)
    { "T224", "K", "Eigene Tooltips verdecken keine Knöpfe" },
    { "T225", "K", "Kein Überlappen mit Blizzard- oder GoldSentinel-Fenstern" },
    { "T226", "K", "Fenster ganz im Bildschirm" },
    { "T227", "K", "Beschriftungen von Knöpfen nicht abgeschnitten" },
    { "T228", "K", "Angezeigte Spielwerte plausibel („N fertig“ = Abgeben, Questlog, Stufe, Position)" },
    { "T229", "K", "Keine Fehlerschleife (gleiche Meldung > 10× in der Sitzung)" },
    -- 3.12.16: graue Gegenstände automatisch verkaufen, kein Verkaufen-Knopf
    { "T230", "J", "[3.12.16-1] Graue Items: Option an verkauft nur Qualität 0 mit Wert, ungesperrt; Chatzeile" },
    { "T231", "J", "[3.12.16-2] Graue Items: Option aus (auch /lp grau) – nichts verkauft, keine Zeile" },
    { "T232", "J", "[3.12.16-3] Graue Items: Abbruch bei MERCHANT_CLOSED" },
    { "T233", "J", "[3.12.16-4] Graue Items: im Kampf nichts, Kampfbeginn bricht ab" },
    { "T234", "J", "[3.12.16-5] Graue Items: im Test nur mitgeschrieben, kein Knopf am Händlerfenster" },
    -- 3.12.17: Wegdaten (Auswertung testberichte/wege)
    { "T235", "J", "[3.12.17-1] Wegnetz: Anfang/Ende und Kreuzung bis 10 Yards an bestehende Kante gehängt" },
    { "T236", "J", "[3.12.17-2] Wegpunkte höchstens 25 Yards auseinander, Ecke > 30° bleibt" },
    { "T237", "J", "[3.12.17-3] Keine Wege auf der Kontinentkarte (Aufzeichnung und Wegdaten)" },
    { "T238", "J", "[3.12.17-4] Wegdaten NPC: old/new als [x, y], oldMap, nächster Fundort, nopack" },
    { "T239", "J", "[3.12.17-5] Datenpaket: Orte von NPC 10666, 10881 und 15350 stimmen" },
    -- 3.12.18: eigene Tooltips neben dem Fenster
    { "T240", "J", "[3.12.18-1] Tooltip neben dem Fenster (rechts, sonst links, sonst darunter), nie über den Knöpfen" },
    -- 3.12.19: übrige Abfragen mit geschütztem Wert
    { "T241", "J", "[3.12.19-1] GetPlayerFacing, IsIndoors, IsResting, GetUnitSpeed, UnitLevel geschützt: kein Fehler, Rückfall" },
    -- 3.12.21: GoldSentinelSync 2 und GoldSentinelTest 2
    { "T242", "J", "[T-SY1/T-GS1/T-GS4] Senden nur über GoldSentinelSync, nie CHANNEL, kein Kanal-Beitritt" },
    { "T243", "J", "[T-SY2] Gilde -> GUILD, Gruppe -> PARTY/RAID, ohne beides und ohne Netz: nichts" },
    { "T244", "J", "[T-SY3] NOT_ALLOWED_IN_CHANNEL steht in der Diagnose" },
    { "T245", "J", "[T-GS2] Empfang über ep:OnMessage, Absender nil wird vertragen" },
    { "T246", "J", "[T-GS3] alte Nachricht ohne Kopf (ältere LevelPilot-Version) wird verstanden" },
    { "T247", "J", "[T-GS5] /lp sync test gibt eine Antwortzeile aus" },
    { "T248", "J", "[T-N1] GoldSentinelSync Version 2" },
    { "T249", "J", "[T-N2] ep:UseStorage: gelernter Mitspieler steht in LevelPilotDB.gsSync.book" },
    { "T250", "J", "[T-N3] net = false und scope guild: nichts ins Flüster-Netz" },
    { "T251", "J", "[T-N4] Diagnose enthält NETZ und keinen Spielernamen" },
    { "T252", "J", "[T-GT1] GoldSentinelTest Version 2" },
    { "T253", "J", "[T-GT2] ohne Zustimmung bleibt der Ausgang (share.outbox) nach einem Fehler leer" },
    -- 3.12.22: Nachprüfung 3.12.21
    { "T254", "J", "[3.12.22-1] Netz: Zonen-Anfrage und Mitspielersuche nur vom Urheber, eigene nie ins Netz" },
    { "T255", "J", "[3.12.22-3] Zonen-Antwort höchstens 25 Nachrichten, keine bei voller Warteschlange" },
    { "T256", "J", "[3.12.22-4] Broadcast merkt nur Gesendetes" },
    { "T257", "J", "[3.12.22-5] Testroutine pumpt nur eigene Testnachrichten" },
    { "T258", "J", "[3.12.22-6] Protokoll: kein SCHRITT beim Stehen in der Stadt, kein FOKUS beim Abarbeiten der Zone" },
    -- 3.12.23
    { "T259", "J", "[3.12.23-2] Wegaufzeichnung: Lücke über 25 Yards trennt die Spur (keine gerade Linie)" },
    { "T260", "J", "[3.12.23-2] alte lange Wegstücke in Stücke <= 25 Yards geteilt, Netz bleibt verbunden" },
    -- 3.12.24: Lag beim Einloggen (befund-lag-cpu-beim-einloggen.txt)
    { "T261", "J", "[T-LAG1] Einloggen ohne Lag: Rechenzeit der ersten 60 s < 1 s" },
    { "T262", "J", "[T-LAG2] Notbremse: > 50 ms oder > 1 s in 5 s -> 60 s Pause, eine Chatzeile, LANGSAM" },
    { "T263", "J", "[T-LAG3] Last-Test: 2000 Wegpunkte, 500 Netz-Einträge, unerreichbares Ziel – Portionen <= 16 ms" },
    { "T264", "J", "[T-LAG4] Diagnose zeigt Zeiten je Modul (auch erste 60 s) und schreibt GSDIAG1" },
    { "T265", "J", "[3.12.24] Wegnetz teilen: nur > 80 Yards, 25–80 Yards unsicher, kein verwaister Knoten" },
    -- 3.12.25: Nachprüfung 3.12.24
    { "T266", "J", "[3.12.25-2] Suchschritt-Grenze gilt nur je Suche (keine globale Variable)" },
    { "T267", "J", "[3.12.25-4] von 3.12.23 geteilte Lücken (25–80 Yards) werden als unsicher erkannt" },
    { "T268", "J", "[3.12.25-3/5] LANGSAM der Notbremse bleibt; neuer Auftrag während einer Portion" },
    -- 3.12.26: umfassende Tests (anweisung-tests-umfassend.txt)
    { "T269", "J", "[TU1] Lagen-Katalog: alle Völker/Klassen/Startgebiete, Stufen 1–60, Queststand" },
    { "T270", "J", "[TU2] Abläufe: /reload unterwegs, Plan wechseln, Tod -> Geistheiler -> weiter, annehmen/abgeben" },
    { "T271", "J", "[TU3] Standardwerte: jede Option ab Werk = was der Spieler meint (Liste)" },
    { "T272", "J", "[TU4] Grundregeln mit 1000 Zufallsfällen (Weg, Belohnung, Zeiten, Kampf)" },
    { "T273", "J", "[TU6] Regressionen: jeder Befund seit 1.11. hat einen bleibenden Test" },
    { "T274", "J", "[TU5] echte Daten (nur lesen): Questlog und gemessene Zeiten gegen den Plan" },
    { "T275", "J", "[TU7] Formen des Spiels: je Lauf eine von Forever/Era/TBC im Wechsel, deDE/enUS, Fenster bei Skalierung 80 %" },
    -- 3.12.27: Befehlsliste beim Tippen (BL)
    { "T276", "J", "[T-BL1] jeder Befehl des Handlers steht in der Liste (aus derselben Tabelle)" },
    { "T277", "J", "[T-BL2] Filter /lp w und /lp we liefern genau die passenden" },
    { "T278", "J", "[T-BL3] Klick wählt, Enter führt aus (frische Auswahl <= 10 s)" },
    { "T279", "J", "[T-BL4] Chatfeld wird nie beschrieben (nur HookScript lesen)" },
    { "T280", "J", "[T-BL5] Entwickler-Befehle nur für den Entwickler" },
    { "T281", "J", "[T-BL6] alle Sprachen: jede Beschreibung übersetzt, keine Platzhalter-Fehler" },
    -- 3.12.28: Marktdaten-Netz (anweisung-marktdaten-netz.txt, MN1–MN4)
    { "T282", "J", "[MN4-1] LevelPilot lädt mit und ohne GoldSentinelMarkt.lua (angemeldet bzw. still aus)" },
    { "T283", "J", "[MN4-2] Schalter „Marktdaten teilen“ aus -> kein Lesen, kein Senden, kein Annehmen" },
    { "T284", "J", "[MN4-3] ohne Auktionshaus-API (Era/TBC) kein Lua-Fehler, nichts gelesen" },
    { "T285", "J", "[MN3] Zeile MARKT-NETZ in Testbericht und Diagnose; Schalter in der Zentrale, Standard an" },
    { "T286", "J", "[3.12.28] Zentrale: keine zwei Schalter an derselben Stelle" },
    { "T287", "J", "[T-MK1] T283 auch während ein anderes Addon einen Vollscan weitergibt (feedUntil) und mit AHSentinel" },
    -- 3.12.30
    { "T288", "J", "[T-GR1] fertige Quest mit ferner Abgabe (445 Silberwald, Spieler Undercity L10) bleibt sichtbar, Grundregel still" },
    { "T289", "J", "[T-SP1] Speicher-Messung: Zeilen SPEICHER in der Diagnose, angelegt je Modul, Bestand wächst bei Neuplanungen nicht" },
    -- 3.12.31
    { "T290", "J", "[T-ML] Schalter „Meldungen“ aus: kein Chat, keine Bildschirmmeldung, kein Ton, kein Toast, keine Assistent-Hinweise; Antworten bleiben" },
    -- 3.12.32
    { "T291", "J", "[T-PF-A] Gefahr entlang einer Strecke: schnelle Rechnung liefert genau dasselbe wie die bisherige (2000 Strecken)" },
    -- 3.12.33
    { "T292", "J", "[T-LP-D1] Questauswertung: Pausen zwischen Portionen zählen nicht als Rechenzeit; Auswertung Stufe 31 unter 16 ms" },
    { "T293", "J", "[T-GR1-K] Kompaktmodus: „+n später abgeben“ in der einen Zeile, Questnamen im Tooltip; normale Liste unverändert" },
    -- 3.12.34
    { "T294", "J", "[T-L-1] 5-Minuten-Ticker misst Speicher ohne UpdateAddOnMemoryUsage (kein Ruckler); genaue Messung nur auf Befehl" },
    { "T295", "J", "[T-PF-A2] Klick „Neu planen“ mit kalten Zwischenspeichern läuft in Portionen (längste < 16 ms), warm sofort" },
    -- 3.12.35
    { "T296", "J", "[T-UC-W1] Undercity: Auktionshaus -> Bethor Iceshard über gelaufene Wege (nicht „Weg unbekannt“)" },
    -- 3.12.36
    { "T297", "J", "[T-W3D-B1] Ebenen-Angabe (Karte|drinnen|Unterzone) wird gespeichert; W3D-Schalter aus = Wegführung wie bisher" },
    -- 3.12.37
    { "T298", "J", "[T-WEGE-1] Startwegnetz (9 Zonen seit 3.12.68, vorher Mulgore/Brachland/Donnerfels) (eigene Koordinatenlisten) geladen, nichts gespeichert" },
    -- 3.12.38
    { "T299", "J", "[T-W3D-SPRACHE] Unterzonen-Schlüssel = Name aus dem Spiel (keine Tabelle aus den Spieldaten, 3.12.88); alte Schlüssel lesbar" },
    -- 3.12.39
    { "T300", "J", "[T-LPN1-ERHOLT] Pause ausserhalb des Gasthauses: Hinweis nur bei AFK, nicht beim Ausruhen, nicht auf Höchststufe, abschaltbar" },
    { "T301", "J", "[T-LPN1-WAFFE] Waffenfertigkeit der angelegten Waffe 25+ unter dem Höchstwert: Hinweis; sonst keiner" },
    -- 3.12.40
    { "T302", "J", "[T-LPN1-MEISTER] Waffe einer noch nicht gelernten Art in der Tasche: Hinweis mit dem Waffenmeister, der sie lehrt" },
    -- 3.12.41
    { "T303", "J", "[T-LPN1-GRIND] Stelle abgegrast: Hinweis erst nach 3 Min. ohne Fortschritt am Ziel, „Andere Stelle“ plant die nächste" },
    -- 3.12.42
    { "T304", "J", "[T-LPN1-HAENDLER] Händlerfenster: Upgrades markiert (nur Kauf-Reiter, richtige Seite, aus = keine Markierung)" },
    -- 3.12.43
    { "T305", "J", "[T-LPN1-TALENT] Talent-Vorschlag: nächster Punkt des Level-Builds, Waffen-Alternative, Baum passt nicht = still" },
    -- 3.12.44
    { "T306", "J", "[T-API-NAV] LevelPilotAPI.NavigateTo: gültiges Ziel -> true und Schritt oben; ungültig/unbekannte Karte -> false" },
    -- 3.12.45
    { "T307", "J", "[T-LPN2] /lp clienttest: automatische Prüfungen, Fragen nur wo nötig, Antworten OK/Nicht OK/Überspringen, Zeilen in der Diagnose" },
    -- 3.12.46
    { "T308", "J", "[T-WEGMESSUNG] /lp wegmessung: GSWegMess fehlt = Hinweis; Start, Markieren je Schritt, Lauf überspringen, Ende stoppt die Messung" },
    -- 3.12.47
    { "T309", "J", "[T-PRUEFLISTE] Prüfliste im Spiel: im Testmodus angemeldet (15 Punkte, 3.13.0: + T362), ohne Testmodus wirkungslos, jede Erkennungsstelle löst ihren Punkt aus" },
    -- 3.12.48
    { "T310", "J", "[T-LW6] Laufweg-Messung: Luftlinie/gelaufen/Zeit Weg+Ziel, Pfadart, Neuplanung mit Richtungswechsel, Leerlauf, EP/h je Level; Sprung/Flug/AFK/Lücke zählen nicht" },
    -- 3.12.49
    { "T311", "J", "[T-LW3] Flug nach Zeit: gemessene Flugzeit/Annahme, Reittier-Tempo, Entscheid in beide Richtungen anders als die alte Strecken-Regel" },
    -- 3.12.50
    { "T312", "J", "[T-ST2] Strassennetz (Forever bzw. Classic Era): Kontinent des Spielers geladen, Knoten mit Zone, nichts gespeichert, Weg entlang einer Strasse über Strassenkanten" },
    -- 3.12.51
    { "T313", "J", "[T-LW1] Wegkosten statt Luftlinie: Umweg-Faktor je Zone (Median, Grenzen, Annahme), Reihenfolge wählt das schneller erreichbare Ziel" },
    -- 3.12.54
    { "T314", "J", "[T-NAV1A] /lp navi: Koordinaten mit Zone, Zonenname (genau/Anfang), aus, ungültig; Dienstwörter (auch repair); nächster Dienst nach Wegkosten" },
    -- 3.12.55
    { "T315", "J", "[T-LW5-E2] Classic Era: 4 Forever-Zonen zurückgerechnet (Datenpaket, Dungeon-Eingänge), Hin-/Rückweg genau, Forever unverändert, 2 Forever-Orte auf Questie zurück" },
    -- 3.12.56
    { "T316", "J", "[T-LW5-E3] Daten je Spielversion: Forever = LevelPilotDB (unverändert), Classic Era = LevelPilotDB.era; Kalibrierung liest/schreibt im Bereich der Spielversion" },
    -- 3.12.57
    { "T317", "J", "[T-LW5-E4] Forever-Eigenheiten je Spielversion: Schalter \"Server WoW Forever\" nur wo er wirkt, Hilfetext ohne Forever-Quests, NEU-Kennzeichen nur in Forever" },
    -- 3.12.58
    { "T318", "J", "[T-NAV2] Reiseplan nach Zeit: Laufen/Schiff/Laufen mit Sekunden, Flug statt Laufen, Ruhestein wenn schneller, nicht wenn nicht bereit; Text wie ein Navi" },
    -- 3.12.59
    { "T319", "J", "[T-NAV1B] /lp navi <Name>: NPC (nächster Fundort, keine feindlichen), Dungeon, Zone; Trefferliste, Wahl per Nummer, ein Treffer direkt; Dienstwörter händler/trainer" },
    -- 3.12.60
    { "T320", "J", "[T-NAV1C] Markierung auf der Weltkarte = Navi-Ziel; dieselbe Markierung nur einmal; entfernt -> Navi endet; Schalter aus -> nichts" },
    -- 3.12.61
    { "T321", "J", "[T-LW2A] Exakte Reihenfolge der nächsten 8 Schritte: kürzeste Kette, annehmen vor abgeben, Questlog läuft nie über, erster Schritt bleibt" },
    -- 3.12.62
    { "T322", "J", "[T-NAV3] Navi unterwegs: Gefahr auf dem Weg im Reiseplan (ab Spielerlevel + 3), Ankunft am Navi-Ziel mit Meldung, andere Gehe-zu-Ziele still" },
    -- 3.12.63
    { "T323", "J", "[T-NAV4] Reiseplan auch für weite Routenschritte (gleicher Schritt behält den Plan), Schnittstelle v2: Stop nur für eigene Ziele, Abfrage als Kopie, Reisezeit mit Rückruf" },
    -- 3.12.64
    { "T324", "J", "[T-LW7A] Rundgang über die Fundorte der Gegner: nur nahe und ab 3 Fundorten, nächster nicht besuchter, besucht ab 30 yd, Runde beginnt von vorn" },
    -- 3.12.65
    { "T325", "J", "[T-LW5-E5] Prüfliste im Classic-Era-Client: eigene Era-Liste (6 Punkte, vollständig), im Forever-Client die bisherige; Selbstprüfungen der Era-Punkte" },
    { "T326", "J", "[T-LW2B] Zeitfaktor auch im Normalmodus: Annahme-Wert × Anteil Questdauer an Questdauer + halbem Weg (mind. 0,35), anderer Kontinent 900 s, Questgeber teilen den Weg; Schalter aus = wie vorher; nichts ausgelassen" },
    -- 3.12.66
    { "T327", "J", "[T-LW7D] Tod als Reise: Hinweis nur im Speedrun, bis Stufe 10, Schalter an, Gewinn >= 3 min (Sterben 90 s + Auferstehen 10 s), Friedhof auf demselben Kontinent" },
    -- 3.12.67
    { "T328", "J", "[T-LW8-2] Flugpreise: beim Flugmeister je erreichbarem Ziel mitgeschrieben (nur ab dem aktuellen Ort), im Reiseplan gezeigt, sonst „Preis unbekannt“; neuer Preis ersetzt den alten" },
    -- 3.12.68
    { "T329", "J", "[T-LW7E] Messlatte: Bestzeit je Stufe (alle Charaktere) gegen die virtuelle Reise, nur Stufen mit beiden Werten, Summen; ohne Namen" },
    -- 3.12.69
    { "T330", "J", "[T-NP-LP54-2/NP-LP49] Suche mit Umlauten und Kyrillisch in jeder Schreibweise (Zone, NPC, Dungeon, Dienst); Laufweg-Zeile REISE mit Quelle des Tempos und Komma" },
    -- 3.12.70
    { "T331", "J", "[T-NAV-T1] Vom Spieler gewähltes Navi-Ziel steht oben (vor nahen Abgaben), Vorschläge des Assistenten weiter danach" },
    -- 3.12.71
    { "T332", "J", "[T-ERA-1] Binden/Flugpunkt holen erst nach näheren Routenschritten; Pfeil schaltet über einen Wegpunkt hinter dem Spieler weiter, nie um Ecken" },
    { "T342", "J", "[T-OPT-ROUTE 1b] Stufenband je Zone aus den Questdaten; Zonen im eigenen Stufenband werden bevorzugt" },
    { "T343", "J", "[T-OPT-ROUTE H3] Ruhestein auch, wenn der Reiseplan mit Ruhestein + Flug schneller ist (nicht nur Ziel am Bindeort)" },
    { "T344", "J", "[T-EULA] Kartenrahmen zur Laufzeit messen (C_Map), gespeichert ohne Namen – Ersatz für Daten aus den Spieldateien" },
    { "T345", "J", "[TR-ALLE] testroutine alles: Zusammenfassung (bestanden, nicht prüfbar mit Grund, Fehler) und Abbrechen" },
    { "T346", "J", "[T-EULA] Talentbaum zur Laufzeit aufzeichnen (/lp talente): Namen, Reihe, Spalte, Höchstrang je Klasse und Sprache" },
    { "T347", "J", "[TR-ALLE D2] Prüflisten-Punkt beim Spielen abgehakt -> eigener kleiner GSTEST-Bericht (Punkt, Messwert, Version, erkannt beim Spielen)" },
    { "T348", "J", "[ING-3.12.89-1] Wegsuche über eigene Wege: innere Punkte als Kette (gleicher Weg, gleiche Kosten, weniger Rechenzeit)" },
    { "T349", "J", "[ING-3.12.89-6] Testroutine: Zeile Portionen (Bilder, längstes Bild mit Schritt, Schritte über 16 ms, Zeit je Bereich)" },
    { "T350", "J", "[TAINT] WithEnv schreibt nie in _G; wichtige Blizzard-Namen nach den Tests unverdorben (issecurevariable)" },
    { "T351", "J", "[TESTDATEN] LevelPilotAPI.TestRunning(); während Tests kein automatisches Teilen eigener Aufzeichnungen" },
    { "T352", "J", "[TAKT] Wegnetz laden in Portionen (GoldSentinelTakt): gleiches Netz wie am Stück, längstes Bild, Luftlinie solange es lädt" },
    { "T353", "J", "[TR-TAKT] Testroutine im Takt: Abgabe an sicherer Stelle, nie in pcall oder bei Ersatz (TR.hold); Bilder über 40 ms gezählt" },
    { "T354", "J", "[UMWEG-ABLAGE] Umweg-Messung je Zone abgelegt (Kennung des Netzes): gleiches Netz ohne Wegsuchen, anderes Netz misst neu" },
    { "T355", "J", "[PROTOKOLL] /lp protokoll misst den Speicher aller Addons nur mit \"speicher\"/\"mem\" (sonst kein Bild über 40 ms)" },
    { "T356", "J", "[TR-TAKT] Aufträge aus der Pause einer Prüfung werden zurückgestellt (nicht verworfen) und nach der Routine gestartet" },
    { "T357", "J", "[SYNC-TEST] Prüfungen ändern das Sync-Adressbuch nicht (Hülle + Gegenprobe), Bereinigung entfernt nur Testnamen" },
    { "T358", "J", "[LP-95-1] Sicherung in Portionen bricht bei virtueller Reise ab (keine Überlagerung kopiert, Reise bleibt)" },
    { "T359", "J", "[LP-95-2] Kennung der Umweg-Ablage: Verbindungen und Mess-Konstanten gehören dazu" },
    { "T360", "J", "[TAKT-97] Geländekarte schneller entpackt, Dungeon-Quests und Netz-Statistik im Zwischenspeicher – gleiches Ergebnis" },
    { "T361", "J", "[T150] Nachbarzählung der Questgeber über ein Raster = Zählung jede mit jeder (Grenzfälle 250 yd, Ebenen)" },
    { "T362", "J", "[TU2] Vorschläge: Später (Ruhe, Verdoppelung, Stufe/Ort), Nicht mehr (bleibt, wieder zeigen), nur am passenden Ort, gelernt -> weg" },
    { "T363", "J", "[DEV-0906] Befehlsliste: Entwickler-Befehle nur im Entwicklermodus sichtbar, normale immer" },
    { "T367", "J", "[T150] Neue Planung mit gleichem Ziel erzwingt keine neue Wegsuche (auch nicht bei unbekanntem Weg); Zielwechsel, neue Stufe -> neu" },
    { "T369", "J", "[PROF-2311] Berufs-Hinweise nur nach Prüfung: gelernt -> keiner; Stufe voll -> Geselle; Liste leer -> keiner; nicht gelernt -> Lehrling" },
    { "T370", "J", "[SPERREN-2211] Keine Wegsperren mehr: 20 alte Sperren -> 0; FEST 4 Min. -> keine Sperre; alte/empfangene Sperre ignoriert; keine gesendet" },
    { "T371", "J", "[ORTE-2211] Orte der anderen Fraktion: hindurch -> gemieden, aussen herum frei, Ziel im Ort erlaubt; andere Fraktion darf hindurch; neutrale Städte frei" },
    { "T372", "J", "[LP-M1] Abgabe/Annahme ohne Ort -> Hinweis; mit Ort -> Entfernung + Zone; Erledigen unverändert; 79007 Westfall; ohne Ort nicht als nahe Aufgabe" },
    { "T373", "J", "[LP-M2] Eine Entfernung je Weg: Kopf- und Reisezeile gleich (Yards, km-Grenze), Zeit einmal; Flug unverändert" },
    { "T374", "J", "[LP-M3] Fenstertitel: im Gebiet Name, ausserhalb \"Ziel: …\", ohne Fokus Ort, Fehler unverändert, Tooltip" },
    { "T375", "J", "[LIVEDATEN] Gegenprobe Sandbox-Vergleich: Kopie gleich, geändertes/zusätzliches Feld erkannt (nur an Kopien)" },
    { "T376", "J", "[LP-B1] Im Flug: Zeile \"Im Flug nach …\", keine Entfernung/Laufzeit, Pfeil aus; Landung -> normal" },
    { "T377", "J", "[LP-B2] Zeiten ohne Messung -> \"noch nicht gemessen\"; gemessen -> \"ca.\"; Trainerkosten nur gemessen" },
    { "T378", "J", "[LP-B3] Später abgeben: Gebiet nicht doppelt; Gebietsname wie das Spiel" },
    { "T379", "J", "[LP-B4] Chat \"Fehler-Protokoll … Auffälligkeiten\" nur im Entwicklermodus" },
    { "T380", "J", "[LESBAR-L1/L8] Kontrast >= 4,5:1, Entfernung/Zeit >= 7:1 nicht grau, Gegenprobe dunkelgrau; Schrift >= GameFontNormalSmall" },
    { "T381", "J", "[LP-T1] Virtuelle Reise wiederholbar: dieselbe kurze Reise zweimal -> gleiche Zeit, Schritte, EP, Weg" },
    { "T382", "J", "[LP-O1] Ortsliste: Steinkrallengipfel, Thalanaar (Allianz), Valormok (Horde)" },
    { "T368", "J", "[WEGQ-1242] Wegqualität: 8 Std. im AH -> 0 Abschnitte/0 Laufzeit; Kreis -> verworfen; gerade -> übernommen; abseits vom Ziel -> verworfen; AFK im Lauf -> Zeit ohne AFK" },
    { "T366", "J", "[LUECKEN-1100] Wegnetz-Lücken: durchlaufen -> gemessen und aus der Liste; bekannte Strecke, Flug/Tod, Sprung, Umweg -> nichts; Obergrenze; keine Namen; Rechenzeit" },
    { "T365", "J", "[WEGE-1100] Wegdaten ab Werk an: einmal eine Chatzeile je Konto; ausdrücklich aus bleibt aus, dann nichts gesendet" },
    { "T364", "J", "[T150] Gefahr auf der Strecke: Zwischenspeicher je genauen Eingaben (gleich -> gespeichert, kleinste Änderung -> neu gerechnet)" },
    { "T341", "J", "[T-OPT-ROUTE 1b] Kontinent als Block: anderer Kontinent nur, wenn daheim kaum noch etwas zu tun ist (3.12.84)" },
    { "T340", "J", "[T-ROUTE-Q R5] Questfolge (Annahme/Abgabe, ohne Namen) nur mit Zustimmung aufgezeichnet und als Wegdaten f = 2 gesendet" },
    { "T339", "J", "[T-ORT-1 O5] Questgeber am Weg (bis 60 yd Umweg) wird unterwegs angenommen, an der frühesten passenden Stelle" },
    { "T338", "J", "[T-ORT-1 O2] Im Ort zuerst alle Questgeber: Annahmen im selben Ort (bis 400 yd) vor Zielen ausserhalb" },
    { "T337", "J", "[T-ROUTE-Q R3] Weg springt nicht: Abkürzung am Wegbeginn, alter Weg bleibt, solange der neue nicht deutlich kürzer ist" },
    { "T336", "J", "[T-ROUTE-Q R2] Quests höchstens 2 Stufen über dem Spieler (vorher 3)" },
    { "T335", "J", "[T-ROUTE-Q R1/R4] Annehmbarer Questgeber bis 150 yd kommt vor weitere Ziele und vor Binden/Flugpunkt; fehlende Annahme wird geholt" },
    { "T334", "J", "[T-ORT-1] Orte aus den Questdaten (Häufung der Questgeber, EULA 3.12.87); Startgebiet ohne Spieldaten" },
    { "T333", "J", "[T-ERA-1] Startgebiet: unter Stufe 6 nur Ziele im Startgebiet (solange es dort Aufgaben gibt), erst annehmen, dann erledigen, kein Startgebiet anderer Völker, Binden nur auf dem Weg" },
}
TR.SHORT = { T01 = true, T02 = true, T03 = true, T04 = true, T06 = true, T07 = true, T08 = true, T39 = true,
             T50 = true, T56 = true, T133 = true }

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local IMPL, SKIP, CLIENT = {}, {}, {}
-- Rückgabe NA statt true: in dieser Lage nicht prüfbar -> als übersprungen zählen, nicht als OK
local NA = setmetatable({}, { __tostring = function() return "nicht prüfbar" end })
TR.NA = NA
TR.NA_SUFFIX = " – in dieser Lage nicht prüfbar"
TR.IMPL, TR.SKIP, TR.CLIENT = IMPL, SKIP, CLIENT

local function G() return LP.Game end
local function Count(t) local n = 0 for _ in pairs(type(t) == "table" and t or {}) do n = n + 1 end return n end
local function Near(a, b, eps) return type(a) == "number" and math.abs(a - b) <= (eps or 0.01) end
local function Ms() return debugprofilestop and debugprofilestop() or (GetTime() * 1000) end
local function S(v) return tostring(v) end

-- 3.12.93 (Ingametest 3.12.91 Punkt 1, HOCH SOFORT: Bilder bis 3308 ms): die Testroutine läuft als EINE Aufgabe des gemeinsamen
-- Takts (GoldSentinelTakt, Budget TR.BUDGET ms je Bild). Abgegeben wird nur an sicheren Stellen: zwischen zwei Prüfungen und an
-- ausdrücklich gesetzten Stellen in schweren Prüfungen (TR.Safe). Nie, solange ein Ersatz-Zustand gilt: WithEnv, WithSetting & Co.
-- laufen in pcall (Lua 5.1 kann dort nicht abgeben, der Takt erkennt pcall im Stapel und gibt dann nicht ab), und TR.hold > 0
-- sperrt TR.Safe zusätzlich für Stellen mit eigenem Ersatz ohne pcall. TR.Safe steht nur dort, wo kein Ersatz gilt und keine
-- Zeit gemessen wird – sonst sähe anderer Code in fremden Bildern Testwerte bzw. die Messung zählte fremde Bilder mit.
local function Takt()
    local t = _G.GoldSentinelTakt
    return type(t) == "table" and type(t.Check) == "function" and type(t.Start) == "function" and t or nil
end
TR.BUDGET = 4            -- ms je Bild (Ziel <= 5 ms, Grenze 40 ms)
TR.TIMEOUT = 1800        -- s: "alles" mit langen Reisen dauert im Spiel rund 6 min (Bericht 3.12.91: 330 s)
TR.hold, TR.pausedMs = 0, 0
-- Abgeben, wenn das Budget dieses Bildes verbraucht ist. true = abgegeben (und im nächsten Bild weiter).
function TR.Safe(label)
    local job = TR.job
    if not job or (TR.hold or 0) > 0 then return false end
    local Tk = Takt()
    if not Tk then return false end
    -- eben erst über Budget und Abgabe nicht möglich (pcall im Stapel): höchstens einmal je Millisekunde den Stapel lesen
    local t = Ms()
    if TR.blockedT and t - TR.blockedT < 1 and t >= TR.blockedT then return false end
    -- in einer freigegebenen Rechnung (TR.Coop) ruhen während der Pause Neuplanung und Aufträge von anderem Code (P:Replan,
    -- LP.Jobs.Start): die angehaltene Rechnung darf nicht von einer zweiten gleichen Rechnung überholt werden
    local coop = (TR.coop or 0) > 0
    if coop then TR.coopPause = true end
    -- Etikett der Takt-Messung: Prüfung und Stelle (z. B. "T136 Zentrale")
    if label ~= nil and TR.cur ~= nil and tostring(label) ~= tostring(TR.cur) then label = tostring(TR.cur) .. " " .. tostring(label) end
    local yielded = Tk.Check(label)
    if coop then TR.coopPause = false end
    if yielded then
        TR.pausedMs = TR.pausedMs + (Ms() - t)
        TR.blockedT = nil
        return true
    end
    if job.frameStart and t - job.frameStart >= (job.budget or TR.BUDGET) then
        TR.blockedT = t
        if (job.noYield or 0) == 0 then TR.NoteBlocked(label) end
    end
    return false
end
-- 3.12.99 (Ingametest 3.12.97 Punkt 4: "Abgabe nicht möglich" 388, Stellen im Bericht abgeschnitten): Stelle jeder nicht möglichen
-- Abgabe = Aufrufer der C-Grenze (pcall, xpcall, Show …) als Datei:Zeile, gezählt höchstens einmal je Millisekunde (wie oben)
TR.blockedSites = {}
function TR.NoteBlocked(label)
    local s
    if type(_G.debugstack) == "function" then s = _G.debugstack(3, 200, 0)
    elseif type(debug) == "table" and type(debug.traceback) == "function" then s = debug.traceback("", 3) end
    if type(s) ~= "string" then return end
    local fn, site
    for line in s:gmatch("[^\n]+") do
        if fn then
            local file, ln = line:match("([%w_]+)%.lua[^:]*:(%d+)")
            site = file and (file .. ":" .. ln) or "?"
            break
        elseif line:find("[C]", 1, true) then
            local f = line:match("in function [`'\"]?([%w_%.:]+)") or "?"
            if f ~= "debugstack" and f ~= "traceback" then fn = f end
        end
    end
    if not fn then return end
    local key = tostring(label or TR.cur or "-") .. " @" .. tostring(site) .. " (" .. fn .. ")"
    local sites = TR.blockedSites
    if sites[key] then sites[key] = sites[key] + 1
    elseif (sites.n or 0) < 40 then sites[key] = 1 sites.n = (sites.n or 0) + 1 end
end
-- 3.13.1 (Ingametest 3.13.0 Punkt 3a: Takt "2 (T290 Zentrale, T353 Gegenprobe)", Stellen nur T353): TR.Safe sieht nur die Abgaben,
-- die es selbst versucht. Scheitert die Abgabe einer verschachtelten Rechnung (LP.PCall/PCallY in einem pcall), zählt das nur der
-- Takt (GoldSentinelTakt Sliced). Diese Etiketten kommen jetzt aus der Takt-Zählung dazu ("verschachtelt"); die Summe = Takt-Zahl.
function TR.BlockedLine(job)
    local arr, mine = {}, 0
    local seen = {}
    for k, v in pairs(TR.blockedSites or {}) do
        if k ~= "n" then
            arr[#arr + 1] = { k, v }
            mine = mine + v
            seen[k:match("^(.-) @") or k] = true
        end
    end
    local st = type(job) == "table" and type(job.stats) == "table" and job.stats or nil
    local total = st and tonumber(st.blocked) or mine
    local rest = total - mine
    if rest > 0 and st and type(st.blockedAt) == "table" then
        local missing = {}
        for _, lab in ipairs(st.blockedAt) do
            local l = tostring(lab):match("^(.-) %(") or tostring(lab)
            if not seen[l] then missing[#missing + 1] = tostring(lab) end
        end
        if #missing > 0 then
            arr[#arr + 1] = { table.concat(missing, ", ") .. " @" .. LP.L["verschachtelt"], rest }
        end
    end
    if #arr == 0 then return nil end
    table.sort(arr, function(a, b) if a[2] ~= b[2] then return a[2] > b[2] end return a[1] < b[1] end)
    local out = {}
    for i = 1, math.min(#arr, 8) do out[#out + 1] = arr[i][1] .. " " .. arr[i][2] .. "×" end
    return LP.L("Abgabe nicht möglich, Stellen (%d): %s", #arr, table.concat(out, ", "))
end
-- wie pcall; im Takt darf f an TR.Safe-Stellen abgeben (pcall selbst kann das in Lua 5.1 nicht)
local function PCallY(f, ...)
    local Tk = Takt()
    if Tk and Tk.PCall and TR.job then return Tk.PCall(f, ...) end
    return pcall(f, ...)
end
TR.PCall = PCallY
-- Ersatz ohne pcall (eigene Tauschstellen in einer Prüfung): solange body läuft, gibt TR.Safe nie ab
local function Hold(body, ...)
    TR.hold = (TR.hold or 0) + 1
    local res = { pcall(body, ...) }
    TR.hold = TR.hold - 1
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2, table.maxn(res))
end
TR.Hold = Hold
-- Rechnung freigeben: LP:Yield-Stellen in fn (und in LP.Jobs am Stück) dürfen über TR.Safe abgeben. Nur dort benutzen, wo kein
-- Ersatz-Zustand gilt und fn nicht gemessen wird. Fehler werden weitergegeben.
local function Coop(fn, ...)
    TR.coop = (TR.coop or 0) + 1
    local res = { PCallY(fn, ...) }
    TR.coop = TR.coop - 1
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2, table.maxn(res))
end
TR.Coop = Coop
-- 3.12.93: volle Speicherbereinigung in Portionen (Ingametest 3.12.91: T157 178 ms; Nachbau Laptop-Daten: collectgarbage("collect")
-- am Start 120 ms, nach den Reisen 150 ms je in einem Bild). Schritte bis zwei Durchgänge vollständig sind (der erste kann schon
-- mitten im Gang sein) – danach ist aller Müll von vorher weg, wie bei "collect". Ohne Takt-Aufgabe oder ohne "step": am Stück.
function TR.FullGC(label)
    if not TR.job then collectgarbage("collect") return "collect" end
    local cycles, n = 0, 0
    while cycles < 2 and n < 1000000 do
        local ok, done = pcall(collectgarbage, "step", 0)
        if not ok then collectgarbage("collect") return "collect" end
        if done then cycles = cycles + 1 end
        n = n + 1
        if n % 16 == 0 then TR.Safe(label) end
    end
    if cycles < 2 then collectgarbage("collect") return "collect" end
    return "step"
end

-- body ausführen, danach restore() – auch im Fehlerfall – und den Fehler weitergeben.
-- 3.12.93: clean = true (nur echte Zustände wie ein offenes Fenster, kein Ersatz): body darf an TR.Safe-Stellen abgeben.
local function Guard(body, restore, clean)
    local ok, a, b, c
    if clean then ok, a, b, c = PCallY(body) else ok, a, b, c = pcall(body) end
    restore()
    if not ok then error(a, 0) end
    return a, b, c
end

-- Simulierte Spielversion (GoldSentinelGame.SetTestFlavor), immer zurück
local function WithFlavor(fl, body)
    local g = G()
    if not g or not g.SetTestFlavor then error("GoldSentinelGame fehlt", 0) end
    g.SetTestFlavor(fl)
    return Guard(body, function() g.SetTestFlavor(nil) end)
end

-- Einstellung vorübergehend setzen (über LP.db), immer zurück
local function WithSetting(map, body)
    local old = {}
    for k, v in pairs(map) do old[k] = { LP.db[k] } LP.db[k] = v end
    return Guard(body, function() for k, o in pairs(old) do LP.db[k] = o[1] end end)
end

-- 3.12.93: wie WithSetting, aber body darf an TR.Safe-Stellen abgeben – nur für Einstellungen, die anderer Code in fremden Bildern
-- nicht benutzt (z. B. wegeAuto: nur beim Ausloggen gelesen)
local function WithSettingC(map, body)
    local old = {}
    for k, v in pairs(map) do old[k] = { LP.db[k] } LP.db[k] = v end
    return Guard(body, function() for k, o in pairs(old) do LP.db[k] = o[1] end end, true)
end

-- 3.12.93: während body keine sofortige Neuplanung über LP:Throttle("replan") (Ereignisse wie QDB_CHANGED planen sonst am Stück
-- mit Testdaten neu – Nachbau Laptop-Daten T76: 80 ms im Import). Der Plan bleibt der von vorher; ein vorgemerkter Nachlauf entfällt.
local function NoReplan(body)
    LP._throttle = LP._throttle or {}
    local had = LP._throttle.replan
    local mine = had or { pending = false }
    LP._throttle.replan = mine
    return Guard(body, function()
        if LP._throttle and LP._throttle.replan == mine then
            if had then had.pending = false else LP._throttle.replan = nil end
        end
    end)
end
TR.NoReplan = NoReplan

-- calib.killxp / dungeonxp leer (gemessene Werte ausblenden), immer zurück
local function WithEmptyCalib(body)
    local c = LevelPilotDB and type(LP.Acc().calib) == "table" and LP.Acc().calib
    if not c then return body() end
    local kx, dx = c.killxp, c.dungeonxp
    c.killxp, c.dungeonxp = {}, nil
    return Guard(body, function() c.killxp, c.dungeonxp = kx, dx end)
end

-- Umgebung eigener Funktionen umleiten (setfenv). fake[k] == false bedeutet nil. _G wird nie beschrieben.
local function WithEnv(funcs, fake, body)
    local proxy = setmetatable({}, {
        __index = function(_, k)
            local v = fake[k]
            if v ~= nil then if v == false then return nil end return v end
            return _G[k]
        end,
        -- 3.12.90 (Prüfung 17.11. 20:00, TAINT-Rest-Risiko): Schreiben unter WithEnv landet in der Ersatz-Tabelle, nie in _G –
        -- so kann kein Test je eine Globale anlegen oder überschreiben (verdorbene Globale bis /reload, TAINT-1 bei AHSentinel)
        __newindex = function(_, k, v) rawset(fake, k, v) end,
    })
    local saved = {}
    for i, f in ipairs(funcs) do
        if type(f) == "function" then saved[i] = getfenv(f) setfenv(f, proxy) end
    end
    return Guard(body, function()
        for i, f in ipairs(funcs) do if saved[i] then setfenv(f, saved[i]) end end
    end)
end
TR.WithEnv = WithEnv
-- 3.12.56: wie WithEnv, dazu der Bereich der Spielversion (LP.accRoot) auf das vorgetaeuschte LevelPilotDB – Sicherung
-- und virtuelle Reise lesen ueber LP.Acc() (Classic Era: LevelPilotDB.era), nie mehr direkt die Grundtabelle
local function WithAccEnv(funcs, fake, body)
    local savedAcc = LP.accRoot
    LP.accRoot = fake.LevelPilotDB
    return Guard(function() return WithEnv(funcs, fake, body) end, function() LP.accRoot = savedAcc end)
end

-- flache Kopie einer C_-Tabelle ohne bestimmte Felder (für WithEnv)
local function Without(tbl, ...)
    if type(tbl) ~= "table" then return false end
    local t = {}
    for k, v in pairs(tbl) do t[k] = v end
    for i = 1, select("#", ...) do t[(select(i, ...))] = nil end
    return t
end

-- Köderwerte: gelten innerhalb von body als geschützt (nur LP.Game, synchron, immer zurück)
local function WithSecret(baits, body)
    local g = G()
    if not g then error("GoldSentinelGame fehlt", 0) end
    local set = {}
    for _, v in ipairs(baits) do set[v] = true end
    local orig = g.IsSecret
    g.IsSecret = function(v) return (v ~= nil and set[v] == true) or orig(v) end
    return Guard(body, function() g.IsSecret = orig end)
end

-- simulierter Kampf über LP:InCombat
local function WithCombat(state, body)
    local old = LP.testCombat
    LP.testCombat = state
    return Guard(body, function() LP.testCombat = old end)
end

local function Act() return LP.Act end
local function ActMark() return #LP.Act.log end
local function ActSince(mark, name)
    local n = 0
    for i = mark + 1, #LP.Act.log do if not name or LP.Act.log[i].name == name then n = n + 1 end end
    return n
end

local function Meta(addon, field)
    local f = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    if not f then return nil end
    local ok, v = pcall(f, addon, field)
    return ok and v or nil
end

------------------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------------------
local MODULES = { "Actions", "Advisor", "Backup", "Calib", "Caves", "Center", "Comfort", "Comm", "Danger", "Engine", "Geo",
    "Graph", "Group", "Hints", "Measure", "Names", "Nav", "Pins", "Planner", "Plates", "Protocol", "QuestDB", "Recorder",
    "SelfTest", "Session", "Social", "Supply", "Terrain", "Tooltips", "UI", "Virtual", "ClientTest", "WegMessung", "Pruefliste", "Laufweg", "Luecken" }

IMPL.T01 = function()
    local have, missing = {}, {}
    for _, m in ipairs(LP.modules) do have[m.name] = true end
    for _, n in ipairs(MODULES) do if not have[n] then missing[#missing + 1] = n end end
    local init = {}
    for n in pairs(LP.initErrors or {}) do init[#init + 1] = n end
    if #missing > 0 or #init > 0 or #LP.modules ~= #MODULES then
        return false, string.format("%d Module, fehlend: %s, Startfehler: %s", #LP.modules, table.concat(missing, ","),
            table.concat(init, ",")), #MODULES .. " Module, keine Startfehler"
    end
    return true, #LP.modules .. " Module"
end

IMPL.T02 = function()
    local miss = {}
    for _, k in ipairs({ "API", "Act", "Donate", "Seed", "Dungeons", "Gateways", "CaveSeed", "CaveForeverMaps", "LocaleEN" }) do
        if type(LP[k]) ~= "table" then miss[#miss + 1] = k end
    end
    local n = 0
    for _, c in ipairs({ "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }) do if type(LP.Locales[c]) == "table" then n = n + 1 end end
    if #miss > 0 or n ~= 10 or _G.LevelPilot ~= LP then
        return false, "fehlend: " .. table.concat(miss, ",") .. " · Übersetzungen " .. n, "alle Tabellen, 10 Übersetzungen"
    end
    return true, "10 Übersetzungen"
end

IMPL.T03 = function()
    local toc = Meta("LevelPilot", "Version")
    return toc == LP.version, S(toc), LP.version
end

IMPL.T04 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "Datenpaket LevelPilot_Data fehlt" end
    local toc = Meta("LevelPilot_Data", "Version")
    return toc == d.version and d.format == 1, S(toc) .. " / " .. S(d.version) .. " / Format " .. S(d.format), "gleich, Format 1"
end
CLIENT.T05 = "/dump select(4, GetBuildInfo()) – steht die Zahl in beiden .toc? Addon-Liste: LevelPilot nicht 'veraltet'"

IMPL.T06 = function()
    local g = _G.GoldSentinelGame
    if type(g) ~= "table" then return false, "fehlt", "Version 2" end
    local miss = {}
    for _, k in ipairs({ "IsSecret", "AnySecret", "Safe", "InCombat", "Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
        if type(g[k]) ~= "function" then miss[#miss + 1] = k end
    end
    local ok = type(g.version) == "number" and g.version >= 2 and LP.Game == g and #miss == 0 and g.flavor ~= nil and type(SlashCmdList.GOLDSENTINELGAME) == "function"
    return ok, "Version " .. S(g.version) .. (#miss > 0 and (" fehlt: " .. table.concat(miss, ",")) or ""), "Version >= 2 (heute 3), alles vorhanden"
end

IMPL.T07 = function()
    local GT = _G.GoldSentinelTest
    if type(GT) ~= "table" then return false, "fehlt", "geladen" end
    local reg = GT.registry and GT.registry.LevelPilot
    local ok = (GT.version or 0) >= 1 and reg and reg.db == LevelPilotDB and type(LevelPilotDB.gsTest) == "table"
    return ok and true or false, "Version " .. S(GT.version) .. (reg and " angemeldet" or " nicht angemeldet"), "angemeldet mit LevelPilotDB"
end

IMPL.T08 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    if g.flavor == "forever" then
        local ok = g.IsModern and g.HasSecrets and not g.IsOldAPI and LP.API.modern == true and LP.API.Forever() == true
        return ok and true or false, g.Status(), "Forever, modern"
    end
    if g.flavor == "era" then
        local ok = g.IsOldAPI and LP.API.modern == false
        return ok and true or false, g.Status(), "Era, alte API"
    end
    return true, g.Status()
end

local function FlavorBlock(fl)
    return function()
        return WithEmptyCalib(function()
            return WithSetting({ questLogMax = 0, dungeonMobXP = 0, dungeonQuestXP = 0, forever = true }, function()
                return WithFlavor(fl, function()
                    local g, P = G(), LP.Planner
                    local f, mq = LP.API.Forever(), LP.API.MaxQuests()
                    local dg, dq, gr = P:DungeonXPFactor(), P:DungeonQuestFactor(), P:GreenXPFactor(-3)
                    local note = LP.Social.ForeverGroupNote("x")
                    local got = string.format("Forever %s, Questlog %d, Dungeon %.2f/%.2f, grün %.2f", S(f), mq, dg, dq, gr)
                    if fl == "forever" then
                        return f == true and mq == 40 and Near(dg, 0.36) and Near(dq, 1.5) and Near(gr, 0.85) and note ~= "x", got,
                            "Forever true, 40, 0.36/1.50, 0.85, Gruppenhinweis"
                    elseif fl == "retail" then
                        return g.IsModern and not g.IsForever and f == false and mq == 20, got, "modern, nicht Forever, 20"
                    else
                        local okT = (fl ~= "tbc") or g.IsTBC
                        return okT and g.IsOldAPI and f == false and mq == 20 and Near(dg, 1) and Near(dq, 1) and Near(gr, 1) and note == "x",
                            got, "alt, Forever false, 20, 1/1, 1"
                    end
                end)
            end)
        end)
    end
end
local flavorBefore
IMPL.T09 = function() flavorBefore = G() and G().flavor return FlavorBlock("forever")() end
IMPL.T10 = FlavorBlock("era")
IMPL.T11 = FlavorBlock("tbc")
IMPL.T12 = FlavorBlock("retail")
IMPL.T13 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    local st = g.Status()
    return (flavorBefore == nil or g.flavor == flavorBefore) and not st:find("%[Test%]"), g.flavor .. " · " .. st, S(flavorBefore)
end

IMPL.T14 = function()
    local saved = LP.Game
    LP.Game = nil
    return Guard(function()
        local a = LP.SafeValue(5) == 5
        local b = LP.SameName("Testa-Realm", "Testa") == true and LP.SameName("Testa-Realm", "testa") == false
        return a and b, "SafeValue " .. S(a) .. ", SameName " .. S(b), "beide true"
    end, function() LP.Game = saved end)
end
SKIP.T15 = "wird von addon-check geprüft"

------------------------------------------------------------------------
-- B. Funktionen
------------------------------------------------------------------------
local function Slash(msg) SlashCmdList.LEVELPILOT(msg) end

IMPL.T17 = function()
    local real = LP.char.mode
    -- 3.12.93 (Ingametest 3.12.91: T17 44 ms in einem Bild – je Befehl eine Neuplanung): echte Befehle als freigegebene Rechnung,
    -- dazwischen eine sichere Stelle (der Modus ist eine echte Einstellung, kein Ersatz)
    return Guard(function()
        Coop(Slash, "speed")
        local a = LP.char.mode == "speed" and LP.Planner:IsSpeed()
        TR.Safe("T17")
        Coop(Slash, "normal")
        local b = LP.char.mode == "normal" and not LP.Planner:IsSpeed()
        TR.Safe("T17")
        return a and b, "speed " .. S(a) .. ", normal " .. S(b), "beide true"
    end, function() PCallY(Coop, LP.Planner.SetMode, LP.Planner, real) end, true)
end

IMPL.T19 = function()
    local before = LP.db.language
    return Guard(function()
        local r1 = LP:SetLanguage(nil)
        local r2 = LP:SetLanguage("xx")
        return r1 == false and r2 == false, "ohne Kürzel " .. S(r1) .. ", xx " .. S(r2), "false, false"
    end, function() LP.db.language = before LP:ResetLanguageCache() end)
end

IMPL.T23 = function()
    local mark = ActMark()
    local pos = { LP.db.framePos, LP.db.arrowPos, LP.db.centerPos }
    return Guard(function()
        Slash("reset")
        local n = ActSince(mark, "ReloadUI")
        return n == 1, "ReloadUI mitgeschrieben: " .. n, "1 (nicht ausgeführt)"
    end, function() LP.db.framePos, LP.db.arrowPos, LP.db.centerPos = pos[1], pos[2], pos[3] end)
end

IMPL.T24 = function()
    local was = LP.UI:IsShown()
    Slash("xyz") Slash("xyz")
    return LP.UI:IsShown() == was, S(LP.UI:IsShown()), S(was)
end

IMPL.T27 = function()
    LP.UI:Toast({ key = "test", sev = 1, text = "Test" })
    LP.UI:ClearToasts()
    return true
end

IMPL.T30 = function()
    local f = _G.LevelPilotCenter
    local wasShown = f and f:IsShown()
    return Guard(function()
        if not wasShown then LP.Center:Toggle() end
        for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do LP.Center:Select(k) end
        local esc = false
        for _, n in ipairs(UISpecialFrames or {}) do if n == "LevelPilotCenter" then esc = true end end
        return esc, "8 Reiter, Escape " .. S(esc), "Escape schliesst"
    end, function() if f and not wasShown then f:Hide() end end)
end

IMPL.T38 = function()
    local t = LP.Donate.AddonTitle()
    return t == "LevelPilot", S(t), "LevelPilot"
end

IMPL.T39 = function()
    if (UnitLevel("player") or 1) >= 60 then return NA, "Level 60" end
    LP.Planner:BuildCandidates()
    LP.Planner:Replan(true)
    local st, cur = LP.Engine:Steps(), LP.Engine:Current()
    return #st > 0 and cur and cur.key ~= nil and cur.t ~= nil, #st .. " Schritte, Zustand " .. S(LP.Planner.state), "> 0 Schritte"
end

local KXP = { { 20, 20, 145 }, { 20, 22, 159.5 }, { 20, 24, 174 }, { 20, 25, 174 }, { 20, 17, 105.45 }, { 20, 14, 65.91 },
              { 20, 13, 0 }, { 5, 1, 14 }, { 60, 60, 345 }, { 60, 64, 414 }, { 60, 48, 86.25 }, { 60, 47, 0 } }
IMPL.T40 = function()
    local bad = {}
    for _, e in ipairs(KXP) do
        local v = LP.Planner:KillXPFormula(e[1], e[2])
        if not Near(v, e[3], 0.01) then bad[#bad + 1] = string.format("(%d,%d)=%.2f statt %.2f", e[1], e[2], v, e[3]) end
    end
    return #bad == 0, #bad == 0 and "12 Werte" or table.concat(bad, "; "), "alle 12 Werte"
end

IMPL.T41 = function()
    local P, bad = LP.Planner, {}
    for _, e in ipairs({ { 5, 0 }, { 6, 1 }, { 10, 4 }, { 39, 31 }, { 40, 31 }, { 60, 47 } }) do
        if P:GreyLevel(e[1]) ~= e[2] then bad[#bad + 1] = e[1] .. "->" .. S(P:GreyLevel(e[1])) end
    end
    return #bad == 0, table.concat(bad, ", "), "5->0, 6->1, 10->4, 39->31, 40->31, 60->47"
end

IMPL.T42 = function()
    return WithEmptyCalib(function()
        return WithSetting({ forever = true }, function()
            return WithFlavor("forever", function()
                local P = LP.Planner
                local g3, g2 = P:GreenXPFactor(-3), P:GreenXPFactor(-2)
                local k17, k18 = P:KillXP(20, 17), P:KillXP(20, 18)
                return Near(g3, 0.85) and Near(g2, 1) and Near(k17, 89.64) and Near(k18, 118.64),
                    string.format("%.2f %.2f %.2f %.2f", g3, g2, k17, k18), "0.85 1.00 89.64 118.64"
            end)
        end)
    end)
end

IMPL.T43 = function()
    return WithEmptyCalib(function()
        return WithFlavor("forever", function()
            local P = LP.Planner
            local r = {}
            WithSetting({ dungeonMobXP = 0, forever = true }, function() r[1], r[2] = P:DungeonXPFactor() end)
            WithSetting({ dungeonMobXP = 50, forever = true }, function() r[3], r[4] = P:DungeonXPFactor() end)
            WithSetting({ dungeonQuestXP = 200, forever = true }, function() r[5], r[6] = P:DungeonQuestFactor() end)
            local ok = Near(r[1], 0.36) and r[2] == "auto" and Near(r[3], 0.5) and r[4] == "set" and Near(r[5], 2) and r[6] == "set"
            return ok, string.format("%.2f %s · %.2f %s · %.2f %s", r[1], S(r[2]), r[3], S(r[4]), r[5], S(r[6])), "0.36 auto · 0.50 set · 2.00 set"
        end)
    end)
end

IMPL.T44 = function()
    local P = LP.Planner
    local a, b = P:QuestKillLevel({ level = 18 }, 20), P:QuestKillLevel({}, 20)
    return a == 18 and b == 20, S(a) .. ", " .. S(b), "18, 20"
end

IMPL.T47 = function()
    local txt = table.concat(LP.Planner:DiagLines(), "\n")
    local ok = txt:find("Version " .. LP.version, 1, true) or txt:find(LP.version, 1, true)
    return ok and (not G() or txt:find(G().Status(), 1, true)) and true or false, "Diagnose " .. #txt .. " Zeichen", "Version und G.Status()"
end

IMPL.T50 = function()
    LP.Nav:Recalc(true)
    if not LP.Nav.target then return NA, "kein Ziel (Schritt ohne Ort)" end
    local d = LP.Nav.RemainingDistance and LP.Nav:RemainingDistance()
    if not LP.Nav.hasPath then return false, S(LP.Nav.pathError), "Weg gefunden" end
    return type(d) == "number" and d >= 0, "Weg " .. (d and LP:FormatDist(d) or "?"), "Zahl >= 0"
end

IMPL.T55 = function()
    local Geo = LP.Geo
    local i, n, w = Geo:ToWorld(1411, 0.5, 0.5)
    local cont = Geo.ContinentOf and Geo:ContinentOf(1411)
    local name = Geo:MapName(1411)
    return i ~= nil and type(name) == "string" and name ~= "" and (cont == nil or cont == 1414),
        "Kontinent " .. S(cont) .. ", Name " .. S(name), "1414, Name"
end

IMPL.T56 = function()
    local c = LP.QuestDB:Counts()
    local q = LP.QuestDB:Get(844) or LP.QuestDB:Get(7)
    local ok = type(c) == "table" and type(c.pack) == "number" and type(c.seed) == "number" and type(c.own) == "number"
    return ok and (q == nil or q.name ~= nil), string.format("Paket %s, Start %s, eigene %s", S(c.pack), S(c.seed), S(c.own)), "Zahlen"
end

IMPL.T57 = function()
    local st = LP.Names:StatusText()
    return type(st) == "string" and st ~= "", st, "nicht leer"
end

IMPL.T60 = function()
    local rate = LP.Comm.RateOk
    if not rate then return false, "Comm.RateOk fehlt", "zugänglich" end
    local who = "LPTest-" .. tostring(math.random(100000, 999999))
    local r80, r81
    for i = 1, 81 do local r = rate(who) if i == 80 then r80 = r elseif i == 81 then r81 = r end end
    return r80 == true and r81 == false, "80: " .. S(r80) .. ", 81: " .. S(r81), "80: true, 81: false"
end

IMPL.T63 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local saved = Gp.members[who:match("^([^%-]+)")]
    return Guard(function()
        Gp:OnMessage("S\t5\t10\tGOTO\t0\ttext", who)
        local m = Gp.members["LPTester"]
        local ok = m and m.level == 5 and m.pct == 10 and m.text == "text"
        return ok and true or false, ok and "Mitglied erkannt" or "nicht erkannt", "level 5, pct 10, text"
    end, function() Gp.members["LPTester"] = saved end)
end

IMPL.T65 = function()
    local M = LP.Session.Money
    local a, b, c = M(12345), M(250), M(5)
    local sum = LP.Session:SummaryText()
    return a == "1g 23s" and b == "2s 50c" and c == "5c" and type(sum) == "string", a .. " · " .. b .. " · " .. c, "1g 23s · 2s 50c · 5c"
end

IMPL.T66 = function()
    local D = LP.Comfort.Dur
    local a, b = D(59), D(nil)
    local mark = ActMark()
    -- Reparieren mit simuliertem Händler: nur mitschreiben
    WithSetting({ autoRepair = true }, function()
        WithEnv({ LP.Comfort.Repair }, { CanMerchantRepair = function() return true end,
            GetRepairAllCost = function() return 100, true end, GetMoney = function() return 100000 end }, function()
            LP.Comfort:Repair()
        end)
    end)
    local n = ActSince(mark, "RepairAllItems")
    return b == "?" and type(a) == "string" and n == 1, "Dur(59) " .. a .. ", Reparieren mitgeschrieben " .. n, "?, 1"
end

IMPL.T67 = function()
    local needs = LP.Supply:Needs()
    local mark = ActMark()
    local pend = LP.Supply.EquipRewards
    -- Nachkaufen mit simuliertem Händler: nur API.MerchantBuy im Protokoll (über LP.Act)
    WithSetting({ restock = true }, function()
        local plan = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }
        local origPlan = LP.Supply.Plan
        LP.Supply.Plan = function() return plan, 25 end
        Guard(function()
            WithEnv({ LP.Supply.Restock }, { MerchantFrame = { IsShown = function() return true end } }, function()
                LP.Supply:Restock()
            end)
        end, function() LP.Supply.Plan = origPlan end)
    end)
    local n = ActSince(mark, "MerchantBuy")
    return type(needs) == "table" and n >= 1 and pend ~= nil, #needs .. " Bedarf, Kauf mitgeschrieben " .. n, ">= 1 mitgeschrieben"
end

IMPL.T68 = function()
    LP.Advisor:Run()
    return type(LP.Advisor.hints) == "table", #LP.Advisor.hints .. " Hinweis(e)", "Liste"
end

IMPL.T73 = function()
    local t = LP.Calib:KillXPText()
    return type(t) == "string" and t ~= "", t, "Text"
end

IMPL.T75 = function()
    local Pr = LP.Protocol
    local n0 = Pr:Count()
    Pr:Add("error", "LP-Testroutine Protokoll")
    Pr:Add("error", "LP-Testroutine Protokoll")
    local n1 = Pr:Count()
    -- Eintrag wieder entfernen (Sandbox stellt am Ende ohnehin alles zurück)
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        if type(e) == "table" and type(e.msg) == "string" and e.msg:find("LP-Testroutine", 1, true) then table.remove(entries, i) end
    end
    return n1 - n0 <= 1, "neu: " .. (n1 - n0), "höchstens 1 (gleiche Meldung zusammengefasst)"
end

IMPL.T77 = function()
    local t = LP.Measure:Text()
    return type(t) == "string" and (not G() or t:find(G().Status(), 1, true) ~= nil), #t .. " Zeichen (Text nicht im Bericht)", "enthält G.Status()"
end

IMPL.T79 = function()
    local a = LP.HasBit(2 ^ 32 + 1, 2 ^ 32) == true and LP.HasBit(5, 2) == false and LP.HasBit(0, 1) == false
    local b = LP:SameZoneName("Das Brachland", "Brachland") == true and LP:SameZoneName("Durotar", "Mulgore") == false
    local c = LP:FormatDist(2000) == "1.8 km" and LP.TagHash("Ab c#1") == LP.TagHash("abc#1")
    -- LP:Fire: ein fehlerhafter Zuhörer bricht nicht ab
    local ran = false
    local key = "LP_TEST_FIRE"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire") end, function() ran = true end }
    local before = LP.errorCount
    LP:Fire(key)
    LP.callbacks[key] = nil
    LP.errorCount = before
    return a and b and c and ran, string.format("Bits %s, Zonen %s, Format %s, Fire %s", S(a), S(b), S(c), S(ran)), "alle true"
end

IMPL.T81 = function()
    local names, bad = {}, {}
    for _, t in ipairs(LP.tickers or {}) do
        names[#names + 1] = t.name
        if t.name ~= "journey" then
            -- 3.12.93 (Nachbau Laptop-Daten: ein Ticker bis 56 ms in einem Bild): als freigegebene Rechnung (echter Code, kein Ersatz)
            local ok, err = PCallY(Coop, t.fn)
            if not ok then bad[#bad + 1] = t.name .. ": " .. tostring(err) end
            TR.Safe("T81")          -- 3.12.93: nach jedem Ticker
        end
    end
    return #bad == 0 and #names > 0, #names .. " Ticker" .. (#bad > 0 and (" – " .. table.concat(bad, "; ")) or ""), "kein Fehler"
end

IMPL.T86 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket" end
    local ok = type(d.Q) == "table" and type(d.N) == "table" and next(d.Q) ~= nil
    return ok, "Quests " .. Count(d.Q), "Tabellen gefüllt"
end
SKIP.T87 = "ausserhalb des Spiels"

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (Köder, fehlende Funktionen, Kampfsperre)
------------------------------------------------------------------------
local BAIT_N1, BAIT_N2 = 987654.25, 987655.25

IMPL.T88 = function()
    local fakeC = Without(C_Container, "GetItemCooldown") or {}
    fakeC.GetItemCooldown = function() return BAIT_N1, BAIT_N2 end
    return WithSecret({ BAIT_N1, BAIT_N2 }, function()
        return WithEnv({ LP.API.ItemCooldown }, { C_Container = fakeC, GetItemCooldown = false }, function()
            local v = LP.API.ItemCooldown(LP.API.HEARTHSTONE or 6948)
            return type(v) == "number" and v >= 0, "Rückgabe " .. S(v), "Zahl >= 0 (letzter lesbarer Wert oder 0)"
        end)
    end)
end

IMPL.T91 = function()
    local item = 999001
    local s = LP.Acc().calib or {}
    LP.Acc().calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local savedDrop = s.drops[item]
    s.drops[item] = { k = 1, g = 0 }
    local msg = "Ihr bekommt Beute: |cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
    local savedW = LP.Calib.testWanted
    LP.Calib.testWanted = { [item] = { npc = { [1] = true } } }
    return Guard(function()
        WithSecret({ msg }, function() LP.Calib:OnLoot(msg) end)
        return s.drops[item].g == 0, "Stück " .. S(s.drops[item].g), "0 (Köder nicht verarbeitet)"
    end, function() s.drops[item] = savedDrop LP.Calib.testWanted = savedW end)
end
IMPL.T188 = IMPL.T91

IMPL.T97 = function()
    local bait = "LPTestKoeder Name"
    return WithSecret({ bait }, function()
        local a = LP.SameName(bait, "x")
        local b = G().Short(bait)
        return a == false and b == nil, "SameName " .. S(a) .. ", Short " .. S(b), "false, nil"
    end)
end

IMPL.T101 = function()
    local fakeQ = Without(C_QuestLog, "GetTrivialRange") or false
    return WithEnv({ LP.API.GreenRange }, { C_QuestLog = fakeQ, GetQuestGreenRange = false, UnitQuestTrivialLevelRange = false }, function()
        local R = LP.API.GreenRange
        local a, b, c, d = R(5), R(20), R(45), R(60)
        return a == 5 and b == 7 and c == 10 and d == 13, a .. "," .. b .. "," .. c .. "," .. d, "5,7,10,13"
    end)
end
IMPL.T194 = IMPL.T101

IMPL.T102 = function()
    local API = LP.API
    return WithEnv({ API.MerchantCount, API.MerchantAvailable, API.MerchantLink, API.MerchantBuy, API.MerchantItem },
        { GetMerchantNumItems = false, C_MerchantFrame = false, GetMerchantItemLink = false, BuyMerchantItem = false,
          GetMerchantItemInfo = false }, function()
        local ok = API.MerchantCount() == 0 and API.MerchantAvailable() == false and API.MerchantLink(1) == nil
            and API.MerchantBuy(1, 1) == false and API.MerchantItem(1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/false/nil/false/nil"
    end)
end

IMPL.T103 = function()
    local API = LP.API
    return WithEnv({ API.ItemInfo, API.IsEquippable, API.SellPrice, API.ItemSpell },
        { C_Item = false, GetItemInfo = false, IsEquippableItem = false, GetItemSpell = false }, function()
        local ok = API.ItemInfo(6948) == nil and API.IsEquippable(6948) == false and API.SellPrice(6948) == 0 and API.ItemSpell(6948) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "nil/false/0/nil"
    end)
end

IMPL.T104 = function()
    local API = LP.API
    return WithEnv({ API.BagSlots, API.BagFree, API.BagLink, API.BagItem, API.UseBagItem },
        { C_Container = false, GetContainerNumSlots = false, GetContainerNumFreeSlots = false, GetContainerItemLink = false,
          GetContainerItemInfo = false, UseContainerItem = false }, function()
        local f1, f2 = API.BagFree(0)
        local ok = API.BagSlots(0) == 0 and f1 == 0 and f2 == 0 and API.BagLink(0, 1) == nil and API.BagItem(0, 1) == nil
            and API.UseBagItem(0, 1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/0,0/nil/nil/nil"
    end)
end

IMPL.T106 = function()
    local known = LP.Hints.Known
    if not known then return false, "Hints.Known fehlt", "zugänglich" end
    return WithEnv({ known }, { C_SpellBook = false, IsSpellKnown = false, IsPlayerSpell = false }, function()
        local r = known(3273)
        return r == nil, "Rückgabe " .. S(r), "nil (unbekannt – kein Hinweis)"
    end)
end
IMPL.T191 = IMPL.T106

IMPL.T107 = function()
    local mark = ActMark()
    local So = LP.Social
    local origText = So.GroupText
    So.GroupText = function() return "LFG Test" end
    return Guard(function()
        local line = WithEnv({ So.OpenGroupChat }, { ChatFrame_OpenChat = false }, function() return So:OpenGroupChat({}) end)
        local n = ActSince(mark, "OpenChat")
        local hasUtil = ChatFrameUtil and ChatFrameUtil.OpenChat
        return line ~= nil and (n == 1 or not hasUtil), "Zeile " .. S(line ~= nil) .. ", mitgeschrieben " .. n, "Zeile, OpenChat mitgeschrieben"
    end, function() So.GroupText = origText end)
end
IMPL.T192 = IMPL.T107

IMPL.T115 = function()
    local mark = ActMark()
    WithSetting({ autoEquipRewards = true }, function()
        WithEnv({ LP.Supply.EquipRewards }, { InCombatLockdown = function() return true end }, function() LP.Supply:EquipRewards() end)
    end)
    local n = ActSince(mark, "Equip")
    return n == 0, "mitgeschrieben " .. n, "0"
end

IMPL.T116 = function()
    local r = WithCombat(true, function() return TR:CanStart(true) end)
    return r == false, "Start erlaubt: " .. S(r), "false"
end

IMPL.T117 = function()
    local Pr = LP.Protocol
    local list = LP.handlers.ADDON_ACTION_BLOCKED
    if not list then return false, "kein Handler", "Handler angemeldet" end
    local n0 = Pr:Count()
    for _, fn in ipairs(list) do pcall(fn, "ADDON_ACTION_BLOCKED", "LevelPilot", "LPTestAktion") end
    local n1 = Pr:Count()
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        local txt = type(e) == "table" and (tostring(e.msg or "") .. tostring(e.a1 or "") .. tostring(e.args and e.args[1] or ""))
        if txt and txt:find("LPTestAktion", 1, true) then table.remove(entries, i) end
    end
    return n1 > n0, "neu: " .. (n1 - n0), "Eintrag 'blocked'"
end

IMPL.T118 = function()
    local g = G()
    local reg = LP.eventFrame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") and true or false
    if g and g.IsModern then
        return LP.handlers.COMBAT_LOG_EVENT_UNFILTERED == nil and not reg, "angemeldet " .. S(reg), "nicht angemeldet (Forever)"
    end
    return reg, "angemeldet " .. S(reg), "angemeldet (alter Client)"
end
CLIENT.T99 = "/lp testroutine kampf, dann allein einen Gegner töten – Fehlerzähler vorher/nachher gleich"

------------------------------------------------------------------------
-- D. Alte Clients
------------------------------------------------------------------------
CLIENT.T119 = "Classic Era mit 'Veraltete AddOns laden' starten, dann /lp testroutine – keine Lua-Fehler beim Laden, T01 OK"
IMPL.T120 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    return true, g.Status() .. (g.IsForever and "" or " – LevelPilot ist für WoW Forever gebaut, alter Client nur Ladeprüfung")
end
IMPL.T121 = function()
    local g = G()
    local want = g and (g.IsModern and true or false) or (C_QuestLog and C_QuestLog.GetInfo ~= nil)
    return LP.API.modern == want, "API.modern " .. S(LP.API.modern), S(want) .. " (laut GoldSentinelGame)"
end
SKIP.T122 = ONLY_FOREVER

------------------------------------------------------------------------
-- E. Daten (Testtabellen über LP:LoadSaved, danach wieder die echten Tabellen)
------------------------------------------------------------------------
local function WithLoad(acc, char, body)
    return Guard(function() LP:LoadSaved(acc, char) return body(acc, char) end,
        function() LP:LoadSaved(LP.Acc(), LevelPilotCharDB) end)   -- 3.12.56: Bereich der Spielversion
end

IMPL.T123 = function()
    return WithLoad({}, {}, function(acc, char)
        local miss = {}
        for k in pairs(LP.DEFAULTS) do if acc[k] == nil and LP.DEFAULTS[k] ~= nil then miss[#miss + 1] = k end end
        for k in pairs(LP.CHAR_DEFAULTS) do if char[k] == nil then miss[#miss + 1] = "char." .. k end end
        local ok = #miss == 0 and acc.speedLevelV2 == true and acc.language == "auto"
        return ok, #miss == 0 and "alle Standardwerte" or ("fehlend: " .. table.concat(miss, ",")), "alle Standardwerte"
    end)
end
IMPL.T206 = function()
    return WithLoad({}, {}, function(acc)
        local ok = acc.autoRepair == true and acc.autoFly == true and acc.restock == false and acc.autoEquipRewards == false
        return ok, string.format("autoRepair %s, autoFly %s, restock %s, autoEquipRewards %s", S(acc.autoRepair), S(acc.autoFly),
            S(acc.restock), S(acc.autoEquipRewards)), "true, true, false, false"
    end)
end
IMPL.T207 = function()
    return WithLoad({ autoRepair = false, autoFly = false, restock = true }, {}, function(acc)
        local ok = acc.autoRepair == false and acc.autoFly == false and acc.restock == true
        return ok, string.format("autoRepair %s, autoFly %s, restock %s", S(acc.autoRepair), S(acc.autoFly), S(acc.restock)), "false, false, true"
    end)
end
IMPL.T204 = function()
    local D = LP.DEFAULTS
    local ok = D.autoRepair == true and D.autoFly == true and D.restock == false and D.autoEquipRewards == false
    return ok, string.format("restock %s, autoEquipRewards %s, autoRepair %s, autoFly %s", S(D.restock), S(D.autoEquipRewards),
        S(D.autoRepair), S(D.autoFly)), "false, false, true, true (Entscheid des Nutzers 3.12.5)"
end

IMPL.T124 = function()
    local a, b
    WithLoad({ speedLevel = 3 }, {}, function(acc) a = acc.speedLevel end)
    WithLoad({ speedLevel = 3, speedLevelV2 = true }, {}, function(acc) b = acc.speedLevel end)
    return a == 2 and b == 3, S(a) .. ", " .. S(b), "2, 3"
end
IMPL.T125 = function()
    local a
    WithLoad({ language = "xx" }, {}, function(acc) a = acc.language end)
    return a == "auto", S(a), "auto"
end
IMPL.T126 = function()
    local M = LP.Protocol.Migrate
    if not M then return false, "Protocol.Migrate fehlt", "vorhanden" end
    local r = M({ k = "zone", msg = "… Das Brachland (1413), Brachland" })
    return r == "drop", S(r), "drop"
end
IMPL.T132 = function()
    local acc = { autoAccept = true }
    return WithLoad(acc, {}, function()
        LP.db.ownSettings = true
        LP.db.autoAccept = false
        local a = acc.autoAccept == true and LP.db.autoAccept == false
        LP.db.ownSettings = false
        local b = LP.db.autoAccept == true
        return a and b, "Charakter " .. S(a) .. ", Konto wieder " .. S(b), "true, true"
    end)
end
IMPL.T199 = function()
    local Pr = LP.Protocol
    local s = LevelPilotDB.protocolLog
    if type(s) ~= "table" then return true, "kein Protokoll" end
    local entries = s.entries
    entries[#entries + 1] = { k = nil, msg = 5 }
    return Guard(function() Pr:LoadEntries() return true, "Laden ohne Fehler" end,
        function() for i = #entries, 1, -1 do if entries[i] and entries[i].msg == 5 then table.remove(entries, i) end end end)
end
IMPL.T203 = function()
    local Q = LP.QuestDB
    return Q.OlderThan("1.5.0", Q.MIN_PACK) == true and Q.OlderThan("1.6.0", Q.MIN_PACK) == false,
        "Mindestversion " .. S(Q.MIN_PACK), "1.5.0 zu alt, 1.6.0 ok"
end
IMPL.T170 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket" end
    return LP.QuestDB.OlderThan(d.version, "1.6.0") == false, S(d.version), ">= 1.6.0"
end

------------------------------------------------------------------------
-- F. Sprachen
------------------------------------------------------------------------
local CODES = { "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }
local function Placeholders(s)
    local out = {}
    for p in tostring(s):gsub("%%%%", ""):gmatch("%%[%-%+ #0]*%d*%.?%d*[sdif]") do out[#out + 1] = p:sub(-1) end
    return table.concat(out)
end

IMPL.T133 = function()
    local res, bad = {}, 0
    for _, code in ipairs(CODES) do
        local t = LP.Locales[code]
        local fb = LP.LanguageInfo[code] and LP.LanguageInfo[code].fallback
        local miss, ex = 0, nil
        for k in pairs(LP.usedKeys or {}) do
            if k ~= "" and not k:find("^%s*$") and not ((t and t[k]) or (fb and LP.Locales[fb] and LP.Locales[fb][k])) then
                miss = miss + 1 ex = ex or k
            end
        end
        if miss > 0 then bad = bad + 1 res[#res + 1] = code .. " " .. miss .. " (" .. tostring(ex):sub(1, 30) .. ")" end
    end
    return bad == 0, bad == 0 and (Count(LP.usedKeys) .. " benutzte Schlüssel in allen Sprachen") or table.concat(res, "; "), "0 fehlend"
end

IMPL.T134 = function()
    local res = {}
    for _, code in ipairs(CODES) do
        TR.Safe("T134")             -- 3.12.93: je Sprache (Sprachtabellen ändern sich nicht)
        for k, v in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and type(v) == "string" and Placeholders(k) ~= Placeholders(v) then
                res[#res + 1] = code .. ": " .. k:sub(1, 30)
            end
        end
    end
    return #res == 0, #res == 0 and "keine Abweichung" or (#res .. ": " .. table.concat(res, "; "):sub(1, 200)), "0 Abweichungen"
end

IMPL.T135 = function()
    local bad = {}
    local VAL = { s = "x", d = 3, i = 3, f = 1.5 }
    for _, code in ipairs(CODES) do
        TR.Safe("T135")             -- 3.12.93: je Sprache
        for k in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and k:find("%", 1, true) then
                local args = {}
                for c in Placeholders(k):gmatch(".") do args[#args + 1] = VAL[c] end
                -- nur echte Formattexte (der deutsche Schlüssel selbst lässt sich formatieren)
                if pcall(string.format, k, unpack(args)) then
                    local ok = pcall(string.format, LP.LocaleLookup(code, k), unpack(args))
                    if not ok then bad[#bad + 1] = code .. ": " .. k:sub(1, 30) end
                end
            end
        end
    end
    return #bad == 0, #bad == 0 and "alle formatierbar" or table.concat(bad, "; "):sub(1, 200), "kein Formatfehler"
end

IMPL.T137 = function()
    local bad = {}
    for _, l in ipairs(LP.LANGUAGES) do
        if not LP:CanDisplay(l.code) then
            local before = LP.db.language
            local r = LP:SetLanguage(l.code)
            LP.db.language = before
            LP:ResetLanguageCache()
            if r ~= false then bad[#bad + 1] = l.code end
        end
    end
    return #bad == 0, #bad == 0 and "ok" or table.concat(bad, ","), "SetLanguage gibt false zurück"
end

IMPL.T139 = function()
    local g = G()
    if not g or not g.Text then return true, "keine Texte" end
    local t = g.Text("game")
    return type(t) == "string" and t ~= "", S(t), "Text"
end

------------------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------------------
IMPL.T140 = function()
    local loaded = {}
    local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    for _, a in ipairs({ "GuildSentinel", "RaidMaster", "ThreatSentinel", "BuffSentinel", "ProfessionSentinel", "AHSentinel" }) do
        if f and f(a) then loaded[#loaded + 1] = a end
    end
    local GT, g = _G.GoldSentinelTest, _G.GoldSentinelGame
    local ok = g and g.version >= 2 and GT and GT.version >= 1 and LP.Game == g and GT.registry.LevelPilot ~= nil
    return ok and true or false, "geladen: " .. (#loaded > 0 and table.concat(loaded, ", ") or "keine"), "gemeinsame Dateien ok"
end
IMPL.T141 = function()
    local ok = _G.LevelPilot == LP and SLASH_LEVELPILOT1 == "/lp" and type(SlashCmdList.LEVELPILOT) == "function"
    return ok, ok and "ok" or "überschrieben", "eigene Namen"
end
SKIP.T143 = "keine Schnittstelle – LevelPilot nutzt keine anderen GoldSentinel-Addons"
IMPL.T145 = function()
    local f = C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered
    if not f then return true, "keine Abfrage möglich" end
    local a, b = f("LvPilot2"), f("LvPilotG")
    return a and b and true or false, S(a) .. ", " .. S(b), "true, true"
end

------------------------------------------------------------------------
-- H. Leistung (je 20 Aufrufe, Median und Höchstwert)
------------------------------------------------------------------------
local function Bench(fn, n)
    local t = {}
    -- 3.12.93: zwischen zwei Messungen eine sichere Stelle (nicht gemessen); unter WithEnv & Co. wirkungslos
    for i = 1, n or 20 do local a = Ms() fn() t[i] = Ms() - a TR.Safe("Messung") end
    table.sort(t)
    return t[math.floor(#t / 2) + 1], t[#t]
end
local function BenchCheck(fn, limit, n)
    return function()
        local med, max = Bench(fn, n)
        return med < limit, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max), string.format("Median < %g ms", limit)
    end
end
IMPL.T146 = BenchCheck(function() LP.UI:Refresh() end, 2)
IMPL.T147 = BenchCheck(function() LP.Engine:CheckSteps() end, 2)
-- 3.12.32 PF-A: Median < 16 ms (kein Bild > 16 ms) und Höchstwert < 33 ms (höchstens zwei Bilder)
-- 3.12.34: vorher einmal planen (Zwischenspeicher warm); der kalte Fall läuft in Portionen und hat eigenen Test T295
IMPL.T150 = function()
    PCallY(Coop, LP.Planner.DoReplan, LP.Planner)      -- 3.12.93: Aufwärmen als freigegebene Rechnung (nicht gemessen)
    local med, max = Bench(function() LP.Planner:Replan(true) end, 5)
    -- 3.13.3 (Ingametest 3.13.2: "Ursache je Version belegen"; im Nachbau mit gleichen Eingaben 3.12.99 11,7 ms -> 3.13.2 5,2–6,2 ms,
    -- im Spiel 18,8 -> 20,7 ms): Aufteilung im Spiel. Drei weitere Neuplanungen, je mit Zeitmessern um die Teile (Ersatz nur für die
    -- Dauer einer Neuplanung, dazwischen eine sichere Stelle). Teile: Planung (DoReplan) mit Aufgaben sammeln (CollectTasks) und
    -- Reihenfolge (Order), darin Gefahr auf der Strecke (Danger:Route mit Treffern des Zwischenspeichers); Rest = Meldung an Anzeige,
    -- Navigation und Karte (PLAN_CHANGED).
    -- 3.13.4 (Ingametest 3.13.3: Aufteilung ging nicht auf – Navigation lief INNERHALB der Planung, ein Rest blieb ohne Namen):
    -- jetzt jeder direkte Teil von P:DoReplan einzeln, dazu "Meldung" (PLAN_CHANGED an Anzeige/Navigation/Karte, darin Navigation)
    -- und "Rest" = Planung minus Summe der Teile (eigene Zeilen in DoReplan: Questlog lesen, Auswahl, Sortieren). Summe = Planung.
    local P, D, N, UI, Q = LP.Planner, LP.Danger, LP.Nav, LP.UI, LP.QuestDB
    local acc, runs = {}, 0
    local rs0h, rs0m = D.routeStats and D.routeStats.hits or 0, D.routeStats and D.routeStats.miss or 0
    -- { Tabelle, Name, Schlüssel, direkter Teil von DoReplan? }
    local parts = {
        { P, "DoReplan", "planung" },
        { P, "BuildCandidates", "kandidaten", true }, { P, "ZoneBands", "zonenbaender", true }, { Q, "ServiceNPCs", "dienste", true },
        { P, "CollectTasks", "aufgaben", true }, { P, "StartFilter", "startregel", true }, { P, "ChooseFocus", "fokus", true },
        { P, "LogCount", "questlog", true }, { P, "Order", "reihenfolge", true }, { P, "CheckFirstPath", "ersterweg", true },
        { P, "FlightPointTask", "flugpunkt", true }, { P, "BindStep", "binden", true }, { P, "HearthStep", "ruhestein", true },
        { P, "TravelSteps", "reise", true }, { P, "InsertOnWay", "amweg", true }, { P, "InsertByDistance", "nachentfernung", true },
        { P, "NearTurninsFirst", "naheabgaben", true }, { P, "NearAcceptsFirst", "naheannahmen", true },
        { P, "OnWayAccepts", "annahmenamweg", true }, { P, "InsertPriority", "vorrang", true }, { P, "LogBundleIndex", "buendelindex", true },
        { P, "BundleNear", "buendel", true }, { P, "LaterTurnins", "spaeterabgeben", true },
        { D, "Route", "gefahr" }, { N, "Recalc", "navi" }, { UI, "Refresh", "anzeige" },
    }
    local total, depth = 0, 0
    local Fire0 = LP.Fire
    for _ = 1, 3 do
        local saved = {}
        Guard(function()
            for i, e in ipairs(parts) do
                local tbl, name, key = e[1], e[2], e[3]
                local o = tbl and rawget(tbl, name)
                if type(o) == "function" then
                    saved[i] = o
                    local direct = e[4]
                    tbl[name] = function(...)
                        -- direkte Teile nur zählen, wenn sie nicht in einem anderen direkten Teil laufen (sonst doppelt)
                        if direct then depth = depth + 1 end
                        local a = Ms()
                        local r1, r2, r3, r4 = o(...)
                        local k = (direct and depth > 1) and (key .. "_darin") or key
                        acc[k] = (acc[k] or 0) + (Ms() - a)
                        if direct then depth = depth - 1 end
                        return r1, r2, r3, r4
                    end
                end
            end
            LP.Fire = function(self, ev, ...)
                if ev ~= "PLAN_CHANGED" then return Fire0(self, ev, ...) end
                local a = Ms()
                Fire0(self, ev, ...)
                acc.meldung = (acc.meldung or 0) + (Ms() - a)
            end
            local a = Ms()
            P:Replan(true)
            total = total + (Ms() - a)
            runs = runs + 1
        end, function()
            LP.Fire = Fire0
            for i, e in ipairs(parts) do if saved[i] then e[1][e[2]] = saved[i] end end
        end)
        TR.Safe("T150")
    end
    local function avg(k) return (acc[k] or 0) / math.max(1, runs) end
    local hits = (D.routeStats and D.routeStats.hits or 0) - rs0h
    local miss = (D.routeStats and D.routeStats.miss or 0) - rs0m
    local list, sum = {}, 0
    for _, e in ipairs(parts) do
        if e[4] and (acc[e[3]] or 0) > 0 then list[#list + 1] = { e[3], avg(e[3]) } sum = sum + avg(e[3]) end
    end
    list[#list + 1] = { "meldung", avg("meldung") }
    sum = sum + avg("meldung")
    local rest = avg("planung") - sum
    list[#list + 1] = { "rest", rest }
    table.sort(list, function(x, y) return x[2] > y[2] end)
    local txt, small = {}, 0
    for _, e in ipairs(list) do
        if e[2] >= 0.05 or e[1] == "rest" then txt[#txt + 1] = ("%s %.2f"):format(e[1], e[2]) else small = small + e[2] end
    end
    if small > 0 then txt[#txt + 1] = ("kleine Teile %.2f"):format(small) end
    local split = string.format(" · Aufteilung (Ø von %d, ms): gesamt %.2f = Planung %.2f + Aufruf %.2f · Planung = %s · darin: Gefahr %.2f "
        .. "[Zwischenspeicher %d/%d], Navigation %.2f, Anzeige %.2f · Kandidaten %s, Aufgaben im Plan %s", runs, total / math.max(1, runs),
        avg("planung"), total / math.max(1, runs) - avg("planung"), table.concat(txt, " + "), avg("gefahr"), hits, hits + miss, avg("navi"),
        avg("anzeige"), tostring(P.diag and P.diag.candidates), tostring(P.steps and #P.steps))
    return med < 16 and max < 33, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max) .. split, "Median < 16 ms, Höchstwert < 33 ms"
end
IMPL.T157 = function()
    TR.FullGC("T157")
    local kb = collectgarbage("count")
    local grow = TR.memStart and (kb - TR.memStart) or 0
    local usage
    -- 3.12.95: kein UpdateAddOnMemoryUsage mehr (misst den Speicher ALLER Addons am Stück, nicht teilbar; dieselbe C-Funktion
    -- machte im Ingametest 3.12.94 "/lp protokoll" zu einem Bild von 93 ms). Gezeigt wird der Wert der letzten Messung.
    local get = (C_AddOns and C_AddOns.GetAddOnMemoryUsage) or GetAddOnMemoryUsage
    if get then
        local ok, kb2 = pcall(get, "LevelPilot")
        usage = ok and tonumber(kb2) or nil
    end
    return grow < 1024, string.format("Zuwachs %.0f KB (ab dem Start der Prüfungen)%s", grow,
        (usage and usage > 0) and string.format(", LevelPilot %.0f KB (Stand der letzten Messung)", usage) or ""), "< 1024 KB"
end

------------------------------------------------------------------------
-- I. Fehlerzählung
------------------------------------------------------------------------
-- 3.12.19: absichtliche Testfehler danach wieder vergessen (Zähler, letzte Meldung, Fehlerliste von
-- GoldSentinelTest), damit der Fehlerzähler im Bericht nur echte Fehler zeigt
local function ForgetTestErrors(n0, last0)
    LP.errorCount, LP.lastError = n0, last0
    for k in pairs(LP.errors) do if type(k) == "string" and k:find("LP-Testfehler", 1, true) then LP.errors[k] = nil end end
    local st = LevelPilotDB and LevelPilotDB.gsTest
    if st and type(st.errors) == "table" then
        for k, e in pairs(st.errors) do
            if type(e) == "table" and (tostring(e.msg):find("LP-Testfehler", 1, true) or e.wo == "Testroutine" or e.wo == "ticker-test") then
                st.errors[k] = nil
            end
        end
    end
end
TR.ForgetTestErrors = ForgetTestErrors

IMPL.T158 = function()
    local n0, last0 = LP.errorCount, LP.lastError
    local msg = "LP-Testfehler Safe " .. tostring(math.random(1000, 9999))
    local r = LP:Safe("Testroutine", function() error(msg, 0) end)
    local inErr = LP.errors[msg] == true
    local gt = false
    local s = LevelPilotDB.gsTest
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do if type(e) == "table" and e.wo == "Testroutine" then gt = true s.errors[k] = nil end end
    end
    local ok = r == false and LP.errorCount == n0 + 1 and inErr and (gt or not LP.trackingErrors)
    local plus = LP.errorCount - n0
    ForgetTestErrors(n0, last0)
    return ok, string.format("Rückgabe %s, Zähler +%d, GoldSentinelTest %s", S(r), plus, S(gt)), "false, +1, true"
end
IMPL.T160 = function()
    local list = LP.handlers.PLAYER_XP_UPDATE
    if not list then return true, "kein Handler" end
    local n0, ran, last0 = LP.errorCount, false, LP.lastError
    table.insert(list, 1, function() error("LP-Testfehler Ereignis", 0) end)
    table.insert(list, function() ran = true end)
    return Guard(function()
        LP.eventFrame:GetScript("OnEvent")(LP.eventFrame, "PLAYER_XP_UPDATE", "player")
        return LP.errorCount == n0 + 1 and ran, "Zähler +" .. (LP.errorCount - n0) .. ", übrige liefen " .. S(ran), "+1, true"
    end, function()
        table.remove(list, 1) table.remove(list)
        ForgetTestErrors(n0, last0)
    end)
end
IMPL.T161 = function()
    local n0, ran, last0 = LP.errorCount, false, LP.lastError
    local key = "LP_TEST_FIRE2"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire", 0) end, function() ran = true end }
    LP:Fire(key)
    LP.callbacks[key] = nil
    local plus = LP.errorCount - n0
    ForgetTestErrors(n0, last0)
    return plus == 1 and ran, "Zähler +" .. plus .. ", nächster lief " .. S(ran), "+1, true"
end
IMPL.T163 = function()
    local n0, last0 = LP.errorCount, LP.lastError
    local msg = "LP-Testfehler Ticker"
    LP:Safe("ticker-test", function() error(msg, 0) end)
    LP:Safe("ticker-test", function() error(msg, 0) end)
    local plus = LP.errorCount - n0
    ForgetTestErrors(n0, last0)
    return plus == 2, "Zähler +" .. plus, "+2 (Chatmeldung nur einmal)"
end
IMPL.T198 = function()
    local n = 0
    for _, t in ipairs(LP.tickers or {}) do if t.name ~= "journey" then n = n + 1 end end
    return n == 15, n .. " Ticker über LP:Ticker", "15 (ohne Reise; 3.12.26 dazu Grundregeln; 3.12.48 dazu Laufweg-Messung)"
end
SKIP.T205 = "vor dem Push mit addon-check"

------------------------------------------------------------------------
-- J. Regressionstests (wiederverwendete Prüfungen unter eigener ID)
------------------------------------------------------------------------
IMPL.T167 = IMPL.T06
IMPL.T168 = IMPL.T47
IMPL.T172 = IMPL.T40
IMPL.T173 = function()
    local P = LP.Planner
    return P.FOREVER_GREEN == 0.85 and P.GREEN_DIFF == 3, S(P.FOREVER_GREEN) .. " / " .. S(P.GREEN_DIFF), "0.85 / 3"
end
IMPL.T175 = IMPL.T44
IMPL.T176 = function()
    local P = LP.Planner
    return P.FOREVER_DG_MOB == 0.36 and P.FOREVER_DG_QUEST == 1.5, S(P.FOREVER_DG_MOB) .. " / " .. S(P.FOREVER_DG_QUEST), "0.36 / 1.5"
end
IMPL.T178 = function()
    return WithSetting({ forever = true }, function()
        return WithFlavor("forever", function()
            local t = LP.Social.ForeverGroupNote("x")
            local want = L["Ein viel höheres Gruppenmitglied kann dafür sorgen, dass alle 0 EP bekommen."]
            return t:sub(-#want) == want, "Hinweis " .. S(t ~= "x"), "endet mit dem Gruppen-EP-Hinweis"
        end)
    end)
end
IMPL.T182 = function()
    local f = LP.Comfort.XPNeed
    if not f then return false, "Comfort.XPNeed fehlt", "zugänglich" end
    local sum, n = 0, 0
    for l = 1, 59 do local v = f(l) if v then sum, n = sum + v, n + 1 end end
    return sum == 4084700 and n == 59, sum .. " in " .. n .. " Einträgen", "4084700 in 59"
end
IMPL.T185 = IMPL.T88
IMPL.T202 = function()
    local g = G()
    if not g then return true, "ohne GoldSentinelGame: Einstellung" end
    return WithSetting({ forever = true }, function()
        local a = WithFlavor("forever", function() return LP.API.Forever() end)
        local b = WithFlavor("era", function() return LP.API.Forever() end)
        return a == true and b == false, "forever " .. S(a) .. ", era " .. S(b), "true, false"
    end)
end

------------------------------------------------------------------------
-- J. 3.12.5: einmalige Hinweise auf Nachkaufen und Belohnung anlegen
------------------------------------------------------------------------
local PLAN = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }

-- Hinweis-Zustand des Charakters vorübergehend leeren
local function WithOptState(body)
    local Su = LP.Supply
    local savedHints, savedPending = LP.char.optHints, Su.optPending
    LP.char.optHints, Su.optPending = {}, {}
    return Guard(body, function() LP.char.optHints, Su.optPending = savedHints, savedPending end)
end
-- Hinweise des Anbieters abfragen (ohne den Assistenten laufen zu lassen)
local function OptHintsShown()
    local list = {}
    LP.Supply.OptHintsProvider(function(key, sev, text, action, label, action2)
        list[#list + 1] = { key = key, action = action, action2 = action2 }
    end)
    return list
end

IMPL.T208 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            local mark = ActMark()
            local first = LP.Supply:CheckRestockHint(PLAN)
            local shown1 = #OptHintsShown()
            LP.Supply.optPending = {}                 -- Händler geschlossen, Sitzung geht weiter
            local second = LP.Supply:CheckRestockHint(PLAN)
            local bought = ActSince(mark, "MerchantBuy")
            return first == true and shown1 == 1 and second == false and bought == 0,
                string.format("erster Besuch %s (%d Hinweis), zweiter %s, gekauft %d", S(first), shown1, S(second), bought),
                "true (1), false, 0"
        end)
    end)
end

IMPL.T209 = function()
    local link = "|cff1eff00|Hitem:999002::::::::|h[Test]|h|r"
    local A = LP.Advisor
    local orig = A.UpgradeValue
    A.UpgradeValue = function(_, l) if l == link then return 10 end return orig(A, l) end
    return Guard(function()
        return WithOptState(function()
            return WithSetting({ autoEquipRewards = false }, function()
                local mark = ActMark()
                local first = LP.Supply:CheckRewardHint({ link })
                local shown = #OptHintsShown()
                LP.Supply.optPending = {}
                local second = LP.Supply:CheckRewardHint({ link })
                local acted = ActSince(mark, "Equip") + ActSince(mark, "GetQuestReward")
                return first == true and shown == 1 and second == false and acted == 0,
                    string.format("erste %s (%d Hinweis), zweite %s, gewählt/angelegt %d", S(first), shown, S(second), acted),
                    "true (1), false, 0"
            end)
        end)
    end, function() A.UpgradeValue = orig end)
end

IMPL.T210 = function()
    return WithOptState(function()
        return WithSetting({ restock = true, autoEquipRewards = true }, function()
            local a = LP.Supply:CheckRestockHint(PLAN)
            LP.Supply.optPending.restock = { text = "x" }          -- schon vorgemerkt, dann eingeschaltet
            local shown = #OptHintsShown()
            return a == false and shown == 0, "Hinweis " .. S(a) .. ", gezeigt " .. shown, "false, 0"
        end)
    end)
end

IMPL.T211 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            LP.Supply:CheckRestockHint(PLAN)
            local inCombat = WithCombat(true, function() return #OptHintsShown() end)
            local later = WithCombat(false, function() return #OptHintsShown() end)
            return inCombat == 0 and later == 1, "im Kampf " .. inCombat .. ", danach " .. later, "0, 1"
        end)
    end)
end

-- 3.12.5 offen-Punkt 1: dieselbe Leiche zweimal öffnen zählt Kill und Stück nur einmal
IMPL.T212 = function()
    local Ca = LP.Calib
    if not Ca.ResetLooted then return false, "Calib.ResetLooted fehlt", "zugänglich" end
    local item, npc = 999003, 99901
    local guid = "Creature-0-1-1-1-" .. npc .. "-0000ABCDEF"
    local s = LP.Acc().calib or {}
    LP.Acc().calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local saved, savedW = s.drops[item], Ca.testWanted
    s.drops[item] = nil
    Ca.testWanted = { [item] = { npc = { [npc] = true } } }
    local fake = {
        GetNumLootItems = function() return 1 end,
        GetLootSlotLink = function() return "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r" end,
        GetLootSourceInfo = function() return guid, 2 end,
        UnitExists = function() return false end,
    }
    return Guard(function()
        -- 3.12.6: Stück zählen erst bei der Beutemeldung (was liegen bleibt, zählt nicht)
        local link = "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
        local selfMsg = (LOOT_ITEM_SELF_MULTIPLE and LOOT_ITEM_SELF_MULTIPLE:gsub("%%%d?%$?s", link, 1):gsub("%%%d?%$?d", "2", 1))
            or ("Ihr bekommt Beute: " .. link .. "x2.")
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, fake, function()
            Ca:OnLootOpened()
            Ca:OnLoot(selfMsg)
            Ca:OnLootClosed()
            Ca:OnLootOpened()          -- erneut geöffnet: dieselbe Leiche, keine neue Beutemeldung
            Ca:OnLootClosed()
        end)
        local d = s.drops[item] or { k = 0, g = 0 }
        return d.k == 1 and d.g == 2, "Kills " .. d.k .. ", Stück " .. d.g, "Kills 1, Stück 2"
    end, function() s.drops[item] = saved Ca.testWanted = savedW Ca.ResetLooted(guid) end)
end

------------------------------------------------------------------------
-- 3.12.6: weitere Hilfen
------------------------------------------------------------------------
-- Funktion vorübergehend durch einen Zähler ersetzen (Addon-Tabelle, nie _G). pass = true: Original danach aufrufen
local function WithCounter(tbl, key, body, pass)
    local orig = tbl[key]
    local n = 0
    tbl[key] = function(...)
        n = n + 1
        if pass and orig then return orig(...) end
    end
    return Guard(function() return body(function() return n end) end, function() tbl[key] = orig end)
end

-- Text in einem Fenster suchen (FontStrings in allen Unterfenstern)
local function FindText(frame, text, depth)
    if not frame or (depth or 0) > 12 then return false end
    if frame.GetRegions then
        for _, r in ipairs({ frame:GetRegions() }) do
            local t = r and r.GetText and r:GetText()
            if type(t) == "string" and t:find(text, 1, true) then return true end
        end
    end
    if frame.GetChildren then
        for _, c in ipairs({ frame:GetChildren() }) do
            if FindText(c, text, (depth or 0) + 1) then return true end
        end
    end
    return false
end

-- Einträge in der Fehlerliste von GoldSentinelTest (dieses Addon) zählen/entfernen
local function GTErrors(where, remove)
    local s = LevelPilotDB.gsTest
    local n = 0
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do
            if type(e) == "table" and (where == nil or e.wo == where or tostring(e.msg):find(where, 1, true)) then
                n = n + 1
                if remove then s.errors[k] = nil end
            end
        end
    end
    return n
end

-- Protokoll-Einträge mit einem Text entfernen
local function DropProtocol(text)
    local entries = LP.Protocol:Entries()
    local n = 0
    for i = #entries, 1, -1 do
        local e = entries[i]
        if type(e) == "table" and tostring(e.msg or ""):find(text, 1, true) then table.remove(entries, i) n = n + 1 end
    end
    return n
end

local function HandlerList(ev) return LP.handlers[ev] or {} end
local function CallHandlers(ev, ...)
    for _, fn in ipairs(HandlerList(ev)) do fn(ev, ...) end
end

-- Kill mit EP-Meldung simulieren (Calib): Ziellevel tl, EP-Gewinn gain. Rückgabe calib.killxp
local function SimKill(tl, gain, fake)
    local Ca = LP.Calib
    local L0 = UnitLevel("player") or 1
    local xp = 100
    local f = {
        UnitLevel = function(u) if u == "target" then return tl end return L0 end,
        UnitExists = function() return true end,
        UnitIsPlayer = function() return false end,
        UnitXP = function() return xp end,
        UnitXPMax = function() return 1000000 end,
        IsInGroup = function() return false end,
        GetXPExhaustion = function() return nil end,
        IsInInstance = function() return false, "none" end,
    }
    for k, v in pairs(fake or {}) do f[k] = v end
    Ca.ResetKillXP()
    return Guard(function()
        WithEnv({ Ca.ReadTarget, Ca.OnXPUpdate, Ca.OnKillXPMessage }, f, function()
            Ca:ReadTarget()
            Ca:OnXPUpdate()
            xp = xp + gain
            if f.SetXP then f.SetXP() end
            Ca:OnXPUpdate()
            Ca:OnKillXPMessage()
        end)
    end, function() Ca.ResetKillXP() end)
end

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (3.12.6)
------------------------------------------------------------------------
IMPL.T89 = function()
    local R = LP.Recorder
    local bait = "LPTestKoeder Haendler"
    local plain = "LPTestHaendler"
    local before = Count(LP.db.vendors)
    -- ohne Schutz wird der Händler erkannt (Gegenprobe), mit Schutz nicht
    local function rec(name)
        return WithEnv({ R.RecordService }, { UnitName = function() return name end, UnitGUID = function() return nil end,
            CanMerchantRepair = function() return false end }, function() R:RecordService("merchant") end)
    end
    local pos = LP.Geo:Player() ~= nil
    WithSecret({ bait }, function() rec(bait) end)
    local secretN = Count(LP.db.vendors)
    rec(plain)
    local plainN = Count(LP.db.vendors)
    for k, v in pairs(LP.db.vendors) do if type(v) == "table" and v.name == plain then LP.db.vendors[k] = nil end end
    LP.QuestDB:InvalidateServices()
    local ok = secretN == before and (plainN == before + 1 or not pos)
    return ok, string.format("geschützt %+d, Gegenprobe %+d", secretN - before, plainN - before), "geschützt +0, Gegenprobe +1"
end
IMPL.T186 = IMPL.T89

IMPL.T90 = function()
    local bait, baitUnit = "LPTestKoeder Kiste", "LPTestKoeder Einheit"
    local added = 0
    local tt = {
        GetUnit = function() return bait, baitUnit end,
        GetItem = function() return nil end,
        GetOwner = function() return UIParent end,
        AddLine = function() added = added + 1 end,
        Show = function() end,
    }
    local left = { GetText = function() return bait end }
    return WithSecret({ bait, baitUnit }, function()
        return WithEnv({ LP.Tooltips.OnShowObject, LP.Tooltips.OnUnit }, { GameTooltipTextLeft1 = left }, function()
            LP.Tooltips.OnShowObject(tt)
            tt.lpObjectDone = nil
            LP.Tooltips.OnUnit(tt)
            return added == 0, "Zeilen " .. added, "0"
        end)
    end)
end
IMPL.T187 = IMPL.T90

-- 3.12.21: Addon-Nachrichten kommen über GoldSentinelSync an (eigenes Ereignis-Frame der gemeinsamen Datei)
local OWN_PREFIX = { LvPilot2 = true, LvPilotG = true }   -- eigene Kennungen bei GoldSentinelSync
local function Deliver(prefix, msg, dist, sender)
    local Sy = _G.GoldSentinelSync
    if Sy and Sy.OnAddonMessage then Sy.OnAddonMessage(prefix, msg, dist, sender) end
end
TR.Deliver = Deliver

-- CHAT_MSG_ADDON mit geschützten Werten: geschützte Kennung/Nachricht -> nichts; geschützter Absender -> Comm
-- verarbeitet ohne Absender (keine Antwort), Group ignoriert (Gegenprobe ohne Schutz)
IMPL.T92 = function()
    local Gp = LP.Group
    local who = "LP9Tester-Test"
    local prefixC, prefixG = "LvPilot2", "LvPilotG"
    local msgG = "S\t5\t10\tGOTO\t0\ttext"
    local recv0 = LP.db.net and LP.db.net.recv
    return WithCounter(LP.Comm, "Receive", function(nC)
        return WithCounter(Gp, "OnMessage", function(nG)
            WithSecret({ "LPTestNachricht", msgG }, function()
                Deliver(prefixC, "LPTestNachricht", "WHISPER", who)
                Deliver(prefixG, msgG, "PARTY", who)
            end)
            local secretC, secretG = nC(), nG()
            -- nur der Absender geschützt: Comm ohne Absender, Group nichts
            WithSecret({ who }, function()
                Deliver(prefixC, "LPTestNachricht2", "WHISPER", who)
                Deliver(prefixG, msgG, "PARTY", who)
            end)
            local anonC, anonG = nC() - secretC, nG() - secretG
            -- Gegenprobe ohne Schutz: beide würden verarbeiten
            Deliver(prefixC, "LPTestNachricht3", "WHISPER", "LP9Tester2-Test")
            Deliver(prefixG, msgG, "PARTY", "LP9Tester2-Test")
            local plainC, plainG = nC() - secretC - anonC, nG() - secretG - anonG
            local ok = secretC == 0 and secretG == 0 and anonC == 1 and anonG == 0 and plainC == 1 and plainG == 1
            return ok, string.format("geschützt Comm %d Group %d · Absender geschützt Comm %d Group %d · Gegenprobe Comm %d Group %d",
                secretC, secretG, anonC, anonG, plainC, plainG), "0/0 · 1/0 · 1/1"
        end)
    end)
end
IMPL.T189 = IMPL.T92

-- Testkandidat für die Namensplaketten: Questziel "LPTestwolf getötet"
local function PlateCand()
    return { { id = 999101, title = "LPTest", byNpc = {}, objs = { { text = "LPTestwolf getötet: 0/8", have = 0, need = 8,
        finished = false, type = "monster" } } } }
end
IMPL.T93 = function()
    local bait = "LPTestwolf"
    local cand = PlateCand()
    local fake = { UnitName = function() return bait end, UnitGUID = function() return "LPTestKoeder GUID" end,
                   UnitIsPlayer = function() return false end, UnitIsDead = function() return false end }
    local plain = WithEnv({ LP.Plates.ForUnit }, fake, function() return LP.Plates:ForUnit("target", true, cand) end)
    local secret = WithSecret({ bait, "LPTestKoeder GUID" }, function()
        return WithEnv({ LP.Plates.ForUnit }, fake, function() return LP.Plates:ForUnit("target", true, cand) end)
    end)
    return secret == nil and plain ~= nil, "geschützt " .. S(secret ~= nil) .. ", Gegenprobe " .. S(plain ~= nil), "kein Treffer, Gegenprobe Treffer"
end

-- EP-Messung je Kill: echte Werte messen, geschützte nicht
IMPL.T74 = function()
    local P = LP.Planner
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 then return NA, "Level 60 – keine EP" end
    local f = P:KillXPFormula(L0, L0)
    return WithEmptyCalib(function()
        local c = LP.Acc().calib
        SimKill(L0, f)
        local k = c.killxp and c.killxp[0]
        local n1, r1 = k and k.n or 0, k and k.n > 0 and k.sum / k.n or 0
        SimKill(L0, f, { GetXPExhaustion = function() return 500 end })
        local n2 = c.killxp and c.killxp[0] and c.killxp[0].n or 0
        SimKill(L0, f, { IsInGroup = function() return true end })
        local n3 = c.killxp and c.killxp[0] and c.killxp[0].n or 0
        local ok = n1 == 1 and Near(r1, 1, 0.01) and n2 == 1 and n3 == 1
        return ok, string.format("gemessen %d (Verhältnis %.2f), erholt %+d, Gruppe %+d", n1, r1, n2 - n1, n3 - n2), "1 (1.00), +0, +0"
    end)
end

IMPL.T94 = function()
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 then return NA, "Level 60 – keine EP" end
    local f = LP.Planner:KillXPFormula(L0, L0)
    local baitL, baitXP = "LPTestKoeder Level", "LPTestKoeder EP"
    return WithEmptyCalib(function()
        local c = LP.Acc().calib
        -- geschütztes Ziellevel
        WithSecret({ baitL }, function()
            SimKill(L0, f, { UnitLevel = function(u) if u == "target" then return baitL end return L0 end })
        end)
        local n1 = Count(c.killxp)
        -- geschützte EP
        WithSecret({ baitXP }, function()
            SimKill(L0, f, { UnitXP = function() return baitXP end })
        end)
        local n2 = Count(c.killxp)
        return n1 == 0 and n2 == 0, "Messungen: Level geschützt " .. n1 .. ", EP geschützt " .. n2, "0, 0"
    end)
end

IMPL.T95 = function()
    local bait = "LPTestKoeder Klasse"
    local line = WithSecret({ bait }, function()
        return WithEnv({ LP.Measure.UnitLine }, { UnitExists = function() return true end, UnitIsPlayer = function() return false end,
            UnitClassification = function() return bait end, UnitGUID = function() return nil end, UnitLevel = function() return 5 end,
            UnitName = function() return "LPTest" end }, function() return LP.Measure.UnitLine("target") end)
    end)
    local ok = type(line) == "string" and not line:find(bait, 1, true) and line:find(" ? ", 1, true) ~= nil
    return ok, ok and "\"?\" statt des Werts" or S(line), "\"?\""
end
IMPL.T200 = IMPL.T95

-- erstes Paket-NPC mit Levelbereich (für die Gegenprobe)
local function PackNpcWithLevel()
    local N = _G.LevelPilotData and _G.LevelPilotData.N
    if type(N) ~= "table" then return nil end
    local n = 0
    for id, e in pairs(N) do
        n = n + 1
        if type(e) == "table" and type(e.lo) == "number" and e.lo > 0 and e.lo < 55 then return id, e end
        if n > 2000 then break end
    end
    return nil
end
IMPL.T96 = function()
    local Ca = LP.Calib
    local id, npc = PackNpcWithLevel()
    local guid = "Creature-0-1-1-1-" .. (id or 99902) .. "-0000ABCDEF"
    local lv = npc and ((npc.hi or npc.lo) + 3) or 10
    local c = LP.Acc().calib or {}
    LP.Acc().calib = c
    c.mobs = type(c.mobs) == "table" and c.mobs or {}
    local saved = c.mobs[id or 99902]
    c.mobs[id or 99902] = nil
    local fake = { UnitExists = function() return true end, UnitIsPlayer = function() return false end,
                   UnitPlayerControlled = function() return false end,
                   UnitGUID = function() return guid end, UnitLevel = function() return lv end }
    return Guard(function()
        WithSecret({ guid }, function() WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end) end)
        local a = c.mobs[id or 99902] == nil
        WithSecret({ lv }, function() WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end) end)
        local b = c.mobs[id or 99902] == nil
        WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end)
        local plain = c.mobs[id or 99902] ~= nil
        return a and b and (plain or not id), string.format("GUID geschützt %s, Level geschützt %s, Gegenprobe %s",
            a and "nichts" or "gelernt", b and "nichts" or "gelernt", plain and "gelernt" or "nichts"), "nichts, nichts, gelernt"
    end, function() c.mobs[id or 99902] = saved end)
end

IMPL.T98 = function()
    local bx, bm = "LPTestKoeder EP", "LPTestKoeder EPmax"
    return WithSecret({ bx, bm }, function()
        return WithEnv({ LP.PlayerXP }, { UnitXP = function() return bx end, UnitXPMax = function() return bm end }, function()
            local xp, mx, readable = LP:PlayerXP()
            LP.Comfort:TimerText()
            LP.Comfort:TimeTo60()
            LP.Comfort:TimeToLevel()
            LP.UI:Refresh()
            return readable == false and xp == 0 and mx == 1, string.format("lesbar %s, EP %s/%s", S(readable), S(xp), S(mx)),
                "lesbar false, 0/1, kein Lua-Fehler"
        end)
    end)
end

IMPL.T100 = function()
    local API = LP.API
    local fakeQ = Without(C_QuestLog, "GetNumQuestLogEntries", "GetQuestObjectives", "GetQuestTagInfo", "IsQuestFlaggedCompleted",
        "GetLogIndexForQuestID") or false
    return WithEnv({ API.NumEntries, API.Objectives, API.QuestTag, API.IsQuestDone, API.LogIndexForQuest, API.Entry },
        { C_QuestLog = fakeQ, GetNumQuestLogEntries = false, GetNumQuestLeaderBoards = false, GetQuestTagInfo = false,
          IsQuestFlaggedCompleted = false, GetQuestLogTitle = false }, function()
        local n, o, t, d, i = API.NumEntries(), API.Objectives(1), API.QuestTag(999104), API.IsQuestDone(1), API.LogIndexForQuest(1)
        local ok = n == 0 and type(o) == "table" and #o == 0 and t == nil and d == false and i == nil
        return ok, string.format("%s, %s Ziele, %s, %s, %s", S(n), S(type(o) == "table" and #o), S(t), S(d), S(i)), "0, 0 Ziele, nil, false, nil"
    end)
end

-- Selbsttest-Prüfung "Schnittstellen" mit fehlenden Funktionen
local function InterfacesCheck(fake)
    local fn
    for _, c in ipairs(LP.SelfTest.CHECKS or {}) do if c.name == "Schnittstellen" then fn = c.fn end end
    if not fn then return nil end
    local res = WithEnv({ fn }, fake, function() return LP.SelfTest:RunCheck("Schnittstellen") end)
    local t = {}
    for _, r in ipairs(res or {}) do t[#t + 1] = r.text end
    return table.concat(t, " ")
end

IMPL.T105 = function()
    local API = LP.API
    local fake = { UnitCharacterPoints = false, GetUnspentTalentPoints = false }
    return WithEnv({ API.TalentPoints }, fake, function()
        local p = API.TalentPoints()
        local talentHint = false
        WithSetting({ advTalents = true }, function()
            LP.Advisor:Run()
            for _, h in ipairs(LP.Advisor.hints or {}) do if h.key == "talents" then talentHint = true end end
        end)
        local diag = InterfacesCheck(fake) or ""
        local ok = p == nil and not talentHint and diag:find(L["Talentpunkte"], 1, true) ~= nil
        return ok, string.format("Punkte %s, Hinweis %s, Diagnose %s", S(p), S(talentHint),
            diag:find(L["Talentpunkte"], 1, true) and "nennt Talentpunkte" or "ohne Eintrag"), "nil, false, nennt Talentpunkte"
    end)
end

-- 3.12.21: der frühere Kanal LevelPilotNet wird nur noch verlassen, nie betreten
IMPL.T108 = function()
    local Comm = LP.Comm
    if not Comm.LeaveOldChannel then return false, "Comm.LeaveOldChannel fehlt", "zugänglich" end
    local function run(idx)
        local mark = ActMark()
        WithEnv({ Comm.LeaveOldChannel }, { GetChannelName = function() return idx end, LeaveChannelByName = function() end },
            function() Comm.LeaveOldChannel() end)
        return ActSince(mark, "LeaveChannelByName")
    end
    local a, b = run(7), run(0)
    return a == 1 and b == 0, string.format("im Kanal: verlassen %d×, nicht im Kanal: %d×", a, b), "1×, 0×"
end
IMPL.T193 = IMPL.T108

IMPL.T109 = function()
    local Su, H = LP.Supply, LP.Hints
    local fake = { GetPetHappiness = false, GetPetFoodTypes = false, UnitClass = function() return "Jäger", "HUNTER" end,
                   UnitExists = function() return true end }
    WithSetting({ restockPetFood = true, hintClass = true }, function()
        WithEnv({ Su.Needs, H.ClassReminders }, fake, function()
            Su:Needs()
            H.ClassReminders(function() end)
        end)
    end)
    local diag = InterfacesCheck(fake) or ""
    local a = diag:find(L["Zufriedenheit des Begleiters"], 1, true) ~= nil
    local b = diag:find(L["Futter des Begleiters"], 1, true) ~= nil
    return a and b, "Diagnose: Zufriedenheit " .. S(a) .. ", Futter " .. S(b), "beide als nicht verfügbar"
end

IMPL.T110 = function()
    local D, Nm, Pr = LP.Donate, LP.Names, LP.Protocol
    local used = 0
    local a = WithEnv({ D.AddonTitle }, { C_AddOns = false, GetAddOnMetadata = function() used = used + 1 return "|cffffb238LevelPilot|r" end },
        function() return D.AddonTitle() end)
    local b = WithEnv({ D.AddonTitle }, { C_AddOns = false, GetAddOnMetadata = false }, function() return D.AddonTitle() end)
    WithEnv({ Nm.Load }, { C_AddOns = false, LoadAddOn = false }, function() Nm:Load("xx") Nm:Load(LP:Language()) end)
    if Pr.Memory then WithEnv({ Pr.Memory }, { UpdateAddOnMemoryUsage = false }, function() Pr.Memory() end) end
    local ok = a == "LevelPilot" and used == 1 and b == "LevelPilot"
    return ok, string.format("alt %s (%d×), ohne beide %s", S(a), used, S(b)), "LevelPilot (1×), LevelPilot"
end

IMPL.T111 = function()
    local Gp, Se = LP.Group, LP.Session
    if not Gp.Send then return false, "Group.Send fehlt", "zugänglich" end
    return WithSetting({ groupSync = true }, function()
        -- 3.12.21: Gruppe über GoldSentinelSync (nur an die Gruppe, nie ins Netz)
        local Sy = _G.GoldSentinelSync
        local api = Sy and Sy.api
        if not api then return false, "GoldSentinelSync fehlt", "geladen" end
        local oGroup, oRaid = api.inGroup, api.inRaid
        local a, b, net0 = 0, 0, Sy.netQueue and #Sy.netQueue or 0
        local snap = LP.Comm:QueueSnapshot()
        Guard(function()
            api.inGroup, api.inRaid = function() return true end, function() return false end
            local q0 = LP.Comm:QueueCount()
            WithEnv({ Gp.InGroup }, { IsInGroup = function() return true end }, function() Gp.Send("R") end)
            a = LP.Comm:QueueCount() - q0
            q0 = LP.Comm:QueueCount()
            WithSetting({ groupSync = false }, function()
                WithEnv({ Gp.InGroup }, { IsInGroup = function() return true end }, function() Gp.Send("R") end)
            end)
            b = LP.Comm:QueueCount() - q0
        end, function() api.inGroup, api.inRaid = oGroup, oRaid LP.Comm:QueueRestore(snap) end)
        local netAdded = (Sy.netQueue and #Sy.netQueue or 0) - net0
        if netAdded > 0 then a = -1 end
        local mark = ActMark()
        WithEnv({ Se.Summary }, { C_ChatInfo = false, SendChatMessage = false, IsInGuild = function() return true end },
            function() Se:Summary(true) end)
        local c = ActSince(mark, "SendChatMessage")
        return a == 1 and b == 0 and c == 0, string.format("Gruppe %d, Gruppenmodus aus %d, Bilanz %d", a, b, c), "1, 0, 0"
    end)
end

-- Flug-Schritt vorgeben (Engine:Current, Addon-Tabelle)
local function FlyStep(body)
    local E = LP.Engine
    local orig = E.Current
    E.Current = function() return { t = "FLY", text = "LPTestflugpunkt", key = "LPTestFlug" } end
    return Guard(body, function() E.Current = orig end)
end

-- weitere alte Globals, je einzeln weg
IMPL.T112 = function()
    local E, C, A, Su, H, Ac = LP.Engine, LP.Comfort, LP.Advisor, LP.Supply, LP.Hints, LP.Actions
    local step = { t = "COMPLETE", id = 999105, key = "LPTest" }
    local cases = {
        { { E.HandleGreeting }, "GetNumActiveQuests", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "GetActiveTitle", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "SelectActiveQuest", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "GetNumAvailableQuests", function() E.HandleGreeting() end },
        { { C.Repair }, "GetRepairAllCost", function() C:Repair() end, { CanMerchantRepair = function() return true end } },
        { { A.Checks.Durability }, "GetInventoryItemDurability", function() A.Checks.Durability(function() end) end },
        { { A.Checks.Ammo }, "GetInventoryItemCount", function() A.Checks.Ammo(function() end) end,
          { UnitClass = function() return "Jäger", "HUNTER" end, GetInventoryItemLink = function() return "item:2504" end } },
        { { Su.Needs }, "GetItemInfoInstant", function() Su:Needs() end,
          { C_Item = Without(C_Item, "GetItemInfoInstant") or false, UnitClass = function() return "Jäger", "HUNTER" end,
            GetInventoryItemLink = function() return "item:2504" end } },
        { { C.AutoFly }, "NumTaxiNodes", function() FlyStep(function() C:AutoFly() end) end },
        { { C.AutoFly }, "TaxiNodeName", function() FlyStep(function() C:AutoFly() end) end },
        { { H.LearnTrainerCosts }, "GetNumTrainerServices", function() H:LearnTrainerCosts() end },
        { { H.ClassReminders }, "GetWeaponEnchantInfo", function() H.ClassReminders(function() end) end,
          { UnitClass = function() return "Schurke", "ROGUE" end } },
        { { Ac.ItemFor }, "GetQuestLogSpecialItemInfo", function() Ac.ItemFor(step) end },
        { { Ac.Update }, "GetItemIcon", function() Ac:Update() end, { C_Item = Without(C_Item, "GetItemIconByID") or false } },
    }
    local bad = {}
    -- 3.12.93 (Nachbau Laptop-Daten: ein Fall bis 87 ms – Dienst-NPCs/Umwege mit kaltem Zwischenspeicher unter dem Ersatz): die
    -- Suche nach den nächsten Diensten vorher als freigegebene Rechnung (ohne Ersatz) aufwärmen
    for _, kind in ipairs({ "repair", "vendor", "inn", "flight", "trainer" }) do
        PCallY(Coop, LP.QuestDB.NearestService, LP.QuestDB, kind)
        TR.Safe("T112")
    end
    -- 3.12.93: Einstellungen je Fall (vorher einmal für alle 15 Fälle) – dazwischen sind sie zurück und es gibt eine sichere Stelle
    for _, c in ipairs(cases) do
        WithSetting({ autoTurnin = true, autoAccept = true, autoRepair = true, autoFly = true, advDurability = true, advAmmo = true,
                      restockAmmo = true, hintClass = true }, function()
            local fake = { [c[2]] = false }
            for k, v in pairs(c[4] or {}) do fake[k] = v end
            local ok, err = pcall(WithEnv, c[1], fake, c[3])
            if not ok then bad[#bad + 1] = c[2] .. ": " .. tostring(err):sub(1, 80) end
        end)
        TR.Safe("T112")
    end
    return #bad == 0, #bad == 0 and (#cases .. " Fälle ohne Fehler") or table.concat(bad, "; "), "kein Lua-Fehler"
end

IMPL.T113 = function()
    local Nm = LP.Names
    local threw = 0
    return WithEnv({ Nm.Init }, { collectgarbage = function() threw = threw + 1 error("LP-Testfehler collectgarbage", 0) end }, function()
        local ok, err = pcall(Nm.Init, Nm)
        local st = Nm:StatusText()
        return ok and type(st) == "string", ok and ("Laden zu Ende" .. (threw > 0 and ", collectgarbage warf" or "")) or tostring(err),
            "Laden läuft zu Ende"
    end)
end
IMPL.T190 = IMPL.T113

IMPL.T114 = function()
    local Ac = LP.Actions
    local btn = _G.LevelPilotTargetButton
    if not btn then return false, "LevelPilotTargetButton fehlt", "vorhanden" end
    -- Zustand vorher/nachher vergleichen (der sichere Knopf selbst wird nie verändert)
    local function state()
        return tostring(btn.GetAttribute and btn:GetAttribute("macrotext")), btn:IsShown() and true or false,
            Ac.bar and Ac.bar:IsShown() and true or false
    end
    local m1, s1, b1 = state()
    local touched = 0
    local fake = { InCombatLockdown = function() return true end }
    WithEnv({ Ac.Update }, fake, function()
        WithCounter(LP.Engine, "Current", function(n)
            Ac:Update()
            touched = n()
        end)
    end)
    local m2, s2, b2 = state()
    local inCombat = touched == 0 and m1 == m2 and s1 == s2 and b1 == b2
    -- nach dem Kampf: PLAYER_REGEN_ENABLED holt die Aktualisierung nach
    local runs = WithCounter(Ac, "Update", function(n)
        for _, fn in ipairs(HandlerList("PLAYER_REGEN_ENABLED")) do pcall(fn, "PLAYER_REGEN_ENABLED") end
        return n()
    end, true)
    return inCombat and runs >= 1, string.format("im Kampf: Schritt gelesen %d×, Knopf %s · danach %d Aktualisierung", touched,
        inCombat and "unverändert" or "verändert", runs), "0×, unverändert · danach >= 1"
end

------------------------------------------------------------------------
-- J. Regressionstests (3.12.6)
------------------------------------------------------------------------
IMPL.T169 = function()
    return WithFlavor("forever", function()
        local a = LP.SameName("Testa", "Testa Beispiel")
        local b = LP.SameName("Testa Beispiel", "Testa Eisenfaust")
        local me = UnitName("player")
        local realm = GetRealmName and GetRealmName() or "Realm"
        local own = tostring(me) .. "-" .. tostring(realm):gsub("%s", "")
        local members = Count(LP.Group.members)
        local c = WithCounter(LP.Comm, "Receive", function(n)
            Deliver("LvPilot2", "LPTestNachricht", "WHISPER", own)
            Deliver("LvPilotG", "S\t5\t10\tGOTO\t0\ttext", "PARTY", own)
            return n()
        end)
        local m2 = Count(LP.Group.members)
        return a == true and b == false and c == 0 and m2 == members, string.format("%s, %s, eigene Nachricht: Comm %d, Group %+d",
            S(a), S(b), c, m2 - members), "true, false, 0, +0"
    end)
end

CLIENT.T171 = "/dump select(4, GetBuildInfo()) – Nummer in LevelPilot.toc und LevelPilot_Data.toc, 16001 bleibt drin"

IMPL.T177 = function()
    local P, Ca = LP.Planner, LP.Calib
    local a = { IMPL.T74() }
    local b = { IMPL.T94() }
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 or L0 < 6 then return a[1] and b[1] and true or false, "Level " .. L0 .. " – Messung auf Stufe -3 nicht möglich" end
    return WithEmptyCalib(function()
        return WithSetting({ forever = true }, function()
            return WithFlavor("forever", function()
                local f = P:KillXPFormula(L0, L0 - 3)
                for _ = 1, 20 do SimKill(L0 - 3, math.floor(f * 0.7 + 0.5)) end
                local r = Ca:KillXPRatio(-3)
                local g, measured = P:GreenXPFactor(-3)
                local txt = Ca:KillXPText()
                local ok = a[1] and b[1] and r ~= nil and Near(g, r, 0.001) and measured == true and txt:find("20", 1, true) ~= nil
                return ok and true or false, string.format("T74 %s, T94 %s, Stufe -3: %.2f (%s), %s", S(a[1]), S(b[1]), g or 0,
                    S(measured), txt), "OK, OK, Messwert ersetzt 0.85, gemessen 20"
            end)
        end)
    end)
end

IMPL.T179 = function()
    local key = "aus deinen EP der letzten Stunde – gilt für jeden Modus (Normal und Speedrun)"
    local miss = {}
    for _, code in ipairs(CODES) do
        local t = LP.Locales[code]
        local fb = LP.LanguageInfo[code] and LP.LanguageInfo[code].fallback
        if not ((t and t[key]) or (fb and LP.Locales[fb] and LP.Locales[fb][key])) then miss[#miss + 1] = code end
    end
    local f = _G.LevelPilotCenter
    local wasShown = f and f:IsShown()
    local shown = Guard(function()
        if not (f and f:IsShown()) then LP.Center:Toggle() end
        LP.Center:Select("comfort")
        return FindText(_G.LevelPilotCenter, L[key])
    end, function() if _G.LevelPilotCenter and not wasShown then _G.LevelPilotCenter:Hide() end end)
    return #miss == 0 and shown, "angezeigt " .. S(shown) .. (#miss > 0 and (", fehlt in " .. table.concat(miss, ",")) or ", alle 10 Sprachen"),
        "angezeigt, alle 10 Sprachen"
end

IMPL.T184 = function()
    local B = LP.Backup
    local ok, err = pcall(Slash, "reise bericht")
    local f = _G.LevelPilotBackupFrame
    local titled = f and FindText(f, L["Virtuelle Reise – Bericht"]) or false
    if f then f:Hide() end
    return ok and titled, ok and ("Titel übersetzt " .. S(titled)) or tostring(err), "kein Fehler, Titel übersetzt"
end

IMPL.T195 = function()
    local a = { IMPL.T105() }
    local b = { IMPL.T109() }
    return a[1] and b[1] and true or false, "T105 " .. S(a[1]) .. ", T109 " .. S(b[1]), "beide OK"
end
CLIENT.T195 = "/dump UnitCharacterPoints, /dump GetUnspentTalentPoints, /dump GetPetHappiness, /dump GetPetFoodTypes – Ergebnis zurückmelden"
CLIENT.T213 = "/dump C_SpellBook.IsSpellKnown(3273) und /dump IsPlayerSpell(3273) – Erste Hilfe gelernt? Beide Antworten zurückmelden"

-- K13: Dropraten ohne Kampflog (3.12.6: Kill bei der EP-Meldung, Stück über CHAT_MSG_LOOT)
IMPL.T196 = function()
    local Ca = LP.Calib
    local g = G()
    if not (g and g.IsModern) then return true, "alter Client: Kampflog wie bisher" end
    local item, npc = 999006, 99906
    local guid = "Creature-0-1-1-1-" .. npc .. "-0000ABCD01"
    local guid2 = "Creature-0-1-1-1-" .. npc .. "-0000ABCD02"
    local s = LP.Acc().calib or {}
    LP.Acc().calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local saved, savedW = s.drops[item], Ca.testWanted
    s.drops[item] = nil
    Ca.testWanted = { [item] = { npc = { [npc] = true } } }
    local link = "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
    local tguid = guid
    local target = { UnitExists = function() return true end, UnitGUID = function() return tguid end, UnitIsDead = function() return true end }
    local loot = {
        GetNumLootItems = function() return 1 end,
        GetLootSlotLink = function() return link end,
        GetLootSourceInfo = function() return tguid, 2 end,
        UnitExists = function() return false end,
    }
    local selfMsg = (LOOT_ITEM_SELF_MULTIPLE and LOOT_ITEM_SELF_MULTIPLE:gsub("%%%d?%$?s", link, 1):gsub("%%%d?%$?d", "2", 1))
        or ("Ihr bekommt Beute: " .. link .. "x2.")
    local function D() local d = s.drops[item] or { k = 0, g = 0 } return d.k, d.g end
    return Guard(function()
        -- 1) Kill bei der EP-Meldung, Leiche ohne Beute (nie geöffnet)
        WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end)
        local k1, g1 = D()
        -- 2) zweite Leiche: EP-Meldung, dann plündern (Kill nicht doppelt), Beutemeldung x2
        tguid = guid2
        WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end)
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, loot, function() Ca:OnLootOpened() end)
        Ca:OnLoot(selfMsg)
        Ca:OnLootClosed()
        local k2, g2 = D()
        -- 3) erneut geöffnet, Tasche voll: nichts kommt an -> keine Stück
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, loot, function() Ca:OnLootOpened() end)
        Ca:OnLootClosed()
        local k3, g3 = D()
        -- 4) geschützte GUID bei der EP-Meldung -> kein Kill
        tguid = "Creature-0-1-1-1-" .. npc .. "-0000ABCD03"
        WithSecret({ tguid }, function() WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end) end)
        local k4 = D()
        local ok = k1 == 1 and g1 == 0 and k2 == 2 and g2 == 2 and k3 == 2 and g3 == 2 and k4 == 2
        return ok, string.format("ohne Beute %d/%d · geplündert %d/%d · liegen gelassen %d/%d · geschützt %d", k1, g1, k2, g2, k3, g3, k4),
            "1/0 · 2/2 · 2/2 · 2 (Kills/Stück)"
    end, function()
        s.drops[item] = saved
        Ca.testWanted = savedW
        Ca.ResetLooted(guid) Ca.ResetLooted(guid2) Ca.ResetLooted(tguid)
    end)
end

IMPL.T201 = function()
    local Tt, Q = LP.Tooltips, LP.QuestDB
    local I = _G.LevelPilotData and _G.LevelPilotData.I
    local item
    local n = 0
    for id in pairs(type(I) == "table" and I or {}) do
        n = n + 1
        local info = Q:ItemQuests(id)
        if info and info.starts and #info.starts > 0 then item = id break end
        if n > 3000 then break end
    end
    if not item then return true, "kein Gegenstand, der eine Quest startet (ohne Datenpaket)" end
    return WithSetting({ tooltips = true }, function()
        return WithCounter(LP.API, "IsQuestDone", function(calls)
            Tt:ItemLines(item)
            Tt:IsProtected(item)
            return calls() >= 1, "LP.API.IsQuestDone " .. calls() .. "×", ">= 1×"
        end, true)
    end)
end

------------------------------------------------------------------------
-- B. Funktionen (3.12.6)
------------------------------------------------------------------------
local function Shown(name) local f = _G[name] return f and f:IsShown() and true or false end
local function Hide(name) local f = _G[name] if f then f:Hide() end end

-- alle Slash-Befehle in pcall: Fehlerliste
-- 3.12.93: echte Befehle (kein Ersatz) als freigegebene Rechnung, nach jedem Befehl eine sichere Stelle. In einem pcall bzw. unter
-- WithEnv & Co. (Aufrufer) gibt der Takt ohnehin nicht ab.
local function SlashAll(list)
    local bad = {}
    for _, m in ipairs(list) do
        local ok, err = PCallY(Coop, Slash, m)
        if not ok then bad[#bad + 1] = "\"" .. m .. "\": " .. tostring(err):sub(1, 80) end
        TR.Safe("/lp " .. m)
    end
    return bad
end

IMPL.T16 = function()
    local ui0, ce0, compact0 = LP.UI:IsShown(), Shown("LevelPilotCenter"), LP.db.compactMode
    local bad = SlashAll({ "" })
    local ui1 = LP.UI:IsShown()
    bad = SlashAll({ "" })
    local ce = {}
    for _, m in ipairs({ "zentrale", "center" }) do
        local a = Shown("LevelPilotCenter")
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        ce[#ce + 1] = Shown("LevelPilotCenter") ~= a
    end
    for _, m in ipairs({ "kompakt", "kompakt", "compact", "compact" }) do for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end end
    local donate = {}
    for _, m in ipairs({ "spenden", "donate", "support" }) do
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        local f = LP.Donate.frame or _G.LevelPilotDonateFrame
        donate[#donate + 1] = f == nil or f:IsShown()
        if f then f:Hide() end
    end
    if LP.UI:IsShown() ~= ui0 then LP.UI:Toggle() end
    if Shown("LevelPilotCenter") ~= ce0 then LP.Center:Toggle() end
    local ok = #bad == 0 and ui1 ~= ui0 and ce[1] and ce[2] and LP.db.compactMode == compact0 and donate[1] and donate[2] and donate[3]
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Guide wechselt %s, Zentrale %s/%s, kompakt gleich %s",
        S(ui1 ~= ui0), S(ce[1]), S(ce[2]), S(LP.db.compactMode == compact0)), "alles wechselt, kompakt wie vorher"
end

IMPL.T18 = function()
    local P = LP.Planner
    local old = P.priority
    return Guard(function()
        local bad = SlashAll({ "way 45.5 60.2" })
        local p1 = P.priority
        local a = p1 and p1.t == "GOTO" and Near(p1.x, 45.5, 0.01) and Near(p1.y, 60.2, 0.01)
        for _, e in ipairs(SlashAll({ "weg 10 20" })) do bad[#bad + 1] = e end
        local p2 = P.priority
        local b = p2 and p2.t == "GOTO" and Near(p2.x, 10, 0.01) and Near(p2.y, 20, 0.01)
        for _, e in ipairs(SlashAll({ "find repar", "such flug", "find xyz" })) do bad[#bad + 1] = e end
        local pos = LP.Geo:Player() ~= nil
        return #bad == 0 and ((a and b) or not pos) and true or false,
            #bad > 0 and table.concat(bad, "; ") or ("way " .. S(a) .. ", weg " .. S(b)), "GOTO 45.5/60.2 und 10/20, kein Fehler"
    end, function() P.priority = old PCallY(Coop, P.Replan, P) end, true)   -- 3.12.93: echte Befehle wie vom Spieler, darf abgeben
                                                                            -- 3.12.99: auch die Neuplanung danach (vorher pcall)
end

IMPL.T20 = function()
    local mark = ActMark()
    local bad = SlashAll({ "teilen", "share", "gruppe", "lfg", "bilanz", "summary", "bilanz gilde", "summary guild" })
    local guild = IsInGuild and IsInGuild() and ((C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage) and true or false
    local sent = ActSince(mark, "SendChatMessage")
    local push = ActSince(mark, "QuestLogPushQuest")
    local share = LP.Social:ShareList()
    local sum = LP.Session:Summary(false)
    local want = L("LevelPilot-Bilanz: %d Level, %d Quests, %s, %s aktiv gespielt", 0, 0, "", ""):match("^[^:]+")
    local ok = #bad == 0 and (guild and sent == 2 or (not guild and sent == 0)) and (push == 0 or #share > 0)
        and type(sum) == "string" and sum:sub(1, #want) == want
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Gilde %s: %d mitgeschrieben, Teilen %d, Bilanz %s",
        S(guild), sent, push, sum:sub(1, #want)), "Gilde nur mit Gilde, Bilanz-Text"
end

IMPL.T21 = function()
    local Pr = LP.Protocol
    local f = function() return _G.LevelPilotBackupFrame end
    local opened = {}
    local bad = {}
    for _, m in ipairs({ "protokoll", "log", "diag", "diagnose", "plan", "messen", "measure", "test", "selbsttest" }) do
        if f() then f():Hide() end
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        if m == "protokoll" or m == "messen" or m == "test" then opened[#opened + 1] = f() and f():IsShown() or false end
        if f() then f():Hide() end
    end
    for _, e in ipairs(SlashAll({ "protokoll leer" })) do bad[#bad + 1] = e end
    local n = Pr:Count()
    local ok = #bad == 0 and n == 0 and opened[1] and opened[2] and opened[3]
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Kopierfenster %s/%s/%s, Protokoll danach %d",
        S(opened[1]), S(opened[2]), S(opened[3]), n), "Fenster auf und zu, Protokoll 0"
end

IMPL.T22 = function()
    local V = LP.Virtual
    if not LP:IsDev() then
        local bad = SlashAll({ "reise hier" })
        local was = V.active
        if V.active then V:Abort() end
        return #bad == 0 and not was, "ohne Testmodus: Reise gestartet " .. S(was), "nichts"
    end
    local bad = SlashAll({ "reise hier", "reise stop", "reise zuschauen", "reise stopp", "reise bericht", "journey report" })
    Hide("LevelPilotBackupFrame") Hide("LevelPilotVirtualFrame")
    local active = V.active
    if V.active then V:Abort() end
    local sb = V.s and V.s.sandboxDiff
    local ok = #bad == 0 and not active and (sb == nil or #sb == 0)
    return ok, #bad > 0 and table.concat(bad, "; ") or ("Reise aktiv " .. S(active) .. ", Sandbox " .. (sb and #sb == 0 and "OK" or "?")),
        "aus, Sandbox OK (\"reise vergleich\" nur mit /lp testroutine reise)"
end

IMPL.T25 = function()
    local UI = LP.UI
    local db = LP.db
    local saved = { db.compactMode, db.stepsShown, db.scale, db.locked }
    local was = UI:IsShown()
    -- 3.12.99 (Ingametest 3.12.97: Bild "T22 graph–T25" 61,9 ms, T25 58,1 ms am Stück): echte Einstellungen des Spielers (kein
    -- Ersatz), jeder Schritt als freigegebene Rechnung, dazwischen sichere Stellen
    return Guard(function()
        Coop(UI.Toggle, UI) TR.Safe("T25") Coop(UI.Toggle, UI) TR.Safe("T25")
        local same = UI:IsShown() == was
        if not UI:IsShown() then Coop(UI.Toggle, UI) end
        local function Apply(refresh)
            Coop(UI.ApplySettings, UI) TR.Safe("T25")
            if refresh then Coop(UI.Refresh, UI) TR.Safe("T25") end
        end
        for _, v in ipairs({ true, false }) do db.compactMode = v Apply(true) end
        for _, v in ipairs({ 1, 5, 10 }) do db.stepsShown = v Apply(true) end
        for _, v in ipairs({ 0.6, 1.6 }) do db.scale = v Apply(true) end
        for _, v in ipairs({ true, false }) do db.locked = v Apply(false) end
        local grip = type(UI.CreateSizeGrip) == "function"
        local cur = LP.Engine:Current()
        local txt = cur and UI:StepText(cur, false)
        local ok = same and grip and (cur == nil or (type(txt) == "string" and txt ~= ""))
        return ok, string.format("Toggle zweimal gleich %s, Text %s", S(same), cur and S(txt ~= "") or "kein Schritt"), "kein Fehler, Text"
    end, function()
        db.compactMode, db.stepsShown, db.scale, db.locked = saved[1], saved[2], saved[3], saved[4]
        UI:ApplySettings()
        if UI:IsShown() ~= was then UI:Toggle() end
    end, true)
end

IMPL.T26 = function()
    local E, UI = LP.Engine, LP.UI
    local step = E:Current()
    if not step then return NA, "kein Schritt geplant" end
    if step.t == "LEVEL" or step.key == "NODATA" or step.key == "NOPOS" or step.key == "DGIN" then
        return NA, "aktueller Schritt lässt sich nicht überspringen (" .. tostring(step.t) .. ")"
    end
    -- 3.12.93: ein Ziel (PRIO: Trainer-Besuch, /lp weg …) ist kein Routenschritt – übersprungen wird es erledigt und kommt nicht
    -- "wieder geplant" zurück (Nachbau Allianz Stufe 10: der Hinweis „Klassentrainer“ stand oben, T26 meldete FEHLER)
    if type(step.key) == "string" and step.key:find("^PRIO:") then
        return NA, "aktueller Schritt ist ein Ziel (" .. step.key .. "), kein Routenschritt"
    end
    local saved = {}
    for _, k in ipairs({ "ignored", "doneKeys", "notOffered", "dungeonRun" }) do saved[k] = LP.Backup.DeepCopy(LP.char[k] or {}) end
    local lastIgn = E.lastIgnored
    local function planned()
        for _, s in ipairs(E:Steps()) do if s.key == step.key then return true end end
        return false
    end
    return Guard(function()
        -- 3.12.94 (Ingametest 3.12.93: T26 286 ms in einem Bild – mehrere Neuplanungen am Stück): echte Schritte des Spielers (kein
        -- Ersatz), Neuplanungen als freigegebene Rechnung, dazwischen sichere Stellen
        UI:StepMenu(nil, step)
        local menuShown = Shown("LevelPilotStepMenu")
        Hide("LevelPilotStepMenu")
        Coop(E.Skip, E, step)
        local gone = not planned()
        TR.Safe("T26")
        local quest = step.id and (step.t == "ACCEPT" or step.t == "COMPLETE" or step.t == "TURNIN")
        if quest then Coop(E.Unignore, E) else LP.char.doneKeys[step.key] = nil end
        Coop(LP.Planner.Replan, LP.Planner, true)
        local back = planned()
        TR.Safe("T26")
        Coop(E.Later, E, step)
        local later = E:IsLater(step.key) and not planned()
        E.later[step.key] = nil
        TR.Safe("T26")
        Coop(E.ResetIgnored, E)
        return menuShown and gone and back and later, string.format("Menü %s, übersprungen %s, wieder geplant %s, zurückgestellt %s",
            S(menuShown), S(gone), S(back), S(later)), "Menü, übersprungen, wieder geplant, zurückgestellt"
    end, function()
        E.later[step.key] = nil
        E.lastIgnored = lastIgn
        for k, v in pairs(saved) do
            local cur = LP.char[k]
            if type(cur) == "table" then
                for kk in pairs(cur) do if v[kk] == nil then cur[kk] = nil end end
                for kk, vv in pairs(v) do cur[kk] = vv end
            end
        end
        TR.Safe("T26")
        PCallY(Coop, LP.Planner.Replan, LP.Planner, true)
    end, true)          -- 3.12.94: echte Schritte des Spielers, darf abgeben
end

IMPL.T28 = function()
    local b = _G.LevelPilotMinimapButton
    if not b then return false, "Minimap-Button fehlt", "vorhanden" end
    local was, angle = LP.db.showMinimapBtn, LP.db.minimapAngle
    return Guard(function()
        LP.db.showMinimapBtn = false LP.UI:ApplySettings()
        local off = not b:IsShown()
        LP.db.showMinimapBtn = true LP.UI:ApplySettings()
        local on = b:IsShown() and true or false
        return off and on and LP.db.minimapAngle == angle, "aus versteckt " .. S(off) .. ", an sichtbar " .. S(on), "versteckt, sichtbar, Winkel gleich"
    end, function() LP.db.showMinimapBtn = was LP.UI:ApplySettings() end)
end

IMPL.T29 = function()
    local a = _G.LevelPilotArrow
    local was = LP.db.showArrow
    return Guard(function()
        LP.db.showArrow = false
        LP.Nav:Refresh()
        local hidden = not a or not a:IsShown()
        LP.db.showArrow = true
        LP.Nav:Refresh()
        return hidden, "aus versteckt " .. S(hidden), "versteckt"
    end, function() LP.db.showArrow = was pcall(LP.Nav.Refresh, LP.Nav) end)
end

-- 3.12.93: Klick über den Lua-Handler (OnClick) als freigegebene Rechnung; ohne Handler oder gesperrt wie bisher Button:Click
local function ClickY(btn)
    local h = btn.GetScript and btn:GetScript("OnClick")
    if type(h) == "function" and (not btn.IsEnabled or btn:IsEnabled() ~= false) then return Coop(h, btn, "LeftButton", false) end
    return btn:Click()
end

-- Zentrale öffnen und alle Reiter einmal aufbauen
local function WithCenter(body)
    local f = _G.LevelPilotCenter
    local was = f and f:IsShown()
    return Guard(function()
        if not (_G.LevelPilotCenter and _G.LevelPilotCenter:IsShown()) then LP.Center:Toggle() end
        for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do
            Coop(LP.Center.Select, LP.Center, k)   -- 3.12.93: Aufbau eines Reiters darf abgeben (z. B. Dungeon-Übersicht)
            TR.Safe("Zentrale")            -- 3.12.93: nach jedem Reiter (in einem pcall des Aufrufers wirkungslos)
        end
        return body()
    end, function() if _G.LevelPilotCenter and not was then _G.LevelPilotCenter:Hide() end end, true)   -- 3.12.93: nur echtes Fenster, darf abgeben
end

IMPL.T31 = function()
    return WithCenter(function()
        local list, seen = {}, {}
        for i = #(LP.Center.toggles or {}), 1, -1 do
            local t = LP.Center.toggles[i]
            if not seen[t.key] then seen[t.key] = true list[#list + 1] = t end
        end
        local mark = ActMark()
        local bad, changed = {}, {}
        for _, t in ipairs(list) do
            local before = LP.db[t.key]
            -- 3.12.93 (Ingametest 3.12.91: T31 678 ms in einem Bild; Nachbau Laptop-Daten: Schalter mit Neuplanung bzw. „Datenpaket
            -- nutzen" (QuestDB:Reconnect + Neuplanung mit kalten Zwischenspeichern) bis 350 ms je Klick): der Klick-Handler (OnClick,
            -- Lua) direkt als freigegebene Rechnung – Button:Click ist im Spiel eine C-Funktion, darunter könnte nie abgegeben werden;
            -- ein gesperrter Knopf wie bisher über Click. Nach jedem Schalter (wieder wie vorher) eine sichere Stelle.
            local ok1, e1 = PCallY(ClickY, t.button)
            local mid = LP.db[t.key]
            local ok2, e2 = PCallY(ClickY, t.button)
            TR.Safe("T31")
            if not ok1 or not ok2 then bad[#bad + 1] = t.key .. ": " .. tostring(e1 or e2):sub(1, 60)
            elseif LP.db[t.key] ~= before then changed[#changed + 1] = t.key
            elseif (not mid) == (not before) then bad[#bad + 1] = t.key .. ": schaltet nicht" end
        end
        local ok = #bad == 0 and #changed == 0 and #list >= 60
        return ok, string.format("%d Schalter, Fehler: %s, nicht zurück: %s", #list,
            #bad > 0 and table.concat(bad, "; ") or "keine", #changed > 0 and table.concat(changed, ",") or "keine"),
            ">= 60 Schalter, alle zweimal, Wert wie vorher"
    end)
end

IMPL.T32 = function()
    return WithCenter(function()
        local bad = {}
        local list = {}
        local seen = {}
        for i = #(LP.Center.steppers or {}), 1, -1 do
            local st = LP.Center.steppers[i]
            if not seen[st.label] then seen[st.label] = true list[#list + 1] = st end
        end
        for _, st in ipairs(list) do
            -- Seite des Steppers zeigen (die Anzeige wird nur auf der sichtbaren Seite erneuert)
            for k, p in pairs(LP.Center.pages or {}) do if p == st.page then LP.Center:Select(k) end end
            local v0 = st.get()
            -- 3.12.93 (Ingametest 3.12.91: T32 3308 ms in einem Bild, ~400 Klicks mit ApplySettings und Neuaufbau der Seite):
            -- nach jedem Klick eine sichere Stelle (echte Einstellung, kein Ersatz; die Seite zeigt für ein paar Bilder Zwischenwerte)
            local ok, err = PCallY(function()
                local steps = math.ceil((st.max - st.min) / st.step) + 2
                for _ = 1, steps do st.plus:Click() TR.Safe("T32") end
                if math.abs(st.get() - st.max) > 1e-6 then error("Maximum " .. tostring(st.get()) .. " statt " .. st.max, 0) end
                local txt = st.val:GetText()
                if txt ~= string.format(st.fmt, st.get()) then error("Text " .. tostring(txt), 0) end
                for _ = 1, steps do st.minus:Click() TR.Safe("T32") end
                if math.abs(st.get() - st.min) > 1e-6 then error("Minimum " .. tostring(st.get()) .. " statt " .. st.min, 0) end
                txt = st.val:GetText()
                if txt ~= string.format(st.fmt, st.get()) then error("Text " .. tostring(txt), 0) end
            end)
            st.set(v0)
            TR.Safe("T32")
            if not ok then bad[#bad + 1] = tostring(st.label):sub(1, 30) .. ": " .. tostring(err) end
            if st.get() ~= v0 then bad[#bad + 1] = tostring(st.label):sub(1, 30) .. ": nicht zurück" end
        end
        LP.UI:ApplySettings()
        LP.Center:Refresh()
        -- im Code gibt es 11 Stepper; einen zwölften "Vorräte" hat die Zentrale nicht (Mengen kommen aus den Grundwerten)
        return #bad == 0 and #list >= 11, #list .. " Stepper" .. (#bad > 0 and (": " .. table.concat(bad, "; ")) or ""),
            "alle Stepper (11 im Code), Grenzen halten, Text = format(Wert)"
    end)
end

IMPL.T33 = function()
    return WithCenter(function()
        LP.Center:Select("comfort")
        local n = 0
        for _, l in ipairs(LP.LANGUAGES) do if LP:CanDisplay(l.code) then n = n + 1 end end
        local btn = 0
        for _, e in ipairs(LP.Center.langButtons or {}) do if e.button:IsShown() then btn = btn + 1 end end
        return btn == n + 1, "Knöpfe " .. S(btn) .. ", anzeigbare Sprachen " .. n, "1 + anzeigbare Sprachen"
    end)
end

IMPL.T34 = function()
    return WithCenter(function()
        LP.Center:Select("data")
        local bad = {}
        local B = LP.Backup
        -- 3.12.93 (Ingametest 3.12.91: T34 914 ms in einem Bild; Nachbau Laptop-Daten 342 ms, davon 79 % „Daten sichern“ mit den
        -- ECHTEN Daten, 3 MB): „Daten sichern“ mit kleinen Testdaten (wie T76); jeder Knopf als freigegebene Rechnung, danach eine
        -- sichere Stelle
        local function SmallExport()
            local keep, db = {}, LP.db
            for _, k in ipairs({ "qdb", "vendors", "taxi", "caves", "graph" }) do keep[k] = db[k] end
            return Guard(function()
                db.qdb, db.vendors, db.taxi, db.caves = { [999701] = { n = "LPTest", l = 3 } }, {}, {}, {}
                db.graph = { nodes = {}, edges = {} }
                B:ShowExport()
            end, function() for k, v in pairs(keep) do db[k] = v end end)
        end
        for _, fn in ipairs({ function() LP.QuestDB:Reconnect() end, function() LP.Planner:Diagnose() end,
                              function() LP.Protocol:Show() end, function() LP.SelfTest:Show(false) end,
                              SmallExport, function() B:ShowImport() end }) do
            local ok, err = PCallY(Coop, fn)
            if not ok then bad[#bad + 1] = tostring(err):sub(1, 80) end
            Hide("LevelPilotBackupFrame")
            TR.Safe("T34")
        end
        local jb = LP.Center.journeyButtons or {}
        local vis = 0
        for _, b in ipairs(jb) do if b:IsShown() then vis = vis + 1 end end
        local want = LP:IsDev() and #jb or 0
        return #bad == 0 and #jb == 3 and vis == want, string.format("Fehler %d, Reiseknöpfe %d sichtbar von %d", #bad, vis, #jb),
            "kein Fehler, 3 Reiseknöpfe nur im Testmodus"
    end)
end

IMPL.T36 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local saved = Gp.members.LPTester
    return Guard(function()
        Gp:OnMessage("S\t5\t10\tGOTO\t0\ttext", who)
        Gp:Refresh()
        local st = Gp:Status(Gp.members.LPTester or {})
        local shared = Gp:SharedQuests()
        local panel = _G.LevelPilotGroupPanel
        local inGroup = IsInGroup and IsInGroup() or false
        local hidden = inGroup or not panel or not panel:IsShown()
        return hidden and (shared == nil or type(shared) == "table"), "Status " .. S(st) .. ", Panel ohne Gruppe versteckt " .. S(hidden), "kein Fehler, versteckt"
    end, function() Gp.members.LPTester = saved pcall(Gp.Refresh, Gp) end)
end

IMPL.T37 = function()
    local Ac = LP.Actions
    local was = LP.db.showActionBar
    return Guard(function()
        LP.db.showActionBar = false Ac:Update()
        LP.db.showActionBar = true Ac:Update()
        local m = Ac.MacroText({ "Kobold", "Wolf" })
        local long = {}
        for i = 1, 30 do long[i] = "Sehr langer Name eines Gegners Nummer " .. i end
        local m2 = Ac.MacroText(long)
        local b1 = _G["BINDING_NAME_CLICK LevelPilotTargetButton:LeftButton"]
        local b2 = _G["BINDING_NAME_CLICK LevelPilotItemButton:LeftButton"]
        local ok = m:sub(1, 12) == "/cleartarget" and m:find("/targetexact Kobold", 1, true) ~= nil and #m2 <= 255 and b1 ~= nil and b2 ~= nil
        return ok, string.format("Makro %d Zeichen, lang %d Zeichen, Tasten %s/%s", #m, #m2, S(b1 ~= nil), S(b2 ~= nil)),
            "/cleartarget … /targetexact Kobold, <= 255, Tasten gesetzt"
    end, function() LP.db.showActionBar = was pcall(Ac.Update, Ac) end)
end

IMPL.T45 = function()
    local P = LP.Planner
    local d = _G.LevelPilotData
    if type(d) ~= "table" or type(d.Q) ~= "table" then return NA, "kein Datenpaket" end
    local real = LP.char.mode
    local speed0 = LP.db.speedLevel
    return Guard(function()
        local bad = {}
        -- 3.12.93 (Ingametest 3.12.91: T45 102 ms in einem Bild): Modus/Stufe sind echte Einstellungen (kein Ersatz) – Neuplanungen
        -- als freigegebene Rechnung, dazwischen sichere Stellen
        for _, lv in ipairs({ 1, 2, 3 }) do
            LP.db.speedLevel = lv
            Coop(P.SetMode, P, "speed")
            local ok, err = PCallY(Coop, P.Replan, P, true)
            if not ok then bad[#bad + 1] = lv .. ": " .. tostring(err):sub(1, 60) end
            TR.Safe("T45")
        end
        LP.db.speedLevel = 2
        Coop(P.Replan, P, true)
        TR.Safe("T45")
        local escort, protectedSkipped = nil, nil
        for id in pairs(P.speedSkip) do
            local q = d.Q[id]
            if type(q) == "table" and q.tg == 84 then escort = id end
            if P:IsProtected(id) then protectedSkipped = id end
        end
        if #bad > 0 then return false, table.concat(bad, "; "), "kein Fehler" end
        if not escort then
            if protectedSkipped then return false, "Klassenquest übersprungen: " .. S(protectedSkipped), "Klassenquest nein" end
            return NA, "keine Eskortenquest im Bereich (Stufen 1–3 ohne Fehler, keine Klassenquest übersprungen)"
        end
        return protectedSkipped == nil, "Eskorte " .. escort .. " übersprungen, Klassenquest übersprungen: " .. S(protectedSkipped), "Eskorte ja, Klassenquest nein"
    end, function() LP.db.speedLevel = speed0 PCallY(Coop, P.SetMode, P, real) end, true)
end

IMPL.T46 = function()
    local P = LP.Planner
    -- 3.12.93: Übersicht als freigegebene Rechnung, sichere Stellen zwischen den Schritten (Nachbau Laptop-Daten: 33 ms in einem Bild)
    local ov = Coop(P.DungeonOverview, P)
    local n = type(ov) == "table" and #ov or 0
    TR.Safe("T46")
    for _, d in ipairs(LP.Dungeons or {}) do P:DungeonUsable(d.area or d.id or d[1]) break end
    P:PlanInstance(LP:PlayerLevel() or 1)
    TR.Safe("T46")
    local rows = WithCenter(function()
        LP.Center:Select("dungeons")
        return FindText(_G.LevelPilotCenter, L["Dungeons"]) or n == 0
    end)
    return type(ov) == "table" and rows and true or false, n .. " Dungeons in der Übersicht", "Liste, Reiter zeigt Zeilen"
end

IMPL.T48 = function()
    local E = LP.Engine
    local id = 999301
    local ign = LP.char.ignored
    local saved = ign[id]
    ign[id] = true
    return Guard(function()
        local want = E:WantQuest(id, "LPTest")
        E:CheckSteps()
        local dg = E:InDungeon()
        local inInst = IsInInstance and select(1, IsInInstance())
        E:UpdateInstance()
        return want == false and (dg == false or (inInst and true or false)), "WantQuest " .. S(want) .. ", Dungeon " .. S(dg), "false, false"
    end, function() ign[id] = saved end)
end

IMPL.T49 = function()
    local id = 999302
    local mark = ActMark()
    local choices = 0
    local selActive = {}
    local gossip = {
        GetActiveQuests = function() return { { title = "Fertig", questID = 999303, isComplete = true } } end,
        GetAvailableQuests = function() return { { title = "Neu", questID = id } } end,
        SelectActiveQuest = function(q) selActive[#selActive + 1] = q end,
        SelectAvailableQuest = function() end,
    }
    local fake = {
        GetQuestID = function() return id end, GetTitleText = function() return "LPTest" end,
        IsQuestCompletable = function() return true end, GetNumQuestChoices = function() return choices end,
        C_GossipInfo = gossip, IsShiftKeyDown = function() return false end,
    }
    local list = {}
    for _, ev in ipairs({ "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "GOSSIP_SHOW", "QUEST_GREETING" }) do
        for _, fn in ipairs(HandlerList(ev)) do list[#list + 1] = fn end
    end
    list[#list + 1] = LP.Engine.HandleGossip
    list[#list + 1] = LP.Engine.HandleGreeting
    local origWant = LP.Engine.WantQuest
    local ign = LP.char.ignored
    local savedIgn = ign[id]
    return Guard(function()
        LP.Engine.WantQuest = function(_, qid) return qid == id and not ign[id] end
        local r = {}
        WithEnv(list, fake, function()
            WithSetting({ autoAccept = true, autoTurnin = true }, function()
                local m = ActMark()
                CallHandlers("QUEST_DETAIL")
                r.accept = ActSince(m, "AcceptQuest")
                m = ActMark()
                WithSetting({ autoAccept = false }, function() CallHandlers("QUEST_DETAIL") end)
                r.acceptOff = ActSince(m, "AcceptQuest")
                for _, c in ipairs({ 0, 1, 2 }) do
                    choices = c
                    m = ActMark()
                    CallHandlers("QUEST_COMPLETE")
                    r["c" .. c] = ActSince(m, "GetQuestReward")
                end
                m = ActMark()
                CallHandlers("GOSSIP_SHOW")
                local first = LP.Act.log[m + 1]
                r.gossip = first and first.name or "-"
                ign[id] = true
                m = ActMark()
                CallHandlers("QUEST_DETAIL")
                r.ignored = ActSince(m, "AcceptQuest")
            end)
        end)
        local ok = r.accept == 1 and r.acceptOff == 0 and r.c0 == 1 and r.c1 == 1 and r.c2 == 0 and r.gossip == "SelectActiveQuest" and r.ignored == 0
        return ok, string.format("Annehmen %d/%d, Belohnung 0:%d 1:%d 2:%d, Gossip zuerst %s, ignoriert %d", r.accept, r.acceptOff,
            r.c0, r.c1, r.c2, r.gossip, r.ignored), "1/0, 1 1 0, SelectActiveQuest, 0"
    end, function() LP.Engine.WantQuest = origWant ign[id] = savedIgn end)
end

IMPL.T51 = function()
    local Gr, Geo = LP.Graph, LP.Geo
    local st = Gr:Stats(true)
    local i1, n1, w1 = Geo:ToWorld(1411, 0.52, 0.44)
    local i2, n2, w2 = Geo:ToWorld(1454, 0.45, 0.55)
    if not i1 then return false, "Geo:ToWorld(1411) liefert nichts", "Weltkoordinaten" end
    -- 3.12.93 (Ingametest 3.12.91: T51 122 ms in einem Bild): Wegsuche als freigegebene Rechnung, sichere Stellen dazwischen
    TR.Safe("T51")
    local path = i2 and Coop(Gr.Path, Gr, i1, n1, w1, 1411, i2, n2, w2, 1454)
    TR.Safe("T51")
    local near = Gr:Near(i1, n1, w1, 2000, 1411)
    local nearest = Gr:Nearest(i1, n1, w1, 4000, 1411)
    local s0 = st.nodes or st.count or 0
    local id1 = Gr:AddNode(i1, n1 + 37, w1 + 41, 1411)
    local id2 = Gr:AddNode(i1, n1 + 77, w1 + 81, 1411)
    local added = Gr:AddEdge(id1, id2, "s")
    TR.Safe("T51")
    local st2 = Gr:Stats(true)
    -- Startwege: so viele, wie die Startdatenbank enthält (Data/Seed.lua, zurzeit leer – die Wege kommen aus dem Wegenetz)
    local seedN = #((LP.Seed and LP.Seed.paths) or {})
    local seedOk = (seedN == 0 and (st.seedEdges or 0) == 0) or (st.seedEdges or 0) > 0
    local st2n = st2.nodes or st2.count or 0
    local ok = seedOk and type(path) == "table" and type(near) == "table" and nearest ~= nil and id1 and id2 and added and st2n >= s0
    return ok and true or false, string.format("Startwege %s (Startdatenbank %d), Weg %s Punkte, Knoten nah %d, neu %s/%s", S(st.seedEdges), seedN,
        S(type(path) == "table" and #path), type(near) == "table" and #near or 0, S(id1), S(id2)), "Startwege > 0, Weg, Knoten"
end

IMPL.T52 = function()
    local T = LP.Terrain
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket" end
    local a = T:Available(1411)
    _G.LevelPilotData = nil
    local b = Guard(function() return T:Available(1411) end, function() _G.LevelPilotData = d end)
    local i, n, w = LP.Geo:ToWorld(1411, 0.4, 0.4)
    local i2, n2, w2 = LP.Geo:ToWorld(1411, 0.6, 0.6)
    local seg = T:Segment(1411, { i, n, w }, { i2, n2, w2 })
    local ref = T:Refine({ { i, n, w, 1411 }, { i2, n2, w2, 1411 } })
    T:Unknown(1411, { i, n, w }, { i2, n2, w2 })
    T:Clear()
    LP.Graph:ClearTerrainCache()
    return a == true and b == false and type(ref) == "table", "mit Paket " .. S(a) .. ", ohne " .. S(b) .. ", Strecke " .. S(seg ~= nil),
        "true, false, Punkte"
end

IMPL.T53 = function()
    local Cv = LP.Caves
    local a, b, c = Cv:Count()
    local i, n, w = LP.Geo:ToWorld(1411, 0.33, 0.77)
    local isNew = Cv:Store({ i = i, en = n, ew = w, cn = n + 30, cw = w + 30, r = 60 })
    Cv:Rebuild()
    local a2, b2, c2 = Cv:Count()
    Cv:At(i, n + 30, w + 30)
    Cv:Same({ inst = i, cn = n, cw = w, r = 60 }, { inst = i, cn = n + 5, cw = w, r = 60 })
    Cv:All() Cv:Rebuild() Cv:Tick()
    return type(a) == "number" and type(b) == "number" and type(c) == "number" and isNew and b2 == b + 1,
        string.format("%s/%s/%s -> %s/%s/%s", S(a), S(b), S(c), S(a2), S(b2), S(c2)), "3 Zahlen, +1"
end

IMPL.T54 = function()
    local Dg, Geo = LP.Danger, LP.Geo
    local L0 = UnitLevel("player") or 1
    Dg:Ready()
    local id, npc = PackNpcWithLevel()
    if npc then Dg:MobLevel(npc, id) end
    local i, n, w = Geo:ToWorld(1411, 0.5, 0.5)
    local i2, n2, w2 = Geo:ToWorld(1411, 0.4, 0.3)
    Dg:At(i, n, w) Dg:AtMap(1411, 0.5, 0.5) Dg:Route(i, n, w, n2, w2) Dg:Segment(i, n, w, n2, w2)
    Dg:OK(L0, L0) Dg:Limit(L0)
    local path = { { i, n, w, 1411 }, { i2, n2, w2, 1411 } }
    Dg:PathDanger(path)
    Dg:GrindSpot(i, n, w, L0, 300)
    local grey = L0 - LP.Planner:GreyLevel(L0)
    local minLevel = math.max(1, L0 - 3)
    local kills, sum = Dg:WayKills(path, L0, grey, 120, minLevel)
    local avg = kills > 0 and sum / kills or nil
    local ok = type(kills) == "number" and (kills == 0 or (avg >= minLevel and avg <= L0 + 2))
    return ok, string.format("Weg-Kills %d, Mittel %s", kills, avg and string.format("%.1f", avg) or "–"), "Mittel zwischen " .. minLevel .. " und " .. (L0 + 2)
end

IMPL.T58 = function()
    local R, API = LP.Recorder, LP.API
    local id = 999401
    local saved = LP.db.qdb[id]
    return Guard(function()
        local e = R:Entry(id, true)
        local own = LP.db.qdb[id] == e and e.net == nil
        local a1, a2 = API.AcceptedArgs(1234, nil)
        local b1, b2 = API.AcceptedArgs(3, 1234)
        R:ScanProgress() R:FlushTrail(true) R:SamplePath()
        local n0 = Count(LP.db.vendors)
        WithEnv({ R.RecordService }, { UnitName = function() return nil end }, function() R:RecordService("merchant") end)
        local none = Count(LP.db.vendors) == n0
        local ok = own and a2 == 1234 and a1 == API.LogIndexForQuest(1234) and b1 == 3 and b2 == 1234 and none
        return ok, string.format("Eintrag %s, (1234,nil)->(%s,%s), (3,1234)->(%s,%s), ohne NPC %s", S(own), S(a1), S(a2), S(b1), S(b2),
            none and "nichts" or "angelegt"), "eigener Eintrag, (LogIndex,1234), (3,1234), nichts"
    end, function() LP.db.qdb[id] = saved end)
end

-- leere Sandbox-Questdatenbank
local function WithQdb(tbl, body)
    local saved = LP.db.qdb
    LP.db.qdb = tbl
    LP.QuestDB:Invalidate()
    return Guard(body, function() LP.db.qdb = saved LP.QuestDB:Invalidate() end)
end

IMPL.T59 = function()
    local Comm = LP.Comm
    local sender = "LPTest-Realm"
    local id = 299501
    local i, n, w = LP.Geo:ToWorld(1411, 0.5, 0.5)
    local test = { [id] = { n = "LPTestquest", l = 12, f = "H", s = { i, n, w }, o = { [1] = { { i, n + 20, w + 20 } } } } }
    local msgs = WithQdb(test, function() return Comm:EncodeQuest(id) end) or {}
    local bad = {}
    -- 3.12.93 (Nachbau Allianz: 56 ms in einem Bild): empfangene Testquests lösen sonst über LP:Throttle eine Neuplanung am Stück mit
    -- den Ersatz-Questdaten aus – hier aus (NoReplan)
    local res = NoReplan(function() return WithQdb({}, function()
        for _, m in ipairs(msgs) do local ok, err = pcall(Comm.Receive, Comm, m, sender) if not ok then bad[#bad + 1] = err end end
        local r = LP.db.qdb[id]
        local got = r and r.net == true and r.n == "LPTestquest" and r.l == 12 and r.f == "H" and r.o ~= nil
        -- eigener Eintrag: nur Bestätigung
        LP.db.qdb[id + 1] = { n = "Eigen", l = 5, f = "H", by = 0 }
        local enc = WithQdb({ [id + 1] = { n = "Eigen", l = 7, f = "A" } }, function() return Comm:EncodeQuest(id + 1) end)
        LP.db.qdb[id + 1] = { n = "Eigen", l = 5, f = "H", by = 0 }
        for _, m in ipairs(enc or {}) do pcall(Comm.Receive, Comm, m, sender) end
        local o = LP.db.qdb[id + 1]
        local ownOk = o.by == 1 and o.l == 5 and o.f == "H" and o.net == nil
        -- ungültige Quests
        local n0 = Count(LP.db.qdb)
        for _, m in ipairs({ "Q\t299503\t12\tX\t\t\tName\t0", "Q\t0\t12\tH\t\t\tName\t0", "Q\t299504\t99\tH\t\t\tName\t0" }) do
            local ok, err = pcall(Comm.Receive, Comm, m, sender) if not ok then bad[#bad + 1] = err end
        end
        local invalidOk = Count(LP.db.qdb) == n0
        return { got = got, own = ownOk, invalid = invalidOk }
    end) end)
    -- jede Art gültig und kaputt (Wirkung landet in der Sandbox)
    local item
    for k in pairs((_G.LevelPilotData and _G.LevelPilotData.I) or {}) do item = k break end
    local mob, npc = PackNpcWithLevel()
    local kinds = {
        { "H\t3.12.6", "H" },
        { "Z\t1411", "Z\tx" },
        { "E\t1411\t12\t" .. id, "E\tx\ty" },
        { "C\t" .. (i or 0) .. "\t" .. math.floor(n or 0) .. "\t" .. math.floor(w or 0) .. "\t1411\t" .. math.floor((n or 0) + 30) .. "\t" .. math.floor((w or 0) + 30) .. "\t60", "C\t1\t2" },
        { item and ("D\t" .. item .. "\t10\t5\t2") or "D\t1\t10\t5", "D\tx\t1" },
        { mob and ("M\t" .. mob .. "\t" .. npc.lo .. "\t" .. (npc.lo + 1)) or "M\t1\t1\t2", "M\t1\t70\t1" },
        { "F\t3\t3000\t90", "F\t0" },
        { "P\t" .. (i or 0) .. "\t" .. math.floor(n or 0) .. "," .. math.floor(w or 0) .. ",1411;" .. math.floor((n or 0) + 10) .. "," .. math.floor((w or 0) + 10) .. ",1411\t1", "P\t0\tzz" },
    }
    local leak = 0
    WithQdb({}, function()
        for _, k in ipairs(kinds) do
            local ok1, e1 = pcall(Comm.Receive, Comm, k[1], sender)
            local q0 = Count(LP.db.qdb)
            local c0 = select(1, LP.Caves:Count())
            local ok2, e2 = pcall(Comm.Receive, Comm, k[2], sender)
            if not ok1 then bad[#bad + 1] = k[1]:sub(1, 1) .. ": " .. tostring(e1):sub(1, 60) end
            if not ok2 then bad[#bad + 1] = k[2]:sub(1, 1) .. " kaputt: " .. tostring(e2):sub(1, 60) end
            if Count(LP.db.qdb) ~= q0 or select(1, LP.Caves:Count()) ~= c0 then leak = leak + 1 end
        end
    end)
    if LP.Social and LP.Social.partners then LP.Social.partners.LPTest = nil end
    local ok = #bad == 0 and res.got and res.own and res.invalid and leak == 0
    return ok and true or false, string.format("Quest übernommen %s, eigene nur bestätigt %s, ungültig verworfen %s, kaputt ohne Eintrag %s%s",
        S(res.got), S(res.own), S(res.invalid), S(leak == 0), #bad > 0 and (" · Fehler: " .. table.concat(bad, "; ")) or ""), "alles true, kein Fehler"
end

IMPL.T61 = function()
    local Comm = LP.Comm
    local mark = ActMark()
    local snap = Comm:QueueSnapshot()
    return Guard(function()
        Comm:Queue("H\tLPTest", "PARTY")
        Comm:Broadcast({ "H\tLPTest2" }, "lptest")
        for _ = 1, 3 do if Comm.SendNext then Comm:SendNext() end end
        Comm:Hello()
        Comm:Rejoin()
        local st = Comm:Stats()
        local sends, prefixOk = 0, true
        for i = mark + 1, #LP.Act.log do
            local e = LP.Act.log[i]
            if e.name == "SendAddonMessage" then sends = sends + 1 if e.a1 ~= "LvPilot2" and e.a1 ~= "LvPilotG" then prefixOk = false end end
        end
        return type(st) == "table" and st.sent ~= nil and st.recv ~= nil and prefixOk,
            string.format("mitgeschrieben %d, Präfix %s, Stats sent/recv %s/%s", sends, prefixOk and "LvPilot2" or "falsch", S(st.sent), S(st.recv)),
            "nur mitgeschrieben, Präfix LvPilot2, Stats"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T62 = function()
    local Comm = LP.Comm
    local mark = ActMark()
    local snap = Comm:QueueSnapshot()
    return Guard(function()
        Comm:RequestZone(1411, true)
        Comm:ReplyZone("LPTest", 1411)
        Comm:OnZoneRequest("LPTest", 1411)
        for _ = 1, 5 do if Comm.SendNext then Comm:SendNext() end end
        local n = ActSince(mark)
        return n >= 1, "mitgeschrieben " .. n, ">= 1"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T64 = function()
    local So = LP.Social
    local mark = ActMark()
    local saved = So.partners and So.partners.LPTester
    return Guard(function()
        local list = So:ShareList()
        local step = { t = "COMPLETE", id = 999601, elite = true, q = "LPTest", key = "LPTestElite" }
        local text = So:GroupText(step)
        local line = So:OpenGroupChat(step)
        local r = {}
        WithSetting({ findPartners = true }, function()
            So:OnMessage({ "E", "1411", "12", "999601" }, "LPTester-Test")
            r.on = So.partners.LPTester ~= nil
            So:Matches()
            So.partners.LPTester = nil
            So:Announce()
        end)
        WithSetting({ findPartners = false }, function()
            So:OnMessage({ "E", "1411", "12", "999601" }, "LPTester-Test")
            r.off = So.partners.LPTester == nil
        end)
        local real = 0
        local ok = type(list) == "table" and (text == nil or text:find("^LF[GM]") ~= nil) and r.on and r.off
        return ok and true or false, string.format("Teilen %d, Text %s, Partner an %s, aus ignoriert %s", #list, S(text and text:sub(1, 3)),
            S(r.on), S(r.off)), "Liste, LFG/LFM, an erkannt, aus ignoriert"
    end, function() if So.partners then So.partners.LPTester = saved end end)
end

IMPL.T69 = function()
    local H = LP.Hints
    local up = H:UpcomingClassQuests()
    H:TrainerCost(LP:PlayerLevel() or 1)
    H:RidingTrainer()
    H:LearnTrainerCosts()
    local keys = { "hintClassQuests", "hintClass", "hintTrainer", "hintMount", "hintProfessions" }
    local bad = {}
    for _, k in ipairs(keys) do
        for _, v in ipairs({ true, false }) do
            local ok, err = pcall(WithSetting, { [k] = v }, function() LP.Advisor:Run() end)
            if not ok then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    LP.Advisor:Run()
    return type(up) == "table" and #bad == 0, #up .. " Klassenquests" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "Liste, kein Fehler"
end

IMPL.T70 = function()
    local Pi = LP.Pins
    Pi:Refresh()
    local ok = type(Pi.areas) == "table" and type(Pi.objects) == "table" and type(Pi.avail) == "table"
    Pi:NearestObject() Pi:CheckAlert() Pi:UpdateMinimap() Pi:UpdateWorldMap()
    local bad = {}
    for _, k in ipairs({ "mapAreas", "mapAvailable", "objPins", "objArrow", "objAlert" }) do
        for _, v in ipairs({ false, true }) do
            local okc, err = pcall(WithSetting, { [k] = v }, function() Pi:Refresh() Pi:UpdateMinimap() Pi:UpdateWorldMap() Pi:CheckAlert() end)
            if not okc then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    Pi:Refresh()
    return ok and #bad == 0, string.format("Gebiete %d, Fundstellen %d, verfügbar %d", Count(Pi.areas), Count(Pi.objects), Count(Pi.avail))
        .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "Tabellen, kein Fehler"
end

IMPL.T71 = function()
    local Pl = LP.Plates
    Pl:ForUnit("target")
    Pl:UpdateAll()
    local o = Pl:OpenObjectives()
    Pl:Refresh()
    local bad = {}
    for _, k in ipairs({ "platesQuest", "platesAll" }) do
        for _, v in ipairs({ false, true }) do
            local ok, err = pcall(WithSetting, { [k] = v }, function() Pl:Refresh() Pl:UpdateAll() end)
            if not ok then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    Pl:Refresh()
    return type(o) == "table" and #bad == 0, #o .. " offene Ziele" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "kein Fehler"
end

IMPL.T72 = function()
    local Tt = LP.Tooltips
    return WithSetting({ tooltips = true }, function()
        local u = Tt:UnitLines("player")
        -- Questgegenstand einer Quest im Log
        local item
        for qid, st in pairs(LP.Planner.inLog or {}) do
            local q = LP.QuestDB:Get(qid)
            for _, o in ipairs(q and q.obj or {}) do if o.item and not st.complete then item = o.item break end end
            if item then break end
        end
        local lines = item and Tt:ItemLines(item)
        Tt:ObjectLines("Testobjekt")
        Tt:IsProtected(6948)
        local tdp = TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and true or false
        local ok = u == nil and (item == nil or type(lines) == "table")
        return ok, string.format("Spieler %s, Questgegenstand %s, Hook über %s", S(u), item and S(lines ~= nil) or "keiner im Log",
            tdp and "TooltipDataProcessor" or "HookScript"), "nil, Zeilen"
    end)
end

IMPL.T76 = function()
    local B = LP.Backup
    local test = {
        qdb = { [999701] = { n = "LPTest1", l = 3, f = "H" }, [999702] = { n = "LPTest2", l = 4, f = "A" } },
        vendors = { ["LPTest@1411"] = { map = 1411, x = 0.5, y = 0.5, name = "LPTest", vendor = true } },
        taxi = { ["LPTestflug"] = { map = 1411, x = 0.4, y = 0.4 } },
        caves = {}, graph = { nodes = {}, edges = {} },
    }
    local savedF = {}
    for k in pairs(test) do savedF[k] = LP.db[k] end
    local okI, msg, export, ok2, msg2, ok3, sumOk, okShow
    -- 3.12.93 (Ingametest 3.12.91: T76 603 ms in einem Bild; Nachbau Laptop-Daten 456 ms: 82 % „Daten sichern“ mit den ECHTEN Daten
    -- (3 MB), 18 % Neuplanung mit Testdaten nach dem Import): „Daten sichern“ zeigt jetzt die Testdaten; Neuplanung währenddessen aus
    NoReplan(function() Guard(function()
        for k, v in pairs(test) do LP.db[k] = v end
        export = B:Export()
        okShow = pcall(B.ShowExport, B)
        Hide("LevelPilotBackupFrame")
        for _, k in ipairs({ "qdb", "vendors", "taxi", "caves" }) do LP.db[k] = {} end
        okI, msg = B:Import(export)
        sumOk = Count(LP.db.qdb) == 2 and Count(LP.db.vendors) == 1 and Count(LP.db.taxi) == 1
        ok2, msg2 = B:Import("kaputt")
        local bad = export:gsub("^(%w+):(%x)", function(f, c) return f .. ":" .. (c == "0" and "1" or "0") end)
        ok3 = B:Import(bad)
    end, function() for k, v in pairs(savedF) do LP.db[k] = v end LP.QuestDB:Invalidate() LP.QuestDB:InvalidateServices() end) end)
    -- SaveCopy / CheckOnLoad mit Test-Tabellen (die echten bleiben unberührt)
    local fakeDB = { qdb = { [1] = { n = "a" } }, vendors = {}, taxi = {}, caves = {}, calib = {}, graph = { nodes = {} } }
    local bigBackup = { t = 1, count = 1000000, data = {} }
    local fakeChar = { backup = bigBackup }
    WithAccEnv({ B.SaveCopy }, { LevelPilotDB = fakeDB, LevelPilotCharDB = fakeChar }, function() B:SaveCopy() end)
    local kept = fakeChar.backup == bigBackup
    local db2 = { qdb = {}, vendors = {}, taxi = {}, caves = {}, calib = {}, graph = { nodes = {} } }
    local char2 = { backup = { t = 1, count = 3, data = { qdb = { [1] = { n = "a" }, [2] = { n = "b" }, [3] = { n = "c" } }, vendors = {}, taxi = {} } } }
    local restoredBefore = B.restored
    WithAccEnv({ B.CheckOnLoad }, { LevelPilotDB = db2, LevelPilotCharDB = char2 }, function() B:CheckOnLoad() end)
    B.restored = restoredBefore
    local healed = Count(db2.qdb) == 3
    local bad = {}
    if not okShow then bad[#bad + 1] = "ShowExport" end
    for _, fn in ipairs({ function() B:ShowImport() end, function() B:ShowText("LPTest", "LPTest", "LPTest") end,
                          function() return B:Info() end }) do
        local ok, err = pcall(fn)
        if not ok then bad[#bad + 1] = tostring(err):sub(1, 60) end
        Hide("LevelPilotBackupFrame")
    end
    local nothing = type(msg) == "string" and msg:find(L["Ergänzt: %d Quests, %d Händler, %d Flugpunkte, %d Wegstücke. Nichts wurde gelöscht."]
        :match("([^.]+)%.$") or "Nichts wurde gelöscht", 1, true) ~= nil
    local ok = okI and sumOk and nothing and ok2 == false and msg2 == L["Das ist kein LevelPilot-Sicherungstext."] and ok3 == false and kept and healed and #bad == 0
    return ok and true or false, string.format("Import %s (Anzahlen %s), kaputt %s, Prüfsumme %s, Kopie behalten %s, wiederhergestellt %s%s",
        S(okI), S(sumOk), S(ok2), S(ok3), S(kept), S(healed), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""),
        "true (gleich), false, false, true, true"
end

IMPL.T78 = function()
    local t = L("%d Module gestartet", 3)
    local client = LP:ClientLanguage()
    local loc = GetLocale and GetLocale() or "enUS"
    local map = { deDE = "de", enUS = "en", enGB = "en", frFR = "fr", esES = "es", esMX = "mx", ptBR = "pt", itIT = "it", ruRU = "ru",
                  koKR = "ko", zhCN = "cn", zhTW = "tw" }
    LP:CanDisplay(client)
    local path = LP:FontFor(client)
    LP:FontWorks(path)
    local fixed = LP:FixText("LPTest")
    local fs = LP.UI:Text(UIParent, 11)
    LP:RegisterText(fs, "LPTest")
    LP:ApplyFont(fs, 11)
    fs:Hide()
    local ok = t:find("3", 1, true) ~= nil and (map[loc] == nil or map[loc] == client)
    return ok, "Text " .. t .. ", Client " .. S(client) .. " (" .. S(loc) .. ")", "enthält 3, Sprache passt"
end

IMPL.T80 = function()
    local skip = { ADDON_LOADED = true, PLAYER_LOGIN = true, CHAT_MSG_ADDON = true, COMBAT_LOG_EVENT_UNFILTERED = true,
                   PLAYER_LOGOUT = true }
    local args = { UNIT_QUEST_LOG_CHANGED = { "player" }, NAME_PLATE_UNIT_ADDED = { "nameplate1" }, NAME_PLATE_UNIT_REMOVED = { "nameplate1" },
                   PLAYER_ENTERING_WORLD = { false, false }, UNIT_INVENTORY_CHANGED = { "player" }, QUEST_ACCEPTED = { 0 },
                   QUEST_TURNED_IN = { 0, 0, 0 }, CHAT_MSG_LOOT = { "" }, PLAYER_XP_UPDATE = { "player" } }
    local n0 = LP.errorCount
    local onEvent = LP.eventFrame:GetScript("OnEvent")
    local evs = {}
    for ev in pairs(LP.handlers) do if not skip[ev] then evs[#evs + 1] = ev end end
    table.sort(evs)
    local mark = ActMark()
    local list = {}
    -- 3.12.93 (Nachbau: ein Ereignis bis 238 ms in einem Bild): die Handler wie der Verteiler (Core: pcall je Handler, Fehler über
    -- LP:Error), aber als freigegebene Rechnung – unter dem pcall des Verteilers könnte nie abgegeben werden; nach jedem Ereignis eine
    -- sichere Stelle. Den Verteiler selbst prüft der erste Aufruf (ein Ereignis wie bisher über OnEvent).
    local viaFrame = false
    for _, ev in ipairs(evs) do
        local before = LP.errorCount
        if not viaFrame then
            onEvent(LP.eventFrame, ev, unpack(args[ev] or {}))
            viaFrame = true
        else
            local hs = LP.handlers[ev] or {}
            for hi = 1, #hs do
                local ok, err = PCallY(Coop, hs[hi], ev, unpack(args[ev] or {}))
                if not ok then LP:Error(ev, err) end
            end
        end
        if LP.errorCount > before then list[#list + 1] = ev end
        TR.Safe("T80")              -- nach jedem Ereignis (echte Handler, kein Ersatz)
    end
    local real = LP.Act.real
    return LP.errorCount == n0, #evs .. " Ereignisse" .. (#list > 0 and (", Fehler bei: " .. table.concat(list, ",")) or ""), "Fehlerzähler unverändert"
end

IMPL.T82 = function()
    local bad = {}
    for _, n in ipairs({ "nav", "pins" }) do
        local d = LP.drivers and LP.drivers[n]
        local fn = d and d:GetScript("OnUpdate")
        if not fn then bad[#bad + 1] = n .. ": kein Treiber"
        else
            local ok, err = pcall(fn, d, 0.1)
            if not ok then bad[#bad + 1] = n .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    local map = WorldMapFrame and WorldMapFrame:IsShown()
    if map then local ok, err = pcall(LP.Pins.UpdateWorldMap, LP.Pins) if not ok then bad[#bad + 1] = "Weltkarte: " .. tostring(err) end end
    return #bad == 0, #bad == 0 and ("Navigation und Pins" .. (map and ", Weltkarte offen" or ", Weltkarte zu (Hooks nicht geprüft)")) or table.concat(bad, "; "),
        "kein Fehler"
end

------------------------------------------------------------------------
-- Virtuelle Reisen (vorab im Ablauf gestartet – Warten geht nur ausserhalb einer Prüfung, siehe TR:Journeys)
------------------------------------------------------------------------
local JOURNEY_SKIP = "virtuelle Reise nicht gelaufen (nur im Testmodus, nicht auf Level 60)"
local LONG_ONLY = "nur mit /lp testroutine reise (Reise 1–60 in beiden Modi, dauert einige Minuten)"
local function J(k) return TR.journey and TR.journey[k] end

IMPL.T83 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    local rep = tostring(r.report or "")
    local sbLine = L["Sandbox: echte Daten unverändert (OK)"]
    local ok = (s.steps or 0) > 0 and type(s.sandboxDiff) == "table" and #s.sandboxDiff == 0 and rep:find(sbLine, 1, true) ~= nil
        and r.after.char and not r.after.taxiMeta and r.after.quests
    return ok and true or false, string.format("%d Schritte, Sandbox %s, danach LP.char echt %s, Flugpunkte ohne Überlagerung %s, API.Quests Original %s",
        s.steps or 0, (type(s.sandboxDiff) == "table" and #s.sandboxDiff == 0) and "OK" or "FEHLER", S(r.after.char), S(not r.after.taxiMeta),
        S(r.after.quests)), "Schritte > 0, alles zurück"
end

IMPL.T35 = function()
    local w = J("window")
    if not w then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local ok = w.pause == L["Weiter"] and w.resume == L["Pause"] and w.watch == L["Schnell"] and w.fast == L["Zuschauen"]
        and w.afterStop and w.report
    return ok and true or false, string.format("Pause→%s→%s, Zuschauen→%s→%s, nach Stopp nur Bericht/Schliessen %s, Bericht %s",
        S(w.pause), S(w.resume), S(w.watch), S(w.fast), S(w.afterStop), S(w.report)), "Beschriftungen wechseln, danach nur Bericht"
end

IMPL.T85 = function()
    local a = J("abort")
    if not a then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local ok = a.realChar and a.realTaxi and a.restored
    return ok and true or false, string.format("während: echter Charakter %s, Flugpunkte ohne Überlagerung %s · nach Abbruch zurück %s%s",
        S(a.realChar), S(a.realTaxi), S(a.restored), a.left and (" (umgeleitet: " .. a.left .. ")") or ""), "true, true, true"
end

IMPL.T155 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    local per = (s.planMs or 0) / math.max(1, s.planN or 1)
    -- 3.12.97: Median, Höchstwert, Planungen mit Speicherfall (Bereinigung) und ihr Anteil an der Zeit, Speicher je Planung
    local list = s.planList or {}
    local ms, gcN, gcMs, kb = {}, 0, 0, 0
    for i, e in ipairs(list) do
        ms[i] = e.ms
        if e.kb < -1024 then gcN, gcMs = gcN + 1, gcMs + e.ms else kb = kb + e.kb end
    end
    table.sort(ms)
    local med = #ms > 0 and (#ms % 2 == 1 and ms[(#ms + 1) / 2] or (ms[#ms / 2] + ms[#ms / 2 + 1]) / 2) or 0
    local extra = #ms > 0 and string.format(" · Median %.2f ms, längste %.2f ms · mit Speicherbereinigung %d Planungen (%.0f ms) · ohne: %.0f KB je Planung",
        med, ms[#ms], gcN, gcMs, kb / math.max(1, #list - gcN)) or ""
    -- 3.12.98 (Ingametest 3.12.97: längste Planung 294,56 ms – "Ausreisser belegen"): die drei längsten mit Nummer, Stufe, Zone, KB
    local top = {}
    for _, e in ipairs(list) do top[#top + 1] = e end
    table.sort(top, function(a, b) return a.ms > b.ms end)
    local tp = {}
    for i = 1, math.min(3, #top) do
        local e = top[i]
        tp[#tp + 1] = ("#%s %.1f ms (Stufe %s, Zone %s, %+.0f KB)"):format(tostring(e.n or "?"), e.ms, tostring(e.lvl or "?"),
            tostring(e.map or "?"), e.kb or 0)
    end
    if #tp > 0 then extra = extra .. " · längste: " .. table.concat(tp, ", ") end
    return per < 16, string.format("%.2f ms je Planung (%d)%s", per, s.planN or 0, extra), "< 16 ms"
end

IMPL.T174 = function()
    local r = J("speed")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    -- ohne Erholt-Bonus (der verdoppelt Monster-EP und gehört nicht zur Rechnung mit dem Monsterlevel)
    local k, xp = s.wayKills or 0, (s.wayXP or 0) - (s.wayBonus or 0)
    local L0 = s.startLevel or (UnitLevel("player") or 1)
    local Lmax = s.level or (L0 + 2)
    local cap = LP.Planner:KillXP(Lmax, Lmax)
    -- 3.13.8 LP-T1: ohne Weg-Kills ist die Rechnung "EP je Kill" nicht prüfbar – mit belegtem Grund statt FEHLER. FEHLER bleibt, wenn
    -- kein Weg geprüft wurde (Speedrun-Zweig nie gelaufen) oder Monster im Band da waren und trotzdem keiner zählt (Fehler der Rechnung).
    if k == 0 then
        local checks, cand = s.wayChecks or 0, s.wayCand or 0
        if checks == 0 then return false, string.format("keine Weg-Kills im Speedrun (Level %d–%d): kein Weg geprüft", L0, Lmax), "Wege geprüft > 0" end
        if cand == 0 then
            return NA, string.format("keine Weg-Kills (Level %d–%d): %d Wege geprüft, kein Monster im Stufenband am Weg – EP je Kill nicht prüfbar", L0, Lmax, checks)
        end
        if (s.wayShort or 0) > 0 and not s.wayMinLv then
            return NA, string.format("keine Weg-Kills (Level %d–%d): %d Wege, %d Monster im Band, aber %d Weg(e) kürzer als 120 Yards (höchstens 1 Kill je 120 Yards) – nicht prüfbar",
                L0, Lmax, checks, cand, s.wayShort)
        end
        if s.wayMinLv then
            return NA, string.format("keine Weg-Kills (Level %d–%d): %d Wege, %d Monster im Band, alle unter der Untergrenze Stufe %d (Questen bringt mehr) – nicht prüfbar",
                L0, Lmax, checks, cand, s.wayMinLv)
        end
        return false, string.format("keine Weg-Kills (Level %d–%d) trotz %d Monstern im Band", L0, Lmax, cand), "Weg-Kills > 0"
    end
    local per = xp / k
    return per <= cap, string.format("%d Weg-Kills (Level %d–%d), %.1f EP je Kill ohne Erholt-Bonus (Grenze %.1f)", k, L0, Lmax, per, cap),
        "EP je Kill <= KillXP(Level, Level)"
end

IMPL.T181 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local head = L("Werte: Kills/Min %s · EP je Kill %s · Dungeon-Faktoren %s", "\1", "\1", "\1"):match("^([^\1]*)")
    local found = tostring(LP.Virtual.lastReport or r.report or ""):find(head, 1, true) ~= nil
    return found, "Zeile \"" .. head .. "…\" " .. (found and "vorhanden" or "fehlt"), "vorhanden"
end

local function LongCheck()
    local l = J("long")
    if not l then return false, TR.journey and TR.journey.longWhy or "lange Reise nicht beendet", "Normal und Speedrun" end
    local hn, hs = (l.normal or 0) / 3600, (l.speed or 0) / 3600
    local ok = hs < hn and hn >= 50 and hn <= 400 and hs >= 50 and hs <= 400 and l.mode == l.modeBefore and l.text ~= nil
    -- 3.13.8 LP-T1: Sekunden mit ausgeben (Vergleich mehrerer Läufe auf die Sekunde)
    return ok, tostring(l.text) .. string.format(" (Modus danach %s) [Normal %d s, Speedrun %d s]", S(l.mode), math.floor((l.normal or 0) + 0.5),
        math.floor((l.speed or 0) + 0.5)), "Speedrun < Normal, beide 50–400 h, Modus unverändert"
end
IMPL.T84, IMPL.T180, IMPL.T183 = LongCheck, LongCheck, LongCheck
TR.LONG = { T84 = true, T180 = true, T183 = true }

-- Reisen nacheinander laufen lassen (im Ablauf, ausserhalb jeder Prüfung). wait(cond, sek) gibt die Kontrolle ab.
function TR:Journeys(wait, long)
    local V = LP.Virtual
    self.journey = {}
    if not V or not LP:IsDev() then self.journey.why = JOURNEY_SKIP return end
    local L0 = UnitLevel("player") or 1
    if V.active then self.journey.why = "virtuelle Reise lief schon" return end
    local API, Geo = LP.API, LP.Geo
    local orig = { Quests = API.Quests, Objectives = API.Objectives, IsQuestDone = API.IsQuestDone, GeoPlayer = Geo.Player,
                   HearthReady = API.HearthReady }
    -- 3.13.8 LP-T1 (belegt mit den Wegdaten des Nutzers: zwei Läufe 2857132 / 2857116 s trotz fester Portionen; ohne Abgaben gleich):
    -- Hintergrund-Aufträge (Wegnetz laden, eigene Ketten, Orte …) liefen neben der Reise weiter und wurden nach Uhr fertig – die Reise sah
    -- das Wegnetz je Lauf zu einem anderen Zeitpunkt. Vor jeder Reise darum warten, bis keine anderen Aufträge mehr laufen.
    local function busy()
        local n = LP.Jobs and LP.Jobs.Count() or 0
        local Tk = Takt()
        for _, j in ipairs(Tk and Tk.jobs or {}) do if j ~= self.job and j.state == "laeuft" then n = n + 1 end end
        return n
    end
    local function settle()
        wait(function()
            if LP.Jobs and LP.Jobs.Count() > 0 then pcall(LP.Jobs.Step) end
            return busy() == 0
        end, 120)
        self.journey.busyLeft = busy()
    end
    local function run(opts, during)
        local res = {}
        opts.silent = true
        opts.onDone = function(rep, s) res.report, res.s, res.done = rep, s, true end
        settle()
        V:Start(opts.where or "here", opts)
        if not V.active then return nil end
        if during then pcall(during, res) end
        wait(function() return res.done or not V.active end, opts.maxSec or 240)
        if V.active then V:Stop() end
        wait(function() return res.done end, 3)
        -- nur die geprüften Werte behalten (Speicher, T157)
        local s = res.s or {}
        res.s = { steps = s.steps, sandboxDiff = s.sandboxDiff, planMs = s.planMs, planN = s.planN, planList = s.planList, wayKills = s.wayKills,
                  wayXP = s.wayXP, wayBonus = s.wayBonus, startLevel = s.startLevel, level = s.level,
                  wayChecks = s.wayChecks, wayCand = s.wayCand, wayMinLv = s.wayMinLv, wayShort = s.wayShort, clock = s.clock, xp = s.xp, dist = s.dist }   -- 3.13.8
        res.report = res.report and tostring(res.report):sub(1, 4000)
        res.after = { char = LP.char == LevelPilotCharDB,
                      taxiMeta = type(LP.Acc().taxi) == "table" and getmetatable(LP.Acc().taxi) ~= nil,
                      quests = API.Quests == orig.Quests }
        return res
    end
    if L0 < 60 and not self.abort then
        -- T83/T155/T181: kurze Reise über den Ticker
        self.journey.short = run({ maxLevel = math.min(60, L0 + 2) })
        -- 3.13.8 LP-T1 (T381): dieselbe kurze Reise ein zweites Mal – gleicher Code, gleiche Ausgangslage -> gleiche Zeit
        if not self.abort then self.journey.short2 = run({ maxLevel = math.min(60, L0 + 2) }) end
        -- T174: dasselbe im Speedrun
        -- unter Level 10 etwas länger: am Anfang bringen Wege selten Monster, die sich lohnen
        if not self.abort then self.journey.speed = run({ maxLevel = math.min(60, L0 + (L0 < 10 and 5 or 2)), mode = "speed" }) end
    else
        self.journey.why = L0 >= 60 and "Level 60 – keine Reise ab hier" or self.abort
    end
    -- T35: Fenster der Reise (Knöpfe; Zuschauen öffnet keine Weltkarte)
    if not self.abort and L0 < 60 then
        local w = {}
        local res = run({ maxLevel = math.min(60, L0 + 1), maxSec = 1 }, function()
            V:ShowWindow()
            local win = V.Window and V.Window()
            if not win then return end
            local click = function(b)
                local fn = b:GetScript("OnClick")
                if fn then WithEnv({ fn }, { ToggleWorldMap = false }, function() fn(b, "LeftButton") end) end
            end
            click(win.bPause) w.pause = win.bPause.label:GetText()
            click(win.bPause) w.resume = win.bPause.label:GetText()
            click(win.bWatch) w.watch = win.bWatch.label:GetText()
            click(win.bWatch) w.fast = win.bWatch.label:GetText()
            click(win.bStop)
            w.afterStop = not win.bPause:IsShown() and not win.bWatch:IsShown() and not win.bStop:IsShown()
            local rb = win.bReport
            if rb then click(rb) end
            w.report = _G.LevelPilotBackupFrame and _G.LevelPilotBackupFrame:IsShown() or false
            Hide("LevelPilotBackupFrame")
            win:Hide()
        end)
        if res then self.journey.window = w end
    end
    -- T85: Abbruch mitten in der Reise
    if not self.abort and L0 < 60 then
        local a = {}
        V:Start("here", { silent = true, maxLevel = math.min(60, L0 + 2) })
        if V.active then
            wait(function() return false end, 1)
            a.realChar = V:RealChar() == LevelPilotCharDB
            a.realTaxi = getmetatable(V:RealTaxi() or {}) == nil
            V:Abort()
            local left = {}
            if API.Quests ~= orig.Quests then left[#left + 1] = "API.Quests" end
            if API.Objectives ~= orig.Objectives then left[#left + 1] = "API.Objectives" end
            if API.IsQuestDone ~= orig.IsQuestDone then left[#left + 1] = "API.IsQuestDone" end
            if Geo.Player ~= orig.GeoPlayer then left[#left + 1] = "Geo.Player" end
            if API.HearthReady ~= orig.HearthReady then left[#left + 1] = "API.HearthReady" end
            a.restored = #left == 0 and LP.char == LevelPilotCharDB
            a.left = #left > 0 and table.concat(left, ", ") or nil
            self.journey.abort = a
        end
    end
    -- T84/T180/T183: 1–60 in beiden Modi (nur "/lp testroutine reise")
    if long and not self.abort then
        local l = { modeBefore = LP.char.mode }
        settle()                                                         -- 3.13.8 LP-T1
        local started = V:CompareModes(function(n, s, text) l.normal, l.speed, l.text = n, s, text end, 60)
        if started then
            wait(function() return l.text ~= nil end, 3600)
            if V.active then V:Stop() end
        end
        l.mode = LP.char.mode
        if l.text then self.journey.long = l else self.journey.longWhy = "lange Reise nicht beendet" end
    end
end

------------------------------------------------------------------------
-- E. Daten (3.12.6)
------------------------------------------------------------------------
IMPL.T127 = function()
    local V = LP.Virtual
    local real = { ["LPTestflug"] = { map = 1411 } }
    local overlay = V.MakeOverlay(real)
    overlay.LPTestVirtuell = { map = 1 }
    local isReal = V.RealTaxiOf(overlay) == real
    -- SaveCopy speichert die echte Liste (Test-Tabellen, die echten bleiben unberührt)
    local fakeDB = { qdb = { [1] = { n = "a" } }, vendors = {}, taxi = overlay, caves = {}, calib = {}, graph = { nodes = {} } }
    local fakeChar = {}
    WithAccEnv({ LP.Backup.SaveCopy }, { LevelPilotDB = fakeDB, LevelPilotCharDB = fakeChar }, function() LP.Backup:SaveCopy() end)
    local savedReal = fakeDB.taxi == real
    local copy = fakeChar.backup and fakeChar.backup.data and fakeChar.backup.data.taxi
    local copyReal = type(copy) == "table" and copy.LPTestflug ~= nil and copy.LPTestVirtuell == nil
    return isReal and savedReal and copyReal, string.format("RealTaxiOf echt %s, Konto echt %s, Kopie ohne Reise-Einträge %s",
        S(isReal), S(savedReal), S(copyReal)), "true, true, true"
end

-- Beispiel-DB im Stand vor 3.8/3.10
local OLD_DB = function()
    return {
        qdb = { [999801] = { n = "Alt", l = 5, f = "H", s = { 1, 100, 100 } } },
        speedLevel = 3, calib = { kills = {} },
        protocolLog = { entries = { { k = "zone", msg = "… Das Brachland (1413), Brachland" }, { k = "session", msg = "L1 L5 3" } } },
    }, { mode = "normal" }
end

IMPL.T128 = function()
    -- Calib liest die Messungen immer aus LP.Acc().calib (nicht aus der geladenen Fassung); im echten Spiel
    -- sind dort eigene Messungen -> "gemessen true". Darum ohne eigene Messungen prüfen (3.12.19).
    -- 3.13.1 (Ingametest 3.13.0: Bild "T123–T128" 69 ms): jede der vier Funktionen mit einer frisch geladenen alten Fassung in ihrer
    -- eigenen Hülle, dazwischen eine sichere Stelle (vorher alle vier in einer Hülle am Stück)
    local bad, filled, measured = {}, nil, nil
    TR.Safe("T128")       -- 3.13.3 (Ingametest 3.13.2: Bild "T124–T128" 69,7 ms): T124–T127 nicht mit der ersten Hülle hier zusammen
    local fns = { function() LP.Planner:Replan(true) end, function() LP.Calib:KillXPText() end,
                  function() LP.Protocol:LoadEntries() end, function() LP.Virtual:Report() end }
    for idx, fn in ipairs(fns) do
        local acc, char = OLD_DB()
        WithEmptyCalib(function() return WithLoad(acc, char, function()
            local ok, err = pcall(fn)
            if not ok then bad[#bad + 1] = tostring(err):sub(1, 80) end
            if idx == 1 then filled = acc.speedLevelV2 == true and type(char.levelTimes) == "table" and type(char.fpVisited) == "table" end
            if idx == #fns then measured = LP.Calib:KillXPMeasured() end
            return true
        end) end)
        TR.Safe("T128")
    end
    return #bad == 0 and filled and measured == false, string.format("ergänzt %s, gemessen %s%s", S(filled), S(measured),
        #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "ergänzt, false, kein Fehler"
end

IMPL.T129 = function()
    local acc = {
        qdb = { [123] = "kaputt", [124] = { n = 5, l = "x" } }, graph = 5, taxi = "x", vendors = { [1] = false }, caves = { 1 },
        calib = { killxp = { [-3] = { n = "a" } } }, protocolLog = { entries = { { k = nil, msg = 5 } } }, net = { peers = 7 },
    }
    local char = { ignored = "x", levelTimes = { [5] = "x" }, bind = 3 }
    local bad = {}
    -- 3.12.93 (Nachbau: Reiter „Dungeons“ mit kaltem Quest-Zwischenspeicher bis 120 ms unter den kaputten Daten): die Übersicht
    -- vorher mit den echten Daten als freigegebene Rechnung (füllt den Zwischenspeicher; die kaputten Einträge 123/124 sind keine
    -- Dungeon-Quests und werden unten ausdrücklich geholt)
    PCallY(Coop, LP.Planner.DungeonOverview, LP.Planner)
    TR.Safe("T129")
    -- ebenso die Stufenbänder je Zone (sonst rechnet die Neuplanung unten sie am Stück mit den kaputten Daten)
    if LP.Planner.ZoneBands then PCallY(Coop, LP.Planner.ZoneBands, LP.Planner) TR.Safe("T129") end
    local calls = {
        { "QuestDB:Counts", function() LP.QuestDB:Counts() LP.QuestDB:Get(123) LP.QuestDB:Get(124) end },
        { "Planner:Replan", function() LP.Planner:Replan(true) end },
    }
    -- 3.12.93 (Ingametest 3.12.91: T129 73 ms in einem Bild): Zentrale je Reiter (vorher alle 8 Reiter und "data"/"route" in einem
    -- Aufruf) und jeder Aufruf mit eigenem Laden der kaputten Daten; dazwischen (echte Daten wieder geladen) eine sichere Stelle
    for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do
        calls[#calls + 1] = { "Center " .. k, function()
            local f = _G.LevelPilotCenter
            local was = f and f:IsShown()
            if not (_G.LevelPilotCenter and _G.LevelPilotCenter:IsShown()) then LP.Center:Toggle() end
            local ok, err = pcall(LP.Center.Select, LP.Center, k)
            if _G.LevelPilotCenter and not was then _G.LevelPilotCenter:Hide() end
            if not ok then error(err, 0) end
        end }
    end
    for _, c in ipairs({
            { "Backup", function() LP.Backup:Count(acc) LP.Backup:Export() end },
            { "Protocol", function() LP.Protocol:LoadEntries() end },
            { "Calib", function() LP.Calib:KillXPRatio(-3) LP.Calib:KillXPText() end },
            { "Comm", function() LP.Comm:EncodeQuest(123) LP.Comm:EncodeQuest(124) end },
            { "Virtual", function() LP.Virtual:Fingerprint() end },
            { "Comfort", function() LP.Comfort:LevelTimesText() end },
        }) do calls[#calls + 1] = c end
    for _, c in ipairs(calls) do
        WithLoad(acc, char, function()
            local ok, err = pcall(c[2])
            if not ok then bad[#bad + 1] = c[1] .. ": " .. tostring(err):sub(1, 70) end
        end)
        TR.Safe("T129")
    end
    -- SaveCopy mit denselben Tabellen (ohne die echten zu berühren)
    WithLoad(acc, char, function()
        local okS, errS = pcall(WithAccEnv, { LP.Backup.SaveCopy }, { LevelPilotDB = acc, LevelPilotCharDB = char }, function() LP.Backup:SaveCopy() end)
        if not okS then bad[#bad + 1] = "SaveCopy: " .. tostring(errS):sub(1, 70) end
    end)
    return #bad == 0, #bad == 0 and "alle Aufrufe ohne Fehler" or table.concat(bad, "; "), "kein Lua-Fehler"
end

IMPL.T130 = function()
    local Q = LP.QuestDB
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket installiert" end
    local CP = Q.ConnectPack
    if not CP then return false, "QuestDB.ConnectPack fehlt", "zugänglich" end
    local scheduled
    local function conn(data)
        return WithEnv({ CP }, { _G = { LevelPilotData = data }, C_Timer = { After = function(_, fn) scheduled = fn end } },
            function() return CP() end)
    end
    local r = {}
    return Guard(function()
        WithSetting({ usePack = true }, function()
            local ok1, i1 = conn(nil)
            r.miss = ok1 == false and i1 == L["nicht installiert"]
            local ok2, i2 = conn(setmetatable({ format = 2 }, { __index = d }))
            r.fmt = ok2 == false and i2 == L["unbekanntes Format "] .. "2"
            local warned = Q.packWarned
            Q.packWarned = false
            scheduled = nil
            local ok3 = conn(setmetatable({ version = "1.5.0" }, { __index = d }))
            r.old = ok3 == true and scheduled ~= nil
            scheduled = nil
            conn(setmetatable({ version = "1.5.0" }, { __index = d }))
            r.once = scheduled == nil
            Q.packWarned = warned
        end)
        -- Kurztest-Prüfung (T04) ohne Paket
        _G.LevelPilotData = nil
        local _, b = Guard(function() return IMPL.T04() end, function() _G.LevelPilotData = d end)
        r.short = b == "Datenpaket LevelPilot_Data fehlt"
        -- 3.12.93 (Nachbau PC-Daten: bis 1,3 s in einem Bild – nach dem Wechsel der Questquelle Neuplanung mit kaltem Zwischenspeicher):
        -- zurück zum echten Datenpaket als freigegebene Rechnung (echte Daten, kein Ersatz)
        Coop(Q.Reconnect, Q)
        r.back = Q.pack == true
        local ok = r.miss and r.fmt and r.old and r.once and r.short and r.back
        return ok and true or false, string.format("fehlt %s, Kurztest %s, Format 2 %s, 1.5.0 läuft mit einem Hinweis %s/%s, danach Paket %s",
            S(r.miss), S(r.short), S(r.fmt), S(r.old), S(r.once), S(r.back)), "alles true"
    end, function() _G.LevelPilotData = d PCallY(Coop, Q.Reconnect, Q) end, true)
end
IMPL.T203 = function()
    local Q = LP.QuestDB
    return Q.OlderThan("1.5.0", Q.MIN_PACK) == true and Q.OlderThan("1.6.0", Q.MIN_PACK) == false,
        "Mindestversion " .. S(Q.MIN_PACK), "1.5.0 zu alt, 1.6.0 ok"
end

IMPL.T131 = function()
    local Q = LP.QuestDB
    local CQ = Q.ConnectQuestie
    if not CQ then return false, "QuestDB.ConnectQuestie fehlt", "zugänglich" end
    -- Ersatz nur in der Umgebung der Funktion: ein echtes Questie bleibt unberührt
    local function conn(lib) return WithEnv({ CQ }, { _G = { LibQuestieDB = lib } }, function() return CQ() end) end
    return Guard(function()
        return WithSetting({ useQuestie = true }, function()
            local ok1, i1 = conn({ RequireContract = function() return false, "LPTest" end })
            local ok2, i2 = conn({ RequireContract = function() return true end })
            local a = ok1 == false and tostring(i1):sub(1, #L["Version zu alt ("]) == L["Version zu alt ("]
            local b = ok2 == false and i2 == L["Schnittstelle unvollständig"]
            return a and b, "alt: " .. tostring(i1) .. " · ohne Tabelle: " .. tostring(i2) ..
                (_G.LibQuestieDB and " · echtes Questie geladen (nicht ersetzt)" or ""), "Version zu alt (…) · Schnittstelle unvollständig"
        end)
    end, function() pcall(Q.Reconnect, Q) end)
end

------------------------------------------------------------------------
-- F. Sprachen (3.12.6)
------------------------------------------------------------------------
local function CutLabels()
    local bad = {}
    for b in pairs(LP.UI.buttons or {}) do
        local fs = b.label
        if fs and b:IsShown() and fs.GetStringWidth and b.GetWidth then
            local tw, bw = fs:GetStringWidth() or 0, b:GetWidth() or 0
            if bw > 0 and tw > bw - 2 then bad[#bad + 1] = tostring(fs:GetText()) end
        end
    end
    return bad
end

IMPL.T136 = function()
    local before = LP.db.language
    local bad = {}
    local n = 0
    return Guard(function()
        for _, l in ipairs(LP.LANGUAGES) do
            if LP:CanDisplay(l.code) then
                n = n + 1
                -- 3.12.93 (Ingametest 3.12.91: T136 2193 ms in einem Bild): je Schritt eine sichere Stelle, Umstellen der Sprache
                -- (Neuplanung) als freigegebene Rechnung. Die Sprache ist eine echte Einstellung (kein Ersatz); andere Fenster zeigen
                -- sie für ein paar Bilder mit.
                local ok, err = PCallY(function()
                    Coop(LP.SetLanguage, LP, l.code)
                    TR.Safe("T136")
                    if LP:Language() ~= l.code then error("Sprache " .. LP:Language(), 0) end
                    if not LP.UI:IsShown() then LP.UI:Toggle() LP.UI:Toggle() end
                    TR.Safe("T136")
                    Coop(LP.UI.Refresh, LP.UI)
                    TR.Safe("T136")
                    WithCenter(function() end)
                    TR.Safe("T136")
                    LP.Backup:ShowText("LPTest", "LPTest", "LPTest") Hide("LevelPilotBackupFrame")
                    TR.Safe("T136")
                    LP.Protocol:Show() Hide("LevelPilotBackupFrame")
                    TR.Safe("T136")
                    if LP:IsDev() and LP.Virtual.ShowWindow then LP.Virtual:ShowWindow() Hide("LevelPilotVirtualFrame") end
                    TR.Safe("T136")
                    local cut = CutLabels()
                    if #cut > 0 then error("abgeschnitten: " .. table.concat(cut, ", "):sub(1, 80), 0) end
                end)
                if not ok then bad[#bad + 1] = l.code .. ": " .. tostring(err) end
            end
        end
        return #bad == 0, n .. " Sprachen" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "kein Fehler, nichts abgeschnitten"
    end, function()
        LP.db.language = before
        LP:ResetLanguageCache()
        PCallY(Coop, LP.SetLanguage, LP, before)
        LP.db.language = before
    end, true)
end

IMPL.T138 = function()
    local st = LP.Names:StatusText()
    local ok = type(st) == "string" and (st:find("ok", 1, true) or st:find(L["geladen"], 1, true)
        or st == L["nicht nötig (Englisch)"]) ~= nil
    local en = LP.Names.LOCALE_OF and LP.Names.LOCALE_OF.en
    local it = LP.Names.LOCALE_OF and LP.Names.LOCALE_OF.it
    local same = en == nil or en == it
    return ok and same, st:sub(1, 80) .. (en and (" · en/it: " .. S(en) .. "/" .. S(it)) or ""), "ok/geladen, en und it englisch"
end

------------------------------------------------------------------------
-- G. Zusammenspiel (3.12.6)
------------------------------------------------------------------------
-- 3.12.94 (Befund 18.11. 09:07, MITTEL): der Testfehler darf NIE beim Handler des Spiels ankommen (vorher pcall(geterrorhandler(), …):
-- die Kette endete bei Blizzard_ScriptErrors, das Fehlerfenster ging beim Spieler auf). Jetzt: beide Abgriffe direkt (GoldSentinelTest
-- wie sein Fehler-Haken: Record(addon, "Lua", …) über GT.Error; das Protokoll über Pr.OnLuaError) und geprüft, dass beide Haken in der
-- Kette hängen. Das Fehlerfenster des Spiels wird gezählt: soll 0. Gegenprobe 3.12.92: 1 (Spiel, Stack Blizzard_ScriptErrors.lua:59/72).
local function ErrorWindowShown()
    local f = _G.ScriptErrorsFrame
    return f and f.IsShown and f:IsShown() and true or false
end
TR.ErrorWindowShown = ErrorWindowShown
local function TestErrorDirect(msg)
    local GTm = _G.GoldSentinelTest
    if GTm and GTm.Error then pcall(GTm.Error, "LevelPilot", "Lua", msg) end
    if LP.Protocol and LP.Protocol.OnLuaError then pcall(LP.Protocol.OnLuaError, msg) end
end
IMPL.T142 = function()
    if not geterrorhandler then return true, "kein Fehler-Handler" end
    local msg = "Interface/AddOns/LevelPilot/Test.lua:1: LP-Testfehler Handlerkette"
    local win0 = ErrorWindowShown()
    local gt0 = GTErrors("LP-Testfehler Handlerkette")
    TestErrorDirect(msg)
    local gt1 = GTErrors("LP-Testfehler Handlerkette", true)
    local pr = DropProtocol("LP-Testfehler Handlerkette")
    local hooks = _G.GoldSentinelTestHooked == true and LP.Protocol.hooked == true
    local opened = (ErrorWindowShown() and not win0) and 1 or 0
    local bug = _G.BugGrabber and "BugGrabber geladen" or "ohne BugGrabber"
    local ok = gt1 > gt0 and pr >= 1 and hooks and opened == 0
    return ok, string.format("GoldSentinelTest %d, Protokoll %d, Haken in der Kette %s · Fehlerfenster geöffnet: %d · %s",
        gt1 - gt0, pr, S(hooks), opened, bug), "beide >= 1, Haken true, Fehlerfenster 0"
end

IMPL.T144 = function()
    local Q = LP.QuestDB
    local r = {}
    if _G.LibQuestieDB or _G.QuestieLoader then
        WithSetting({ usePack = false, useQuestie = true }, function()
            Q:Reconnect()
            local c = Q:Counts()
            r.with = Q.questie == true and (c.questie or 0) > 0
        end)
        Coop(Q.Reconnect, Q)            -- 3.12.93: zurück zur echten Quelle als freigegebene Rechnung (kalte Neuplanung)
        return r.with and true or false, "mit Questie: aktiv " .. S(r.with), "aktiv, Quests > 0"
    end
    WithSetting({ usePack = false, useQuestie = true }, function()
        Q:Reconnect()
        r.info = tostring(Q.questieInfo or "")
    end)
    Coop(Q.Reconnect, Q)                -- 3.12.93: zurück zur echten Quelle als freigegebene Rechnung (kalte Neuplanung)
    local ok = r.info:find(L["nicht installiert"], 1, true) ~= nil
    return ok, "ohne Questie: " .. r.info:sub(1, 60) .. " (Teil mit Questie übersprungen)", "nicht installiert"
end

------------------------------------------------------------------------
-- H. Leistung (3.12.6)
------------------------------------------------------------------------
IMPL.T148 = function()
    local d = LP.drivers and LP.drivers.nav
    local fn = d and d:GetScript("OnUpdate")
    if not fn then return false, "Navigations-Treiber fehlt", "vorhanden" end
    local med, max = Bench(function() fn(d, 0.05) end)
    -- 3.12.24: Recalc(true) startet die Wegsuche in Portionen; gemessen wird der Start und die laengste Portion
    local Jobs = LP.Jobs
    local oldSync = Jobs.sync
    Jobs.sync = false
    local t0 = Ms()
    LP.Nav:Recalc(true)
    local full = Ms() - t0
    local slice, frames = 0, 0
    while Jobs.Running("navpath") and frames < 5000 do
        local s0 = Ms()
        Jobs.Step()
        slice = math.max(slice, Ms() - s0)
        frames = frames + 1
    end
    Jobs.sync = oldSync
    return med < 2 and full < 16 and slice < 16, string.format("Median %.2f ms, Höchstwert %.2f ms, Recalc(true) %.2f ms, Wegsuche %d Portionen, längste %.2f ms",
        med, max, full, frames, slice), "Median < 2 ms, Recalc < 16 ms, Portion < 16 ms"
end

IMPL.T149 = function()
    local d = LP.drivers and LP.drivers.pins
    local fn = d and d:GetScript("OnUpdate")
    if not fn then return false, "Pins-Treiber fehlt", "vorhanden" end
    local med, max = Bench(function() fn(d, 0.05) end)
    local wm = Bench(function() LP.Pins:UpdateWorldMap() end, 5)
    return med < 2 and wm < 16, string.format("OnUpdate Median %.2f ms (max %.2f), Weltkarte %.2f ms", med, max, wm), "< 2 ms, < 16 ms"
end

IMPL.T151 = function()
    local Geo = LP.Geo
    -- 3.12.90 (Ingametest 3.12.89): Kartenkoordinaten 0–100 (vorher 0,45/0,52 = Kartenecken – gemessen wurde ein Weg
    -- quer durchs unbekannte Gelände, nicht Orgrimmar -> Wegkreuz)
    local i1, n1, w1 = Geo:ToWorld(1454, 45, 55)
    local i2, n2, w2 = Geo:ToWorld(1413, 52, 30)
    if not (i1 and i2) then return false, "Koordinaten fehlen", "Orgrimmar und Wegkreuz" end
    -- 3.12.92 (Prüfung 17.11. 21:30, Plan 3.12.92 Punkt 3): im Spiel läuft die Wegsuche in Portionen über den gemeinsamen Takt.
    -- Gemessen werden getrennt: die Summe am Stück (zur Information, so viel rechnet eine Suche insgesamt) und das längste
    -- Bild, wenn sie wie im Spiel als Takt-Aufgabe läuft (Grenze < 16 ms, harte Grenze 40 ms).
    -- 3.12.93 (Ingametest 3.12.91 Punkt 1/2: die Messung "am Stück" war selbst je Lauf ein Bild von ~43 ms): die Gesamt-Rechenzeit
    -- jetzt aus einer freigegebenen Rechnung (Pausen nicht gezählt) – kein Bild am Stück mehr
    local p0, t0 = TR.pausedMs, Ms()
    Coop(LP.Graph.Path, LP.Graph, i1, n1, w1, 1454, i2, n2, w2, 1413)
    local total = Ms() - t0 - (TR.pausedMs - p0)
    TR.Safe("T151")
    local Jobs = LP.Jobs
    local oldSync = Jobs.sync
    local frames, longest, result = 0, 0, nil
    local ok, err = PCallY(function()
        Jobs.sync = false
        Jobs.lastSummary = nil
        Jobs.StartTakt("lpt151", "path", function() return LP.Graph:Path(i1, n1, w1, 1454, i2, n2, w2, 1413) end,
            function(okp, p) result = okp and (p and #p or 0) or -1 end, { graph = true })
        while Jobs.Running("lpt151") and frames < 5000 do
            local t0 = Ms()
            Jobs.Step()
            local ms = Ms() - t0
            if ms > longest then longest = ms end
            frames = frames + 1
            TR.Safe("T151")          -- zwischen zwei Portionen (gemessen wird nur die Portion; der Treiber ruht)
        end
    end)
    Jobs.Cancel("lpt151")
    Jobs.sync = oldSync
    if not ok then error(err, 0) end
    local sum = Jobs.lastSummary or ""
    -- frames >= 1 und Takt-Zeile: die Suche lief wirklich als Takt-Aufgabe (Gegenprobe: alte Portionen ohne Takt -> keine Zeile)
    return frames >= 1 and sum ~= "" and longest < 16 and (result or 0) > 0, string.format("in Portionen: %d Bilder, längstes %.2f ms, Weg %s Punkte · gesamt %.2f ms (ohne Pausen) · %s",
        frames, longest, tostring(result), total, sum), "als Takt-Aufgabe (>= 1 Bild), längstes Bild < 16 ms, Weg gefunden"
end

-- Drosselung abseits des Weges (Nav.recalcCount)
local function OffPathThrottle()
    local N, Geo = LP.Nav, LP.Geo
    N:Recalc(true)
    local path = N:PathInfo()
    if not path or not path[1] or not path[2] then return NA, "kein Weg (Schritt ohne Ort) – Drosselung nicht messbar" end
    local a, b = path[1], path[2]
    local dn, dw = b[2] - a[2], b[3] - a[3]
    local len = math.sqrt(dn * dn + dw * dw)
    if len < 1 then dn, dw, len = 1, 0, 1 end
    local pn, pw = b[2] - dw / len * 100, b[3] + dn / len * 100      -- 100 Yards seitlich
    local origPlayer = Geo.Player
    local t = GetTime() + 10
    local onTaxi = false
    local fake = { GetTime = function() return t end, UnitOnTaxi = function() return onTaxi end }
    return Guard(function()
        local inst = a[1]
        Geo.Player = function() return inst, pn, pw, a[4] end
        local c0 = N.recalcCount or 0
        WithEnv({ N.Recalc }, fake, function()
            for _ = 1, 20 do t = t + 0.05 N:Recalc(false) end
        end)
        local n1 = (N.recalcCount or 0) - c0
        -- auf dem Flug nie
        onTaxi = true
        pn, pw = pn + 150, pw + 150
        t = t + 5
        local c1 = N.recalcCount or 0
        WithEnv({ N.Recalc }, fake, function()
            for _ = 1, 20 do t = t + 0.05 N:Recalc(false) end
        end)
        local n2 = (N.recalcCount or 0) - c1
        return n1 <= 2 and n2 == 0, string.format("vom Weg ab: %d Neuberechnungen in 1 s, auf dem Flug %d", n1, n2), "<= 2, 0"
    end, function() Geo.Player = origPlayer pcall(N.Recalc, N, true) end)
end
IMPL.T152 = OffPathThrottle
IMPL.T197 = OffPathThrottle

IMPL.T153 = function()
    local h = HandlerList("NAME_PLATE_UNIT_ADDED")
    local a = Bench(function() for _, fn in ipairs(h) do fn("NAME_PLATE_UNIT_ADDED", "nameplate1") end end)
    local b = Bench(function() LP.Tooltips:UnitLines("target") end)
    local c = Bench(function() LP.Calib:ObserveUnit("target") end)
    return a < 1 and b < 1 and c < 0.5, string.format("Plakette %.3f ms, Tooltip %.3f ms, Beobachtung %.3f ms", a, b, c), "< 1, < 1, < 0.5 ms"
end

IMPL.T154 = function()
    local Comm = LP.Comm
    local msg = "Q\t299901\t12\tH\t\t\tLPTestquest\t0"
    local snap = Comm:QueueSnapshot()
    local a, b
    WithQdb({}, function()
        a = Bench(function() Comm:Receive(msg, "LPTest-Realm") end)
    end)
    return Guard(function()
        b = Bench(function() Comm:SendNext() end)
        return a < 1 and b < 0.5, string.format("Empfang %.3f ms, Senden %.3f ms", a, b), "< 1 ms, < 0.5 ms"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T156 = function()
    local names = { ui = true, caves = true, recorder = true, session = true }
    local fns = {}
    for _, t in ipairs(LP.tickers or {}) do if names[t.name] then fns[#fns + 1] = t.fn end end
    if #fns == 0 then return false, "Ticker nicht gefunden", "ui, caves, recorder, session" end
    local med, max = Bench(function() for _, fn in ipairs(fns) do fn() end end)
    return med < 3, string.format("%d Ticker, Summe Median %.2f ms, Höchstwert %.2f ms", #fns, med, max), "Summe < 3 ms"
end

------------------------------------------------------------------------
-- I. Fehlerzählung (3.12.6)
------------------------------------------------------------------------
IMPL.T159 = function()
    if not geterrorhandler then return true, "kein Fehler-Handler" end
    local msg = "Interface/AddOns/LevelPilot/Test.lua:1: LP-Testfehler"
    local gt0 = GTErrors("LP-Testfehler")
    TestErrorDirect(msg)              -- 3.12.94: nie über den Handler des Spiels (Fehlerfenster), siehe T142
    local gt = GTErrors("LP-Testfehler", true) - gt0
    local pr = DropProtocol("LP-Testfehler")
    return gt >= 1 and pr >= 1, string.format("GoldSentinelTest %d, Protokoll %d", gt, pr), "beide >= 1"
end

IMPL.T162 = function()
    LP.initErrors = LP.initErrors or {}
    LP.initErrors.LPTestModul = "LP-Testfehler Start"
    return Guard(function()
        local a = IMPL.T01()
        local diag = table.concat(LP.Planner:DiagLines(), "\n")
        local b = diag:find("LPTestModul", 1, true) ~= nil
        return a == false and b, "T01 meldet FEHLER " .. S(a == false) .. ", Diagnose zeigt ihn " .. S(b), "true, true"
    end, function() LP.initErrors.LPTestModul = nil end)
end

IMPL.T164 = function()
    local V = LP.Virtual
    if not V.Note then return false, "Virtual.Note fehlt", "zugänglich" end
    if V.active then return NA, "Reise läuft – nicht geprüft" end
    local savedS = V.s
    V.s = { problems = {}, seen = {}, level = 1, protoErrors = 0 }
    local gt0 = GTErrors("Reise")
    local pr0 = LP.Protocol:Count(true)
    return Guard(function()
        for i = 1, 6 do V.Note("error", "LP-Testfehler Reise " .. i) end
        local gt = GTErrors("Reise", true) - gt0
        local pr = DropProtocol("LP-Testfehler Reise")
        local tracking = LP.trackingErrors
        local ok = pr == 5 and (gt == 5 or not tracking)
        return ok, string.format("Protokoll %d, GoldSentinelTest %d (je Reise höchstens 5)", pr, gt), "5, 5"
    end, function() V.s = savedS end)
end

------------------------------------------------------------------------
-- J. 3.12.7: Route in Mulgore (Befund aus dem Spiel) und CheckNav
------------------------------------------------------------------------
-- Schritt an einem Kartenpunkt (Mulgore 1412, Koordinaten von WoW Forever)
local function MulgoreStep(t, id, x, y, key)
    local i, n, w = LP.Geo:ToWorld(1412, x, y)
    return { t = t, id = id, map = 1412, x = x, y = y, inst = i, n = n, w = w, key = key or (t .. ":" .. tostring(id)) }
end

IMPL.T214 = function()
    local P = LP.Planner
    local fake = { inLog = { [780] = { complete = true }, [757] = { complete = true }, [3376] = { complete = true },
                             [761] = { complete = true }, [756] = { complete = true }, [772] = { complete = false } } }
    -- Fall 1: Spieler Red Cloud Mesa 54.1/83.9, drei Abgaben in Camp Narache, weites Ziel bei 62/58
    local pi, pn, pw = LP.Geo:ToWorld(1412, 54.1, 83.9)
    if not pi then return NA, "Mulgore-Karte nicht verfügbar" end
    local steps1 = { MulgoreStep("FP", nil, 62, 58, "FP:LPTest"), MulgoreStep("ACCEPT", 753, 48.8, 80.9),
                     MulgoreStep("TURNIN", 3376, 44.2, 77.0), MulgoreStep("TURNIN", 780, 44.5, 77.5),
                     MulgoreStep("TURNIN", 757, 43.9, 76.7) }
    P.NearTurninsFirst(fake, steps1, pi, pn, pw)
    local f1 = steps1[1].t == "TURNIN" and steps1[2].t == "TURNIN" and steps1[3].t == "TURNIN" and steps1[4].key == "FP:LPTest"
    -- Fall 2: Spieler 39.3/46.2, zwei Abgaben in Bloodhoof (südöstlich), offene Quest und weites Ziel im Nordwesten
    local qi, qn, qw = LP.Geo:ToWorld(1412, 39.3, 46.2)
    local steps2 = { MulgoreStep("COMPLETE", 745, 30, 32), MulgoreStep("COMPLETE", 772, 46.5, 61.0),
                     MulgoreStep("TURNIN", 761, 47.6, 60.6), MulgoreStep("TURNIN", 756, 46.7, 60.2) }
    P.NearTurninsFirst(fake, steps2, qi, qn, qw)
    local f2 = steps2[1].t == "TURNIN" and steps2[2].t == "TURNIN" and steps2[3].id == 745
    -- weit entfernte Abgabe (> NEAR_TURNIN) bleibt, wo die Planung sie hingestellt hat
    local steps3 = { MulgoreStep("ACCEPT", 753, 48.8, 80.9), MulgoreStep("TURNIN", 761, 20, 15) }
    P.NearTurninsFirst(fake, steps3, pi, pn, pw)
    local f3 = steps3[1].t == "ACCEPT"
    return f1 and f2 and f3, string.format("Fall 1 Abgaben vorn %s, Fall 2 Abgaben vorn %s, weite Abgabe unverändert %s (Nähe %d Yards)",
        S(f1), S(f2), S(f3), P.NEAR_TURNIN), "true, true, true"
end

-- unbekannte Zelle (kein begehbarer Boden in der Umgebung) auf einer Karte suchen
local function UnknownSpot(map, block)
    local Tr = LP.Terrain
    for y = 5, 95, 2 do
        for x = 5, 95, 2 do
            local all = true
            for dy = -(block or 0), block or 0 do
                for dx = -(block or 0), block or 0 do
                    if Tr:Walkable(map, x + dx, y + dy) ~= false then all = false break end
                end
                if not all then break end
            end
            if all then return x, y end
        end
    end
    return nil
end

IMPL.T215 = function()
    local Q, Tr = LP.QuestDB, LP.Terrain
    -- a) aufgezeichnete Abgabe weit neben dem Datenpaket wird nicht bevorzugt, eine passende schon
    local function base() return { ends = { { 1412, 46.2, 63.3, "Kauth" } }, starts = {}, objectives = {} } end
    local far = Q.Merge(base(), { starts = {}, ends = { { 1412, 62, 58 } }, objectives = {} })
    local near = Q.Merge(base(), { starts = {}, ends = { { 1412, 46.4, 63.0 } }, objectives = {} })
    local a = far.ends[1][2] == 46.2 and near.ends[1][2] == 46.4
    if Tr:Walkable(1412, 46.2, 63.3) == nil then
        return a, "Merge " .. S(a) .. " · ohne Geländekarte (kein Datenpaket): Gebirgsprüfung nicht möglich", "Merge true"
    end
    -- b) Händler/Gastwirt im Gebirge (Aufzeichnung ohne begehbaren Boden) wird nicht angeboten
    local x, y = UnknownSpot(1412, 1)
    local key = "LPTestGebirge@1412"
    local saved = LP.db.vendors[key]
    local b, c = false, false
    Guard(function()
        if x then
            LP.db.vendors[key] = { map = 1412, x = x, y = y, name = "LPTestGebirge", inn = true, vendor = true }
            Q:InvalidateServices()
            b = true
            for _, v in ipairs(Q:ServiceNPCs().inn or {}) do if v.name == "LPTestGebirge" then b = false end end
        end
    end, function() LP.db.vendors[key] = saved Q:InvalidateServices() end)
    -- c) Luftlinie quer über unbekanntes Gelände: keine Linie (nur Pfeil)
    local bx, by = UnknownSpot(1412, 4)
    if bx then
        local i1, n1, w1 = LP.Geo:ToWorld(1412, bx - 4, by - 4)
        local i2, n2, w2 = LP.Geo:ToWorld(1412, bx + 4, by + 4)
        c = LP.Nav.Blocked({ { i1, n1, w1, 1412 }, { i2, n2, w2, 1412 } }) == true
    end
    local walk = Tr:Walkable(1412, 46.2, 63.3) == true            -- Bloodhoof (Datenpaket): begehbar
    local ok = a and walk and (b or not x) and (c or not bx)
    return ok, string.format("Merge %s, Bloodhoof begehbar %s, Gastwirt im Gebirge ausgeblendet %s, Linie über Gebirge unterdrückt %s",
        S(a), S(walk), x and S(b) or "keine Gebirgszelle", bx and S(c) or "kein grosses Gebirge"), "alles true"
end

IMPL.T216 = function()
    local Pr, N = LP.Protocol, LP.Nav
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return true, "keine Position" end
    local bm, bs = "LPTestKoeder Bewegung", "LPTestKoeder Tempo"
    local savedT = N.target
    N.target = { key = "LPTestNav", inst = pi, n = pn + 500, w = pw, label = "LPTest" }
    return Guard(function()
        return WithSecret({ bm, bs }, function()
            return WithEnv({ Pr.CheckNav }, { IsPlayerMoving = function() return bm end, GetUnitSpeed = function() return bs end,
                UnitAffectingCombat = function() return false end }, function()
                local ok, err = pcall(Pr.CheckNav, Pr)
                return ok, ok and "kein Fehler, Vergleich übersprungen" or tostring(err), "kein Lua-Fehler"
            end)
        end)
    end, function() N.target = savedT end)
end

IMPL.T217 = function()
    local P, Pr, Geo = LP.Planner, LP.Protocol, LP.Geo
    local pi, pn, pw = Geo:ToWorld(1456, 45, 55)
    if not pi then return true, "Karte Thunder Bluff nicht verfügbar" end
    -- 3 Aufgaben in Thunder Bluff, 6 in Mulgore
    local tasks = {}
    for k = 1, 3 do local t = MulgoreStep("ACCEPT", 299700 + k, 50, 50) t.map = 1456 t.inst, t.n, t.w = Geo:ToWorld(1456, 40 + k * 4, 50) t.value = 1 tasks[#tasks + 1] = t end
    for k = 1, 6 do local t = MulgoreStep("COMPLETE", 299710 + k, 40 + k, 60) t.value = 1 tasks[#tasks + 1] = t end
    local savedFocus, savedZone, savedTasks = P.focus, LP.char.focusZone, P.lastTasks
    local savedPlayer = Geo.Player
    return Guard(function()
        LP.char.focusZone = nil
        P.focus = nil
        local f1 = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        P.focus = 1412
        local f2 = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        local same = P.ZoneOf(1456) == 1412 and f1 == 1412 and f2 == 1412
        -- Fokus-Wächter: Spieler in Thunder Bluff, Fokus Mulgore -> kein Eintrag
        P.lastTasks = tasks
        Geo.Player = function() return pi, pn, pw, 1456, 45, 55 end
        local n0 = Pr:Count(true)
        WithEnv({ Pr.CheckFocus }, { GetTime = function() return 1e9 end, UnitOnTaxi = function() return false end }, function() Pr:CheckFocus() end)
        local logged = Pr:Count(true) - n0
        -- Vorrang-Ziel (Klassentrainer in Thunder Bluff) nicht vor nahe Abgaben
        local steps = { { t = "TURNIN", nearTurnin = true, key = "TURNIN:1" }, { t = "TURNIN", nearTurnin = true, key = "TURNIN:2" },
                        { t = "ACCEPT", key = "ACCEPT:3" } }
        P.InsertPriority(steps, { t = "GOTO", key = "PRIO:TRAIN:8" })
        local prioOk = steps[3].key == "PRIO:TRAIN:8" and steps[1].t == "TURNIN"
        local ok = same and logged == 0 and prioOk
        return ok, string.format("Fokus aus Thunder Bluff %s/%s, Wächter-Einträge %d, Vorrang-Ziel an Stelle %s", S(f1), S(f2), logged,
            prioOk and "3 (nach den Abgaben)" or "falsch"), "1412/1412, 0, nach den Abgaben"
    end, function()
        P.focus, LP.char.focusZone, P.lastTasks = savedFocus, savedZone, savedTasks
        Geo.Player = savedPlayer
    end)
end

IMPL.T218 = function()
    local N, Geo = LP.Nav, LP.Geo
    local function P(x, y, via, map) local i, n, w = Geo:ToWorld(map or 1412, x, y) return { i, n, w, map or 1412, via = via } end
    if not Geo:ToWorld(1412, 50, 50) then return true, "Mulgore-Karte nicht verfügbar" end
    -- a) Mulgore Fall 1: Red Cloud Mesa -> 62/58 nur als Luftlinie (kein gelaufener Weg) -> keine Linie
    local a = N.Known({ P(54.1, 83.9), P(50, 35, "v"), P(62, 58, "v") }) == false
    -- Mulgore Fall 2: 39.3/46.2 -> Schleife 30/32 als Luftlinie -> keine Linie
    local b = N.Known({ P(39.3, 46.2), P(30, 32, "v") }) == false
    -- b) bekannter Weg: kurzes erstes Stück, gelaufene Kanten, kurzes letztes Stück -> Linie
    local p1 = P(46.0, 63.0)
    local p2 = { p1[1], p1[2] + 20, p1[3], 1412 }
    local p3 = { p1[1], p1[2] + 300, p1[3] + 50, 1412, via = "s" }
    local p4 = { p1[1], p1[2] + 600, p1[3] + 80, 1412, via = "r" }
    local p5 = { p1[1], p1[2] + 630, p1[3] + 80, 1412, via = "v" }
    local c = N.Known({ p1, p2, p3, p4, p5 }) == true
    -- Ziel ohne Netzanschluss: letztes Stück 200 Yards Luftlinie -> keine Linie
    local p6 = { p1[1], p1[2] + 800, p1[3] + 80, 1412, via = "v" }
    local d = N.Known({ p1, p2, p3, p4, p6 }) == false
    -- c) Thunder Bluff mit Aufzug: ohne gelaufene Aufzugskante bleibt der Weg unbekannt, mit Kante bekannt
    local t1 = P(30, 30, nil, 1456)
    local up = { t1[1], t1[2] + 25, t1[3], 1456, via = "v" }
    local lift = { t1[1], t1[2] + 25, t1[3] + 5, 1456, via = "s" }
    local trainer = { t1[1], t1[2] + 60, t1[3] + 5, 1456, via = "v" }
    local e = t1[1] and N.Known({ t1, up, { t1[1], t1[2] + 200, t1[3], 1456, via = "v" } }) == false
    local f = t1[1] and N.Known({ t1, up, lift, trainer }) == true
    local ok = a and b and c and d and (not t1[1] or (e and f))
    return ok, string.format("Mulgore 1 %s, Mulgore 2 %s, bekannter Weg %s, Ziel ohne Netz %s, Aufzug ohne/mit Kante %s/%s",
        S(a), S(b), S(c), S(d), S(e), S(f)), "alles true"
end

IMPL.T219 = function()
    local N, Geo, Gr = LP.Nav, LP.Geo, LP.Graph
    local pi, pn, pw, pz0 = Geo:Player()
    if not pi then return true, "keine Position" end
    local tgt = { key = "LPTestFest", inst = pi, n = pn + 500, w = pw, label = "LPTest" }
    local savedT, savedP, savedKey = N.target, Geo.Player, N.stuckKey
    local cn, cw = pn, pw
    local px, py = cn, cw
    local afk = false
    local fake = { UnitIsAFK = function() return afk end, UnitIsDeadOrGhost = function() return false end,
                   UnitOnTaxi = function() return false end }
    -- Szenario: Liste { Sekunden, Art } mit Art "steh", "kreis"; AFK-Schalter je Szenario
    local function run(plan, isAfk)
        N.ResetStuck()
        afk = isAfk and true or false
        local now, ang = 1000, 0
        px, py = cn + 30, cw                                   -- Kreis um (cn, cw), Start am zielnächsten Punkt
        return WithCounter(N, "OnStuck", function(fired)
            WithEnv({ N.StuckTick, N.Excluded }, fake, function()
                for _, part in ipairs(plan) do
                    for _ = 1, part[1] do
                        now = now + 1
                        if part[2] == "kreis" then
                            ang = ang + 0.25
                            px, py = cn + 30 * math.cos(ang), cw + 30 * math.sin(ang)
                        end
                        N:StuckTick(now)
                    end
                end
            end)
            return fired()
        end)
    end
    return Guard(function()
        N.target = tgt
        Geo.Player = function() return pi, px, py, nil end
        local a = run({ { 600, "kreis" } }, true)                          -- 10 min AFK (auch wenn sich etwas bewegt)
        local a2 = run({ { 600, "steh" } }, false)                         -- 10 min stehen
        local b = run({ { 120, "steh" }, { 60, "kreis" } }, false)          -- 2 min stehen, dann 1 min laufen
        local c = run({ { 250, "kreis" } }, false)                         -- 4 min im Kreis ohne Annäherung
        -- 3.13.7 (Entscheid 22.11. 16:57): Graph:Block sperrt nicht mehr, die Wegsuche nimmt die Kante weiter. Mit Zone: ohne Zone
        -- nahm die Wegsuche schon vorher nur die Luftlinie (Nachbau 3.13.6: Weg "v" mit und ohne Sperre – die alte Prüfung "gemieden"
        -- war immer wahr); mit Zone nimmt sie die Kante (3.13.6 gesperrt: nur Luftlinie, 3.13.7: Kante)
        local pz = pz0                         -- Geo.Player ist hier ersetzt (ohne Karte)
        local i1 = Gr:AddNode(pi, pn + 3000, pw + 3000, pz)
        local i2 = Gr:AddNode(pi, pn + 3100, pw + 3000, pz)
        Gr:AddEdge(i1, i2, "s")
        local before = Gr:IsBlocked(i1, i2)
        Gr:Block(i1, i2, "FEST")
        local after = Gr:IsBlocked(i1, i2)
        local p = Gr:PathRaw(pi, pn + 3000, pw + 3000, pz, pi, pn + 3100, pw + 3000, pz)
        local usesEdge = false
        for _, q in ipairs(p or {}) do if q.via == "s" then usesEdge = true end end
        Gr:Unblock(i1, i2)
        local ok = a == 0 and a2 == 0 and b == 0 and c == 1 and not before and not after and usesEdge
        return ok, string.format("10 min AFK %d, 10 min stehen %d, 2+1 min %d, 4 min Kreis %d (FEST), Kante gesperrt %s, Weg nimmt sie %s",
            a, a2, b, c, S(after), S(usesEdge)), "0, 0, 0, 1, false, true"
    end, function()
        N.target, Geo.Player, N.stuckKey = savedT, savedP, savedKey
        N.ResetStuck()
    end)
end

IMPL.T220 = function()
    local R, Q, Geo = LP.Recorder, LP.QuestDB, LP.Geo
    local N = _G.LevelPilotData and _G.LevelPilotData.N
    local npc = 6747                                    -- Gastwirt Kauth (Bloodhoof), Abgabe von „Eine unvollendete Aufgabe“
    if type(N) ~= "table" or not N[npc] then return true, "kein Datenpaket" end
    -- 3.12.30 (Offline-Routine TU9): Quest 1656 gibt es nur für die Horde – auf der Allianz meldete der Test fälschlich FEHLER
    if LP:PlayerFaction() ~= "Horde" then return NA, "Hordequest 1656 – auf der Allianz nicht prüfbar" end
    local pi = Geo:ToWorld(1412, 47.0, 61.0)
    if not pi then return true, "Mulgore-Karte nicht verfügbar" end
    LP.db.npcPos = type(LP.db.npcPos) == "table" and LP.db.npcPos or {}
    local saved = LP.db.npcPos[npc]
    local savedPlayer = Geo.Player
    -- 3.12.90 (Ingametest 3.12.89 T220 false, Nachbau mit den PC-Daten gleich): hat der Spieler die Quest selbst schon abgegeben,
    -- gilt sein aufgezeichneter Abgabe-Ort (LP.db.qdb, Vorrang vor dem Datenpaket – so gewollt). Für diese Prüfung des
    -- npcPos-Weges die eigene Aufzeichnung kurz weglegen (wird im Guard zurückgestellt).
    LP.db.qdb = type(LP.db.qdb) == "table" and LP.db.qdb or {}
    local savedRec = LP.db.qdb[1656]
    return Guard(function()
        LP.db.qdb[1656] = nil
        LP.db.npcPos[npc] = nil
        Geo.Player = function() local i, n, w = Geo:ToWorld(1412, 47.0, 61.0) return i, n, w, 1412, 47.0, 61.0 end
        WithEnv({ R.RecordNpc }, { UnitGUID = function() return "Creature-0-1-1-1-" .. npc .. "-0000ABCD99" end }, function() R:RecordNpc() end)
        local rec = LP.db.npcPos[npc]
        Q:Invalidate()
        local q = Q:Get(1656)
        local e = q and q.ends and q.ends[1]
        local used = e and e[1] == 1412 and math.abs(e[2] - 47.0) < 0.01 and math.abs(e[3] - 61.0) < 0.01
        -- geschützte GUID: nichts gemerkt
        LP.db.npcPos[npc] = nil
        local bait = "LPTestKoeder GUID"
        WithSecret({ bait }, function()
            WithEnv({ R.RecordNpc }, { UnitGUID = function() return bait end }, function() R:RecordNpc() end)
        end)
        local none = LP.db.npcPos[npc] == nil
        local ok = rec ~= nil and used and none
        return ok and true or false, string.format("gemerkt %s (Datenpaket %s), Abgabeziel aus dem echten Ort %s, geschützt nichts %s",
            S(rec ~= nil), rec and rec.o and string.format("%.1f/%.1f", rec.o[2], rec.o[3]) or "-", S(used), S(none)), "true, true, true"
    end, function()
        LP.db.npcPos[npc] = saved
        LP.db.qdb[1656] = savedRec
        Geo.Player = savedPlayer
        Q:Invalidate()
    end)
end

IMPL.T221 = function()
    local Gr, Geo = LP.Graph, LP.Geo
    local pi, pn, pw, map = Geo:Player()
    if not pi or not map then return NA, "keine Position" end
    -- zwei gelaufene Wegstücke in der aktuellen Zone (Sandbox stellt die Daten zurück)
    local a = Gr:AddNode(pi, pn + 2000, pw + 2000, map)
    local b = Gr:AddNode(pi, pn + 2050, pw + 2000, map)
    local c = Gr:AddNode(pi, pn + 2100, pw + 2010, map)
    Gr:AddEdge(a, b, "r") Gr:AddEdge(b, c, "r")
    -- 3.12.93 (Ingametest 3.12.91: T221 1817 ms in einem Bild): Wegdaten in freigegebenen Rechnungen (TR.Coop) – kein Ersatz aktiv;
    -- wegeExport/wegeSent und wegeAuto benutzt anderer Code nur beim Ausloggen
    local text, edges = Coop(Gr.WegeText, Gr, tostring(map))
    local f = _G.LevelPilotBackupFrame
    Coop(Gr.ShowWege, Gr, tostring(map))
    local shown = f and _G.LevelPilotBackupFrame:IsShown() or (_G.LevelPilotBackupFrame and _G.LevelPilotBackupFrame:IsShown()) or false
    Hide("LevelPilotBackupFrame")
    local savedList, savedSent = LevelPilotDB.wegeExport, LP.db.wegeSent
    return Guard(function()
        LevelPilotDB.wegeExport, LP.db.wegeSent = {}, {}
        local ok1 = WithSettingC({ wegeAuto = true }, function() return Coop(Gr.WegeExport, Gr) end)
        local s1 = LevelPilotDB.wegeExport[1] or ""
        -- 3.12.90 (Ingametest 3.12.89 T221 false, Nachbau mit den PC-Daten gleich): grosse Wegdaten (PC: 17 Zonen, 423 000 Zeichen)
        -- passen nicht in einen Bericht (Grenze 200 KB) – der Rest kommt mit den nächsten Versänden (so gebaut). Darum: weiter
        -- versenden, bis nichts Neues mehr da ist (höchstens 10), dann muss der nächste Versand leer bleiben.
        local more, rounds = true, 1
        while more and rounds < 10 do
            more = WithSettingC({ wegeAuto = true }, function() return Coop(Gr.WegeExport, Gr) end) and true or false
            if more then rounds = rounds + 1 end
        end
        local ok2 = WithSettingC({ wegeAuto = true }, function() return Coop(Gr.WegeExport, Gr) end)   -- nichts Neues
        local n2 = more and 0 or 1
        LP.db.wegeSent = {}
        local off = WithSettingC({ wegeAuto = false }, function() return Coop(Gr.WegeExport, Gr) end)
        local me = UnitName("player")
        local guild = GetGuildInfo and GetGuildInfo("player")
        local leak = (type(me) == "string" and me ~= "" and (s1:find(me, 1, true) or text:find(me, 1, true)))
            or (type(guild) == "string" and guild ~= "" and (s1:find(guild, 1, true) or text:find(guild, 1, true)))
        local ok = edges >= 1 and shown and ok1 == true and s1:sub(1, 7) == "GSWEGE1" and #s1 <= Gr.WEGE_MAX and not ok2 and n2 == 1
            and not off and not leak
        return ok and true or false, string.format("Text %d Wege (Fenster %s), GSWEGE1 %s (%d Zeichen), Versände bis alles drin %d, danach ohne Neues %s, aus %s, Namen %s",
            edges, S(shown), S(ok1), #s1, rounds, S(not ok2), S(not off), leak and "GEFUNDEN" or "keine"), "Wege, Fenster, GSWEGE1, nur Neues, abschaltbar, keine Namen"
    end, function() LevelPilotDB.wegeExport, LP.db.wegeSent = savedList, savedSent end, true)
end

IMPL.T222 = function()
    local P, Geo = LP.Planner, LP.Geo
    local pi, pn, pw = Geo:ToWorld(1412, 38.3, 37.6)
    if not pi then return NA, "Mulgore-Karte nicht verfügbar" end
    -- 3.12.93 (Nachbau Allianz: 83 ms in einem Bild – Stufenbänder mit kaltem Zwischenspeicher unter dem Ersatz): Bänder vorher als
    -- freigegebene Rechnung (hängen nur an den Questdaten, nicht an Fokus/Zone)
    if P.ZoneBands then PCallY(Coop, P.ZoneBands, P) TR.Safe("T222") end
    local function task(t, id, map, x, y, value)
        local i, n, w = Geo:ToWorld(map, x, y)
        return { t = t, id = id, map = map, x = x, y = y, inst = i, n = n, w = w, value = value, key = t .. ":" .. id }
    end
    -- 3 offene Quests in Mulgore (wenig wert), im Brachland 3 Abgaben und viele neue Quests (viel wert)
    local tasks = { task("COMPLETE", 745, 1412, 33, 30, 0.3), task("COMPLETE", 776, 1412, 52, 40, 0.3),
                    task("COMPLETE", 758, 1412, 47, 22, 0.3) }
    local barrens = {}
    for k = 1, 3 do barrens[#barrens + 1] = task("TURNIN", 299800 + k, 1413, 52, 30, 3) end
    for k = 1, 6 do barrens[#barrens + 1] = task("ACCEPT", 299810 + k, 1413, 52, 30, 3) end
    for _, t in ipairs(barrens) do tasks[#tasks + 1] = t end
    local savedFocus, savedZone = P.focus, LP.char.focusZone
    return Guard(function()
        LP.char.focusZone = nil
        P.focus = nil
        local a = P:ChooseFocus(tasks, pi, pn, pw, 1412, {})
        P.focus = 1413
        local b = P:ChooseFocus(tasks, pi, pn, pw, 1412, {})
        -- aus Thunder Bluff (gehört zu Mulgore) ebenso
        local c = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        -- Mulgore fertig: dann gesammelt ins Brachland
        P.focus = 1412
        local d = P:ChooseFocus(barrens, pi, pn, pw, 1412, {})
        local ok = a == 1412 and b == 1412 and c == 1412 and d == 1413
        return ok, string.format("Fokus ohne/mit altem Fokus %s/%s, aus Thunder Bluff %s, Mulgore fertig %s", S(a), S(b), S(c), S(d)),
            "1412/1412, 1412, 1413"
    end, function() P.focus, LP.char.focusZone = savedFocus, savedZone end)
end

------------------------------------------------------------------------
-- 3.12.17: Wegdaten (Auswertung testberichte/wege/auswertung.md)
------------------------------------------------------------------------
-- Testpunkte in Mulgore, Rand der Karte (Sandbox stellt das Wegnetz zurück); Weltkoordinaten in Yards
-- 3.13.6 (Ingametest 3.13.5 T259: im Spiel 0 Punkte – der Spieler war AFK, WoW im Hintergrund): Prüfungen der Weg-Aufzeichnung
-- laufen ohne den echten Stillstand des Spielers (AFK, offene Fenster, alter Stillstand-Zustand). Ersatz nur für die Dauer von body.
local function NoIdle(body)
    local R = LP.Recorder
    if not (R and R.IsIdle and R.panels and R.idle) then return body() end
    local panels, idle = R.panels, {}
    for k, v in pairs(R.idle) do idle[k] = v end
    R.panels = {}
    for k in pairs(R.idle) do R.idle[k] = nil end
    local res = { pcall(WithEnv, { R.IsIdle }, { UnitIsAFK = function() return false end }, body) }
    R.panels = panels
    for k in pairs(R.idle) do R.idle[k] = nil end
    for k, v in pairs(idle) do R.idle[k] = v end
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2, table.maxn(res))
end
TR.NoIdle = NoIdle

local function WegBase()
    local i, n, w = LP.Geo:ToWorld(1412, 8, 92)
    return i, n, w
end
local function Connected(a, b)
    local Gr, seen, queue = LP.Graph, { [a] = true }, { a }
    while #queue > 0 do
        local id = table.remove(queue, 1)
        if id == b then return true end
        for v in pairs(Gr:Neighbors(id) or {}) do
            if not seen[v] and v > 0 then seen[v] = true queue[#queue + 1] = v end
        end
    end
    return false
end

IMPL.T235 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local function P(dn, dw) return { i, n + dn, w + dw, 1412 } end
    -- Weg A: 0 -> 50 -> 100 Yards (Kanten 50 Yards lang)
    Gr:AddPolyline({ P(0, 0), P(50, 0), P(100, 0) }, "r")
    local a0 = Gr:Nearest(i, n, w, 2, 1412)
    local a2 = Gr:Nearest(i, n + 100, w, 2, 1412)
    -- Weg B beginnt 6 Yards neben der Mitte der ersten Kante
    Gr:AddPolyline({ P(25, 6), P(25, 46) }, "r")
    local bEnd = Gr:Nearest(i, n + 25, w + 46, 2, 1412)
    -- Weg C kreuzt die zweite Kante (Punkt 4 Yards daneben)
    Gr:AddPolyline({ P(75, -30), P(75, -4), P(75, 22) }, "r")
    local cEnd = Gr:Nearest(i, n + 75, w + 22, 2, 1412)
    -- Weg D beginnt 15 Yards daneben: bleibt getrennt
    Gr:AddPolyline({ P(40, -15), P(40, -55) }, "r")
    local dEnd = Gr:Nearest(i, n + 40, w - 55, 2, 1412)
    local ab, ac, ad, ok2 = Connected(a0, bEnd), Connected(a0, cEnd), Connected(a0, dEnd), Connected(a0, a2)
    return ab and ac and not ad and ok2,
        string.format("Anfang an Kante %s, Kreuzung %s, 15 Yards daneben %s, Weg A ganz %s", S(ab), S(ac), S(ad), S(ok2)),
        "true, true, false, true"
end

IMPL.T236 = function()
    local R = LP.Recorder
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    -- gerade 240 Yards, dann rechtwinklig 120 Yards; Punkte alle 12 Yards
    local pts = {}
    for k = 0, 20 do pts[#pts + 1] = { i, n + k * 12, w, 1412, k } end
    for k = 1, 10 do pts[#pts + 1] = { i, n + 240, w + k * 12, 1412, 20 + k } end
    local kp = R.KeyPoints(pts)
    local maxGap, corner = 0, false
    for k = 2, #kp do
        local d = math.sqrt((kp[k][2] - kp[k - 1][2]) ^ 2 + (kp[k][3] - kp[k - 1][3]) ^ 2)
        maxGap = math.max(maxGap, d)
    end
    for _, p in ipairs(kp) do if p[2] == n + 240 and p[3] == w then corner = true end end
    return maxGap <= R.SEG_MAX and corner and #kp < #pts,
        string.format("%d von %d Punkten, grösster Abstand %.1f Yards, Ecke %s", #kp, #pts, maxGap, S(corner)),
        "weniger Punkte, <= 25 Yards, Ecke true"
end

IMPL.T237 = function()
    local R, Gr, Geo = LP.Recorder, LP.Graph, LP.Geo
    local ci, cn, cw = Geo:ToWorld(1414, 50, 50)
    if not ci or Geo:ContinentOf(1414) ~= 1414 then return NA, "Kontinentkarte Kalimdor nicht verfügbar" end
    local origPlayer, origVirt = Geo.Player, LP.Virtual.active
    local k = 0
    Geo.Player = function() k = k + 1 return ci, cn + k * 30, cw, 1414, 50, 50 + k * 0.1 end
    return Guard(function()
        LP.Virtual.active = false
        local recorded = 0
        WithSetting({ recordPaths = true }, function()
            NoIdle(function() for _ = 1, 4 do R:SamplePath() recorded = math.max(recorded, R:TrailCount()) end end)
        end)
        -- alte Kontinent-Kante in den Daten: nicht in den Wegdaten
        local a = Gr:AddNode(ci, cn - 500, cw - 500, 1414)
        local b = Gr:AddNode(ci, cn - 450, cw - 500, 1414)
        Gr:AddEdge(a, b, "r")
        local d = Gr:WegeData(nil, function(m) return m == 1414 end)
        return recorded == 0 and #d.zones == 0,
            string.format("aufgezeichnete Punkte %d, Wegdaten Kalimdor %d Zonen", recorded, #d.zones), "0, 0"
    end, function() Geo.Player, LP.Virtual.active = origPlayer, origVirt R:FlushTrail(true) end)
end

IMPL.T238 = function()
    local Gr, R = LP.Graph, LP.Recorder
    local d = LevelPilotData and LevelPilotData.N
    if type(d) ~= "table" or type(d[15350]) ~= "table" then return NA, "kein Datenpaket" end
    local saved = LP.db.npcPos
    return Guard(function()
        LP.db.npcPos = {
            [15350] = { 1456, 58.0, 76.7, t = 100, c = 1, o = { 1413, 46.7, 8.7 } },  -- alter Eintrag: erster Fundort
            [299901] = { 1412, 40, 40, t = 100, c = 1 },                               -- nicht im Datenpaket
        }
        -- 3.12.93 (Ingametest 3.12.91: T238 273 ms in einem Bild – Wegketten ALLER Zonen, gebraucht werden nur die NPC-Orte):
        -- ohne Wegketten (WegeData: noZones) und nur die beiden Karten der Test-NPCs (Ersatz npcPos aktiv, hier wird nicht abgegeben)
        local data = Gr:WegeData(nil, function(m) return m == 1456 or m == 1412 end, true)
        local byId = {}
        for _, e in ipairs(data.npc) do byId[e.id] = e end
        local w, x = byId[15350], byId[299901]
        local spawn = R.PackSpawn(15350, { 1456, 58.0, 76.7 })
        local ok = w and type(w.old) == "table" and #w.old == 2 and #w.new == 2 and w.oldMap == nil
            and math.abs(w.old[1] - 57.8) < 0.05 and math.abs(w.old[2] - 76.4) < 0.05
            and x and x.old == nil and x.nopack == true and spawn and spawn[1] == 1456
        return ok and true or false,
            string.format("15350 alt %s (Karte %s), 299901 nopack %s", w and w.old and (w.old[1] .. "," .. w.old[2]) or "?",
                S(w and w.oldMap or "gleich"), S(x and x.nopack)),
            "15350 alt 57.8,76.4 (Karte gleich), nopack true"
    end, function() LP.db.npcPos = saved end)
end

IMPL.T239 = function()
    local d = LevelPilotData and LevelPilotData.N
    if type(d) ~= "table" or not d[10666] then return NA, "kein Datenpaket" end
    local function near(id, map, x, y)
        local sp = LP.Recorder.PackSpawn(id, { map, x, y })
        return sp and sp[1] == map and math.abs(sp[2] - x) < 0.6 and math.abs(sp[3] - y) < 0.6 or false
    end
    -- 3.12.55 LW-5 E2: im Classic-Era-Client gelten fuer 10666/10881 die Questie-Orte (die Forever-Messung gilt nur Forever)
    local era = LP.Geo.EraFrame and LP.Geo.EraFrame() and LevelPilotData.eraFrame
    local a = era and near(10666, 1420, 43.1, 54.7) or (not era and near(10666, 1420, 52.8, 54.2))
    local b = era and near(10881, 1456, 44.3, 58.8) or (not era and near(10881, 1456, 56.6, 48.1))
    local c = near(15350, 1456, 58.0, 76.7)
    return a and b and c, string.format("10666 %s, 10881 %s, 15350 %s (Datenpaket %s, %s)", S(a), S(b), S(c), S(LevelPilotData.version), era and "Era-Orte" or "Forever-Orte"),
        "true, true, true"
end

------------------------------------------------------------------------
-- 3.12.18: eigene Tooltips neben dem Fenster
------------------------------------------------------------------------
IMPL.T240 = function()
    local UI = LP.UI
    -- reine Rechnung: Fenster 300 breit, Bildschirm 1920
    local s1, d1 = UI.TipSide(800, 1100, 700, 300, 650, 1920, 280)     -- Mitte -> rechts, 50 tiefer
    local s2 = UI.TipSide(1620, 1920, 700, 300, 650, 1920, 280)         -- rechter Rand -> links
    local s3 = UI.TipSide(100, 1850, 700, 300, 650, 1920, 280)          -- fast so breit wie der Bildschirm -> darunter
    local pure = s1 == "RIGHT" and d1 == -50 and s2 == "LEFT" and s3 == "BELOW"
    -- echter Knopf im Leitfenster mit eigenem Test-Tooltip (zeichnet nur auf)
    local frame = _G.LevelPilotFrame
    local btn
    for b in pairs(UI.buttons or {}) do
        if UI.WindowOf(b) == frame then btn = b break end
    end
    local rec = { points = {} }
    local fake = {
        SetOwner = function(_, o, a) rec.owner, rec.anchor = o, a end,
        ClearAllPoints = function() rec.points = {} end,
        SetPoint = function(_, p, rel, rp) rec.points[#rec.points + 1] = { p, rel, rp } end,
        GetEffectiveScale = function() return UIParent:GetEffectiveScale() end,
    }
    local anchored = "kein Knopf"
    if btn then
        UI.TipAnchor(btn, fake)
        local pt = rec.points[1]
        if UI.lastTipSide == "CURSOR" then
            anchored = "ohne Fensterlage (Maus)"
        else
            anchored = (rec.anchor == "ANCHOR_NONE" and pt and pt[2] == frame) and ("am Fenster, " .. tostring(UI.lastTipSide)) or "FALSCH"
        end
    end
    local ok = pure and anchored ~= "FALSCH"
    return ok, string.format("Mitte %s (%s), rechter Rand %s, breit %s; Knopf im Leitfenster: %s", S(s1), S(d1), S(s2), S(s3), anchored),
        "RIGHT (-50), LEFT, BELOW; am Fenster"
end

------------------------------------------------------------------------
-- 3.12.19: übrige Abfragen mit geschütztem Wert (Ergänzung zu T223)
------------------------------------------------------------------------
IMPL.T241 = function()
    local bait = { "LPTestKoeder Abfrage" }
    local fake = {}
    for _, f in ipairs({ "GetPlayerFacing", "IsIndoors", "IsResting", "GetUnitSpeed", "UnitLevel" }) do
        fake[f] = function() return bait end
    end
    local last0 = LP.lastLevel
    return Guard(function()
        LP.lastLevel = 17
        return WithSecret({ bait }, function()
            return WithEnv({ LP.Facing, LP.Indoors, LP.Resting, LP.UnitSpeed, LP.RealLevel }, fake, function()
                local facing, indoors, resting, speed, level = LP.Facing(), LP.Indoors(), LP.Resting(), LP.UnitSpeed(), LP:RealLevel()
                -- Benutzer dieser Abfragen laufen ohne Fehler
                local bad = {}
                for name, fn in pairs({
                    Caves = function() local i, n, w = LP.Geo:Player() if i then LP.Caves:At(i, n, w, nil, nil, true) end end,
                    Ruhe = function() if LP.Session.ExtraText then LP.Session:ExtraText() end end,
                    Messen = function() if LP.Measure and LP.Measure.Text then LP.Measure:Text() end end,
                }) do
                    local ok, err = pcall(fn)
                    if not ok then bad[#bad + 1] = name .. ": " .. tostring(err):sub(1, 60) end
                end
                local ok = facing == nil and indoors == false and resting == false and speed == nil and level == 17 and #bad == 0
                return ok, string.format("Richtung %s, drinnen %s, Erholung %s, Tempo %s, Stufe %s%s", S(facing), S(indoors), S(resting),
                    S(speed), S(level), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "nil, false, false, nil, 17 (zuletzt gelesen)"
            end)
        end)
    end, function() LP.lastLevel = last0 end)
end

------------------------------------------------------------------------
-- 3.12.21: GoldSentinelSync 2 und GoldSentinelTest 2 (Tests ersetzen nur GoldSentinelSync.api-Einträge)
------------------------------------------------------------------------
local function Sy() return _G.GoldSentinelSync end
-- api-Einträge vorübergehend ersetzen; eigene Einträge der Warteschlangen danach entfernen
local function WithSyncApi(repl, body)
    local S0 = Sy()
    if not S0 or type(S0.api) ~= "table" then return NA, "GoldSentinelSync fehlt" end
    local saved = {}
    for k, v in pairs(repl) do saved[k] = S0.api[k] S0.api[k] = v end
    local snap = LP.Comm:QueueSnapshot()
    return Guard(function() return body(S0) end, function()
        for k in pairs(repl) do S0.api[k] = saved[k] end
        LP.Comm:QueueRestore(snap)
    end)
end
local function Yes() return true end
local function No() return false end
-- Wege der eigenen neuen Einträge in der Warteschlange (Gilde/Gruppe) und im Netz
local function OwnDists(S0, q0, n0)
    local d = {}
    for i = q0 + 1, #S0.queue do local it = S0.queue[i] if it.prefix == "LvPilot2" then d[#d + 1] = it.dist end end
    local net = #(S0.netQueue or {}) - n0
    return d, net
end
-- einen Mitspieler mit Sync 2 ins Adressbuch (für das Netz); Rückgabe Aufräumfunktion
local function FakeNetPeer(S0, name)
    local old = S0.book[name]
    S0.book[name] = { seen = S0.api.time(), v = 2, src = "whisper", fail = 0, pause = 0 }
    return function() S0.book[name] = old end
end

IMPL.T242 = function()
    local Comm = LP.Comm
    return WithSetting({ shareGuild = true, shareGroup = true, shareChannel = true }, function()
        return WithSyncApi({ inGuild = Yes, inGroup = Yes, inRaid = No }, function(S0)
            local q0 = #S0.queue
            Comm:Broadcast({ "H\tLPTest242" })
            Comm:Hello()
            Comm:RequestZone(1411, true)
            local mark = ActMark()
            Comm:Rejoin()
            local joined = ActSince(mark)
            local dists, channel = {}, 0
            for i = q0 + 1, #S0.queue do
                local it = S0.queue[i]
                if it.prefix == "LvPilot2" then
                    dists[it.dist] = (dists[it.dist] or 0) + 1
                    local okDist = { GUILD = true, PARTY = true, RAID = true, WHISPER = true }
                    if not okDist[it.dist] then channel = channel + 1 end   -- jeder andere Weg (Kanal) ist falsch
                end
            end
            local n = (dists.GUILD or 0) + (dists.PARTY or 0)
            return n >= 6 and channel == 0 and joined == 0 and Comm.JoinChannel == nil,
                string.format("GUILD %d, PARTY %d, anderer Weg (Kanal) %d, Aktionen beim früheren Kanal-Beitritt %d", dists.GUILD or 0,
                    dists.PARTY or 0, channel, joined), "GUILD und PARTY je 3, Kanal 0, 0"
        end)
    end)
end

IMPL.T243 = function()
    local Comm = LP.Comm
    local function run(guild, group, net, inGuild, inGroup)
        return WithSetting({ shareGuild = guild, shareGroup = group, shareChannel = net }, function()
            return WithSyncApi({ inGuild = inGuild and Yes or No, inGroup = inGroup and Yes or No, inRaid = No }, function(S0)
                local q0, n0 = #S0.queue, #(S0.netQueue or {})
                local drop0 = S0.stats.dropped.nopath or 0
                local ok = Comm:Queue("H\tLPTest243")
                local d, net2 = OwnDists(S0, q0, n0)
                local nopath = (S0.stats.dropped.nopath or 0) - drop0
                S0.stats.dropped.nopath = drop0 > 0 and drop0 or nil
                return table.concat(d, "+") .. (net2 > 0 and "+NETZ" or ""), ok, nopath
            end)
        end)
    end
    local a = run(true, true, false, true, false)
    local b = run(true, true, false, false, true)
    local c, okc, dropc = run(true, true, false, false, false)
    local d = run(false, true, false, true, true)
    -- 3.12.22: Einstellungen mit Netz (ein Netz-Mitspieler bekannt, in Gilde und Gruppe)
    local S0 = Sy()
    local undo = S0 and FakeNetPeer(S0, "Testa9 Beispiel") or function() end
    local oldNet = S0 and S0.NET
    if S0 then S0.NET = true end
    local e, f, g, h = "", "", "", ""
    Guard(function()
        e = run(false, false, true, true, true)
        f = run(true, false, true, true, true)
        g = run(false, true, true, true, true)
        h = run(true, true, true, true, true)
    end, function() undo() if S0 then S0.NET = oldNet end end)
    local ok = a == "GUILD" and b == "PARTY" and c == "" and okc == false and dropc == 1 and d == "PARTY"
        and e == "" and f == "GUILD" and g == "PARTY" and h == "GUILD+PARTY+NETZ"
    return ok, string.format("Gilde: %s · Gruppe: %s · ohne beides: %s (gesendet %s, kein Weg %d) · nur Gruppe erlaubt: %s"
        .. " · nur Netz: %s · Gilde+Netz: %s · Gruppe+Netz: %s · alles: %s",
        a, b, c == "" and "nichts" or c, S(okc), dropc or 0, d, e == "" and "nichts" or e, f, g, h),
        "GUILD · PARTY · nichts (false, 1) · PARTY · nichts · GUILD · PARTY · GUILD+PARTY+NETZ"
end

IMPL.T244 = function()
    local S0 = Sy()
    if not S0 or not S0.OnChannelNotice then return NA, "GoldSentinelSync fehlt" end
    local before = S0.stats.channelRefused or 0
    return Guard(function()
        S0.OnChannelNotice("NOT_ALLOWED_IN_CHANNEL")
        S0.OnChannelNotice("YOU_JOINED")
        local after = S0.stats.channelRefused
        local lines = table.concat(LP.Comm:DiagLines(), "\n")
        local shown = lines:find("Kanal verweigert " .. after, 1, true) ~= nil
        local proto = LP.Protocol:Text():find("SYNC", 1, true) ~= nil
        return after == before + 1 and shown and proto, string.format("gezählt +%d, in der Diagnose %s, im Protokoll %s",
            after - before, S(shown), S(proto)), "+1, true, true"
    end, function() S0.stats.channelRefused = before end)
end

IMPL.T245 = function()
    local ep = LP.Comm.ep
    if not ep then return false, "LevelPilot nicht bei GoldSentinelSync angemeldet", "angemeldet" end
    return WithCounter(LP.Comm, "Receive", function(n)
        local bad = 0
        for _, fn in ipairs(ep.handlers) do
            local ok = pcall(fn, "H\t3.12.0\t5\t10", nil, "GUILD")
            if not ok then bad = bad + 1 end
        end
        local mark = ActMark()
        LP.Comm:OnZoneRequest(nil, 1411)
        local replies = ActSince(mark)
        return n() == 1 and bad == 0 and replies == 0, string.format("verarbeitet %d, Fehler %d, Antwort ohne Absender %d", n(), bad, replies),
            "1, 0, 0"
    end)
end

IMPL.T246 = function()
    local recv0 = LP.db.net.recv or 0
    return WithCounter(LP.Comm, "Receive", function(n)
        Deliver("LvPilot2", "H\t3.11.0\t5\t10", "GUILD", "LP9Alt-Test")
        local a = n()
        Deliver("LvPilotG", "S\t5\t10\tGOTO\t0\tLPTest", "PARTY", "LP9Alt-Test")
        local member = LP.Group.members["LP9Alt"] ~= nil
        LP.Group.members["LP9Alt"] = nil
        LP.db.net.recv = recv0
        return a == 1 and member, string.format("Daten ohne Kopf verstanden %d, Gruppe ohne Kopf %s", a, S(member)), "1, true"
    end)
end

IMPL.T247 = function()
    local S0 = Sy()
    if not S0 or not S0.Ping then return NA, "GoldSentinelSync fehlt" end
    local realNow, realSend = S0.api.now, S0.api.send
    local t = realNow()
    local sent = 0
    -- Ping und eigene Nachrichten nur zählen; Nachrichten anderer Addons gehen normal hinaus
    local function send(prefix, ...)
        if prefix == S0.CTRL or OWN_PREFIX[prefix] then sent = sent + 1 return true end
        return realSend(prefix, ...)
    end
    return WithSyncApi({ now = function() return t end, inGuild = Yes, inGroup = No, inRaid = No, send = send }, function()
        local out = {}
        LP.Comm:SyncTest(function(line) out[#out + 1] = line end)
        for _ = 1, 3 do S0.Pump(true) end
        t = t + S0.PING_WAIT + 1
        S0.Tick()
        local last = out[#out] or ""
        local ok = #out == 2 and last:find("%d") ~= nil and last ~= out[1]
        return ok, string.format("%d Zeilen: %s (Ping gesendet %d)", #out, table.concat(out, " | "), sent),
            "2 Zeilen, zweite „N Antworten (Gilde a, Gruppe b)“"
    end)
end

IMPL.T248 = function()
    local S0 = Sy()
    local v = S0 and tonumber(S0.VERSION)
    return v ~= nil and v >= 2, "GoldSentinelSync " .. S(v), "Version >= 2"
end

IMPL.T249 = function()
    local S0 = Sy()
    if not S0 or not S0.OnAddonMessage then return NA, "GoldSentinelSync fehlt" end
    local store = LP.Acc().gsSync      -- 3.12.56: Bereich der Spielversion
    local name = "Testa9 Beispiel"
    local old = S0.book[name]
    return Guard(function()
        S0.OnAddonMessage("LvPilot2", "#S1:lptst249:1:H\t3.12.21\t1\t1", "GUILD", name)
        local inBook = S0.book[name] ~= nil
        local own = type(store) == "table" and type(store.book) == "table"
        -- 3.12.90 (Ingametest 3.12.89 T249: "LevelPilotDB.gsSync false … Speicher eines anderen GoldSentinel-Addons"): der gemeinsame
        -- Baustein GoldSentinelSync gehört dem Addon, das ihn zuerst geladen hat; dann speichert er in dessen Daten, nicht in
        -- LevelPilotDB (so gebaut). Gespeichert ist richtig, wenn der Eintrag in dem Speicher steht, den der Baustein benutzt.
        local other = S0.store ~= store and type(S0.store) == "table" and type(S0.store.book) == "table"
        local stored = (own and store.book[name] ~= nil) or (other and S0.store.book[name] ~= nil)
        return inBook and stored and true or false, string.format("gelernt %s, LevelPilotDB.gsSync %s, gespeichert %s%s", S(inBook), S(own),
            S(stored), S0.store == store and "" or " (Speicher eines anderen GoldSentinel-Addons)"), "true, true, true"
    end, function() S0.book[name] = old S0.peers.lptst249 = nil end)
end

IMPL.T250 = function()
    local ep = LP.Comm.ep
    local S0 = Sy()
    if not ep or not S0 then return NA, "GoldSentinelSync fehlt" end
    return WithSyncApi({ inGuild = Yes, inGroup = No, inRaid = No }, function()
        local undo = FakeNetPeer(S0, "Testa9 Beispiel")
        local oldNet = S0.NET
        return Guard(function()
            S0.NET = true
            local function grow(opts)
                local n0 = #S0.netQueue
                ep:Send("H\tLPTest250", opts)
                return #S0.netQueue - n0
            end
            local all, nonet, guild = grow(nil), grow({ net = false }), grow({ scope = "guild" })
            return all >= 1 and nonet == 0 and guild == 0, string.format("normal %d, net=false %d, scope guild %d", all, nonet, guild),
                ">= 1, 0, 0"
        end, function() undo() S0.NET = oldNet end)
    end)
end

IMPL.T251 = function()
    local S0 = Sy()
    if not S0 then return NA, "GoldSentinelSync fehlt" end
    local undo = FakeNetPeer(S0, "Testa9 Beispiel")
    return Guard(function()
        local text = table.concat(LP.Comm:DiagLines(), "\n") .. "\n" .. LP.Protocol:Text()
        local me = UnitName("player")
        local netz = text:find("NETZ", 1, true) ~= nil
        local leak = text:find("Testa9 Beispiel", 1, true) ~= nil
            or (type(me) == "string" and not LP.Game.IsSecret(me) and me ~= "" and text:find(me, 1, true) ~= nil)
        for name in pairs(S0.book) do
            if type(name) == "string" and #name > 2 and text:find(name, 1, true) then leak = true end
        end
        return netz and not leak, string.format("NETZ %s, Spielernamen %s", S(netz), leak and "GEFUNDEN" or "keine"), "true, keine"
    end, undo)
end

IMPL.T252 = function()
    local g = _G.GoldSentinelTest
    local v = g and tonumber(g.version)
    return v ~= nil and v >= 2, "GoldSentinelTest " .. S(v), "Version >= 2"
end

IMPL.T253 = function()
    local g = _G.GoldSentinelTest
    if not g or not g.Setting then return NA, "GoldSentinelTest 2 fehlt" end
    local old = g.Setting("consent")
    local sh = LevelPilotDB.gsTest and LevelPilotDB.gsTest.share
    local n0 = sh and type(sh.outbox) == "table" and #sh.outbox or 0
    local e0, last0 = LP.errorCount, LP.lastError
    return Guard(function()
        g.SetSetting("consent", false)
        LP:Safe("Testroutine", function() error("LP-Testfehler Ausgang", 0) end)
        sh = LevelPilotDB.gsTest and LevelPilotDB.gsTest.share
        local n1 = sh and type(sh.outbox) == "table" and #sh.outbox or 0
        return n1 == n0, string.format("Ausgang vorher %d, nach dem Fehler %d (Zustimmung %s)", n0, n1, S(old)), "unverändert"
    end, function()
        g.SetSetting("consent", old)
        TR.ForgetTestErrors(e0, last0)
    end)
end

------------------------------------------------------------------------
-- 3.12.22: Nachprüfung 3.12.21
------------------------------------------------------------------------
IMPL.T254 = function()
    local Comm, Soc = LP.Comm, LP.Social
    local S0 = Sy()
    if not S0 or not Comm.ep then return NA, "GoldSentinelSync fehlt" end
    local origin = "Testa9 Beispiel"
    local hash = Comm.OriginKey(origin)
    return WithSetting({ findPartners = true, shareGuild = true, shareGroup = true, shareChannel = true }, function()
        return WithSyncApi({ inGuild = Yes, inGroup = Yes, inRaid = No }, function()
            local undo = FakeNetPeer(S0, "LP9Netz Partner")
            local oldNet, saved = S0.NET, {}
            for k, v in pairs(Soc.partners) do saved[k] = v end
            return Guard(function()
                S0.NET = true
                wipe(Soc.partners)
                local zone = 0
                local origZ = Comm.OnZoneRequest
                Comm.OnZoneRequest = function() zone = zone + 1 end
                local function count() local n = 0 for _ in pairs(Soc.partners) do n = n + 1 end return n end
                -- weitergegeben übers Netz (Absender = Weitergeber)
                Deliver("LvPilot2", "#S2:lpt254a:1:1:E\t1413\t20\t123\t" .. hash, "WHISPER", "LP9Weiter-Test")
                Deliver("LvPilot2", "#S2:lpt254a:2:1:Z\t1413\t20\t" .. hash, "WHISPER", "LP9Weiter-Test")
                -- ältere Version ohne Prüfsumme, geflüstert und vom Weitergeber in seine Gilde gebracht (3.12.23)
                Deliver("LvPilot2", "E\t1413\t20\t123", "WHISPER", "LP9Weiter-Test")
                Deliver("LvPilot2", "#S1:lpt254c:1:E\t1413\t20\t123", "GUILD", "LP9Weiter-Test")
                Deliver("LvPilot2", "#S1:lpt254c:2:Z\t1413\t20", "GUILD", "LP9Weiter-Test")
                local relayed, relayedZ = count(), zone
                -- vom Urheber selbst in der Gilde
                Deliver("LvPilot2", "#S1:lpt254b:1:E\t1413\t20\t123\t" .. hash, "GUILD", origin .. "-Realm")
                Deliver("LvPilot2", "#S1:lpt254b:2:Z\t1413\t20\t" .. hash, "GUILD", origin)
                local direct, directZ = count() - relayed, zone - relayedZ
                Comm.OnZoneRequest = origZ
                -- eigenes Senden von E und Z: nichts ins Netz
                local n0 = #S0.netQueue
                local enc = Soc.Encode
                Soc.Encode = function() return "E\t1413\t20\t123\t" .. Comm.OwnOrigin() end
                Soc:Announce()
                Soc.Encode = enc
                Comm:RequestZone(1413, true)
                local netAdded = #S0.netQueue - n0
                local ok = relayed == 0 and relayedZ == 0 and direct == 1 and directZ == 1 and netAdded == 0
                return ok, string.format("weitergegeben: Partner %d, Anfrage %d · vom Urheber: Partner %d, Anfrage %d · eigene ins Netz %d",
                    relayed, relayedZ, direct, directZ, netAdded), "0, 0 · 1, 1 · 0"
            end, function()
                undo() S0.NET = oldNet
                wipe(Soc.partners) for k, v in pairs(saved) do Soc.partners[k] = v end
            end)
        end)
    end)
end

IMPL.T255 = function()
    local Comm = LP.Comm
    local S0 = Sy()
    if not S0 then return NA, "GoldSentinelSync fehlt" end
    local caves = LP.db.caves
    local fake = {}
    for k = 1, 60 do
        fake["lpt255_" .. k] = { i = 1, en = 1000 + k, ew = 2000 + k, cn = 1010 + k, cw = 2010 + k, m = 1412, r = 60, net = true }
    end
    return WithSyncApi({}, function()
        return Guard(function()
            LP.db.caves = fake
            local q0 = #S0.queue
            local sent = Comm:ReplyZone("LP9Frager-Test", 1412) or 0
            local inQueue = #S0.queue - q0
            -- volle Warteschlange: keine Antwort
            for _ = 1, Comm.REPLY_QUEUE_LIMIT + 1 do S0.queue[#S0.queue + 1] = { prefix = "LPTestFremd", msg = "x", dist = "GUILD" } end
            local q1 = #S0.queue
            local sent2 = Comm:ReplyZone("LP9Frager2-Test", 1412) or 0
            local full = #S0.queue - q1
            for i = #S0.queue, 1, -1 do if S0.queue[i].prefix == "LPTestFremd" then table.remove(S0.queue, i) end end
            return sent > 0 and sent <= Comm.REPLY_MAX and inQueue <= Comm.REPLY_MAX and sent2 == 0 and full == 0,
                string.format("Antwort %d Nachrichten (Warteschlange +%d) · bei voller Warteschlange %d", sent, inQueue, sent2),
                "1–25 · 0"
        end, function() LP.db.caves = caves end)
    end)
end

------------------------------------------------------------------------
-- 3.12.96 (Befund HOCH der Prüf-Sitzung 18.11. 13:55): T254 lieferte Testnachrichten an das ECHTE GoldSentinelSync; das gemeinsame
-- Adressbuch (liegt oft in der Datenbank eines ANDEREN Addons – die Sandbox von LevelPilot sieht es nicht) merkte sich die Absender,
-- und das Flüster-Netz flüsterte danach echt an sie. Jetzt: der ganze Zustand von Sync wird um jede Prüfung, die Sync berührt,
-- gesichert und danach GENAU wiederhergestellt (in dieselben Tabellen – das Adressbuch ist zugleich die Ablage des anderen Addons).
-- counter bleibt (zurückgesetzt kämen eigene neue Nachrichten bei anderen als Dubletten an).
------------------------------------------------------------------------
TR.ENV_SEC = 10                -- 3.12.99: Umgebungsmessung vor der Testroutine (Hinweis 18.11. 19:55)
TR.SYNC_TABLES = { "book", "peers", "seen", "seenList", "stats", "whispered", "hideUntil", "netQueue", "queue", "netWin", "pings" }
TR.SYNC_VALUES = { "NET", "lastGossip", "lastIntro", "lastReply", "lastSend", "lastHello", "helloAt" }
local function SyncCopy(v, seen)
    if type(v) ~= "table" then return v end
    seen = seen or {}
    if seen[v] then return seen[v] end
    local c = {}
    seen[v] = c
    for k, x in pairs(v) do c[k] = SyncCopy(x, seen) end
    return c
end
function TR.SyncSnapshot(S0)
    local snap = { t = {}, v = {} }
    for _, k in ipairs(TR.SYNC_TABLES) do if type(S0[k]) == "table" then snap.t[k] = SyncCopy(S0[k]) end end
    for _, k in ipairs(TR.SYNC_VALUES) do snap.v[k] = S0[k] end
    return snap
end
function TR.SyncRestore(S0, snap)
    for k, copy in pairs(snap.t) do
        local cur = S0[k]
        if type(cur) == "table" then
            for kk in pairs(cur) do cur[kk] = nil end
            for kk, vv in pairs(copy) do cur[kk] = SyncCopy(vv) end
        else
            S0[k] = SyncCopy(copy)
        end
    end
    for _, k in ipairs(TR.SYNC_VALUES) do S0[k] = snap.v[k] end
end
-- gleicher Inhalt (für Prüfung "vor/nach gleich")
local function SyncSame(a, b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= "table" then return a == b end
    for k, v in pairs(a) do if not SyncSame(v, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end
TR.SyncSame = SyncSame
local function WithSyncState(body)
    local S0 = Sy()
    if not S0 then return body() end
    local snap = TR.SyncSnapshot(S0)
    return Guard(body, function() TR.SyncRestore(S0, snap) end)
end
TR.WithSyncState = WithSyncState
-- jede Prüfung, die Nachrichten an Sync liefert oder seinen Zustand ändert
TR.SYNC_TESTS = { "T63", "T92", "T169", "T242", "T243", "T244", "T245", "T246", "T247", "T249", "T250", "T251", "T254", "T255" }
-- 3.12.97 (Hinweis Sync 3, 18.11. 15:45): Sync 3 lernt während einer Testroutine nichts aus eingehenden Nachrichten. Prüfungen, die
-- genau dieses Lernen prüfen, setzen GoldSentinelSync.testLearn = true nur für ihre Dauer (Sync 2: Feld ohne Wirkung). Im Nachbau mit
-- Sync 3 ohne testLearn rot: T249, T357 – sonst keine (T254 prüft die Weitergabe, nicht das Lernen: grün mit und ohne).
TR.SYNC_LEARN = { T249 = true, T357 = true }
local function WithTestLearn(fn)
    local S0 = Sy()
    if not S0 then return fn() end
    local old = S0.testLearn
    S0.testLearn = true
    return Guard(fn, function() S0.testLearn = old end)
end
TR.WithTestLearn = WithTestLearn
for _, id in ipairs(TR.SYNC_TESTS) do
    local fn = IMPL[id]
    if fn and TR.SYNC_LEARN[id] then
        IMPL[id] = function() return WithSyncState(function() return WithTestLearn(fn) end) end
    elseif fn then
        IMPL[id] = function() return WithSyncState(fn) end
    end
end

-- Sicherheitsnetz nach JEDER Prüfung: kommt ein Testname (alt oder neu) ins Adressbuch, wird er sofort entfernt und als Fehler gezählt
function TR.SyncLeakCheck(id, before)
    local S0 = Sy()
    if not S0 or type(S0.book) ~= "table" then return 0 end
    local n = 0
    for name in pairs(S0.book) do
        if LP.Comm.IsSyncTestName(name) and not (before and before[name]) then
            S0.book[name] = nil
            n = n + 1
            TR.syncLeaks = TR.syncLeaks or {}
            TR.syncLeaks[#TR.syncLeaks + 1] = tostring(id) .. ": " .. name
        end
    end
    return n
end
function TR.SyncTestNamesIn()
    local S0 = Sy()
    local set = {}
    if S0 and type(S0.book) == "table" then
        for name in pairs(S0.book) do if LP.Comm.IsSyncTestName(name) then set[name] = true end end
    end
    return set
end

-- T358 (Nachprüfung LP-95-1): Sicherung in Portionen bricht ab, sobald eine virtuelle Reise läuft (nie die Überlagerung kopieren, nie die
-- Reise des Spielers abbrechen). Kleine Ersatz-Daten (300 Quests) statt der echten; ohne Abgabe (die Ersatz-Tabellen sieht sonst niemand).
IMPL.T358 = function()
    local B, V = LP.Backup, LP.Virtual
    if not (B and B.SaveCopy and B.ABORT_VIRTUAL and V) then return false, "fehlt", "Backup.ABORT_VIRTUAL" end
    local function fakeDb()
        local q = {}
        for i = 1, 300 do q[900000 + i] = { n = "LPTest" .. i, l = 10 } end
        return { qdb = q, vendors = {}, taxi = { [1] = { n = "LPTestFlug" } }, caves = {}, calib = {}, npcPos = {}, graph = { nodes = {} } }
    end
    local r = {}
    local saved = { acc = LP.Acc, char = _G.LevelPilotCharDB, yield = LP.Yield, active = V.active, abort = V.Abort }
    local ok, err = pcall(function()
        local aborted = 0
        V.Abort = function() aborted = aborted + 1 end                  -- nie die echte Reise anfassen
        local function run(startAfter)
            local db, char = fakeDb(), { backup = { t = 1, count = 1, data = nil } }
            local old = char.backup
            LP.Acc = function() return db end
            _G.LevelPilotCharDB = char
            local calls = 0
            LP.Yield = function() calls = calls + 1 if startAfter and calls == startAfter then V.active = true end end
            V.active = false
            local okRun, e = pcall(B.SaveCopy, B, true)
            V.active = false
            return okRun, e, char.backup == old, char.backup, calls
        end
        -- 1) Reise startet nach der ersten Abgabe: abgebrochen, alte Sicherung bleibt, Reise nicht abgebrochen
        local ok1, e1, kept1 = run(1)
        r.abortMid = not ok1 and e1 == B.ABORT_VIRTUAL and kept1 and aborted == 0
        -- 2) Reise läuft schon beim Start: sofort abgebrochen
        V.active = true
        local db, char = fakeDb(), { backup = { t = 1, count = 1 } }
        local old = char.backup
        LP.Acc = function() return db end
        _G.LevelPilotCharDB = char
        LP.Yield = function() end
        local ok2, e2 = pcall(B.SaveCopy, B, true)
        V.active = false
        r.abortStart = not ok2 and e2 == B.ABORT_VIRTUAL and char.backup == old and aborted == 0
        -- 3) Gegenprobe ohne Reise: fertig, neue Sicherung mit allen 301 Einträgen, mindestens eine Abgabe
        local ok3, _, kept3, bk3, calls3 = run(nil)
        r.full = ok3 and not kept3 and type(bk3) == "table" and bk3.count == 301 and calls3 >= 1
    end)
    LP.Acc, _G.LevelPilotCharDB, LP.Yield, V.active, V.Abort = saved.acc, saved.char, saved.yield, saved.active, saved.abort
    if not ok then error(err, 0) end
    local good = r.abortMid and r.abortStart and r.full
    return good and true or false, ("Reise startet in der Pause: abgebrochen, alte Sicherung bleibt %s · Reise läuft beim Start: abgebrochen %s · ohne Reise: fertig, 301 Einträge %s")
        :format(S(r.abortMid), S(r.abortStart), S(r.full)), "true · true · true"
end

-- T359 (Nachprüfung LP-95-2): andere Verbindungen bei gleicher Knotenzahl und Gradsumme, andere Mess-Konstanten -> andere Kennung
IMPL.T359 = function()
    local G = LP.Graph
    if not (G.DetourSig and G.EdgeTerm) then return false, "fehlt", "Graph.DetourSig/EdgeTerm" end
    -- zwei Netze mit gleichen Knoten 1..4 und je 2 Verbindungen: 1–2, 3–4 gegen 1–3, 2–4 (Gradsumme gleich 4)
    local function edgeSum(pairs_)
        local s0 = 0
        for _, p in ipairs(pairs_) do s0 = s0 + G.EdgeTerm(p[1], p[2]) + G.EdgeTerm(p[2], p[1]) end   -- beide Richtungen wie adj
        return s0
    end
    local a = G.DetourSig(4, 10, 4, 0, edgeSum({ { 1, 2 }, { 3, 4 } }))
    local b = G.DetourSig(4, 10, 4, 0, edgeSum({ { 1, 3 }, { 2, 4 } }))
    local p0 = G.DETOUR_PAIRS
    G.DETOUR_PAIRS = p0 + 1
    local c = G.DetourSig(4, 10, 4, 0, edgeSum({ { 1, 2 }, { 3, 4 } }))
    G.DETOUR_PAIRS = p0
    local d = G.DetourSig(4, 10, 4, 0, edgeSum({ { 1, 2 }, { 3, 4 } }))
    local ok = a ~= b and a ~= c and a == d and (G.DETOUR_CACHE_VER or 0) >= 2
    return ok, ("andere Verbindungen -> andere Kennung %s · andere Paarzahl -> andere Kennung %s · gleich -> gleich %s · Version %s")
        :format(S(a ~= b), S(a ~= c), S(a == d), S(G.DETOUR_CACHE_VER)), "true · true · true · 2"
end

-- T360 (3.12.97, Ingametest 3.12.95 Bilder über 40 ms): schnelleres Entpacken der Geländekarte, Dungeon-Quests und Netz-Statistik im
-- Zwischenspeicher – je gleiches Ergebnis wie bisher (Gegenproben)
IMPL.T360 = function()
    local T, P, G = LP.Terrain, LP.Planner, LP.Graph
    if not (T and T.DecodeInto and T.DecodeOld and P.DungeonQuestIds and P.DungeonQuestsReset) then return false, "fehlt", "3.12.97" end
    local r = {}
    -- 1) Entpacken: neu = alt für bis zu 3 Karten des Datenpakets; Gegenprobe: ein Zeichen anders -> Ergebnis anders
    local d = _G.LevelPilotData
    local maps, same, cells = 0, true, 0
    if type(d) == "table" and type(d.T) == "table" then
        local keys = {}
        for m in pairs(d.T) do keys[#keys + 1] = m end
        table.sort(keys)
        for i = 1, math.min(3, #keys) do
            local str = d.T[keys[i]]
            local a = T.DecodeInto({}, str)
            TR.Safe("T360")
            local b = T.DecodeOld({}, str)
            TR.Safe("T360")
            for k = 0, #str * 3 - 1 do if a[k] ~= b[k] then same = false end end
            cells = cells + #str * 3
            maps = maps + 1
            TR.Safe("T360")
        end
        local str = d.T[keys[1]]
        if str then
            local ch = str:sub(1, 1) == "A" and "B" or "A"
            local alt = T.DecodeInto({}, ch .. str:sub(2))
            local org = T.DecodeInto({}, str)
            r.gegen = alt[0] ~= org[0] or alt[1] ~= org[1] or alt[2] ~= org[2]
        end
    end
    r.decode = maps == 0 or same
    -- 2) Dungeon-Übersicht: aus dem Zwischenspeicher gleich wie frisch gesammelt
    local function sig(list)
        local t = {}
        for _, e in ipairs(list) do t[#t + 1] = ("%s:%d/%d/%d"):format(tostring(e.area), e.open, e.log, e.done) end
        table.sort(t)
        return table.concat(t, ",")
    end
    -- 3.12.98 (Nachbau: T360 52,5 ms in einem Bild): als freigegebene Rechnung (Sammeln über alle Quests gibt mit "svc" ab)
    local function ov() local ok, v = PCallY(Coop, P.DungeonOverview, P) if not ok then error(v, 0) end return v end
    local function ids() local ok, v = PCallY(Coop, P.DungeonQuestIds) if not ok then error(v, 0) end return v end
    local a1 = sig(ov())
    local l1 = ids()
    local l2 = ids()
    r.cached = l1 == l2
    TR.Safe("T360")
    P.DungeonQuestsReset()
    local a2 = sig(ov())
    r.reset = ids() ~= l1
    r.dungeon = a1 == a2 and a1 ~= ""
    TR.Safe("T360")
    -- 3) Statistik: zweimal abgefragt gleich (3.12.98: kein frisches Zählen hier – alle Kanten am Stück, Nachbau 11,6 ms in einem
    -- Bild, nicht sicher teilbar; das erste Stats() nach Ablauf/Änderung zählt ohnehin frisch)
    TR.Safe("T360")
    local s1 = G:Stats()
    TR.Safe("T360")
    local s2 = G:Stats()
    r.stats = s1.edges == s2.edges and s1.yards == s2.yards and s1.nodes == s2.nodes
    local good = r.decode and (maps == 0 or r.gegen) and r.cached and r.reset and r.dungeon and r.stats
    return good and true or false, ("Entpacken neu = alt %s (%d Karten, %d Zellen), Gegenprobe anders %s · Dungeon-Quests gemerkt %s, nach Zurücksetzen neu %s, Übersicht gleich %s · Statistik zweimal gleich %s (%d Kanten)")
        :format(S(r.decode), maps, cells, S(r.gegen), S(r.cached), S(r.reset), S(r.dungeon), S(r.stats), s1.edges or -1),
        "true · true · true, true, true · true"
end

-- T361 (3.12.98, Ingametest 3.12.97 T150): Nachbarzählung der Questgeber über ein Raster = bisherige Zählung (jede mit jeder)
IMPL.T361 = function()
    local P = LP.Planner
    if not (P.HubCounts and P.HubCountsOld) then return false, "fehlt", "P.HubCounts" end
    local seed = 12345
    local function rnd() seed = (seed * 16807) % 2147483647 return seed / 2147483647 end
    local acc = {}
    for i = 1, 150 do                                   -- 3.12.98: 150 statt 300 (die alte Zählung ist jede mit jeder)
        local inst = i % 7 == 0 and 1 or 0
        local t = { inst = inst, n = 1000 + rnd() * 1500, w = -2000 + rnd() * 1500 }
        if i % 50 == 0 then t.n, t.w = nil, nil end                           -- ohne Ort
        acc[#acc + 1] = { t = t }
    end
    -- Grenzfälle: genau 250 yd (zählt), knapp darüber (zählt nicht), auf Zellgrenzen, negative Koordinaten
    acc[#acc + 1] = { t = { inst = 0, n = 500, w = 500 } }
    acc[#acc + 1] = { t = { inst = 0, n = 750, w = 500 } }
    acc[#acc + 1] = { t = { inst = 0, n = 500, w = 750.000001 } }
    acc[#acc + 1] = { t = { inst = 0, n = -250, w = -250 } }
    acc[#acc + 1] = { t = { inst = 0, n = 0, w = -250 } }
    acc[#acc + 1] = { t = { inst = 1, n = 500, w = 500 } }               -- andere Ebene, gleicher Ort
    local a = P.HubCounts(acc)
    TR.Safe("T361")
    local b = P.HubCountsOld(acc)
    TR.Safe("T361")
    local diff, n, maxC = 0, 0, 0
    for _, x in ipairs(acc) do
        if a[x] ~= b[x] then diff = diff + 1 end
        if a[x] then n = n + 1 maxC = math.max(maxC, a[x]) end
    end
    local e1, e2, e3 = acc[#acc - 5], acc[#acc - 4], acc[#acc - 3]
    local edge = a[e1] ~= nil and b[e1] == a[e1]
    return diff == 0 and n > 0 and edge, ("%d Annahmen mit Ort, abweichend %d, grösste Gruppe %d · Grenzfälle gleich %s"):format(n, diff, maxC, S(edge)),
        "abweichend 0"
end

-- T357: Prüfungen liefern an Sync, ohne dass sich sein Zustand ändert (Gegenprobe: ohne Hülle lernt Sync den Absender)
IMPL.T357 = function()
    local S0 = Sy()
    if not S0 or not S0.OnAddonMessage or not LP.Comm.ep then return NA, "GoldSentinelSync fehlt" end
    local name = "LP9Probe-Test"
    local r = {}
    -- Name in die Liste der Testnamen (für die Bereinigung und das Sicherheitsnetz) – nur für diese Prüfung
    do
        local before = TR.SyncSnapshot(S0)
        WithSyncState(function()
            Deliver("LvPilot2", "#S1:lpt357a:1:H\t3.12.96\t1\t1", "GUILD", name)
            Deliver("LvPilot2", "#S2:lpt357b:1:1:H\t3.12.96\t1\t1", "WHISPER", name)
            r.learnedInside = S0.book[name] ~= nil
        end)
        local after = TR.SyncSnapshot(S0)
        r.same = SyncSame(before.t, after.t) and SyncSame(before.v, after.v)
        r.book = S0.book[name] == nil
        -- Sync 3: ohne testLearn lernt Sync während der Testroutine nichts (Schutz der gemeinsamen Datei); Sync 2 lernt
        local ver = tonumber(S0.VERSION) or 0
        S0.testLearn = false
        WithSyncState(function()
            Deliver("LvPilot2", "#S1:lpt357d:1:H\t3.12.97\t1\t1", "GUILD", name)
            r.held = S0.book[name] == nil
        end)
        S0.testLearn = true
        r.heldOk = (ver >= 3 and r.held) or (ver < 3 and not r.held)
        -- Gegenprobe ohne Hülle: Sync lernt den Absender (so kam es zum Befund) – danach von Hand zurück
        Deliver("LvPilot2", "#S1:lpt357c:1:H\t3.12.96\t1\t1", "GUILD", name)
        r.learnedRaw = S0.book[name] ~= nil
        TR.SyncRestore(S0, before)
        r.cleanAgain = S0.book[name] == nil and SyncSame(before.t, TR.SyncSnapshot(S0).t)
        -- Bereinigung beim Laden: entfernt genau die Testnamen, sonst nichts
        local keep = "Normalspieler-Realm"
        S0.book["LPWeiter-Test"] = { seen = 1, v = 2, fail = 0, pause = 0, src = "net" }
        S0.book["Testa Beispiel-Realm"] = { seen = 1, v = 2, fail = 0, pause = 0, src = "guild" }
        S0.book[keep] = { seen = 1, v = 2, fail = 0, pause = 0, src = "guild" }
        local c0 = LP.Comm.syncCleaned or 0
        local removed = LP.Comm:CleanSyncBook()
        r.removed = removed
        r.kept = S0.book[keep] ~= nil
        LP.Comm.syncCleaned = c0
        TR.SyncRestore(S0, before)
        r.final = SyncSame(before.t, TR.SyncSnapshot(S0).t)
        local ok = r.learnedInside and r.same and r.book and r.heldOk and r.learnedRaw and r.cleanAgain and r.removed == 2 and r.kept and r.final
        return ok and true or false, ("in der Hülle gelernt %s, danach Zustand gleich %s, Name weg %s · Sync %d ohne testLearn: nichts gelernt %s"
            .. " · Gegenprobe ohne Hülle gelernt %s, zurück %s · Bereinigung entfernt %d, echter Name bleibt %s · Ende gleich %s")
            :format(S(r.learnedInside), S(r.same), S(r.book), ver, S(r.held), S(r.learnedRaw), S(r.cleanAgain), r.removed or -1, S(r.kept),
            S(r.final)), "true, true, true · Sync 3: true (Sync 2: false) · true, true · 2, true · true"
    end
end
do local fn = IMPL.T357 IMPL.T357 = function() return WithTestLearn(fn) end end     -- 3.12.97: prüft das Lernen (testLearn)


IMPL.T256 = function()
    local Comm = LP.Comm
    return WithSyncApi({ inGuild = No, inGroup = No, inRaid = No }, function()
        local key = "lpt256"
        local first = WithSetting({ shareGuild = true, shareGroup = true, shareChannel = false }, function()
            return Comm:Broadcast({ "H\tLPTest256" }, key)
        end)
        local second
        WithSyncApi({ inGuild = Yes }, function()
            second = WithSetting({ shareGuild = true, shareGroup = true, shareChannel = false }, function()
                return Comm:Broadcast({ "H\tLPTest256" }, key)
            end)
        end)
        local third
        WithSyncApi({ inGuild = Yes }, function()
            third = WithSetting({ shareGuild = true, shareGroup = true, shareChannel = false }, function()
                return Comm:Broadcast({ "H\tLPTest256" }, key)
            end)
        end)
        return first == false and second == true and third == nil,
            string.format("ohne Weg %s, danach mit Gilde %s, nochmals %s", S(first), S(second), S(third)),
            "false, true, nil (schon gesendet)"
    end)
end

IMPL.T257 = function()
    local S0 = Sy()
    if not S0 or not S0.api or not S0.api.lpDry then return NA, "nur während der ganzen Testroutine" end
    -- während der Routine sind die Warteschlangen eigene Tabellen: nichts Fremdes darin
    local foreign = 0
    for _, it in ipairs(S0.queue) do if not OWN_PREFIX[it.prefix] and it.prefix ~= S0.CTRL then foreign = foreign + 1 end end
    local h = TR.syncHandle
    local separate = h ~= nil and h.queue ~= S0.queue and h.netQueue ~= S0.netQueue
    return separate and foreign == 0, string.format("eigene Warteschlange %s, fremde Einträge darin %d", S(separate), foreign),
        "true, 0"
end

IMPL.T258 = function()
    local Pr = LP.Protocol
    if not Pr.StepIdle then return false, "Protocol.StepIdle fehlt", "vorhanden" end
    -- in der Stadt stehen (Bank, Auktionshaus): kein SCHRITT-Eintrag; gelaufen: Eintrag
    local idle = Pr.StepIdle(40, true)
    local walked = Pr.StepIdle(800, true)
    local field = Pr.StepIdle(40, false)
    local dungeon = Pr.StepSkip({ key = "DGIN", t = "DUNGEON" })
    local turnin = Pr.StepSkip({ key = "TURNIN:405", t = "TURNIN" })
    -- FOKUS: aktueller Schritt in der Zone des Spielers -> keine Meldung
    local fokusHere = Pr.FocusOk(1456, 1456, 1413)
    local fokusAway = Pr.FocusOk(1456, 1413, 1413)
    local ok = idle and not walked and not field and dungeon and not turnin and fokusHere and not fokusAway
    return ok, string.format("Stadt gestanden: ruhig %s, gelaufen: %s, Feld: %s · Dungeon ruhig %s, Abgabe %s · Fokus beim Abarbeiten ruhig %s, sonst %s",
        S(idle), S(walked), S(field), S(dungeon), S(turnin), S(fokusHere), S(fokusAway)),
        "true, false, false · true, false · true, false"
end

------------------------------------------------------------------------
-- 3.12.23: Wegstücke ohne grosse Lücken
------------------------------------------------------------------------
IMPL.T259 = function()
    local R, Gr, Geo = LP.Recorder, LP.Graph, LP.Geo
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local pos = { n, w }
    local origPlayer, origVirt = Geo.Player, LP.Virtual.active
    Geo.Player = function() return i, pos[1], pos[2], 1412, 8, 92 end
    return Guard(function()
        LP.Virtual.active = false
        R:FlushTrail(true)
        local e0 = Gr:Stats(true).edges
        local gapTrail, gapEdges, walkTrail, kept, dropped
        WithSetting({ recordPaths = true }, function() NoIdle(function()
            R:SamplePath()                       -- erster Punkt
            pos[1] = n + 70                      -- 70 Yards weiter (Ruckler, schnell)
            R:SamplePath()
            gapTrail = R:TrailCount()            -- neue Spur ab dem zweiten Punkt
            R:FlushTrail(false)
            gapEdges = Gr:Stats(true).edges - e0
            -- normal gelaufen: alle 12 Yards
            for k = 1, 5 do pos[1] = n + 200 + k * 12 R:SamplePath() end
            walkTrail = R:TrailCount()
            -- 3.13.6: gerader Lauf -> Abschnitt übernommen (Wegqualität lässt ihn durch; in der Testroutine vorgemerkt)
            local pend = R.pending and R.pending.stat or {}
            local k0, d0 = pend.kept or 0, (pend.detour or 0) + (pend.offgoal or 0) + (pend.idle or 0)
            R:FlushTrail(false)
            pend = R.pending and R.pending.stat or {}
            kept = (pend.kept or 0) - k0
            dropped = (pend.detour or 0) + (pend.offgoal or 0) + (pend.idle or 0) - d0
        end) end)
        return gapTrail == 1 and gapEdges == 0 and walkTrail == 5 and kept == 1 and dropped == 0,
            string.format("nach 70-Yards-Lücke Spur %d Punkt(e), Kanten über die Lücke %d · gelaufen %d Punkte · Abschnitt übernommen %d, verworfen %d",
                gapTrail, gapEdges, walkTrail, kept or -1, dropped or -1),
            "1, 0 · 5 · 1, 0"
    end, function() Geo.Player, LP.Virtual.active = origPlayer, origVirt R:FlushTrail(true) end)
end

IMPL.T260 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    -- ein altes gerades Stück: 100 Yards ohne Zwischenpunkt, daneben ein Weg, der 30 Yards vor dem Ende davon abgeht
    Gr:AddPolyline({ { i, n, w - 60, 1412 }, { i, n + 100, w - 60, 1412 } }, "r")
    local a = Gr:Nearest(i, n, w - 60, 2, 1412)
    local b = Gr:Nearest(i, n + 100, w - 60, 2, 1412)
    local split = Gr:Densify()
    local longest, steps = 0, 0
    -- Weg von a nach b ablaufen
    local cur, prev = a, nil
    while cur and cur ~= b and steps < 20 do
        local nextId
        for v in pairs(Gr:Neighbors(cur) or {}) do
            local nd = Gr:NodeById(v)
            if v ~= prev and nd and math.abs(nd[3] - (w - 60)) < 1 then nextId = v end
        end
        if not nextId then break end
        local p, q = Gr:NodeById(cur), Gr:NodeById(nextId)
        longest = math.max(longest, math.sqrt((q[2] - p[2]) ^ 2 + (q[3] - p[3]) ^ 2))
        prev, cur, steps = cur, nextId, steps + 1
    end
    local reached = cur == b
    return split >= 1 and reached and longest <= 25.5 and steps >= 4,
        string.format("geteilt %d, %d Stücke, längstes %.1f Yards, Weg durchgehend %s", split, steps, longest, S(reached)),
        ">= 1, 4 Stücke, <= 25 Yards, true"
end

------------------------------------------------------------------------
-- 3.12.24: Lag beim Einloggen (T-LAG1–T-LAG4)
------------------------------------------------------------------------
IMPL.T261 = function()
    local Pf = LP.Perf
    local sum, worst, n = 0, 0, 0
    local per = {}
    for key, s in pairs(Pf.stats) do
        sum = sum + (s.lms or 0)
        worst = math.max(worst, s.lmax or 0)
        n = n + (s.ln or 0)
        if (s.ln or 0) > 0 then per[#per + 1] = { k = tostring(key), ms = s.lms or 0, max = s.lmax or 0, n = s.ln or 0 } end
    end
    if n == 0 then return NA, "keine Messung aus den ersten 60 s nach dem Einloggen" end
    -- 3.12.94 (Ingametest 3.12.92/3.12.93 Punkt 2: "je Aufrufer Summe/Max ausweisen"): die 8 teuersten Schlüssel mit Summe, Aufrufen
    -- und längstem Aufruf
    table.sort(per, function(x, y) return x.ms > y.ms end)
    local parts = {}
    for i = 1, math.min(8, #per) do
        local e = per[i]
        parts[#parts + 1] = ("%s %d ms/%d×/max %d"):format(e.k, math.floor(e.ms + 0.5), e.n, math.floor(e.max + 0.5))
    end
    -- 3.12.97 (Ingametest 3.12.95 T261 a): die 3 teuersten Bereiche nach Auftrag/Schlüssel aufgeschlüsselt
    local sub = {}
    for i = 1, math.min(3, #per) do
        local m = Pf.loginKeys and Pf.loginKeys[per[i].k]
        if m then
            local ks = {}
            for k, e in pairs(m) do ks[#ks + 1] = { k = k, ms = e.ms, n = e.n, max = e.max } end
            table.sort(ks, function(x, y) return x.ms > y.ms end)
            local kp = {}
            for j = 1, math.min(5, #ks) do
                kp[#kp + 1] = ("%s %d/%d×/max %d"):format(ks[j].k, math.floor(ks[j].ms + 0.5), ks[j].n, math.floor(ks[j].max + 0.5))
            end
            sub[#sub + 1] = per[i].k .. ": " .. table.concat(kp, ", ")
        end
    end
    -- 3.12.97 (T261 d): erstes oder zweites Einloggen – hat die Umweg-Ablage getroffen?
    local G = LP.Graph
    local hits, meas = G and G.loginHits or 0, (G and G.loginMeasured or 0) + (G and G.loginDeferred or 0)
    local kind = (hits > 0 and meas == 0) and "zweites (Ablage getroffen)" or (hits == 0 and meas > 0) and "erstes (Ablage leer/neu)"
        or (hits > 0 and meas > 0) and "gemischt (bekannte Zonen aus der Ablage, neue gemessen)" or "keine Umweg-Messung"
    if G and (G.loginDeferred or 0) > 0 then kind = kind .. (", %d Zonen erst nach 60 s gemessen"):format(G.loginDeferred) end
    return sum < 1000, string.format("erste 60 s: %d ms in %d Aufrufen, längster %d ms · je Aufrufer: %s · aufgeschlüsselt: %s · Einloggen: %s, Umweg-Ablage %d übernommen / %d gemessen",
        math.floor(sum), n, math.floor(worst), table.concat(parts, ", "), #sub > 0 and table.concat(sub, " | ") or "–", kind, hits, meas), "< 1000 ms"
end
CLIENT.T261 = "Mit dem Krieger einloggen: sofort laufen können, CPU normal; /lp diag – Zeile „ZEIT erste 60 s“ unter 1000 ms"

IMPL.T262 = function()
    local Pf = LP.Perf
    local saved = { clock = Pf.clock, paused = Pf.paused, windows = Pf.windows, said = Pf.said, brakes = Pf.brakes, print = LP.Print }
    local t = 0
    local printed = {}
    return Guard(function()
        Pf.clock = function() return t end
        Pf.paused, Pf.windows, Pf.said, Pf.testBrake = {}, {}, {}, true
        LP.Print = function(_, m) printed[#printed + 1] = tostring(m) end
        local runs = 0
        local function costly(ms) return function() runs = runs + 1 t = t + ms end end
        -- 1) ein Aufruf über 50 ms
        Pf.Run("lpt262a", "route", true, costly(80))
        local paused1 = Pf.Paused("lpt262a")
        Pf.Run("lpt262a", "route", true, costly(80))       -- pausiert: läuft nicht
        local ran1 = runs
        -- 2) viele kleine: 30 × 40 ms in 5 s
        runs = 0
        for _ = 1, 30 do Pf.Run("lpt262b", "route", true, costly(40)) end
        local paused2, ran2 = Pf.Paused("lpt262b"), runs
        -- 3) nochmals über 50 ms: keine zweite Chatzeile für denselben Schlüssel
        Pf.paused.lpt262a = nil
        Pf.Run("lpt262a", "route", true, costly(80))
        local lines = 0
        for _, m in ipairs(printed) do if m:find("60", 1, true) then lines = lines + 1 end end
        local slow = 0
        for _, e in ipairs(LP.Protocol:Entries()) do if e.k == "brake" and tostring(e.msg):find("lpt262", 1, true) then slow = slow + 1 end end
        -- 4) 3.12.25: Hintergrund 300 ms in 4-ms-Portionen -> keine Pause; eine Portion über 50 ms -> Pause
        local bg = Pf.CheckSlice("lpt262c", 4)
        local bgLong = Pf.CheckSlice("lpt262d", 60)
        -- 5) in der Pause verworfen: gezählt, Nachholen vorgemerkt
        local again = 0
        Pf.after.lpt262b = function() again = again + 1 end
        local sk0 = Pf.skipped.lpt262b or 0
        Pf.Run("lpt262b", "route", true, costly(1))
        local skipped = (Pf.skipped.lpt262b or 0) - sk0
        local queued = Pf.afterSet and Pf.afterSet.lpt262b == true
        Pf.after.lpt262b, Pf.skipped.lpt262b = nil, nil
        if Pf.afterSet then Pf.afterSet.lpt262b = nil end
        local ok = paused1 and ran1 == 1 and paused2 and ran2 < 30 and lines >= 2 and slow >= 2
            and bg == false and bgLong == true and skipped == 1 and queued
        return ok, string.format("über 50 ms: Pause %s, zweiter Aufruf lief %s · Summe: Pause %s nach %d Aufrufen · Chatzeilen %d · LANGSAM %d"
            .. " · Portionen 4 ms: Pause %s, Portion 60 ms: Pause %s · in der Pause verworfen %d, Nachholen vorgemerkt %s",
            S(paused1), S(ran1 > 1), S(paused2), ran2, lines, slow, S(bg), S(bgLong), skipped, S(queued)),
            "true, false · true, < 30 · >= 2 · >= 2 · false, true · 1, true"
    end, function()
        Pf.clock, Pf.paused, Pf.windows, Pf.said, Pf.brakes, LP.Print = saved.clock, saved.paused, saved.windows, saved.said, saved.brakes, saved.print
        Pf.testBrake = nil
    end)
end

IMPL.T263 = function()
    local Gr, Comm, Jobs, Pf = LP.Graph, LP.Comm, LP.Jobs, LP.Perf
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local t0, p0 = Pf.clock(), TR.pausedMs
    -- 2000 Wegpunkte: 50 Spuren zu 40 Punkten (alle 12 Yards) am Kartenrand
    -- 3.12.93 (Ingametest 3.12.91: T263 1690 ms in einem Bild; Nachbau Laptop-Daten 773 ms, davon Aufbau 424 ms = AddPolyline je Spur
    -- ~8 ms): nach jeder Spur abgeben (kein Ersatz aktiv; die Testpunkte stehen wie in jeder Prüfung bis zur Sandbox im Netz)
    local seed = 1
    local function rnd() seed = (seed * 1103515245 + 12345) % 2147483648 return seed / 2147483648 end
    for k = 1, 50 do
        local pts, dn, dw, dir = {}, n + rnd() * 600, w - rnd() * 600, rnd() * 6.28
        for _ = 1, 40 do
            dir = dir + (rnd() - 0.5) * 0.6
            dn, dw = dn + 12 * math.cos(dir), dw + 12 * math.sin(dir)
            pts[#pts + 1] = { i, dn, dw, 1412 }
        end
        Gr:AddPolyline(pts, "r")
        TR.Safe("T263")
    end
    local build = Pf.clock() - t0 - (TR.pausedMs - p0)
    -- 500 empfangene Netz-Einträge (Wegstücke), je Absender höchstens 25
    local worstRecv, recv = 0, 0
    -- 3.12.94 (Ingametest 3.12.93: T263 136 ms in einem Bild): die 500 Einträge in 10 Blöcken zu 50 (LP.Fire ist je Block ersetzt,
    -- dazwischen zurück und eine sichere Stelle)
    for blk = 0, 9 do
    WithCounter(LP, "Fire", function()
        for k = blk * 50 + 1, blk * 50 + 50 do
            local a = { i, n + 700 + (k % 40) * 12, w - 700 - math.floor(k / 40) * 12, 1412 }
            local b = { i, a[2] + 12, a[3], 1412 }
            local msg = Comm:EncodePath({ a, b }, "0")[1]
            local s0 = Pf.clock()
            Comm:Receive(msg, "LPLast" .. math.floor(k / 25) .. "-Test", "GUILD")
            local ms = Pf.clock() - s0
            recv = recv + ms
            if ms > worstRecv then worstRecv = ms end
        end
    end)
    TR.Safe("T263")
    end
    -- Wegsuche in Portionen: erreichbares und unerreichbares Ziel (andere Welt ohne Übergang)
    local function portions(gi, gn, gw, gz)
        local oldSync, frames, worst, result = Jobs.sync, 0, 0, nil
        Jobs.sync = false
        Jobs.Start("lpt263", "path", function() return Gr:Path(i, n, w, 1412, gi, gn, gw, gz) end, function(ok, p) result = ok and (p and #p or 0) or -1 end)
        while Jobs.Running("lpt263") and frames < 5000 do
            local s0 = Pf.clock()
            Jobs.Step()
            local ms = Pf.clock() - s0
            if ms > worst then worst = ms end
            frames = frames + 1
            TR.Safe("T263")            -- 3.12.93: zwischen zwei Portionen (gemessen wird nur die Portion; der Treiber ruht)
        end
        Jobs.Cancel("lpt263")
        Jobs.sync = oldSync
        return frames, worst, result
    end
    local f1, w1, r1 = portions(i, n + 500, w - 500, 1412)
    local f2, w2, r2 = portions(i + 999, n, w, 99999)
    local total = Pf.clock() - t0 - (TR.pausedMs - p0)
    local ok = worstRecv <= 16 and w1 <= 16 and w2 <= 16 and f1 < 5000 and f2 < 5000 and r1 ~= nil and r2 ~= nil
    return ok, string.format("Aufbau %d ms · 500 Einträge: längster %.1f ms (Summe %d ms) · Wegsuche: %d Portionen, längste %.1f ms · unerreichbar: %d Portionen, längste %.1f ms, beendet %s · gesamt %d ms",
        math.floor(build), worstRecv, math.floor(recv), f1, w1, f2, w2, S(r2 ~= nil), math.floor(total)),
        "je Portion und Eintrag <= 16 ms, Suche endet"
end

IMPL.T264 = function()
    local Pf, Pr = LP.Perf, LP.Protocol
    Pf.Add("route", 3)
    -- 3.13.1 (Ingametest 3.13.0: Bild "T263–T264" 52 ms): Text, Export und Schreibversuch je in einem eigenen Bild (kein Ersatz aktiv)
    TR.Safe("T264")
    local text = Pr:Text()
    TR.Safe("T264")
    local zeit = text:find("ZEIT ", 1, true) ~= nil
    local login = text:find("erste 60 s", 1, true) ~= nil
    local route = text:find("Routenberechnung", 1, true) ~= nil
    local exp = Pr.ExportString()
    TR.Safe("T264")
    local head = exp:sub(1, 19) == "GSDIAG1|LevelPilot|"
    local me = UnitName and LP.SafeValue(UnitName("player"))
    local leak = type(me) == "string" and me ~= "" and exp:find(me, 1, true) ~= nil
    local wrote = Pr:WriteExport()                   -- im Test nie in die Speicherdatei
    return zeit and login and route and head and not leak and wrote == false,
        string.format("ZEIT %s, erste 60 s %s, Module %s, Export %s (%d Zeichen), Name %s, im Test geschrieben %s",
            S(zeit), S(login), S(route), S(head), #exp, leak and "GEFUNDEN" or "keiner", S(wrote)),
        "true, true, true, true, keiner, false"
end

IMPL.T265 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local c0 = Gr:Count()
    -- 60 Yards (mögliche Lücke) und 120 Yards (alte Vereinfachung)
    Gr:AddPolyline({ { i, n - 900, w + 300, 1412 }, { i, n - 840, w + 300, 1412 } }, "r")
    Gr:AddPolyline({ { i, n - 900, w + 400, 1412 }, { i, n - 780, w + 400, 1412 } }, "r")
    local a = Gr:Nearest(i, n - 900, w + 300, 2, 1412)
    local b = Gr:Nearest(i, n - 840, w + 300, 2, 1412)
    local c1 = Gr:Count()
    Gr:Densify()
    local e60 = a and b and Gr:Neighbors(a) and Gr:Neighbors(a)[b]
    local unsure = e60 and e60.u == 1
    local added = Gr:Count() - c1
    -- verwaiste Knoten: jeder neue Knoten hat Kanten
    local orphans = 0
    for _, id in ipairs(Gr:Near(i, n - 840, w + 400, 80, 1412)) do
        if not next(Gr:Neighbors(id) or {}) then orphans = orphans + 1 end
    end
    return unsure and added == 4 and orphans == 0 and c1 - c0 == 4,
        string.format("60 Yards unsicher und ungeteilt %s · 120 Yards: %d neue Knoten · ohne Kante %d", S(unsure), added, orphans),
        "true · 4 · 0"
end

------------------------------------------------------------------------
-- 3.12.25: Nachprüfung 3.12.24
------------------------------------------------------------------------
IMPL.T266 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    -- Planung mit kurzer Wegprüfung, auch wenn die Suche einen Fehler wirft
    local origRaw = Gr.PathRaw
    Gr.PathRaw = function() error("LP-Testfehler Wegsuche", 0) end
    local ok1 = pcall(Gr.Path, Gr, i, n, w, 1412, i, n + 300, w, 1412, 5)
    Gr.PathRaw = origRaw
    local global = Gr.expandLimit
    -- je Suche: mit 1 Schritt kein langer Weg, danach ohne Grenze wieder normal
    local seen = {}
    local origRaw2 = Gr.PathRaw
    Gr.PathRaw = function(self, a, b, c, d, e, f, g, h, maxExpand) seen[#seen + 1] = maxExpand or "nil" return origRaw2(self, a, b, c, d, e, f, g, h, maxExpand) end
    pcall(Gr.Path, Gr, i, n, w, 1412, i, n + 300, w, 1412, 1)
    pcall(Gr.Path, Gr, i, n, w, 1412, i, n + 300, w, 1412)
    Gr.PathRaw = origRaw2
    local passed = seen[1] == 1 and seen[#seen] == "nil"
    return ok1 == false and global == nil and passed,
        string.format("Fehler in der Suche aufgefangen %s, globale Grenze %s, Grenze je Suche %s (danach %s)", S(not ok1), S(global),
            S(seen[1]), S(seen[#seen])), "true, nil, 1 (danach nil)"
end

IMPL.T267 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local function line(dn, dw, step, count)
        local pts = {}
        for k = 0, count do pts[#pts + 1] = { i, n + dn + k * step, w + dw, 1412 } end
        -- Knoten direkt anlegen wie Densify (ohne Zusammenlegen benachbarter Punkte)
        Gr:AddPolyline(pts, "r")
        return Gr:Nearest(i, n + dn, w + dw, 2, 1412), Gr:Nearest(i, n + dn + step, w + dw, 2, 1412)
    end
    local a1, b1 = line(-1300, 500, 20, 3)          -- 60 Yards in 3 gleichen Stücken: geteilte Lücke
    local a2, b2 = line(-1300, 600, 30, 4)          -- 120 Yards: alte Vereinfachung, nicht markieren
    -- 3.12.93 (Ingametest 3.12.91: T267 87 ms in einem Bild): Durchlauf über das ganze Netz als freigegebene Rechnung
    TR.Safe("T267")
    local chains = Coop(Gr.MarkSplitGaps, Gr)
    local e1 = a1 and b1 and (Gr:Neighbors(a1) or {})[b1]
    local e2 = a2 and b2 and (Gr:Neighbors(a2) or {})[b2]
    local m1, m2 = e1 and e1.u == 1, e2 and e2.u == 1
    return m1 and not m2 and chains >= 1, string.format("60-Yards-Kette unsicher %s, 120-Yards-Kette unsicher %s, Ketten %d", S(m1), S(m2), chains),
        "true, false, >= 1"
end

IMPL.T268 = function()
    local Pf, Pr, Jobs = LP.Perf, LP.Protocol, LP.Jobs
    local saved = { paused = Pf.paused, windows = Pf.windows, said = Pf.said, print = LP.Print }
    return Guard(function()
        Pf.paused, Pf.windows, Pf.said, Pf.testBrake = {}, {}, {}, true
        LP.Print = function() end
        Pf.Check("lpt268", 99, "Test")
        LP.Planner:Replan()
        local kept = 0
        for _, e in ipairs(Pr:Entries()) do if e.k == "brake" and tostring(e.msg):find("lpt268", 1, true) then kept = kept + 1 end end
        -- ein Auftrag startet während seiner Portion einen neuen
        local oldSync = Jobs.sync
        Jobs.sync = false
        local inner, err = false, nil
        Jobs.Start("lpt268a", "graph", function()
            Jobs.Start("lpt268b", "graph", function() inner = true end)
        end)
        local ok = pcall(function()
            for _ = 1, 5 do Jobs.Step() end
        end)
        Jobs.Cancel("lpt268a") Jobs.Cancel("lpt268b")
        Jobs.sync = oldSync
        return kept >= 1 and ok and inner, string.format("LANGSAM nach Planung noch da %d · Auftrag im Auftrag: ohne Fehler %s, lief %s", kept, S(ok), S(inner)),
            ">= 1 · true, true"
    end, function()
        Pf.paused, Pf.windows, Pf.said, LP.Print, Pf.testBrake = saved.paused, saved.windows, saved.said, saved.print, nil
    end)
end

------------------------------------------------------------------------
-- 3.12.26: umfassende Tests TU1–TU9 (anweisung-tests-umfassend.txt)
------------------------------------------------------------------------
-- Zuordnung der Fälle zu den Bereichen TU1–TU7 für die Zeilen im Testbericht (TU8)
TR.TU = {
    TU1 = { "T269", "T214", "T217", "T222", "T26", "T45", "T39" },
    TU2 = { "T270", "T230", "T232", "T259", "T263", "T147", "T155", "T362" },
    TU3 = { "T271", "T123", "T206", "T207", "T204" },
    TU4 = { "T272" },
    TU5 = { "T274" },
    TU6 = { "T273" },
    TU7 = { "T275", "T06", "T77", "T92", "T223", "T241" },
}
TR.TU_NAMES = { TU1 = "Lagen", TU2 = "Abläufe", TU3 = "Standardwerte", TU4 = "Grundregeln", TU5 = "echte Daten",
                TU6 = "Regressionen", TU7 = "Formen des Spiels" }

-- Völker (Classic-Bit, Fraktion, Startgebiet) und mögliche Klassen
local LAGEN_RACES = {
    { id = 1, name = "Human",    f = "Alliance", start = 1429, classes = { "WARRIOR", "PALADIN", "ROGUE", "PRIEST", "MAGE", "WARLOCK" } },
    { id = 3, name = "Dwarf",    f = "Alliance", start = 1426, classes = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST" } },
    { id = 4, name = "NightElf", f = "Alliance", start = 1438, classes = { "WARRIOR", "HUNTER", "ROGUE", "PRIEST", "DRUID" } },
    { id = 7, name = "Gnome",    f = "Alliance", start = 1426, classes = { "WARRIOR", "ROGUE", "MAGE", "WARLOCK" } },
    { id = 2, name = "Orc",      f = "Horde",    start = 1411, classes = { "WARRIOR", "HUNTER", "ROGUE", "SHAMAN", "WARLOCK" } },
    { id = 5, name = "Scourge",  f = "Horde",    start = 1420, classes = { "WARRIOR", "ROGUE", "PRIEST", "MAGE", "WARLOCK" } },
    { id = 6, name = "Tauren",   f = "Horde",    start = 1412, classes = { "WARRIOR", "HUNTER", "SHAMAN", "DRUID" } },
    { id = 8, name = "Troll",    f = "Horde",    start = 1411, classes = { "WARRIOR", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE" } },
}
local LAGEN_CLASS_BITS = { WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16, SHAMAN = 64, MAGE = 128, WARLOCK = 256, DRUID = 1024 }
local LAGEN_RACE_BITS = { [1] = 1, [2] = 2, [3] = 4, [4] = 8, [5] = 16, [6] = 32, [7] = 64, [8] = 128 }
local LAGEN_LEVELS = { 1, 12, 30, 58 }

-- Lage einstellen: Volk, Klasse, Fraktion, Stufe (eigene Tabellen und Umgebung eigener Funktionen; nie Blizzard)
-- frischer Charakter: nichts erledigt, leerer Questlog, nichts ignoriert (eigene Tabellen, danach zurück)
local function WithLage(race, class, level, body)
    local QDB, P, API = LP.QuestDB, LP.Planner, LP.API
    local oc, orb, oLevel, oDone = QDB.classBit, QDB.packRaceBit, LP.PlayerLevel, API.IsQuestDone
    local oTurned, oIgn, oNo = LP.char.turnedIn, LP.char.ignored, LP.char.notOffered
    local log = {}
    for k, v in pairs(P.inLog) do log[k] = v end
    return Guard(function()
        QDB.classBit, QDB.packRaceBit = LAGEN_CLASS_BITS[class], LAGEN_RACE_BITS[race.id]
        LP.PlayerLevel = function() return level end
        API.IsQuestDone = function() return false end
        LP.char.turnedIn, LP.char.ignored, LP.char.notOffered = {}, {}, {}
        wipe(P.inLog)
        return WithEnv({ LP.PlayerFaction }, { UnitFactionGroup = function() return race.f, race.f end }, body)
    end, function()
        QDB.classBit, QDB.packRaceBit, LP.PlayerLevel, API.IsQuestDone = oc, orb, oLevel, oDone
        LP.char.turnedIn, LP.char.ignored, LP.char.notOffered = oTurned, oIgn, oNo
        wipe(P.inLog)
        for k, v in pairs(log) do P.inLog[k] = v end
    end)
end

-- Quests nach Stufe vorsortieren (einmal je Lauf)
local levelIndex
local function LevelIndex()
    if levelIndex then return levelIndex end
    local idx = {}
    -- 3.12.93: alle 200 Quests eine sichere Stelle (erst fertig gebaut in levelIndex – nie halb sichtbar)
    for k, id in ipairs(LP.QuestDB:AllIds()) do
        if k % 200 == 0 then TR.Safe("Stufen") end
        local info = LP.QuestDB:QuickInfo(id)
        local l = info and ((info.level or 0) > 0 and info.level or info.reqLevel) or 0
        if l and l > 0 and l <= 63 then
            idx[l] = idx[l] or {}
            local t = idx[l]
            t[#t + 1] = id
        end
    end
    levelIndex = idx
    return levelIndex
end

IMPL.T269 = function()
    local P, QDB = LP.Planner, LP.QuestDB
    if not (_G.LevelPilotData and _G.LevelPilotData.version) then return NA, "kein Datenpaket" end
    local idx = LevelIndex()
    local lagen, bad, checked = 0, {}, 0
    local function fail(msg) if #bad < 8 then bad[#bad + 1] = msg end end
    local mineF = LP:PlayerFaction()
    -- 3.12.93 (Nachbau Laptop-Daten: eine Lage bis 50 ms in einem Bild, fast nur QuestDB:Get mit kaltem Zwischenspeicher, z. B. nach
    -- dem Sprachwechsel in T136): alle Quests des Stufenindex vorher einmal holen, alle 50 eine sichere Stelle (ausserhalb von
    -- WithLage). Get hängt nicht von Volk/Klasse ab (nur von der Fraktion – geprüft werden nur Völker der eigenen Fraktion).
    do
        local k = 0
        for l = 1, 63 do
            for _, id in ipairs(idx[l] or {}) do
                QDB:Get(id)
                k = k + 1
                if k % 50 == 0 then TR.Safe("T269") end
            end
        end
    end
    -- Völker der eigenen Fraktion: Quests werden mit den Questgebern der eigenen Fraktion zwischengespeichert; die
    -- andere Fraktion prüft der Testlauf eines Charakters dieser Fraktion
    local other = 0
    for _, race in ipairs(LAGEN_RACES) do
        if race.f ~= mineF then other = other + #race.classes * #LAGEN_LEVELS end
        for _, class in ipairs(race.f == mineF and race.classes or {}) do
            for _, level in ipairs(LAGEN_LEVELS) do
                lagen = lagen + 1
                WithLage(race, class, level, function()
                    local avail, startHere = 0, 0
                    for l = math.max(1, level - 12), level + 3 do
                        for _, id in ipairs(idx[l] or {}) do
                            local q = QDB:Get(id)
                            if q and P:IsAvailable(q, level) then
                                avail = avail + 1
                                checked = checked + 1
                                -- Regeln je verfügbarer Quest
                                if q.faction and q.faction ~= (race.f == "Horde" and "H" or "A") then
                                    fail(("%s %s L%d: Quest %d der anderen Fraktion"):format(race.name, class, level, id))
                                end
                                if q.classes and q.classes ~= 0 and not LP.HasBit(q.classes, LAGEN_CLASS_BITS[class]) then
                                    fail(("%s %s L%d: Klassenquest %d einer anderen Klasse"):format(race.name, class, level, id))
                                end
                                if q.races and q.races ~= 0 and q.raceSys == "pack" and not LP.HasBit(q.races, LAGEN_RACE_BITS[race.id]) then
                                    fail(("%s %s L%d: Volksquest %d eines anderen Volks"):format(race.name, class, level, id))
                                end
                                if (q.reqLevel or 0) > level then
                                    fail(("%s %s L%d: Quest %d erst ab Stufe %d"):format(race.name, class, level, id, q.reqLevel))
                                end
                                if level == 1 then
                                    for _, st in ipairs(q.starts or {}) do if st[1] == race.start then startHere = startHere + 1 break end end
                                end
                            end
                        end
                    end
                    if level == 1 and startHere < 1 then
                        fail(("%s %s L1: nur %d Quests im Startgebiet %d"):format(race.name, class, startHere, race.start))
                    end
                    if level < 58 and avail == 0 then fail(("%s %s L%d: keine verfügbare Quest"):format(race.name, class, level)) end
                end)
                TR.Safe("T269")           -- 3.12.93: nach jeder Lage (ausserhalb von WithLage, kein Ersatz aktiv)
            end
        end
    end
    -- Queststand: erledigt / im Log / abgebrochen / fehlgeschlagen an einer verfügbaren Quest der eigenen Lage
    local level = LP:PlayerLevel()
    local probe
    for l = math.max(1, level - 3), level + 2 do
        for _, id in ipairs(idx[l] or {}) do
            local q = QDB:Get(id)
            if q and P:IsAvailable(q, level) then probe = q break end
        end
        if probe then break end
    end
    local states = "keine verfügbare Quest"
    if probe then
        local id = probe.id
        local oldDone, oldLog = LP.char.turnedIn[id], P.inLog[id]
        Guard(function()
            LP.char.turnedIn[id] = LP:Now()
            local done = P:IsAvailable(probe, level)
            LP.char.turnedIn[id] = nil
            P.inLog[id] = { complete = false, objDone = {} }
            local inlog = P:IsAvailable(probe, level)
            P.inLog[id] = { complete = false, objDone = {}, failed = true }
            local failed = P:IsAvailable(probe, level)
            P.inLog[id] = nil
            local abandoned = P:IsAvailable(probe, level)
            states = ("erledigt %s, im Log %s, fehlgeschlagen %s, abgebrochen %s"):format(S(done), S(inlog), S(failed), S(abandoned))
            if done or inlog or failed or not abandoned then fail("Queststand " .. id .. ": " .. states) end
        end, function() LP.char.turnedIn[id], P.inLog[id] = oldDone, oldLog end)
    end
    return #bad == 0, ("%d Lagen (%s; %d Lagen der anderen Fraktion im Lauf mit deren Charakter), %d verfügbare Quests geprüft · %s%s"):format(lagen,
        mineF, other, checked, states,
        #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "keine Verletzung; erledigt/im Log/fehlgeschlagen false, abgebrochen true"
end

IMPL.T270 = function()
    local P, E = LP.Planner, LP.Engine
    local function keys()
        local out = {}
        for i, st in ipairs(E:Steps() or {}) do if i > 5 then break end out[#out + 1] = st.key end
        return table.concat(out, ",")
    end
    local bad = {}
    local mark, real = ActMark(), LP.Act.real
    local e0 = LP.errorCount
    -- 1) /reload unterwegs: Kandidaten und Plan neu aus den gespeicherten Daten -> gleicher Plan
    -- 3.12.93: Neuplanungen ohne Ersatz als freigegebene Rechnung, sichere Stellen zwischen den Schritten
    Coop(P.Replan, P, true)
    TR.Safe("T270")
    local before = keys()
    WithLoad(LevelPilotDB, LevelPilotCharDB, function()
        P:BuildCandidates()
        P:Replan(true)
    end)
    local after = keys()
    if before ~= after then bad[#bad + 1] = "nach /reload anderer Plan: " .. before .. " -> " .. after end
    TR.Safe("T270")
    -- 2) Plan wechseln: Normal -> Speedrun -> Normal ergibt wieder denselben Plan (Modus = echte Einstellung, darf abgeben)
    local mode = LP.char.mode
    Guard(function()
        Coop(P.SetMode, P, mode == "speed" and "normal" or "speed")
        Coop(P.Replan, P, true)
        TR.Safe("T270")
        Coop(P.SetMode, P, mode)
        Coop(P.Replan, P, true)
    end, function() LP.char.mode = mode end, true)
    TR.Safe("T270")
    local back = keys()
    if back ~= before then bad[#bad + 1] = "Modus hin und zurück: " .. before .. " -> " .. back end
    -- 3) Tod -> Geistheiler -> weiter: kein Fehler, der Schritt bleibt
    local cur = E:Current()
    local okDead = pcall(CallHandlers, "PLAYER_DEAD")
    local okAlive = pcall(CallHandlers, "PLAYER_UNGHOST")
    pcall(CallHandlers, "PLAYER_ALIVE")
    TR.Safe("T270")
    Coop(P.Replan, P, true)
    local cur2 = E:Current()
    TR.Safe("T270")
    if not okDead or not okAlive then bad[#bad + 1] = "Tod/Geistheiler mit Fehler" end
    if cur and cur2 and cur.key ~= cur2.key and not cur2.key:find("^DEATH") then
        bad[#bad + 1] = "nach dem Tod anderer Schritt: " .. tostring(cur.key) .. " -> " .. tostring(cur2.key)
    end
    -- 4) annehmen/abgeben automatisch: QUEST_COMPLETE mit 1 Belohnung -> GetQuestReward(1), mit 3 -> nichts
    local function complete(choices)
        local m = ActMark()
        local fake = { GetNumQuestChoices = function() return choices end, GetQuestItemLink = function() return nil end }
        local list = HandlerList("QUEST_COMPLETE")
        WithEnv(list, fake, function() WithSetting({ autoTurnin = true }, function() CallHandlers("QUEST_COMPLETE") end) end)
        local n, arg = 0, nil
        for i = m + 1, #LP.Act.log do
            local e = LP.Act.log[i]
            if e.name == "GetQuestReward" then n, arg = n + 1, e.a1 end
        end
        return n, arg
    end
    local n1, a1 = complete(1)
    local n3 = complete(3)
    if n1 ~= 1 or a1 ~= 1 then bad[#bad + 1] = ("1 Belohnung: %d× Index %s"):format(n1, S(a1)) end
    if n3 ~= 0 then bad[#bad + 1] = "3 Belohnungen: automatisch gewählt" end
    -- am Ende: nichts Echtes, keine Lua-Fehler
    local realActs = LP.Act.real - real
    local errs = LP.errorCount - e0
    if realActs ~= 0 then bad[#bad + 1] = "echte Aktionen " .. realActs end
    if errs ~= 0 then bad[#bad + 1] = "Lua-Fehler " .. errs end
    return #bad == 0, #bad == 0 and ("Plan nach /reload und Moduswechsel gleich (%s), Tod ohne Fehler, Belohnung 1 -> Index 1, 3 -> keine"):format(before)
        or table.concat(bad, "; "), "alles gleich, keine Fehler, nichts Echtes"
end

-- erwartete Standardwerte (was der Spieler ab Werk erwartet) – jede Abweichung ist ein FEHLER
local EXPECT_DEFAULTS = {
    autoAccept = true, autoTurnin = true, autoSellGrey = true, autoRepair = true, autoFly = true, restock = false,
    autoEquipRewards = false, showArrow = true, showEta = true, showTimer = true, recordPaths = true, recordQuests = true,
    shareGuild = true, shareGroup = true, shareChannel = true, shareSeed = false, compactMode = false, locked = false,
    safeMode = false, dungeons = true, language = "auto", questLogMax = 0, dungeonMobXP = 0, dungeonQuestXP = 0,
    speedLevel = 2, scale = 1.0, stepsShown = 5, summaryGuild = false, findPartners = true, groupSync = true,
    cmdHint = true, marktTeilen = true,
}
IMPL.T271 = function()
    return WithLoad({}, {}, function(acc)
        local list, bad = {}, {}
        local keys = {}
        for k, v in pairs(LP.DEFAULTS) do if type(v) ~= "table" then keys[#keys + 1] = k end end
        table.sort(keys)
        for _, k in ipairs(keys) do list[#list + 1] = k .. "=" .. tostring(acc[k]) end
        for k, v in pairs(EXPECT_DEFAULTS) do
            if acc[k] ~= v then bad[#bad + 1] = ("%s ist %s, soll %s"):format(k, tostring(acc[k]), tostring(v)) end
        end
        -- leere Felder: nil-Werte ab Werk (Fenstergrösse) führen nicht zu Fehlern beim Anzeigen
        local okUI = pcall(LP.UI.Refresh, LP.UI)
        if not okUI then bad[#bad + 1] = "Anzeige mit Werkseinstellungen wirft einen Fehler" end
        return #bad == 0, ("%d Optionen ab Werk: %s%s"):format(#keys, table.concat(list, ", "),
            #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "alle wie erwartet"
    end)
end

-- TU4: Grundregeln mit Zufallsfällen – läuft vor den Prüfungen in Portionen (TR:Invariants), T272 meldet
TR.INV_SEED = 1113
TR.INV_CASES = 1000
local PROTECTED_IN_COMBAT = { Sell = true, EquipItemByName = true, EquipItem = true, PickupContainerItem = true,
                              UseAction = true, BuyMerchantItem = true }
function TR:Invariants(yield)
    local seed = TR.INV_SEED
    local function rnd() seed = (seed * 1103515245 + 12345) % 2147483648 return seed / 2147483648 end
    local res = { n = 0, fails = {}, kinds = { weg = 0, belohnung = 0, zeit = 0, kampf = 0 }, seed = TR.INV_SEED }
    local function fail(kind, msg) if #res.fails < 10 then res.fails[#res.fails + 1] = kind .. ": " .. msg end end
    local P, Gr, Ter = LP.Planner, LP.Graph, LP.Terrain
    local pi, pn, pw, pmap = LP.Geo:Player()
    local cases = TR.INV_CASES
    local function case(k)
        local kind = k % 4
        if kind == 0 and pi and pmap then
            -- Weg: zufälliges Ziel bis 400 Yards; jedes Stück Luftlinie über Gelände, das die Geländekarte kennt,
            -- muss begehbar sein
            if k % 40 == 0 then
                local gn, gw = pn + (rnd() - 0.5) * 800, pw + (rnd() - 0.5) * 800
                -- 3.12.99 (Ingametest 3.12.97: Bilder "Grundregeln" 61/59/59 ms): echte Wegsuche, darf abgeben (vorher pcall)
                local ok, p = PCallY(Coop, Gr.Path, Gr, pi, pn, pw, pmap, pi, gn, gw, pmap, 2000)
                if ok and p then
                    for j = 2, #p do
                        local a, b = p[j - 1], p[j]
                        if a.map and a.map == b.map and Ter and Ter.Walkable and Ter:Available(a.map) then
                            local mx, my = ((a.x or 0) + (b.x or 0)) / 2, ((a.y or 0) + (b.y or 0)) / 2
                            if a.x and b.x and Ter:Walkable(a.map, mx, my) == false and not (a.known and b.known) then
                                fail("weg", ("Fall %d: Stück %.1f,%.1f -> %.1f,%.1f über unbegehbares Gelände (Karte %d)"):format(k, a.x, a.y, b.x, b.y, a.map))
                            end
                        end
                    end
                end
            end
            res.kinds.weg = res.kinds.weg + 1
        elseif kind == 1 then
            -- Belohnung: nie automatisch eine falsche (mehrere Wahlmöglichkeiten -> nie automatisch)
            local choices = math.floor(rnd() * 6)
            local auto = rnd() < 0.8
            local m = ActMark()
            local fake = { GetNumQuestChoices = function() return choices end, GetQuestItemLink = function() return nil end }
            WithEnv(HandlerList("QUEST_COMPLETE"), fake, function()
                WithSetting({ autoTurnin = auto }, function() pcall(CallHandlers, "QUEST_COMPLETE") end)
            end)
            for i = m + 1, #LP.Act.log do
                local e = LP.Act.log[i]
                if e.name == "GetQuestReward" then
                    if not auto then fail("belohnung", ("Fall %d: abgegeben, obwohl automatisch aus"):format(k)) end
                    if choices > 1 then fail("belohnung", ("Fall %d: bei %d Belohnungen automatisch gewählt"):format(k, choices)) end
                    if (e.a1 or 0) > choices then fail("belohnung", ("Fall %d: Index %s bei %d Belohnungen"):format(k, S(e.a1), choices)) end
                end
            end
            res.kinds.belohnung = res.kinds.belohnung + 1
        elseif kind == 2 then
            -- Zeiten: Schätzungen nie negativ, nie über 6 Stunden je Quest
            local ids = {}
            for id in pairs(P.inLog) do ids[#ids + 1] = id end
            if #ids > 0 then
                local id = ids[math.floor(rnd() * #ids) + 1]
                local ok, eta = pcall(LP.Session.QuestETA, LP.Session, id)
                if ok and eta and (eta < 0 or eta > 6 * 3600) then
                    fail("zeit", ("Fall %d: Quest %d geschätzt %d s"):format(k, id, math.floor(eta)))
                end
            end
            res.kinds.zeit = res.kinds.zeit + 1
        else
            -- Kampf: Händler und Belohnung im Kampf -> keine geschützte Aktion
            local m = ActMark()
            WithCombat(true, function()
                local ev = rnd() < 0.5 and "MERCHANT_SHOW" or "QUEST_COMPLETE"
                local fake = { GetNumQuestChoices = function() return 1 end, GetQuestItemLink = function() return nil end }
                WithEnv(HandlerList(ev), fake, function() pcall(CallHandlers, ev) end)
                if ev == "MERCHANT_SHOW" then pcall(CallHandlers, "MERCHANT_CLOSED") end
            end)
            for i = m + 1, #LP.Act.log do
                local e = LP.Act.log[i]
                if PROTECTED_IN_COMBAT[e.name] then fail("kampf", ("Fall %d: %s im Kampf"):format(k, e.name)) end
            end
            res.kinds.kampf = res.kinds.kampf + 1
        end
    end
    -- je Fall geschützt (ein Fehler ist eine Verletzung, kein Abbruch); abgegeben wird ausserhalb des pcall
    for k = 1, cases do
        local ok, err = PCallY(case, k)    -- 3.12.99: PCallY statt pcall, damit die Wegsuche darin abgeben kann
        if not ok then fail("fehler", ("Fall %d: %s"):format(k, tostring(err):sub(1, 80))) end
        res.n = res.n + 1
        if yield then yield() end
    end
    self.inv = res
    return res
end

IMPL.T272 = function()
    local r = TR.inv
    if not r then return NA, "Grundregeln nur in der ganzen Testroutine (Bereich J)" end
    local k = r.kinds
    return #r.fails == 0 and r.n >= 1000, ("%d Fälle (Startwert %d): Weg %d, Belohnung %d, Zeiten %d, Kampf %d%s"):format(r.n, r.seed,
        k.weg, k.belohnung, k.zeit, k.kampf, #r.fails > 0 and (" · VERLETZT: " .. table.concat(r.fails, "; ")) or ""),
        ">= 1000 Fälle, keine Verletzung"
end

-- TU6: jeder Befund seit dem 1.11. (auftraege/LevelPilot) mit seinem bleibenden Test
TR.REGRESSIONS = {
    { "korrektur-3.12.2 K1–K20", { "T174", "T175", "T176", "T177", "T178", "T179", "T180", "T181", "T182", "T183", "T184", "T185",
      "T186", "T187", "T188", "T189", "T190", "T191", "T192", "T193", "T194", "T195", "T196", "T197", "T198", "T199", "T200",
      "T201", "T202", "T203" } },
    { "Standardwerte mit Folgen (K Frage, A1, A2)", { "T204", "T206", "T207", "T208", "T209", "T210", "T211" } },
    { "Datenpaket nur in der gemeinsamen ZIP (R)", { "T205" } },
    { "3.12.5-1 Drop-Messung doppelt", { "T212" } },
    { "3.12.6-2 Berufszauber", { "T213" } },
    { "5.11. Mulgore: nahe Abgaben zuerst", { "T214" } },
    { "5.11. Linie übers Gebirge", { "T215" } },
    { "5.11. Protocol.lua:235 geschützte Zahl", { "T216" } },
    { "5.11. Thunder Bluff/Mulgore ein Fokus, PRIO, FEST", { "T217" } },
    { "Wegpunkte Punkt 1–6 Wegnetz statt Luftlinie", { "T218" } },
    { "Wegpunkte Punkt 7–9 FEST nur bei Laufzeit", { "T219" } },
    { "Wegpunkte Punkt 10 echte NPC-Orte", { "T220" } },
    { "Wegpunkte Punkt 11/13/14 Wegdaten GSWEGE1", { "T221" } },
    { "5.11. erst offene Quests der aktuellen Zone", { "T222" } },
    { "9.11. Session.lua:29 secret boolean (798×)", { "T223" } },
    { "Oberfläche (anweisung-testroutine-oberflaeche)", { "T224", "T225", "T226", "T227", "T228", "T229" } },
    { "Graue Items ohne Knopf", { "T230", "T231", "T232", "T233", "T234" } },
    { "Wegdaten a–e (Netz zerfällt, Punkte selten, Kontinent, npc old, NPC-Orte)", { "T235", "T236", "T237", "T238", "T239" } },
    { "Tooltips über den Knöpfen", { "T240" } },
    { "übrige geschützte Abfragen, T128, Fehlerzähler", { "T241", "T128" } },
    { "Kanal LevelPilotNet / gemeinsamer Sync 2 / Test 2", { "T108", "T242", "T243", "T244", "T245", "T246", "T247", "T248",
      "T249", "T250", "T251", "T252", "T253" } },
    { "keine Spielernamen", { "T165", "T251" } },
    { "Nachprüfung 3.12.21 Punkte 1–5", { "T254", "T243", "T255", "T256", "T257" } },
    { "Protokoll: SCHRITT/FOKUS/ZONE ruhig", { "T258" } },
    { "Nachprüfung 3.12.22: Z/E ohne Prüfsumme, grosse Wegelücken", { "T254", "T259", "T260" } },
    { "KRITISCH Lag beim Einloggen (T-LAG1–4)", { "T261", "T262", "T263", "T264", "T148" } },
    { "Nachprüfung 3.12.23: Sprung-Kanten, verwaister Knoten", { "T265" } },
    { "Nachprüfung 3.12.24 Punkte 1–6", { "T262", "T266", "T267", "T268" } },
    { "3.12.27: Schalter Befehlsliste auf derselben Stelle wie „nur für diesen Charakter“", { "T286" } },
    { "Nachprüfung 3.12.28 MK1 (feedUntil störte T283)", { "T287" } },
    { "Nachprüfung 3.12.28 GR1 (Quest 445 fertig, kein Abgabe-Schritt)", { "T288" } },
    { "Nachprüfung 3.12.28 SP1 (Speicher bis 125 MB, Messauftrag)", { "T289" } },
    { "ML1 Schalter „Meldungen“ (Wunsch des Nutzers 14.11.)", { "T290" } },
    { "Nachprüfung 3.12.30 PF-A (Planung Allianz 26 ms)", { "T150", "T291" } },
    { "Nachprüfung 3.12.31 LP-D1 (Questauswertung 495 ms nach dem Einloggen)", { "T292" } },
    { "Nachprüfung 3.12.30 GR1-K (Kompaktmodus: Später abgeben unsichtbar)", { "T293" } },
    { "L-1 Ruckler alle 5 Min. (UpdateAddOnMemoryUsage im Ticker)", { "T294" } },
    { "Nachprüfung 3.12.32 PF-A-Rest (Höchstwert 26 ms im ersten Lauf)", { "T295" } },
    { "UC-W1 Undercity „Weg unbekannt“ zum Lich-NPC (Bildschirmfotos 15.11.)", { "T296" } },
    { "W3D B1 Ebenen-Angabe mitschreiben (Supervisor 15.11. 20:15, nur speichern)", { "T297" } },
    { "Punkt 1/6 Koordinatenlisten Mulgore, Brachland, Donnerfels (anweisung-wegpunkte-strassen)", { "T298" } },
    { "W3D sprachfreier Ebenen-Schlüssel (Supervisor 15.11. 21:48/22:03)", { "T299" } },
    { "LP-N1 Wünsche der Spieler: Erholt-Bonus und Waffenfertigkeit (Supervisor 15.11. 22:33)", { "T300", "T301" } },
    { "LP-N1 4b Waffenmeister für neue Waffenarten (Supervisor 15.11. 22:49)", { "T302" } },
    { "LP-N1 3 Grind-Ausweichorte (Supervisor 15.11. 22:49/23:18)", { "T303" } },
    { "LP-N1 2 Schritt 1 Upgrades im Händlerfenster (Supervisor 15.11. 23:18)", { "T304" } },
    { "LP-N1 1 Talent-Empfehlung als Text (Supervisor 15.11. 23:18)", { "T305" } },
    { "Wunsch ProfessionSentinel: LevelPilotAPI.NavigateTo (Supervisor 15.11. 23:48)", { "T306" } },
    { "LP-N2 geführter Client-Test (Supervisor 16.11. 00:19)", { "T307" } },
    { "Geführte Wegmessung für GSWegMess (Supervisor 16.11. 00:48)", { "T308" } },
    { "Prüfliste im Spiel (Entscheid des Nutzers 16.11. 06:47, Supervisor 06:49)", { "T309" } },
    { "LW-6 Laufweg-Messung (Auftrag des Nutzers 16.11. 07:30, Supervisor 07:34)", { "T310" } },
    { "LW-3 Flug nach Zeit (Auftrag des Nutzers 16.11. 07:30, Supervisor 07:34)", { "T311" } },
    { "ST-2 Strassennetz aus den Spieldateien (Supervisor 16.11. 08:11)", { "T312" } },
    { "LW-1 Wegkosten statt Luftlinie (Auftrag des Nutzers 16.11. 07:30, Supervisor 07:34)", { "T313" } },
    { "NAV-1a /lp navi (Navigator, Entscheid des Nutzers 16.11. 07:55)", { "T314" } },
    { "LW-5 E2 Classic Era: Rückrechnung der Forever-Zonen (Entscheid des Nutzers 16.11. 10:08)", { "T315" } },
    { "LW-5 E3 Classic Era: Daten je Spielversion (Entscheid des Nutzers 16.11. 10:08)", { "T316" } },
    { "LW-5 E4 Classic Era: Forever-Eigenheiten je Spielversion (Entscheid des Nutzers 16.11. 10:08)", { "T317" } },
    { "NAV-2 Reiseplan nach Zeit (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T318" } },
    { "NAV-1b Namenssuche mit Trefferliste (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T319" } },
    { "NAV-1c Weltkarte: Markierung = Navi-Ziel (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T320" } },
    { "LW-2a exakte Reihenfolge bis 8 Ziele (Auftrag des Nutzers 16.11. 07:30, Analyse Abschnitt 6 (3))", { "T321" } },
    { "NAV-3 Navi unterwegs: Gefahr, Ankunft (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T322" } },
    { "NAV-4 Zusammenspiel: Route nutzt den Reiseplan, Schnittstelle für andere Addons (Entscheid des Nutzers 16.11. 07:55)", { "T323" } },
    { "LW-7a Rundgang über die Fundorte der Gegner (RestedXP-Vergleich, Bewertung 13:10)", { "T324" } },
    { "LW-5 E1/E5 Classic Era: .toc 16001+11509, Prüfliste Era (Supervisor 13:25, Messung Forever 13:39)", { "T325" } },
    { "LW-2b Zeitmodell im Normalmodus (Messreihe 18 Reisen, Supervisor 13:25 \"Code nur bei Beleg\")", { "T326" } },
    { "LW-7 (d) Tod als Reise (Entscheid des Nutzers 13:27, Schwelle 3 min Supervisor 13:57)", { "T327" } },
    { "LW-8 (2) Flugpreise (Supervisor 14:14 \"JA, bauen\")", { "T328" } },
    { "LW-7 (e) Messlatte aus eigenen Zahlen, LW-4 Startwegnetz 9 Zonen (Supervisor 14:14)", { "T329", "T298" } },
    { "Nachprüfung 14:30: NP-LP54-2 Gross/Klein mit Umlauten/Kyrillisch, NP-LP49-1/-2 Laufweg-Zeile", { "T330" } },
    { "Nachtest im Spiel 15:37: NAV-T1 Navi-Ziel an zweiter Stelle", { "T331" } },
    { "BEFUND HOCH ERA-1 (Nutzer 17:05): Startzone – weites Ziel vor nahen Questgebern, Pfeil kehrt um", { "T332", "T333", "T334", "T335", "T336", "T337", "T338", "T339", "T340", "T341", "T342", "T343", "T344", "T345", "T346", "T347", "T348", "T349", "T350", "T351", "T352" } },
    { "HOCH SOFORT Ingametest 3.12.91: Testroutine friert ein (Bilder bis 3,3 s)", { "T349", "T353" } },
    { "HOCH Ingametest 3.12.94: Einloggen (T261), Bilder über 40 ms (T21, T275, T157)", { "T261", "T275", "T157", "T354", "T355", "T356" } },
    { "HOCH Befund 18.11. 13:55: Testnamen im Sync-Adressbuch (echtes Flüstern)", { "T357", "T254", "T249" } },
    { "Ingametest 3.12.95: Einloggen, T155, T295, Bilder über 40 ms", { "T261", "T155", "T295", "T340", "T355", "T360" } },
    { "Ingametest 3.12.97: Einloggen erstes Mal, T155, T150, Abgabe nicht möglich", { "T261", "T155", "T150", "T361" } },
    { "Auftrag 19.11. 09:36: Vorschläge Später/Nicht mehr, nur am passenden Ort", { "T362", "T302" } },
    { "Entscheid 19.11. 09:06: Entwickler-Befehle nur im Entwicklermodus sichtbar", { "T363" } },
    { "Entscheid 19.11. 11:00: Wegdaten Opt-out mit einmaliger Information", { "T365" } },
    { "Auftrag 19.11. 11:00: Wegnetz-Lücken automatisch messen", { "T366" } },
    { "Ingametest 3.13.3: T150 vollständige Aufteilung, Navigation nicht bei jeder Planung", { "T150", "T367" } },
    { "Auftrag 19.11. 12:42: gelaufene Wege sind nicht immer gute Wege", { "T368", "T366" } },
    { "Auftrag 23.11.: Berufs-Hinweise nur nach Prüfung der gelernten Berufe", { "T369", "T362" } },
    { "Entscheid 22.11. 16:57/16:58: keine Wege mehr sperren, ausser durch Orte der anderen Fraktion", { "T370", "T371", "T219" } },
    { "Montag 23.11. LP-M1 Abgabe ohne Ort", { "T372" } },
    { "Montag 23.11. LP-M2 eine Entfernung je Weg", { "T373" } },
    { "Montag 23.11. LP-M3 Fenstertitel = Levelgebiet", { "T374" } },
    { "Hinweis 20.11.: Test ändert nie Livedaten (Sandbox, Sync-Adressbuch, Gegenproben)", { "T375", "T357" } },
    { "Prüfung 23.11. LP-T1 Reise wiederholbar, rote Nachbau-Tests belegt", { "T381", "T174", "T303" } },
    { "Prüfung 23.11. LP-B1 bis LP-B4, LP-O1", { "T376", "T377", "T378", "T379", "T382" } },
    { "Hinweis 20.11.: Lesbarkeit L1–L8", { "T380", "T373", "T377" } },
    { "Ingametest 3.13.0: T150 Neuplanung (Gefahr auf der Strecke in Blöcken, Zwischenspeicher)", { "T150", "T291", "T364" } },
}
IMPL.T273 = function()
    local known = {}
    for _, e in ipairs(TR.IDS) do known[e[1]] = true end
    local special = { T165 = true, T166 = true }        -- laufen am Ende der Routine (eigener Ablauf)
    local have, missing = 0, {}
    for _, r in ipairs(TR.REGRESSIONS) do
        local ok = #r[2] > 0
        for _, id in ipairs(r[2]) do
            if not known[id] or not (IMPL[id] or CLIENT[id] or SKIP[id] or special[id]) then ok = false end
        end
        if ok then have = have + 1 else missing[#missing + 1] = r[1] end
    end
    TR.regressionLine = ("Regressionen: %d von %d vorhanden"):format(have, #TR.REGRESSIONS)
    return #missing == 0, TR.regressionLine .. (#missing > 0 and (" · fehlt: " .. table.concat(missing, "; ")) or ""), "alle vorhanden"
end

IMPL.T274 = function()
    local Pr = LP.Protocol
    if not Pr.CheckRules then return false, "Protocol.CheckRules fehlt", "vorhanden" end
    local v, checked = Pr:CheckRules(true)
    return #v == 0, ("%d Questlog-Einträge und Messwerte geprüft%s"):format(checked, #v > 0 and (" · " .. table.concat(v, "; ")) or ""),
        "keine Grundregel verletzt"
end
CLIENT.T274 = "Nach einer Spielsitzung /lp diag: keine Zeile „GRUNDREGEL VERLETZT“ (oder Fall melden)"

-- 3.12.95 (Entscheid der Prüf-Sitzung 18.11.): je Lauf EINE Spielversion im Wechsel forever -> era -> tbc -> …; die nächste steht in
-- der Test-Ablage (LevelPilotDB.gsTest.lpT275, bleibt beim Zurückschreiben der Sandbox stehen). Alle drei in einem Bild: 92 ms.
TR.T275_FLAVORS = { "forever", "era", "tbc" }
local function T275Next(peek)
    local list = TR.T275_FLAVORS
    local st = LevelPilotDB and LevelPilotDB.gsTest
    local i = st and math.floor(tonumber(st.lpT275) or 1) or 1
    if i < 1 or i > #list then i = 1 end
    local nx = i % #list + 1
    if st and not peek then st.lpT275 = nx end
    return list[i], list[nx]
end
TR.T275Next = T275Next

IMPL.T275 = function()
    local bad, done = {}, {}
    local P, UI = LP.Planner, LP.UI
    local fl, nextFl = T275Next()
    do
        local ok, err = pcall(WithFlavor, fl, function()
            P:BuildCandidates()
            P:Replan(true)
            UI:Refresh()
            return true
        end)
        if ok then done[#done + 1] = fl .. " (nächster Lauf: " .. nextFl .. ")"
        else bad[#bad + 1] = fl .. ": " .. tostring(err):sub(1, 60) end
        TR.Safe("T275")             -- 3.12.93: nach der Spielversion (ausserhalb von WithFlavor)
    end
    PCallY(Coop, P.BuildCandidates, P) TR.Safe("T275") PCallY(Coop, P.Replan, P, true) TR.Safe("T275")
    -- Sprachen: Texte des aktuellen Schritts in deDE und enUS ohne Platzhalter-Fehler
    local lang0 = LP.db.language
    for _, code in ipairs({ "de", "en" }) do
        local ok, err = pcall(function()
            LP.db.language = code
            LP:ResetLanguageCache()
            UI:Refresh()
            local cur = LP.Engine:Current()
            if cur and UI.StepText then UI:StepText(cur) end
        end)
        if ok then done[#done + 1] = code else bad[#bad + 1] = code .. ": " .. tostring(err):sub(1, 60) end
    end
    LP.db.language = lang0
    LP:ResetLanguageCache()
    -- Fenster bei Skalierung 80 %: ganz im Bildschirm (Oberflächenprüfung, nur im echten Client)
    local f = _G.LevelPilotFrame
    if f and f.GetScale and LP.UICheck and LP.UICheck.Available() then
        local sc = f:GetScale()
        local ok = pcall(function()
            f:SetScale(sc * 0.8)
            local out = LP.UICheck.InsideScreen and LP.UICheck.InsideScreen() or {}
            if type(out) == "table" and #out > 0 then bad[#bad + 1] = "80 %: ausserhalb " .. #out end
        end)
        f:SetScale(sc)
        done[#done + 1] = ok and "80 %" or "80 % Fehler"
    end
    UI:Refresh()
    return #bad == 0, ("geprüft: %s%s"):format(table.concat(done, ", "), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""),
        "eine Spielversion je Lauf (forever/era/tbc im Wechsel), de, en ohne Fehler"
end

------------------------------------------------------------------------
-- 3.12.27: Befehlsliste beim Tippen (T-BL1–T-BL6)
------------------------------------------------------------------------
local function WithHint(dev, body)
    local H = LP.CmdHint
    local oDev, oSel, oStore = H.dev, H.selected, H.store
    local uses = {}
    return Guard(function()
        H.dev = function() return dev end
        H.store = function() return uses end
        H.selected = nil
        return body(H)
    end, function() H.dev, H.selected, H.store = oDev, oSel, oStore end)
end
local function Keys(list) local t = {} for _, it in ipairs(list) do t[it.key] = true end return t end

IMPL.T276 = function()
    if not (LP.CmdHint and LP.COMMANDS and LP.FindCommand) then return false, "CmdHint/COMMANDS fehlt", "vorhanden" end
    return WithHint(true, function(H)
        local listed = Keys(H:List(""))
        local missing, wrong = {}, {}
        for _, c in ipairs(LP.COMMANDS) do
            if c[1] ~= "" then
                if not listed[H.Base(c)] then missing[#missing + 1] = c[1] end
                -- jedes Wort, das der Handler versteht, findet genau diesen Eintrag
                for _, w in ipairs(c.words or { c[1], c[2] }) do
                    local msg = w .. (c.args and " x" or "")
                    if LP:FindCommand(msg) ~= c then wrong[#wrong + 1] = msg end
                end
            end
        end
        -- Befehle vor 3.12.27 (Rückwärts-Prüfung): alle finden einen Eintrag
        local old = { "zentrale", "center", "speed", "speedrun", "normal", "modus", "mode", "weg 45 60", "way 45 60", "suche gasthaus",
            "find inn", "sprache de", "lang en", "teilen", "share", "gruppe", "lfg", "bilanz", "bilanz gilde", "summary", "kompakt",
            "compact", "wege", "ways", "protokoll", "protokoll leer", "log", "testroutine a", "test", "selbsttest", "messen", "measure",
            "test reise", "reise", "reise stopp", "journey", "grau", "grey", "gray", "junk", "spenden", "donate", "support", "zurück",
            "zurueck", "undo", "plan", "sync test", "sync", "diag", "diagnose", "debug", "reset" }
        for _, m in ipairs(old) do if not LP:FindCommand(m) then wrong[#wrong + 1] = m end end
        return #missing == 0 and #wrong == 0, ("%d Befehle in der Tabelle, fehlen in der Liste: %s · falsch zugeordnet: %s"):format(#LP.COMMANDS - 1,
            #missing > 0 and table.concat(missing, ", ") or "keine", #wrong > 0 and table.concat(wrong, ", ") or "keine"), "keine, keine"
    end)
end

IMPL.T277 = function()
    return WithHint(true, function(H)
        local function expect(prefix)
            local t = {}
            for _, c in ipairs(LP.COMMANDS) do
                if c[1] ~= "" and (c[1]:lower():sub(1, #prefix) == prefix or c[2]:lower():sub(1, #prefix) == prefix) then t[H.Base(c)] = true end
            end
            return t
        end
        local bad = {}
        for _, pfx in ipairs({ "w", "we", "s", "test", "" }) do
            local got, want = Keys(H:List(pfx)), expect(pfx)
            for k in pairs(want) do if not got[k] then bad[#bad + 1] = pfx .. ": fehlt " .. k end end
            for k in pairs(got) do if not want[k] then bad[#bad + 1] = pfx .. ": zu viel " .. k end end
        end
        local w = {}
        for _, it in ipairs(H:List("we")) do w[#w + 1] = it.key end
        table.sort(w)
        local m = H:Match("/lp we")
        return #bad == 0 and m == "we", ("/lp we -> %s (Rest %s)%s"):format(table.concat(w, ", "), S(m), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""),
            "genau die passenden"
    end)
end

IMPL.T278 = function()
    return WithHint(true, function(H)
        local plan
        for _, it in ipairs(H:List("pl")) do if it.key == "plan" then plan = it end end
        if not plan then return false, "Eintrag plan fehlt", "vorhanden" end
        H:Select(plan, true)
        local resolved = H:Resolve("pl")              -- unvollständiges Wort + frische Auswahl -> plan
        H:Select(plan, true)
        H.selected.t = H.selected.t - 11              -- abgelaufen
        local stale = H:Resolve("pl")
        -- Enter: Slash-Handler führt die Auswahl aus
        local ran = 0
        H:Select(plan, true)
        WithCounter(LP.Planner, "Replan", function(n)
            SlashCmdList.LEVELPILOT("pl")
            ran = n()
        end)
        return resolved == "plan" and stale == "pl" and ran >= 1,
            ("Auswahl -> %s, nach 11 s -> %s, Enter führte aus %d×"):format(S(resolved), S(stale), ran), "plan, pl, >= 1"
    end)
end

IMPL.T279 = function()
    local H = LP.CmdHint
    local writes, hooks, scripts = 0, {}, 0
    local text = "/lp w"
    -- 3.12.90 (Ingametest 3.12.89: "LevelPilotCmdHint:SetPoint(): Wrong object type"): ein ECHTER, unsichtbarer EditBox-Rahmen statt
    -- einer Lua-Tabelle – die Liste verankert sich an der Box (SetPoint braucht einen Rahmen). Nur die gezählten Aufrufe ersetzt
    -- (Felder an diesem eigenen Rahmen, nie an Blizzard-Rahmen).
    TR.cmdHintBox = TR.cmdHintBox or CreateFrame("EditBox", nil, UIParent)
    local box = TR.cmdHintBox
    box:Hide()
    box:SetSize(300, 20)
    box:ClearAllPoints()
    box:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 0, 0)
    box.HookScript = function(_, ev, fn) hooks[ev] = fn end
    box.SetScript = function() scripts = scripts + 1 end
    box.SetText = function() writes = writes + 1 end
    box.Insert = function() writes = writes + 1 end
    box.GetText = function() return text end
    box.IsShown = function() return true end
    box.SetFocus = function() end
    local oInstant = H.instantClose
    return Guard(function()
        H.instantClose = true
        H:HookBox(box)
        if hooks.OnTextChanged then hooks.OnTextChanged(box) end
        local shown = H.frame and H.frame:IsShown()
        if hooks.OnTabPressed then hooks.OnTabPressed(box) end
        local selected = H:Selection() ~= nil
        if hooks.OnEditFocusLost then hooks.OnEditFocusLost(box) end
        text = "hallo"
        if hooks.OnTextChanged then hooks.OnTextChanged(box) end
        local hidden = not (H.frame and H.frame:IsShown())
        return writes == 0 and scripts == 0 and shown and selected and hidden,
            ("Liste gezeigt %s, Tab wählt %s, geschlossen %s · ins Chatfeld geschrieben %d×, SetScript %d×"):format(S(shown), S(selected),
                S(hidden), writes, scripts), "true, true, true · 0, 0"
    end, function() H.instantClose = oInstant H.selected = nil H:Hide() if H.hooked then H.hooked[box] = nil end end)
end

IMPL.T280 = function()
    local function devCount(dev)
        return WithHint(dev, function(H)
            local n = 0
            for _, it in ipairs(H:List("")) do
                for _, c in ipairs(LP.COMMANDS) do if c.dev and H.Base(c) == it.key then n = n + 1 end end
            end
            return n
        end)
    end
    local total = 0
    for _, c in ipairs(LP.COMMANDS) do if c.dev then total = total + 1 end end
    local a, b = devCount(false), devCount(true)
    return a == 0 and b == total and total > 0, ("ohne Entwickler %d, mit Entwickler %d von %d"):format(a, b, total), "0, alle"
end

IMPL.T281 = function()
    local lang0 = LP.db.language
    local bad, langs = {}, 0
    for _, code in ipairs({ "en", "fr", "es", "it", "pt", "ru", "ko", "cn", "tw" }) do
        LP.db.language = code
        LP:ResetLanguageCache()
        langs = langs + 1
        for _, c in ipairs(LP.COMMANDS) do
            local t = LP.L[c[3]]
            if type(t) ~= "string" or t == "" or t == c[3] then bad[#bad + 1] = code .. ": " .. c[3] break end
        end
        local ok, txt = pcall(string.format, LP.L["Enter = %s"], "/lp plan")
        if not ok or not txt:find("/lp plan", 1, true) then bad[#bad + 1] = code .. ": Enter = %s" end
    end
    LP.db.language = lang0
    LP:ResetLanguageCache()
    return #bad == 0, ("%d Sprachen%s"):format(langs, #bad > 0 and (" · fehlt: " .. table.concat(bad, "; ")) or ", alle Beschreibungen übersetzt"),
        "alle übersetzt"
end

------------------------------------------------------------------------
-- 3.12.28: Marktdaten-Netz (MN1–MN4). Ersetzt wird nur GoldSentinelMarkt.api und der eigene Zustand der Datei
-- (Hosts, Zähler, Zeitpunkte) – nie eine Blizzard-Funktion. Alles wird danach zurückgestellt.
------------------------------------------------------------------------
local function GMk() return _G.GoldSentinelMarkt end

-- Zustand der gemeinsamen Datei sichern, Test-Hosts und Test-API setzen, danach alles zurück
local function WithMarkt(api, body)
    local GM = GMk()
    if type(GM) ~= "table" then return NA end
    local keep = {}
    for _, k in ipairs({ "api", "hosts", "store", "lastEv", "readAt", "reader", "askAt", "answerAt", "answerT", "outbox", "prev", "feedUntil" }) do
        keep[k] = { GM[k] }
    end
    local st = GM.stats or {}
    local stCopy, drCopy = {}, {}
    for k, v in pairs(st) do if k ~= "dropped" then stCopy[k] = v end end
    for k, v in pairs(st.dropped or {}) do drCopy[k] = v end
    local marktDB = LP.marktDB
    local fakeApi = {}
    for k, v in pairs(GM.api or {}) do fakeApi[k] = v end
    for k, v in pairs(api or {}) do fakeApi[k] = v end
    local testDB = {}
    GM.api = fakeApi
    GM.hosts = {}
    GM.store = nil
    GM.lastEv, GM.readAt, GM.reader, GM.askAt, GM.answerAt, GM.prev = nil, nil, nil, nil, nil, nil
    GM.feedUntil = nil   -- 3.12.29 MK1: ein laufender Vollscan eines anderen Addons (FeedStart) darf den Test nicht stören
    GM.outbox = {}
    GM.Attach("LevelPilot", testDB)
    GM.askAt = nil
    LP.marktDB = testDB
    return Guard(function() return body(GM, testDB) end, function()
        for k, v in pairs(keep) do GM[k] = v[1] end
        if GM.stats then
            for k in pairs(GM.stats) do if k ~= "dropped" then GM.stats[k] = nil end end
            for k, v in pairs(stCopy) do GM.stats[k] = v end
            GM.stats.dropped = GM.stats.dropped or {}
            for k in pairs(GM.stats.dropped) do GM.stats.dropped[k] = nil end
            for k, v in pairs(drCopy) do GM.stats.dropped[k] = v end
        end
        LP.marktDB = marktDB
        pcall(LP.MarktSync, LP)
    end)
end

-- nachgebautes Auktionshaus mit drei Auktionen (keine Namen)
local function FakeAH(reads)
    local rows = { { 2589, 5, 500 }, { 2589, 10, 900 }, { 2592, 1, 120 } }
    return {
        GetNumReplicateItems = function() return #rows end,
        GetReplicateItemInfo = function(i)
            reads[1] = reads[1] + 1
            local r = rows[i + 1]
            if not r then return nil end
            return nil, nil, r[2], nil, nil, nil, nil, nil, nil, r[3], nil, nil, nil, nil, nil, nil, r[1]
        end,
        GetReplicateItemTimeLeft = function() return 4 end,
    }
end

local function MarktApi(clock, ah)
    return {
        now = function() return clock[1] end,
        time = function() return 1800000000 + math.floor(clock[1]) end,
        ms = function() return clock[1] * 1000 end,
        inCombat = function() return false end,
        ah = function() return ah end,
        faction = function() return "H" end,
        random = function() return 1 end,
        ahs = function() return false end,   -- 3.12.29 (GoldSentinelMarkt v2): Test unabhängig davon, ob AHSentinel geladen ist
    }
end

IMPL.T282 = function()
    local GM = GMk()
    local with = type(GM) == "table" and (tonumber(GM.VERSION) or 0) >= 1 and GM.hosts and GM.hosts.LevelPilot == LevelPilotDB
        and type(LevelPilotDB.gsMarkt) == "table"
    -- ohne die Datei: dieselben Funktionen mit einer Umgebung, in der GoldSentinelMarkt fehlt
    local okA, attached, okL, line
    WithEnv({ LP.MarktAttach, LP.MarktSync, LP.MarktLine }, { GoldSentinelMarkt = false }, function()
        okA, attached = pcall(LP.MarktAttach, LP, {})
        pcall(LP.MarktSync, LP)
        okL, line = pcall(LP.MarktLine, LP)
    end)
    local without = okA and attached == false and okL and line == "MARKT-NETZ: Datei fehlt"
    return with and without and true or false,
        ("mit Datei: angemeldet %s (v%s) · ohne Datei: Fehler %s, angemeldet %s, Zeile „%s“"):format(S(with),
            S(type(GM) == "table" and GM.VERSION), S(not okA), S(attached), S(line)),
        "true · false, false, MARKT-NETZ: Datei fehlt"
end

IMPL.T283 = function()
    local clock, reads = { 1000 }, { 0 }
    local ah = FakeAH(reads)
    return WithMarkt(MarktApi(clock, ah), function(GM, db)
        -- Gegenprobe an: ein Scan-Ereignis merkt das Lesen vor
        LP:MarktSync()
        GM.OnReplicate()
        local onPlanned = GM.readAt ~= nil
        GM.readAt, GM.lastEv = nil, nil
        -- Schalter aus (wie in der Zentrale)
        local sent0, acc0 = GM.stats.sent, GM.stats.accepted
        local out = WithSetting({ marktTeilen = false }, function()
            LP:MarktSync()
            local shareOff = GM.IsShareOn() == false and db.gsMarktAus == true
            clock[1] = clock[1] + 100
            GM.OnReplicate()
            local planned = GM.readAt ~= nil or GM.reader ~= nil
            GM.OnMessage("S:H:" .. GM.Enc(1800000000) .. ":" .. GM.Enc(2589) .. ",1k,5,1", "x")
            local accepted = GM.stats.accepted - acc0
            GM.Pump()
            return { shareOff, planned, accepted, GM.stats.sent - sent0, #GM.outbox }
        end)
        LP:MarktSync()
        local backOn = GM.IsShareOn()
        local ok = onPlanned and out[1] and not out[2] and out[3] == 0 and out[4] == 0 and out[5] == 0 and reads[1] == 0 and backOn
        return ok, ("an: Lesen vorgemerkt %s · aus: Schalter %s, Lesen vorgemerkt %s, gelesen %d, angenommen %d, gesendet %d, Warteschlange %d · wieder an %s")
            :format(S(onPlanned), S(out[1]), S(out[2]), reads[1], out[3], out[4], out[5], S(backOn)),
            "true · true, false, 0, 0, 0, 0 · true"
    end)
end

-- T-MK1: echter Wert wie bei AHSentinel FeedStart (Uhr + 300), dazu "AHSentinel geladen" in der echten api
IMPL.T287 = function()
    local GM = GMk()
    if type(GM) ~= "table" or type(GM.api) ~= "table" or type(GM.api.now) ~= "function" then return NA end
    local keepFeed, keepApi = GM.feedUntil, GM.api
    local fake = {}
    for k, v in pairs(GM.api) do fake[k] = v end
    fake.ahs = function() return true end
    local okRun, a, b
    Guard(function()
        GM.feedUntil = GM.api.now() + 300
        GM.api = fake
        okRun, a, b = pcall(IMPL.T283)
    end, function() GM.feedUntil, GM.api = keepFeed, keepApi end)
    local restored = GM.feedUntil == keepFeed and GM.api == keepApi
    return okRun and a == true and restored,
        ("T283 mit feedUntil = Uhr + 300 und AHSentinel geladen: %s (%s) · Zustand zurück %s"):format(S(okRun and a), S(b), S(restored)),
        "true (… Lesen vorgemerkt true …) · true"
end

IMPL.T284 = function()
    local clock = { 2000 }
    return WithMarkt(MarktApi(clock, nil), function(GM)
        LP:MarktSync()
        local errs = {}
        local function try(name, f, ...) local ok, e = pcall(f, ...) if not ok then errs[#errs + 1] = name .. ": " .. tostring(e) end end
        try("OnReplicate", GM.OnReplicate)
        clock[1] = clock[1] + 10
        local scans0 = GM.stats.scans
        try("Tick", GM.Tick)
        try("Get", GM.Get, 2589)
        try("DiagLines", GM.DiagLines)
        local okL, line = pcall(LP.MarktLine, LP)
        if not okL then errs[#errs + 1] = "MarktLine: " .. tostring(line) end
        local ok = #errs == 0 and GM.reader == nil and GM.stats.scans == scans0 and okL and line:find("ohne AH-API", 1, true) ~= nil
        return ok, ("Fehler %d%s · gelesen %s · Zeile „%s“"):format(#errs, #errs > 0 and (" (" .. errs[1] .. ")") or "",
            S(GM.reader ~= nil or GM.stats.scans ~= scans0), S(line)), "0 · false · … ohne AH-API …"
    end)
end

IMPL.T285 = function()
    local okL, line = pcall(LP.MarktLine, LP)
    local need = { "MARKT-NETZ: v", "Scans mitgelesen", "gesendet", "empfangen", "Speicher" }
    local miss = {}
    for _, w in ipairs(need) do if not (okL and line:find(w, 1, true)) then miss[#miss + 1] = w end end
    local okT, txt = pcall(LP.Protocol.Text, LP.Protocol)
    local inDiag = okT and type(txt) == "string" and txt:find("MARKT-NETZ", 1, true) ~= nil
    local toggle = WithCenter(function()
        for _, t in ipairs((LP.Center and LP.Center.toggles) or {}) do if t.key == "marktTeilen" then return true end end
        return false
    end)
    local def = LP.DEFAULTS and LP.DEFAULTS.marktTeilen == true
    local lbl = LP.L["Marktdaten teilen (anonym, nur Preise)"]
    return #miss == 0 and inDiag and toggle and def and type(lbl) == "string" and lbl ~= "",
        ("Zeile „%s“%s · Diagnose %s · Schalter %s · Standard an %s"):format(S(line), #miss > 0 and (" fehlt: " .. table.concat(miss, ", ")) or "",
            S(inDiag), S(toggle), S(def)), "alle Teile, true, true, true"
end

IMPL.T286 = function() return WithCenter(function()
    local Ce = LP.Center
    if not (Ce and Ce.toggles) or #Ce.toggles == 0 then return NA end
    local seen, dup = {}, {}
    for _, t in ipairs(Ce.toggles) do
        if t.parent and t.x and t.y then
            local k = tostring(t.parent) .. ":" .. t.x .. ":" .. t.y
            if seen[k] then dup[#dup + 1] = seen[k] .. " / " .. t.key else seen[k] = t.key end
        end
    end
    return #dup == 0, ("%d Schalter%s"):format(#Ce.toggles, #dup > 0 and (" · gleiche Stelle: " .. table.concat(dup, "; ")) or ", jeder an eigener Stelle"),
        "keine doppelte Stelle"
end) end

------------------------------------------------------------------------
-- 3.12.30 GR1: echte Lage aus der Diagnose 3.12.27 – Priester L10 in Undercity (1458), Fokus Tirisfal (1420),
-- aktueller Schritt TURNIN:405; Quest 445 "Lieferung in den Silberwald" fertig, Abgabe NPC 1937 im Silberwald (1421).
------------------------------------------------------------------------
IMPL.T288 = function()
    local P, QDB, Pr, Geo = LP.Planner, LP.QuestDB, LP.Protocol, LP.Geo
    local q445, q405 = QDB:Get(445), QDB:Get(405)
    if not (q445 and q445.ends and #q445.ends > 0 and q405) then return NA, "Quest 445/405 nicht in den Daten" end
    if LP.Virtual and LP.Virtual.active then return NA end
    local e1 = q445.ends[1]
    local endMap = type(e1) == "table" and e1[1]
    local ui, un, uw = Geo:ToWorld(1458, 60, 50)
    if not ui then return NA, "Undercity-Karte nicht verfügbar" end
    local log = {}
    for k, v in pairs(P.inLog) do log[k] = v end
    local savedSteps, savedIgn, savedPrint, savedShown = P.steps, LP.char.ignored, LP.Print, LP.db.stepsShown
    local doneBefore = 0
    for _ in pairs(LP.char.doneKeys) do doneBefore = doneBefore + 1 end
    return Guard(function()
        LP.char.ignored = {}
        wipe(P.inLog)
        P.inLog[445] = { complete = true, title = q445.name or "Quest 445", objDone = {}, index = 1 }
        P.inLog[405] = { complete = true, title = q405.name or "Quest 405", objDone = {}, index = 2 }
        local tasks = P:CollectTasks(ui, un, uw, 10)
        local t445
        for _, t in ipairs(tasks) do if t.t == "TURNIN" and t.id == 445 then t445 = t end end
        -- so wie in der Diagnose: nur die Abgabe 405 ist Schritt (445 liegt ausserhalb von Fokus, Nähe und Zone)
        local steps = { { t = "TURNIN", id = 405, key = "TURNIN:405", q = q405.name, map = 1458 } }
        P.steps = steps
        local function Viol()
            local v = Pr:CheckRules(true)
            for _, m in ipairs(v) do if m:find("Quest 445 ", 1, true) then return true end end
            return false
        end
        local before = Viol()                       -- Gegenprobe: ohne Hinweis meldet die Grundregel 445
        LP.db.stepsShown = 5
        local note = P:LaterTurnins(steps, tasks)
        local after = Viol()
        local pos
        for i, st in ipairs(steps) do if st == note then pos = i end end
        local zone = endMap and Geo:MapName(endMap) or ""
        local text = note and note.text or ""
        local named = text:find(q445.name or "Quest 445", 1, true) ~= nil and (zone == "" or text:find(zone, 1, true) ~= nil)
        local only445 = note and #note.laterIds == 1 and note.laterIds[1] == 445
        -- Überspringen / Zurückstellen entfernt den Hinweis nicht und schreibt nichts in den Charakter
        LP.Print = function() end
        LP.Engine:Skip(note)
        LP.Engine:Later(note)
        local doneAfter = 0
        for _ in pairs(LP.char.doneKeys) do doneAfter = doneAfter + 1 end
        local kept = not LP.char.ignored[445] and doneAfter == doneBefore and not LP.Engine.later[note and note.key or ""]
        -- viele Schritte: der Hinweis steht in der letzten angezeigten Zeile
        local many = {}
        for k = 1, 9 do many[k] = { t = "COMPLETE", id = 900000 + k, key = "COMPLETE:" .. (900000 + k) } end
        local n2 = P:LaterTurnins(many, tasks)
        local visible = n2 and many[5] == n2
        local ok = before and note and not after and pos == 2 and named and only445 and kept and visible
        return ok and true or false,
            ("ohne Hinweis Grundregel %s · Hinweis %s an Stelle %s: „%s“ · mit Hinweis Grundregel %s · Abgabe-Aufgabe 445 %s (Karte %s) · Überspringen/Zurückstellen lässt ihn stehen %s · bei 10 Schritten Zeile 5 %s")
                :format(before and "meldet 445" or "still", S(note ~= nil), S(pos), text, after and "meldet 445" or "still",
                    S(t445 ~= nil), S(t445 and t445.map or endMap), S(kept), S(visible)),
            "meldet 445 · true an Stelle 2 (Quest + Silberwald) · still · … · true · true"
    end, function()
        wipe(P.inLog)
        for k, v in pairs(log) do P.inLog[k] = v end
        P.steps, LP.char.ignored, LP.Print, LP.db.stepsShown = savedSteps, savedIgn, savedPrint, savedShown
    end)
end

-- 3.12.30 SP1: Messung des Speichers (keine volle Müllabfuhr). Ersetzt wird nur LP.Perf.mem (eigene Funktion).
IMPL.T289 = function()
    local Perf, P, G, Q, D = LP.Perf, LP.Planner, LP.Graph, LP.QuestDB, LP.Danger
    if not (Perf and Perf.MemLines and G.CacheSizes and Q.CacheSize and D.CacheSize) then return false, "Messung fehlt", "vorhanden" end
    -- a) angelegter Speicher je Aufruf: 100 -> 150 KB zählt 50, fällt der Wert (Müllabfuhr lief) zählt 0
    local savedMem, savedStat = Perf.mem, Perf.stats.t289
    local seq, i = { 100, 150, 150, 90 }, 0
    local a = Guard(function()
        Perf.stats.t289 = nil
        Perf.mem = function() i = i + 1 return seq[i] or 0 end
        Perf.Run("t289", "t289", false, function() end)
        Perf.Run("t289", "t289", false, function() end)
        return Perf.stats.t289 and Perf.stats.t289.kb or -1
    end, function() Perf.mem, Perf.stats.t289 = savedMem, savedStat end)
    -- b) Zeilen in der Diagnose
    local okT, txt = pcall(LP.Protocol.Text, LP.Protocol)
    local diag = okT and type(txt) == "string" and txt:find("SPEICHER Lua gesamt", 1, true) ~= nil
        and txt:find("SPEICHER angelegt je Modul", 1, true) ~= nil and txt:find("SPEICHER Bestand", 1, true) ~= nil
    -- c) Bestand: 10 Neuplanungen am selben Ort lassen die Zwischenspeicher nicht weiter wachsen
    local function Sizes() local v, u = G:CacheSizes() return { v, u, D:CacheSize(), Q:CacheSize() } end
    local grow = {}
    if not (LP.Virtual and LP.Virtual.active) and LP.Geo:Player() then
        -- 3.12.93 (Ingametest 3.12.91: T289 141 ms in einem Bild): jede Neuplanung als freigegebene Rechnung, dazwischen sichere Stellen
        PCallY(Coop, P.DoReplan, P)
        TR.Safe("T289")
        local s1 = Sizes()
        for _ = 1, 10 do PCallY(Coop, P.DoReplan, P) TR.Safe("T289") end
        local s2 = Sizes()
        local names = { "Luftlinien-Nachbarn", "Geländeprüfungen", "Gefahren-Strecken", "Quests entschlüsselt" }
        for k = 1, 4 do if s2[k] > s1[k] then grow[#grow + 1] = ("%s %d->%d"):format(names[k], s1[k], s2[k]) end end
    end
    local ok = a == 50 and diag and #grow == 0
    return ok, ("angelegt gezählt %s KB (soll 50) · Diagnose-Zeilen %s · Zuwachs nach 10 Neuplanungen: %s"):format(S(a), S(diag),
        #grow > 0 and table.concat(grow, ", ") or "keiner"), "50 · true · keiner"
end

-- 3.12.31 ML1: Schalter "Meldungen". Ersetzt wird nur LP.sink (eigene Tabelle) – keine Blizzard-Funktion.
IMPL.T290 = function()
    local A, UI = LP.Advisor, LP.UI
    local cnt = { chat = 0, screen = 0, sound = 0 }
    local fake = {
        chat = function() cnt.chat = cnt.chat + 1 end,
        screen = function() cnt.screen = cnt.screen + 1 end,
        sound = function() cnt.sound = cnt.sound + 1 end,
    }
    local savedSink, st = LP.sink, LP.msgStats
    local sup0, leak0 = st.suppressed, st.leaked
    local savedHints = A and A.hints
    local function Reset() cnt.chat, cnt.screen, cnt.sound = 0, 0, 0 end
    return Guard(function()
        LP.sink = fake
        local r = {}
        -- AUS: ungefragte Meldungen auf allen Wegen
        WithSetting({ messages = false }, function()
            LP:Print("t290")
            LP:Screen("t290", 1, 1, 1, 3175)
            local sup1 = st.suppressed
            if UI and UI.toastAnchor then UI:Toast({ key = "t290", sev = 1, text = "t290" }) end
            r.toastSup = (not (UI and UI.toastAnchor)) or st.suppressed > sup1
            if A and A.Run then A:Run() end
            r.hints = #(A and A.hints or {})
            r.off = { cnt.chat, cnt.screen, cnt.sound }
            -- Ausnahmen 1 und 2: Antwort auf eigene Handlung und Ausgabe während eines Befehls bleiben
            Reset()
            LP:Reply("t290")
            LP:AsReply(function() LP:Print("t290") LP:Screen("t290", 1, 1, 1) end)
            r.reply = { cnt.chat, cnt.screen }
            r.leakOff = st.leaked - leak0
            -- absichtlich falscher Fall: Ausgabe am Schalter vorbei wird erkannt
            Reset()
            LP.out.chat("t290 am Schalter vorbei")
            r.bypass = st.leaked - leak0
        end)
        st.leaked = leak0
        -- AN: unverändert
        Reset()
        WithSetting({ messages = true }, function()
            LP:Print("t290")
            LP:Screen("t290", 1, 1, 1, 3175)
            r.on = { cnt.chat, cnt.screen, cnt.sound }
        end)
        local okLine, line = pcall(LP.MessagesLine, LP)
        local toggle = WithCenter(function()
            for _, t in ipairs((LP.Center and LP.Center.toggles) or {}) do if t.key == "messages" then return true end end
            return false
        end)
        local def = LP.DEFAULTS and LP.DEFAULTS.messages == true
        local ok = r.off[1] == 0 and r.off[2] == 0 and r.off[3] == 0 and r.toastSup and r.hints == 0
            and r.reply[1] == 2 and r.reply[2] == 1 and r.leakOff == 0 and r.bypass == 1
            and r.on[1] == 1 and r.on[2] == 1 and r.on[3] == 1 and okLine and line == LP.L("MELDUNGEN: %s · unterdrückt %d · durchgerutscht %d", LP:MessagesOn() and LP.L["an"] or LP.L["aus"], st.suppressed, st.leaked)
            and toggle and def
        return ok, ("AUS: Chat %d, Mitte %d, Ton %d, Toast unterdrückt %s, Assistent-Hinweise %d · Antworten Chat %d, Mitte %d · durchgerutscht %d · am Schalter vorbei erkannt %d · AN: Chat %d, Mitte %d, Ton %d · Schalter %s, Standard an %s")
            :format(r.off[1], r.off[2], r.off[3], S(r.toastSup), r.hints, r.reply[1], r.reply[2], r.leakOff, r.bypass,
                r.on[1], r.on[2], r.on[3], S(toggle), S(def)),
            "AUS 0/0/0, true, 0 · 2, 1 · 0 · 1 · AN 1/1/1 · true, true"
    end, function()
        LP.sink = savedSink
        st.suppressed, st.leaked = sup0, leak0
        if A then
            A.hints = savedHints
            if A.Run then pcall(A.Run, A) end
        end
    end)
end

-- 3.12.32 PF-A: Danger:Route wurde schneller (ohne Funktionsaufruf je Punkt, Abbruch ab Grenze). Gegenprobe mit der
-- bisherigen Rechnung (Punkt für Punkt über Danger:At) auf 2000 Zufallsstrecken um den Spieler (eigener Zufall).
IMPL.T291 = function()
    local D = LP.Danger
    local inst, pn, pw = LP.Geo:Player()
    if not (D and D.Route and inst and pn) then return NA end
    local seed = 291
    local function rnd() seed = (seed * 1103515245 + 12345) % 2147483648 return seed / 2147483648 end
    local function Ref(n1, w1, n2, w2, skip)
        local dn, dw = n2 - n1, w2 - w1
        local len = math.sqrt(dn * dn + dw * dw)
        if len <= (skip or 0) then return 0 end
        local steps = math.max(1, math.ceil(len / 50))
        local mx = 0
        for i = 0, steps do
            if len * i / steps >= (skip or 0) then
                local v = D:At(inst, n1 + dn * i / steps, w1 + dw * i / steps)
                if v > mx then mx = v end
            end
        end
        return mx
    end
    local skips = { 0, 150, 37.5, 300 }
    local diff, diffStop, nonzero, first = 0, 0, 0, nil
    for k = 1, 2000 do
        local n1, w1 = pn + (rnd() - 0.5) * 2000, pw + (rnd() - 0.5) * 2000
        local n2, w2 = pn + (rnd() - 0.5) * 10000, pw + (rnd() - 0.5) * 10000
        local skip = skips[k % 4 + 1]
        if k % 25 == 0 then TR.Safe("T291") end      -- 3.12.93: 2000 Fälle (Ingametest 3.12.91: 130 ms in einem Bild)
        local ref = Ref(n1, w1, n2, w2, skip)
        -- 3.13.7: Orte der anderen Fraktion (Start-/Zielort ausgenommen) gehören zum Ergebnis von D:Route
        if D.RoutePlaces then ref = D:RoutePlaces(ref, inst, n1, w1, n2, w2, skip) end
        local new = D:Route(inst, n1, w1, n2, w2, skip)
        local lim = 1 + math.floor(rnd() * 60)
        local fast = D:Route(inst, n1, w1, n2, w2, skip, lim)
        if ref > 0 then nonzero = nonzero + 1 end
        if new ~= ref then diff = diff + 1 first = first or ("%d: neu %s, bisher %s"):format(k, new, ref) end
        if (fast >= lim) ~= (ref >= lim) then diffStop = diffStop + 1 first = first or ("%d: Grenze %d neu %s, bisher %s"):format(k, lim, fast, ref) end
    end
    -- absichtlich falscher Fall: eine Rechnung mit halb so vielen Messpunkten (alle 100 statt 50 Yards) muss der
    -- Vergleich als abweichend erkennen
    local caught = 0
    for k = 1, 500 do
        local n1, w1 = pn + (rnd() - 0.5) * 2000, pw + (rnd() - 0.5) * 2000
        local n2, w2 = pn + (rnd() - 0.5) * 10000, pw + (rnd() - 0.5) * 10000
        local dn, dw = n2 - n1, w2 - w1
        local steps = math.max(1, math.ceil(math.sqrt(dn * dn + dw * dw) / 100))
        local wrong = 0
        for i = 0, steps do
            local v = D:At(inst, n1 + dn * i / steps, w1 + dw * i / steps)
            if v > wrong then wrong = v end
        end
        if wrong ~= Ref(n1, w1, n2, w2, 0) then caught = caught + 1 end
    end
    return diff == 0 and diffStop == 0 and caught > 0, ("2000 Strecken (mit Gefahr %d): Abweichung %d, mit Grenze %d%s · Gegenprobe (halbe Messpunkte) erkannt %d von 500")
        :format(nonzero, diff, diffStop, first and (" – " .. first) or "", caught), "0, 0, Gegenprobe > 0"
end

-- 3.12.33 LP-D1: Ursache der "Questauswertung 495 ms": Perf.Run mass die Wanduhr über die Pausen einer Portion hinweg.
-- a) eigene Uhr und eine eigene Portion in LP.Jobs.list (eigene Tabellen): 5 ms rechnen, abgeben, 100 ms andere Bilder,
--    3 ms rechnen -> gemessen 8 ms (Gegenprobe: Wanduhr 108 ms). b) Questauswertung auf Stufe 31 (eigenes Volk) unter 16 ms.
IMPL.T292 = function()
    local Perf, J, P = LP.Perf, LP.Jobs, LP.Planner
    if not (Perf and J and J.list and P._perf_BuildCandidates) then return NA end
    local clock = 0
    local savedClock, savedStat = Perf.clock, Perf.stats.t292
    local measured, wall
    Guard(function()
        Perf.clock = function() return clock end
        Perf.stats.t292 = nil
        local co
        co = coroutine.create(function()
            Perf.Run("t292", "t292", false, function()
                clock = clock + 5
                J.Yield("plan")              -- Budget 4 ms überschritten -> abgeben
                clock = clock + 3
            end)
        end)
        J.list.t292 = { co = co, kinds = { plan = true }, sliceStart = 0, budget = 4, slices = 0, cpu = 0, mod = "t292" }
        local t0 = clock
        coroutine.resume(co)                 -- erste Portion bis zur Abgabe
        clock = clock + 100                  -- andere Bilder vergehen
        coroutine.resume(co)                 -- Rest
        wall = clock - t0
        measured = Perf.stats.t292 and Perf.stats.t292.max or -1
    end, function()
        J.list.t292 = nil
        Perf.clock, Perf.stats.t292 = savedClock, savedStat
    end)
    -- b) Rechenzeit der Questauswertung auf Stufe 31 (ohne Portionen, am Stück)
    local race
    for _, r in ipairs(LAGEN_RACES) do if r.f == LP:PlayerFaction() then race = r break end end
    -- b) Questauswertung Stufe 31 als Portion (wie im Spiel nach dem Einloggen und beim Stufenaufstieg):
    --    längste Portion < 16 ms, Gesamtrechenzeit zur Information
    local cpu, longest, slices, n = 0, 0, 0, #(LP.QuestDB:AllIds() or {})
    if race then
        WithLage(race, race.classes[1], 31, function()
            local co = coroutine.create(function() P._perf_BuildCandidates(P) end)
            J.list.t292b = { co = co, kinds = { plan = true }, budget = J.BUDGET_MS, slices = 0, cpu = 0, mod = "t292" }
            local okR = true
            Guard(function()
                while coroutine.status(co) ~= "dead" and slices < 500 do
                    J.list.t292b.sliceStart = Perf.clock()
                    local t = Perf.clock()
                    local ok2 = coroutine.resume(co)
                    local ms = Perf.clock() - t
                    if not ok2 then okR = false break end
                    slices, cpu = slices + 1, cpu + ms
                    if ms > longest then longest = ms end
                end
            end, function() J.list.t292b = nil end)
            if not okR then longest = 999 end
        end)
        pcall(P._perf_BuildCandidates, P)    -- Kandidaten für die echte Stufe wiederherstellen
    end
    local ok = measured == 8 and wall == 108 and slices > 0 and longest < 16
    return ok, ("in Portionen gemessen %s ms (Wanduhr %s ms) · Stufe 31, %d Quests: %d Portionen, längste %.2f ms, zusammen %.2f ms")
        :format(S(measured), S(wall), n, slices, longest, cpu), "8 (108) · längste Portion < 16 ms"
end

-- 3.12.33 GR1-K: eigene Schritte, Anzeige neu zeichnen, danach alles zurück
IMPL.T293 = function()
    local P, UI = LP.Planner, LP.UI
    if not (UI and UI.rows and UI.Refresh and UI.LaterSuffix) then return NA end
    local savedSteps = P.steps
    local note = { t = "NOTE", key = "LATER:445", laterIds = { 445 }, text = LP.L["|cff3dd694Später abgeben|r: "] .. "Test 445 (Silberwald)" }
    local steps = { { t = "TURNIN", id = 405, key = "TURNIN:405", q = "Test 405" }, note }
    local want = LP.L("+%d später abgeben", 1)
    local r = {}
    -- 3.12.90 (Ingametest 3.12.89 T293 false, Nachbau mit verstecktem Leitfenster gleich): UI:Refresh zeichnet nur bei offenem
    -- Leitfenster – für die Prüfung kurz öffnen, danach wie vorher
    local wasShown = UI:IsShown()
    Guard(function()
        if not wasShown then UI:Toggle() end
        P.steps = steps
        WithSetting({ compactMode = true }, function()
            UI:Refresh()
            local row = UI.rows[1]
            r.compact = row and row.text and (row.text:GetText() or ""):find(want, 1, true) ~= nil
            r.tip = row and rawget(row, "laterNote") == note
        end)
        WithSetting({ compactMode = false, stepsShown = 5 }, function()
            UI:Refresh()
            local row = UI.rows[1]
            r.normal = row and row.text and (row.text:GetText() or ""):find(want, 1, true) == nil and rawget(row, "laterNote") == nil
        end)
        -- Gegenprobe: ohne Hinweis nichts angehängt
        P.steps = { steps[1] }
        WithSetting({ compactMode = true }, function()
            UI:Refresh()
            local row = UI.rows[1]
            r.none = row and row.text and (row.text:GetText() or ""):find(want, 1, true) == nil
        end)
    end, function()
        P.steps = savedSteps
        if UI:IsShown() ~= wasShown then pcall(UI.Toggle, UI) end
        pcall(UI.Refresh, UI)
    end)
    local ok = r.compact and r.tip and r.normal and r.none
    return ok and true or false, ("kompakt angehängt %s, Tooltip %s · normale Liste ohne Anhang %s · ohne Hinweis kein Anhang %s")
        :format(S(r.compact), S(r.tip), S(r.normal), S(r.none)), "true, true · true · true"
end

-- 3.12.34 L-1: Der registrierte 300-s-Ticker, das Einloggen-Sample und der Diagnose-Text rufen UpdateAddOnMemoryUsage nie auf.
-- WithEnv setzt eine zählende Ersatzfunktion nur für die eigenen Funktionen ein (setfenv) – keine Blizzard-Tabelle wird geändert.
IMPL.T294 = function()
    local Pr = LP.Protocol
    if not (Pr and Pr.MemoryTick and Pr.MeasureAddon and Pr.LuaSample) then return false, "Funktionen fehlen", "vorhanden" end
    local tick
    for _, t in ipairs(LP.tickers or {}) do if t.name == "protocol_memory" then tick = t end end
    local calls = 0
    local fake = {
        UpdateAddOnMemoryUsage = function() calls = calls + 1 end,
        GetAddOnMemoryUsage = function() return 1024 end,
        C_AddOns = { GetAddOnMemoryUsage = function() return 1024 end },
    }
    local r = {}
    -- 3.13.3 (Ingametest 3.13.2: Bild "T294–T295" 96,8 ms): die drei Schritte je in eigener Hülle, dazwischen eine sichere Stelle
    local funcs = { Pr.MemoryTick, Pr.LuaSample, Pr.MeasureAddon, Pr.Text, Pr.ExportString }
    WithEnv(funcs, fake, function()
        if tick then tick.fn() end
        Pr.MemoryTick()
        r.tick = calls
    end)
    TR.Safe("T294")
    WithEnv(funcs, fake, function()
        pcall(Pr.ExportString)              -- Diagnose-Text (auch beim Ausloggen)
        r.text = calls - r.tick
    end)
    TR.Safe("T294")
    WithEnv(funcs, fake, function()
        Pr.MeasureAddon()                   -- Gegenprobe: die alte Messung im Ticker wäre 1 Aufruf
        r.measure = calls - r.tick - r.text
    end)
    TR.Safe("T294")
    local info = Pr.MemInfo()
    local ok = tick and tick.fn == Pr.MemoryTick and tick.interval == 300 and r.tick == 0 and r.text == 0 and r.measure == 1
        and info.luaNow and info.luaNow > 0
    return ok and true or false, ("Ticker 300 s registriert %s · UpdateAddOnMemoryUsage im Ticker %d×, im Diagnose-Text %d× · Gegenprobe Messung auf Befehl %d× · Lua gesamt %s KB")
        :format(S(tick ~= nil and tick.fn == Pr.MemoryTick), r.tick or -1, r.text or -1, r.measure or -1, S(info.luaNow and math.floor(info.luaNow))),
        "true · 0×, 0× · 1× · > 0"
end

-- 3.12.34 PF-A-Rest: Ursache der 26 ms im ersten T150-Lauf = Aufbau der Kandidaten und Dienst-NPCs nach vorherigen Tests
-- (Stufe/Sprache gewechselt). Prüft: kalt -> Portionen (eigene Schleife über LP.Jobs.Step), warm -> sofort.
IMPL.T295 = function()
    local P, J, Q = LP.Planner, LP.Jobs, LP.QuestDB
    if not (P.Cold and J and J.Step and Q.InvalidateServices) then return false, "fehlt", "vorhanden" end
    local r = {}
    local savedSync, savedMax = J.sync, J.maxSlice
    Guard(function()
        J.sync = false
        P:InvalidateCandidates()
        Q:InvalidateServices()
        r.cold = P:Cold()
        P:Replan(true)
        r.job = J.Running("replan")
        J.maxSlice = 0
        local frames = 0
        -- 3.13.3 (Ingametest 3.13.2: Bild "T294–T295" 96,8 ms – alle Portionen der kalten Planung in EINEM Bild der Testroutine):
        -- nach jeder Portion eine sichere Stelle. J.sync = false ist der Wert beim normalen Spielen (kein Ersatz); schiebt der Ticker
        -- der Aufträge während der Pause selbst eine Portion nach, zählt sie hier nicht mit (Ergebnis "fertig" und "längste" bleiben)
        while J.Running("replan") and frames < 500 do J.Step() frames = frames + 1 TR.Safe("T295") end
        r.frames, r.longest = frames, J.maxSlice
        r.done = not J.Running("replan")
        r.warm = not P:Cold()
        TR.Safe("T295")
        P:Replan(true)
        r.warmSync = not J.Running("replan")
    end, function()
        if J.Running("replan") then J.Cancel("replan") end
        J.sync, J.maxSlice = savedSync, math.max(savedMax or 0, J.maxSlice or 0)
    end, true)
    local ok = r.cold and r.job and r.done and (r.longest or 99) < 16 and r.warm and r.warmSync
    return ok and true or false, ("kalt erkannt %s · in Portionen %s (%d Bilder, längste %.2f ms) · danach warm %s · warmer Klick sofort %s")
        :format(S(r.cold), S(r.job), r.frames or -1, r.longest or -1, S(r.warm), S(r.warmSync)), "true · true (< 16 ms) · true · true"
end

-- 3.12.35 UC-W1: mit dem echten Wegnetz des Spielers (nur lesen). Ohne genug Wegdaten in Undercity nicht prüfbar;
-- die feste Prüfung mit den eingesandten Wegdaten läuft in der Offline-Routine (test_ucw1.lua).
IMPL.T296 = function()
    local G, Geo, N = LP.Graph, LP.Geo, LP.Nav
    if not (G.PathKnown and N.Known) then return false, "PathKnown fehlt", "vorhanden" end
    local npc = _G.LevelPilotData and LevelPilotData.N and LevelPilotData.N[1498]
    local s = npc and npc.s and npc.s[1]
    if not (s and s[1] == 1458) then return NA, "Bethor Iceshard nicht im Datenpaket" end
    local i2, n2, w2 = Geo:ToWorld(1458, s[2], s[3])
    local i1, n1, w1 = Geo:ToWorld(1458, 64.3, 35.9)
    if not (i1 and i2) then return NA, "Undercity-Karte nicht verfügbar" end
    local near = G:Near(i1, n1, w1, 60, 1458)
    if not near or #near == 0 then return NA, "keine gelaufenen Wege am Auktionshaus von Undercity" end
    local p = G:Path(i1, n1, w1, 1458, i2, n2, w2, 1458)
    local q = G:PathKnown(i1, n1, w1, 1458, i2, n2, w2, 1458)
    local knownP, knownQ = p and N.Known(p), q and N.Known(q)
    if not q then return NA, ("im eigenen Wegnetz kein ganz gelaufener Weg bis Bethor (normale Suche bekannt %s)"):format(S(knownP)) end
    return knownQ == true, ("normale Suche bekannt %s · nur bekannte Wege: %d Punkte, bekannt %s"):format(S(knownP), #q, S(knownQ)),
        "bekannt true"
end

-- 3.12.36 W3D B1: Ebenen-Angabe am Spieler, Speichern als Nummer, Schalter aus (Messung GSWegMess steht noch aus)
IMPL.T297 = function()
    local G = LP.Graph
    if not (G.LevelInfo and G.LvId and G.LvName and G.On) then return false, "W3D-Bausteine fehlen", "vorhanden" end
    local lv = G.LevelInfo()
    local form = type(lv) == "string" and lv:find("^%d+|[do]|") ~= nil
    local id = G.LvId(lv)
    local back = id and G.LvName({ lv = id })
    local off = G.On() == false
    return (form and back == lv and off) and true or false,
        ("Ebenen-Angabe „%s“ · gespeichert als Nr. %s · zurück „%s“ · Schalter aus %s"):format(tostring(lv), tostring(id),
            tostring(back), S(off)), "Karte|d/o|Unterzone · Nummer · gleich · true"
end

-- 3.12.37 Punkt 1/6: Startwegnetz aus Data/Wege.lua (nur WoW-Forever-Client), in Portionen beim Einloggen geladen
IMPL.T298 = function()
    local G = LP.Graph
    if not G.SeedWegeAktiv then return false, "Startwegnetz fehlt", "vorhanden" end
    if not G.SeedWegeAktiv() then return NA, "kein WoW-Forever-Client – Startwegnetz absichtlich aus" end
    local st = G.seedWegeStat
    if not st then return false, "nicht geladen", "geladen" end
    if not st.fertig then return NA, ("wird noch geladen (%d Wege)"):format(st.wege or 0) end
    local saved = 0
    for _, e in pairs(LP.db.graph.edges or {}) do if e[3] == "seed" then saved = saved + 1 end end
    -- 3.12.68 LW-4: 9 Zonen (vorher 3: Mulgore, Brachland, Donnerfels)
    local ok = st.karten == 9 and (st.knoten or 0) + (st.eigen or 0) > 1500 and (st.kanten or 0) > 2000 and saved == 0
    return ok, ("Karten %d · neue Knoten %d · eigene genutzt %d · Kanten %d · gespeichert %d"):format(st.karten or 0,
        st.knoten or 0, st.eigen or 0, st.kanten or 0, saved), "Karten 9 · Knoten > 1500 · Kanten > 2000 · gespeichert 0"
end

-- 3.12.38 W3D: Unterzonen-Namen -> Schluessel. 3.12.88 EULA: keine Tabelle aus den Spieldaten mehr – der Schluessel ist der Name
-- aus dem Spiel; alte gespeicherte "#ID:Name"-Schluessel bleiben lesbar.
IMPL.T299 = function()
    local G = LP.Graph
    if not (G.SubKey and G.SubName) then return false, "SubKey/SubName fehlen", "vorhanden" end
    local r = {}
    r.noTable = LP.AreaNames == nil
    r.same = G.SubKey("Magieviertel") == "Magieviertel" and G.SubKey("Magic Quarter") == "Magic Quarter" and G.SubKey("") == ""
    r.old = G.SubName("#1497:Magic Quarter") == "Magic Quarter" and G.SubName("#1638") == "1638" and G.SubName("Kanäle") == "Kanäle"
    r.lv = G.LvSprachfrei("1458|d|Magieviertel") == "1458|d|Magieviertel"
    local ok = r.noTable and r.same and r.old and r.lv
    return ok, ("keine Tabelle %s · Name bleibt %s · alte Schlüssel lesbar %s · Ebenen-Angabe unverändert %s"):format(S(r.noTable),
        S(r.same), S(r.old), S(r.lv)), "true ×4"
end

-- 3.12.39 LP-N1: Hinweise mit eigener Sammelliste (keine Toasts, keine echten Spielwerte)
local function Collect(fn)
    local out = {}
    fn(function(key, sev, text) out[#out + 1] = { key = key, sev = sev, text = text } end)
    return out
end
IMPL.T300 = function()
    local A = LP.Advisor
    if not A.CheckRested then return false, "CheckRested fehlt", "vorhanden" end
    local afk, resting, level = true, false, 20
    local fake = { UnitIsAFK = function() return afk end, IsResting = function() return resting end,
                   GetMaxPlayerLevel = function() return 60 end, InCombatLockdown = function() return false end }
    local r = {}
    local savedLevel = LP.PlayerLevel
    local ok, err = pcall(WithEnv, { A.CheckRested }, fake, function()
        LP.PlayerLevel = function() return level end
        r.afk = #Collect(A.CheckRested)
        resting = true r.rest = #Collect(A.CheckRested)
        resting, afk = false, false r.noafk = #Collect(A.CheckRested)
        afk, level = true, 60 r.max = #Collect(A.CheckRested)
        level = 20
        local was = LP.db.advRested
        LP.db.advRested = false r.off = #Collect(A.CheckRested)
        LP.db.advRested = was
        return true
    end)
    LP.PlayerLevel = savedLevel
    if not ok then error(err, 0) end
    local good = ok and r.afk == 1 and r.rest == 0 and r.noafk == 0 and r.max == 0 and r.off == 0
    return good and true or false, ("AFK draussen %s · im Gasthaus %s · nicht AFK %s · Stufe 60 %s · aus %s"):format(
        S(r.afk), S(r.rest), S(r.noafk), S(r.max), S(r.off)), "1 · 0 · 0 · 0 · 0"
end
CLIENT.T300 = "Ausserhalb von Gasthaus/Hauptstadt /afk eingeben: im Assistenten erscheint „Pause? Im Gasthaus …“ mit „Hinführen“; im Gasthaus nicht"
CLIENT.T301 = "Waffe einer Art mit niedriger Fertigkeit anlegen (z. B. neue Questwaffe): Hinweis „Waffenfertigkeit …: x von y“ – prüft, ob der Name der Fertigkeit genau der Waffenart entspricht (Sprache des Clients)"
IMPL.T301 = function()
    local A = LP.Advisor
    if not A.CheckWeaponSkill then return false, "CheckWeaponSkill fehlt", "vorhanden" end
    local rank = 40
    local lines = { { "Waffenfertigkeiten", true }, { "Einhandäxte", false }, { "Dolche", false } }
    local fake = {
        GetInventoryItemLink = function(_, slot) if slot == 16 then return "|Hitem:999301::::::::|h[Testaxt]|h|r" end end,
        -- 3.12.95 (Hinweis Prüf-Sitzung 18.11.): wie im Forever-Client nur C_Item.GetItemInfo, kein globales GetItemInfo (bis 3.12.94 gab
        -- der Test ein globales vor – im Forever-Client fiel die Prüfung still aus); unten Gegenprobe Classic: nur das globale
        C_Item = { GetItemInfo = function() return "Testaxt", nil, 2, 20, 15, "Waffe", "Einhandäxte" end },
        GetItemInfo = false,
        GetNumSkillLines = function() return #lines end,
        GetSkillLineInfo = function(i)
            local l = lines[i]
            if l[2] then return l[1], true end
            if l[1] == "Einhandäxte" then return l[1], false, nil, rank, 0, 0, 100 end
            return l[1], false, nil, 20, 0, 0, 100
        end,
    }
    local r = {}
    local ok = WithEnv({ A.CheckWeaponSkill, LP.API.ItemInfo }, fake, function()
        local h = Collect(A.CheckWeaponSkill)
        r.low, r.text = #h, h[1] and h[1].text
        rank = 80 r.ok = #Collect(A.CheckWeaponSkill)           -- 20 unter dem Hoechstwert: kein Hinweis
        rank = 40
        lines[2][1] = "Zweihandäxte" r.other = #Collect(A.CheckWeaponSkill)   -- andere Waffenart niedrig: kein Hinweis
        lines[2][1] = "Einhandäxte"
        fake.GetItemInfo, fake.C_Item = fake.C_Item.GetItemInfo, false                    -- Gegenprobe Classic: nur global
        r.classic = #Collect(A.CheckWeaponSkill)
        return true
    end)
    local good = ok and r.low == 1 and r.ok == 0 and r.other == 0 and r.classic == 1 and tostring(r.text):find("40", 1, true) ~= nil
    return good and true or false, ("40/100 %s („%s“) · 80/100 %s · andere Waffenart %s · Classic (nur globales GetItemInfo) %s")
        :format(S(r.low), tostring(r.text), S(r.ok), S(r.other), S(r.classic)), "1 · 0 · 0 · 1"
end

-- 3.12.40 LP-N1 4b: eigene Testtasche, eigene Fertigkeiten, Krieger
IMPL.T302 = function()
    local A, API = LP.Advisor, LP.API
    if not (A.CheckWeaponMaster and A.WEAPON_MASTERS) then return false, "CheckWeaponMaster fehlt", "vorhanden" end
    local NAMES = { [0] = "Einhandäxte", [15] = "Dolche", [6] = "Stangenwaffen", [19] = "Zauberstäbe" }
    local ITEMS = { [999401] = { 2, 15 }, [999402] = { 2, 6 }, [999403] = { 2, 19 }, [999400] = { 2, 0 } }
    local skills = { "Waffenfertigkeiten", "Einhandäxte" }
    local bag = {}
    local fake = {
        GetNumSkillLines = function() return #skills end,
        GetSkillLineInfo = function(i) return skills[i], i == 1 end,
        GetItemSubClassInfo = function(_, sub) return NAMES[sub] end,
        GetInventoryItemLink = function(_, slot) if slot == 16 then return "item:999400" end end,
        C_Item = false,
        GetItemInfoInstant = function(id)
            local n = tonumber(tostring(id):match("(%d+)"))
            local it = ITEMS[n]
            if it then return n, nil, nil, nil, nil, it[1], it[2] end
        end,
        UnitClass = function() return "Krieger", "WARRIOR" end,
        InCombatLockdown = function() return false end,
    }
    local saved = { BagSlots = API.BagSlots, BagItem = API.BagItem, PlayerLevel = LP.PlayerLevel, teacher = A.TeacherOK, hidden = A.Hidden }
    local level = 15
    local r = {}
    local ok, err = pcall(WithEnv, { A.CheckWeaponMaster }, fake, function()
        API.BagSlots = function(b) return b == 0 and 1 or 0 end
        API.BagItem = function(b, slot) return bag[1] end
        LP.PlayerLevel = function() return level end
        -- 3.13.0: der Ort (A:TeacherOK) wird in T362 geprüft; hier immer "am passenden Ort", unten Gegenprobe "nicht am Ort"
        A.TeacherOK = function() return true end
        A.Hidden = function() return false end
        bag[1] = { id = 999401, quality = 2, link = "[Testdolch]" }
        A.TeacherOK = function() return false end r.notHere = #Collect(A.CheckWeaponMaster) A.TeacherOK = function() return true end
        local h = Collect(A.CheckWeaponMaster)
        r.dagger, r.text = #h, h[1] and h[1].text or ""
        skills[3] = "Dolche" r.known = #Collect(A.CheckWeaponMaster) skills[3] = nil
        bag[1] = { id = 999401, quality = 0, link = "[grauer Dolch]" } r.grey = #Collect(A.CheckWeaponMaster)
        bag[1] = { id = 999403, quality = 2, link = "[Zauberstab]" } r.wand = #Collect(A.CheckWeaponMaster)
        bag[1] = { id = 999402, quality = 2, link = "[Stangenwaffe]" } r.pole15 = #Collect(A.CheckWeaponMaster)
        level = 20 r.pole20 = #Collect(A.CheckWeaponMaster)
        bag[1] = { id = 999401, quality = 2, link = "[Testdolch]" }
        skills[2] = "One-Handed Axes" r.calib = #Collect(A.CheckWeaponMaster) skills[2] = "Einhandäxte"
        -- 3.12.95 (Hinweis Prüf-Sitzung 18.11.): Gegenprobe Forever – nur C_Item.GetItemInfoInstant, kein globales
        fake.C_Item, fake.GetItemInfoInstant = { GetItemInfoInstant = fake.GetItemInfoInstant }, false
        r.forever = #Collect(A.CheckWeaponMaster)
        return true
    end)
    API.BagSlots, API.BagItem, LP.PlayerLevel = saved.BagSlots, saved.BagItem, saved.PlayerLevel
    A.TeacherOK, A.Hidden = saved.teacher, saved.hidden
    if not ok then error(err, 0) end
    -- Der Lehrer der Dolche fuer die Horde in Kalimdor ist Sayoc (11868); fehlt das Datenpaket, steht die Ersatzzeile da
    -- Lehrer der Dolche der eigenen Fraktion (Horde: Sayoc; Allianz: Woo Ping/Bixi/Ilyenia) – je nach Ort der nächste
    local teacher = not _G.LevelPilotData
    for _, x in ipairs(LP.QuestDB:ServiceNPCs().trainer or {}) do
        if x.id and A.WEAPON_MASTERS[x.id] and A.WEAPON_MASTERS[x.id][15] and x.name and r.text:find(x.name, 1, true) then teacher = true end
    end
    local good = r.dagger == 1 and teacher and r.known == 0 and r.grey == 0 and r.wand == 0 and r.pole15 == 0 and r.pole20 == 1 and r.calib == 0
        and r.forever == 1 and r.notHere == 0
    return good, ("nicht am Ort %s · Dolch ungelernt %s („%s“) · gelernt %s · grau %s · Zauberstab (Krieger) %s · Stangenwaffe Lv15 %s / Lv20 %s · Sprache passt nicht %s · Forever (nur C_Item) %s")
        :format(S(r.notHere), S(r.dagger), r.text, S(r.known), S(r.grey), S(r.wand), S(r.pole15), S(r.pole20), S(r.calib), S(r.forever)),
        "0 · 1 · 0 · 0 · 0 · 0 / 1 · 0 · 1"
end
-- 3.13.0 (Auftrag 19.11. 09:36): Später / Nicht mehr / passender Ort. Eigene Ablage (Tabellen ersetzt, danach zurück), Zeit, Ort,
-- Stufe, Kampf, Eile und Navi-Weg nur in eigenen Feldern ersetzt.
IMPL.T362 = function()
    local A, H, N, Geo = LP.Advisor, LP.Hints, LP.Nav, LP.Geo
    if not (A.Later and A.Never and A.Hidden and A.Unhide and A.Done and A.TeacherOK and A.HiddenList) then
        return false, "Später/Nicht mehr fehlt", "vorhanden"
    end
    local c = LP.char
    local saved = { sn = c.hintSnooze, nv = c.hintNever, now = A.Now, place = A.Place, lvl = LP.PlayerLevel, hints = A.hints,
                    hurry = A.Hurry, cur = N.CurrentPath, soon = A.Soon, ns = LP.QuestDB.NearestService }
    local now, place, level, hurry = 100000, 1454, 10, false
    local r = {}
    local ok, err = pcall(function()
        c.hintSnooze, c.hintNever = {}, {}
        A.Now = function() return now end
        A.Place = function() return place end
        LP.PlayerLevel = function() return level end
        A.Hurry = function() return hurry end
        A.Soon = function() end
        A.hints = { { key = "lpt362", text = "Erste Hilfe kannst du hier lernen" }, { key = "andere", text = "x" } }
        local h = A.hints[1]
        local t0 = now
        -- Später
        A:Later(h)
        r.drop = #A.hints == 1 and A.hints[1].key == "andere"
        r.h1 = A:Hidden("lpt362")
        now = t0 + 31 * 60 r.same = A:Hidden("lpt362")                         -- gleiche Stadt, gleiche Stufe -> ruht
        now = t0 + 10 * 60 level = 11 r.early = A:Hidden("lpt362")              -- nächste Stufe, aber unter 30 Min. -> ruht
        now = t0 + 31 * 60 r.lvl = A:Hidden("lpt362")                           -- nächste Stufe nach 30 Min. -> wieder da
        -- zweites Später: 60 Min.; Ortswechsel nach 45 Min. (andere Stadt), zurück in die erste
        local t1 = now
        A:Later(h)
        r.n2 = c.hintSnooze.lpt362.untilT - t1
        place = 1458 A:TrackPlaces() place = 1454
        now = t1 + 45 * 60 r.p45 = A:Hidden("lpt362")
        now = t1 + 61 * 60 r.p61 = A:Hidden("lpt362")
        r.cap = A:SnoozeRest(7) == A.SNOOZE_MAX and A:SnoozeRest(1) == 30 * 60 and A:SnoozeRest(3) == 120 * 60
        -- Nicht mehr: bleibt (Stufe, Ort, Zeit), steht in der Liste, "wieder zeigen" -> wieder da
        A:Never(h)
        level, place, now = 20, 1420, now + 30 * 86400
        r.never = A:Hidden("lpt362")
        local list = A:HiddenList()
        r.list = #list == 1 and list[1].never and list[1].text == "Erste Hilfe kannst du hier lernen"
        A:Unhide("lpt362")
        r.unhide = not A:Hidden("lpt362") and #A:HiddenList() == 0
        -- gelernt -> weg, auch aus der Liste (Erste Hilfe 3273 über die Hinweisquelle)
        A:Never({ key = "prof3273", text = "Erste Hilfe" })
        -- Lehrersuche ersetzt (sonst echte Wegsuche zu allen Trainern am Stück: im Nachbau 317 ms in einem Bild); hier geht es nur
        -- um "gelernt -> weg", der Ort ist oben geprüft
        LP.QuestDB.NearestService = function() return nil end
        local known = true
        local fake = { C_SpellBook = { IsSpellKnown = function() return known end }, IsSpellKnown = false, IsPlayerSpell = false,
                       -- 3.13.7: Fertigkeitenliste geladen, Erste Hilfe nicht darin (Known entscheidet)
                       GetNumSkillLines = function() return 1 end,
                       GetSkillLineInfo = function() return "Einhandschwerter", false, nil, 1, nil, nil, 50 end,
                       GetSpellInfo = function(id) return id == 3273 and "Erste Hilfe" or "Kochen" end }
        local okW, eW = pcall(WithEnv, { H.ProfessionHints, H.Known, H.SkillLines, H.ProfTier }, fake, function()
            local was = LP.db.hintProfessions
            LP.db.hintProfessions = true
            Collect(H.ProfessionHints)
            LP.db.hintProfessions = was
        end)
        if not okW then error(eW, 0) end
        r.done = c.hintNever.prof3273 == nil and #A:HiddenList() == 0
        -- Gegenprobe: nicht gelernt -> Eintrag bleibt
        A:Never({ key = "prof3273", text = "Erste Hilfe" }) known = false
        pcall(WithEnv, { H.ProfessionHints, H.Known, H.SkillLines, H.ProfTier }, fake, function()
            local was = LP.db.hintProfessions
            LP.db.hintProfessions = true
            Collect(H.ProfessionHints)
            LP.db.hintProfessions = was
        end)
        r.notDone = c.hintNever.prof3273 ~= nil
        -- nur am passenden Ort
        local fakeT = { InCombatLockdown = function() return false end, UnitAffectingCombat = function() return false end,
                        IsResting = function() return false end }
        local inCombat, resting = false, false
        fakeT.InCombatLockdown = function() return inCombat end
        fakeT.IsResting = function() return resting end
        local function ok2(v, d)
            local okT, res = pcall(WithEnv, { A.TeacherOK }, fakeT, function() return A:TeacherOK(v, d) end)
            if not okT then error(res, 0) end
            return res
        end
        place, hurry = 1411, false
        N.CurrentPath = function() return nil, 2 end
        local tv = { map = 1454, x = 50, y = 50 }
        r.near = ok2(tv, 120)
        r.far = ok2(tv, 600)
        resting = true place = 1454 r.city = ok2(tv, 600)
        place = 1411 r.otherCity = ok2(tv, 600) resting = false
        inCombat = true r.combat = ok2(tv, 50) inCombat = false
        hurry = true r.hurry = ok2(tv, 50) hurry = false
        r.none = ok2(nil, nil)
        -- auf dem Weg: Lehrer 100 yd neben einer Strecke im Durotar, Gegenprobe 400 yd daneben
        local ai, an, aw = Geo:ToWorld(1411, 40, 50)
        local bi, bn, bw = Geo:ToWorld(1411, 60, 50)
        if ai and bi then
            N.CurrentPath = function() return { { ai, an, aw }, { bi, bn, bw } }, 2 end
            local mn, mw = (an + bn) / 2, (aw + bw) / 2
            local function at(off)
                -- Punkt senkrecht zur Strecke: Karte zurückrechnen ist nicht nötig, NearRoute rechnet in Weltkoordinaten
                local dn, dw = bn - an, bw - aw
                local len = math.sqrt(dn * dn + dw * dw)
                return mn + (-dw / len) * off, mw + (dn / len) * off
            end
            local savedTW = Geo.ToWorld
            local pn, pw = at(100)
            Geo.ToWorld = function(self, m, x, y) if m == 999362 then return ai, pn, pw end return savedTW(self, m, x, y) end
            r.route = ok2({ map = 999362, x = 0, y = 0 }, 900)
            pn, pw = at(400)
            r.offRoute = ok2({ map = 999362, x = 0, y = 0 }, 900)
            Geo.ToWorld = savedTW
        else
            r.route, r.offRoute = true, false
        end
        return true
    end)
    c.hintSnooze, c.hintNever = saved.sn, saved.nv
    LP.QuestDB.NearestService = saved.ns
    A.Now, A.Place, LP.PlayerLevel, A.hints, A.Hurry, N.CurrentPath, A.Soon = saved.now, saved.place, saved.lvl, saved.hints, saved.hurry,
        saved.cur, saved.soon
    if not ok then error(err, 0) end
    local good = r.drop and r.h1 and r.same and r.early and not r.lvl and r.n2 == 3600 and r.p45 and not r.p61 and r.cap and r.never
        and r.list and r.unhide and r.done and r.notDone and r.near and not r.far and r.city and not r.otherCity and not r.combat
        and not r.hurry and not r.none and r.route and not r.offRoute
    return good and true or false, ("Später: weg %s, ruht %s, gleiche Stadt+Stufe 31 Min. %s, nächste Stufe 10 Min. %s / 31 Min. %s · zweimal %s s, Ort 45 Min. %s / 61 Min. %s, Grenzen %s · Nicht mehr %s, Liste %s, wieder zeigen %s · gelernt weg %s / ungelernt bleibt %s · Ort: 120 yd %s, 600 yd %s, Stadt %s, andere Stadt %s, Kampf %s, Eile %s, ohne Lehrer %s, Weg 100 yd %s / 400 yd %s")
        :format(S(r.drop), S(r.h1), S(r.same), S(r.early), S(r.lvl), S(r.n2), S(r.p45), S(r.p61), S(r.cap), S(r.never), S(r.list),
            S(r.unhide), S(r.done), S(r.notDone), S(r.near), S(r.far), S(r.city), S(r.otherCity), S(r.combat), S(r.hurry), S(r.none),
            S(r.route), S(r.offRoute)),
        "true, true, true, true / false · 3600, true / false, true · true, true, true · true / true · true, false, true, false, false, false, false, true / false"
end
CLIENT.T362 = "Bei einem echten Vorschlag (z. B. „Erste Hilfe kannst du hier lernen“) „Später“ klicken: in derselben Stadt und Stufe kommt er nicht wieder; „Nicht mehr“ bei einem anderen: auch nach /reload weg, in der Zentrale (Assistent) unter „Ausgeblendete Vorschläge“ mit „wieder zeigen“"

-- 3.13.7 (Auftrag 23.11.): Fertigkeitenliste, Berufszauber-Namen und Lehrer nur in eigenen Feldern ersetzt (WithEnv bzw. Felder der
-- Module, danach zurück). Kochen = 2550, Erste Hilfe = 3273.
IMPL.T369 = function()
    local H, A, Q = LP.Hints, LP.Advisor, LP.QuestDB
    if not (H and H.ProfessionHints and H.SkillLines and H.ProfTier) then return false, "Berufsprüfung fehlt", "Hints.SkillLines/ProfTier" end
    local saved = { lvl = LP.PlayerLevel, ns = Q.NearestService, tok = A.TeacherOK, hid = A.Hidden, opt = LP.db.hintProfessions }
    local lines, level, known = {}, 10, false
    local fake = {
        GetNumSkillLines = function() local n = 0 for _ in pairs(lines) do n = n + 1 end return n end,
        GetSkillLineInfo = function(i)
            local k = 0
            for name, v in pairs(lines) do k = k + 1 if k == i then return name, false, nil, v[1], nil, nil, v[2] end end
        end,
        GetSpellInfo = function(id) return id == 2550 and "Kochen" or (id == 3273 and "Erste Hilfe" or nil) end,
        C_SpellBook = { IsSpellKnown = function() return known end }, IsSpellKnown = false, IsPlayerSpell = false,
    }
    local r = {}
    local function run()
        local hints
        local okW, eW = pcall(WithEnv, { H.ProfessionHints, H.Known, H.SkillLines, H.ProfTier }, fake, function()
            hints = Collect(H.ProfessionHints)
        end)
        if not okW then error(eW, 0) end
        local cook, cookJ = 0, 0
        for _, h in ipairs(hints or {}) do
            if h.key == "prof2550" then cook = cook + 1 elseif h.key == "prof2550j" then cookJ = cookJ + 1 end
        end
        return cook, cookJ
    end
    local ok, err = pcall(function()
        LP.PlayerLevel = function() return level end
        Q.NearestService = function() return { name = "Testlehrer", map = 1411, x = 50, y = 50 }, 20 end
        A.TeacherOK = function() return true end
        A.Hidden = function() return false end
        LP.db.hintProfessions = true
        -- 1) Kochen gelernt (Lehrling 30/75, Stufe 25 wie im Befund) -> kein Hinweis (vorher: Known(2550) false -> "Kochen kannst du
        --    hier lernen"); mit 60/75 wäre Geselle richtig (Fall 2)
        lines = { Kochen = { 30, 75 }, ["Erste Hilfe"] = { 1, 75 } } level = 25 known = false
        local a, b = run() r.learned = a == 0 and b == 0 r.learnedTxt = a .. "/" .. b
        -- 2) Stufe voll: 55/75, Stufe 12 -> Geselle
        lines = { Kochen = { 55, 75 } } level = 12
        a, b = run() r.journey = a == 0 and b == 1
        -- Gegenproben Geselle: Fertigkeit 49 -> nichts; Stufe 9 -> nichts; schon Geselle (60/150) -> nichts
        lines = { Kochen = { 49, 75 } } a, b = run() r.j49 = a == 0 and b == 0
        lines = { Kochen = { 55, 75 } } level = 9 a, b = run() r.j9 = a == 0 and b == 0
        lines = { Kochen = { 60, 150 } } level = 25 a, b = run() r.j150 = a == 0 and b == 0
        -- 3) Liste leer (noch nicht geladen) -> kein Hinweis, auch wenn nicht gelernt
        lines = {} known = false a, b = run() r.empty = a == 0 and b == 0
        -- 4) nicht gelernt (Liste geladen, Kochen nicht darin, Zauber unbekannt) -> Lehrling
        lines = { ["Erste Hilfe"] = { 10, 75 } } known = false a, b = run() r.apprentice = a == 1 and b == 0
        -- Gegenprobe: nicht in der Liste, aber Zauber bekannt -> gelernt -> kein Hinweis
        known = true a, b = run() r.knownSpell = a == 0 and b == 0
        -- 5) Name des Berufszaubers unbekannt -> kein Hinweis
        local gsi = fake.GetSpellInfo
        fake.GetSpellInfo = function() return nil end known = false
        a, b = run() r.noName = a == 0 and b == 0
        fake.GetSpellInfo = gsi
    end)
    LP.PlayerLevel, Q.NearestService, A.TeacherOK, A.Hidden, LP.db.hintProfessions = saved.lvl, saved.ns, saved.tok, saved.hid, saved.opt
    if not ok then error(err, 0) end
    local good = r.learned and r.journey and r.j49 and r.j9 and r.j150 and r.empty and r.apprentice and r.knownSpell and r.noName
    return good and true or false, ("gelernt (Kochen 30/75, Stufe 25) -> kein Hinweis %s (%s) · Stufe voll 55/75, Stufe 12 -> Geselle %s · 49 -> keiner %s · Stufe 9 -> keiner %s · schon Geselle -> keiner %s · Liste leer -> keiner %s · nicht gelernt -> Lehrling %s · Zauber bekannt -> keiner %s · Name unbekannt -> keiner %s")
        :format(S(r.learned), tostring(r.learnedTxt), S(r.journey), S(r.j49), S(r.j9), S(r.j150), S(r.empty), S(r.apprentice), S(r.knownSpell), S(r.noName)),
        "true ×9"
end

-- 3.13.7 Entscheid des Nutzers 22.11. 16:57 "Alle Sperren aufheben und keine Wege mehr sperren": alte Daten mit 20 Sperren -> nach dem
-- Laden 0; 4 Min. ohne Annäherung (FEST) -> keine Sperre; Sperre aus alten Daten/fremder Herkunft -> Wegsuche nimmt die Kante trotzdem;
-- Wegdaten senden keine Sperren. Ändert keine echten Daten (Testtabellen; Wegnetz-Knoten wie T219 in der Sicherung der Testroutine).
IMPL.T370 = function()
    local Gr, N, Geo = LP.Graph, LP.Nav, LP.Geo
    if not (Gr and Gr.ClearBlocks and N and N.OnStuck) then return false, "Graph.ClearBlocks fehlt", "vorhanden" end
    local r = {}
    -- 1) Laden: 20 Sperren + 3 FEST-Einträge (2 gesperrt) in Testtabellen -> 0 Sperren, 0 gesperrte Einträge, Protokoll mit Zahl
    local g = { blocked = {} }
    for i = 1, 20 do g.blocked[i .. ":" .. (i + 1)] = { t = 1, why = "FEST" } end
    local db = { festLog = { { map = 1, blocked = true }, { map = 2 }, { map = 3, blocked = true } } }
    local logged
    local savedAddL = LP.Protocol and LP.Protocol.AddL
    local ok, err = pcall(function()
        if LP.Protocol then LP.Protocol.AddL = function(_, kind, key, a, b) logged = kind .. ":" .. tostring(a) .. "/" .. tostring(b) end end
        local nb, nf = Gr.ClearBlocks(g, db)
        local left = 0 for _ in pairs(g.blocked) do left = left + 1 end
        local fl = 0 for _, f in ipairs(db.festLog) do if f.blocked then fl = fl + 1 end end
        r.cleared = nb == 20 and nf == 2 and left == 0 and fl == 0 and #db.festLog == 3
        r.clearedTxt = ("%d -> %d, FEST %d -> %d"):format(nb, left, nf, fl)
        r.logged = logged == "wege:20/2"
    end)
    if LP.Protocol then LP.Protocol.AddL = savedAddL end
    if not ok then error(err, 0) end
    -- 2) FEST nach 4 Min. ohne Annäherung: N:OnStuck sperrt nichts (Graph:Block wird nicht aufgerufen, G.blocked bleibt gleich)
    local pi, pn, pw = Geo:Player()
    if not pi then return true, "keine Position" end
    local Gdb = LP.db.graph
    local function nBlocked() local c = 0 for _ in pairs(Gdb and Gdb.blocked or {}) do c = c + 1 end return c end
    local before = nBlocked()
    local saved = { stuck = LP.Protocol and LP.Protocol.Stuck, recalc = N.Recalc, key = N.stuckKey,
                    slog = N.stuckLog, fl = type(LP.db.festLog) == "table" and #LP.db.festLog or nil, ms = N.stuck and N.stuck.moveSecs }
    local calls = 0
    ok, err = pcall(function()
        if LP.Protocol then LP.Protocol.Stuck = function() end end
        N.Recalc = function() end
        N.stuckLog = {}
        if N.stuck then N.stuck.moveSecs = 240 end
        WithCounter(Gr, "Block", function(n)
            N:OnStuck({ key = "LPTestFest", inst = pi, n = pn + 500, w = pw, label = "LPTest" }, 600)
            calls = n()
        end)
    end)
    if LP.Protocol then LP.Protocol.Stuck = saved.stuck end
    N.Recalc, N.stuckKey, N.stuckLog = saved.recalc, saved.key, saved.slog
    if N.stuck then N.stuck.moveSecs = saved.ms end
    if saved.fl and type(LP.db.festLog) == "table" then while #LP.db.festLog > saved.fl do table.remove(LP.db.festLog) end end
    if not ok then error(err, 0) end
    r.noBlock = calls == 0 and nBlocked() == before
    r.blockFn = Gr:Block(1, 2, "FEST") == false and not Gr:IsBlocked(1, 2)
    -- 3) Sperre aus alten Daten / von anderen Spielern (Eintrag in G.blocked): die Wegsuche nimmt die Kante trotzdem
    local pz = select(4, Geo:Player())
    local i1 = Gr:AddNode(pi, pn + 3000, pw + 3000, pz)
    local i2 = Gr:AddNode(pi, pn + 3100, pw + 3000, pz)
    Gr:AddEdge(i1, i2, "s")
    local key = (i1 < i2) and (i1 .. ":" .. i2) or (i2 .. ":" .. i1)
    Gdb.blocked = type(Gdb.blocked) == "table" and Gdb.blocked or {}
    Gdb.blocked[key] = { t = 1, why = "FEST" }
    local usesEdge, exported = false, nil
    ok, err = pcall(function()
        local p = Gr:PathRaw(pi, pn + 3000, pw + 3000, pz, pi, pn + 3100, pw + 3000, pz)
        for _, q in ipairs(p or {}) do if q.via == "s" then usesEdge = true end end
        local d = Gr:WegeData(nil, nil, true)
        exported = d and #(d.blocked or {})
    end)
    Gdb.blocked[key] = nil
    if not ok then error(err, 0) end
    r.ignored = usesEdge
    r.noSend = exported == 0
    local good = r.cleared and r.logged and r.noBlock and r.blockFn and r.ignored and r.noSend
    return good and true or false, ("20 Sperren beim Laden -> 0 %s (%s) · Protokoll %s · FEST 4 Min. -> keine Sperre %s (Graph:Block %d×) · Graph:Block sperrt nicht %s · alte/empfangene Sperre ignoriert %s · gesendet %s Sperren")
        :format(S(r.cleared), tostring(r.clearedTxt), S(r.logged), S(r.noBlock), calls, S(r.blockFn), S(r.ignored), tostring(exported)),
        "true · true · true (0×) · true · true · 0"
end

-- 3.13.7 Nachtrag 22.11. 16:58: einzige Ausnahme sind Dörfer/Städte der anderen Fraktion (feste Ortsliste aus dem Datenpaket, nur für
-- Wege). Horde: Strecke durch ein Allianz-Dorf zählt als Sperrgebiet (D.TOWN), aussen herum nicht; Ziel im Dorf bleibt erreichbar;
-- Allianz-Liste enthält dieses Dorf nicht (Allianz darf hindurch); neutrale Städte in keiner Liste.
IMPL.T371 = function()
    local D, Geo = LP.Danger, LP.Geo
    local Npc = _G.LevelPilotData and _G.LevelPilotData.N
    if not (D and D.BuildPlaces and D.PlaceHit) then return false, "Ortsliste fehlt", "Danger.BuildPlaces" end
    if type(Npc) ~= "table" then return true, "kein Datenpaket" end
    local my = LP:PlayerFaction() == "Horde" and "H" or "A"
    local enemy = my == "H" and "A" or "H"
    local placesE = D.BuildPlaces(Npc, enemy)          -- Orte, die dieser Charakter meidet
    local placesM = D.BuildPlaces(Npc, my)             -- Orte, die ein Charakter der anderen Fraktion meiden würde
    local nE, nM = 0, 0
    for _, l in pairs(placesE) do nE = nE + #l end
    for _, l in pairs(placesM) do nM = nM + #l end
    -- ein Dorf der anderen Fraktion auf dem eigenen Kontinent (der kleinste Ort mit mindestens 8 NPCs)
    local pi = Geo:Player()
    local p
    for _, q in ipairs(placesE[pi] or {}) do if q.npcs >= 8 and (not p or q.npcs < p.npcs) then p = q end end
    if not p then return NA, "kein Ort der anderen Fraktion auf diesem Kontinent" end
    local r = {}
    local savedPlaces = D.places
    local ok, err = pcall(function()
        if not D:Ready() then D:Build() end
        D.places = { [pi] = { p } }        -- nur dieser Ort (ein Nachbarort soll "aussen herum" nicht verfälschen)
        local R = p.r
        -- quer hindurch / aussen herum (2 Radien neben dem Mittelpunkt)
        r.through = D.PlaceHit(pi, p.n - 3 * R, p.w, p.n + 3 * R, p.w) == true
        r.around = D.PlaceHit(pi, p.n - 3 * R, p.w + 2.2 * R, p.n + 3 * R, p.w + 2.2 * R) == false
        r.routeThrough = D:Route(pi, p.n - 3 * R, p.w, p.n + 3 * R, p.w, 0) >= D.TOWN
        -- Ziel im Ort: Strecke endet im Ort -> zählt nicht (hinein darf man)
        r.into = D:RoutePlaces(0, pi, p.n - 3 * R, p.w, p.n, p.w, 0) < D.TOWN
        -- Wegsuche-Kosten: Strecke durch den Ort ist ein Sperrgebiet (x25), aussen herum nicht
        r.segment = D:Segment(pi, p.n - 3 * R, p.w, p.n + 3 * R, p.w) >= D.TOWN
        -- Ziel selbst bleibt erlaubt (D:At ohne Ortsliste)
        r.target = D:At(pi, p.n, p.w) < D.TOWN or "Wachen"
        -- Charakter der anderen Fraktion: dieses Dorf steht nicht in seiner Liste
        local inOther = false
        for _, q in ipairs(placesM[pi] or {}) do if (q.n - p.n) ^ 2 + (q.w - p.w) ^ 2 <= (q.r + p.r) ^ 2 then inOther = true end end
        r.otherOK = not inOther
        -- neutrale Städte in keiner Liste (Mitte laut Datenpaket: Gastwirt/Flugmeister-Gegend)
        r.neutral = true
        r.neutralTxt = {}
        for _, c in ipairs({ { 1434, 27.0, 77.0, "Beutebucht" }, { 1413, 62.5, 37.5, "Ratschet" }, { 1446, 51.5, 28.5, "Gadgetzan" }, { 1452, 61.0, 38.5, "Everlook" } }) do
            local ci, cn, cw = Geo:ToWorld(c[1], c[2], c[3])
            if ci then
                for _, set in ipairs({ placesE, placesM }) do
                    for _, q in ipairs(set[ci] or {}) do
                        if (cn - q.n) ^ 2 + (cw - q.w) ^ 2 <= q.r * q.r then r.neutral = false r.neutralTxt[#r.neutralTxt + 1] = c[4] end
                    end
                end
            end
        end
    end)
    D.places = savedPlaces
    if not ok then error(err, 0) end
    local good = r.through and r.around and r.routeThrough and r.into and r.segment and r.otherOK and r.neutral
    return good and true or false, ("Orte der anderen Fraktion %d, der eigenen %d · Testort Karte %s (%d NPCs, Radius %d yd): hindurch -> Sperrgebiet %s, aussen herum frei %s, Route hindurch %s, Ziel im Ort erlaubt %s, Wegkosten hindurch x25 %s, Ziel selbst %s · andere Fraktion darf hindurch %s · neutrale Städte frei %s%s")
        :format(nE, nM, tostring(p.map), p.npcs, math.floor(p.r), S(r.through), S(r.around), S(r.routeThrough), S(r.into), S(r.segment), S(r.target),
            S(r.otherOK), S(r.neutral), #r.neutralTxt > 0 and (" (" .. table.concat(r.neutralTxt, ", ") .. ")") or ""),
        "true ×7"
end

-- 3.13.7 LP-M1: Annahme/Abgabe ohne Ort -> "Ort unbekannt – Questbeschreibung lesen"; mit Ort -> Entfernung + Zone; COMPLETE unverändert;
-- belegte Abgabe 79007 (Westfall); Aufgabe ohne Ort kommt hinter alle Aufgaben dieses Kontinents (vorher Kosten 5000 = vor 6 km).
IMPL.T372 = function()
    local UI, P, Q, Geo = LP.UI, LP.Planner, LP.QuestDB, LP.Geo
    if not (UI and UI.StepText and Q and Q.EXTRA_ENDS and P.NO_PLACE_COST) then return false, "LP-M1 fehlt", "vorhanden" end
    local pi, pn, pw, pmap = Geo:Player()
    if not pi then return true, "keine Position" end
    local TXT = LP.L["Ort unbekannt – Questbeschreibung lesen"]
    local r = {}
    local function has(s, sub) return tostring(s):find(sub, 1, true) ~= nil end
    -- Anzeige
    local t1 = UI:StepText({ t = "TURNIN", q = "LPTest Abgabe", id = 990001, key = "TURNIN:990001" }, false)
    local t2 = UI:StepText({ t = "ACCEPT", q = "LPTest Annahme", id = 990002, key = "ACCEPT:990002" }, true)
    local other = pmap == 1436 and 1429 or 1436
    local t3 = UI:StepText({ t = "TURNIN", q = "LPTest Abgabe", id = 990003, map = other, x = 50, y = 50, key = "TURNIN:990003" }, false)
    local c1 = UI:StepText({ t = "COMPLETE", q = "LPTest Ziel", id = 990004, key = "COMPLETE:990004" }, false)
    local c2 = UI:StepText({ t = "COMPLETE", q = "LPTest Ziel", id = 990004, key = "COMPLETE:990004" }, true)
    r.turnin = has(t1, TXT)
    r.accept = has(t2, TXT) and not has(t2, LP.L["Questgeber an dieser Stelle"])
    r.withPlace = not has(t3, TXT) and has(t3, Geo:MapName(other) or "?") and (has(t3, " km") or has(t3, LP.L[" Yards"]))
    r.complete = not has(c1, TXT) and has(c2, TXT)
    -- belegte Abgabe 79007 (aufgezeichnet ohne "e")
    local savedRec = LP.db.qdb[79007]
    local ok, err = pcall(function()
        LP.db.qdb[79007] = { n = "LPTest Notiz", l = 22, s = { 1413, 46.3, 73.9 }, f = "H" }
        Q:Invalidate(79007)
        local q = Q:Get(79007)
        local e = q and q.ends and q.ends[1]
        r.extra = e and e[1] == 1436 and e[2] == 37.5 and e[3] == 50.7 or false
    end)
    LP.db.qdb[79007] = savedRec
    Q:Invalidate(79007)
    if not ok then error(err, 0) end
    -- Reihenfolge: ohne Ort hinter zwei Aufgaben in 6 und 8 km Weg (Luftlinie), gleicher Wert
    local function task(t, id, dn)
        return { t = t, id = id, q = "LPTest " .. id, key = t .. ":" .. id, value = 1, inst = dn and pi or nil, n = dn and (pn + dn) or nil, w = dn and pw or nil }
    end
    local function order()
        local tasks = { task("TURNIN", 990010, nil), task("COMPLETE", 990011, 6600), task("COMPLETE", 990012, 8800) }
        local out = P:Order(tasks, pi, pn, pw)
        local pos
        for i, t in ipairs(out) do if t.id == 990010 then pos = i end end
        return pos, #out
    end
    local pos, n = order()
    r.last = pos == n and n == 3
    -- Gegenprobe: alte Kosten 5000 -> ohne Ort vorn
    local savedCost = P.NO_PLACE_COST
    P.NO_PLACE_COST = 5000
    local okO, posOld = pcall(order)
    P.NO_PLACE_COST = savedCost
    if not okO then error(posOld, 0) end
    r.oldFirst = posOld == 1
    local good = r.turnin and r.accept and r.withPlace and r.complete and r.extra and r.last and r.oldFirst
    return good and true or false, ("Abgabe ohne Ort -> Hinweis %s · Annahme ohne Ort -> Hinweis %s · mit Ort -> Entfernung + Zone %s · Erledigen unverändert %s · 79007 Abgabe Westfall 37.5/50.7 %s · ohne Ort hinter 6/8 km %s (Platz %s von %s) · Gegenprobe alte Kosten 5000 -> vorn %s")
        :format(S(r.turnin), S(r.accept), S(r.withPlace), S(r.complete), S(r.extra), S(r.last), tostring(pos), tostring(n), S(r.oldFirst)),
        "true ×7"
end

-- 3.13.7 LP-M2: eine Entfernung für denselben Weg – Kopfzeile und Reisezeile zeigen dieselbe Zahl, die Zeit steht nur einmal.
-- 3 Entfernungen: Yards (36), km-Grenze (999,6 -> 0.9 km), Flug (mehrere Abschnitte: Reiseplan unverändert, Zeiten je Abschnitt).
IMPL.T373 = function()
    local UI, P, Geo, E, Nav = LP.UI, LP.Planner, LP.Geo, LP.Engine, LP.Nav
    if not (UI and UI.NavLine and P.PlanText) then return false, "LP-M2 fehlt", "UI.NavLine" end
    local pi, pn, pw, pmap = Geo:Player()
    if not pi or not pmap then return true, "keine Position" end
    local r = {}
    local savedCur, savedRem = E.Current, Nav.RemainingDistance
    local function count(s, sub)
        local c, i = 0, 1
        while true do local a, b = tostring(s):find(sub, i, true) if not a then break end c = c + 1 i = b + 1 end
        return c
    end
    local ok, err = pcall(function()
        for _, case in ipairs({ { 36, 35, 5, "yd" }, { 999.6, 1001.4, 143, "km" } }) do
            local d, planDist, secs = case[1], case[2], case[3]
            local s = { t = "TURNIN", q = "LPTest", id = 990020, key = "TURNIN:990020", map = pmap, x = 50, y = 50 }
            s.navPlan = { legs = { { k = "walk", dist = planDist, secs = secs } }, total = secs }
            s.navText = P.PlanText(s.navPlan)
            E.Current = function() return s end
            Nav.RemainingDistance = function() return d end
            local txt = UI:StepText(s, true)
            local f = LP:FormatDist(d)
            local times = 0
            for _ in tostring(txt):gmatch("%d+:%d%d") do times = times + 1 end
            r[case[4]] = count(txt, f) == 2 and count(txt, LP:FormatDist(planDist)) == (f == LP:FormatDist(planDist) and 2 or 0) and times == 1
            r[case[4] .. "Txt"] = f .. " ×" .. count(txt, f) .. ", Zeiten " .. times
        end
        -- Flug: mehrere Abschnitte -> Reiseplan wie berechnet (Zeit je Abschnitt + gesamt), NavLine = navText
        local s = { t = "TURNIN", q = "LPTest", id = 990021, key = "TURNIN:990021", map = pmap, x = 50, y = 50 }
        s.navPlan = { legs = { { k = "walk", dist = 300, secs = 43 }, { k = "fly", from = "A", to = "B", secs = 130 }, { k = "walk", dist = 200, secs = 29 } }, total = 202 }
        s.navText = P.PlanText(s.navPlan)
        r.fly = UI.NavLine(s, true) == s.navText and count(s.navText, "(0:43)") == 1 and count(s.navText, "~3:22") == 1
    end)
    E.Current, Nav.RemainingDistance = savedCur, savedRem
    if not ok then error(err, 0) end
    local good = r.yd and r.km and r.fly
    return good and true or false, ("Yards: gleiche Zahl in Kopf- und Reisezeile, Zeit einmal %s (%s) · km-Grenze %s (%s) · Flug: Reiseplan unverändert %s")
        :format(S(r.yd), tostring(r.ydTxt), S(r.km), tostring(r.kmTxt), S(r.fly)), "true ×3"
end

-- 3.13.7 LP-M3: Fenstertitel = Levelgebiet. Spieler darin (auch Hauptstadt der Zone) -> Name; ausserhalb -> "Ziel: <Name>";
-- ohne Fokus (keine Quests) -> Ort des Spielers; Fehlerzustände unverändert; Tooltip erklärt die Wahl.
IMPL.T374 = function()
    local UI, P, Geo = LP.UI, LP.Planner, LP.Geo
    if not (UI and UI.TitleText and UI.TitleTip) then return false, "LP-M3 fehlt", "UI.TitleText" end
    local L = LP.L
    local r = {}
    local barrens, mulgore = Geo:MapName(1413), Geo:MapName(1412)
    r.inside = UI.TitleText("ok", 1413, 1413) == barrens
    r.city = UI.TitleText("ok", 1412, 1456) == mulgore                   -- Donnerfels liegt in Mulgore
    r.outside = UI.TitleText("ok", 1413, 1456) == L("Ziel: %s", barrens)  -- Befund: Donnerfels, Titel "Das Brachland"
    r.noquests = UI.TitleText("noquests", nil, 1412) == mulgore
    r.errors = UI.TitleText("error", 1413, 1456) == L["|cffff5555Fehler bei der Planung|r"]
        and UI.TitleText("nodata", 1413, 1456) == L["|cffff8c33Keine Questdaten|r"]
        and UI.TitleText("noposition", 1413, 1456) == L["|cffff8c33Position unbekannt|r"]
    local savedF, savedZ = P.focus, LP.char.focusZone
    P.focus, LP.char.focusZone = 1413, false
    local tipAuto = UI.TitleTip()
    LP.char.focusZone = 1413
    local tipMan = UI.TitleTip()
    P.focus = nil
    local tipNone = UI.TitleTip()
    P.focus, LP.char.focusZone = savedF, savedZ
    r.tip = type(tipAuto) == "string" and type(tipMan) == "string" and tipAuto ~= tipMan and tipNone == nil
    local good = r.inside and r.city and r.outside and r.noquests and r.errors and r.tip
    return good and true or false, ("im Gebiet -> Name %s · Hauptstadt im Gebiet -> Name %s · ausserhalb -> \"Ziel: …\" %s · ohne Fokus -> Ort %s · Fehlerzustände unverändert %s · Tooltip (automatisch/gewählt/ohne) %s")
        :format(S(r.inside), S(r.city), S(r.outside), S(r.noquests), S(r.errors), S(r.tip)), "true ×6"
end

-- 3.13.7 Hinweis 20.11. "Test ändert nie Livedaten" (4. Gegenprobe): der Vergleich der Sandbox erkennt ein geändertes Feld. Nur an Kopien
-- (TR.CopyP/TR.SameP), nie an den echten Tabellen: Kopie gleich -> gleich; Kopie mit einem geänderten/zusätzlichen Feld -> abweichend.
IMPL.T375 = function()
    if not (TR.CopyP and TR.SameP) then return false, "Sandbox-Vergleich fehlt", "TR.CopyP/TR.SameP" end
    local same = TR.SameP(TR.CopyP(LevelPilotCharDB), LevelPilotCharDB)
    local c = TR.CopyP(LevelPilotCharDB)
    c.lpTestGegenprobe = 1
    local extra = TR.SameP(c, LevelPilotCharDB)
    local c2 = TR.CopyP(LevelPilotCharDB)
    local changed = nil
    for k, v in pairs(c2) do if type(v) == "number" then c2[k] = v + 1 changed = k break elseif type(v) == "boolean" then c2[k] = not v changed = k break end end
    local diff2 = changed and TR.SameP(c2, LevelPilotCharDB) or false
    local ok = same == true and extra == false and diff2 == false and LevelPilotCharDB.lpTestGegenprobe == nil
    return ok, ("Kopie gleich %s · zusätzliches Feld erkannt %s · geändertes Feld (%s) erkannt %s · echte Daten unberührt %s")
        :format(S(same), S(not extra), tostring(changed), S(not diff2), S(LevelPilotCharDB.lpTestGegenprobe == nil)), "true ×4"
end

-- 3.13.8 LP-B1: im Flug kein Laufziel mit Laufzeit/wachsender Entfernung; oben "Im Flug nach <Ziel>"; Pfeil aus; nach der Landung normal.
IMPL.T376 = function()
    local UI, N, E, Se = LP.UI, LP.Nav, LP.Engine, LP.Session
    if not (N and N.InFlight and UI and UI.StepText) then return false, "LP-B1 fehlt", "Nav.InFlight" end
    local pi, pn, pw, pmap = LP.Geo:Player()
    if not pmap then return true, "keine Position" end
    local onTaxi = true
    local fake = { UnitOnTaxi = function() return onTaxi end }
    local s = { t = "COMPLETE", q = "LPTest Blaulaubknollen", id = 990030, key = "COMPLETE:990030", map = pmap, x = 50, y = 50,
                navPlan = { legs = { { k = "walk", dist = 1100, secs = 157 } }, total = 157 } }
    s.navText = LP.Planner.PlanText(s.navPlan)
    local saved = { cur = E.Current, rem = N.RemainingDistance, eta = Se.QuestETA, dest = N.flightDest }
    local r = {}
    local ok, err = pcall(function()
        E.Current = function() return s end
        N.RemainingDistance = function() return 1100 end
        Se.QuestETA = function() return 600, true end
        WithEnv({ N.InFlight }, fake, function()
            N.flightDest = "Crossroads"
            local fly, dest = N.InFlight()
            local txt = UI:StepText(s, true)
            r.fly = fly == true and dest == "Crossroads"
            r.line = txt:find(LP.L("Im Flug nach %s", "Crossroads"), 1, true) ~= nil
            r.noDist = txt:find(LP:FormatDist(1100), 1, true) == nil
            r.noEta = Se:EtaText(s) == nil and txt:find(LP.L("ca. %s", LP.Comfort.Dur(600)), 1, true) == nil
            N.flightDest = nil
            r.unknown = UI:StepText(s, true):find(LP.L["Im Flug"], 1, true) ~= nil
            -- Landung: normal, Flugziel vergessen
            onTaxi = false
            N.flightDest = "Crossroads"
            local fly2 = N.InFlight()
            local txt2 = UI:StepText(s, true)
            r.landed = fly2 == false and N.flightDest == nil and txt2:find(LP:FormatDist(1100), 1, true) ~= nil
                and txt2:find(LP.L["Im Flug"], 1, true) == nil
        end)
    end)
    E.Current, N.RemainingDistance, Se.QuestETA, N.flightDest = saved.cur, saved.rem, saved.eta, saved.dest
    if not ok then error(err, 0) end
    local good = r.fly and r.line and r.noDist and r.noEta and r.unknown and r.landed
    return good and true or false, ("im Flug erkannt %s · Zeile \"Im Flug nach …\" %s · keine Entfernung %s · keine Laufzeit %s · Ziel unbekannt -> \"Im Flug\" %s · Landung -> normal %s")
        :format(S(r.fly), S(r.line), S(r.noDist), S(r.noEta), S(r.unknown), S(r.landed)), "true ×6"
end

-- 3.13.8 LP-B2 (Schätzen verboten): Zeit ohne eigene Messung -> "noch nicht gemessen" statt "ca."; mit Messung "ca."; Zone mit
-- Annahmen/Abgaben (30 s Vorgabe) -> "Zone: noch nicht gemessen"; Trainerkosten ohne Messung -> kein Hinweis mit Zahl.
IMPL.T377 = function()
    local Se, P, E, H = LP.Session, LP.Planner, LP.Engine, LP.Hints
    if not (Se and Se.ZoneETA and H and H.TrainerHints) then return false, "LP-B2 fehlt", "vorhanden" end
    local s = { t = "COMPLETE", q = "LPTest", id = 990040, key = "COMPLETE:990040", map = 1413, x = 50, y = 50 }
    local saved = { eta = Se.QuestETA, steps = E.Steps, focus = P.focus, cur = E.Current, cost = H.TrainerCost, money = LP.db.hintTrainer,
                    show = LP.db.showEta }
    local r = {}
    local ok, err = pcall(function()
        LP.db.showEta = true
        E.Current = function() return nil end
        Se.QuestETA = function() return 600, false end
        r.unmeasured = Se:EtaText(s) == LP.L["Zeit: noch nicht gemessen"]
        Se.QuestETA = function() return 600, true end
        r.measured = Se:EtaText(s) == LP.L("ca. %s", LP.Comfort.Dur(600))
        P.focus = 1413
        E.Steps = function() return { s, { t = "ACCEPT", id = 990041, map = 1413 } } end
        local z, m = Se:ZoneETA()
        r.zone = z == 630 and m == false and tostring(Se:ExtraText() or ""):find(LP.L["Zone: noch nicht gemessen"], 1, true) ~= nil
        E.Steps = function() return { s, { t = "COMPLETE", id = 990042, map = 1413 } } end
        local z2, m2 = Se:ZoneETA()
        r.zoneM = z2 == 1200 and m2 == true
        -- Trainerkosten geschätzt -> kein Hinweis; gemessen -> Hinweis mit Zahl
        LP.db.hintTrainer = true
        H.TrainerCost = function() return 999999999, true end
        local a = Collect(H.TrainerHints)
        local n1 = 0 for _, h in ipairs(a) do if h.key == "traincost" then n1 = n1 + 1 end end
        H.TrainerCost = function() return 999999999, false end
        local b = Collect(H.TrainerHints)
        local n2 = 0 for _, h in ipairs(b) do if h.key == "traincost" then n2 = n2 + 1 end end
        r.trainer = n1 == 0 and n2 == 1
    end)
    Se.QuestETA, E.Steps, P.focus, E.Current, H.TrainerCost, LP.db.hintTrainer, LP.db.showEta =
        saved.eta, saved.steps, saved.focus, saved.cur, saved.cost, saved.money, saved.show
    if not ok then error(err, 0) end
    local good = r.unmeasured and r.measured and r.zone and r.zoneM and r.trainer
    return good and true or false, ("ohne Messung -> \"noch nicht gemessen\" %s · gemessen -> \"ca.\" %s · Zone mit Annahme (30 s Vorgabe) -> nicht gemessen %s · Zone nur gemessene Ziele -> gemessen %s · Trainerkosten geschätzt -> kein Hinweis, gemessen -> Hinweis %s")
        :format(S(r.unmeasured), S(r.measured), S(r.zone), S(r.zoneM), S(r.trainer)), "true ×5"
end

-- 3.13.8 LP-B3 (a): Gebiet in Klammern fehlt, wenn der Questname es enthält. (b) Gebietsname = Name des Spiels (Geo:MapName), nie
-- fest englisch: im deutschen WoW-Forever-Client heisst das Gebiet laut Uploads "Ashenvale" (GetRealZoneText, siehe Bericht).
IMPL.T378 = function()
    local P, Geo = LP.Planner, LP.Geo
    if not P.LaterPart then return false, "LaterPart fehlt", "vorhanden" end
    local r = {}
    r.same = P.LaterPart("Die Jagd in Ashenvale", "Ashenvale") == "Die Jagd in Ashenvale"
    r.long = P.LaterPart("Reise in das Vorgebirge von Hillsbrad", "Vorgebirge von Hillsbrad") == "Reise in das Vorgebirge von Hillsbrad"
    r.case = P.LaterPart("die jagd in ASHENVALE", "Ashenvale") == "die jagd in ASHENVALE"
    r.other = P.LaterPart("Die heilige Flamme", "Tausend Nadeln") == "Die heilige Flamme (Tausend Nadeln)"
    r.none = P.LaterPart("Quest", nil) == "Quest"
    -- Gebietsname aus dem Spiel: Geo:MapName(1440) wie C_Map.GetMapInfo (ohne Sprachpaket-Ersatz gleich)
    local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(1440)
    local game = info and info.name
    local foreign = LP.Names and LP.Names.Foreign and LP.Names:Foreign()
    r.zoneName = foreign and true or (game == nil or Geo:MapName(1440) == game)
    local good = r.same and r.long and r.case and r.other and r.none and r.zoneName
    return good and true or false, ("Name enthält Gebiet -> ohne Klammer %s · Hillsbrad %s · Gross/klein %s · anderes Gebiet -> mit Klammer %s · ohne Gebiet %s · Gebietsname = Spiel (%s) %s")
        :format(S(r.same), S(r.long), S(r.case), S(r.other), S(r.none), tostring(game), S(r.zoneName)), "true ×6"
end

-- 3.13.8 LP-B4: Chatzeile "Das Fehler-Protokoll hat n neue Auffälligkeit(en) …" nur im Entwicklermodus.
IMPL.T379 = function()
    local Pr = LP.Protocol
    if not (Pr and Pr.LoginNotice) then return false, "LoginNotice fehlt", "vorhanden" end
    local saved = { dev = LP.IsDev, count = Pr.Count, proto = LP.db.protocol }
    local r = {}
    local ok, err = pcall(function()
        Pr.Count = function() return 5 end
        LP.db.protocol = true
        LP.IsDev = function() return false end
        r.player = Pr.LoginNotice() == nil
        LP.IsDev = function() return true end
        local m = Pr.LoginNotice()
        r.dev = type(m) == "string" and m:find("5", 1, true) ~= nil
        Pr.Count = function() return 0 end
        r.none = Pr.LoginNotice() == nil
        Pr.Count = function() return 5 end
        LP.db.protocol = false
        r.off = Pr.LoginNotice() == nil
    end)
    LP.IsDev, Pr.Count, LP.db.protocol = saved.dev, saved.count, saved.proto
    if not ok then error(err, 0) end
    local good = r.player and r.dev and r.none and r.off
    return good and true or false, ("Spieler ohne Entwicklermodus -> keine Chatzeile %s · Entwicklermodus -> Zeile %s · 0 neue -> keine %s · Protokoll aus -> keine %s")
        :format(S(r.player), S(r.dev), S(r.none), S(r.off)), "true ×4"
end

-- 3.13.8 Lesbarkeit L1/L8 (Hinweis 20.11.): L1 Kontrast jeder Farbe in den Zeilen des Fensters >= 4,5:1 (WCAG 2 AA) auf der hellsten
-- Zeilenfarbe (rowCur), Entscheidungszahlen (Entfernung, Zeit) >= 7:1 (AAA) und nicht grau; Gegenprobe dunkelgrau 555555 -> Befund.
-- L8 Schrift im Fenster nicht kleiner als GameFontNormalSmall (Classic: 10). L2–L7 siehe Bericht (L3 = T373, L7 = T377).
local function Lin(c) return c <= 0.03928 and c / 12.92 or ((c + 0.055) / 1.055) ^ 2.4 end
local function Lum(r, g, b) return 0.2126 * Lin(r) + 0.7152 * Lin(g) + 0.0722 * Lin(b) end
function TR.Contrast(hex, bg)
    local r, g, b = tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255
    local a, c = Lum(r, g, b), Lum(bg[1], bg[2], bg[3])
    return (math.max(a, c) + 0.05) / (math.min(a, c) + 0.05), r, g, b
end
local function Gray(r, g, b) return (math.max(r, g, b) - math.min(r, g, b)) < 0.1 and math.max(r, g, b) < 0.85 end
IMPL.T380 = function()
    local UI, E, N = LP.UI, LP.Engine, LP.Nav
    if not (UI and UI.StepText and UI.DECIDE) then return false, "Lesbarkeit fehlt", "UI.DECIDE" end
    local bg = LP.colors.rowCur
    local pi, pn, pw, pmap = LP.Geo:Player()
    local saved = { cur = E.Current, rem = N.RemainingDistance, eta = LP.Session.QuestETA, lvl = LP.PlayerLevel }
    local texts, bad, worst = {}, {}, nil
    local ok, err = pcall(function()
        LP.PlayerLevel = function() return 20 end
        N.RemainingDistance = function() return 1234 end
        LP.Session.QuestETA = function() return 900, true end
        for _, st in ipairs({ { t = "COMPLETE", level = 26 }, { t = "TURNIN", level = 23 }, { t = "ACCEPT", level = 20 }, { t = "ACCEPT", level = 17 },
                              { t = "COMPLETE", level = 12 }, { t = "TURNIN", level = 5 } }) do
            local s = { t = st.t, q = "LPTest", id = 990050, key = st.t .. ":990050", level = st.level, map = pmap, x = 50, y = 50 }
            E.Current = function() return s end
            texts[#texts + 1] = UI:StepText(s, true)
            texts[#texts + 1] = UI:StepText(s, false)
        end
        texts[#texts + 1] = UI.StatusText and UI.StatusText() or ""
    end)
    E.Current, N.RemainingDistance, LP.Session.QuestETA, LP.PlayerLevel = saved.cur, saved.rem, saved.eta, saved.lvl
    if not ok then error(err, 0) end
    local n = 0
    for _, t in ipairs(texts) do
        for hex in tostring(t):gmatch("|c%x%x(%x%x%x%x%x%x)") do
            n = n + 1
            local c = TR.Contrast(hex, bg)
            if not worst or c < worst[2] then worst = { hex, c } end
            if c < 4.5 then bad[#bad + 1] = hex .. (" %.1f"):format(c) end
        end
    end
    -- Entscheidungszahlen: Entfernung und Zeit
    local dHex = UI.DECIDE:match("|c%x%x(%x%x%x%x%x%x)")
    local dc, dr, dg, db = TR.Contrast(dHex, bg)
    local decideOK = dc >= 7 and not Gray(dr, dg, db)
    local distColored = texts[1]:find(UI.DECIDE .. LP:FormatDist(1234), 1, true) ~= nil
    -- Gegenprobe: dunkelgrau muss auffallen
    local gc, gr, gg, gb = TR.Contrast("555555", bg)
    local caught = gc < 4.5 and Gray(gr, gg, gb)
    -- L8: Schriftgrössen aller Schriften im Fenster
    local minSize = 10
    if GameFontNormalSmall and GameFontNormalSmall.GetFont then
        local okF, _, sz = pcall(GameFontNormalSmall.GetFont, GameFontNormalSmall)
        if okF and tonumber(sz) then minSize = math.floor(tonumber(sz) + 0.5) end
    end
    local small, fonts = {}, 0
    local frame = UI.Frame and UI.Frame() or _G.LevelPilotFrame
    local function Walk(f, depth)
        if not f or depth > 10 then return end
        if f.GetRegions then
            for _, rg in ipairs({ f:GetRegions() }) do
                if rg.GetFont then
                    local okG, _, size = pcall(rg.GetFont, rg)
                    if okG and tonumber(size) then
                        fonts = fonts + 1
                        if math.floor(tonumber(size) + 0.5) < minSize then
                            local okT, txt = pcall(rg.GetText, rg)
                            small[#small + 1] = tostring(size) .. " „" .. tostring(okT and txt or "?"):sub(1, 20) .. "“"
                        end
                    end
                end
            end
        end
        if f.GetChildren then for _, ch in ipairs({ f:GetChildren() }) do Walk(ch, depth + 1) end end
    end
    Walk(frame, 0)
    local good = #bad == 0 and decideOK and distColored and caught and #small == 0 and n > 0
    return good and true or false, ("L1: %d Farben geprüft, unter 4,5:1: %s (schwächste %s %.1f:1) · Entfernung/Zeit %.1f:1 nicht grau %s, Entfernung in dieser Farbe %s · Gegenprobe 555555 erkannt %s · L8: %d Schriften im Fenster, kleiner als %d: %s")
        :format(n, #bad > 0 and table.concat(bad, ", ") or "keine", worst and worst[1] or "-", worst and worst[2] or 0, dc, S(decideOK), S(distColored),
            S(caught), fonts, minSize, #small > 0 and table.concat(small, ", ") or "keine"), "keine · >= 7, true, true · true · keine"
end

-- 3.13.8 LP-T1: virtuelle Reise wiederholbar – dieselbe kurze Reise zweimal (gleicher Code, gleiche Ausgangslage) -> gleiche Zeit,
-- gleiche Schritte, gleiche EP und gleicher Weg. Gegenprobe ist der Nachbau 3.13.7 (Abgabe nach Uhr): 3 Läufe verschieden.
IMPL.T381 = function()
    local a, b = J("short"), J("short2")
    if not (a and b) then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local sa, sb = a.s or {}, b.s or {}
    local same = sa.clock == sb.clock and sa.steps == sb.steps and sa.xp == sb.xp and sa.level == sb.level and sa.dist == sb.dist
    return same, ("Lauf 1: %.0f s, %s Schritte, Stufe %s, %s EP, %.0f yd · Lauf 2: %.0f s, %s Schritte, Stufe %s, %s EP, %.0f yd")
        :format(sa.clock or -1, tostring(sa.steps), tostring(sa.level), tostring(sa.xp), sa.dist or -1,
            sb.clock or -1, tostring(sb.steps), tostring(sb.level), tostring(sb.xp), sb.dist or -1), "gleich"
end

-- 3.13.8 LP-O1: die drei fehlenden Orte stehen in der Ortsliste (je 5 ortsfeste NPCs im Datenpaket, PLACE_MIN 5)
IMPL.T382 = function()
    local D, Geo = LP.Danger, LP.Geo
    local Npc = _G.LevelPilotData and _G.LevelPilotData.N
    if not (D and D.BuildPlaces) or type(Npc) ~= "table" then return true, "kein Datenpaket" end
    local A, H = D.BuildPlaces(Npc, "A"), D.BuildPlaces(Npc, "H")
    local function has(set, map, x, y)
        local i, n, w = Geo:ToWorld(map, x, y)
        if not i then return nil end
        for _, p in ipairs(set[i] or {}) do if (n - p.n) ^ 2 + (w - p.w) ^ 2 <= p.r * p.r then return true end end
        return false
    end
    local r = {
        peak = has(A, 1442, 36.0, 7.0),        -- Steinkrallengipfel (Gastwirtin 35.8/5.7, Teloren 36.4/7.2)
        thal = has(A, 1444, 89.4, 46.1),       -- Thalanaar (Rendow 89.4/45.9)
        valo = has(H, 1447, 22.2, 51.3),       -- Valormok (Gruul Darkblade 22.2/51.1)
    }
    local good = r.peak and r.thal and r.valo
    return good and true or false, ("Steinkrallengipfel %s · Thalanaar %s · Valormok %s"):format(S(r.peak), S(r.thal), S(r.valo)), "true ×3"
end

-- 3.13.5 (Auftrag 19.11. 12:42 Punkt 6): Abtastung direkt (R:TrackIdle, R.TrailOK) mit erfundenen Orten und Zeiten; eigene Ablage
-- (LP.char/LP.db ersetzt), Fenster-Merker und Stillstand-Zustand gesichert und zurück. Keine echten Wege gelernt.
IMPL.T368 = function()
    local R = LP.Recorder
    if not (R and R.TrackIdle and R.TrailOK and R.IsIdle and R.Stat) then return false, "Wegqualität fehlt", "Recorder" end
    local saved = { char = LP.char, db = LP.db, panels = R.panels, idle = {}, pending = R.pending, running = TR.running }
    for k, v in pairs(R.idle) do saved.idle[k] = v end
    local r = {}
    local inst, n0, w0 = LP.Geo:Player()
    if not inst then return NA, "kein Ort des Spielers", "-" end
    -- 3.13.6 (Ingametest 3.13.5: "Stehen ... false" – der Spieler war AFK): ohne den echten AFK-Zustand prüfen (Abschnitt 3 setzt
    -- ihn selbst)
    local ok, err = pcall(WithEnv, { R.IsIdle }, { UnitIsAFK = function() return false end }, function()
        LP.char, LP.db = { levelIdle = 0 }, { trailStats = {} }
        -- wie beim normalen Spielen (ausserhalb der Testroutine wird direkt geschrieben); eigene Vormerkung
        R.pending = { stat = {}, idle = 0 }
        TR.running = false
        R.panels = {}
        for k in pairs(R.idle) do R.idle[k] = nil end
        -- 1) 8 Std. im Auktionshaus (Fenster offen, kein Ortswechsel): Stillstand = ganze Zeit, kein Abschnitt
        R.panels.ah = true
        local dtMax = R.IDLE_DT_MAX
        R.IDLE_DT_MAX = 3600                                 -- Abtastung jede Stunde statt alle 0,5 s (Rechenzeit der Prüfung)
        local t, steps = 1000, 9
        local idleN = 0
        for _ = 1, steps do if R:TrackIdle(t, inst, n0, w0) then idleN = idleN + 1 end t = t + 3600 end
        R.IDLE_DT_MAX = dtMax
        R.panels.ah = nil
        r.ahIdle = idleN == steps and math.abs((LP.char.levelIdle or 0) - 8 * 3600) <= 2
        -- 2) stehen ohne Fenster: erst nach 30 s Stillstand, dann zählen die 30 s mit
        for k in pairs(R.idle) do R.idle[k] = nil end
        LP.char.levelIdle = 0
        local early
        for i = 1, 120 do                                   -- 60 s stehen
            local isI = R:TrackIdle(t, inst, n0, w0)
            if i == 50 then early = isI end                  -- nach 25 s: noch nicht
            t = t + 0.5
        end
        r.still = early == false and math.abs((LP.char.levelIdle or 0) - 60) <= 1.5
        -- 3) AFK mitten im Lauf: 120 s laufen, davon 40 s AFK -> 40 s Stillstand
        LP.char.levelIdle = 0
        for k in pairs(R.idle) do R.idle[k] = nil end
        local afk = false
        local env = { UnitIsAFK = function() return afk end }
        local okW, eW = pcall(WithEnv, { R.IsIdle }, env, function()
            for i = 1, 240 do
                afk = i > 100 and i <= 180
                R:TrackIdle(t, inst, n0 + i * 3.5, w0)        -- 7 yd/s: läuft immer
                t = t + 0.5
            end
        end)
        if not okW then error(eW, 0) end
        r.afk = math.abs((LP.char.levelIdle or 0) - 40) <= 1
        -- 4) Abschnitte: gerade -> lernen; Kreis -> verwerfen; Hin-und-her -> verwerfen; abseits vom Ziel -> verwerfen
        local function line(len, f)
            local pts = {}
            for i = 0, 20 do pts[#pts + 1] = f(i / 20 * len) end
            return pts
        end
        local straight = line(300, function(d) return { inst, n0 + d, w0 } end)
        local circle = line(2 * math.pi * 60, function(d) local a = d / 60 return { inst, n0 + 60 * math.cos(a), w0 + 60 * math.sin(a) } end)
        local back = {}
        for i = 0, 40 do local x = (i % 10 < 5) and (i % 10) * 30 or (10 - i % 10) * 30 back[#back + 1] = { inst, n0 + x, w0 } end
        r.straight = (R.TrailOK(straight, { inst, n0 + 600, w0 })) == true
        local okC, whyC = R.TrailOK(circle)
        r.circle = okC == false and whyC == "detour"
        local okB, whyB = R.TrailOK(back)
        r.back = okB == false and whyB == "detour"
        local okO, whyO = R.TrailOK(straight, { inst, n0 - 600, w0 })       -- weg vom Ziel
        r.offgoal = okO == false and whyO == "offgoal"
        r.noTarget = (R.TrailOK(straight)) == true                          -- ohne Ziel: nur Umweg-Prüfung
        -- 4b) während der Testroutine nur vormerken (echte Daten bleiben unverändert), danach übernehmen
        for k in pairs(R.idle) do R.idle[k] = nil end
        LP.char.levelIdle = 0
        R.panels.ah = true
        TR.running = true
        local t2 = t
        for _ = 1, 10 do R:TrackIdle(t2, inst, n0, w0) t2 = t2 + 0.5 end
        local during = LP.char.levelIdle
        TR.running = false
        R:TrackIdle(t2, inst, n0, w0)                                -- erste Abtastung danach übernimmt
        R.panels.ah = nil
        r.pend = during == 0 and math.abs(LP.char.levelIdle - 5) <= 0.6
        -- 5) Zahlen je Version
        R.Stat("kept") R.Stat("detour")
        local line1 = R.StatLine() or ""
        r.stat = line1:find(LP.version, 1, true) ~= nil and line1:find("1", 1, true) ~= nil
        r.statLine = line1
    end)
    LP.char, LP.db, R.panels = saved.char, saved.db, saved.panels
    R.pending, TR.running = saved.pending, saved.running
    R.IDLE_DT_MAX = 2
    for k in pairs(R.idle) do R.idle[k] = nil end
    for k, v in pairs(saved.idle) do R.idle[k] = v end
    if not ok then error(err, 0) end
    local good = r.ahIdle and r.still and r.afk and r.straight and r.circle and r.back and r.offgoal and r.noTarget and r.stat and r.pend
    return good and true or false, ("während Testroutine nur vorgemerkt, danach übernommen %s · 8 Std. AH: alles Stillstand, 0 Laufzeit %s · Stehen: erst nach 30 s, dann mit %s · AFK 40 s im Lauf abgezogen %s · gerade übernommen %s · Kreis verworfen %s · Hin-und-her verworfen %s · abseits vom Ziel verworfen %s · ohne Ziel gerade übernommen %s · Zahlen je Version %s")
        :format(S(r.pend), S(r.ahIdle), S(r.still), S(r.afk), S(r.straight), S(r.circle), S(r.back), S(r.offgoal), S(r.noTarget), S(r.stat)),
        "true ×10"
end

-- 3.13.4 (Ingametest 3.13.3 T150: Navigation 5,99 ms je Neuplanung): erst den Weg zum aktuellen Ziel rechnen lassen (echte
-- Wegsuche, darf abgeben), dann nur Ersatz in eigenen Feldern (Schritte, Stufe, Merker der Navigation) ohne Abgabe.
IMPL.T367 = function()
    local N, P = LP.Nav, LP.Planner
    if not (N and N.PlanNeedsForce) then return false, "PlanNeedsForce fehlt", "vorhanden" end
    local step = P.steps and P.steps[1]
    if not (step and step.inst) then return NA, "kein Ziel mit Ort im Plan", "-" end
    local ok0 = PCallY(Coop, N.Recalc, N, true)
    local guard = 0
    while LP.Jobs.Running("navpath") and guard < 2000 do LP.Jobs.Step() guard = guard + 1 TR.Safe("T367") end
    if not (ok0 and N.hasPath) then return NA, "kein Weg zum aktuellen Ziel", "-" end
    local r = {}
    local saved = { steps = P.steps, lvl = LP.PlayerLevel, unk = N.pathUnknown, blk = N.pathBlocked }
    local ok, err = pcall(function()
        local f0, why0 = N.PlanNeedsForce()
        r.same, r.why = f0 == false, why0
        -- gesperrter/unbekannter Weg zum selben Ziel erzwingt nichts (der Takt der Navigation prüft Bewegung und neue Wegdaten)
        N.pathUnknown = true r.unknown = N.PlanNeedsForce() == false N.pathUnknown = saved.unk
        N.pathBlocked = true r.blocked = N.PlanNeedsForce() == false N.pathBlocked = saved.blk
        local lv = (LP:PlayerLevel() or 1) + 1
        LP.PlayerLevel = function() return lv end r.level = N.PlanNeedsForce() == true LP.PlayerLevel = saved.lvl
        local other = {}
        for k, v in pairs(step) do other[k] = v end
        other.key = tostring(step.key) .. ":LPT367"
        P.steps = { other } r.changed = N.PlanNeedsForce() == true P.steps = saved.steps
        r.back = N.PlanNeedsForce() == false
    end)
    P.steps, LP.PlayerLevel, N.pathUnknown, N.pathBlocked = saved.steps, saved.lvl, saved.unk, saved.blk
    if not ok then error(err, 0) end
    local good = r.same and r.unknown and r.blocked and r.level and r.changed and r.back
    return good and true or false, ("gleiches Ziel: nicht erzwingen %s · Weg unbekannt: nicht erzwingen %s · gesperrt: nicht erzwingen %s · neue Stufe: neu %s · anderes Ziel: neu %s · zurück: nicht erzwingen %s")
        :format(S(r.same) .. (r.why and (" (" .. r.why .. ")") or ""), S(r.unknown), S(r.blocked), S(r.level), S(r.changed), S(r.back)), "true ×6"
end

-- 3.13.2 (Auftrag 19.11. 11:00 Punkt 2e): eigene Lückenliste (eine Testlücke in Durotar), eigene Ablage (LP.db ersetzt), Positionen
-- direkt an LU:Sample (kein Spieler bewegt). Ersatz nur in eigenen Feldern, danach zurück.
IMPL.T366 = function()
    local LU = LP.Luecken
    if not (LU and LU.Sample and LU.Finish and LU.Since) then return false, "Luecken fehlt", "LP.Luecken" end
    local saved = { list = LU.LIST, db = LP.db, maxStore = LU.MAX_STORE, stats = LU.stats, active = LU.active }
    local r = {}
    local ok, err = pcall(function()
        -- 3.13.5: Testlücke 600 Yards lang (Weltkoordinaten -> Zonenkoordinaten), unabhängig von der Grösse der Karte im Client
        local pi0, pn0, pw0, pmap0 = LP.Geo:Player()
        if not (pi0 and pmap0) then error("kein Ort des Spielers", 0) end
        local zm = LP.Geo:ContinentOf(pmap0) ~= pmap0 and pmap0 or 1411
        local ix, iy = LP.Geo:ToMap(zm, pi0, pn0, pw0)
        local jx, jy = LP.Geo:ToMap(zm, pi0, pn0 + 600, pw0)
        if not (ix and jx) then error("Zonenkoordinaten fehlen", 0) end
        LU.LIST = { { zm, ix, iy, jx, jy, 9, 600 } }
        LU.stats = { started = 0, done = 0, aborted = 0, ms = 0, calls = 0 }
        LU:Reset()
        LP.db = { wegeAuto = true }
        local i1, n1, w1 = LP.Geo:ToWorld(zm, ix, iy)
        local _, n2, w2 = LP.Geo:ToWorld(zm, jx, jy)
        if not i1 then error("Karte fehlt", 0) end
        local len = LP.Geo:Dist(n1, w1, n2, w2)
        local function walk(from, to, steps, t0, okFn, jumpAt)
            local t = t0
            for k = 0, steps do
                local f = k / steps
                local n, w = from[1] + (to[1] - from[1]) * f, from[2] + (to[2] - from[2]) * f
                if jumpAt and k == jumpAt then n = n + 500 end
                LU:Sample(okFn == nil or okFn(k), i1, n, w, t)
                t = t + 0.5
            end
            return t
        end
        local steps = math.max(4, math.ceil(len / 5))           -- 5 Yards je halbe Sekunde (zu Fuss)
        -- 1) Lücke durchlaufen -> gemessen, aus der Liste, Umweg-Faktor 1
        walk({ n1, w1 }, { n2, w2 }, steps, 1000)
        local mess = LP.db.lueckenMess or {}
        local m = mess[1]
        -- 3.13.5: ein Lauf ist nie die Wahrheit – nach dem ersten Lauf bleibt die Lücke offen
        r.done = #mess == 1 and m and m.m == zm and math.abs(m.f - 1) <= 0.02 and LU:OpenCount() == 1
        -- keine Namen: nur Schlüssel, Karte, Zahlen, Version
        local names = false
        for k, v in pairs(m or {}) do
            if not ({ k = true, m = true, w = true, s = true, l = true, f = true, p = true, t = true, v = true, n = true, best = true })[k] then names = true end
            if type(v) == "string" and k ~= "k" and k ~= "v" then names = true end
        end
        r.noNames = m ~= nil and not names
        -- 2) zweiter Lauf, LANGSAMER (halbes Tempo) -> gemessen, Lücke zu, bester Lauf bleibt der erste; dritter -> keine Messung mehr
        local best1 = LP.db.lueckenRuns and LP.db.lueckenRuns[LU.Key(LU.LIST[1])] and LP.db.lueckenRuns[LU.Key(LU.LIST[1])].best
        local s1 = best1 and best1.s
        walk({ n1, w1 }, { n2, w2 }, steps * 2, 2000)
        local runs = LP.db.lueckenRuns[LU.Key(LU.LIST[1])]
        r.worseKeeps = #(LP.db.lueckenMess or {}) == 2 and LU:OpenCount() == 0 and runs.best.s == s1 and runs.n == 2
        walk({ n1, w1 }, { n2, w2 }, steps, 2500)
        r.once = #(LP.db.lueckenMess or {}) == 2
        -- besserer Lauf ersetzt (frische Ablage: langsam, dann schnell)
        local dbKeep = LP.db
        LP.db = { wegeAuto = true }
        LU:Reset()
        walk({ n1, w1 }, { n2, w2 }, steps * 2, 2600)
        local runsB = LP.db.lueckenRuns and LP.db.lueckenRuns[LU.Key(LU.LIST[1])]
        local slow = runsB and runsB.best and runsB.best.s
        walk({ n1, w1 }, { n2, w2 }, steps, 3600)
        runsB = LP.db.lueckenRuns and LP.db.lueckenRuns[LU.Key(LU.LIST[1])]
        local fast = runsB and runsB.best and runsB.best.s
        r.betterReplaces = slow ~= nil and fast ~= nil and fast < slow
        r.bestInfo = ("%s -> %s s, Läufe %s, Messungen %d, letzter Abbruch %s"):format(tostring(slow), tostring(fast),
            tostring(runsB and runsB.n), #(LP.db.lueckenMess or {}), tostring(LU.lastAbort))
        LP.db = dbKeep
        -- 3) Gegenproben mit frischer Ablage: bekannte Strecke (abseits) -> nichts; Flug/Tod (ok = false) -> nichts; Sprung -> nichts;
        --    Umweg (hin und her bis über 4x) -> nichts
        LP.db = { wegeAuto = true }
        LU:Reset()
        walk({ n1 + 400, w1 + 400 }, { n2 + 400, w2 + 400 }, steps, 3000)
        r.known = #(LP.db.lueckenMess or {}) == 0 and LU.active == nil
        walk({ n1, w1 }, { n2, w2 }, steps, 4000, function(k) return k < steps / 2 end)
        r.flight = #(LP.db.lueckenMess or {}) == 0
        walk({ n1, w1 }, { n2, w2 }, steps, 5000, nil, math.floor(steps / 2))
        r.jump = #(LP.db.lueckenMess or {}) == 0
        local mid = { (n1 + n2) / 2, (w1 + w2) / 2 + 300 }                -- 300 yd quer zur Lücke
        local t = walk({ n1, w1 }, mid, steps * 3, 6000)
        for _ = 1, 3 do t = walk(mid, { mid[1], mid[2] - 200 }, steps * 2, t) t = walk({ mid[1], mid[2] - 200 }, mid, steps * 2, t) end
        walk(mid, { n2, w2 }, steps * 3, t)
        r.detour = #(LP.db.lueckenMess or {}) == 0
        -- 4) Obergrenze: höchstens MAX_STORE Messungen (älteste weg)
        LU.MAX_STORE = 2
        for k = 1, 3 do
            LP.db.lueckenDone = {}
            LU:Reset()
            walk({ n1, w1 }, { n2, w2 }, steps, 7000 + k * 1000)
        end
        local ms2 = LP.db.lueckenMess or {}
        r.cap = #ms2 == 2
        -- 5) Versand: Since liefert die neuen; aus (wegeAuto false) -> WegeExport legt nichts bereit
        r.since = #LU:Since(0) == 2 and #LU:Since(ms2[2].t) == 0
        LP.db.wegeAuto = false
        r.noSend = LP.Graph.WegeExport(LP.Graph) == false
        -- 6) eigene Rechenzeit je Abtastung
        r.avg = LU.stats.calls > 0 and LU.stats.ms / LU.stats.calls or 0
        r.max = LU.stats.max or 0
    end)
    LU.LIST, LP.db, LU.MAX_STORE, LU.stats = saved.list, saved.db, saved.maxStore, saved.stats
    LU:Reset()
    LU.active = nil
    if not ok then error(err, 0) end
    local good = r.done and r.noNames and r.once and r.known and r.flight and r.jump and r.detour and r.cap and r.since and r.noSend
        and r.avg < 1 and r.worseKeeps and r.betterReplaces
    return good and true or false, ("durchlaufen -> gemessen, bleibt offen %s · schlechterer 2. Lauf ersetzt nicht, Lücke zu %s · besserer ersetzt %s (%s) · keine Namen %s · dritter Lauf -> keine Messung %s · bekannte Strecke nichts %s · Flug/Tod nichts %s · Sprung nichts %s · Umweg nichts %s · Obergrenze %s · Versand neu %s · aus -> nichts %s · Rechenzeit je Abtastung Ø %.3f ms, höchstens %.3f ms")
        :format(S(r.done), S(r.worseKeeps), S(r.betterReplaces), tostring(r.bestInfo), S(r.noNames), S(r.once), S(r.known), S(r.flight), S(r.jump), S(r.detour), S(r.cap), S(r.since), S(r.noSend),
            r.avg or -1, r.max or -1), "true ×12 · Ø < 1 ms"
end

-- 3.13.2 (Entscheid 19.11. 11:00): eigene Ablage (LP.db ersetzt nur für die Prüfung), Chatzeilen gezählt statt gezeigt
IMPL.T365 = function()
    if not LP.WegeInfoOnce then return false, "WegeInfoOnce fehlt", "vorhanden" end
    local savedDb, savedPrint = LP.db, LP.Print
    local lines = 0
    local r = {}
    local ok, err = pcall(function()
        LP.Print = function() lines = lines + 1 end
        LP.db = { wegeAuto = true }                                  -- neu (nie ausgeschaltet; Standard an)
        r.new = LP:WegeInfoOnce() == true and lines == 1 and LP.db.wegeInfoShown == true
        r.second = LP:WegeInfoOnce() == false and lines == 1          -- zweiter Start: keine Zeile
        lines = 0
        LP.db = { wegeAuto = false }                                 -- bisher ausdrücklich aus
        r.off = LP:WegeInfoOnce() == false and lines == 0 and LP.db.wegeAuto == false
        r.noSend = LP.Graph.WegeExport(LP.Graph) == false            -- aus -> nichts bereitgelegt
    end)
    LP.db, LP.Print = savedDb, savedPrint
    if not ok then error(err, 0) end
    r.default = LP.DEFAULTS and LP.DEFAULTS.wegeAuto == true
    local good = r.new and r.second and r.off and r.noSend and r.default
    return good and true or false, ("neu: Zeile + gemerkt %s · zweiter Start ohne Zeile %s · bisher aus bleibt aus, ohne Zeile %s · aus: nichts gesendet %s · Standard an %s")
        :format(S(r.new), S(r.second), S(r.off), S(r.noSend), S(r.default)), "true ×5"
end

-- 3.13.1 (Ingametest 3.13.0 T150): Zwischenspeicher von Danger:Route. Exaktheit der Blöcke prüft T291 (2000 Strecken gegen die
-- Rechnung je Messpunkt).
IMPL.T364 = function()
    local D = LP.Danger
    if not (D and D.Route and D.routeStats and D.RouteCacheReset) then return false, "Zwischenspeicher fehlt", "Danger.routeStats" end
    local inst, pn, pw = LP.Geo:Player()
    if not (inst and pn) then return NA, "kein Ort des Spielers", "-" end
    local st = D.routeStats
    local r = {}
    local function miss(f) local m0 = st.miss local v = f() return st.miss - m0, v end
    local n2, w2 = pn + 3000, pw + 2000
    r.m1, r.a = miss(function() return D:Route(inst, pn, pw, n2, w2, 150, 40) end)
    r.m2, r.b = miss(function() return D:Route(inst, pn, pw, n2, w2, 150, 40) end)          -- gleich -> gespeichert
    r.m3 = miss(function() return D:Route(inst, pn + 0.001, pw, n2, w2, 150, 40) end)       -- 1/1000 Yard anders -> neu
    r.m4 = miss(function() return D:Route(inst, pn, pw, n2, w2, 150, 41) end)               -- andere Grenze -> neu
    r.m5 = miss(function() return D:Route(inst, pn, pw, n2, w2, 150) end)                   -- ohne Grenze -> neu
    D:RouteCacheReset()
    r.m6, r.c = miss(function() return D:Route(inst, pn, pw, n2, w2, 150, 40) end)          -- geleert -> neu, gleiches Ergebnis
    local good = r.m2 == 0 and r.m3 == 1 and r.m4 == 1 and r.m5 == 1 and r.m6 == 1 and r.a == r.b and r.a == r.c
    return good, ("gleich gespeichert %s · 1/1000 yd neu %s · andere Grenze neu %s · ohne Grenze neu %s · geleert neu %s · Ergebnis gleich %s")
        :format(S(r.m2 == 0), S(r.m3 == 1), S(r.m4 == 1), S(r.m5 == 1), S(r.m6 == 1), S(r.a == r.b and r.a == r.c)), "true ×6"
end

-- 3.13.0 (Entscheid 19.11. 09:06): Befehlsliste ohne Entwickler-Befehle, wenn der Entwicklermodus aus ist; Gegenprobe an
IMPL.T363 = function()
    local H = LP.CmdHint
    if not (H and H.List and LP.COMMANDS) then return false, "CmdHint.List fehlt", "vorhanden" end
    local savedDev = H.dev
    local devCmds, normal = {}, 0
    for _, cmd in ipairs(LP.COMMANDS) do
        if cmd[1] ~= "" then if cmd.dev then devCmds[#devCmds + 1] = cmd[1] else normal = normal + 1 end end
    end
    local r = {}
    local ok, err = pcall(function()
        local function count(on)
            H.dev = function() return on end
            local nDev, nNorm = 0, 0
            for _, e in ipairs(H:List("")) do
                local isDev = false
                for _, cmd in ipairs(LP.COMMANDS) do if cmd.dev and e.order and LP.COMMANDS[e.order] == cmd then isDev = true end end
                if isDev then nDev = nDev + 1 else nNorm = nNorm + 1 end
            end
            return nDev, nNorm
        end
        r.offDev, r.offNorm = count(false)
        r.onDev, r.onNorm = count(true)
    end)
    H.dev = savedDev
    if not ok then error(err, 0) end
    local need = { "testroutine", "prüfliste", "debug", "sync test", "messen", "clienttest", "wegmessung" }
    local have = {}
    for _, w in ipairs(devCmds) do have[w] = true end
    local missing = {}
    for _, w in ipairs(need) do if not have[w] then missing[#missing + 1] = w end end
    local good = r.offDev == 0 and r.offNorm == normal and r.onDev == #devCmds and r.onNorm == normal and #missing == 0
    return good, ("aus: dev %d, normal %d/%d · an: dev %d/%d, normal %d · als dev: %s%s"):format(r.offDev, r.offNorm, normal, r.onDev,
        #devCmds, r.onNorm, table.concat(devCmds, ", "), #missing > 0 and (" · FEHLT: " .. table.concat(missing, ", ")) or ""),
        "aus: dev 0 · an: alle"
end

CLIENT.T302 = "Waffe einer noch nicht gelernten, für die Klasse erlaubten Art (grün oder besser) in die Tasche: Hinweis nennt den richtigen Waffenmeister; nach dem Lernen verschwindet er"

-- 3.12.41 LP-N1 3: eigene Testquest, eigene Stellen; Spieler, Zeit und Quest nur in eigenen Tabellen ersetzt
IMPL.T303 = function()
    local P, Geo, QDB = LP.Planner, LP.Geo, LP.QuestDB
    if not (P.WithoutExhausted and P.CheckStuck and P.MarkExhausted) then return false, "Funktionen fehlen", "vorhanden" end
    local Z = 1411
    local A, B, C = { Z, 40, 40 }, { Z, 41, 40 }, { Z, 60, 60 }        -- A und B nah beieinander, C weit weg
    local ai, an, aw = Geo:ToWorld(Z, 40, 40)
    local QID = 999303
    local saved = { steps = P.steps, ex = P.exhausted[QID], get = QDB.Get, player = Geo.Player, replan = P.Replan, stuck = P.stuck,
                    grind = LP.db.advGrind, lvl = LP.PlayerLevel }
    -- 3.13.8 LP-T1: Stufe 60 vorgeben – auf Stufe 1 (Nachbau) galt die Stelle C (Durotar 60/60) als zu gefährlich (SafePoints), der Hinweis
    -- kam nicht und die Prüfung war rot, nur wegen der Stufe des Testcharakters (Nachbau Stufe 25: OK)
    LP.PlayerLevel = function() return 60 end
    local r = {}
    -- 3.12.90 (Ingametest 3.12.89: "attempt to index field 'stuck' (a nil value)"): ist der Spieler beim Lauf AFK, setzt CheckStuck
    -- nichts. Darum hier "nicht AFK" für CheckStuck vortäuschen (eigene Umgebung, kein Blizzard-Global beschrieben) und fehlenden
    -- Zustand als Ergebnis melden statt als Lua-Fehler.
    local ok, err = pcall(WithEnv, { P.CheckStuck }, { UnitIsAFK = function() return false end }, function()
        LP.db.advGrind = true
        -- a) leere Stelle wird ausgelassen, alle leer -> Liste bleibt, abgelaufen -> wieder da
        P.exhausted[QID] = { { ai, an, aw, (GetTime and GetTime() or 0) + 600 } }
        local keep = P:WithoutExhausted(QID, { A, B, C })
        r.skip = #keep == 1 and keep[1] == C
        r.all = #P:WithoutExhausted(QID, { A, B }) == 2
        P.exhausted[QID][1][4] = 0
        r.expired = #P:WithoutExhausted(QID, { A, B, C }) == 3 and P.exhausted[QID] == nil
        -- b) Hinweis erst nach STUCK_SECS am Ziel ohne Fortschritt
        QDB.Get = function(_, id) if id == QID then return { id = QID, name = "Testquest", objectives = { { kind = "kill", spots = { A, B, C } } } } end return saved.get(QDB, id) end
        P.steps = { { t = "COMPLETE", id = QID, q = "Testquest", inst = ai, n = an, w = aw } }
        Geo.Player = function() return ai, an + 5, aw end
        P.stuck = nil
        r.first = #Collect(function(add) P:CheckStuck(add) end)
        r.started = P.stuck ~= nil
        if not r.started then return end
        P.stuck.since = P.stuck.since - (P.STUCK_SECS + 5)
        local h = Collect(function(add) P:CheckStuck(add) end)
        r.after, r.text = #h, h[1] and h[1].text or ""
        local hint
        P:CheckStuck(function(key, sev, text, action) hint = action end)
        -- c) "Andere Stelle": A gilt als leer, die Planung nimmt C (Replan hier nur gezählt)
        local replans = 0
        P.Replan = function() replans = replans + 1 end
        if hint then hint() end
        local keep2 = P:WithoutExhausted(QID, { A, B, C })
        r.marked = replans == 1 and #keep2 == 1 and keep2[1] == C
        -- d) weg vom Ziel -> zurückgesetzt; aus -> nichts
        Geo.Player = function() return ai, an + 500, aw end
        P:CheckStuck(function() end)
        r.away = P.stuck == nil
        LP.db.advGrind = false
        Geo.Player = function() return ai, an + 5, aw end
        r.off = #Collect(function(add) P:CheckStuck(add) end) == 0 and P.stuck == nil
    end)
    P.steps, P.exhausted[QID], QDB.Get, Geo.Player, P.Replan, P.stuck = saved.steps, saved.ex, saved.get, saved.player, saved.replan, saved.stuck
    LP.db.advGrind, LP.PlayerLevel = saved.grind, saved.lvl
    if not ok then error(err, 0) end
    local good = r.skip and r.all and r.expired and r.started and r.first == 0 and r.after == 1 and r.marked and r.away and r.off
    return good and true or false, ("Zähler gestartet %s · leere Stelle ausgelassen %s · alle leer -> Liste bleibt %s · abgelaufen %s · sofort %s · nach 3 Min. %s („%s“) · Andere Stelle %s · weg %s · aus %s")
        :format(S(r.started), S(r.skip), S(r.all), S(r.expired), S(r.first), S(r.after), tostring(r.text), S(r.marked), S(r.away), S(r.off)),
        "true · true · true · true · 0 · 1 · true · true · true"
end
CLIENT.T303 = "Bei einer Töte-Quest 3 Min. am Ziel ohne Fortschritt stehen/suchen: Hinweis „Seit 3 Min. kein Fortschritt …“, Klick „Andere Stelle“ -> Pfeil zur nächsten Stelle"

-- 3.12.42: eigene Ware, eigene Knöpfe, eigenes Händlerfenster (nur LP-Tabellen ersetzt; MerchantFrame über WithEnv)
IMPL.T304 = function()
    local A, API = LP.Advisor, LP.API
    if not (A.MarkMerchant and A.MerchantUpgrades) then return false, "MarkMerchant fehlt", "vorhanden" end
    local wares = {}
    for i = 1, 14 do wares[i] = (i == 2 or i == 12) and "lpt304:up" or "lpt304:no" end
    local function Btn()
        local b = { shown = false }
        function b:CreateTexture()
            local t = { visible = true }
            function t:SetTexture() end function t:SetSize() end function t:SetPoint() end
            function t:Show() self.visible = true end function t:Hide() self.visible = false end
            return t
        end
        return b
    end
    local btns = {}
    for i = 1, 10 do btns[i] = Btn() end
    local frame = { page = 1, selectedTab = 1, IsShown = function() return true end }
    local saved = { count = API.MerchantCount, link = API.MerchantLink, equ = API.IsEquippable, up = A.UpgradeValue,
                    btn = A.MerchantButton, adv = LP.db.advUpgrades }
    local r = {}
    local ok, err = pcall(WithEnv, { A.MarkMerchant }, { MerchantFrame = frame, MERCHANT_ITEMS_PER_PAGE = 10 }, function()
        API.MerchantCount = function() return #wares end
        API.MerchantLink = function(i) return wares[i] end
        API.IsEquippable = function() return true end
        A.UpgradeValue = function(_, link) if link == "lpt304:up" then return 5 end return nil end
        A.MerchantButton = function(i) return btns[i] end
        LP.db.advUpgrades = true
        r.p1 = A:MarkMerchant()
        r.b2 = btns[2].lpUpgrade and btns[2].lpUpgrade.visible
        r.b3 = btns[3].lpUpgrade == nil
        frame.page = 2 r.p2 = A:MarkMerchant()
        r.p2b2 = btns[2].lpUpgrade and btns[2].lpUpgrade.visible           -- Ware 12 auf Seite 2, Platz 2
        frame.selectedTab = 2 r.buyback = A:MarkMerchant()
        r.hidden = btns[2].lpUpgrade and not btns[2].lpUpgrade.visible
        frame.selectedTab = 1 LP.db.advUpgrades = false r.off = A:MarkMerchant()
        return true
    end)
    API.MerchantCount, API.MerchantLink, API.IsEquippable, A.UpgradeValue, A.MerchantButton = saved.count, saved.link, saved.equ, saved.up, saved.btn
    LP.db.advUpgrades = saved.adv
    if not ok then error(err, 0) end
    local good = r.p1 == 1 and r.b2 and r.b3 and r.p2 == 1 and r.p2b2 and r.buyback == 0 and r.hidden and r.off == 0
    return good and true or false, ("Seite 1: %s markiert (Platz 2 %s, Platz 3 ohne %s) · Seite 2: %s (Platz 2 %s) · Rückkauf-Reiter %s, ausgeblendet %s · aus %s")
        :format(S(r.p1), S(r.b2), S(r.b3), S(r.p2), S(r.p2b2), S(r.buyback), S(r.hidden), S(r.off)), "1 · true · true · 1 · true · 0 · true · 0"
end
CLIENT.T304 = "Händler mit tragbarer Ware öffnen: Plus-Zeichen oben links an den Waren, die für deine Klasse ein Upgrade sind (wie „Mögliches Upgrade“); Seite wechseln: Zeichen wandern mit"

-- 3.12.43: Talentbaum des Kriegers aus den eigenen Build-Daten nachgebaut (eigene Ränge), Sprache ersetzt.
-- 3.12.88 EULA: die Liste kennt nur Namen (de/en) – Suche über den Namen, Platzhalter und fremde Sprachen ohne Vorschlag.
IMPL.T305 = function()
    local A = LP.Advisor
    local list = LP.TalentBuilds and LP.TalentBuilds.WARRIOR
    if not (A.TalentNext and list) then return false, "TalentNext oder Builds fehlen", "vorhanden" end
    -- alle 9 Klassen: 51 Punkte; keine Lage im Baum mehr in den Daten (nur Namen, Ränge, Sätze)
    local all51, noPos, n9 = true, true, 0
    for _, l in pairs(LP.TalentBuilds) do
        n9 = n9 + 1
        local n = 0
        for _, e in ipairs(l) do
            n = n + (e.r or 0)
            if type(e[3]) == "number" or type(e[4]) == "number" or e.alt then noPos = false end
            if type(e[1]) ~= "string" or type(e[2]) ~= "string" or type(e.de) ~= "string" then noPos = false end
        end
        if n ~= 51 then all51 = false end
    end
    all51 = all51 and n9 == 9
    local lang, names = "de", {}
    local function build()
        names = {}
        for _, e in ipairs(list) do
            local nm = e[lang]
            if nm and not names[nm] then names[nm] = { nm, 0, 5 } names[#names + 1] = names[nm] end
        end
    end
    build()
    local fake = {
        UnitClass = function() return "Krieger", "WARRIOR" end,
        GetLocale = function() return lang == "de" and "deDE" or (lang == "en" and "enUS" or "frFR") end,
        GetNumTalentTabs = function() return 1 end,
        GetNumTalents = function() return #names end,
        GetTalentInfo = function(_, i) local t = names[i] return t[1], nil, 1, i, t[2], t[3] end,
    }
    local r = {}
    local ok, err = pcall(WithEnv, { A.TalentNext, A.TalentLang }, fake, function()
        r.n1, r.r1, _, r.w1 = A:TalentNext()
        names[list[1].de][2] = list[1].r
        r.n2, r.r2 = A:TalentNext()
        -- alles bis vor den Platzhalter (Waffenmeister) erfüllt -> kein Vorschlag, Grund "offen"
        for k = 1, #list do
            if list[k].offen then r.openIndex = k break end
            names[list[k].de][2] = math.min(5, (names[list[k].de][2] or 0) + 0) names[list[k].de][2] = list[k].r
        end
        local a, _, _, _, g = A:TalentNext()
        r.open = a == nil and g == "offen" and r.openIndex ~= nil
        -- englischer Client: englische Namen und Sätze
        lang = "en" build()
        local n, _, _, w = A:TalentNext()
        r.en = n == list[1].en and w == list[1][2]
        -- fremde Sprache: kein Vorschlag, Grund "sprache"
        lang = "fr"
        local b, _, _, _, g2 = A:TalentNext()
        r.lang = b == nil and g2 == "sprache"
        -- Name steht nicht im Baum (anderer Client): kein Vorschlag, Grund "offen"
        lang = "de" build() names = {}
        local c, _, _, _, g3 = A:TalentNext()
        r.missing = c == nil and g3 == "offen"
        return true
    end)
    if not ok then error(err, 0) end
    local good = all51 and noPos and r.n1 == list[1].de and r.r1 == 1 and r.w1 == list[1][1] and r.n2 == list[2].de and r.r2 == 1
        and r.open and r.en and r.lang and r.missing
    return good, ("51 Punkte je Klasse %s · nur Namen %s · Start %s %s/… · danach %s · Platzhalter stoppt %s · englisch %s · fremde Sprache %s · Name fehlt %s")
        :format(S(all51), S(noPos), tostring(r.n1), tostring(r.r1), tostring(r.n2), S(r.open), S(r.en), S(r.lang), S(r.missing)),
        "alles true, erster Eintrag Rang 1, zweiter Eintrag"
end
CLIENT.T305 = "Mit freiem Talentpunkt: Hinweis „Talentpunkt(e) frei“ zeigt „Vorschlag (Level-Build von LevelPilot): <Talent> x/y – <Satz>“; das Talent gibt es im Talentfenster (Taste N)"

-- 3.12.44: öffentliche Schnittstelle; Neuplanung nur gezählt, Ziel danach wiederhergestellt
IMPL.T306 = function()
    local API = _G.LevelPilotAPI
    if not (API and API.NavigateTo) then return false, "LevelPilotAPI.NavigateTo fehlt", "vorhanden" end
    local P = LP.Planner
    local saved, savedReplan = P.priority, P.Replan
    local replans = 0
    local r = {}
    -- 3.12.93 (Ingametest 3.12.91: T306 189 ms; Nachbau Allianz im Wald von Elwynn: 544 ms in einem Bild – Reiseplan nach Durotar
    -- über den Kontinent): geprüft wird das Ziel, nicht der Reiseplan – C.PlanNavi hier ersetzt wie die Neuplanung
    local Cf = LP.Comfort
    local savedPlan = Cf and Cf.PlanNavi
    local ok, err = pcall(function()
        P.Replan = function() replans = replans + 1 end
        if Cf then Cf.PlanNavi = function() return false end end
        r.good = API.NavigateTo(1411, 52.0, 43.0, "Lehrer lpt306")
        local p = P.priority
        r.step = p and p.t == "GOTO" and p.text == "Lehrer lpt306" and p.map == 1411 and p.inst ~= nil
        r.notitle = API.NavigateTo(1411, 50, 50) and P.priority.text ~= ""
        P.priority = nil
        r.bad1 = API.NavigateTo(1411, 150, 20)
        r.bad2 = API.NavigateTo(nil, 10, 10)
        r.bad3 = API.NavigateTo("x", 10, 10)
        r.untouched = P.priority == nil
        -- unbekannte Karte: nur prüfbar, wo die Spielversion für sie keine Weltkoordinaten liefert (im Nachbau gibt es alle)
        if LP.Geo:ToWorld(987654, 50, 50) == nil then r.unknown = API.NavigateTo(987654, 50, 50) else r.unknown = "n/a" end
    end)
    P.priority, P.Replan = saved, savedReplan
    if Cf then Cf.PlanNavi = savedPlan end
    if not ok then error(err, 0) end
    local good = r.good == true and r.step and r.notitle and r.bad1 == false and r.bad2 == false and r.bad3 == false
        and (r.unknown == false or r.unknown == "n/a") and r.untouched and replans == 2 and (tonumber(API.version) or 0) >= 2      -- 3.12.63: Schnittstelle ab Version 2 (T323); 3.12.92: Version 3 (TestRunning)
    return good, ("gültig %s, Schritt oben %s, ohne Titel %s · x=150 %s · ohne Karte %s · Text %s · unbekannte Karte %s · Ziel unverändert %s · Neuplanungen %d · Version %s")
        :format(S(r.good), S(r.step), S(r.notitle), S(r.bad1), S(r.bad2), S(r.bad3), S(r.unknown), S(r.untouched), replans, S(API.version)),
        "true · true · true · false · false · false · false · true · 2 · 2"
end
CLIENT.T306 = "/run print(LevelPilotAPI.NavigateTo(1411, 52, 43, \"Test\")) -> true, oben im Guide steht „Test“ mit Pfeil dorthin"

-- 3.12.45 LP-N2: eigene Prüfpunkte (Fenster und Meldung ersetzt), dann die echten zehn ohne Lua-Fehler
IMPL.T307 = function()
    local CT = LP.ClientTest
    if not (CT and CT.Start and CT.Answer and CT.DiagLines) then return false, "ClientTest fehlt", "vorhanden" end
    local saved = { steps = CT.STEPS, show = CT.Show, hide = CT.Hide, reply = LP.Reply, ct = LP.db.clientTest }
    local shown, replies = {}, {}
    local r = {}
    local ok, err = pcall(function()
        CT.Show = function(_, x) shown[#shown + 1] = x.id end
        CT.Hide = function() end
        LP.Reply = function(_, m) replies[#replies + 1] = m end
        CT.STEPS = {
            { id = "A", name = "auto ok, Frage", auto = function() return "OK", "a" end, ask = function() return "Siehst du A?" end },
            { id = "B", name = "auto ok", auto = function() return "OK", "b" end },
            { id = "C", name = "auto fehler", auto = function() return "FEHLER", "c" end, ask = function() return "nie gefragt" end },
            { id = "D", name = "Lua-Fehler", auto = function() error("lpt307") end },
            { id = "E", name = "auto ok, Frage", auto = function() return "OK", "e" end, ask = function() return "Siehst du E?" end },
            { id = "F", name = "auto ok, Frage", auto = function() return "OK", "f" end, ask = function() return "Siehst du F?" end },
        }
        CT:Start()
        r.firstShown = shown[1]
        r.queued = #CT.queue
        CT:Answer(true)
        CT:Answer(false)
        CT:Answer(nil)
        local st = {}
        for _, x in ipairs(CT.results) do st[x.id] = x.status end
        r.st = st
        r.summary = CT:Summary()
        r.reply = replies[1]
        r.diag = #CT:DiagLines()
        -- echte Prüfpunkte: laufen ohne Lua-Fehler durch (Antworten: überspringen)
        CT.STEPS = saved.steps
        CT:Start()
        while #CT.queue > 0 do CT:Answer(nil) end
        local luaErr = 0
        for _, x in ipairs(CT.results) do if tostring(x.detail):find("lua", 1, true) or tostring(x.detail):find("attempt to", 1, true) then luaErr = luaErr + 1 end end
        r.real, r.realErr = #CT.results, luaErr
    end)
    CT.STEPS, CT.Show, CT.Hide, LP.Reply, LP.db.clientTest = saved.steps, saved.show, saved.hide, saved.reply, saved.ct
    if not ok then error(err, 0) end
    local st = r.st or {}
    local good = r.firstShown == "A" and r.queued == 3 and st.A == "OK" and st.B == "OK" and st.C == "FEHLER" and st.D == "FEHLER"
        and st.E == "FEHLER" and st.F == "N/A" and r.diag == 7 and r.reply and r.real == 10 and r.realErr == 0
    return good, ("zuerst gefragt %s · Fragen %s · A %s B %s C %s D %s E(nicht OK) %s F(übersprungen) %s · „%s“ · Diagnose-Zeilen %s · echte Punkte %s, Lua-Fehler %s")
        :format(tostring(r.firstShown), S(r.queued), tostring(st.A), tostring(st.B), tostring(st.C), tostring(st.D), tostring(st.E),
            tostring(st.F), tostring(r.reply), S(r.diag), S(r.real), S(r.realErr)),
        "A · 3 · OK OK FEHLER FEHLER FEHLER N/A · Meldung · 7 · 10, 0"
end

-- 3.12.46: eigenes Mess-Werkzeug (nur Zähler), Fenster und Meldung ersetzt, Ziel des Guides danach wiederhergestellt
IMPL.T308 = function()
    local WM = LP.WegMessung
    if not (WM and WM.Start and WM.Mark and WM.Tool) then return false, "WegMessung fehlt", "vorhanden" end
    local marks, running, started, stopped = {}, false, 0, 0
    local tool = {
        Running = function() return running end,
        Start = function() running = true started = started + 1 end,
        Stop = function() running = false stopped = stopped + 1 end,
        Mark = function(t) if not running then return false end marks[#marks + 1] = t return true end,
    }
    local have = false
    local saved = { show = WM.Show, reply = LP.Reply, prio = LP.Planner.priority, replan = LP.Planner.Replan,
                    planNavi = LP.Comfort and LP.Comfort.PlanNavi }
    local replies, shown = {}, 0
    local r = {}
    local ok, err = pcall(function()
        WM.Show = function() shown = shown + 1 end
        LP.Reply = function(_, m) replies[#replies + 1] = m end
        LP.Planner.Replan = function() end
        -- 3.12.93 (Ingametest 3.12.91: T308 334 ms in einem Bild): der Reiseplan je Ziel (C.PlanNavi, Wegsuche) gehört nicht zu
        -- dieser Prüfung (geprüft wird Ablauf und Ziel) – hier ersetzt wie die Neuplanung
        if LP.Comfort then LP.Comfort.PlanNavi = function() return false end end
        local realTool = WM.Tool
        WM.Tool = function() return have and tool or nil end
        r.missing = WM:Start() == false and replies[1] ~= nil and WM.state == nil
        have = true
        r.started = WM:Start() == true and started == 1 and running and shown == 1
        r.arrow = LP.Planner.priority and LP.Planner.priority.text ~= nil      -- Lauf 1 Schritt 1: Pfeil zum Auktionshaus
        local names = WM.Names()
        r.names = names.uc ~= nil and names.mq ~= nil and not tostring(names.mq):find("^#")
        WM:Mark() WM:Mark() WM:Mark()                                      -- Lauf 1 fertig
        r.run2 = WM.state and WM.state.run == 2 and WM.state.step == 1
        WM:SkipRun()                                                       -- Lauf 2 übersprungen
        r.run3 = WM.state and WM.state.run == 3
        WM:Mark() WM:Mark()                                                -- Lauf 3
        WM:Mark() WM:Mark() WM:Mark()                                      -- Lauf 4 -> fertig
        r.done = WM.state == nil and stopped == 1 and not running
        r.marks = #marks
        r.first = marks[1]
        r.skip = false for _, m in ipairs(marks) do if m == "L2 übersprungen" then r.skip = true end end
        r.final = replies[#replies]
        WM.Tool = realTool
    end)
    WM.Show, LP.Reply, LP.Planner.priority, LP.Planner.Replan = saved.show, saved.reply, saved.prio, saved.replan
    if LP.Comfort then LP.Comfort.PlanNavi = saved.planNavi end
    WM.state = nil
    if not ok then error(err, 0) end
    local good = r.missing and r.started and r.arrow and r.names and r.run2 and r.run3 and r.done and r.marks == 9 and r.skip
        and r.first == "L1 Auktionshaus"
    return good and true or false, ("ohne Werkzeug Hinweis %s · Start %s · Pfeil %s · Ortsnamen %s · Lauf 2 %s · übersprungen -> Lauf 3 %s · Ende stoppt %s · Notizen %s (erste „%s“, Sprung notiert %s) · „%s“")
        :format(S(r.missing), S(r.started), S(r.arrow), S(r.names), S(r.run2), S(r.run3), S(r.done), S(r.marks), tostring(r.first), S(r.skip), tostring(r.final)),
        "true · true · true · true · true · true · true · 9 (L1 Auktionshaus, true)"
end
CLIENT.T308 = "Mit GSWegMess: /lp wegmessung – Fenster zeigt Lauf 1 Schritt 1, Pfeil zum Auktionshaus; „Markieren & weiter“ -> /wegmess zeigt mehr Zeilen; am Ende Chatzeile „Wegmessung fertig …“"

-- 16.11.: Prüfliste im Spiel. (a)/(b) echter Baustein GoldSentinelPruefliste, Testmodus über eine eigene Umgebung für dessen
-- IsDev (setfenv, _G.GoldSentinelDev bleibt unberührt), Zustand in einer Testtabelle (nie LevelPilotDB).
-- (c) jede Erkennungsstelle: eine Ersatzliste zählt mit, welche Punkte gemeldet werden; die Stellen laufen über die
-- vorhandenen Tests (T293, T300–T304, T307) bzw. über eigene kleine Aufrufe (Talent, Wegmessung, Unterstadt, Protokoll).
IMPL.T309 = function()
    local M = LP.Pruefliste
    local PL = M and M.Baustein and M.Baustein()
    if not (M and M.List and M.Hit and M.POINTS) then return false, "Prüfliste fehlt", "vorhanden" end
    if type(PL) ~= "table" or type(PL.IsDev) ~= "function" then return false, "GoldSentinelPruefliste.lua fehlt", "vorhanden" end
    local saved = { list = M.list, next = M.nextTry, db = M.DB, dry = M.Dry, reg = PL.lists and PL.lists.LevelPilot, pts = M.Points,
                    perf = LP.Perf, mem = LP.Protocol.MemInfo, fac = LP.PlayerFaction, player = LP.Geo.Player,
                    tp = LP.API.TalentPoints, tn = LP.Advisor.TalentNext, adv = LP.db.advTalents, reply = LP.Reply,
                    rdb = M.ReportDB }
    local devOn, testDB, r = false, {}, {}
    local reportDB = {}                                 -- 3.12.89: Berichte je abgehaktem Punkt (T347) nie in die echten Daten
    M.ReportDB = function() return reportDB end
    local fakeDev = { version = 99, IsDev = function() return devOn end }
    -- der Baustein liest _G.GoldSentinelDev: eigene Sicht auf _G nur für dessen IsDev (das echte _G wird nicht beschrieben)
    local viewG = setmetatable({ GoldSentinelDev = fakeDev }, { __index = _G, __newindex = function() error("T309: _G nicht beschreiben", 0) end })
    local ok, err = pcall(WithEnv, { PL.IsDev }, { GoldSentinelDev = fakeDev, _G = viewG }, function()
        M.DB = function() return testDB end
        M.Dry = function() return false end
        M.Points = function() return M.POINTS end    -- 3.12.65: die Forever-Liste (die Era-Liste prüft T325)
        -- (a) ohne Testmodus: keine Liste, nichts gemeldet, keine Berichtszeilen
        M.list, M.nextTry = nil, 0
        r.offList = M:List(true) == nil
        r.offHit = M:Hit("T300", "x") == false and M:Fail("PF-A", "x") == false
        r.offReport = #M:ReportLines() == 0
        r.offStore = next(testDB) == nil
        -- (b) mit Testmodus: angemeldet, 15 Punkte vollständig, Fehler-Meldung und Bericht
        devOn = true
        M.list, M.nextTry = nil, 0
        local l = M:List(true)
        r.on = l ~= nil and PL.lists.LevelPilot == l
        local ids, full = {}, 0
        for _, p in ipairs(l and l.points or {}) do
            if p.id and p.title and p.since and p.todo and p.expect and not ids[p.id] then full = full + 1 end
            ids[p.id] = true
        end
        r.n, r.full = l and #l.points or 0, full
        r.fail = M:Fail("PF-A", "20 ms") == true and l:State("PF-A") == "fehler"
        r.failAgain = M:Fail("PF-A", "21 ms") == false
        r.head = (M:ReportLines()[1] or "")
        r.lines = #M:ReportLines()
        r.stored = type(testDB.pruefliste) == "table" and type(testDB.pruefliste.p) == "table" and testDB.pruefliste.p["PF-A"] ~= nil
        -- (c) jede Erkennungsstelle: Ersatzliste zählt mit
        local seen = {}
        M.list = { byId = ids, State = function() return "offen" end, Set = function() return true end,
                   Hit = function(_, id) seen[id] = "hit" return true end, ReportLines = function() return {} end }
        local fakeFail = M.Fail
        M.Fail = function(self, id) seen[id] = seen[id] or "fail" return true end
        for _, t in ipairs({ "T293", "T300", "T301", "T302", "T303", "T304", "T307", "T344", "T362" }) do pcall(IMPL[t]) end   -- T344: Kartenrahmen (3.12.88), T362: Später/Nicht mehr (3.13.0)
        -- Talent-Vorschlag (CheckTalents mit einem freien Punkt und einem Vorschlag)
        LP.db.advTalents = true
        LP.API.TalentPoints = function() return 1 end
        LP.Advisor.TalentNext = function() return "Testtalent", 1, 5, "Test" end
        pcall(Collect, LP.Advisor.CheckTalents)
        LP.API.TalentPoints, LP.Advisor.TalentNext, LP.db.advTalents = saved.tp, saved.tn, saved.adv
        -- Wegmessung vollständig (eigenes Mess-Werkzeug, 12 Markierungen, kein Lauf übersprungen)
        local WM = LP.WegMessung
        local running = false
        local tool = { Running = function() return running end, Start = function() running = true end,
                       Stop = function() running = false end, Mark = function() return running end }
        local realTool, realShow, realGuidePrio, realReplan = WM.Tool, WM.Show, LP.Planner.priority, LP.Planner.Replan
        local realPlanNavi = LP.Comfort and LP.Comfort.PlanNavi          -- 3.12.93: Reiseplan je Ziel hier nicht nötig (wie T308)
        WM.Tool, WM.Show, LP.Planner.Replan = function() return tool end, function() end, function() end
        if LP.Comfort then LP.Comfort.PlanNavi = function() return false end end
        LP.Reply = function() end
        pcall(function()
            WM:Start()
            for _ = 1, WM.StepCount() do WM:Mark() end
        end)
        WM.Tool, WM.Show, LP.Planner.priority, LP.Planner.Replan, WM.state = realTool, realShow, realGuidePrio, realReplan, nil
        if LP.Comfort then LP.Comfort.PlanNavi = realPlanNavi end
        r.wmSteps = WM.StepCount()
        -- Unterstadt: bekannter Weg (graph) in Karte 1458; Gegenprobe: "Weg unbekannt" bzw. andere Karte meldet nichts
        LP.Geo.Player = function() return 1, 0, 0, 1458 end
        local nav = LP.Nav
        r.navNo = nav.PLWeg("  (Weg unbekannt)", "graph", 200) == false and nav.PLWeg("", "direct", 200) == false
        LP.Geo.Player = function() return 1, 0, 0, 1454 end
        r.navNo = r.navNo and nav.PLWeg("", "graph", 200) == false and seen["UC-W1"] == nil
        LP.Geo.Player = function() return 1, 0, 0, 1458 end
        nav.PLWeg("", "graph", 200)
        LP.Geo.Player = saved.player
        -- Protokoll: Speicher-Messung, Krieger 60 s, Allianz-Planung (20 ms = zu langsam), 2 Stunden Spiel
        local now = GetTime and GetTime() or 0
        LP.Perf = { stats = { route = { n = 4, max = 20, ln = 1, lms = 300 }, ui = { n = 9, max = 2, ln = 3, lms = 200 } },
                    loginT = now - 8000, FRAME_MS = 16 }
        LP.Protocol.MemInfo = function() return { ms = 12 } end
        LP.PlayerFaction = function() return "Alliance" end
        r.loginMs = M.LoginMs()
        pcall(WithEnv, { M.OnProtocol }, { UnitClass = function() return "Krieger", "WARRIOR" end }, function() M:OnProtocol() return true end)
        LP.Perf, LP.Protocol.MemInfo, LP.PlayerFaction = saved.perf, saved.mem, saved.fac
        M.Fail = fakeFail
        -- Testroutine (trocken) meldet nie etwas: echte Sperre M.Dry mit LP.Act.dry = true
        M.Dry = saved.dry
        local wasDry = LP.Act.dry
        LP.Act.dry = true
        seen.DRY = nil
        r.dry = M:Hit("T300", "trocken") == false and M:Fail("PF-A", "trocken") == false
        LP.Act.dry = wasDry
        local miss = {}
        for _, p in ipairs(M.POINTS) do if not seen[p.id] then miss[#miss + 1] = p.id end end
        r.miss = table.concat(miss, ",")
        r.pfa = seen["PF-A"]
        return true
    end)
    M.list, M.nextTry, M.DB, M.Dry, M.Points, M.ReportDB = saved.list, saved.next, saved.db, saved.dry, saved.pts, saved.rdb
    if PL.lists then PL.lists.LevelPilot = saved.reg end
    LP.Perf, LP.Protocol.MemInfo, LP.PlayerFaction, LP.Geo.Player = saved.perf, saved.mem, saved.fac, saved.player
    LP.API.TalentPoints, LP.Advisor.TalentNext, LP.db.advTalents, LP.Reply = saved.tp, saved.tn, saved.adv, saved.reply
    if not ok then error(err, 0) end
    local good = r.offList and r.offHit and r.offReport and r.offStore and r.on and r.n == 15 and r.full == 15 and r.fail
        and r.failAgain and r.head:find("0 von 15", 1, true) ~= nil and r.lines == 16 and r.stored and r.navNo and r.miss == ""
        and r.pfa == "fail" and r.loginMs == 500 and r.wmSteps == 12 and r.dry
    return good and true or false, ("ohne Testmodus: Liste %s, Meldung %s, Bericht leer %s, nichts gespeichert %s · mit: angemeldet %s, Punkte %s (vollständig %s), Fehler %s/doppelt %s, „%s“ (%s Zeilen), gespeichert %s · Unterstadt-Gegenprobe %s · nicht ausgelöst: „%s“ · PF-A %s · 60 s %s ms · Wegmessung %s Schritte · trocken gesperrt %s")
        :format(S(r.offList), S(r.offHit), S(r.offReport), S(r.offStore), S(r.on), S(r.n), S(r.full), S(r.fail), S(r.failAgain),
            tostring(r.head), S(r.lines), S(r.stored), S(r.navNo), tostring(r.miss), tostring(r.pfa), S(r.loginMs), S(r.wmSteps), S(r.dry)),
        "true ×4 · true, 15 (15), true/true, „PRÜFLISTE LevelPilot: 0 von 15 erledigt“ (16), true · true · „“ · fail · 500 · 12 · true"
end
CLIENT.T309 = "/lp prüfliste (nur Testmodus): Fenster „Prüfliste LevelPilot 3.12.47 – 0 von 14 erledigt“, unten die Anweisung zum ersten Punkt; /afk draussen -> T300 springt auf „erledigt (erkannt)“ und eine Chatzeile erscheint"

-- LW-6: Laufweg-Messung mit gespielter Folge (Werte direkt an LW:Sample, eigene Charakter-Tabelle statt LevelPilotCharDB)
IMPL.T310 = function()
    local LW = LP.Laufweg
    if not (LW and LW.Sample and LW.Lines and LW.Store) then return false, "Laufweg fehlt", "vorhanden" end
    local saved = { char = LP.char, cur = LW.cur, last = LW.last }
    local r = {}
    local ok, err = pcall(function()
        LP.char = {}
        LW.cur, LW.last = nil, nil
        local t, pos = 0, { 0, 0 }
        local planned = {}
        local function tick(dt, o)
            t = t + dt
            o = o or {}
            o.now, o.inst, o.n, o.w, o.map = t, 1, o.n or pos[1], o.w or pos[2], 1413
            o.level, o.xp, o.xpMax = o.level or 10, o.xp, o.xpMax or 1000
            o.planned = function(k) return planned[k] == true end
            pos = { o.n, o.w }
            LW:Sample(o)
        end
        local A = { key = "A", t = "COMPLETE", inst = 1, n = 0, w = 300 }
        local B = { key = "B", t = "TURNIN", inst = 1, n = 0, w = 900 }
        local C = { key = "C", t = "ACCEPT", inst = 1, n = 0, w = -900 }
        -- A: 300 yd Luftlinie, 30 s geradeaus mit 10 yd/s (Pfad Netz), Ankunft bei 260 (40 yd), dann 20 s am Ziel
        planned.A = true
        tick(0, { step = A, xp = 100 })
        for i = 1, 30 do tick(1, { step = A, w = i * 10, kind = "graph", xp = 100 + i * 10 }) end
        for _ = 1, 20 do tick(1, { step = A, w = 300, kind = "graph", xp = 400 }) end
        -- A erledigt (nicht mehr geplant) -> B; 12 s Richtung B, dann Neuplanung auf C (entgegengesetzt), B bleibt geplant
        planned.A, planned.B = nil, true
        for i = 1, 12 do tick(1, { step = B, w = 300 + i * 5, kind = "terrain", xp = 400 }) end
        planned.C = true
        tick(1, { step = C, w = 360, xp = 400 })
        -- C: Sprung (500 yd in 1 s), Flug (taxi), AFK, Lücke (10 s) – zählen nicht als gelaufen
        tick(1, { step = C, w = -140, unknown = true, xp = 400 })
        for i = 1, 5 do tick(1, { step = C, w = -140 - i * 50, taxi = true, kind = "direct", xp = 400 }) end
        for _ = 1, 4 do tick(1, { step = C, w = -390, afk = true, xp = 400 }) end
        tick(10, { step = C, w = -390, xp = 400 })
        for i = 1, 6 do tick(1, { step = C, w = -390 - i * 10, kind = "direct", xp = 900 }) end
        -- Levelaufstieg: 900 -> Level 11 mit 50 EP (Level 10 bekommt die restlichen 100)
        tick(1, { step = C, w = -460, level = 11, xp = 50 })
        r.gelC = LW.cur and LW.cur.key == "C" and LW.cur.gel        -- nur 6×10 + 10 beim Levelaufstieg (ohne Sprung 500, Flug 250)
        -- Leerlauf: 7 s ohne Schritt mit Ziel (C wird dabei abgeschlossen)
        planned.C = nil
        for _ = 1, 7 do tick(1, { step = { key = "NODATA", t = "LEVEL" }, w = -460, level = 11, xp = 50 }) end
        local s = LW.Store()
        local z = s.z[1413] or { k = {} }
        r.n, r.a, r.luftA, r.gelA, r.tw, r.tz = z.n, z.a, z.luftA, z.gelA, z.tw, z.tz
        r.netz, r.gel, r.unb = z.k.netz or 0, z.k.gel or 0, z.k.unb or 0
        r.replans, r.rev, r.idle = s.replans, s.rev, s.idle
        r.l10, r.l11 = s.lvl[10] and s.lvl[10].xp, s.lvl[11] and s.lvl[11].xp
        r.s10 = s.lvl[10] and s.lvl[10].s
        local lines = LW.Lines(s)
        r.lines = #lines
        r.first = lines[1]
        r.umweg = tostring(lines[1]):find("Umweg gelaufen/Luftlinie 0,87", 1, true) ~= nil
        r.zone = tostring(lines[4]):find("(3, ", 1, true) ~= nil
        r.eph = tostring(lines[5]):find("^EP/h je Level") ~= nil
        r.diff = LW.Diff(170, -170) == 20 and LW.Diff(0, 180) == 180
        return true
    end)
    LP.char, LW.cur, LW.last = saved.char, saved.cur, saved.last
    if not ok then error(err, 0) end
    -- erwartet: A (Start bei 0, Luftlinie 300, Ankunft in Sekunde 26 bei 260 yd = 40 yd vor dem Ziel: gelaufen 260, Weg 25 s,
    -- die Sekunde der Ankunft und die 24 danach am Ziel = 25 s), B (12 s Weg, Gelände), C (Weg 1 + 1 Sprung + 5 Flug + 6 + 1 s;
    -- AFK und die Lücke zählen nicht). EP Level 10: 300 + 500 + 100 = 900, Level 11: 50
    local good = r.n == 3 and r.a == 1 and r.luftA == 300 and r.gelA == 260 and r.tw == 25 + 12 + 14 and r.tz == 25
        and r.netz == 25 and r.gel == 12 and r.unb == 1 and r.replans == 1 and r.rev == 1 and r.idle == 7
        and r.l10 == 900 and r.l11 == 50 and r.gelC == 70 and r.lines == 6 and r.umweg and r.zone and r.eph and r.diff
    return good and true or false, ("Schritte %s (angekommen %s) · Luftlinie %s gelaufen %s · Zeit Weg %s / Ziel %s · Netz %s s Gelände %s s unbekannt %s s · Neuplanungen %s Richtungswechsel %s · Leerlauf %s s · EP L10 %s L11 %s (L10 %s s) · C gelaufen %s · Zeilen %s, Umweg 0,87 %s, Zone %s, EP/h %s, Winkel %s")
        :format(S(r.n), S(r.a), S(r.luftA), S(r.gelA), S(r.tw), S(r.tz), S(r.netz), S(r.gel), S(r.unb), S(r.replans), S(r.rev), S(r.idle),
            S(r.l10), S(r.l11), S(r.s10), S(r.gelC), S(r.lines), S(r.umweg), S(r.zone), S(r.eph), S(r.diff)),
        "3 (1) · 300 / 260 · 51 / 25 · 25 / 12 / 1 · 1 / 1 · 7 · 900 / 50 · C 70 · 6, true ×5"
end
CLIENT.T310 = "Nach einer Spielstunde /lp protokoll: Zeilen „LAUFWEG …“ (Schritte, Umweg, Zeit Weg/Ziel, Pfad, Neuplanungen, je Zone) und „EP/h je Level“ mit plausiblen Zahlen"

-- LW-3: Flug nach Zeit. Zahlen (Umweg 1,25, Gespräch 15 s, Vorsprung 30 s):
--  B Reittier 14 yd/s, Luftlinie 2600, je 500 yd zum/vom Flugmeister, Flug 1800 yd (Annahme 30 + 1800×1,3/32 = 103,1 s):
--    laufen 232,1 s · fliegen 89,3 + 15 + 103,1 = 207,4 s (+30 = 237,4 > 232,1) -> LAUFEN; alte Regel 1000×1,25+300 = 1550 < 2600 = Flug
--  C zu Fuss 7 yd/s, Luftlinie 2500, je 900 yd, Flug gemessen 60 s: laufen 446,4 s · fliegen 321,4 + 15 + 60 = 396,4 (+30 = 426,4
--    < 446,4) -> FLUG; alte Regel 1800×1,25+300 = 2550 >= 2500 = laufen
IMPL.T311 = function()
    local P, Geo = LP.Planner, LP.Geo
    if not (P.FlyDecision and P.GroundYps and P.FlightSecs and LP.Laufweg and LP.Laufweg.MountSpeed) then return false, "LW-3 fehlt", "vorhanden" end
    local saved = { char = LP.char, taxi = LP.db.taxi, tp = Geo.TaxiPoint, fs = LP.Calib.FlightSecs, last = P.lastTravel }
    local r = {}
    local ok, err = pcall(function()
        LP.char = { taxiKnown = {} }
        -- Tempo
        r.foot = P.GroundYps() == 7
        r.m1 = LP.Laufweg.MountSpeed(11.2) == true and LP.char.mountYps == 11.2
        r.m2 = LP.Laufweg.MountSpeed(30) == false and LP.Laufweg.MountSpeed(6) == false and LP.Laufweg.MountSpeed(9) == false
        r.m3 = LP.Laufweg.MountSpeed(14) == true and P.GroundYps() == 14
        -- Flugzeit: Annahme ohne Messung, sonst gemessen
        LP.Calib.FlightSecs = function() return nil end
        local a, asrc = P.FlightSecs(1800)
        r.ann = math.abs(a - (30 + 1800 * 1.3 / 32)) < 0.01 and asrc == "Annahme"
        LP.Calib.FlightSecs = function(_, d) return d / 30 end
        local g, gsrc = P.FlightSecs(1800)
        r.mes = g == 60 and gsrc == "gemessen"
        -- Entscheid als Zahl
        local fb, wb, flb = P.FlyDecision(2600, 500, 500, 30 + 1800 * 1.3 / 32, 14)
        r.b = fb == false and math.abs(wb - 232.14) < 0.01 and math.abs(flb - 207.41) < 0.01
        local fc, wc, flc = P.FlyDecision(2500, 900, 900, 60, 7)
        r.c = fc == true and math.abs(wc - 446.43) < 0.01 and math.abs(flc - 396.43) < 0.01
        -- in TravelSteps (zwei Flugmeister auf einer Linie, Ziel dahinter)
        local A = { name = "LPTestFP-A", n = 0, w = 500 }
        local B = { name = "LPTestFP-B", n = 0, w = 2300 }
        LP.db.taxi = { a = A, b = B }
        LP.char.taxiKnown = { a = true, b = true }
        Geo.TaxiPoint = function(_, tx) if tx then return 1413, 50, 50, 1, tx.n, tx.w end end
        -- B: Reittier 14, Start (0, 0), Flugmeister (0, 500) und (0, 2300) = 1800 yd Flug (Annahme), Ziel (424, 2565,2):
        -- Luftlinie 2600, vom Flugmeister 500 -> genau Fall B oben -> laufen
        LP.Calib.FlightSecs = function() return nil end
        local stB = P:TravelSteps({ inst = 1, n = 424.0, w = 2565.2 }, 1, 0, 0)
        r.geoB = math.abs(Geo:Dist(0, 0, 424.0, 2565.2) - 2600) < 0.5 and math.abs(Geo:Dist(0, 2300, 424.0, 2565.2) - 500) < 0.5
        r.tsB = #stB == 0 and P.lastTravel and P.lastTravel.took == false
        -- C: zu Fuss, Luftlinie 2500 (Flugmeister je 900), Flug gemessen 60 s -> Flug
        LP.char.mountYps = nil
        A.w, B.w = 900, 2200
        LP.Calib.FlightSecs = function() return 60 end
        local stC = P:TravelSteps({ inst = 1, n = 0, w = 2500 + 0 }, 1, 0, 0)
        -- Ziel 2500, Start 0: zum Flugmeister 900, vom Flugmeister 300 – andere Zahlen: laufen 446,4 · fliegen 1200×1,25/7 + 15 + 60 = 289,3
        r.tsC = #stC == 2 and stC[1].t == "GOTO" and stC[2].t == "FLY" and P.lastTravel.took == true and P.lastTravel.fsrc == "gemessen"
        r.lines = table.concat(LP.Laufweg.Lines({ v = 1, since = "x", z = {}, rev = 0, replans = 0, idle = 0, lvl = {} }), "\n"):find("REISE letzter Flugvergleich: Laufen 446 s · Fliegen 289 s (Flugzeit gemessen) -> Flug", 1, true) ~= nil
        return true
    end)
    LP.char, LP.db.taxi, Geo.TaxiPoint, LP.Calib.FlightSecs, P.lastTravel = saved.char, saved.taxi, saved.tp, saved.fs, saved.last
    if not ok then error(err, 0) end
    local good = r.foot and r.m1 and r.m2 and r.m3 and r.ann and r.mes and r.b and r.c and r.geoB and r.tsB and r.tsC and r.lines
    return good and true or false, ("zu Fuss 7 %s · Reittier 11,2 %s · unplausibel abgelehnt %s · 14 %s · Flugzeit Annahme %s / gemessen %s · B Reittier: laufen %s · C zu Fuss: Flug %s · Planung B ohne Flug %s · Planung C Flugmeister+Flug %s · Protokollzeile %s")
        :format(S(r.foot), S(r.m1), S(r.m2), S(r.m3), S(r.ann), S(r.mes), S(r.b), S(r.c), S(r.tsB), S(r.tsC), S(r.lines)),
        "true ×11 (dazu Geometrie Fall B geprüft)"
end
-- 3.12.50 ST-2: Strassen des eigenen Kontinents (im Spiel: echte Zonen über C_Map.GetMapInfoAtPosition)
IMPL.T312 = function()
    local G, Geo, N = LP.Graph, LP.Geo, LP.Nav
    if not (G.LoadRoads and G.RoadText and Geo.ZoneAt) then return false, "Strassen fehlen", "vorhanden" end
    if not G.RoadsAktiv() then return NA, "Strassennetz seit 3.12.88 entfernt (EULA) – Wegnetz aus gelaufenen Wegen" end
    if not (C_Map and C_Map.GetMapInfoAtPosition) then return NA, "C_Map.GetMapInfoAtPosition fehlt – Zonen der Strassen unbekannt" end
    local R, welche = G.RoadData()
    local inst = Geo:Player()
    local k = R and R.karten and inst ~= nil and R.karten[inst]
    if not k then return NA, "keine Strassen für diesen Kontinent (" .. tostring(inst) .. ")" end
    local st = G.roadStat and G.roadStat[inst]
    if not st then return false, "nicht geladen", "geladen" end
    if not st.fertig then return NA, "wird noch geladen" end
    local saved = 0
    for _, e in pairs(LP.db.graph.edges or {}) do if e[3] == "road" then saved = saved + 1 end end
    -- Weg entlang der längsten Strasse dieses Kontinents (3. bis drittletzter Punkt)
    local best, bl
    for _, line in ipairs(k.e) do
        local l = 0
        for j = 2, #line do l = l + Geo:Dist(k.p[2 * line[j - 1] - 1], k.p[2 * line[j - 1]], k.p[2 * line[j] - 1], k.p[2 * line[j]]) end
        if #line >= 8 and (not bl or l > bl) then best, bl = line, l end
    end
    local road, len = 0, 0
    if best then
        local a, b = best[3], best[#best - 2]
        local an, aw, bn, bw = k.p[2 * a - 1], k.p[2 * a], k.p[2 * b - 1], k.p[2 * b]
        local za, zb = Geo:ZoneAt(inst, an, aw), Geo:ZoneAt(inst, bn, bw)
        local p = za and zb and G:Path(inst, an, aw, za, inst, bn, bw, zb)
        if p then for i = 2, #p do
            local d = Geo:Dist(p[i - 1][2], p[i - 1][3], p[i][2], p[i][3])
            len = len + d
            if p[i].via == "road" then road = road + d end
        end end
    end
    local share = len > 0 and road / len or 0
    local ok = st.kanten > 0 and st.ohneZone * 10 < st.knoten and saved == 0 and share >= 0.5
    return ok, ("%s · gespeichert %d · Weg auf der längsten Strasse: %d yd, davon Strasse %d %%"):format(G.RoadText(), saved,
        math.floor(len + 0.5), math.floor(share * 100 + 0.5)), "Kanten > 0 · ohne Zone < 10 % · gespeichert 0 · Strasse ≥ 50 %"
end
-- 3.12.51 LW-1: Umweg-Faktor und Reihenfolge. Ziel A 500 yd in einer Zone mit Umweg 1,8 (= 900 yd Weg), Ziel B 700 yd in
-- einer Zone mit Umweg 1,0 (= 700 yd Weg): mit Wegkosten zuerst B, mit reiner Luftlinie (vorher) zuerst A.
IMPL.T313 = function()
    local G, P = LP.Graph, LP.Planner
    if not (G.Detour and G.DetourOf and P.WayFactor and P.OPT) then return false, "LW-1 fehlt", "vorhanden" end
    local saved = { det = G.detour, opt = P.OPT.wayCost }
    local r = {}
    local ok, err = pcall(function()
        r.med = G.DetourOf({ 1.1, 1.3, 1.2, 2.5, 1.0 }) == 1.2
        r.even = math.abs(G.DetourOf({ 1.1, 1.3, 1.2, 1.4, 1.0, 1.5 }) - 1.25) < 1e-9
        r.cap = G.DetourOf({ 3, 3, 3, 3, 3 }) == G.DETOUR_MAX and G.DetourOf({ 0.9, 0.9, 0.9, 0.9, 0.9 }) == G.DETOUR_MIN
        r.few = G.DetourOf({ 1.2, 1.3 }) == nil
        G.detour = { [99001] = { f = 1.8, n = 12 }, [99002] = { f = 1.0, n = 12 } }
        local f0, n0 = G:Detour(nil)
        r.def = f0 == G.DETOUR_DEFAULT and n0 == 0
        r.zone = G:Detour(99001) == 1.8 and P.WayFactor(99002) == 1.0
        local A = { t = "COMPLETE", id = 990001, key = "T313A", inst = 1, n = 500, w = 0, map = 99001, value = 1 }
        local B = { t = "COMPLETE", id = 990002, key = "T313B", inst = 1, n = -700, w = 0, map = 99002, value = 1 }
        P.OPT.wayCost = true
        local o1 = P:Order({ A, B }, 1, 0, 0)
        P.OPT.wayCost = false
        local o2 = P:Order({ A, B }, 1, 0, 0)
        r.first1, r.first2 = o1[1] and o1[1].key, o2[1] and o2[1].key
        r.off = P.WayFactor(99001) == 1
        return true
    end)
    G.detour, P.OPT.wayCost = saved.det, saved.opt
    if not ok then error(err, 0) end
    local good = r.med and r.even and r.cap and r.few and r.def and r.zone and r.first1 == "T313B" and r.first2 == "T313A" and r.off
    return good and true or false, ("Median %s (gerade Anzahl %s) · Grenzen %s · zu wenig Paare %s · ohne Zone Annahme %s · je Zone %s · mit Wegkosten zuerst %s · Luftlinie (vorher) zuerst %s · Schalter aus = 1 %s")
        :format(S(r.med), S(r.even), S(r.cap), S(r.few), S(r.def), S(r.zone), tostring(r.first1), tostring(r.first2), S(r.off)),
        "true ×6 · T313B · T313A · true"
end
-- 3.12.54 NAV-1a: eigene Kartennamen/Spielerort/Dienste nur über die eigenen Tabellen von LevelPilot ersetzt (immer zurück)
IMPL.T314 = function()
    local C, Geo, Q, P, G = LP.Comfort, LP.Geo, LP.QuestDB, LP.Planner, LP.Graph
    if not (C.Navi and C.ZoneByName and Q.NearestService) then return false, "Navi fehlt", "vorhanden" end
    local saved = { mn = Geo.MapName, zn = LP.Names and LP.Names.Zone, rep = P.Replan, prio = P.priority, reply = LP.Reply,
                    find = C.Find, sv = Q.ServiceNPCs, pl = Geo.Player, tw = Geo.ToWorld, det = G.detour, wc = P.OPT.wayCost,
                    plan = C.PlanNavi }
    local NAMES = { [1413] = "Brachland", [1412] = "Mulgore", [1454] = "Orgrimmar" }
    local r, replies, found = {}, {}, {}
    local ok, err = pcall(function()
        Geo.MapName = function(_, m) return NAMES[m] or tostring(m) end
        if LP.Names then LP.Names.Zone = function() return nil end end
        P.Replan = function() end
        C.PlanNavi = function() return false end         -- 3.12.94: kein Reiseplan zu den Testzielen (geprüft wird das Ziel)
        LP.Reply = function(_, m) replies[#replies + 1] = m end
        r.z1 = C.ZoneByName("Brachland") == 1413 and C.ZoneByName("  BRACHLAND ") == 1413
        r.z2 = C.ZoneByName("mul") == 1412 and C.ZoneByName("xyz") == nil and C.ZoneByName("") == nil
        P.priority = nil
        local kind, map = C:Navi("45 60 brachland")
        r.nav = kind == "weg" and map == 1413 and P.priority and P.priority.key == "WAY:1413:45.0:60.0"
        r.off = C:Navi("aus") == "aus" and P.priority == nil
        local n0 = #replies
        r.off2 = C:Navi("off") == "aus" and #replies == n0 + 1
        C:Navi("120 5")
        r.bad = P.priority == nil
        C:Navi("45 60 nirgendwo")
        r.nozone = P.priority == nil and tostring(replies[#replies]):find("nirgendwo", 1, true) ~= nil
        C.Find = function(_, k) found[#found + 1] = k end
        C:Navi("repair") C:Navi("Reparatur") C:Navi("mailbox") C:Navi("gasthaus")
        r.words = table.concat(found, ",")
        -- nächster Dienst nach Wegkosten: A 500 yd in Zone mit Umweg 1,8, B 700 yd in Zone mit Umweg 1,0
        Geo.Player = function() return 1, 0, 0, 1413 end
        Geo.ToWorld = function(_, m, x, y) return 1, x, y end
        Q.ServiceNPCs = function() return { vendor = { { name = "A", map = 99001, x = 500, y = 0 }, { name = "B", map = 99002, x = -700, y = 0 } } } end
        G.detour = { [99001] = { f = 1.8, n = 12 }, [99002] = { f = 1.0, n = 12 } }
        P.OPT.wayCost = true
        local v1, d1 = Q:NearestService("vendor")
        P.OPT.wayCost = false
        local v2 = Q:NearestService("vendor")
        r.svc = v1 and v1.name == "B" and d1 == 700 and v2 and v2.name == "A"
        return true
    end)
    Geo.MapName, P.Replan, P.priority, LP.Reply, C.Find = saved.mn, saved.rep, saved.prio, saved.reply, saved.find
    if LP.Names then LP.Names.Zone = saved.zn end
    Q.ServiceNPCs, Geo.Player, Geo.ToWorld, G.detour, P.OPT.wayCost = saved.sv, saved.pl, saved.tw, saved.det, saved.wc
    C.PlanNavi = saved.plan
    if not ok then error(err, 0) end
    local good = r.z1 and r.z2 and r.nav and r.off and r.off2 and r.bad and r.nozone and r.words == "repair,repair,mailbox,inn" and r.svc
    return good and true or false, ("Zone genau %s · Anfang/unbekannt %s · navi 45 60 brachland %s · aus %s · aus ohne Ziel %s · ungültig %s · Zone fehlt %s · Dienstwörter „%s“ · nächster Händler nach Wegkosten %s")
        :format(S(r.z1), S(r.z2), S(r.nav), S(r.off), S(r.off2), S(r.bad), S(r.nozone), tostring(r.words), S(r.svc)),
        "true ×7 · repair,repair,mailbox,inn · true"
end
-- 3.12.55 LW-5 E2: eigenes Paket im Test (nie LevelPilotData), Spielversion über GoldSentinelGame.SetTestFlavor (WithFlavor)
IMPL.T315 = function()
    local Geo, Q = LP.Geo, LP.QuestDB
    if not (Geo.FromData and Geo.ToData and Q.EraUnconvert and LP.CaveForeverMaps) then return false, "LW-5 E2 fehlt", "vorhanden" end
    local t = LP.CaveForeverMaps[1412]
    local fx, fy = 44.2, 76.1                                  -- Forever-Kartenpunkt in Mulgore
    local ex, ey = (fx - t[2]) / t[1], (fy - t[4]) / t[3]       -- erwartet in Classic-Grenzen
    local function fake()
        return { N = { [1] = { s = { { 1412, fx, fy, 50, 50 }, { 1413, 1, 2 } } }, [10666] = { s = { { 1420, 52.8, 54.2 } } } },
                 O = { [2] = { s = { { 1433, 10, 10 } } } }, Q = { [5] = { ob = { e = { "x", { { 1453, 10, 20 } } } } } },
                 D = { [9] = { e = { { 1423, 30, 40 } } } }, MB = { { 1433, 5, 6 }, { 1411, 5, 6 } } }
    end
    local r = {}
    WithFlavor("forever", function()
        local x, y = Geo:FromData(1412, fx, fy)
        r.fv = x == fx and y == fy and Geo.EraFrame() == false
        local d = fake()
        r.fvPack = Q.EraUnconvert(d) == 0 and d.N[1].s[1][2] == fx and d.N[10666].s[1][2] == 52.8
    end)
    WithFlavor("era", function()
        local x, y = Geo:FromData(1412, fx, fy)
        r.era = math.abs(x - ex) < 1e-9 and math.abs(y - ey) < 1e-9 and Geo.EraFrame() == true
        local bx, by = Geo:ToData(1412, x, y)
        r.round = math.abs(bx - fx) < 1e-9 and math.abs(by - fy) < 1e-9
        local ox, oy = Geo:FromData(1413, 33.3, 44.4)
        r.other = ox == 33.3 and oy == 44.4
        local d = fake()
        local n = Q.EraUnconvert(d)
        r.n = n
        r.pack = math.abs(d.N[1].s[1][2] - ex) < 1e-9 and d.N[1].s[2][2] == 1 and d.MB[2][2] == 5
            and math.abs(d.D[9].e[1][2] - (30 - LP.CaveForeverMaps[1423][2]) / LP.CaveForeverMaps[1423][1]) < 1e-9
        r.npc = d.N[10666].s[1][2] == 43.1 and d.N[10666].s[1][3] == 54.7
        r.again = Q.EraUnconvert(d) == 0
    end)
    local good = r.fv and r.fvPack and r.era and r.round and r.other and r.n == 6 and r.pack and r.npc and r.again
    return good and true or false, ("Forever unverändert %s (Paket %s) · Era Mulgore %.2f/%.2f -> %.2f/%.2f %s · hin und zurück %s · andere Zone %s · Paket: %s Punkte zurückgerechnet, Werte %s · Gordo auf Questie %s · zweimal = nichts %s")
        :format(S(r.fv), S(r.fvPack), fx, fy, ex, ey, S(r.era), S(r.round), S(r.other), S(r.n), S(r.pack), S(r.npc), S(r.again)),
        "true (true) · true · true · true · 6 (NPC 2, Objekt 1, Quest 1, Dungeon 1, Briefkasten 1), true · true · true"
end
-- 3.12.56 LW-5 E3: Wahl des Bereichs (reine Rechnung mit eigenen Tabellen) und Kalibrierung im gewählten Bereich
IMPL.T316 = function()
    if not (LP.ChooseAcc and LP.Acc and LP.Calib and LP.Calib.KillXPRatio) then return false, "LW-5 E3 fehlt", "vorhanden" end
    local r = {}
    local root = { graph = { nodes = { 1 } }, qdb = { 9 } }
    local a, k = LP.ChooseAcc(root, false)
    r.fv = a == root and k == "forever" and root.era == nil
    local e, k2 = LP.ChooseAcc(root, true)
    r.era = e == root.era and k2 == "era" and type(e) == "table" and e.graph == nil and root.graph.nodes[1] == 1
    e.graph = { nodes = { 2 } }
    local e2 = LP.ChooseAcc(root, true)
    r.keep = e2 == e and e2.graph.nodes[1] == 2 and root.graph.nodes[1] == 1
    -- Kalibrierung: liest im festgelegten Bereich (LP.accRoot), nie in einer anderen Tabelle
    local saved = LP.accRoot
    local ok, err = pcall(function()
        LP.accRoot = { calib = { killxp = { [7] = { n = 99, sum = 148.5 } } } }
        local v = LP.Calib:KillXPRatio(7)
        r.calib = v == 1.5
        LP.accRoot = { calib = {} }
        r.calib2 = LP.Calib:KillXPRatio(7) == nil
        -- Sprache und echte Flugpunkte ebenso im Bereich (Era-Befund der Offline-Routine 3.12.56: Sprache aus der Grundtabelle)
        local tx = { ["1:2"] = { 1 } }
        LP.accRoot = { language = (LP:Language() == "fr") and "es" or "fr", taxi = tx }
        r.lang = LP:Language() == LP.accRoot.language
        r.taxi = (LP.Virtual.active and true) or LP.Virtual:RealTaxi() == tx
    end)
    LP.accRoot = saved
    if not ok then error(err, 0) end
    -- ersetzte Grundtabelle (nur Offline-Tests tun das): Bereich der neuen Tabelle, nie die alte
    local savedBase, savedAcc2 = LP.accBase, LP.accRoot
    LP.accBase, LP.accRoot = {}, { stale = true }
    local okB, accB = pcall(LP.Acc)
    LP.accBase, LP.accRoot = savedBase, savedAcc2
    r.base = okB and accB ~= nil and not accB.stale and accB == (LP.ChooseAcc(LevelPilotDB, LP.accKind == "era"))
    r.now = LP.Acc() == (LP.accRoot or LevelPilotDB) and (LP.accKind == "era") == LP.IsEraClient()
    local good = r.fv and r.era and r.keep and r.calib and r.calib2 and r.lang and r.taxi and r.base and r.now
    return good and true or false, ("Forever = Grundtabelle %s · Era = eigener Bereich %s · Era-Daten bleiben, Forever unberührt %s · Kalibrierung im Bereich %s / leer %s · Sprache %s · Flugpunkte %s · ersetzte Grundtabelle %s · jetzt %s (%s)")
        :format(S(r.fv), S(r.era), S(r.keep), S(r.calib), S(r.calib2), S(r.lang), S(r.taxi), S(r.base), S(r.now), tostring(LP.accKind)),
        "true ×9"
end
IMPL.T317 = function()
    local Ce, QDB = LP.Center, LP.QuestDB
    if not (Ce and Ce.ForeverSwitchUseful and Ce.DataHelp and QDB and QDB.IsNewQuest) then return false, "LW-5 E4 fehlt", "vorhanden" end
    local r, savedSet = {}, LP.db.forever
    local ok, err = pcall(function()
        LP.db.forever = true
        WithFlavor("forever", function()
            r.swF = Ce.ForeverSwitchUseful()
            local t = Ce.DataHelp()
            r.helpF = t:find("Forever", 1, true) ~= nil
            r.newF = QDB.IsNewQuest(nil) == (QDB.pack and true or false) and QDB.IsNewQuest({}) == false
        end)
        WithFlavor("era", function()
            r.swE = Ce.ForeverSwitchUseful() == false
            local t = Ce.DataHelp()
            r.helpE = t:find("Forever", 1, true) == nil and #t > 100
            r.newE = QDB.IsNewQuest(nil) == false
        end)
        WithFlavor("tbc", function() r.swT = Ce.ForeverSwitchUseful() == false end)
    end)
    LP.db.forever = savedSet
    if not ok then error(err, 0) end
    local good = r.swF and r.swE and r.swT and r.helpF and r.helpE and r.newF and r.newE
    return good and true or false, ("Schalter Forever %s / Era aus %s / TBC aus %s · Hilfe Forever %s / Era ohne Forever %s · NEU Forever %s / Era nie %s")
        :format(S(r.swF), S(r.swE), S(r.swT), S(r.helpF), S(r.helpE), S(r.newF), S(r.newE)), "true ×7"
end
IMPL.T318 = function()
    local P = LP.Planner
    if not (P and P.TravelPlan and P.PlanText and P.PlanPath) then return false, "NAV-2 fehlt", "vorhanden" end
    local G, Geo, API = LP.Graph, LP.Geo, LP.API
    local o = { path = G.Path, tp = Geo.TaxiPoint, tw = Geo.ToWorld, hr = API.HearthReady, fs = P.FlightSecs,
                known = LP.char.taxiKnown, bind = LP.char.bind, yps = LP.char.mountYps, useH = LP.db.useHearth, taxi = LP.db.taxi }
    local route
    local r = {}
    local function near(a, b) return a and b and math.abs(a - b) < 0.05 end
    local ok, err = pcall(function()
        G.Path = function(_, sI, sn, sw, sZ, gI, gn, gw, gZ)
            if route then return route, "graph" end
            return { { sI, sn, sw, sZ }, { gI, gn, gw, gZ, via = "g" } }, "graph"
        end
        LP.char.taxiKnown, LP.char.mountYps, LP.db.useHearth = {}, nil, false
        local goal = { inst = 1, n = 6000, w = 0, map = 1411 }
        -- 1) Laufen 700 yd · Schiff 300 s · Laufen 350 yd (7 yd/s zu Fuss)
        route = { { 1, 0, 0, 1411 }, { 1, 700, 0, 1411, via = "g" }, { 0, 0, 0, 1429, via = "boat", secs = 300, name = "Test" },
                  { 0, 0, 350, 1429, via = "g" } }
        local p1 = P:TravelPlan(1, 0, 0, 1411, { inst = 0, n = 0, w = 350, map = 1429 })
        local l = p1 and p1.legs or {}
        r.boat = #l == 3 and l[1].k == "walk" and near(l[1].secs, 100) and l[2].k == "boat" and l[2].secs == 300
                 and l[3].k == "walk" and near(l[3].secs, 50) and near(p1.total, 450)
        local txt = P.PlanText(p1) or ""
        r.text = txt:find("7:30", 1, true) ~= nil and txt:find("5:00", 1, true) ~= nil
        route = nil
        -- 2) Flug: Flugmeister je 100 yd von Start und Ziel, Flugzeit 120 s -> 100/7 + 15 + 120 + 100/7 statt 6000/7
        local A, B = { name = "FA", i = 1, n = 100, w = 0 }, { name = "FB", i = 1, n = 5900, w = 0 }
        Geo.TaxiPoint = function(_, tx) if type(tx) == "table" and tx.i then return 1411, 0, 0, tx.i, tx.n, tx.w end end
        P.FlightSecs = function() return 120, "Test" end
        LP.char.taxiKnown, LP.db.taxi = { FA = true, FB = true }, { FA = A, FB = B }
        local p2 = P:TravelPlan(1, 0, 0, 1411, goal)
        l = p2 and p2.legs or {}
        r.fly = #l == 3 and l[1].k == "walk" and l[2].k == "fly" and l[2].to == "FB" and near(l[2].secs, 135)
                and near(p2.total, 200 / 7 + 135)
        LP.char.taxiKnown = {}
        -- 3) Ruhestein: Bindeort 1000 yd vor dem Ziel, bereit -> 10 s + 1000/7 statt 6000/7; nicht bereit -> laufen
        LP.db.useHearth, LP.char.bind = true, { map = 1411, x = 50, y = 50, name = "Gasthaus Test" }
        Geo.ToWorld = function(_, map, x, y) if map == 1411 and x == 50 then return 1, 5000, 0 end return o.tw(Geo, map, x, y) end
        API.HearthReady = function() return true end
        local p3 = P:TravelPlan(1, 0, 0, 1411, goal)
        l = p3 and p3.legs or {}
        r.hearth = p3 and p3.hearth and l[1].k == "hearth" and l[1].secs == 10 and near(p3.total, 10 + 1000 / 7) or false
        API.HearthReady = function() return false end
        local p4 = P:TravelPlan(1, 0, 0, 1411, goal)
        r.noHearth = p4 and not p4.hearth and #p4.legs == 1 and near(p4.total, 6000 / 7) or false
    end)
    G.Path, Geo.TaxiPoint, Geo.ToWorld, API.HearthReady, P.FlightSecs = o.path, o.tp, o.tw, o.hr, o.fs
    LP.char.taxiKnown, LP.char.bind, LP.char.mountYps, LP.db.useHearth, LP.db.taxi = o.known, o.bind, o.yps, o.useH, o.taxi
    if not ok then error(err, 0) end
    local good = r.boat and r.text and r.fly and r.hearth and r.noHearth
    return good and true or false, ("Laufen/Schiff/Laufen 450 s %s · Text %s · Flug %s · Ruhestein %s · nicht bereit -> laufen %s")
        :format(S(r.boat), S(r.text), S(r.fly), S(r.hearth), S(r.noHearth)), "true ×5"
end
IMPL.T319 = function()
    local C, Geo, P = LP.Comfort, LP.Geo, LP.Planner
    if not (C.NameCandidates and C.ShowHits and C.ServiceKind and C.NaviTo) then return false, "NAV-1b fehlt", "vorhanden" end
    local saved = { mn = Geo.MapName, rep = P.Replan, prio = P.priority, reply = LP.Reply, pl = Geo.Player, tw = Geo.ToWorld,
                    hits = C.naviHits, dg = LP.Dungeons, plan = C.PlanNavi }
    local r, replies = {}, {}
    local fac = LP:PlayerFaction() == "Horde" and "H" or "A"
    local foe = fac == "H" and "A" or "H"
    local data = { N = {
        [900001] = { n = "Testgeber Alpha", f = fac, s = { { 99001, 10, 0 }, { 99001, 2, 0 } } },
        [900002] = { n = "Testgeber Beta", f = "AH", s = { { 99001, 30, 0 } } },
        [900003] = { n = "Testgeber Feind", f = foe, s = { { 99001, 1, 0 } } },
        [900004] = { n = "Wildschwein Gamma", s = { { 99001, 50, 0 } } },
    } }
    local ok, err = pcall(function()
        Geo.MapName = function(_, m) return "Testzone" .. tostring(m) end
        Geo.Player = function() return 1, 0, 0, 99001 end
        Geo.ToWorld = function(_, m, x, y) if m == 99001 then return 1, x * 100, y * 100 end return saved.tw(Geo, m, x, y) end
        P.Replan = function() end
        -- 3.12.94 (Ingametest 3.12.93: T319 302 ms in einem Bild): kein Reiseplan zu den Testzielen (geprüft wird die Auswahl)
        C.PlanNavi = function() return false end
        LP.Reply = function(_, m) replies[#replies + 1] = tostring(m) end
        LP.Dungeons = { [99] = { name = "Testgrotte", en = "Test Cave", e = { { 99001, 70, 0 } } } }
        r.words = C.ServiceKind("händler") == "vendor" and C.ServiceKind("trainer") == "trainer" and C.ServiceKind("gasthaus") == "inn"
                  and C.ServiceKind("thrall") == nil
        local c = C.NameCandidates("testgeber", data)
        local keys = {}
        for _, x in ipairs(c) do keys[x.key] = x end
        r.npc = keys.N900001 and keys.N900002 and not keys.N900003 and keys.N900001.x == 2 and true or false
        r.mob = #C.NameCandidates("gamma", data) == 1
        local dg = C.NameCandidates("test cave", data)
        r.dungeon = #dg == 1 and dg[1].kind == "dungeon" and dg[1].x == 70
        r.short = #C.NameCandidates("te", data) == 0
        -- Liste mit 2 Treffern, Wahl per Nummer; ein Treffer -> direkt
        P.priority = nil
        C.ShowHits("testgeber", { keys.N900001, keys.N900002 }, 2)
        r.list = C.naviHits and #C.naviHits == 2 and replies[#replies]:find("2) ", 1, true) ~= nil and P.priority == nil
        r.pick = C:Navi("2") == "treffer" and P.priority and P.priority.key == "PRIO:navi:N900002" and true or false
        r.off = C:Navi("aus") == "aus" and P.priority == nil
        C.ShowHits("gamma", { C.NameCandidates("gamma", data)[1] }, 1)
        r.single = P.priority and P.priority.key == "PRIO:navi:N900004" and C.naviHits == nil and true or false
        C.ShowHits("nix", {}, 0)
        r.none = replies[#replies]:find("nix", 1, true) ~= nil
    end)
    Geo.MapName, P.Replan, P.priority, LP.Reply, Geo.Player, Geo.ToWorld = saved.mn, saved.rep, saved.prio, saved.reply, saved.pl, saved.tw
    C.naviHits, LP.Dungeons, C.PlanNavi = saved.hits, saved.dg, saved.plan
    if not ok then error(err, 0) end
    local good = r.words and r.npc and r.mob and r.dungeon and r.short and r.list and r.pick and r.off and r.single and r.none
    return good and true or false, ("Dienstwörter %s · NPC nächster Fundort, ohne feindliche %s · Gegner %s · Dungeon %s · zu kurz %s · Liste %s · Nummer %s · aus %s · ein Treffer direkt %s · nichts gefunden %s")
        :format(S(r.words), S(r.npc), S(r.mob), S(r.dungeon), S(r.short), S(r.list), S(r.pick), S(r.off), S(r.single), S(r.none)), "true ×10"
end
IMPL.T320 = function()
    local C, Geo, P = LP.Comfort, LP.Geo, LP.Planner
    if not C.OnUserWaypoint then return false, "NAV-1c fehlt", "vorhanden" end
    -- C_Map ist eine Blizzard-Tabelle: nie ändern. Die Markierung kommt über eine eigene Ersatz-Umgebung (WithEnv).
    local wp
    local fakeMap = setmetatable({ GetUserWaypoint = function() return wp end }, { __index = C_Map })
    local saved = { rep = P.Replan, prio = P.priority, reply = LP.Reply, set = LP.db.naviMapPin, mn = Geo.MapName, plan = C.PlanNavi }
    local r, replies = {}, {}
    -- 3.12.93 (Ingametest 3.12.91: T320 87 ms; Nachbau Allianz: 231 ms in einem Bild): Reiseplan je Markierung hier nicht nötig
    local ok, err = pcall(function()
        P.Replan = function() end
        C.PlanNavi = function() return false end
        LP.Reply = function(_, m) replies[#replies + 1] = tostring(m) end
        Geo.MapName = function(_, m) return "Testzone" .. tostring(m) end
        LP.db.naviMapPin = true
        P.priority = nil
        local function fire() return WithEnv({ C.OnUserWaypoint }, { C_Map = fakeMap }, function() return C.OnUserWaypoint() end) end
        wp = { uiMapID = 1411, position = { x = 0.452, y = 0.607 } }
        local k1 = fire()
        r.set = k1 == "pin" and P.priority and P.priority.key == "PRIO:navi:PIN:1411:45.2:60.7" and true or false
        local n = #replies
        r.once = fire() == nil and #replies == n
        wp = { uiMapID = 1411, position = { GetXY = function() return 0.5, 0.25 end } }
        r.xy = fire() == "pin" and P.priority and P.priority.key == "PRIO:navi:PIN:1411:50.0:25.0" and true or false
        wp = nil
        r.clear = fire() == "aus" and P.priority == nil
        P.priority = { key = "WAY:1:1:1", t = "GOTO" }
        r.keepOther = fire() == nil and P.priority and P.priority.key == "WAY:1:1:1" and true or false
        LP.db.naviMapPin = false
        wp = { uiMapID = 1411, position = { x = 0.1, y = 0.1 } }
        r.off = fire() == nil and P.priority and P.priority.key == "WAY:1:1:1" and true or false
    end)
    P.Replan, P.priority, LP.Reply, LP.db.naviMapPin, Geo.MapName = saved.rep, saved.prio, saved.reply, saved.set, saved.mn
    C.PlanNavi = saved.plan
    if not ok then error(err, 0) end
    local good = r.set and r.once and r.xy and r.clear and r.keepOther and r.off
    return good and true or false, ("Markierung -> Ziel %s · doppelt nur einmal %s · Vector2D %s · entfernt -> Ende %s · anderes Ziel bleibt %s · Schalter aus %s · Ereignis im Client %s")
        :format(S(r.set), S(r.once), S(r.xy), S(r.clear), S(r.keepOther), S(r.off), S(C.pinEvent)), "true ×6"
end
IMPL.T321 = function()
    local P = LP.Planner
    if not (P.ExactOrder and P.ValidOrder) then return false, "LW-2a fehlt", "vorhanden" end
    local savedWC = P.OPT.wayCost
    local r = {}
    local function T(t, id, x) return { t = t, id = id, inst = 1, n = x, w = 0 } end
    local function keys(list) local o = {} for i, t in ipairs(list) do o[i] = t.t:sub(1, 1) .. (t.id or "") .. "@" .. t.n end return table.concat(o, " ") end
    local ok, err = pcall(function()
        P.OPT.wayCost = false                                   -- reine Luftlinie: Zahlen im Test genau
        -- 1) Linie: Start 0, erster Schritt 50, dann 400/100/300/200 -> 100/200/300/400 (Kette ab Schritt 1: 950 -> 350)
        local l1 = { T("COMPLETE", 1, 50), T("COMPLETE", 2, 400), T("COMPLETE", 3, 100), T("COMPLETE", 4, 300), T("COMPLETE", 5, 200) }
        local changed, old, new = P:ExactOrder(l1, 1, 0, 0, 10)
        r.line = changed and keys(l1) == "C1@50 C3@100 C5@200 C4@300 C2@400" and math.abs(old - 950) < 0.01 and math.abs(new - 350) < 0.01
        -- 2) Abgabe erst nach Annahme derselben Quest (Abgabe liegt näher)
        local l2 = { T("COMPLETE", 1, 50), T("ACCEPT", 7, 400), T("TURNIN", 7, 100), T("COMPLETE", 2, 300), T("COMPLETE", 3, 200) }
        P:ExactOrder(l2, 1, 0, 0, 10)
        local posA, posT
        for i, t in ipairs(l2) do if t.id == 7 then if t.t == "ACCEPT" then posA = i else posT = i end end end
        r.prec = posA and posT and posA < posT and P.ValidOrder(l2, 10) and l2[1].id == 1
        -- 3) Questlog voll (frei 1, erster Schritt nimmt an): Annahme 8 erst nach der Abgabe 9, obwohl sie näher liegt.
        --    Gültige Eingabe T9 A8 C2 C3 = 750; frei wäre A8 C2 T9 C3 = 350 (ungültig); bestes gültiges = 650
        local l3 = { T("ACCEPT", 1, 50), T("TURNIN", 9, 300), T("ACCEPT", 8, 100), T("COMPLETE", 2, 200), T("COMPLETE", 3, 400) }
        local _, o3, n3 = P:ExactOrder(l3, 1, 0, 0, 1)
        local pA, pT
        for i, t in ipairs(l3) do if t.id == 8 then pA = i elseif t.id == 9 then pT = i end end
        r.log = pA and pT and pT < pA and P.ValidOrder(l3, 1) and o3 and math.abs(o3 - 750) < 0.01 and math.abs(n3 - 650) < 0.01 and true or false
        -- 4) schon optimal -> unverändert; 5) weniger als 4 Schritte -> nichts
        local l4 = { T("COMPLETE", 1, 50), T("COMPLETE", 2, 100), T("COMPLETE", 3, 200), T("COMPLETE", 4, 300) }
        r.keep = P:ExactOrder(l4, 1, 0, 0, 10) == false and keys(l4) == "C1@50 C2@100 C3@200 C4@300"
        r.small = P:ExactOrder({ T("COMPLETE", 1, 50), T("COMPLETE", 2, 10) }, 1, 0, 0, 10) == false
        -- 6) Schritt danach zählt mit: 9 Schritte im Fenster + 1 dahinter bei 1000 -> der letzte im Fenster liegt nahe 1000
        local l6 = { T("COMPLETE", 1, 50) }
        for i, x in ipairs({ 900, 150, 800, 250, 700, 350, 600, 450 }) do l6[#l6 + 1] = T("COMPLETE", 10 + i, x) end
        l6[#l6 + 1] = T("COMPLETE", 99, 1000)
        P:ExactOrder(l6, 1, 0, 0, 10)
        r.tail = l6[9].n == 900 and l6[10].id == 99 and l6[2].n == 150
    end)
    P.OPT.wayCost = savedWC
    if not ok then error(err, 0) end
    local good = r.line and r.prec and r.log and r.keep and r.small and r.tail
    return good and true or false, ("Linie 950 -> 350 %s · annehmen vor abgeben %s · Questlog voll 750 -> 650 %s · optimal bleibt %s · < 4 nichts %s · Schritt danach zählt %s")
        :format(S(r.line), S(r.prec), S(r.log), S(r.keep), S(r.small), S(r.tail)), "true ×6"
end

IMPL.T322 = function()
    local P, G, Dg, Geo, E = LP.Planner, LP.Graph, LP.Danger, LP.Geo, LP.Engine
    if not (P.PlanPath and P.PlanText and Dg and E and E.CheckSteps) then return false, "NAV-3 fehlt", "vorhanden" end
    local o = { path = G.Path, pd = Dg.PathDanger, lim = Dg.Limit, pl = Geo.Player, rep = P.Replan, reply = LP.Reply,
                steps = P.steps, prio = P.priority, known = LP.char.taxiKnown }
    local r, replies, worst = {}, {}, 0
    local ok, err = pcall(function()
        G.Path = function(_, sI, sn, sw, sZ, gI, gn, gw, gZ) return { { sI, sn, sw, sZ }, { gI, gn, gw, gZ, via = "g" } }, "graph" end
        Dg.Limit = function() return 10 end
        Dg.PathDanger = function() return worst, 1, 100, 0 end
        LP.char.taxiKnown = {}
        local goal = { inst = 1, n = 700, w = 0, map = 1411 }
        worst = 12
        local p1 = P.PlanPath(1, 0, 0, 1411, goal)
        r.danger = p1 and p1.danger and p1.danger.level == 12 and (P.PlanText(p1) or ""):find("12", 1, true) ~= nil and true or false
        worst = 9
        local p2 = P.PlanPath(1, 0, 0, 1411, goal)
        r.safe = p2 and p2.danger == nil and not (P.PlanText(p2) or ""):find("|cffff5555", 1, true) and true or false
        -- Ankunft: Navi-Ziel (Planner.priority) erreicht -> Meldung; anderes Gehe-zu-Ziel -> still
        P.Replan = function() end
        LP.Reply = function(_, m) replies[#replies + 1] = tostring(m) end
        Geo.Player = function() return 1, 500, 500, 1411 end
        local prio = { t = "GOTO", inst = 1, n = 505, w = 500, key = "WAY:T322" }
        P.priority, P.steps = prio, { prio }
        E:CheckSteps()
        r.arrive = LP.char.doneKeys["WAY:T322"] == true and #replies == 1
        LP.char.doneKeys["WAY:T322"] = nil
        local other = { t = "GOTO", inst = 1, n = 505, w = 500, key = "FPGO:T322" }
        P.priority, P.steps = nil, { other }
        E:CheckSteps()
        r.quiet = LP.char.doneKeys["FPGO:T322"] == true and #replies == 1
        LP.char.doneKeys["FPGO:T322"] = nil
    end)
    G.Path, Dg.PathDanger, Dg.Limit, Geo.Player, P.Replan, LP.Reply = o.path, o.pd, o.lim, o.pl, o.rep, o.reply
    P.steps, P.priority, LP.char.taxiKnown = o.steps, o.prio, o.known
    LP.char.doneKeys["WAY:T322"], LP.char.doneKeys["FPGO:T322"] = nil, nil
    if not ok then error(err, 0) end
    local good = r.danger and r.safe and r.arrive and r.quiet
    return good and true or false, ("Gefahr Stufe 12 im Plan %s · ohne Gefahr kein Hinweis %s · Ankunft Navi-Ziel mit Meldung %s · anderes Ziel still %s")
        :format(S(r.danger), S(r.safe), S(r.arrive), S(r.quiet)), "true ×4"
end
IMPL.T323 = function()
    local C, P, Geo, API = LP.Comfort, LP.Planner, LP.Geo, _G.LevelPilotAPI
    if not (C.PlanTarget and C.OnPlanChanged and API and (tonumber(API.version) or 0) >= 2 and API.StopNavigation and API.TravelTime) then
        return false, "NAV-4 fehlt", "vorhanden"
    end
    local o = { pl = Geo.Player, tw = Geo.ToWorld, steps = P.steps, prio = P.priority, rep = P.Replan, tp = P.TravelPlan,
                cache = C.planCache, sync = LP.Jobs.sync, pn = C.PlanNavi }
    local r = {}
    local ok, err = pcall(function()
        Geo.Player = function() return 1, 0, 0, 1411 end
        Geo.ToWorld = function(_, m, x, y) return 1, x * 100, y * 100 end
        P.Replan = function() end
        LP.Jobs.sync = true
        P.TravelPlan = function(_, _, _, _, _, g) return { legs = { { k = "walk", dist = g.n, secs = g.n / 7 } }, total = g.n / 7 } end
        -- Routenschritt weit weg -> Ziel des Reiseplans; nah -> keins; Navi-Ziel geht vor
        local far = { t = "TURNIN", inst = 1, n = 2000, w = 0, key = "TURNIN:9001" }
        local near = { t = "TURNIN", inst = 1, n = 300, w = 0, key = "TURNIN:9002" }
        P.priority = nil
        P.steps = { far }
        r.far = C.PlanTarget() == far
        P.steps = { near }
        r.near = C.PlanTarget() == nil
        local prio = { t = "GOTO", inst = 1, n = 50, w = 0, key = "WAY:T323" }
        P.priority = prio
        r.prio = C.PlanTarget() == prio
        P.priority = nil
        -- gleicher Schritt nach Neuplanung: Plan aus dem Zwischenspeicher, ohne neu zu rechnen
        P.steps = { far }
        C.PlanNavi(far)
        r.plan = far.navText ~= nil and C.planCache and C.planCache.key == "TURNIN:9001" and true or false
        local again = { t = "TURNIN", inst = 1, n = 2000, w = 0, key = "TURNIN:9001" }
        P.steps = { again }
        local calls = 0
        C.PlanNavi = function(...) calls = calls + 1 return o.pn(...) end
        C.OnPlanChanged()
        r.cache = again.navText == far.navText and calls == 0
        C.PlanNavi = o.pn
        -- Schnittstelle v2
        P.priority = { t = "GOTO", map = 1411, x = 10, y = 20, inst = 1, n = 1000, w = 2000, text = "Eigenes Ziel", key = "WAY:1411:10.0:20.0" }
        r.stopOwn = API.StopNavigation() == false and P.priority ~= nil
        local nav = API.GetNavigation()
        r.get = nav and nav.map == 1411 and nav.x == 10 and nav.title == "Eigenes Ziel" and nav ~= P.priority and true or false
        P.priority = { t = "GOTO", map = 1411, x = 10, y = 20, inst = 1, n = 1000, w = 2000, text = "API", key = "PRIO:API:1411:10.0:20.0" }
        r.stopApi = API.StopNavigation() == true and P.priority == nil
        r.badKind = API.NavigateToNearest("schmied") == false
        local got
        r.travel = API.TravelTime(1411, 7, 0, function(secs, txt) got = { secs, txt } end) == true
                   and got and math.abs(got[1] - 100) < 0.01 and type(got[2]) == "string" and true or false
        r.badArgs = API.TravelTime(1411, 120, 0, function() end) == false and API.TravelTime(1411, 5, 5) == false
    end)
    Geo.Player, Geo.ToWorld, P.steps, P.priority, P.Replan, P.TravelPlan = o.pl, o.tw, o.steps, o.prio, o.rep, o.tp
    C.planCache, LP.Jobs.sync, C.PlanNavi = o.cache, o.sync, o.pn
    if not ok then error(err, 0) end
    local good = r.far and r.near and r.prio and r.plan and r.cache and r.stopOwn and r.get and r.stopApi and r.badKind and r.travel and r.badArgs
    return good and true or false, ("Route weit %s / nah keins %s / Navi zuerst %s · Plan %s · gleicher Schritt aus Speicher %s · Stop eigenes Ziel nein %s · Abfrage Kopie %s · Stop API-Ziel %s · falsche Art %s · Reisezeit 100 s %s · falsche Angaben %s")
        :format(S(r.far), S(r.near), S(r.prio), S(r.plan), S(r.cache), S(r.stopOwn), S(r.get), S(r.stopApi), S(r.badKind), S(r.travel), S(r.badArgs)), "true ×11"
end
IMPL.T324 = function()
    local Pi, Geo = LP.Pins, LP.Geo
    if not (Pi and Pi.NextKillSpot) then return false, "LW-7a fehlt", "vorhanden" end
    local saved = { areas = Pi.areas, tw = Geo.ToWorld, arrow = LP.db.objArrow }
    local r = {}
    local function A(key, x) return { p = { 99001, x, 0 }, kill = true, key = "K:T324:" .. key } end
    local ok, err = pcall(function()
        Geo.ToWorld = function(_, m, x, y) if m == 99001 then return 1, x, y end return saved.tw(Geo, m, x, y) end
        -- Fundorte auf einer Linie: 0, 100, 200, 300 (Yards)
        Pi.areas = { A("a", 0), A("b", 100), A("c", 200), A("d", 300) }
        local t1 = Pi:NextKillSpot(1, 5, 0)                -- bei a: a besucht -> nächster b
        r.first = t1 and t1.entry.key == "K:T324:b" and t1.round == true and true or false
        local t2 = Pi:NextKillSpot(1, 100, 0)              -- bei b -> c
        local t3 = Pi:NextKillSpot(1, 200, 0)              -- bei c -> d
        r.order = t2 and t3 and t2.entry.key == "K:T324:c" and t3.entry.key == "K:T324:d" and true or false
        local t4 = Pi:NextKillSpot(1, 300, 0)              -- bei d: alle besucht -> Runde von vorn, nächster ist c
        r.loop = t4 and t4.entry.key == "K:T324:c" and true or false
        r.far = Pi:NextKillSpot(1, 900, 0) == nil          -- weiter als 250 yd vom nächsten Fundort
        Pi.areas = { A("x", 0), A("y", 100) }
        r.few = Pi:NextKillSpot(1, 50, 0) == nil           -- nur 2 Fundorte
        Pi.areas = { A("m", 0), A("n", 100), { p = { 99001, 50, 0 }, key = "K:T324:area" } }
        r.onlyKill = Pi:NextKillSpot(1, 50, 0) == nil      -- Gebiete ohne Töte-Ziel zählen nicht
    end)
    Pi.areas, Geo.ToWorld, LP.db.objArrow = saved.areas, saved.tw, saved.arrow
    if not ok then error(err, 0) end
    local good = r.first and r.order and r.loop and r.far and r.few and r.onlyKill
    return good and true or false, ("erster %s · Reihenfolge %s · Runde von vorn %s · zu weit %s · < 3 %s · nur Töte-Ziele %s")
        :format(S(r.first), S(r.order), S(r.loop), S(r.far), S(r.few), S(r.onlyKill)), "true ×6"
end
IMPL.T325 = function()
    local M = LP.Pruefliste
    if not (M and M.Points and M.ERA_POINTS) then return false, "E5 fehlt", "vorhanden" end
    local o = { era = LP.IsEraClient, kind = LP.accKind, acc = LP.Acc, max = LP.API.MaxQuests, sw = LP.Center.ForeverSwitchUseful,
                hadEra = type(LevelPilotDB) == "table" and LevelPilotDB.era }
    local r = {}
    local function auto(id)
        for _, p in ipairs(M.ERA_POINTS) do if p.id == id then return p.auto() end end
    end
    local ok, err = pcall(function()
        -- Liste je Spielversion, Era-Punkte vollständig und eindeutig
        LP.IsEraClient = function() return true end
        local e = M.Points()
        local ids, full = {}, 0
        for _, p in ipairs(e) do
            if p.id and p.title and p.since and p.todo and p.expect and not ids[p.id] then full = full + 1 end
            ids[p.id] = true
        end
        r.era = e == M.ERA_POINTS and #e == 6 and full == 6
        LP.IsEraClient = function() return false end
        r.fv = M.Points() == M.POINTS
        -- Selbstprüfungen: ausserhalb von Era nichts (nil)
        r.offEra = auto("E5-1") == nil and auto("E5-2") == nil and auto("E5-3") == nil
        LP.IsEraClient = function() return true end
        r.load = auto("E5-1") == true
        local eraTab = o.hadEra or {}
        if not o.hadEra then LevelPilotDB.era = eraTab end
        LP.accKind, LP.Acc = "era", function() return eraTab end
        local a2 = auto("E5-2")
        LP.accKind = "forever"
        local a2b = auto("E5-2")
        r.data = a2 == true and a2b == false
        LP.API.MaxQuests, LP.Center.ForeverSwitchUseful = function() return 20 end, function() return false end
        local a3 = auto("E5-3")
        LP.API.MaxQuests = function() return 40 end
        r.log = a3 == true and auto("E5-3") == false
    end)
    LP.IsEraClient, LP.accKind, LP.Acc, LP.API.MaxQuests, LP.Center.ForeverSwitchUseful = o.era, o.kind, o.acc, o.max, o.sw
    if not o.hadEra and type(LevelPilotDB) == "table" then LevelPilotDB.era = nil end
    if not ok then error(err, 0) end
    local good = r.era and r.fv and r.offEra and r.load and r.data and r.log
    return good and true or false, ("Era-Liste 6 vollständig %s · Forever bisherige %s · ausserhalb Era still %s · lädt %s · Bereich era / falsch %s · Questlog 20 / 40 %s")
        :format(S(r.era), S(r.fv), S(r.offEra), S(r.load), S(r.data), S(r.log)), "true ×6"
end
IMPL.T326 = function()
    local P = LP.Planner
    if not (P.TravelFactor and P.OPT.timeNormal ~= nil) then return false, "LW-2b fehlt", "vorhanden" end
    local o = { wc = P.OPT.wayCost, tn = P.OPT.timeNormal, sp = P.IsSpeed, tw = LP.Geo.ToWorld }
    local r = {}
    local function near(a, b) return math.abs(a - b) < 0.001 end
    local ok, err = pcall(function()
        P.OPT.wayCost = false                                -- Luftlinie: genaue Zahlen
        r.f1 = near(P.TravelFactor(300, { inst = 1, n = 700, w = 0 }, 1, 0, 0, 1), 300 / 350)       -- 700 yd = 100 s
        r.f2 = near(P.TravelFactor(30, { inst = 1, n = 7000, w = 0 }, 1, 0, 0, 1), 0.35)            -- sehr weit: Untergrenze
        r.f3 = near(P.TravelFactor(300, { inst = 2, n = 0, w = 0 }, 1, 0, 0, 1), 300 / 750)         -- anderer Kontinent 900 s
        r.f4 = near(P.TravelFactor(300, { inst = 1, n = 700, w = 0 }, 1, 0, 0, 2), 300 / 325)       -- 2 Questgeber teilen
        -- im Normalmodus angewendet, nichts ausgelassen; Schalter aus = unverändert
        P.IsSpeed = function() return false end
        LP.Geo.ToWorld = function(_, m, x, y) return 1, x, y end
        local function run()
            local q = { id = 99901, starts = {}, objectives = {} }
            local acc = { { q = q, t = { t = "ACCEPT", id = 99901, value = 1, inst = 1, n = 7000, w = 0, map = 1411 } } }
            local tasks = {}
            P:SpeedFilter(acc, tasks, 10, 1, 0, 0)
            return tasks
        end
        P.OPT.timeNormal = true
        local t1 = run()
        r.on = #t1 == 1 and t1[1].value < 1 and t1[1].value >= 0.35
        P.OPT.timeNormal = false
        local t2 = run()
        r.off = #t2 == 1 and t2[1].value == 1
    end)
    P.OPT.wayCost, P.OPT.timeNormal, P.IsSpeed, LP.Geo.ToWorld = o.wc, o.tn, o.sp, o.tw
    if not ok then error(err, 0) end
    local good = r.f1 and r.f2 and r.f3 and r.f4 and r.on and r.off
    return good and true or false, ("700 yd/300 s = 0,857 %s · Untergrenze 0,35 %s · anderer Kontinent 0,4 %s · 2 Questgeber %s · Normalmodus angewendet, nicht ausgelassen %s · Schalter aus unverändert %s")
        :format(S(r.f1), S(r.f2), S(r.f3), S(r.f4), S(r.on), S(r.off)), "true ×6"
end
IMPL.T327 = function()
    local P, G = LP.Planner, LP.Graph
    if not (P.DeathSkip and P.Graves and P.DEATH) then return false, "LW-7 (d) fehlt", "vorhanden" end
    local o = { path = G.Path, graves = P.Graves, sp = P.IsSpeed, lvl = LP.PlayerLevel, ds = LP.db.deathSkip, uh = LP.db.useHearth,
                known = LP.char.taxiKnown, yps = LP.char.mountYps }
    local r = {}
    local list
    local ok, err = pcall(function()
        G.Path = function(_, sI, sn, sw, sZ, gI, gn, gw, gZ) return { { sI, sn, sw, sZ }, { gI, gn, gw, gZ, via = "g" } }, "graph" end
        P.Graves = function() return list end
        P.IsSpeed = function() return true end
        LP.PlayerLevel = function() return 6 end
        LP.db.deathSkip, LP.db.useHearth, LP.char.taxiKnown, LP.char.mountYps = true, false, {}, nil
        local goal = { inst = 1, n = 6000, w = 0, map = 1411 }
        local function plan() return P:TravelPlan(1, 0, 0, 1411, goal) end
        -- Friedhof 500 yd vor dem Ziel: 6000/7 − (90 + 10 + 500/7) = 685,7 s
        list = { { inst = 1, n = 5500, w = 0, map = 1411, x = 50, y = 50 } }
        local p1 = plan()
        r.hint = p1 and p1.deathSkip and math.abs(p1.deathSkip.gain - (6000 / 7 - 100 - 500 / 7)) < 0.01 and true or false
        r.text = p1 and (P.PlanText(p1) or ""):find("~11 ", 1, true) ~= nil and true or false
        r.walk = p1 and #p1.legs == 1 and p1.legs[1].k == "walk" and true or false       -- nur Hinweis, Plan bleibt
        -- Gewinn unter 3 min: Friedhof 4500 yd vor dem Ziel -> 857 − (100 + 643) = 114 s
        list = { { inst = 1, n = 1500, w = 0, map = 1411, x = 50, y = 50 } }
        r.small = plan().deathSkip == nil
        list = { { inst = 1, n = 5500, w = 0, map = 1411, x = 50, y = 50 } }
        LP.PlayerLevel = function() return 11 end
        r.level = plan().deathSkip == nil
        LP.PlayerLevel = function() return 6 end
        P.IsSpeed = function() return false end
        r.speed = plan().deathSkip == nil
        P.IsSpeed = function() return true end
        LP.db.deathSkip = false
        r.off = plan().deathSkip == nil
        LP.db.deathSkip = true
        list = { { inst = 0, n = 5500, w = 0, map = 1429, x = 50, y = 50 } }
        r.cont = plan().deathSkip == nil
        list = nil
        r.nodata = plan().deathSkip == nil
    end)
    G.Path, P.Graves, P.IsSpeed, LP.PlayerLevel = o.path, o.graves, o.sp, o.lvl
    LP.db.deathSkip, LP.db.useHearth, LP.char.taxiKnown, LP.char.mountYps = o.ds, o.uh, o.known, o.yps
    if not ok then error(err, 0) end
    local good = r.hint and r.text and r.walk and r.small and r.level and r.speed and r.off and r.cont and r.nodata
    return good and true or false, ("Hinweis 686 s %s · Text ~11 min %s · Plan bleibt Laufen %s · unter 3 min nichts %s · Stufe 11 nichts %s · ohne Speedrun nichts %s · Schalter aus nichts %s · anderer Kontinent nichts %s · ohne Daten nichts %s")
        :format(S(r.hint), S(r.text), S(r.walk), S(r.small), S(r.level), S(r.speed), S(r.off), S(r.cont), S(r.nodata)), "true ×9"
end
IMPL.T328 = function()
    local R, P = LP.Recorder, LP.Planner
    if not (R and R.RecordTaxiCost and R.FlightCost) then return false, "Flugpreise fehlen", "vorhanden" end
    local saved = LP.db.flightCost
    local r = {}
    local nodes
    local api = {
        NumTaxiNodes = function() return #nodes end,
        TaxiNodeName = function(i) return nodes[i][1] end,
        TaxiNodeGetType = function(i) return nodes[i][2] end,
        TaxiNodeCost = function(i) return nodes[i][3] end,
    }
    local ok, err = pcall(function()
        LP.db.flightCost = nil
        nodes = { { "T328 Start", "CURRENT", 0 }, { "T328 Ziel A", "REACHABLE", 120 }, { "T328 Ziel B", "REACHABLE", 2450 },
                  { "T328 fern", "DISTANT", 999 } }
        r.n = R:RecordTaxiCost(api)
        r.read = R.FlightCost("T328 Start", "T328 Ziel A") == 120 and R.FlightCost("T328 Start", "T328 Ziel B") == 2450
                 and R.FlightCost("T328 Start", "T328 fern") == nil and R.FlightCost("T328 Ziel A", "T328 Start") == nil
        nodes[2][3] = 100
        R:RecordTaxiCost(api)
        r.update = R.FlightCost("T328 Start", "T328 Ziel A") == 100
        nodes = { { "T328 Ziel A", "REACHABLE", 1 } }                 -- ohne aktuellen Ort: nichts
        r.nocur = R:RecordTaxiCost(api) == 0
        r.noapi = R:RecordTaxiCost({}) == 0
        local plan = { legs = { { k = "fly", secs = 130, from = "T328 Start", to = "T328 Ziel B" } }, total = 130 }
        local t1 = P.PlanText(plan) or ""
        plan.legs[1].to = "T328 unbekannt"
        local t2 = P.PlanText(plan) or ""
        r.text = t1:find(LP.Session.Money(2450), 1, true) ~= nil and t2:find(L["Preis unbekannt"], 1, true) ~= nil
    end)
    LP.db.flightCost = saved
    if not ok then error(err, 0) end
    local good = r.n == 2 and r.read and r.update and r.nocur and r.noapi and r.text
    return good and true or false, ("mitgeschrieben %s · gelesen (nur ab Start, fern nicht) %s · neuer Preis %s · ohne aktuellen Ort nichts %s · ohne Schnittstelle nichts %s · Reiseplan Preis / unbekannt %s")
        :format(S(r.n), S(r.read), S(r.update), S(r.nocur), S(r.noapi), S(r.text)), "2 · true ×5"
end
IMPL.T329 = function()
    local V = LP.Virtual
    if not (V and V.BestRows) then return false, "Messlatte fehlt", "vorhanden" end
    local levelAt = { [5] = { t = 0 }, [6] = { t = 600 }, [7] = { t = 1500 }, [8] = { t = 2700 } }
    local best = { [5] = { t = 500, who = "Name" }, [6] = { t = 1000, who = "Name" }, [7] = { t = 30 }, [9] = { t = 999 } }
    local rows, sum = V.BestRows(levelAt, best)
    local r = {}
    r.rows = #rows == 2 and rows[1].level == 5 and rows[1].best == 500 and rows[1].sim == 600 and rows[2].level == 6 and rows[2].sim == 900
    r.sum = sum and sum.best == 1500 and sum.sim == 1500 and true or false
    local none = V.BestRows(levelAt, {})
    r.none = #none == 0
    local named = false
    for _, x in ipairs(rows) do for _, v in pairs(x) do if v == "Name" then named = true end end end
    r.noName = not named
    local good = r.rows and r.sum and r.none and r.noName
    return good and true or false, ("Stufen mit beiden Werten (7: unter 60 s, 8/9: ohne Paar) %s · Summen %s · ohne Bestzeiten leer %s · ohne Namen %s")
        :format(S(r.rows), S(r.sum), S(r.none), S(r.noName)), "true ×4"
end
IMPL.T330 = function()
    local C, Geo, LW, P = LP.Comfort, LP.Geo, LP.Laufweg, LP.Planner
    if not (C.Fold and C.Norm and LW and LW.Lines) then return false, "Faltung fehlt", "vorhanden" end
    local o = { mn = Geo.MapName, zn = LP.Names and LP.Names.Zone, tw = Geo.ToWorld, pl = Geo.Player, gy = P.GroundYps, lt = P.lastTravel,
                dg = LP.Dungeons }
    local r = {}
    local ok, err = pcall(function()
        local F = C.Fold
        r.fold = F("Ödland") == "ödland" and F("ÄÖÜ ÀÉÎÑ") == "äöü àéîñ" and F("ТИРИСФАЛЬ") == "тирисфаль" and F("Ёж") == "ёж"
                 and F("Ѐ") == "ѐ" and F("×ß") == "×ß" and F("ödland") == "ödland" and F("다르나서스") == "다르나서스"
        Geo.MapName = function(_, m) return ({ [1418] = "Ödland", [1423] = "Östliche Pestländer", [1420] = "Тирисфальские леса" })[m] or tostring(m) end
        if LP.Names then LP.Names.Zone = function() return nil end end
        r.zone = C.ZoneByName("ödland") == 1418 and C.ZoneByName("ÖDLAND") == 1418 and C.ZoneByName("östliche") == 1423
                 and C.ZoneByName("тирисфальские") == 1420 and C.ZoneByName("ТИРИСФАЛЬСКИЕ ЛЕСА") == 1420
        Geo.Player = function() return 1, 0, 0, 99001 end
        Geo.ToWorld = function(_, m, x, y) return 1, x, y end
        LP.Dungeons = { [98] = { name = "Üldaman-Test", en = "Uldaman Test", e = { { 99001, 5, 0 } } } }
        local data = { N = { [900101] = { n = "Öberst Ärger", s = { { 99001, 10, 0 } } }, [900102] = { n = "Грок Тестов", s = { { 99001, 20, 0 } } } } }
        local function has(list, key) for _, c in ipairs(list) do if c.key == key then return true end end return false end
        r.npc = has(C.NameCandidates("öberst", data), "N900101") and has(C.NameCandidates("ÖBERST ä", data), "N900101")
                and has(C.NameCandidates("грок", data), "N900102") and has(C.NameCandidates("üldaman", data), "D98")
        -- Laufweg-Zeile: Quelle des Tempos und Komma (vorher "(nil)" und Punkt)
        P.GroundYps = function() return 8.53, "Reittier gemessen" end
        P.lastTravel = nil
        local lines = LW.Lines({ since = "x", z = {}, replans = 0, rev = 0, idle = 0, lvl = {} })
        local rl = ""
        for _, l in ipairs(lines) do if tostring(l):find("^REISE") then rl = l end end
        r.src = rl:find("(Reittier gemessen)", 1, true) ~= nil
        r.comma = rl:find("8,5 yd/s", 1, true) ~= nil and not rl:find("8.5 yd/s", 1, true)
    end)
    Geo.MapName, Geo.ToWorld, Geo.Player, P.GroundYps, P.lastTravel, LP.Dungeons = o.mn, o.tw, o.pl, o.gy, o.lt, o.dg
    if LP.Names then LP.Names.Zone = o.zn end
    if not ok then error(err, 0) end
    local good = r.fold and r.zone and r.npc and r.src and r.comma
    return good and true or false, ("Faltung %s · Zone ödland/ÖDLAND/östliche/тирисфальские %s · NPC/Dungeon %s · Laufweg Quelle %s · Komma %s")
        :format(S(r.fold), S(r.zone), S(r.npc), S(r.src), S(r.comma)), "true ×5"
end
IMPL.T331 = function()
    local P, C, API = LP.Planner, LP.Comfort, _G.LevelPilotAPI
    local o = { rep = P.Replan, prio = P.priority, pn = C.PlanNavi }
    local r = {}
    local function near() return { { t = "TURNIN", nearTurnin = true, key = "TURNIN:1" }, { t = "TURNIN", nearTurnin = true, key = "TURNIN:2" },
                                   { t = "ACCEPT", key = "ACCEPT:3" } } end
    local ok, err = pcall(function()
        local s1 = near()
        P.InsertPriority(s1, { t = "GOTO", key = "WAY:T331", explicit = true })
        r.explicit = s1[1].key == "WAY:T331" and s1[2].key == "TURNIN:1"
        local s2 = near()
        P.InsertPriority(s2, { t = "GOTO", key = "PRIO:TRAIN:8" })
        r.advisor = s2[3].key == "PRIO:TRAIN:8" and s2[1].key == "TURNIN:1"
        -- jeder Weg des Spielers setzt "explicit": Comfort.Navigate (navi, weg, suche, Markierung) und die Schnittstelle
        P.Replan, C.PlanNavi = function() end, function() end
        P.priority = nil
        C.Navigate(1411, 50, 50, "T331", "WAY:1411:50.0:50.0")
        r.navi = P.priority and P.priority.explicit == true and true or false
        P.priority = nil
        r.api = API and API.NavigateTo(1411, 40, 40, "T331") == true and P.priority and P.priority.explicit == true and true or false
    end)
    P.Replan, P.priority, C.PlanNavi = o.rep, o.prio, o.pn
    if not ok then error(err, 0) end
    local good = r.explicit and r.advisor and r.navi and r.api
    return good and true or false, ("gewähltes Ziel oben %s · Assistent nach nahen Abgaben %s · Navi setzt es %s · Schnittstelle setzt es %s")
        :format(S(r.explicit), S(r.advisor), S(r.navi), S(r.api)), "true ×4"
end
IMPL.T332 = function()
    local P, N = LP.Planner, LP.Nav
    if not (P.InsertByDistance and N and N.Passed) then return false, "ERA-1 fehlt", "vorhanden" end
    local r = {}
    -- (a) Nordhain-Lage: Annahmen 18/40 yd, Erledigen 101 yd, weit 1400 yd; Binden 483 yd -> nach den nahen, vor dem weiten
    local function T(t, d) return { t = t, inst = 1, n = d, w = 0, key = t .. d } end
    local steps = { T("ACCEPT", 18), T("ACCEPT", 40), T("COMPLETE", 101), T("ACCEPT", 1400) }
    local pos = P.InsertByDistance(steps, T("BIND", 483), 0, 1, 0, 0)
    r.bind = pos == 4 and steps[4].t == "BIND" and steps[1].t == "ACCEPT" and steps[5].n == 1400
    -- Reise-Schritte vor der Route (base) bleiben vorn; alles näher -> ans Ende; anderer Kontinent zählt als weit
    local s2 = { { t = "FLY", key = "FLY:x" }, T("ACCEPT", 10), T("ACCEPT", 20) }
    r.base = P.InsertByDistance(s2, T("FP", 998), 1, 1, 0, 0) == 4 and s2[1].t == "FLY"
    local s3 = { T("ACCEPT", 10), { t = "ACCEPT", inst = 0, n = 5, w = 0, key = "other" } }
    r.cont = P.InsertByDistance(s3, T("BIND", 300), 0, 1, 0, 0) == 2
    -- (b) Wegpunkt hinter dem Spieler (−20,0) auf dem Weg nach (100,0): übersprungen; vor ihm (20,0): nicht; seitlich an einer
    -- Ecke (0,50) -> (100,50): nicht (Skalarprodukt 0)
    local function W(n, w) return { 1, n, w } end
    r.behind = N.Passed({ W(0, 0), W(-20, 0), W(100, 0) }, 2, 0, 0) == true
    r.ahead = N.Passed({ W(0, 0), W(20, 0), W(100, 0) }, 2, 0, 0) == false
    r.corner = N.Passed({ W(0, 0), W(0, 50), W(100, 50) }, 2, 0, 0) == false
    r.last = N.Passed({ W(0, 0), W(-20, 0) }, 2, 0, 0) == false
    -- 3.12.81: Wegpunkt 120 yd voraus, danach ein 1500-yd-Stück zurück -> NICHT überspringen (nur in der Nähe des Wegpunkts)
    r.far = N.Passed({ W(0, 0), W(120, 10), W(-1478, -700) }, 2, 0, 0) == false
    -- (b) Ursache: Gefahren-Zelle (100 yd) an der Ecke geschnitten. Strecke (0,213)->(213,0) schneidet Zelle (1,1) auf 13 yd;
    -- Messpunkte alle 50 yd (bis 3.12.70) trafen sie nicht -> Weg sprang zwischen "sicher" und "x25". Jetzt jede Zelle.
    local Dg = LP.Danger
    local cl = Dg and Dg.CellsOnLine
    if not cl then return false, "Gitter-Durchlauf fehlt", "vorhanden" end
    local cells = { [1 * 100000 + 1] = 5, [-1 * 100000 - 1] = 7 }
    r.cellCorner = cl(cells, 0, 213, 213, 0) == 5 and cl(cells, 213, 0, 0, 213) == 5
    r.cellMiss = cl(cells, 0, 190, 190, 0) == 0 and cl(cells, 0, 0, 0, 0) == 0
    r.cellNeg = cl(cells, -150, -30, -30, -150) == 7 and cl(cells, -50, -50, -50, -50) == 7 and cl(cells, -150, -150, -150, -150) == 0
    local good = r.bind and r.base and r.cont and r.behind and r.ahead and r.corner and r.last and r.far and r.cellCorner and r.cellMiss and r.cellNeg
    return good and true or false, ("Binden nach nahen Schritten %s · Reise-Schritte bleiben vorn %s · anderer Kontinent weit %s · Wegpunkt hinten übersprungen %s · vorn nicht %s · Ecke nicht %s · letzter nie %s · weit vor dem Wegpunkt nie %s · Gefahren-Zelle an der Ecke erkannt %s · daneben nicht %s · negative Koordinaten %s")
        :format(S(r.bind), S(r.base), S(r.cont), S(r.behind), S(r.ahead), S(r.corner), S(r.last), S(r.far), S(r.cellCorner), S(r.cellMiss), S(r.cellNeg)), "true ×11"
end
IMPL.T333 = function()
    local P = LP.Planner
    if not (P.StartFilter and P.InStartArea and P.InsertOnWay and P.StartAreas) then return false, "ERA-1 Startgebiet fehlt", "vorhanden" end
    local r = {}
    -- Startpunkt (0,0), Gasthaus (500,0): Startgebiet = näher am Start als am Gasthaus UND weniger als 500 yd vom Start
    local A = { inst = 1, n = 0, w = 0, innN = 500, innW = 0, r = 500, map = 1, races = { Human = true } }
    local B = { inst = 1, n = 5000, w = 0, innN = 5500, innW = 0, r = 500, map = 2, races = { Orc = true } }
    r.area = P.InStartArea(A, 1, 200, 0) and not P.InStartArea(A, 1, 300, 0) and not P.InStartArea(A, 1, -600, 0)
        and P.InStartArea(A, 1, -400, 100) and not P.InStartArea(A, 2, 0, 0)
    local function T(t, n, extra)
        local x = { t = t, inst = 1, n = n, w = 0, key = t .. n }
        for k, v in pairs(extra or {}) do x[k] = v end
        return x
    end
    local tasks = { T("ACCEPT", 30), T("COMPLETE", 150), T("TURNIN", 466), T("ACCEPT", 5100), T("ACCEPT", 900), { t = "NOTE", key = "x" } }
    local res
    local oldAreas = P.StartAreas
    Guard(function()
        P.StartAreas = function() return { A, B } end
        local out, rule = P:StartFilter(tasks, 3, 1, 0, 0, "Human")
        local keys = {}
        for _, t in ipairs(out) do keys[#keys + 1] = t.key end
        r.inside = rule == A and table.concat(keys, ",") == "ACCEPT30,COMPLETE150,x"
        -- Stufe 6: Regel aus, alles erlaubt (auch fremde Startgebiete)
        out, rule = P:StartFilter(tasks, 6, 1, 0, 0, "Human")
        r.level6 = rule == nil and #out == 6
        -- keine Aufgabe mehr im Startgebiet -> hinaus erlaubt
        out, rule = P:StartFilter({ T("TURNIN", 466), T("ACCEPT", 900) }, 3, 1, 0, 0, "Human")
        r.empty = rule == A and #out == 2
        -- blockierte Aufgabe im Startgebiet zählt nicht
        out = P:StartFilter({ T("ACCEPT", 40, { pathBlocked = true }), T("TURNIN", 466) }, 3, 1, 0, 0, "Human")
        r.blocked = #out == 2
        -- fremdes Startgebiet unter Stufe 6: Ork darf in B, Mensch nicht (Spieler ausserhalb jedes Startgebiets); ab 6 beide
        local o1 = P:StartFilter({ T("ACCEPT", 5100) }, 4, 1, 2000, 0, "Human")
        local o2 = P:StartFilter({ T("ACCEPT", 5100) }, 4, 1, 2000, 0, "Orc")
        local o3 = P:StartFilter({ T("ACCEPT", 5100) }, 6, 1, 2000, 0, "Human")
        r.foreign = #o1 == 0 and #o2 == 1 and #o3 == 1
        -- 3.12.73: Questgeber gleich am Weg (<= 150 yd vom Spieler bei (200,0)) knapp ausserhalb bleibt, anderes Ziel dort nicht
        local o4 = P:StartFilter({ T("ACCEPT", 300), T("COMPLETE", 320), T("COMPLETE", 150) }, 3, 1, 200, 0, "Human")
        local k4 = {}
        for _, t in ipairs(o4) do k4[#k4 + 1] = t.key end
        r.nearGiver = table.concat(k4, ",") == "ACCEPT300,COMPLETE150"
    end, function() P.StartAreas = oldAreas end)
    -- Binden auf dem Weg: Spieler (0,0), Schritte (100,0) und (300,0); Gasthaus (200,20) -> Umweg 3,96 yd -> zwischen beiden
    local steps = { T("ACCEPT", 100), T("ACCEPT", 300) }
    local bind = { t = "BIND", inst = 1, n = 200, w = 20, key = "BIND" }
    local pos, det = P.InsertOnWay(steps, bind, 0, 1, 0, 0, 60)
    r.onWay = pos == 2 and steps[2] == bind and det and det < 5
    local steps2 = { T("ACCEPT", 100), T("ACCEPT", 300) }
    local far = { t = "BIND", inst = 1, n = 200, w = 400, key = "BIND" }
    r.notOnWay = P.InsertOnWay(steps2, far, 0, 1, 0, 0, 60) == nil and #steps2 == 2
    local steps3 = { T("ACCEPT", 100) }
    local endB = { t = "BIND", inst = 1, n = 140, w = 0, key = "BIND" }
    r.atEnd = P.InsertOnWay(steps3, endB, 0, 1, 0, 0, 60) == 2
    -- erst annehmen, dann erledigen: TURNIN 10, COMPLETE 50, ACCEPT 80, COMPLETE 120, ACCEPT 200, ACCEPT 900 (draussen)
    local ord = { T("TURNIN", 10), T("COMPLETE", 50), T("ACCEPT", 80), T("COMPLETE", 120), T("ACCEPT", 200), T("ACCEPT", 900) }
    local mv = P.AcceptsFirst(ord, A)
    local ks = {}
    for _, t in ipairs(ord) do ks[#ks + 1] = t.key end
    r.acceptFirst = mv == 2 and table.concat(ks, ",") == "TURNIN10,ACCEPT80,ACCEPT200,COMPLETE50,COMPLETE120,ACCEPT900"
    local good = r.area and r.inside and r.level6 and r.empty and r.blocked and r.foreign and r.nearGiver and r.onWay and r.notOnWay and r.atEnd and r.acceptFirst
    return good and true or false, ("Startgebiet-Grenze %s · Stufe 3 nur drinnen %s · Stufe 6 frei %s · ohne Aufgabe drinnen hinaus %s · blockierte zählt nicht %s · fremdes Startgebiet %s · Questgeber am Weg %s · Binden auf dem Weg %s · nicht auf dem Weg kein Binden %s · am Ende %s · erst annehmen, dann erledigen %s")
        :format(S(r.area), S(r.inside), S(r.level6), S(r.empty), S(r.blocked), S(r.foreign), S(r.nearGiver), S(r.onWay), S(r.notOnWay), S(r.atEnd), S(r.acceptFirst)), "true ×11"
end
IMPL.T334 = function()
    -- 3.12.87 EULA-Austausch: Orte aus den Questdaten (Häufung der Questgeber), keine Gebiets-IDs aus den Spieldateien
    local O, P = LP.Orte, LP.Planner
    if not O then return false, "Orte fehlt", "vorhanden" end
    if not O.Available() then return NA, "ohne Questdaten" end
    local r = {}
    local Geo = LP.Geo
    if O.BuildNow then O.BuildNow() end
    r.noGameData = O.START == nil and (_G.LevelPilotData == nil or O.At ~= nil)
    -- je Fraktion zwei Orte (Questgeber der anderen Fraktion zählen nicht): Allianz Nordhain/Goldhain (Elwynn),
    -- Horde Tal der Prüfungen/Klingenhügel (Durotar)
    local function At(map, x, y) return O.At(map, Geo:FromData(map, x, y)) end
    local horde = UnitFactionGroup and UnitFactionGroup("player") == "Horde"
    local map = horde and 1411 or 1429
    local north = horde and At(1411, 43.3, 68.5) or At(1429, 48.9, 41.6)
    local gold = horde and At(1411, 52.0, 43.0) or At(1429, 43.8, 65.8)
    r.north = north ~= nil
    r.gold = gold ~= nil and gold ~= north
    r.edge = O.At(99999, 50, 50) == nil
    r.info = north ~= nil and O.Info(north) == map
    -- Startgebiet ohne Spieldaten: Mittellinie Startplatz–Gasthaus (Regel vor ORT-1)
    local areas = P:StartAreas()
    r.start = #areas > 0 and areas[1].ids == nil and areas[1].innN ~= nil
    local good = r.noGameData and r.north and r.gold and r.edge and r.info and r.start
    return good and true or false, ("keine Spieldaten %s · Startort ist ein Ort %s · Nachbarort anderer Ort %s · fremde Karte nil %s · Eltern = Karte %s · Startgebiet ohne Spieldaten %s")
        :format(S(r.noGameData), S(r.north), S(r.gold), S(r.edge), S(r.info), S(r.start)), "true ×6"
end
IMPL.T335 = function()
    local P = LP.Planner
    if not P.NearAcceptsFirst then return false, "NearAcceptsFirst fehlt", "vorhanden" end
    local r = {}
    local function T(t, n, w, extra)
        local x = { t = t, inst = 1, n = n, w = w or 0, key = t .. n .. ":" .. (w or 0) }
        for k, v in pairs(extra or {}) do x[k] = v end
        return x
    end
    local function Keys(steps) local k = {} for _, t in ipairs(steps) do k[#k + 1] = t.key end return table.concat(k, ",") end
    -- Abgabe 400 yd vorn, Annahme 120 yd hinten in der Liste -> Annahme zuerst
    local s1 = { T("TURNIN", 400), T("COMPLETE", 600), T("ACCEPT", 120) }
    r.r1 = P.NearAcceptsFirst(s1, {}, 1, 0, 0) == 1 and Keys(s1) == "ACCEPT120:0,TURNIN400:0,COMPLETE600:0"
    -- nahe Abgabe (50 yd) bleibt vorn, Binden (80 yd) nicht vor der Annahme
    local s2 = { T("TURNIN", 50), T("BIND", 80), T("ACCEPT", 140) }
    r.r4 = P.NearAcceptsFirst(s2, {}, 1, 0, 0) == 1 and Keys(s2) == "TURNIN50:0,ACCEPT140:0,BIND80:0"
    -- Annahme fehlt in der Route, steht aber in den Aufgaben -> geholt; weiter weg (200 yd) nicht; gesperrt nicht
    local s3 = { T("COMPLETE", 500) }
    local tasks = { T("ACCEPT", 100), T("ACCEPT", 200), T("ACCEPT", 30, 0, { pathBlocked = true }) }
    r.fetch = P.NearAcceptsFirst(s3, tasks, 1, 0, 0) == 1 and Keys(s3) == "ACCEPT100:0,COMPLETE500:0"
    -- Kette: vom Spieler (0,0) zum nächsten (40,0), dann (100,0), nicht (60,100) dazwischen
    local s4 = { T("COMPLETE", 900), T("ACCEPT", 100), T("ACCEPT", 60, 100), T("ACCEPT", 40) }
    P.NearAcceptsFirst(s4, {}, 1, 0, 0)
    r.chain = Keys(s4) == "ACCEPT40:0,ACCEPT100:0,ACCEPT60:100,COMPLETE900:0"
    -- vom Spieler gewähltes Ziel (explicit) wird nicht verschoben; nichts in der Nähe -> nichts
    local s5 = { T("ACCEPT", 20, 0, { explicit = true }), T("COMPLETE", 300) }
    r.keep = P.NearAcceptsFirst(s5, {}, 1, 0, 0) == 0 and Keys(s5) == "ACCEPT20:0,COMPLETE300:0"
    local good = r.r1 and r.r4 and r.fetch and r.chain and r.keep
    return good and true or false, ("Annahme vor weitem Ziel %s · vor Binden, nahe Abgabe bleibt vorn %s · aus den Aufgaben geholt %s · Kette %s · gewähltes Ziel bleibt %s")
        :format(S(r.r1), S(r.r4), S(r.fetch), S(r.chain), S(r.keep)), "true ×5"
end
IMPL.T336 = function()
    local P = LP.Planner
    if not P.QUEST_ABOVE then return false, "QUEST_ABOVE fehlt", "vorhanden" end
    -- erfundene Quest-IDs (negativ, nie in Daten/Questlog), ohne Volk/Klasse-Einschränkung
    local function Q(id, ql) return { id = id, level = ql, reqLevel = 1, starts = { { 1429, 50, 50 } }, objectives = {}, ends = {} } end
    local q12, q13 = Q(-990012, 12), Q(-990013, 13)
    local a12 = P:IsAvailable(q12, 10)
    if not a12 then return NA, "Testquest wird aus anderem Grund nicht angeboten" end
    local a13 = P:IsAvailable(q13, 10)
    local old = P.QUEST_ABOVE
    local a13b
    Guard(function() P.QUEST_ABOVE = 3 a13b = P:IsAvailable(q13, 10) end, function() P.QUEST_ABOVE = old end)
    local good = P.QUEST_ABOVE == 2 and a12 == true and a13 == false and a13b == true
    return good and true or false, ("Grenze %s · Stufe+2 angeboten %s · Stufe+3 nicht %s · Regel greift (mit +3 angeboten) %s")
        :format(S(P.QUEST_ABOVE), S(a12), S(a13 == false), S(a13b)), "2 · true ×3"
end
IMPL.T337 = function()
    local Gr, N = LP.Graph, LP.Nav
    if not (Gr.ShortcutStart and N and N.KeepOld and N.PathLength) then return false, "Abkürzung/KeepOld fehlt", "vorhanden" end
    local r = {}
    local function W(n, w, extra) local x = { 1, n, w, 1413 } for k, v in pairs(extra or {}) do x[k] = v end return x end
    -- eigene Gefahrenregel aus (nur LP-Tabelle, wird zurückgesetzt)
    local Dg = LP.Danger
    local oldRule = Dg and Dg.pathRule
    Guard(function()
        if Dg then Dg.pathRule = false end
        -- Haarnadel: Start (0,0) -> Knoten (0,33) -> zurück auf der Strasse (15,-19) -> (30,-33) -> weiter
        local p = { W(0, 0), W(0, 33), W(15, -19), W(30, -33), W(200, -60) }
        local out, cut = Gr.ShortcutStart(p, 60)
        r.hairpin = cut == 2 and #out == 3 and out[2][2] == 30 and out[2][3] == -33
        -- gerader Weg: nichts abzukürzen
        local q = { W(0, 0), W(30, 0), W(60, 0), W(90, 0) }
        local out2, cut2 = Gr.ShortcutStart(q, 60)
        r.straight = cut2 == 0 and #out2 == 4
        -- Punkt näher als 60 yd, aber erst nach > 240 yd Weg: nicht (zu weit, echte Schleife um ein Hindernis)
        local loop = { W(0, 0), W(0, 100), W(100, 100), W(100, 0), W(40, 0) }
        local _, cut3 = Gr.ShortcutStart(loop, 60)
        r.longLoop = cut3 == 0
        -- nie auf ein Tor selbst
        local g = { W(0, 0), W(0, 33), W(20, -10, { gw = true }), W(300, 0) }
        local _, cut4 = Gr.ShortcutStart(g, 60)
        r.gate = cut4 == 0
        -- 3.12.76: Haarnadel mitten im Weg (100,0) -> (100,55) -> (101,1) -> weiter: Stück fällt weg; Kurve ohne Rückkehr bleibt
        if Gr.RemoveLoops then
            local h = { W(0, 0), W(100, 0), W(100, 30), W(100, 55), W(101, 1), W(200, 0) }
            local o5, rm5 = Gr.RemoveLoops(h)
            r.loop = rm5 == 2 and #o5 == 4 and o5[3][2] == 101
            local k = { W(0, 0), W(100, 0), W(100, 100), W(0, 100) }
            local _, rm6 = Gr.RemoveLoops(k)
            r.loopKeep = rm6 == 0
        end
    end, function() if Dg then Dg.pathRule = oldRule end end)
    -- alten Weg behalten: Rest 500, neu 480 -> behalten; neu 460 -> nehmen (30 yd/10 % = 50 yd); ohne Werte -> nehmen
    r.keep = N.KeepOld(500, 480) == true and N.KeepOld(500, 460) == true and N.KeepOld(500, 449) == false
        and N.KeepOld(100, 75) == true and N.KeepOld(100, 69) == false and N.KeepOld(nil, 50) == false
    r.len = math.abs(N.PathLength({ W(0, 0), W(30, 0), W(30, 40) }) - 70) < 0.01
    local good = r.hairpin and r.straight and r.longLoop and r.gate and r.keep and r.len and r.loop and r.loopKeep
    return good and true or false, ("Haarnadel abgekürzt %s · gerader Weg bleibt %s · lange Schleife bleibt %s · nie auf ein Tor %s · alter Weg bleibt bis max(30 yd, 10 %%) %s · Weglänge %s · Haarnadel mitten im Weg entfernt %s · Kurve bleibt %s")
        :format(S(r.hairpin), S(r.straight), S(r.longLoop), S(r.gate), S(r.keep), S(r.len), S(r.loop), S(r.loopKeep)), "true ×8"
end
IMPL.T338 = function()
    local P = LP.Planner
    if not (P.HubOf and P.HUB_RADIUS) then return false, "HubOf fehlt", "vorhanden" end
    local r = {}
    local function T(t, n, extra)
        local x = { t = t, inst = 1, n = n, w = 0, map = 1, key = t .. n }
        for k, v in pairs(extra or {}) do x[k] = v end
        return x
    end
    local function Keys(steps) local k = {} for _, t in ipairs(steps) do k[#k + 1] = t.key end return table.concat(k, ",") end
    -- Ort A = n < 500, Ort B = n >= 500 (eigene Testfunktion statt Ortsdaten, wird zurückgesetzt)
    local oldHub = P.HubOf
    Guard(function()
        P.HubOf = function(map, inst, n) if not n then return nil end return n < 500 and 9 or 87 end
        -- Spieler bei 0 in Ort A; Annahme bei 300 (Ort A, > 150 yd) kommt vor das Ziel bei 700 (Ort B)
        local s1 = { T("COMPLETE", 700), T("ACCEPT", 300) }
        r.hub = P.NearAcceptsFirst(s1, {}, 1, 0, 0, nil, 1) == 1 and Keys(s1) == "ACCEPT300,COMPLETE700"
        -- Annahme bei 450 (Ort A, aber > 400 yd) nicht
        local s2 = { T("COMPLETE", 700), T("ACCEPT", 450) }
        r.radius = P.NearAcceptsFirst(s2, {}, 1, 0, 0, nil, 1) == 0
        -- Annahme bei 550 liegt in Ort B (anderer Ort) -> nicht
        local s3 = { T("COMPLETE", 700), T("ACCEPT", 550) }
        r.other = P.NearAcceptsFirst(s3, {}, 1, 0, 0, nil, 1) == 0
        -- ohne Karte des Spielers: alte Regel (nur 150 yd)
        local s4 = { T("COMPLETE", 700), T("ACCEPT", 300) }
        r.nomap = P.NearAcceptsFirst(s4, {}, 1, 0, 0) == 0
    end, function() P.HubOf = oldHub end)
    local good = r.hub and r.radius and r.other and r.nomap
    return good and true or false, ("Annahme im Ort vor Ziel ausserhalb %s · über 400 yd nicht %s · anderer Ort nicht %s · ohne Karte nur 150 yd %s")
        :format(S(r.hub), S(r.radius), S(r.other), S(r.nomap)), "true ×4"
end
IMPL.T339 = function()
    local P = LP.Planner
    if not (P.OnWayAccepts and P.ONWAY_DETOUR) then return false, "OnWayAccepts fehlt", "vorhanden" end
    local r = {}
    local function T(t, n, w, extra)
        local x = { t = t, inst = 1, n = n, w = w or 0, key = t .. n .. ":" .. (w or 0) }
        for k, v in pairs(extra or {}) do x[k] = v end
        return x
    end
    local function Keys(steps) local k = {} for _, t in ipairs(steps) do k[#k + 1] = t.key end return table.concat(k, ",") end
    -- Ziel 750 yd, Questgeber bei (760, 40): vor dem Ziel 54 yd Umweg, zwischen Ziel und 900 nur 37 yd -> trotzdem die früheste
    -- Stelle (unterwegs mitnehmen), nicht die mit dem kleinsten Umweg
    local s1 = { T("TURNIN", 750), T("COMPLETE", 900) }
    local n1 = P.OnWayAccepts(s1, { T("ACCEPT", 760, 40) }, 1, 0, 0)
    r.onway = n1 == 1 and Keys(s1) == "ACCEPT760:40,TURNIN750:0,COMPLETE900:0"
    -- schon in der Route, aber hinten: nach vorn
    local s2 = { T("TURNIN", 750), T("ACCEPT", 400, 20) }
    P.OnWayAccepts(s2, {}, 1, 0, 0)
    r.moved = Keys(s2) == "ACCEPT400:20,TURNIN750:0"
    -- 3.12.85: zwei hintere Annahmen am Weg – keine wird übersprungen (vorher rückte die Stelle beim Vorziehen weiter)
    local s5 = { T("TURNIN", 750), T("ACCEPT", 400, 0), T("ACCEPT", 300, 0) }
    P.OnWayAccepts(s5, {}, 1, 0, 0)
    r.both = Keys(s5) == "ACCEPT300:0,ACCEPT400:0,TURNIN750:0"
    -- abseits (Umweg > 60 yd): nicht
    local s3 = { T("TURNIN", 750) }
    r.off = P.OnWayAccepts(s3, { T("ACCEPT", 400, 200) }, 1, 0, 0) == 0 and #s3 == 1
    -- vom Spieler gewähltes Ziel bleibt vorn
    local s4 = { T("COMPLETE", 750, 0, { explicit = true }) }
    P.OnWayAccepts(s4, { T("ACCEPT", 400, 0) }, 1, 0, 0)
    r.explicit = s4[1].explicit == true
    local good = r.onway and r.moved and r.off and r.explicit and r.both
    return good and true or false, ("Questgeber am Weg vor dem Ziel %s · aus hinterer Stelle nach vorn %s · abseits nicht %s · gewähltes Ziel bleibt vorn %s · zwei hintere Annahmen beide vorn %s")
        :format(S(r.onway), S(r.moved), S(r.off), S(r.explicit), S(r.both)), "true ×5"
end
IMPL.T340 = function()
    local R, Gr = LP.Recorder, LP.Graph
    if not (R and R.QuestOrder) then return false, "QuestOrder fehlt", "vorhanden" end
    local GT = _G.GoldSentinelTest
    if not (GT and GT.Encode) or type(LevelPilotDB) ~= "table" then return NA, "ohne GoldSentinelTest/Speicher" end
    local r = {}
    local db = LP.db
    local keep = { qo = db.questOrder, auto = db.wegeAuto, sent = db.wegeSent, exp = LevelPilotDB.wegeExport }
    Guard(function()
        db.questOrder, db.wegeAuto = {}, false
        R:QuestOrder("A", 783)
        r.noConsent = #db.questOrder == 0
        db.wegeAuto = true
        R:QuestOrder("A", 783)
        R:QuestOrder("T", 783)
        local e = db.questOrder[1]
        r.entry = #db.questOrder == 2 and e.q == 783 and e.a == "A" and type(e.l) == "number" and type(e.t) == "number"
        local names = false
        for _, x in ipairs(db.questOrder) do for k in pairs(x) do if k ~= "q" and k ~= "a" and k ~= "l" and k ~= "t" and k ~= "m" then names = true end end end
        r.noNames = not names
        -- Versand: f = 2 mit "qo"; zweiter Versand ohne Neues -> nichts
        -- 3.12.97 (Ingametest 3.12.95: T340 "wege" 102,8 ms, Speicher -96 MB): mit leerem wegeSent exportierte die Prüfung das GANZE
        -- Wegnetz neu (~96 MB Abfall). Jetzt gilt alles schon Gesendete weiter als gesendet (nur lesen: Metatabelle über die echten
        -- Tabellen, Schreiben landet in der Hülle) – hinaus geht nur, was die Prüfung neu anlegt (Questfolge) und echt Ungesendetes
        local ks = type(keep.sent) == "table" and keep.sent or {}
        local function over(t) return setmetatable({}, { __index = type(t) == "table" and t or {} }) end
        LevelPilotDB.wegeExport, db.wegeSent = {}, { e = over(ks.e), b = over(ks.b), n = over(ks.n), f = math.huge }
        -- 3.12.93 (Ingametest 3.12.91: T340 550 ms in einem Bild): freigegebene Rechnung; questOrder/wegeAuto/wegeSent/wegeExport
        -- liest anderer Code nur bei Quest-Ereignissen (beenden die Routine) und beim Ausloggen
        local ok = Coop(Gr.WegeExport, Gr)
        local s1 = LevelPilotDB.wegeExport[#LevelPilotDB.wegeExport] or ""
        local _, nq = s1:gsub('"q":783', "")
        r.sent = ok and s1:find('"f":2', 1, true) ~= nil and s1:find('"qo":[', 1, true) ~= nil and nq == 2 and s1:find('"a":"T"', 1, true) ~= nil
        r.once = (db.wegeSent.q or 0) >= e.t
    end, function()
        db.questOrder, db.wegeAuto, db.wegeSent, LevelPilotDB.wegeExport = keep.qo, keep.auto, keep.sent, keep.exp
    end, true)
    local good = r.noConsent and r.entry and r.noNames and r.sent and r.once
    return good and true or false, ("ohne Zustimmung nichts %s · Eintrag Quest/Art/Stufe/Zeit %s · keine Namen %s · gesendet als f=2 mit qo %s · als versandt gemerkt %s")
        :format(S(r.noConsent), S(r.entry), S(r.noNames), S(r.sent), S(r.once)), "true ×5"
end
IMPL.T341 = function()
    local P = LP.Planner
    local ok = P.CROSS_STARVE == 2.5 and P.CROSS_MIN_LEVEL == nil
    return ok and true or false, ("Kontinentwechsel nur, wenn daheim Restwert unter %s · keine Stufengrenze mehr %s")
        :format(S(P.CROSS_STARVE), S(P.CROSS_MIN_LEVEL == nil)), "2.5 · true"
end
IMPL.T342 = function()
    local P = LP.Planner
    if not (P.ZoneBands and P.BAND_IN) then return false, "ZoneBands fehlt", "vorhanden" end
    if not (LP.QuestDB:Counts().total > 1000) then return NA, "ohne Datenpaket" end
    local b = P:ZoneBands()
    local n = 0
    for _ in pairs(b) do n = n + 1 end
    local fac = LP:PlayerFaction()
    -- Startzonen: Band beginnt unter 6 und endet unter 15 (Elwynn/Durotar je nach Fraktion); Bänder geordnet (von <= bis)
    local start = fac == "Horde" and b[1411] or b[1429]
    local sane = true
    for _, v in pairs(b) do if not (v[1] <= v[2] and v[1] >= 1 and v[2] <= 60) then sane = false end end
    local good = n >= 20 and start and start[1] < 6 and start[2] < 15 and sane and P.BAND_IN > 1 and P.BAND_OUT < 1
    return good and true or false, ("Zonen mit Band %d · Startzone %s–%s · Bänder gültig %s · Faktoren %s/%s")
        :format(n, S(start and start[1]), S(start and start[2]), S(sane), S(P.BAND_IN), S(P.BAND_OUT)), ">= 20 · <6–<15 · true · 1.5/0.6"
end
IMPL.T343 = function()
    local P, Geo, API = LP.Planner, LP.Geo, LP.API
    if not P.HearthStep then return false, "HearthStep fehlt", "vorhanden" end
    local r = {}
    local o = { tp = P.TravelPlan, tw = Geo.ToWorld, hr = API.HearthReady, bind = LP.char.bind, uh = LP.db.useHearth }
    Guard(function()
        LP.db.useHearth, LP.char.bind = true, { map = 1411, x = 50, y = 50, name = "Gasthaus Test" }
        API.HearthReady = function() return true end
        -- Bindeort 3000 yd vom Spieler, Ziel 6000 yd weit, 5000 yd vom Bindeort (also NICHT nahe am Bindeort)
        Geo.ToWorld = function(_, map, x, y) if map == 1411 and x == 50 then return 1, 0, 3000 end return o.tw(Geo, map, x, y) end
        local target = { t = "COMPLETE", inst = 1, n = 6000, w = 0, map = 1411, key = "T343" }
        P.TravelPlan = function() return { hearth = true, total = 300, legs = {} } end
        local s1 = P:HearthStep(target, 1, 0, 0)
        r.viaPlan = s1 and s1.t == "HEARTH" or false
        P.TravelPlan = function() return { hearth = false, total = 800, legs = {} } end
        r.notFaster = P:HearthStep(target, 1, 0, 0) == nil
        -- Ziel nahe am Bindeort: wie bisher, ohne Reiseplan
        local asked = false
        P.TravelPlan = function() asked = true return nil end
        local near = { t = "COMPLETE", inst = 1, n = 300, w = 3000, map = 1411, key = "T343b" }
        local s3 = P:HearthStep(near, 1, -3000, 0)
        r.nearBind = s3 and s3.t == "HEARTH" and not asked or false
    end, function()
        P.TravelPlan, Geo.ToWorld, API.HearthReady, LP.char.bind, LP.db.useHearth = o.tp, o.tw, o.hr, o.bind, o.uh
    end)
    local good = r.viaPlan and r.notFaster and r.nearBind
    return good and true or false, ("Ruhestein, weil Reiseplan schneller %s · nicht, wenn nicht schneller %s · Ziel am Bindeort wie bisher %s")
        :format(S(r.viaPlan), S(r.notFaster), S(r.nearBind)), "true ×3"
end
IMPL.T344 = function()
    if not LP.RecordMapRects then return false, "RecordMapRects fehlt", "vorhanden" end
    local r = {}
    local o = { kr = LP.db.kartenrahmen, max = LP.MAPRECT_MAX, pr = LP.Print }
    local function V(x, y) return { GetXY = function() return x, y end } end
    local fake = {
        CreateVector2D = function(x, y) return { x, y } end,
        C_Map = {
            GetMapInfo = function(id)
                if id == 1429 then return { mapID = 1429, mapType = 3, parentMapID = 1415 } end
                if id == 1415 then return { mapID = 1415, mapType = 2, parentMapID = 947 } end
                if id == 77 then return { mapID = 77, mapType = 3, parentMapID = 1 } end   -- ohne Weltlage (Instanz)
            end,
            GetWorldPosFromMapPos = function(id, v)
                if id == 77 then return nil end
                local base = id == 1429 and 1000 or 0
                return 0, V(base + v[1] * 100, base + v[2] * 200)
            end,
        },
    }
    local n
    Guard(function()
        LP.MAPRECT_MAX = 1500
        LP.Print = function() end
        WithEnv({ LP.RecordMapRects }, fake, function() n = LP:RecordMapRects() end)
        local k = LP.db.kartenrahmen
        local m = k and k.maps and k.maps[1429]
        r.count = n == 2 and k.count == 2
        r.rect = m and m[1] == 0 and m[2] == 1000 and m[3] == 1000 and m[4] == 1100 and m[5] == 1200 and m[6] == 3 and m[7] == 1415 or false
        r.noInst = k and k.maps[77] == nil or false
        local names = false
        for _, v in pairs(k and k.maps or {}) do for _, x in ipairs(v) do if type(x) == "string" then names = true end end end
        r.noNames = not names
        -- ohne C_Map: nichts, keine Fehler
        LP.db.kartenrahmen = nil
        WithEnv({ LP.RecordMapRects }, { C_Map = false }, function() r.noApi = LP:RecordMapRects() == 0 and LP.db.kartenrahmen == nil end)
    end, function() LP.db.kartenrahmen, LP.MAPRECT_MAX, LP.Print = o.kr, o.max, o.pr end)
    local good = r.count and r.rect and r.noInst and r.noNames and r.noApi
    return good and true or false, ("2 Karten gezählt %s · Ecken/Typ/Eltern %s · Karte ohne Weltlage nicht %s · keine Namen %s · ohne C_Map nichts %s")
        :format(S(r.count), S(r.rect), S(r.noInst), S(r.noNames), S(r.noApi)), "true ×5"
end
IMPL.T345 = function()
    if not (TR.SummaryLines and TR.Command) then return false, "TR-ALLE fehlt", "vorhanden" end
    local r = {}
    local fake = { counts = { ok = 7, fehler = 1, uebersprungen = 3, client = 0 }, results = {
        { id = "X1", status = "SKIP", grund = "ohne Gruppe" .. TR.NA_SUFFIX },
        { id = "X2", status = "SKIP", grund = "ohne Gruppe" .. TR.NA_SUFFIX },
        { id = "X3", status = "SKIP", grund = "nur im Classic-Era-Client" .. TR.NA_SUFFIX },
        { id = "X4", status = "FEHLER" } } }
    local o = { pl = LP.Pruefliste }
    local lines
    Guard(function()
        LP.Pruefliste = nil                               -- ohne Prüfliste: nur Ergebnis und Fehler
        lines = TR:SummaryLines(fake)
    end, function() LP.Pruefliste = o.pl end)
    local first = lines and lines[1] or ""
    r.counts = first:find("7", 1, true) ~= nil and first:find("8", 1, true) ~= nil and first:find("3", 1, true) ~= nil
    r.reason = first:find("ohne Gruppe (2)", 1, true) ~= nil and first:find("nur im Classic-Era-Client (1)", 1, true) ~= nil
    r.noSuffix = not first:find(TR.NA_SUFFIX, 1, true)
    r.err = lines and #lines == 2 and lines[2]:find("1", 1, true) ~= nil
    -- Abbrechen nur, wenn ein Lauf läuft
    local o2 = { running = TR.running, abort = TR.abort, reply = LP.Reply }
    Guard(function()
        LP.Reply = function() end
        TR.running, TR.abort = false, nil
        TR:Command("stopp")
        r.noRun = TR.abort == nil
        TR.running = true
        TR:Command("stopp")
        r.stop = TR.abort ~= nil
    end, function() TR.running, TR.abort, LP.Reply = o2.running, o2.abort, o2.reply end)
    r.slice = TR.SLICE_MS == 5
    local good = r.counts and r.reason and r.noSuffix and r.err and r.noRun and r.stop and r.slice
    return good and true or false, ("Zahlen %s · Gründe gezählt %s · ohne Zusatz %s · Fehlerzeile %s · stopp ohne Lauf nichts %s · stopp bricht ab %s · Portion 5 ms %s")
        :format(S(r.counts), S(r.reason), S(r.noSuffix), S(r.err), S(r.noRun), S(r.stop), S(r.slice)), "true ×7"
end
IMPL.T346 = function()
    if not LP.RecordTalents then return false, "RecordTalents fehlt", "vorhanden" end
    local r = {}
    local o = { tb = LP.db.talentbaum, pr = LP.Print }
    local fake = {
        UnitClass = function() return "Krieger", "WARRIOR" end,
        GetLocale = function() return "deDE" end,
        GetNumTalentTabs = function() return 2 end,
        GetNumTalents = function(tab) return tab == 1 and 2 or 1 end,
        GetTalentInfo = function(tab, i) return ("Talent %d-%d"):format(tab, i), "icon", i, tab, 0, 5 end,
    }
    local n
    Guard(function()
        LP.Print = function() end
        LP.db.talentbaum = nil
        WithEnv({ LP.RecordTalents }, fake, function() n = LP:RecordTalents() end)
        local t = LP.db.talentbaum and LP.db.talentbaum.WARRIOR and LP.db.talentbaum.WARRIOR.deDE
        r.count = n == 3 and t and t.count == 3
        local e = t and t.tabs[1] and t.tabs[1][2]
        r.entry = e and e[1] == "Talent 1-2" and e[2] == 2 and e[3] == 1 and e[4] == 5 or false
        r.noIcon = e and e[5] == nil or false
        WithEnv({ LP.RecordTalents }, { GetTalentInfo = false, GetNumTalents = false }, function() r.noApi = LP:RecordTalents() == 0 end)
    end, function() LP.db.talentbaum, LP.Print = o.tb, o.pr end)
    local good = r.count and r.entry and r.noIcon and r.noApi
    return good and true or false, ("3 Talente %s · Name/Reihe/Spalte/Rang %s · ohne Symbol %s · ohne Abfrage nichts %s")
        :format(S(r.count), S(r.entry), S(r.noIcon), S(r.noApi)), "true ×4"
end
CLIENT.T346 = "Wo: auf einem Charakter, den du ohnehin hast (Stufe egal), nicht im Kampf. Schritte: 1. Tippe in den Chat: /lp talente "
    .. "2. Tippe: /reload. Was du siehst: „LevelPilot: Talente: … Talente aufgezeichnet – jetzt /reload, dann Upload.“ Kosten: kein Gold, unter 1 Minute."

-- 3.12.89 TR-ALLE Nachtrag D2 (Supervisor 19:15): je Punkt, der sich beim Spielen selbst abhakt, EIN GSTEST-Bericht
-- (eigene Liste, eigene Berichts-Tabelle, Testmodus nur in einer eigenen Sicht auf _G – echte Daten bleiben unberührt)
IMPL.T347 = function()
    local M = LP.Pruefliste
    local PL = M and M.Baustein and M.Baustein()
    local GT = _G.GoldSentinelTest
    if not (M and M.SaveHitReport and M.ReportDB and PL and PL.IsDev) then return false, "Prüfliste ohne Berichte", "vorhanden" end
    if not (GT and GT.Begin and GT.PREFIX) then return false, "GoldSentinelTest fehlt", "vorhanden" end
    local saved = { list = M.list, next = M.nextTry, db = M.DB, dry = M.Dry, reg = PL.lists and PL.lists.LevelPilot, pts = M.Points,
                    rdb = M.ReportDB }
    local devOn, testDB, reportDB, r = false, {}, {}, {}
    local fakeDev = { version = 99, IsDev = function() return devOn end }
    local viewG = setmetatable({ GoldSentinelDev = fakeDev }, { __index = _G, __newindex = function() error("T347: _G nicht beschreiben", 0) end })
    local function reports() return reportDB.gsTest and reportDB.gsTest.reports or {} end
    local ok, err = pcall(WithEnv, { PL.IsDev }, { GoldSentinelDev = fakeDev, _G = viewG }, function()
        M.DB = function() return testDB end
        M.Dry = function() return false end
        M.Points = function() return M.POINTS end
        M.ReportDB = function() return reportDB end
        -- (a) ohne Testmodus: kein Bericht
        M.list, M.nextTry = nil, 0
        M:Hit("T300", "aus")
        r.off = #reports() == 0
        -- (b) Testmodus: Hit -> genau ein Bericht mit Punkt, Messwert, Version, "beim Spielen"
        devOn = true
        M.list, M.nextTry = nil, 0
        local l = M:List(true)
        r.hit = M:Hit("T300", "mit Knopf Hinführen") == true
        local rep = reports()[1] or ""
        r.n1 = #reports()
        r.prefix = rep:sub(1, #GT.PREFIX) == GT.PREFIX
        r.fields = rep:find("T300", 1, true) ~= nil and rep:find("mit Knopf Hinf", 1, true) ~= nil
            and rep:find(tostring(LP.version), 1, true) ~= nil and rep:find("beim Spielen", 1, true) ~= nil
            and rep:find("pruefliste", 1, true) ~= nil
        r.ms = M.lastReportMs
        -- (c) derselbe Punkt nochmals: schon erledigt -> kein zweiter Bericht
        M:Hit("T300", "nochmals")
        r.n2 = #reports()
        -- (d) Fehler erkannt -> Bericht mit FEHLER
        r.fail = M:Fail("PF-A", "20 ms") == true
        local rep2 = reports()[2] or ""
        r.failRep = #reports() == 2 and rep2:find("FEHLER", 1, true) ~= nil and rep2:find("PF-A", 1, true) ~= nil
        -- (e) während der Testroutine mit der echten Berichts-Tabelle: nie schreiben (Sperre), hier ohne echtes Schreiben geprüft
        local tr = LP.TestRoutine
        local wasRun = tr.running
        tr.running = true
        local real = M.ReportDB
        M.ReportDB = M.REPORT_DB_REAL
        r.guard = M:SaveHitReport("T301", "OK", "x") == false
        M.ReportDB = real
        tr.running = wasRun
        r.n3 = #reports()
        return true
    end)
    M.list, M.nextTry, M.DB, M.Dry, M.Points, M.ReportDB = saved.list, saved.next, saved.db, saved.dry, saved.pts, saved.rdb
    if PL.lists then PL.lists.LevelPilot = saved.reg end
    if not ok then error(err, 0) end
    local fast = r.ms == nil or r.ms < 1
    local good = r.off and r.hit and r.n1 == 1 and r.prefix and r.fields and r.n2 == 1 and r.fail and r.failRep and r.guard
        and r.n3 == 2 and fast
    return good and true or false, ("ohne Testmodus kein Bericht %s · Hit %s -> Berichte %s, GSTEST1 %s, Felder %s, %s ms · nochmals %s · Fehler %s/%s · Sperre Testroutine %s (%s)")
        :format(S(r.off), S(r.hit), S(r.n1), S(r.prefix), S(r.fields), r.ms and ("%.2f"):format(r.ms) or "?", S(r.n2), S(r.fail),
            S(r.failRep), S(r.guard), S(r.n3)),
        "true · true -> 1, true, true, < 1 ms · 1 · true/true · true (2)"
end
CLIENT.T347 = "Wo: im Entwicklermodus beim normalen Spielen. Schritte: 1. Spiele wie immer, bis die Prüfliste einen Punkt selbst abhakt (Chatzeile „… erledigt (erkannt)“). Was du siehst: nichts Neues im Spiel; beim nächsten Hochladen kommt ein kleiner Testbericht „Prüfliste“ mit diesem Punkt mit. Kosten: keine. OK, wenn der Bericht ankommt."

-- 3.12.90 Ingametest 3.12.89 Punkt 1 (T151 bis 2,1 s mit 19 446 eigenen Knoten): innere Punkte eigener Wege werden als Kette
-- gegangen. Eigenes kleines Netz am Rand von Mulgore (Sandbox stellt das Wegnetz zurück): Kette aus 21 Punkten, dann Abzweig.
IMPL.T348 = function()
    local Gr = LP.Graph
    if not (Gr.MarkOwnInner and Gr.IsOwnInner) then return false, "Ketten fehlen", "Graph:MarkOwnInner" end
    -- eigene Ecke von Mulgore (andere Tests legen ihre Wege bei WegBase an – deren Knoten würden den Weg hier ändern)
    local i, n, w = LP.Geo:ToWorld(1412, 90, 12)
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local function P(dn, dw) return { i, n + dn, w + dw, 1412 } end
    local line = {}
    for k = 0, 20 do line[#line + 1] = P(k * 20, 0) end           -- 400 Yards, alle 20 Yards ein Punkt
    Gr:AddPolyline(line, "r")
    Gr:AddPolyline({ P(400, 0), P(400, 100), P(400, 200) }, "r")   -- Abzweig am Ende
    Gr:AddPolyline({ P(400, 0), P(500, 0) }, "r")                  -- Kreuzung am Ende (dort ein voller Knoten)
    local saved = Gr.OWN_INNER
    local Dg = LP.Danger
    local savedRule = Dg and Dg.pathRule
    local r = {}
    -- 3.12.93 (Ingametest 3.12.91: T348 68 ms in einem Bild): die beiden Läufe je für sich (Ersatz nur während eines Laufs),
    -- dazwischen und vor dem Zurücksetzen eine sichere Stelle
    local function Run(own)
        return pcall(function()
        -- ohne Gefahrenregel (am Kartenrand liegen Zellen mit starken Mobs): so geht die Suche die gemerkte Kette am Stück
        if Dg then Dg.pathRule = false end
        local function run()
            Gr:MarkOwnInner()
            local p, kind, c = Gr:Path(i, n - 5, w, 1412, i, n + 400, w + 205, 1412)
            local mid = 0
            for _, pt in ipairs(p or {}) do if pt.id and Gr.IsOwnInner(pt.id) then mid = mid + 1 end end
            local plain = 0
            for _, pt in ipairs(p or {}) do if math.abs(pt[3] - w) < 1 and pt[2] > n + 1 and pt[2] < n + 399 then plain = plain + 1 end end
            return c, p and #p or 0, mid, plain, Gr.ownInnerCount or 0
        end
        Gr.OWN_INNER = own
        if own then r.c1, r.n1, r.mid1, r.plain1, r.inner1 = run()
        else r.c0, r.n0, r.mid0, r.plain0, r.inner0 = run() end
        end)
    end
    TR.Safe("T348")
    local ok, err = Run(true)
    Gr.OWN_INNER = saved
    if Dg then Dg.pathRule = savedRule end
    if ok then
        TR.Safe("T348")
        ok, err = Run(false)
        Gr.OWN_INNER = saved
        if Dg then Dg.pathRule = savedRule end
    end
    TR.Safe("T348")
    Gr:MarkOwnInner()
    if not ok then error(err, 0) end
    local same = r.c1 and r.c0 and math.abs(r.c1 - r.c0) <= 0.01 * r.c0
    -- gleicher Weg wie ohne Ketten (3.12.89), und die inneren Punkte stehen im Weg (Gegenprobe: ohne Einfügen der Kette fehlen sie)
    local good = r.inner1 >= 19 and r.inner0 == 0 and same and r.n1 == r.n0 and r.plain1 == r.plain0 and r.mid1 >= 15
    return good and true or false, ("innere Punkte %s (aus: %s) · Kosten %.0f / %.0f · Punkte im Weg %s / %s · auf der Kette %s / %s, davon innere %s")
        :format(S(r.inner1), S(r.inner0), r.c1 or -1, r.c0 or -1, S(r.n1), S(r.n0), S(r.plain1), S(r.plain0), S(r.mid1)),
        ">= 19 (0) · gleich (±1 %) · gleich · gleich, innere >= 15"
end
CLIENT.T348 = "Wo: irgendwo, wo du schon Wege gelaufen bist. Schritte: 1. Tippe /lp testroutine alles. Was du siehst: am Ende T151 (Orgrimmar -> Wegkreuz) unter 16 ms. Kosten: keine. OK, wenn T151 und T348 bestanden sind."

-- 3.12.93 (Ingametest 3.12.91 Punkt 1, HOCH SOFORT): die Testroutine selbst läuft im Takt. Geprüft im laufenden Lauf: über dem
-- Budget gibt TR.Safe ab (ein neues Bild wird gezählt), in einem pcall und bei TR.hold > 0 nie (kein "attempt to yield across").
-- Gegenprobe: ohne Abgabe (TR.Safe am Budget nicht überschritten) kommt kein neues Bild dazu.
IMPL.T353 = function()
    if not (TR.job and TR.frames) then return NA, "nur im Lauf der Routine (Takt-Aufgabe)" end
    local function burn() local t = Ms() while Ms() - t < (TR.BUDGET or 4) + 1 do end end
    local r = {}
    TR.Safe("T353")                                     -- frisches Bild
    local n0 = TR.frames.n
    r.under = TR.Safe("T353")                           -- Budget noch nicht verbraucht: keine Abgabe (Gegenprobe)
    r.n0b = TR.frames.n
    burn()
    r.free = TR.Safe("T353")                            -- über dem Budget, kein Ersatz: Abgabe
    r.n1 = TR.frames.n
    burn()
    -- 3.12.94: Etikett "Gegenprobe" – in der Takt-Zeile "Abgabe nicht möglich: … (T353 Gegenprobe (pcall))" ist diese absichtlich
    local okP, eP = pcall(function() r.inPcall = TR.Safe("Gegenprobe") end)
    r.pcallOK = okP
    TR.blockedT = nil
    burn()
    r.held = Hold(function() return TR.Safe("T353") end)
    TR.Safe("T353")
    local good = r.under == false and r.n0b == n0 and r.free == true and r.n1 > n0 and r.pcallOK and r.inPcall == false
        and r.held == false
    return good and true or false, ("unter Budget %s (Bilder +%d) · über Budget %s (Bilder +%d) · in pcall %s (Fehler %s) · bei Ersatz %s")
        :format(S(r.under), r.n0b - n0, S(r.free), r.n1 - n0, S(r.inPcall), okP and "nein" or tostring(eP), S(r.held)),
        "false (+0) · true (+1 oder mehr) · false (nein) · false"
end

-- 3.12.95 (Ingametest 3.12.94 T261: Umweg-Messung je Zone und Sitzung neu = 83 % der Rechenzeit der ersten 60 s): Ablage je Zone mit
-- Kennung des Netzes. Mit eigenen Tabellen (opt) statt Graph.detour/LP.db.detourCache – kein Ersatz-Zustand, die Rechnung darf abgeben.
IMPL.T354 = function()
    local G = LP.Graph
    if not (G.MeasureDetour and G.DetourSig and G.DETOUR_CACHE_KEEP) then return false, "Umweg-Ablage fehlt", "Graph.DetourSig" end
    -- Zone: die des Spielers; hat sie kaum Wegpunkte, die Zone mit den meisten (eine Messung mit 0 Paaren prüfte zu wenig)
    local _, _, _, zone = LP.Geo:Player()
    zone = tonumber(zone)
    local own = zone and G.detour[zone] and tonumber(G.detour[zone].knoten) or nil
    if (not own or own < 50) and G.BusiestZone then
        local okB, best, n = PCallY(Coop, G.BusiestZone, "graph")
        TR.Safe("T354")
        if okB and best and n >= 50 then zone = best end
    end
    if not zone then return NA, "kein Ort des Spielers", "-" end
    local opt = { det = {}, cache = {}, stat = {} }
    local name = "umweg" .. zone .. "t"
    local function run()
        opt.det = {}
        local ok, err = PCallY(Coop, G.MeasureDetour, G, zone, opt)
        if not ok then error(err, 0) end
        local guard = 0
        while LP.Jobs.Running(name) and guard < 20000 do LP.Jobs.Step() guard = guard + 1 TR.Safe("T354") end
        TR.Safe("T354")
        return opt.det[zone] or {}
    end
    local function keys() local n = 0 for _ in pairs(opt.cache[zone] or {}) do n = n + 1 end return n end
    local r = {}
    local a = run()                                                   -- 1) leer: messen und ablegen
    r.a = a.measured == true and not a.cached and type(a.f) == "number" and a.pending == nil and (opt.stat.detourMeasured or 0) == 1
        and keys() == 1 and type((opt.cache[zone] or {})[a.sig or ""]) == "table"
    local b = run()                                                   -- 2) gleiches Netz: aus der Ablage, ohne Wegsuchen
    r.b = b.cached == true and not b.measured and b.f == a.f and b.n == a.n and b.sig == a.sig and (opt.stat.detourHits or 0) == 1
        and (opt.stat.detourMeasured or 0) == 1
    -- 3) Gegenprobe: andere Kennung (anderes Netz) -> neu messen, der abgelegte fremde Wert gilt nicht
    local fake = (a.f or 1.25) == 1.77 and 1.66 or 1.77
    opt.cache[zone] = { ["x" .. tostring(a.sig)] = { f = fake, n = 5, paare = 5, versuche = 9, t = 1 } }
    local c = run()
    r.c = c.measured == true and not c.cached and c.f == a.f and c.f ~= fake and (opt.stat.detourMeasured or 0) == 2 and keys() == 2
    -- 4) Gegenprobe: unbrauchbarer Wert unter der richtigen Kennung (ausserhalb der Grenzen) -> neu messen
    opt.cache[zone][a.sig].f = 99
    local d = run()
    r.d = d.measured == true and d.f == a.f and (opt.stat.detourMeasured or 0) == 3 and opt.cache[zone][a.sig].f == a.f
    -- 5) höchstens DETOUR_CACHE_KEEP Kennungen je Zone: die eben gemessene bleibt, von den übrigen die zuletzt gebrauchten
    opt.cache[zone] = { s1 = { f = 1.2, t = 1 }, s2 = { f = 1.2, t = 2 }, s3 = { f = 1.2, t = 3 }, s4 = { f = 1.2, t = 4 } }
    run()
    local z = opt.cache[zone]
    r.e = keys() == G.DETOUR_CACHE_KEEP and z[a.sig] ~= nil and (G.DETOUR_CACHE_KEEP < 3 or (z.s4 ~= nil and z.s3 ~= nil))
        and z.s1 == nil and z.s2 == nil
    -- 6) Kennung: grosse Summen ohne 32-Bit-Überlauf, jede Grösse zählt
    local s0 = G.DetourSig(10, 4294967301, 7, 3, 9)
    r.f = s0 == ("%d/%d/%d/%d/10/4294967301/7/3/9"):format(G.DETOUR_CACHE_VER, G.DETOUR_PAIRS, G.DETOUR_TRIES, G.DETOUR_MIN_PAIRS)
        and s0 ~= G.DetourSig(10, 4294967301, 7, 4, 9) and s0 ~= G.DetourSig(10, 4294967302, 7, 3, 9)
        and s0 ~= G.DetourSig(11, 4294967301, 7, 3, 9) and s0 ~= G.DetourSig(10, 4294967301, 8, 3, 9)
        and s0 ~= G.DetourSig(10, 4294967301, 7, 3, 10)
    local good = r.a and r.b and r.c and r.d and r.e and r.f
    return good and true or false, ("Zone %d (%d Knoten, Faktor %s, %d Paare) · gemessen+abgelegt %s · aus der Ablage %s · andere Kennung misst neu %s · unbrauchbarer Wert misst neu %s · höchstens %d je Zone %s · Kennung %s")
        :format(zone, a.knoten or 0, tostring(a.f), a.n or 0, S(r.a), S(r.b), S(r.c), S(r.d), G.DETOUR_CACHE_KEEP, S(r.e), S(r.f)),
        "true ×6"
end

-- 3.12.95 (Ingametest 3.12.94 T21: "/lp protokoll" 91–93 ms in einem Bild): UpdateAddOnMemoryUsage misst den Speicher ALLER Addons
-- am Stück; nur noch mit "/lp protokoll speicher" (bzw. "log mem"). Zählende Ersatzfunktion nur für MeasureAddon (WithEnv).
IMPL.T355 = function()
    local Pr = LP.Protocol
    if not (Pr and Pr.MeasureAddon and Pr.Show) then return false, "Protocol fehlt", "Show/MeasureAddon" end
    local calls = 0
    local fake = {
        UpdateAddOnMemoryUsage = function() calls = calls + 1 end,
        GetAddOnMemoryUsage = function() return 1024 end,
        C_AddOns = { GetAddOnMemoryUsage = function() return 1024 end },
    }
    local f = function() return _G.LevelPilotBackupFrame end
    local r, bad = {}, {}
    local replies = {}
    local reply0 = LP.Reply
    -- 3.13.1 (Ingametest 3.13.0: Bild "T354 graph–T355" 137,9 ms = die fünf Befehle am Stück): jeder Befehl in seiner eigenen Hülle
    -- (Ersatz-Messfunktion und Ersatz-Antwort nur für seine Dauer), dazwischen eine sichere Stelle (kein Ersatz aktiv)
    local function step(fn)
        local c0 = calls
        WithEnv({ Pr.MeasureAddon }, fake, function()
            LP.Reply = function(_, m) replies[#replies + 1] = tostring(m) end
            local ok, err = pcall(fn)
            LP.Reply = reply0
            if not ok then error(err, 0) end
        end)
        LP.Reply = reply0
        if f() then f():Hide() end
        TR.Safe("T355")
        return calls - c0
    end
    local function cmd(m)
        return step(function()
            local ok, err = pcall(Slash, m)
            if not ok then bad[#bad + 1] = m .. ": " .. tostring(err):sub(1, 60) end
        end)
    end
    -- 3.12.97 (Ingametest 3.12.95: "T355 graph" 159,7 ms in einem Bild): "diag" und "messen" rechnen den Graphen am Stück (in WithEnv,
    -- ohne Abgabe) – nicht mehr hier; dass sie den Speicher aller Addons nicht messen, prüft T294 (Diagnose-Text 0×), ausgeführt
    -- werden sie in T21
    r.plain = cmd("protokoll") + cmd("log")
    r.mem = cmd("protokoll speicher")
    r.memEn = cmd("log mem")
    r.button = step(function() pcall(Pr.Show, Pr) end)
    LP.Reply = reply0
    local hint = false
    for _, m in ipairs(replies) do if m == L["Speicher aller Addons wird gemessen – das Spiel steht dabei kurz still."] then hint = true end end
    local ok = #bad == 0 and r.plain == 0 and r.mem == 1 and r.memEn == 1 and r.button == 0 and hint
    return ok, #bad > 0 and table.concat(bad, "; ") or ("ohne Zusatz (protokoll, log) %d× · protokoll speicher %d× · log mem %d× · Knopf Fehler-Protokoll %d× · Hinweis vorher %s")
        :format(r.plain or -1, r.mem or -1, r.memEn or -1, r.button or -1, S(hint)), "0× · 1× · 1× · 0× · true"
end

-- 3.12.95: Aufträge, die anderer Code während der Pause einer freigegebenen Rechnung startet, werden zurückgestellt statt verworfen
-- (bis 3.12.94 verworfen: Umweg "in Arbeit", Strassen "geladen", Orte "im Bau" bis zum Neuaufbau). Ohne Abgabe (pcall) – die
-- gesetzte Pause sieht kein anderer Code.
IMPL.T356 = function()
    local J = LP.Jobs
    if not (J.FlushDeferred and J.deferred) then return false, "Zurückstellen fehlt", "Jobs.FlushDeferred" end
    local r, ran = {}, 0
    local saved = { def = J.deferred, pause = TR.coopPause, sync = J.sync, d0 = TR.deferred }
    local ok, err = pcall(function()
        J.deferred, J.sync = {}, true
        TR.coopPause = true
        J.Start("lpT356a", "plan", function() ran = ran + 1 end, nil, { plan = true })
        J.Start("lpT356a", "plan", function() ran = ran + 10 end, nil, { plan = true })   -- neuerer Start ersetzt den zurückgestellten
        J.StartTakt("lpT356b", "plan", function() ran = ran + 100 end, nil, { plan = true })
        TR.coopPause = saved.pause
        r.ranInPause, r.queued = ran, Count(J.deferred)
        r.takt = J.deferred.lpT356b and J.deferred.lpT356b.takt == true
        J.deferred.lpT356c = { mod = "plan", fn = function() ran = ran + 1000 end, kinds = { plan = true } }
        J.Start("lpT356c", "plan", function() ran = ran + 10000 end, nil, { plan = true })  -- normaler Start: der alte entfällt
        r.superseded = J.deferred.lpT356c == nil
        r.flushed = J.FlushDeferred()
        r.empty = next(J.deferred) == nil
    end)
    TR.coopPause, J.sync, TR.deferred = saved.pause, saved.sync, saved.d0
    for k, v in pairs(J.deferred) do saved.def[k] = v end
    J.deferred = saved.def
    if not ok then error(err, 0) end
    local good = r.ranInPause == 0 and r.queued == 2 and r.takt and r.superseded and r.flushed == 2 and r.empty and ran == 10110
    return good and true or false, ("in der Pause gelaufen %d · zurückgestellt %d (Takt-Auftrag %s) · neuerer Start ersetzt %s · nach dem Ende gestartet %d, Summe %d")
        :format(r.ranInPause or -1, r.queued or -1, S(r.takt), S(r.superseded), r.flushed or -1, ran), "0 · 2 (true) · true · 2, 10110"
end

-- 3.12.90 Ingametest 3.12.89 Punkt 6: Bilder der Routine zählen (eigene Zählung, die laufende bleibt unberührt)
IMPL.T349 = function()
    if not (TR.CountFrame and TR.FrameLines) then return false, "Zählung fehlt", "TR:CountFrame" end
    local saved = { f = TR.frames, cur = TR.cur, area = TR.curArea }
    local r = {}
    -- 3.12.95: keine echte Speicherbereinigung zwischen den vorgetäuschten Bildern (sonst zufällig 3. Zeile); im Spiel ggf. gesperrt -> pcall
    local gcStopped = pcall(collectgarbage, "stop")
    local ok, err = pcall(function()
        TR.frames = { n = 0, max = 0, over = {}, area = {}, order = {} }
        TR.cur, TR.curArea = "T1", "A" TR:CountFrame(3)
        TR.cur, TR.curArea = "T2", "A" TR:CountFrame(25)
        TR.cur, TR.curArea = "T2", "A" TR:CountFrame(18)
        TR.cur, TR.curArea = "T9", "B" TR:CountFrame(40)
        TR.cur, TR.curArea = "T9", "B" TR:CountFrame(2)
        TR.cur, TR.curArea = "T9", "B" TR:CountFrame(41)   -- 3.12.93: über 40 ms zählt (40 selbst nicht)
        local l = TR:FrameLines() or {}
        r.l1, r.l2, r.l3none = l[1] or "", l[2] or "", l[3] == nil
        -- 3.12.95: Bild über 40 ms, in dem der Speicher fiel (Speicherbereinigung) – Speicher vorher 8 MB höher vorgetäuscht
        TR.frames.lastMem = collectgarbage("count") + 8192
        TR.cur, TR.curArea = "T7", "B" TR:CountFrame(55)
        TR.frames.lastMem = collectgarbage("count") + 8192
        TR.cur, TR.curArea = "T8", "B" TR:CountFrame(30)                       -- Gegenprobe: unter 40 ms zählt nicht
        l = TR:FrameLines() or {}
        r.l3 = l[3] or ""
    end)
    if gcStopped then pcall(collectgarbage, "restart") end
    TR.frames, TR.cur, TR.curArea = saved.f, saved.cur, saved.area
    if not ok then error(err, 0) end
    local want1 = L("Portionen: %d Bilder, längstes %.1f ms (%s), Schritte über %d ms: %d%s", 6, 41, "T9", 16, 2, " – T9 41 ms, T2 25 ms")
        .. " · " .. L("Bilder über %d ms: %d", 40, 1)
    local want2 = L("Rechenzeit je Bereich: %s", "A 0.0 s · B 0.1 s")
    local want3 = L("Bilder über %d ms, in denen der Speicher fiel (Speicherbereinigung): %d – %s", 40, 1, "T7 55 ms (-8 MB)")
    return r.l1 == want1 and r.l2 == want2 and r.l3none and r.l3 == want3, ("„%s“ · „%s“ · ohne Speicherfall keine 3. Zeile %s · „%s“")
        :format(r.l1, r.l2, S(r.l3none), r.l3), ("„%s“ · „%s“ · true · „%s“"):format(want1, want2, want3)
end
CLIENT.T349 = "Wo: im Entwicklermodus. Schritte: 1. Tippe /lp testroutine alles. Was du siehst: am Ende im Chat die Zeilen „Portionen: … Bilder, längstes … ms (…) … · Bilder über 40 ms: …“ und „Rechenzeit je Bereich: …“. Kosten: keine. OK, wenn beide Zeilen da sind."

-- 3.12.90 Prüfung 20:00: WithEnv schreibt nie in _G; dazu wie AHSentinel T899 eine Liste wichtiger Blizzard-Namen, die nach den
-- Tests noch "sicher" (nicht von einem Addon beschrieben) sein müssen. Läuft spät im Ablauf (Bereich J), also nach fast allen Tests.
TR.SECURE_NAMES = { "GetCVar", "SetCVar", "UnitIsAFK", "UnitLevel", "UnitGUID", "UnitName", "GetTime", "CreateFrame", "print",
    "C_QuestLog", "C_Map", "C_Timer", "GetMoney", "GetLocale", "IsInGroup", "UnitXP", "UnitXPMax", "GetXPExhaustion",
    "IsInInstance", "GetRepairAllCost", "CanMerchantRepair", "GetNumLootItems", "UnitExists", "UnitIsPlayer", "UnitOnTaxi",
    "ToggleWorldMap", "debugprofilestop", "ChatEdit_GetActiveWindow", "GetGuildInfo", "UnitRace", "UnitClass", "GetSubZoneText" }
IMPL.T350 = function()
    local name = "LPTestGlobal350"
    local before = rawget(_G, name)
    local function writer() LPTestGlobal350 = 350 return LPTestGlobal350 end
    local seen = WithEnv({ writer }, {}, function() return writer() end)
    local leaked = rawget(_G, name) ~= before
    if leaked then rawset(_G, name, before) end
    local bad, checked = {}, 0
    if type(issecurevariable) == "function" then
        for _, n in ipairs(TR.SECURE_NAMES) do
            if rawget(_G, n) ~= nil then
                checked = checked + 1
                local ok, sec, who = pcall(issecurevariable, n)
                if ok and sec == false then bad[#bad + 1] = n .. (who and (" (" .. tostring(who) .. ")") or "") end
            end
        end
    end
    local good = seen == 350 and not leaked and #bad == 0
    return good and true or false, ("im Test gelesen %s · in _G angekommen %s · Blizzard-Namen geprüft %d, verdorben: %s"):format(S(seen),
        S(leaked), checked, #bad > 0 and table.concat(bad, ", ") or "keine"), "350 · false · keine"
end

-- 3.12.92 Hinweis 18.11.2026 06:45 (Testdaten nie zu anderen Addons): TestRunning für andere Addons; Testdaten gehen nie hinaus
IMPL.T351 = function()
    local Comm, A = LP.Comm, _G.LevelPilotAPI
    if not (A and A.TestRunning and Comm and Comm.AutoShareBlocked) then return false, "fehlt", "LevelPilotAPI.TestRunning" end
    local saved = { run = TR.running, bc = Comm.Broadcast, ts = Comm.testSend }
    local r = {}
    local ok, err = pcall(function()
        local sent = 0
        Comm.Broadcast = function() sent = sent + 1 return true end
        local pts = { { 1, 0, 0, 1412 }, { 1, 30, 0, 1412 } }
        TR.running = true
        r.during = A.TestRunning()
        LP:Fire("PATH_RECORDED", pts)
        LP:Fire("CALIB_FLIGHT")
        r.blocked = sent
        Comm.testSend = true                          -- Gegenprobe im selben Test: ausdrücklich erlaubt -> geht hinaus
        LP:Fire("PATH_RECORDED", pts)
        r.allowed = sent - r.blocked
        Comm.testSend = saved.ts
        TR.running = false
        r.after = A.TestRunning()
    end)
    TR.running, Comm.Broadcast, Comm.testSend = saved.run, saved.bc, saved.ts
    if not ok then error(err, 0) end
    local virt = LP.Virtual and LP.Virtual.active
    local good = r.during == true and r.blocked == 0 and r.allowed == 1 and (r.after == false or virt)
    return good and true or false, ("TestRunning während Test %s, danach %s · geteilt während Test %s, mit Erlaubnis %s"):format(S(r.during),
        S(r.after), S(r.blocked), S(r.allowed)), "true, false · 0, 1"
end

-- 3.12.92 Plan Punkt 2 (T261): Graph:Init lädt die eigenen Knoten/Kanten als GoldSentinelTakt-Aufgabe. Hier in Portionen (Takt von
-- Hand angetrieben) – Fingerabdruck gleich dem aus den gespeicherten Daten, längstes Bild <= Budget + Reserve, während des
-- Ladens liefert die Wegsuche die Luftlinie ("direct"). Gegenprobe: Graph.INIT_PORTION = false -> keine Portionen.
IMPL.T352 = function()
    local Gr, Takt, Jobs = LP.Graph, _G.GoldSentinelTakt, LP.Jobs
    if not (Gr.LoadFingerprint and Takt and Takt.Tick and Jobs.TaktTick) then return false, "fehlt", "Graph.LoadFingerprint, GoldSentinelTakt" end
    local r = {}
    local oldSync = Jobs.sync
    -- 3.12.93 (Nachbau Laptop-Daten: T352 ~120 ms in einem Bild): zwischen zwei Portionen eine sichere Stelle (gemessen wird nur
    -- die Portion; Jobs.sync = false ist der Zustand des normalen Spiels, der Portionen-Treiber ruht während der Routine)
    local ok, err = PCallY(function()
        TR.Safe("T352")
        r.fpSync, r.n = Coop(Gr.DataFingerprint)
        TR.Safe("T352")          -- erwartet: aus den gespeicherten Daten (ohne Laden am Stück)
        Jobs.sync = false
        Gr:Init()
        r.loadingAtStart = Gr.loading == true
        local i, n, w = LP.Geo:ToWorld(1412, 50, 50)
        local p, kind = Gr:Path(i, n, w, 1412, i, n + 300, w, 1412)
        r.kindLoading = kind
        local frames, maxMs = 0, 0
        while Gr.loading and frames < 5000 do
            local t0 = Ms()
            Jobs.TaktTick()            -- 3.12.93: nie die laufende Testroutine selbst antreiben
            local ms = Ms() - t0
            if ms > maxMs then maxMs = ms end
            frames = frames + 1
            TR.Safe("T352")
        end
        r.frames, r.maxMs = frames, maxMs
        local guard = 0
        while Jobs.Count() > 0 and guard < 20000 do Jobs.Step() guard = guard + 1 TR.Safe("T352") end   -- Startnetz/innere Punkte fertig
        r.fpPortion = Gr.LoadFingerprint()
        r.summary = Gr.loadSummary or ""
    end)
    Jobs.sync = oldSync
    if not ok then
        pcall(function() Jobs.sync = true Gr:Init() Jobs.sync = oldSync end)
        error(err, 0)
    end
    local budget = Gr.LOAD_BUDGET or 4
    local portions = Gr.INIT_PORTION ~= false and r.loadingAtStart
    local good = portions and r.fpSync == r.fpPortion and r.kindLoading == "direct" and r.frames >= 1
        and r.maxMs <= budget + 12
    return good and true or false, ("Fingerabdruck Daten %s · geladen in Portionen %s · lädt: Weg %s · %d Bilder, längstes %.1f ms · %s")
        :format(r.fpSync, r.fpPortion, tostring(r.kindLoading), r.frames or 0, r.maxMs or 0, r.summary),
        ("gleich · direct · längstes Bild <= %d ms"):format(budget + 12)
end
CLIENT.T344 = "Wo: irgendwo im Spiel, nicht im Kampf (der Befehl ist nur für dein Konto freigeschaltet). Schritte: 1. Tippe in den Chat: /lp kartenrahmen "
    .. "2. Tippe in den Chat: /reload – der Uploader schickt die Daten danach von selbst. Was du siehst: Im Chat steht "
    .. "'LevelPilot: Kartenrahmen: … Karten gemessen und gespeichert – jetzt /reload, dann Upload.' mit einer Zahl um 50 "
    .. "(alle Zonen und beide Kontinente; WoW Forever: 54). Kosten: kein Gold, unter 1 Minute. Danach OK – oder Nicht OK mit dem Text, der stattdessen kam."
CLIENT.T343 = "Im Spiel: weites Ziel, Bindeort in einer Stadt mit Flugmeister – der Guide schlägt Ruhestein + Flug vor, wenn das schneller ist"
CLIENT.T342 = "Im Spiel: Zonenwahl passt zur Stufe (keine Zone, deren Quests klar über oder unter dir liegen, wenn es passende gibt)"
CLIENT.T341 = "Im Spiel: der Guide wechselt den Kontinent erst, wenn auf deinem kaum noch passende Quests sind"
CLIENT.T340 = "Im Spiel mit Wegdaten-Versand an: Quests annehmen/abgeben, ausloggen – die Wegdaten enthalten die Questfolge (ohne Namen)"
CLIENT.T339 = "Im Spiel: auf dem Weg zu einem Ziel steht ein Questgeber am Weg – der Guide nimmt ihn unterwegs mit"
CLIENT.T338 = "Im Spiel: in einem Dorf (z. B. Späherkuppe) zeigt der Guide zuerst alle Questgeber im Dorf, dann die Ziele draussen"
CLIENT.T337 = "Im Spiel: einem Ziel folgen – die Entfernung fällt stetig, der Pfeil dreht nicht zurück"
CLIENT.T336 = "Im Spiel: keine Quest im Guide, die mehr als 2 Stufen über dir liegt"
CLIENT.T335 = "Im Spiel: steht ein Questgeber in der Nähe (bis 150 yd), zeigt der Guide zuerst ihn – erst danach weiter weg oder zum Gasthaus"
CLIENT.T334 = "Im Spiel: /lp testroutine – Nordhain und Goldhain werden als verschiedene Orte erkannt (Era und Forever)"
CLIENT.T333 = "Im Classic-Era-Client: neuer Charakter – die Route bleibt im Startgebiet (Nordhain, Tal der Prüfungen …), bis dort alles erledigt ist oder Stufe 6; kein Binden/Flugpunkt vorher"
CLIENT.T332 = "Im Classic-Era-Client: neuer Charakter in der Startzone – erst die nahen Questgeber, Binden/Flugpunkt später; der Pfeil dreht beim Laufen nicht um"

CLIENT.T331 = "Im Spiel: mit fertiger Quest in der Nähe /lp navi 50 50 ödland – das Navi-Ziel steht oben, der Pfeil zeigt dorthin"

CLIENT.T330 = "Im Spiel: /lp navi 50 50 ödland (Allianz/Horde egal) findet das Ödland; /lp protokoll Zeile REISE zeigt „Tempo 7,0 yd/s (zu Fuss)“"

CLIENT.T329 = "Im Spiel: /lp testroutine reise, danach /lp testroutine bericht – Abschnitt „Messlatte: Bestzeiten je Stufe“"

CLIENT.T328 = "Im Spiel: Flugmeister ansprechen (Flugkarte öffnen), dann /lp navi zu einem Ziel mit Flug – im Reiseplan „Flug nach X, 1s 20c (2:10)“"

CLIENT.T327 = "Im Spiel (Speedrun, Stufe 1–10, Schalter an): weiter Weg mit Friedhof nahe am Ziel – gelbe Zeile „Speedrun-Trick: … spart ~X min“. Haltbarkeit/Nachwirkungen nach dem Auferstehen messen (Forever)"

CLIENT.T326 = "Im Spiel nicht einzeln sichtbar: Wirkung über die virtuelle Reise (/lp testroutine reise) und die Laufweg-Zeilen (LW-6)"

CLIENT.T325 = "Im Classic-Era-Client: AddOn-Liste ohne „veraltet“, /lp prüfliste zeigt „Classic Era: …“ (6 Punkte), E5-1 bis E5-3 erledigt sich selbst"

CLIENT.T324 = "Im Spiel: Töte-Quest mit mehreren Gegner-Gruppen – nahe dem Gebiet zeigt der Pfeil „Gegner – Rundgang“ und führt von Gruppe zu Gruppe, danach von vorn"

CLIENT.T323 = "Im Spiel: weiter Routenschritt (z. B. Abgabe in einer anderen Zone) – „Reise ~…“ unter dem Schritt; ein anderes Addon (ProfessionSentinel) ruft LevelPilotAPI.NavigateToNearest(\"trainer\")"

CLIENT.T322 = "Im Spiel: /lp navi zu einem Ort hinter einem Gebiet mit hohen Gegnern – rote Zeile „Vorsicht: Gegner bis Stufe …“; am Ziel „Navi: angekommen“"

CLIENT.T320 = "Im Spiel: Markierung auf der Weltkarte setzen (Strg+Klick) – LevelPilot führt hin, Reiseplan unter dem Ziel; Markierung entfernen -> Navi endet. Gibt es das Ereignis im Forever-Client? (Zeile „Ereignis im Client“)"

CLIENT.T319 = "Im Spiel: /lp navi gornek (oder ein anderer Questgeber), /lp navi flammenschlund, bei mehreren Treffern /lp navi 2"

CLIENT.T318 = "Im Spiel: /lp navi 50 50 Brachland (von Durotar) – im Guide unter dem Ziel „Reise ~m:ss: … → …“, die Zeit wird alle 10 s neu gerechnet"

CLIENT.T317 = "Im Classic-Era-Client: Einstellungen > Server & Dungeons ohne Schalter „Server WoW Forever“; Daten-Seite ohne „WoW-Forever-Quests“"

CLIENT.T316 = "Im Classic-Era-Client (Nutzer seit 10:36): nach dem ersten Einloggen steht in SavedVariables/LevelPilot.lua ein Bereich „era“; Forever-Wege erscheinen dort nicht"

CLIENT.T315 = "Nur im Classic-Era-Client prüfbar (Nutzer hat keinen): NPCs in Mulgore/Sturmwind stehen am richtigen Ort – Verdacht, zu messen"

CLIENT.T314 = "/lp navi 45 60 Brachland: Pfeil zum Punkt, oben im Guide „Wegpunkt 45.0, 60.0 · Brachland“; /lp navi briefkasten: nächster Briefkasten; /lp navi aus: Route geht weiter"

CLIENT.T313 = "Nach einer Spielstunde /lp protokoll: Zeile „UMWEG je Zone …“ mit gemessenen Zonen (n Paare), Werte zwischen 1,0 und 1,8"

CLIENT.T312 = "WoW Forever: /lp testroutine – T312 zeigt „STRASSEN Kontinent … Knoten (… ohne Zone …)“; „ohne Zone“ fast 0 (sonst liefert C_Map.GetMapInfoAtPosition nichts)"

CLIENT.T311 = "Mit bekannten Flugpunkten ein Ziel weit weg wählen, /lp protokoll: Zeile „REISE letzter Flugvergleich: Laufen x s · Fliegen y s (Flugzeit gemessen) …“ passt zur Wahl; auf dem Reittier „Tempo 11,2 yd/s (Reittier gemessen)“"

-- TU8: je Bereich eine Zeile "OK n · FEHLER n · SKIP n"
function TR:TULines(T)
    local byId = {}
    for _, r in ipairs(T.results) do byId[r.id] = r.status end
    local out = {}
    for _, key in ipairs({ "TU1", "TU2", "TU3", "TU4", "TU5", "TU6", "TU7" }) do
        local ok, fe, sk, cl = 0, 0, 0, 0
        for _, id in ipairs(TR.TU[key]) do
            local st = byId[id]
            if st == "OK" then ok = ok + 1 elseif st == "FEHLER" then fe = fe + 1
            elseif st == "CLIENT" then cl = cl + 1 elseif st then sk = sk + 1 end
        end
        out[#out + 1] = ("%s %s: OK %d · FEHLER %d · SKIP %d%s"):format(key, TR.TU_NAMES[key], ok, fe, sk, cl > 0 and (" · im Client %d"):format(cl) or "")
    end
    out[#out + 1] = TR.regressionLine or "Regressionen: nicht geprüft"
    return out
end

------------------------------------------------------------------------
-- 3.12.16: graue Gegenstände automatisch verkaufen (Comfort:SellGrey), alles mit Testtaschen und eigener Uhr
------------------------------------------------------------------------
-- Testtasche: Platz -> Gegenstand; eigene Zeitschlange statt C_Timer; LP:Print mitgeschrieben
local GREY_LINK = "|cff9d9d9d|Hitem:999101::::::::|h[Testplunder]|h|r"
local function GreyBag()
    return {
        [1] = { id = 999101, count = 1, quality = 0, link = GREY_LINK },                       -- verkaufen
        [2] = { id = 999102, count = 1, quality = 0, link = GREY_LINK, noValue = true },       -- kein Wert
        [3] = { id = 999103, count = 1, quality = 0, link = GREY_LINK, locked = true },        -- gesperrt
        [4] = { id = 999104, count = 1, quality = 1, link = "|cffffffff|Hitem:999104::::::::|h[Weiß]|h|r" },
        [5] = { id = 999105, count = 1, quality = 2, link = "|cff1eff00|Hitem:999105::::::::|h[Grün]|h|r" },
        [6] = { id = 999106, count = 3, quality = 0, link = GREY_LINK },                       -- verkaufen
    }
end
local function WithGreyShop(bag, open, body)
    local C, API = LP.Comfort, LP.API
    local queue, printed = {}, {}
    local timer = { After = function(_, fn) queue[#queue + 1] = fn end }
    local oSlots, oItem, oPrint, oOpen, oRun = API.BagSlots, API.BagItem, LP.Print, C.merchantOpen, C.sellRun
    API.BagSlots = function(b) return b == 0 and 6 or 0 end
    API.BagItem = function(b, sl) return b == 0 and bag[sl] or nil end
    LP.Print = function(_, msg) printed[#printed + 1] = tostring(msg) end
    C.merchantOpen, C.sellRun = open, nil
    local function drain(max)
        local n = 0
        while #queue > 0 and n < (max or 50) do
            local fn = table.remove(queue, 1)
            fn() n = n + 1
        end
        return n
    end
    return Guard(function()
        return WithEnv({ C.SellGrey }, { C_Timer = timer, GetMoney = function() return 12345 end }, function()
            return body(C, drain, printed, queue)
        end)
    end, function()
        API.BagSlots, API.BagItem, LP.Print, C.merchantOpen, C.sellRun = oSlots, oItem, oPrint, oOpen, oRun
    end)
end

IMPL.T230 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain, printed)
                local mark = ActMark()
                local real = LP.Act.real
                local run = C:SellGrey()
                drain()
                local sold = ActSince(mark, "Sell")
                local line = #printed == 1 and printed[1] or nil
                local listed = run and #run.list or 0
                local ok = run ~= nil and listed == 2 and sold == 2 and run.sold == 2 and line ~= nil and line:find("2", 1, true) ~= nil
                    and LP.Act.real == real
                return ok, string.format("Liste %d, verkauft %d, Zeilen %d (%s)", listed, sold, #printed, S(line)),
                    "Liste 2 (nur Qualität 0 mit Wert, ungesperrt), verkauft 2, 1 Zeile"
            end)
        end)
    end)
end

IMPL.T231 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain, printed)
                local mark = ActMark()
                -- /lp grau schaltet aus (Chatzeile der Umschaltung zählt nicht als Verkaufszeile)
                SlashCmdList.LEVELPILOT("grau")
                local off = LP.db.autoSellGrey
                local n0 = #printed
                local run = C:SellGrey()
                drain()
                local sold = ActSince(mark, "Sell")
                SlashCmdList.LEVELPILOT("grau")
                local back = LP.db.autoSellGrey
                local empty = WithSetting({ autoSellGrey = true }, function()
                    return WithGreyShop({}, true, function(C2, drain2, printed2)
                        local r = C2:SellGrey() drain2()
                        return r == nil and #printed2 == 0
                    end)
                end)
                return off == false and run == nil and sold == 0 and #printed == n0 + 1 and back == true and empty,
                    string.format("aus %s, Lauf %s, verkauft %d, Zeilen %d, wieder an %s, leere Tasche ohne Zeile %s",
                        S(not off), S(run), sold, #printed - n0, S(back), S(empty)),
                    "aus true, Lauf nil, verkauft 0, Zeilen 1 (Umschaltung), wieder an true, leere Tasche true"
            end)
        end)
    end)
end

IMPL.T232 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain, printed)
                local mark = ActMark()
                local run = C:SellGrey()                  -- erster Gegenstand sofort
                CallHandlers("MERCHANT_CLOSED")            -- Händler zu
                drain()
                local sold = ActSince(mark, "Sell")
                return run ~= nil and sold == 1 and run.done == true and C.merchantOpen == false,
                    string.format("verkauft %d von %d, beendet %s, Händler offen %s", sold, run and #run.list or 0,
                        S(run and run.done), S(C.merchantOpen)),
                    "verkauft 1 von 2, beendet true, Händler offen false"
            end)
        end)
    end)
end

IMPL.T233 = function()
    return WithSetting({ autoSellGrey = true }, function()
        return WithGreyShop(GreyBag(), true, function(C, drain, printed)
            local mark = ActMark()
            local inCombat = WithCombat(true, function() return C:SellGrey() end)
            local sold1 = ActSince(mark, "Sell")
            local run, sold2
            WithCombat(false, function() run = C:SellGrey() end)   -- erster Gegenstand
            WithCombat(true, function() drain() end)               -- Kampf beginnt: Rest bleibt liegen
            sold2 = ActSince(mark, "Sell")
            return inCombat == nil and sold1 == 0 and run ~= nil and sold2 == 1,
                string.format("im Kampf Lauf %s, verkauft %d; Kampfbeginn: verkauft %d", S(inCombat), sold1, sold2),
                "im Kampf Lauf nil, verkauft 0; Kampfbeginn: verkauft 1"
        end)
    end)
end

IMPL.T234 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain)
                local mark, real = ActMark(), LP.Act.real
                C:SellGrey() drain()
                local logged = ActSince(mark, "Sell")
                -- kein eigener Knopf oder Rahmen am Händlerfenster
                local attached = 0
                local mf = _G.MerchantFrame
                for name, f in pairs(_G) do
                    if type(name) == "string" and name:find("^LevelPilot") and type(f) == "table" and f.GetParent then
                        local ok, p = pcall(f.GetParent, f)
                        if ok and p and mf and p == mf then attached = attached + 1 end
                    end
                end
                return logged == 2 and LP.Act.real == real and attached == 0,
                    string.format("mitgeschrieben %d, echt ausgeführt %d, LevelPilot-Rahmen am Händlerfenster %d",
                        logged, LP.Act.real - real, attached),
                    "mitgeschrieben 2, echt ausgeführt 0, Rahmen 0"
            end)
        end)
    end)
end
CLIENT.T234 = "Händler öffnen: graue Gegenstände verschwinden, Chatzeile „N graue Gegenstände verkauft für …“, Reiter Händler/Rückkauf frei sichtbar"

IMPL.T223 = function()
    local Se = LP.Session
    -- Köder: Tabellen gelten als geschützt; ein ungeschützter Wahrheitstest wäre in Forever ein Lua-Fehler,
    -- hier fällt er dadurch auf, dass der Köder (eine Tabelle) als "wahr" durchgeht
    local bait = { "LPTestKoeder Wahrheitswert" }
    local fake = {}
    for _, f in ipairs({ "UnitIsAFK", "UnitOnTaxi", "UnitIsDeadOrGhost", "UnitIsDead", "UnitIsGhost", "UnitAffectingCombat",
                         "UnitInVehicle", "UnitIsPlayer", "UnitPlayerControlled" }) do
        fake[f] = function() return bait end
    end
    fake.UnitExists = function() return true end
    return WithSecret({ bait }, function()
        local bad = {}
        local function try(name, fns, body)
            local ok, err = pcall(WithEnv, fns, fake, body)
            if not ok then bad[#bad + 1] = name .. ": " .. tostring(err):sub(1, 60) end
            return ok, err
        end
        local afk
        Se.MarkActive()
        try("Session:IsAFK", { Se.IsAFK }, function() afk = Se:IsAFK() end)
        try("LP:InCombat", { LP.InCombat }, function() LP:InCombat() end)
        local rec
        try("Recorder", { LP.Recorder.CanRecord }, function() rec = WithSetting({ recordPaths = true }, function() return LP.Recorder.CanRecord() end) end)
        try("Navigation:Excluded", { LP.Nav.Excluded }, function() LP.Nav.Excluded() end)
        try("Calib:ObserveUnit", { LP.Calib.ObserveUnit }, function() LP.Calib:ObserveUnit("target") end)
        try("Plates:ForUnit", { LP.Plates.ForUnit }, function() LP.Plates:ForUnit("target", true, {}) end)
        try("Measure", { LP.Measure.UnitLine }, function() LP.Measure.UnitLine("target") end)
        local ok = #bad == 0 and afk == false and rec == true
        return ok, #bad == 0 and ("kein Fehler, AFK aus dem Leerlauf: " .. S(afk)) or table.concat(bad, "; "), "kein Fehler, AFK false (gerade aktiv)"
    end)
end

------------------------------------------------------------------------
-- K. Oberfläche im echten Client (UICheck.lua). Ohne echten Client ehrlich übersprungen, nie als OK gezählt.
------------------------------------------------------------------------
TR.UI = { T224 = true, T225 = true, T226 = true, T227 = true }        -- brauchen Fenster, Rechtecke, Tooltip
local UI_SKIP = "nur im echten Client (Fenster, Rechtecke, Tooltip)"
local function UIList(problems) return #problems == 0 and "keine" or table.concat(problems, "; ") end
-- Guide und Zentrale offen (alle Reiter einmal gebaut), danach wie vorher
local function WithOpenUI(body)
    local UIm = LP.UI
    local was = UIm:IsShown()
    return Guard(function()
        if not UIm:IsShown() then UIm:Toggle() end
        return WithCenter(function()
            LP.Center:Select("route")
            LP.UICheck.Collect()
            return body()
        end)
    end, function() if UIm:IsShown() ~= was then UIm:Toggle() end end, true)   -- 3.12.94: nur echte Fenster, darf abgeben
end
local function UICase(fn)
    return function()
        return WithOpenUI(function()
            -- 3.12.94 (Ingametest 3.12.93: T224–T227 bis 101 ms in einem Bild): Prüfung als freigegebene Rechnung (UICheck gibt je
            -- Element ab, Art "svc")
            local problems, tested, hints = Coop(fn)
            return #problems == 0, UIList(problems) .. " · geprüft " .. tostring(tested)
                .. (hints and #hints > 0 and (" · Hinweise: " .. table.concat(hints, "; "):sub(1, 300)) or ""), "keine"
        end)
    end
end
IMPL.T224 = UICase(function() return LP.UICheck.TooltipsCoverNothing() end)
IMPL.T225 = UICase(function() return LP.UICheck.WindowsOverlapNothing() end)
IMPL.T226 = UICase(function() return LP.UICheck.InsideScreen() end)
IMPL.T227 = UICase(function() return LP.UICheck.TextFits() end)
IMPL.T228 = function()
    local problems, tested = LP.UICheck.ValuesPlausible()
    return #problems == 0, UIList(problems) .. " · geprüft " .. tested, "keine"
end
IMPL.T229 = function()
    local problems, n = LP.UICheck.NoErrorLoops()
    return #problems == 0, UIList(problems) .. " · Meldungen " .. n, "keine"
end

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
local function GT() return _G.GoldSentinelTest end
local AREAS = "abcdefghijk"

function TR:CanStart(silent)
    if LP:InCombat() then
        if not silent then LP:Reply(L["Testroutine nur ausserhalb des Kampfes."]) end
        return false
    end
    if LP.Virtual and LP.Virtual.active then
        if not silent then LP:Reply(L["Testroutine: Es läuft gerade eine virtuelle Reise."]) end
        return false
    end
    if self.running then
        if not silent then LP:Reply(L["Testroutine läuft bereits."]) end
        return false
    end
    if not GT() then
        if not silent then LP:Reply(L["GoldSentinelTest.lua fehlt – keine Testroutine möglich."]) end
        return false
    end
    return true
end

-- eine Prüfung eintragen
local function RunOne(T, e)
    local id, area, name = e[1], e[2], e[3]
    if TR.LONG[id] and not TR.long then
        T:Skip(id, area, name, LONG_ONLY)
    elseif TR.UI[id] and not LP.UICheck.Available() then
        T:Skip(id, area, name, UI_SKIP)
    elseif IMPL[id] then
        local fn = IMPL[id]
        local autoOK, autoText
        -- erster Rückgabewert immer als true/false (nil aus "a and b" darf nicht als OK gelten)
        local naReason
        -- 3.12.93: die Prüfung läuft vorab über TR.PCall (darf an TR.Safe-Stellen abgeben; T:Check selbst nutzt pcall und
        -- könnte das nicht). T:Check wertet danach nur das Ergebnis aus; die Rechenzeit ohne Pausen kommt in den Bericht.
        local p0, t0 = TR.pausedMs, Ms()
        local syncBefore = TR.SyncTestNamesIn()           -- 3.12.96: Sicherheitsnetz Sync-Adressbuch
        local res = { PCallY(fn) }
        local cpu = (Ms() - t0) - (TR.pausedMs - p0)
        local leaked = TR.SyncLeakCheck(id, syncBefore)
        if leaked > 0 then
            res = { true, false, ("Sync-Adressbuch: %d Testname(n) gelernt und entfernt (%s)"):format(leaked,
                table.concat(TR.syncLeaks, ", ", math.max(1, #TR.syncLeaks - leaked + 1))), "kein Testname im Adressbuch" }
        end
        local passed = T:Check(id, area, name, function()
            if not res[1] then error(res[2], 0) end
            local a, b, c = res[2], res[3], res[4]
            if a == NA then naReason = tostring(b or "") return true, b end
            if a then autoOK, autoText = true, b return true, b end
            return false, b, c
        end)
        do
            local last = T.results[#T.results]
            if last and last.id == id then last.ms = string.format("%.1f", cpu) end
        end
        -- in dieser Lage nicht prüfbar: als übersprungen zählen (nicht als OK)
        if passed and naReason then
            local last = T.results[#T.results]
            T.counts.ok = T.counts.ok - 1
            if last and last.id == id and last.status == "OK" then
                last.status, last.grund, last.ergebnis = "SKIP", naReason .. TR.NA_SUFFIX, nil
                T.counts.uebersprungen = T.counts.uebersprungen + 1
            else
                T:Skip(id, area, name, naReason .. TR.NA_SUFFIX)
            end
            return
        end
        -- automatischer Teil OK, Rest im Client (auto + halb): zusätzlich als "im Client prüfen" eintragen
        if passed and CLIENT[id] and T.results[#T.results] and T.results[#T.results].id == id then
            T.results[#T.results].status = "CLIENT"
            T.counts.ok, T.counts.client = T.counts.ok - 1, T.counts.client + 1
            T.results[#T.results].anleitung = CLIENT[id] .. " (automatischer Teil OK" .. (autoText and (": " .. tostring(autoText)) or "") .. ")"
        end
    elseif CLIENT[id] then T:Client(id, area, name, CLIENT[id])
    elseif SKIP[id] then T:Skip(id, area, name, SKIP[id])
    else
        TR.notYet = (TR.notYet or 0) + 1
        T:Skip(id, area, name, NOT_YET)
    end
end

-- Sandbox: echte Daten sichern / in place zurückschreiben / vergleichen
local function Copy(v) return LP.Backup.DeepCopy(v) end
local function RestoreInto(cur, saved)
    for k in pairs(cur) do if saved[k] == nil then cur[k] = nil end end
    for k, v in pairs(saved) do
        if type(v) == "table" and type(cur[k]) == "table" and getmetatable(cur[k]) == nil then RestoreInto(cur[k], v)
        else cur[k] = v end
    end
end

-- 3.12.21: GoldSentinelSync sendet selbst (gemeinsame Warteschlange). Waehrend der Testroutine gehen eigene
-- Nachrichten nur ins Mitschreiben (LP.Act, trocken); ersetzt wird nur GoldSentinelSync.api.send, nie Blizzard.
local function SyncDry()
    local Sy = _G.GoldSentinelSync
    if not Sy or type(Sy.api) ~= "table" or Sy.api.lpDry then return nil end
    local orig = Sy.api.send
    local wrap = function(prefix, msg, dist, target)
        if OWN_PREFIX[prefix] and LP.Act.dry then
            LP.Act.Call("SendAddonMessage", orig, prefix, msg, dist, target)
            return true
        end
        return orig(prefix, msg, dist, target)
    end
    Sy.api.send, Sy.api.lpDry = wrap, true
    -- 3.12.22: eigene leere Warteschlangen fuer die Dauer der Routine (Felder der gemeinsamen Tabelle). Tests pumpen
    -- so nur Testnachrichten; echte Nachrichten (auch anderer Addons) warten in den echten Tabellen.
    local h = { api = Sy.api, orig = orig, sy = Sy, queue = Sy.queue, netQueue = Sy.netQueue }
    Sy.queue, Sy.netQueue = {}, {}
    return h
end
local function SyncUndo(h)
    if not h then return end
    if h.api then h.api.send, h.api.lpDry = h.orig, nil end
    local Sy = h.sy
    if Sy and h.queue then
        -- was andere Addons waehrend der Routine eingereiht haben, kommt in die echten Tabellen
        for _, pair in ipairs({ { Sy.queue, h.queue }, { Sy.netQueue, h.netQueue } }) do
            local tmp, real = pair[1], pair[2]
            if type(tmp) == "table" and type(real) == "table" and tmp ~= real then
                for _, it in ipairs(tmp) do
                    if type(it) == "table" and not OWN_PREFIX[it.prefix] and it.prefix ~= Sy.CTRL then real[#real + 1] = it end
                end
            end
        end
        Sy.queue, Sy.netQueue = h.queue, h.netQueue
    end
end
TR.SyncDry, TR.SyncUndo = SyncDry, SyncUndo

-- 3.12.93 (Ingametest 3.12.91 Punkt 1: "Sandbox und Bericht" 2372 ms in EINEM Bild): Sicherung, Zurückschreiben und Vergleich
-- in Portionen. Nachbau mit den Laptop-Daten (3.12.92, am Stück): Sicherung 95 ms (vor dem ersten gezählten Bild), Zurückschreiben
-- 173 ms, Vergleich über GoldSentinelTest.Encode 1291 ms (graph 1011 ms, wegeSent 242 ms – je Schlüssel zweimal kodiert).
-- Jetzt: Kopieren/Zurückschreiben/Vergleichen Eintrag für Eintrag mit check() alle SB_STEP Einträge (TR.Safe). Die Schlüssel
-- jeder Tabelle werden vorher gesammelt: über eine Tabelle, in die anderer Code in einer Pause schreibt, darf pairs nicht über
-- die Pause hinweg laufen. Der Vergleich ist genau (Zahlen exakt statt 6 Stellen, jede Tiefe; NaN = NaN).
local SB_STEP = 256
local sbn = 0
local function SbTick(check)
    sbn = sbn + 1
    if sbn >= SB_STEP then sbn = 0 if check then check() end end
end
local function Keys(t) local ks = {} for k in pairs(t) do ks[#ks + 1] = k end return ks end
local function CopyP(v, check)
    if type(v) ~= "table" then return v end
    local t, ks = {}, Keys(v)
    for i = 1, #ks do
        local k = ks[i]
        local x = v[k]
        if x ~= nil then t[k] = CopyP(x, check) end          -- in einer Pause gelöscht: nicht mitnehmen
        SbTick(check)
    end
    return t
end
-- gleich bis in jede Tiefe (b = echte Daten); a wird nur von der Testroutine benutzt
local function SameP(a, b, check)
    if a == b then return true end
    local ta = type(a)
    if ta ~= type(b) then return false end
    if ta == "number" then return a ~= a and b ~= b end     -- NaN
    if ta ~= "table" then return false end
    local ka = Keys(a)
    for i = 1, #ka do
        local k = ka[i]
        if not SameP(a[k], b[k], check) then return false end
        SbTick(check)
    end
    local na, nb = 0, 0
    for _ in pairs(a) do na = na + 1 end
    for _ in pairs(b) do nb = nb + 1 end
    return na == nb
end
-- in place zurückschreiben (wie RestoreInto, eigene Kopien der gesicherten Werte – die Sicherung bleibt für den Vergleich)
local function RestoreP(cur, saved, check, skip)
    local kc = Keys(cur)
    for i = 1, #kc do local k = kc[i] if k ~= skip and saved[k] == nil then cur[k] = nil end end
    local ks = Keys(saved)
    for i = 1, #ks do
        local k = ks[i]
        if k ~= skip then
            local v = saved[k]
            if type(v) == "table" and type(cur[k]) == "table" and getmetatable(cur[k]) == nil then RestoreP(cur[k], v, check)
            else cur[k] = CopyP(v, check) end
        end
        SbTick(check)
    end
end
TR.CopyP, TR.SameP, TR.RestoreP = CopyP, SameP, RestoreP

local function Snapshot(check)
    local sb = { acc = {}, char = CopyP(LevelPilotCharDB, check), enc = {}, encChar = nil }
    local ks = Keys(LevelPilotDB)
    for i = 1, #ks do
        local k = ks[i]
        local v = LevelPilotDB[k]
        if k ~= "gsTest" and v ~= nil then sb.acc[k] = CopyP(v, check) end
    end
    sb.debug, sb.mode = LP.debug, LP.char.mode
    local P = LP.Planner
    sb.focus, sb.priority, sb.leftZones = P.focus, P.priority, P.leftZones and Copy(P.leftZones)
    sb.queue = LP.Comm.QueueSnapshot and LP.Comm:QueueSnapshot() or nil
    sb.language = LP.db.language
    return sb
end

local function AfterRestore(sb)
    LP:LoadSaved(LP.Acc(), LevelPilotCharDB)   -- 3.12.56: Bereich der Spielversion (Era: LevelPilotDB.era)
    LP.debug = sb.debug
    local P = LP.Planner
    P.focus, P.priority = sb.focus, sb.priority
    if sb.leftZones then P.leftZones = sb.leftZones end
end

-- am Stück (Fehlerfall der Routine und Wiederholung einzelner Schlüssel)
local function Restore(sb)
    local accSaved = {}
    for k, v in pairs(sb.acc) do accSaved[k] = Copy(v) end
    accSaved.gsTest = LevelPilotDB.gsTest                       -- der neue Bericht bleibt stehen
    RestoreInto(LevelPilotDB, accSaved)
    RestoreInto(LevelPilotCharDB, Copy(sb.char))
    AfterRestore(sb)
end

-- 3.12.93: in Portionen (check = TR.Safe); der neue Bericht (gsTest) bleibt stehen
local function RestorePortions(sb, check)
    RestoreP(LevelPilotDB, sb.acc, check, "gsTest")
    RestoreP(LevelPilotCharDB, sb.char, check)
    AfterRestore(sb)
end

-- 3.12.93: Vergleich in Portionen. Weicht ein Schlüssel ab, kann das auch anderer Code gewesen sein, der in einer Pause echte Daten
-- schrieb (zwischen Zurückschreiben und Vergleich lagen Bilder). Dann diesen Schlüssel EINMAL am Stück zurückschreiben und am Stück
-- vergleichen: bleibt er verschieden, ist es ein Fehler der Wiederherstellung; sonst steht er im Bericht unter "wiederholt".
local function Diff(sb, check)
    local bad, again = {}, {}
    local keys, seen = {}, {}
    for k in pairs(sb.acc) do if not seen[k] then seen[k] = true keys[#keys + 1] = k end end
    for k in pairs(LevelPilotDB) do if k ~= "gsTest" and not seen[k] then seen[k] = true keys[#keys + 1] = k end end
    local function Redo(k)
        if k == "LevelPilotCharDB" then RestoreInto(LevelPilotCharDB, Copy(sb.char)) return SameP(sb.char, LevelPilotCharDB) end
        if sb.acc[k] == nil then LevelPilotDB[k] = nil
        elseif type(sb.acc[k]) == "table" and type(LevelPilotDB[k]) == "table" and getmetatable(LevelPilotDB[k]) == nil then
            RestoreInto(LevelPilotDB[k], Copy(sb.acc[k]))
        else LevelPilotDB[k] = Copy(sb.acc[k]) end
        return SameP(sb.acc[k], LevelPilotDB[k])
    end
    for _, k in ipairs(keys) do
        if not SameP(sb.acc[k], LevelPilotDB[k], check) then
            if Hold(Redo, k) then again[#again + 1] = tostring(k) else bad[#bad + 1] = tostring(k) end
        end
        if check then check() end
    end
    if not SameP(sb.char, LevelPilotCharDB, check) then
        if Hold(Redo, "LevelPilotCharDB") then again[#again + 1] = "LevelPilotCharDB" else bad[#bad + 1] = "LevelPilotCharDB" end
    end
    if #again > 0 then AfterRestore(sb) end
    if LP.char ~= LevelPilotCharDB then bad[#bad + 1] = "LP.char" end
    if type(LP.Acc().taxi) == "table" and getmetatable(LP.Acc().taxi) ~= nil then bad[#bad + 1] = "taxi (Überlagerung)" end
    if LP.db.language ~= sb.language then bad[#bad + 1] = "language" end
    table.sort(bad)
    table.sort(again)
    local tail = #again > 0 and (" (wiederholt: " .. table.concat(again, ", ") .. ")") or ""
    return (#bad == 0 and "OK" or ("FEHLER: " .. table.concat(bad, ", "))) .. tail
end
TR.Diff = Diff

-- Beobachtung echter Spielereignisse während des Laufs
local watch = CreateFrame("Frame")
local WATCH = { PLAYER_REGEN_DISABLED = "Kampf begonnen", QUEST_TURNED_IN = "echtes Spielereignis während des Tests",
                PLAYER_LEVEL_UP = "echtes Spielereignis während des Tests", QUEST_ACCEPTED = "echtes Spielereignis während des Tests",
                TAXIMAP_OPENED = "echtes Spielereignis während des Tests" }
watch:SetScript("OnEvent", function(_, ev) if TR.running and not TR.abort then TR.abort = WATCH[ev] end end)

-- direkte Aufrufe an LP.Act vorbei zählen (nur während des Laufs; hooksecurefunc ersetzt nichts)
local hooked = false
TR.direct = 0
local function InstallHooks()
    if hooked or not hooksecurefunc then return end
    hooked = true
    local function count() if TR.running then TR.direct = TR.direct + 1 end end
    for _, n in ipairs({ "BuyMerchantItem", "RepairAllItems", "TakeTaxiNode", "AcceptQuest", "CompleteQuest", "GetQuestReward",
                         "EquipItemByName", "QuestLogPushQuest" }) do
        if type(_G[n]) == "function" then pcall(hooksecurefunc, n, count) end
    end
end

-- 3.12.90: ein Bild der Routine zählen (Dauer d ms, Schritt self.cur, Bereich self.curArea)
-- 3.12.93 (Ingametest 3.12.91 Punkt 5): dazu Bilder über 40 ms (Grenze des Nutzers)
TR.FRAME_WARN = 16
TR.FRAME_LIMIT = 40
function TR:CountFrame(d)
    local f = self.frames
    if not f or type(d) ~= "number" then return end
    f.n = f.n + 1
    local step, ar = tostring(self.cur or "?"), tostring(self.curArea or "?")
    -- 3.13.1 (Ingametest 3.13.0 Punkt 3b: Kopfzeile "(T355)", Takt "(T354 graph–T355)"): längstes Bild wie im Takt von der Prüfung am
    -- Ende des vorigen Bildes bis zur Prüfung am Ende dieses Bildes
    local from = f.lastStep
    f.lastStep = step
    if d > f.max then f.max, f.maxStep = d, (from and from ~= step) and (from .. "–" .. step) or step end
    if d > TR.FRAME_WARN then
        if not f.over[step] then f.order[#f.order + 1] = step end
        f.over[step] = math.max(f.over[step] or 0, d)
    end
    if d > TR.FRAME_LIMIT then f.over40 = (f.over40 or 0) + 1 end
    -- 3.12.95 (Nachbau 3.12.95: lange Bilder bei T128/T129 fallen mit der Speicherbereinigung zusammen, Speicher fällt im Bild um
    -- 46–57 MB): fällt der Speicher seit dem letzten Bild um mehr als 1 MB, steht das beim Bild über 40 ms dabei (Beleg für den Ingametest)
    local mem = collectgarbage("count")
    local dm = f.lastMem and (mem - f.lastMem) or 0
    f.lastMem = mem
    if d > TR.FRAME_LIMIT and dm < -1024 then
        f.gc = f.gc or {}
        f.gc[#f.gc + 1] = { step = step, ms = d, mb = dm / 1024 }
    end
    if not f.area[ar] then f.area[ar] = 0 f.areaOrder = f.areaOrder or {} f.areaOrder[#f.areaOrder + 1] = ar end
    f.area[ar] = f.area[ar] + d
end
-- Zeilen für Chat und Bericht: Bilder, längstes Bild, Schritte über 16 ms (höchstens 12, längste zuerst), Bilder über 40 ms,
-- Zeit je Bereich
function TR:FrameLines()
    local f = self.frames
    if not f or f.n == 0 then return nil end
    local over = {}
    for _, st in ipairs(f.order) do over[#over + 1] = st end
    table.sort(over, function(a, b) return f.over[a] > f.over[b] end)
    local parts = {}
    for i = 1, math.min(12, #over) do parts[#parts + 1] = ("%s %.0f ms"):format(over[i], f.over[over[i]]) end
    local lines = { L("Portionen: %d Bilder, längstes %.1f ms (%s), Schritte über %d ms: %d%s", f.n, f.max, tostring(f.maxStep),
        TR.FRAME_WARN, #over, #parts > 0 and (" – " .. table.concat(parts, ", ") .. (#over > 12 and " …" or "")) or "")
        .. " · " .. L("Bilder über %d ms: %d", TR.FRAME_LIMIT, f.over40 or 0) }
    local ap = {}
    for _, ar in ipairs(f.areaOrder or {}) do ap[#ap + 1] = ("%s %.1f s"):format(ar, f.area[ar] / 1000) end
    if #ap > 0 then lines[#lines + 1] = L("Rechenzeit je Bereich: %s", table.concat(ap, " · ")) end
    if f.gc and #f.gc > 0 then
        local g = {}
        for i, e in ipairs(f.gc) do g[i] = e end
        table.sort(g, function(a, b) return a.ms > b.ms end)
        local gp = {}
        for i = 1, math.min(8, #g) do gp[i] = ("%s %.0f ms (%.0f MB)"):format(g[i].step, g[i].ms, g[i].mb) end
        lines[#lines + 1] = L("Bilder über %d ms, in denen der Speicher fiel (Speicherbereinigung): %d – %s", TR.FRAME_LIMIT, #g,
            table.concat(gp, ", ") .. (#g > 8 and " …" or ""))
    end
    return lines
end

-- 3.12.93: Aufräumen nach einem Abbruch der Routine (Fehler ausserhalb einer Prüfung, Zeitlimit, Takt abgebrochen)
function TR:Abort(st, err)
    local A = LP.Act
    A.dry = false
    if st.sb and st.sb.queue and LP.Comm.QueueRestore then pcall(LP.Comm.QueueRestore, LP.Comm, st.sb.queue) end
    SyncUndo(self.syncDry) self.syncDry = nil TR.syncHandle = nil
    if self.jobsSync ~= nil then LP.Jobs.sync = self.jobsSync self.jobsSync = nil end
    LP.Jobs.manual = false
    if st.sb then pcall(Restore, st.sb) end        -- am Stück: Fehlerfall, die echten Daten gehen vor
    self.running = false
    self.job = nil
    TR.hold, TR.coop, TR.coopPause = 0, 0, false
    if LP.Jobs.FlushDeferred then LP.Jobs.FlushDeferred() end     -- 3.12.95: zurückgestellte Aufträge starten
    LP.testGen = LP.testGen + 1
    for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
    LP:Error("Testroutine", err)
end

function TR:Run(area, long, alles)
    if not LP:DevOnly() or not self:CanStart() then return end
    area = area and area:upper() or nil
    if area and not AREAS:upper():find(area, 1, true) then area = nil end
    local A = LP.Act
    self.running, self.abort, self.direct, self.notYet, self.long = true, nil, 0, 0, long and true or false
    self.alles = alles and true or false
    LP.testGen = LP.testGen + 1
    A.dry, A.log, A.dryCount = true, {}, 0
    self.syncDry = SyncDry()
    -- 3.12.24: Arbeit in Portionen waehrend der Routine am Stueck (Tests erwarten das Ergebnis sofort)
    self.jobsSync = LP.Jobs.sync
    LP.Jobs.sync = true
    LP.Jobs.manual = true          -- 3.12.93: der Portionen-Treiber ruht; Tests treiben ihre Aufträge selbst an
    TR.syncHandle = self.syncDry
    local realBefore = A.real
    InstallHooks()
    for ev in pairs(WATCH) do pcall(watch.RegisterEvent, watch, ev) end
    local errBefore = LP.errorCount
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    LP:Reply(L["Testroutine läuft – bitte stillstehen …"])
    local st = {}                -- st.sb: Sicherung (entsteht in den ersten Bildern der Aufgabe)
    TR.hold, TR.coop, TR.coopPause, TR.pausedMs, TR.blockedT, TR.skipped, TR.deferred, TR.syncLeaks = 0, 0, false, 0, nil, 0, 0, nil

    -- Abgabe zwischen zwei Prüfungen bzw. an sicheren Stellen der Routine selbst (kein Ersatz-Zustand aktiv)
    local function yield() TR.Safe(self.cur) end
    -- 3.12.90 (Ingametest 3.12.89 Punkt 6, Pflicht nach TR-ALLE): je Bild die Rechenzeit der Routine messen – Anzahl Bilder, längstes
    -- Bild mit Schritt, Schritte über 16 ms mit Namen, Zeit je Bereich. Gemessen wird nur die eigene Arbeit (Fortsetzen der Routine).
    self.frames = { n = 0, max = 0, over = {}, area = {}, order = {}, over40 = 0 }
    TR.blockedSites = {}
    self.cur, self.curArea = L["Start"], L["Start"]
    local function body()
        -- 3.12.93: Sicherung in Portionen (vorher am Stück vor dem ersten Bild: Nachbau Laptop-Daten 95 ms)
        st.sb = Snapshot(yield)
        local sb = st.sb
        TR.FullGC()                                      -- 3.12.93: in Portionen
        self.memStart = collectgarbage("count")          -- nach der Sicherung (die Kopie zählt nicht als Zuwachs)
        -- virtuelle Reisen vorab (Warten ausserhalb jeder Prüfung)
        self.journey = nil
        self.cur, self.curArea = L["Reisen"], L["Reisen"]
        if not area or area == "B" or area == "H" or area == "J" then
            self:Journeys(function(cond, maxSec)
                local t0 = GetTime()
                while not cond() and GetTime() - t0 < maxSec and not self.abort do coroutine.yield() end
            end, self.long)
            -- Speicher (T157) ab hier: die Reisen füllen einmalig Zwischenspeicher (Wegenetz, Gefahrenkarte) und der
            -- letzte Reisebericht bleibt absichtlich für /lp reise bericht stehen
            TR.FullGC()
            self.memStart = collectgarbage("count")
        end
        -- 3.12.26 TU4: Grundregeln mit Zufallsfällen in Portionen (vor den Prüfungen, ausserhalb jedes pcall)
        self.inv = nil
        self.cur, self.curArea = L["Grundregeln"], L["Grundregeln"]
        if not area or area == "J" then
            levelIndex = nil
            self:Invariants(yield)
        end
        -- TR-ALLE A: Fortschritt je Bereich ("Bereich C – 3 von 11")
        local order, seenA, lastA = {}, {}, nil
        for _, e in ipairs(self.IDS) do
            if (not area or e[2] == area) and not seenA[e[2]] then seenA[e[2]] = true order[#order + 1] = e[2] end
        end
        local posA = {}
        for i, a in ipairs(order) do posA[a] = i end
        for _, e in ipairs(self.IDS) do
            if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" then
                if self.alles and e[2] ~= lastA then
                    lastA = e[2]
                    LP:Reply(L("Testroutine: Bereich %s – %d von %d …", e[2], posA[e[2]] or 0, #order))
                end
                self.cur, self.curArea = e[1], e[2]
                local TkL = Takt()
                if TkL and TkL.Label then TkL.Label(e[1]) end          -- Etikett der Takt-Messung = diese Prüfung
                if self.abort then T:Skip(e[1], e[2], e[3], self.abort)
                else RunOne(T, e) end
                yield()
            end
        end
        self.cur, self.curArea = L["Sandbox und Bericht"], L["Sandbox und Bericht"]
        -- Sandbox zurück und vergleichen (3.12.93: beides in Portionen)
        local ok, err = PCallY(RestorePortions, sb, yield)
        local sandbox
        if ok then
            local okD, d = PCallY(Diff, sb, yield)
            sandbox = okD and d or ("FEHLER: " .. tostring(d))
        else
            sandbox = "FEHLER: " .. tostring(err)
        end
        yield()
        -- Testfehler aus der Fehlerliste von GoldSentinelTest entfernen (sonst gelten sie als echte Fehler)
        local s = LevelPilotDB.gsTest
        if s and type(s.errors) == "table" then
            for k, v in pairs(s.errors) do
                local m = type(v) == "table" and tostring(v.msg) or ""
                if m:find("LP-Testfehler", 1, true) or (type(v) == "table" and v.wo == "Testroutine") then s.errors[k] = nil end
            end
        end
        pcall(LP.Protocol.LoadEntries, LP.Protocol)
        yield()
        -- Zustand des Spiels neu aufbauen. 3.12.93: direkt nach dem Zurückschreiben (vorher nach dem Bericht – das letzte Bild der
        -- Aufgabe kann der Bericht nicht mehr zählen), je Schritt eine Abgabe, Planung als freigegebene Rechnung (echte Daten)
        self.cur, self.curArea = L["Nachlauf"], L["Nachlauf"]
        pcall(LP.ResetLanguageCache, LP)
        yield()
        PCallY(Coop, LP.Planner.BuildCandidates, LP.Planner)
        yield()
        PCallY(Coop, LP.Planner.Replan, LP.Planner, true)
        yield()
        PCallY(Coop, LP.Nav.Recalc, LP.Nav, true)
        yield()
        pcall(LP.UI.Refresh, LP.UI)
        pcall(LP.Center.Refresh, LP.Center)
        yield()
        self.cur, self.curArea = L["Sandbox und Bericht"], L["Sandbox und Bericht"]
        -- T166: IDs eindeutig und vollständig
        if not area or area == "I" then
            T:Check("T166", "I", "Testfall-IDs eindeutig und vollständig", function()
                local seen, dup, miss = {}, {}, {}
                for _, r in ipairs(T.results) do
                    if seen[r.id] then dup[#dup + 1] = r.id end
                    seen[r.id] = true
                end
                for _, e in ipairs(self.IDS) do
                    if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" and not seen[e[1]]
                       and not (#T.results >= GT().MAX_RESULTS) then miss[#miss + 1] = e[1] end
                end
                return #dup == 0 and #miss == 0, "doppelt: " .. table.concat(dup, ",") .. " fehlend: " .. table.concat(miss, ","), "keine"
            end)
        end
        local extra = { sandbox = sandbox, sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
                        fehlerEindeutig = Count(LP.errors), initFehler = Count(LP.initErrors),
                        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version, modus = LP.char.mode,
                        bereich = area or "alle", echteAktionen = (A.real - realBefore) + self.direct,
                        nichtAutomatisiert = self.notYet }
        -- 3.12.93: Takt-Zeile der Routine (Bilder über 5/16/40 ms, längste mit Etikett, Abgabe nicht möglich) in den Bericht
        local Tk = Takt()
        if Tk and Tk.Summary and self.job then extra.takt = Tk.Summary(self.job) end
        -- 3.13.1 (Ingametest 3.13.0 Punkt 3b: Kopfzeile 3968 Bilder, Takt 3966): Kopfzeile im selben Augenblick wie die Takt-Zeile
        -- (vorher erst nach zwei weiteren Portionen des Berichts)
        local okFrames, frameLines = pcall(TR.FrameLines, TR)
        -- 3.12.99 (Hinweis 18.11. 19:30/19:55, GoldSentinelTakt 2): Ort, Spieler in Sicht, Ping, Bildzeit in Ruhe vor dem Lauf
        if Tk and Tk.EnvLine then
            local okE, env = pcall(Tk.EnvLine)
            if okE and env and env ~= "" then extra.umgebung = env end
        end
        extra.gesperrt = TR.BlockedLine(self.job)
        -- 3.13.5 (Auftrag 19.11. 12:42 Punkt 5): Wegabschnitte dieser Version (aufgezeichnet / verworfen je Grund)
        if LP.Recorder and LP.Recorder.StatLine then
            local okW, wl = pcall(LP.Recorder.StatLine)
            if okW and wl then extra.wege = wl end
        end
        -- T165: Bericht ohne Namen (vor Finish geprüft)
        if not area or area == "I" then
            T:Check("T165", "I", "Bericht gespeichert und datenschutzkonform", function()
                local enc = GT().Encode(T:Report(extra))
                local me = UnitName("player")
                local guild = GetGuildInfo and GetGuildInfo("player")
                local leak = (type(me) == "string" and me ~= "" and enc:find(me, 1, true)) or
                             (type(guild) == "string" and guild ~= "" and enc:find(guild, 1, true))
                local acts = (A.real - realBefore) + self.direct
                return not leak and acts == 0, "Namen im Bericht: " .. S(leak and true or false) .. ", echte Aktionen: " .. acts,
                    "keine Namen, 0 echte Aktionen"
            end)
        end
        yield()
        local text = T:Finish(extra)
        yield()
        -- TR-ALLE A: eine Zusammenfassung in Alltagssprache, dazu was noch von Hand offen ist (passiert beim normalen Spielen)
        local okS, sum = pcall(TR.SummaryLines, TR, T)
        local okF, fl = okFrames, frameLines
        if okS and sum and okF and fl then for _, l in ipairs(fl) do sum[#sum + 1] = l end end
        if okS and sum then
            text = table.concat(sum, "\n") .. "\n" .. text
            for _, l in ipairs(sum) do LP:Reply(l) end
        end
        -- Platzhalter zählen nicht als bestanden: eigene Zeile direkt unter der Zählung
        text = text:gsub("(OK %d+ · FEHLER %d+ · [^\n]*)", "%1\n" .. string.format("nicht automatisiert: %d", self.notYet), 1)
        -- 3.12.26 TU8: je Bereich TU1–TU7 eine Zeile
        local okTU, tu = pcall(self.TULines, self, T)
        if okTU then text = text .. "\n" .. table.concat(tu, "\n") end
        yield()
        -- 3.12.28 MN3: Marktdaten-Netz
        pcall(LP.MarktSync, LP)
        local okM, ml = pcall(LP.MarktLine, LP)
        if okM and ml then text = text .. "\n" .. ml end
        -- 3.12.31 ML1: Selbstkontrolle "Meldungen"
        local okG, mg = pcall(LP.MessagesLine, LP)
        if okG and mg then text = text .. "\n" .. mg end
        text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
            _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
        text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (vor dem Test %d, eindeutig %d), Modulstartfehler: %d",
            LP.errorCount, errBefore, Count(LP.errors), Count(LP.initErrors))
        text = text .. "\n" .. (sandbox == "OK" and "echte Daten unverändert: OK" or ("echte Daten unverändert: " .. sandbox:gsub("^FEHLER: ", "FEHLER – ")))
        text = text .. "\n" .. string.format("mitgeschriebene Aktionen: %d · echte Aktionen: %d", A.dryCount, (A.real - realBefore) + self.direct)
        if extra.takt then text = text .. "\n" .. "Takt: " .. extra.takt end
        if extra.umgebung then text = text .. "\n" .. extra.umgebung end
        if extra.gesperrt then text = text .. "\n" .. extra.gesperrt end
        if extra.wege then text = text .. "\n" .. extra.wege end
        text = text .. "\n" .. "Bitte /reload"
        self.lastText = text
        LP.testGen = LP.testGen + 1
        for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
        -- Nachlauf: Trockenlauf noch 5 s, dann Warteschlange von Comm auf den Stand vor dem Test
        C_Timer.After(5, function()
            A.dry = false
            if sb.queue and LP.Comm.QueueRestore then LP.Comm:QueueRestore(sb.queue) end
            SyncUndo(self.syncDry) self.syncDry = nil TR.syncHandle = nil
            if self.jobsSync ~= nil then LP.Jobs.sync = self.jobsSync self.jobsSync = nil end
            LP.Jobs.manual = false
            self.running = false
            if LP.Jobs.FlushDeferred then LP.Jobs.FlushDeferred() end     -- 3.12.95: zurückgestellte Aufträge starten
        end)
        yield()
        LP.Backup:ShowText(L["Testroutine"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
            .. " " .. L["Wird auch automatisch gemeldet."], text)
        LP:Reply(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet"])
    end
    -- 3.12.93: als EINE Aufgabe des gemeinsamen Takts (je Bild höchstens TR.BUDGET ms, Zeitlimit TR.TIMEOUT s)
    local Tk = Takt()
    if Tk then
        self.job = Tk.Start({
            name = "Testroutine", owner = "LevelPilot", budget = TR.BUDGET, timeout = TR.TIMEOUT, fn = body,
            env = TR.ENV_SEC,           -- 3.12.99: Takt 2 misst vorher TR.ENV_SEC s die Umgebung (ohne eigene Arbeit)
            onPortion = function(_, ms) TR:CountFrame(ms) end,
            onDone = function(job)
                if TR.job ~= job then return end
                TR.lastSummary = Tk.Summary(job)
                TR.job = nil
                if job.state ~= "fertig" then
                    TR:Abort(st, tostring(job.err or job.state) .. (job.trace and ("\n" .. tostring(job.trace)) or ""))
                end
            end,
        })
        return
    end
    -- ohne GoldSentinelTakt (sollte nicht vorkommen, die Datei steht in der .toc): eigene Portionen wie bis 3.12.92
    local co = coroutine.create(body)
    local ticker
    ticker = C_Timer.NewTicker(0.05, function()
        local t0 = Ms()
        local ok, err = coroutine.resume(co)
        TR:CountFrame(Ms() - t0)
        if not ok then
            ticker:Cancel()
            TR:Abort(st, err)
        elseif coroutine.status(co) == "dead" then
            ticker:Cancel()
        end
    end)
end

-- Kurztest für alle Spieler (/lp test): nur lesende Prüfungen, gleicher Bericht
function TR:Short()
    if not GT() then LP.SelfTest:Run() return end
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    for _, e in ipairs(self.IDS) do if self.SHORT[e[1]] then RunOne(T, e) end end
    local text = T:Finish({ bereich = "kurz", sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version })
    text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
        _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
    text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (eindeutig %d), Modulstartfehler: %d", LP.errorCount,
        Count(LP.errors), Count(LP.initErrors))
    LP.Backup:ShowText(L["Selbsttest"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
        .. " " .. L["Wird auch automatisch gemeldet."], text)
    return text
end

-- Halbautomatische Beobachtung (Launch-Abend): 2 Minuten, Aktionen mit Folgen nur mitgeschrieben (haendler, quest, flug)
local OBSERVE = { kampf = false, haendler = true, quest = true, flug = true, trainer = false, gruppe = false }
function TR:Observe(kind)
    if not LP:DevOnly() then return end
    if self.running then LP:Reply(L["Testroutine läuft bereits."]) return end
    local A = LP.Act
    local dry = OBSERVE[kind]
    self.running = true
    local err0, mark = LP.errorCount, #A.log
    if dry then A.dry = true end
    LP:Reply(L("Beobachtung „%s“ läuft 2 Minuten – jetzt die Aktion im Spiel ausführen.", kind))
    C_Timer.After(120, function()
        if dry then A.dry = false end
        self.running = false
        local names = {}
        for i = mark + 1, #A.log do names[#names + 1] = tostring(A.log[i].name) end
        LP:Reply(L("Beobachtung „%s“ beendet: neue Fehler %d, mitgeschriebene Aktionen: %s", kind, LP.errorCount - err0,
            #names > 0 and table.concat(names, ", ") or "–"))
    end)
end

-- TR-ALLE (Entscheid des Nutzers 17.11.2026 07:36, Nachtrag D 13:54): Zusammenfassung "x von y bestanden, z nicht prüfbar – Grund"
-- und die Punkte der Prüfliste, die noch von Hand offen sind – sie haken sich beim normalen Spielen selbst ab (Händler, Flugmeister …),
-- der Lauf wartet nie darauf.
TR.SLICE_MS = 5                       -- Portion je Bild (ms)
function TR:SummaryLines(T)
    local c = T.counts or {}
    local done = (c.ok or 0) + (c.fehler or 0)
    local reasons, order = {}, {}
    for _, r in ipairs(T.results or {}) do
        if r.status == "SKIP" then
            local g = tostring(r.grund or "?"):gsub(TR.NA_SUFFIX:gsub("%p", "%%%0"), "")
            g = g:sub(1, 60)
            if not reasons[g] then reasons[g] = 0 order[#order + 1] = g end
            reasons[g] = reasons[g] + 1
        end
    end
    table.sort(order, function(a, b) return reasons[a] > reasons[b] end)
    local why = {}
    for i = 1, math.min(3, #order) do why[#why + 1] = ("%s (%d)"):format(order[i], reasons[order[i]]) end
    local lines = { L("Ergebnis: %d von %d bestanden, %d nicht prüfbar%s", c.ok or 0, done, c.uebersprungen or 0,
        #why > 0 and (" – " .. table.concat(why, "; ")) or "") }
    if (c.fehler or 0) > 0 then lines[#lines + 1] = L("FEHLER: %d – bitte den Bericht schicken (kommt auch mit dem Upload).", c.fehler) end
    local P = LP.Pruefliste
    local l = P and P.List and P:List(true)
    if l and l.State then
        local open = {}
        for _, pt in ipairs(P.Points and P.Points() or {}) do
            if l:State(pt.id) == "offen" then open[#open + 1] = pt.title end
        end
        if #open > 0 then
            lines[#lines + 1] = L("Noch offen von Hand (passiert beim normalen Spielen, nichts zu warten): %s",
                table.concat(open, ", ", 1, math.min(5, #open)) .. (#open > 5 and (" …(+" .. (#open - 5) .. ")") or ""))
        end
    end
    return lines
end

function TR:Command(arg)
    arg = arg and arg:lower():gsub("^%s+", ""):gsub("%s+$", "") or ""
    if arg == "alles" or arg == "all" then return self:Run(nil, true, true) end
    if arg == "stopp" or arg == "stop" or arg == "abbrechen" or arg == "cancel" then
        if self.running then self.abort = L["vom Spieler abgebrochen"] LP:Reply(L["Testroutine wird abgebrochen – Bericht folgt."]) end
        return
    end
    if arg == "" then return self:Run(nil) end
    if #arg == 1 and AREAS:find(arg, 1, true) then return self:Run(arg) end
    if OBSERVE[arg] ~= nil then return self:Observe(arg) end
    if arg == "reise" or arg == "journey" then return self:Run(nil, true) end
    LP:Print(L["Testroutine: /lp testroutine [alles | stopp | a–k | kampf | haendler | quest | flug | trainer | gruppe]"])
end
